version       = "0.2.0"
author        = "geecode"
description   = "G-Code parser"
license       = "MIT"
srcDir        = "src"
bin           = @["geecode"]

requires "nim >= 1.6.0"
#requires "cligen >= 1.5.20"
