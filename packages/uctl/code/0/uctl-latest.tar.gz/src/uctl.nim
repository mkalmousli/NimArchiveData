
import std/strutils
import ./uctl/[util, help]
import std/parseopt

proc exitWithHelp() =
  priHelp()
  quit()

proc chkErr(res: CmdExecRes) =
  case res.status
  of csUnavail, csUnknown, csNeverSet, csPerm, csOutOfRange:
    quit res.errMsg
  of csAmbig:
    quit $res.status & ". Available matches: " & $res.matches
  of csSucc:
    discard

when isMainModule:
  var conf = newStringTable(modeStyleInsensitive)
  var args: seq[string] = @[]
  for (kind, k, v) in getopt(shortNoVal = {'h', '?'}, longNoVal = @["help"]):
    case kind
    of cmdLongOption:
      if k == "help":
        exitWithHelp()
      conf[k] = v
    of cmdShortOption:
      assert k.len == 1
      let kc = k[0]
      if kc in {'h', '?'}:
        exitWithHelp()
      # if is like `-1%`
      if kc in {'0'..'9', '.'} and
          v.strip(chars={'%'}, leading=false).allCharsInSet {'0'..'9', '.'}:
        args.add '-' & kc & v
        continue
      conf[k] = v
    of cmdArgument:
      args.add k
    else: doAssert false, "unreachable"
  let argn = args.len
  let subCmd = args[0]
  proc query(): string =
    let res = exec(subCmd)
    res.chkErr
    res.res
  case argn
  of 0:
    exitWithHelp()
  of 1:
    echo query()
  of 2:
    let sval = args[1]
    let res = exec(subCmd, sval, conf)
    res.chkErr
  else:
    quit("too many arguments")
