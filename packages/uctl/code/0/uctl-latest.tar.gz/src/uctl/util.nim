
static:assert defined(linux), "This module is only for Linux platform"
import std/options
import std/os
import std/osproc
import std/paths
from std/strutils import stripLineEnd, parseInt, parseFloat,
  formatFloat, FloatFormatMode,
  rsplit, join
import std/critbits
import std/macros
import std/strtabs

export strtabs

import ./units

const SysClass* = Path"/sys/class/"
when (NimMajor, NimMinor, NimPatch) > (2, 1, 1):
  export paths.`$`
else:
  proc `$`*(p: Path): string {.inline.} = string(p)

type
  Accessor = ref object of RootObj
    conf: StringTableRef
    writable: bool

  AccessorAux = ref object of Accessor

  PathAccessor = ref object of AccessorAux
    root: Path
    nameCur, nameFull: string ## subpath based on `root`
  PathFbAccessor = ref object of PathAccessor
    nameCurPercentFallback: string
  
  CmdAccessor = ref object of AccessorAux
    getCmd: proc (): string
    setCmd: proc (val: string)

  RangeError* = object of ValueError
    max: int

template notImpl = doAssert false, "not implemented"
template emptyn: NimNode = newEmptyNode()
macro parentNotImpl(def) =
  result = newStmtList()
  var
    parParams = def.params.copyNimTree
    parPragmas = def.pragma.copyNimTree
  parParams[1][1] = bindSym"Accessor"
  let parName = def[0]
  var parImpl = def.kind.newTree(
    parName, emptyn, emptyn,
    parParams, parPragmas, emptyn, bindSym"notImpl")
  parImpl.addPragma ident"base"
  result.add parImpl
  result.add def

using self: AccessorAux
method cur*(self): int{.base.} = notImpl()
method full*(self: AccessorAux): int{.base.} = notImpl()
proc checkValInRange(self; val: int) =
  if val < 0 or val > self.full:
    let exc = newException(RangeError, "value out of range")
    exc.max = self.full
    raise exc
method `cur=`*(self: AccessorAux; val: int){.base.} = notImpl()

method `%=`*(self; per: float){.base.} =
  ## set by percent,
  ## 
  ## Does nothing with `mod` !
  let v = int(per * float self.full)
  self.cur = v

method `%`*(self): float{.base.} = self.cur / self.full


method `$$`*(self): string {.parentNotImpl.} =
  (%self * 100).formatFloat(ffDecimal, 1) & "%"

method `$$=`*(self; sval: string) {.parentNotImpl.} =
  let val = parseUnit(sval, proc (): float = %self)
  self %= val

template read[T](t: typedesc[T]; path: string): T =
  var s = readFile(path)
  s.stripLineEnd
  `parse t` s


template path[T: PathAccessor](self: T, attr: untyped): Path = self.root/Path(self.`name attr`)
template genGetMeth(attr; T:untyped=int, Self=PathAccessor){.dirty.} =
  method attr*(self: Self): T = read(T, $self.path(attr))
template genGet(attr; T:untyped=int, Self=PathAccessor){.dirty.} =
  proc attr*(self: Self): T = read(T, $self.path(attr))

genGetMeth cur
genGetMeth full
genGet curPercentFallback, float, PathFbAccessor

const NeverWriteErrMsg = "the value cannot be set"
type
  PermissionError* = object of OSError

const PermErrMsg* = "No enough permission. you may need to rerun via `sudo` or root"

using self: PathAccessor
method `cur=`*(self; val: int) =
  self.checkValInRange(val)
  assert self.writable, NeverWriteErrMsg
  var f: File
  try:
    f = open($self.path(cur), fmWrite)
  except IOError:
    raise newException(PermissionError, PermErrMsg)
  f.write val
  f.close()

method `%`*(self: PathFbAccessor): float =
  ## get percent
  try:
    procCall(%PathAccessor(self))
  except IOError:
    self.curPercentFallback / 100

method `$$`*(self: CmdAccessor): string = self.getCmd()
method `$$=`*(self: CmdAccessor; sval: string) = self.setCmd(sval)

using patterns: openArray[string]

proc sysClassPath(subdir: string, patterns): Option[Path] =
  let resPatPre = ($SysClass / subdir)
  var res: seq[string]
  for pat in patterns:
    let resPat = resPatPre / pat
    for i in resPat.walkPattern:
      res.add i
  case res.len
  of 0:
    return
  of 1:
    result = some(Path(res[0]))
  else:
    assert false, "multiply target dir in " & $SysClass & " found: " & $res

proc newPathAccessor(root: Path, nameCur, nameFull: string): Accessor =
  PathAccessor(root: root, nameCur: nameCur, nameFull: nameFull, writable: true)
proc newPathAccessor(root: Path, nameCur, nameFull, nameCurPercentFallback: string): Accessor =
  assert nameCurPercentFallback != ""
  PathFbAccessor(root: root, nameCur: nameCur, nameFull: nameFull, nameCurPercentFallback: nameCurPercentFallback)

macro genAccPair(args: untyped, prcBody: untyped) =
  let untyp = ident"untyped"
  var params = @[untyp]
  let arg1 = ident"fullnameId"
  params.add newIdentDefs(arg1, untyp)
  for def in args:
    params.add:
      case def.kind
      of nnkExprColonExpr: newIdentDefs(def[0], def[1])
      of nnkIdent: newIdentDefs(def, untyp)
      else: raise newException(ValueError, "expect ident or ident: type, but got " & $def.kind)
  let body = nnkTupleConstr.newTree(
    newCall(bindSym"astToStr", arg1),
    newProc(params=[bindSym"Accessor"], body=prcBody)
  )
  result = newProc(ident"accPair", params, body, procType=nnkTemplateDef)
  result.addPragma ident"dirty"
  # template accPair(fullnameId; *<args>){.dirty.} = (astToStr(fullnameId), proc (): Accessor = <prcBody>)

template genSysClassPathGetter(root; subdir, patterns) =
  let opt = sysClassPath(subdir, patterns)
  if opt.isNone:
    return  # this exit the callee function
  let root = opt.unsafeGet

genAccPair (subdir: string, patterns: openArray[string], nameCur, nameFull, fallback: string):
  genSysClassPathGetter(root, subdir, patterns)
  newPathAccessor(root, nameCur, nameFull, fallback)

genAccPair (subdir: string, patterns: openArray[string], nameCur, nameFull: string):
  genSysClassPathGetter(root, subdir, patterns)
  newPathAccessor(root, nameCur, nameFull)

proc chkExec(cmd: string): string =
  let tup = execCmdEx(cmd)
  if tup.exitCode != 0:
    raise newException(OSError, cmd.repr & " failed: " & $tup)
  result = tup.output

const VCPFeatureBrightness = "0x10" # VCP code for brightness
type
  ExtraBriAccessor = ref object of AccessorAux
    cmdPre = "ddcutil --terse "
    displayId: int = 1
    fullCache: int

using self: ExtraBriAccessor
proc cmd(self; subcmd: string, args: varargs[string]): string =
  self.cmdPre & " --display " & $self.displayId & ' ' & subcmd & ' ' & args.join(" ")

proc getExtraBriValue(self): tuple[cur, full: string] =
  var res = chkExec(self.cmd("getvcp", VCPFeatureBrightness))
  res.stripLineEnd
  # e.g.
  # VCP 10 C 2 100
  let arr = res.rsplit(' ', 2)
  result.cur = arr[1]
  result.full = arr[2]

proc setupCfg(self) =
  if self.conf == nil: return

  var disp: string
  template get(k) =
    disp = self.conf.getOrDefault(k, disp)
  get"d"
  get"display"
  if disp == "": return
  else: self.conf = nil
  self.displayId = parseInt disp

method full(self: ExtraBriAccessor): int =
  if self.fullCache > 0:
    return self.fullCache
  self.setupCfg
  let t = self.getExtraBriValue()
  result = parseInt t.full
  self.fullCache = result

method cur(self: ExtraBriAccessor): int =
  self.setupCfg
  let t = self.getExtraBriValue()
  result = parseInt t.cur

method `cur=`(self: ExtraBriAccessor; val: int) =
  self.checkValInRange(val)
  self.setupCfg
  let ret = chkExec(self.cmd("setvcp", VCPFeatureBrightness, $val))
  assert ret == ""

proc getFontSizeRepr: string =
  result = chkExec("showconsolefont --info")
  result.stripLineEnd
  # in form of `ROWSxCOLSxCOUNT`
  # We strip `xCOUNT` part
  result = result.rsplit('x', 1)[0]

proc setFontSize(sval: string) =
  if sval == "x2":
    discard chkExec("setfont -d")
  else:
    notImpl()

genAccPair (getCmdt, setCmdt):
  CmdAccessor(
    getCmd: getCmdt,
    setCmd: setCmdt,
    writable: true
  )
genAccPair (T): T(
  writable: true
)

let
  Key2AccGetter = toCritBitTree [
    accPair(battery, "power_supply", ["BAT?", "battery"], "energy_now", "energy_full", fallback="capacity"),
    # BAT1 for most laptops; BAT0 for some; battery for Android (no perm if non-root; contains multi-subdir; has only `capacity`)
    accPair(brightness, "backlight", ["acpi_video", "*_backlight"],  "brightness", "max_brightness"),
    # acpi_video for ATI's; intel_backlight for intel's
    accPair(font, getFontSizeRepr, setFontSize),
    accPair(ebrightness, ExtraBriAccessor)
  ]
template loopAvailCmdsByIt*(cb) =
  bind Key2AccGetter, keys
  for it{.inject.} in Key2AccGetter.keys: cb

type
  CmdStatus* = enum
    csSucc = "successful"
    csAmbig = "cmd is ambiguous"
    csUnavail = "cmd is unavailable on your platform"
    csUnknown = "unknown cmd is given"
    csNeverSet = NeverWriteErrMsg
    csPerm = PermErrMsg
    csOutOfRange = "value out of range"

  CmdExecRes* = object
    case status*: CmdStatus
    of csSucc:
      res*: string
    of csAmbig:
      matches*: seq[string]
    else:
      errMsg*: string

const DefVal = ""
proc isDefVal(f: string): bool = f == ""

proc exec*(subcmd: string, val = DefVal, conf: StringTableRef=nil): CmdExecRes =
  var matches: seq[typeof(Key2AccGetter[""])]
  var matchesCmd: seq[string]
  for (k, v) in Key2AccGetter.pairsWithPrefix subcmd:
    matches.add v
    matchesCmd.add k
  template retStatus(st: CmdStatus; terrMsg) =
    return CmdExecRes(status: st, errMsg: terrMsg)
  template retStatus(st: CmdStatus{atom}) =
    retStatus(st, $st)
  case matches.len
  of 0:
    retStatus csUnknown
  of 1:
    let opt = matches[0]()
    if opt.isNil:
      retStatus csUnavail
    let acc = opt
    acc.conf = conf
    if val.isDefVal:
      result.res = $$acc
    else:
      if not acc.writable:
        retStatus csNeverSet
      result.res = val
      try:
        acc $$= val
      except PermissionError:
        retStatus csPerm
      except RangeError as e:
        retStatus csOutOfRange, $csOutOfRange &
          " (for value: " & val & "). Valid range: 0 .. " & $(e.max) & "%"
  else:
    return CmdExecRes(
      status: csAmbig,
      matches: matchesCmd
    )
