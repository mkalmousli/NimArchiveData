# This testing file is intended to test if functions available
# for end-users work as expected, regardless of how more internal
# functions implement the parsing

import
  unittest,
  clap2,
  options

proc getMatches(app: var App, args: seq[string]): ArgMatches =
  result = initArgMatches(app.name)
  var a: seq[string] = args
  app.get_matches_from(result, a)

# FIXME: newApp(): AppRef doesn't immediately return a chainable app
# for all methods, they'll need dereferencing
template newApp0: var App = newApp("").author("")

var
  a: App
  m: ArgMatches
  arg1: Arg

let
  aopt = "aopt"
  bopt = "bopt"

suite "flags":
  test "only 1 short flag":
    a = newApp("").arg(newArg(aopt).short("-a"))
    check:
      a.getMatches(@[]).is_present(aopt) == false
      a.getMatches(@["-a"]).is_present(aopt) == true
      a.getMatches(@["-a", "-a"]).is_present(aopt) == true

  test "only 1 long flag":
    a = newApp("").arg(newArg(aopt).long("--alpha"))
    check:
      a.getMatches(@[]).is_present(aopt) == false
      a.getMatches(@["--alpha"]).is_present(aopt) == true
      a.getMatches(@["--alpha", "--alpha"]).is_present(aopt) == true

  test "only 1 short + long flag":
    a = newApp("").arg(newArg(aopt).short("-a").long("--alpha"))
    check:
      a.getMatches(@[]).is_present(aopt) == false
      a.getMatches(@["-a"]).is_present(aopt) == true
      a.getMatches(@["--alpha"]).is_present(aopt) == true

  test "2 flags":
    a = newApp("").args(@[
      newArg(aopt).short("-a"),
      newArg(bopt).short("-b"),
    ])

    template check_presences(args: seq[string], aopt, bopt: bool) =
      m = a.getMatches(args)
      check:
        m.is_present("aopt") == aopt
        m.is_present("bopt") == bopt

    check_presences(@[], aopt=false, bopt=false)
    check_presences(@["-a"], aopt=true, bopt=false)
    check_presences(@["-b"], aopt=false, bopt=true)
    check_presences(@["-a", "-b"], aopt=true, bopt=true)
    check_presences(@["-ab"], aopt=true, bopt=true)

  test "multiple":
    arg1 = newArg(aopt).short("-a").multiple(true)
    a = newApp("").arg(arg1)
    check:
      a.getMatches(@[]).occurrences_of(aopt) == 0
      a.getMatches(@["-a"]).occurrences_of(aopt) == 1
      a.getMatches(@["-a", "-a"]).occurrences_of(aopt) == 2

    arg1 = arg1.multiple(false)
    a = newApp("").arg(arg1)
    check:
      a.getMatches(@[]).occurrences_of(aopt) == 0
      a.getMatches(@["-a"]).occurrences_of(aopt) == 1
      a.getMatches(@["-a", "-a"]).occurrences_of(aopt) == 1

  test "exclusive":
    a = newApp("").args(@[
      newArg(aopt).short("-a").mutually_excludes(bopt),
      newArg(bopt).short("-b"),
    ])
    expect ValueError:
      discard a.getMatches(@["-a", "-b"])

  # TODO: this test works if we change .report_error() to
  # raise a ValueError exception instead of quit()
  # proc report_error*(self: App, msg: string, help: bool = false, quit: bool = false, except_msg: string = "") =
  #  ...raise newException(ValueError, except_msg)
  #
  #test "requires":
    #a = newApp("").args(@[
      #newArg(aopt).short("-a").requires(bopt),
      #newArg(bopt).short("-b"),
    #])
    #expect ValueError:
      #discard a.getMatches(@["-a"])


suite "options with 1 argument":
  template check_presences(args: seq[string], present: bool, value: Option[string]) =
    m = a.getMatches(args)
    check:
      m.is_present(aopt) == present
      m.value_of(aopt) == value

  test "short option":
    a = newApp("").arg(newArg(aopt).short("-a").takes_value(true))
    check_presences(@[], false, none(string))
    check_presences(@["-a", "val"], true, some("val"))

  test "long option":
    a = newApp("").arg(newArg(aopt).long("--alpha").takes_value(true))
    check_presences(@[], false, none(string))
    check_presences(@["--alpha", "val"], true, some("val"))
    check_presences(@["--alpha=val"], true, some("val"))
    #check_presences(@["--alpha:val"], true, some("val"))  # TODO

  #test "required":
    #a = newApp("").arg(newArg("aopt").short("-a").takes_value(true).required(true))
    #m = a.getMatches(@["-a", "val"])
    #check:
      #m.is_present("aopt") == true
      #m.value_of("aopt").isSome() == true
      #m.value_of("aopt").unsafeGet() == "val"
    #m = a.getMatches(@[])
    #check:
      #m.is_present("aopt") == false

suite "subcommands":
  template check_presences(sc_name: string, args: seq[string], present: bool, value: Option[string]) =
    m = a.getMatches(args)
    check:
      m.subcommand_matches(sc_name).isSome() == present
      m.subcommand_name() == value

  test "1 subcommand":
    a = newApp("").subcommand(newSubCommand("sub1"))
    check_presences("sub1", @[], false, none(string))
    check_presences("sub1", @["sub1"], true, some("sub1"))

  test "subcommand with options":
    a = newApp("")
      .subcommand(
        newSubCommand("sub1")
        .arg(newArg("mya").short("-a"))
      )
    m = a.getMatches(@["sub1", "-a"])

    check:
      m.subcommand_matches("sub1").isSome() == true
      m.subcommand_name() == some("sub1")

  test "many subcommands":
    a = newApp("")
      .subcommands(@[
        newSubCommand("sub1"),
        newSubCommand("sub2"),
      ])

    check_presences("sub1", @[], false, none(string))
    check_presences("sub1", @["sub1"], true, some("sub1"))
    check_presences("sub2", @["sub2"], true, some("sub2"))
