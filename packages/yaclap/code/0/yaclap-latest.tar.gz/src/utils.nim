import options, tables

template letSome*[T](name: untyped, opt: Option[T]): untyped =
  (opt.isSome and (let name{.inject.} = opt.unsafeGet; true))

type AnyTable[T,U] = Table[T,U] | OrderedTable[T,U]

template letHasKey*[T, U](name: untyped, tab: AnyTable[T, U], keyName: untyped): untyped =
  (tab.hasKey(keyName) and (let name{.inject.} = tab[keyName]; true))

type Iterable*[T] = object
  curidx: uint
  data: seq[T]

proc initIterable[T](data: seq[T]): Iterable[T] =
  Iterable[T](
    curidx: 0'u32,
    data: data,
  )

proc newIterable*[T](data: seq[T]): ref Iterable[T] =
  new(result)
  result[] = initIterable[T](data)

proc nextOrNone[T](it: var Iterable[T]): Option[T] =
  # Rust-style next, returns an option. none() if exceeds index
  result = if it.curidx < it.data.len.uint:
    some(it.data[it.curidx])
  else:
    none(T)
  it.curidx += 1

iterator `next`*[T](it: ref Iterable[T]): T =
  while (
    let i = it[].nextOrNone()
    i.isSome()
  ):
    yield i.unsafeGet()
