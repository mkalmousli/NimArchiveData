{.experimental: "codeReordering".}

import options, tables, sets, strformat, strutils, os
import ./utils

# clap.rs's commit bases on: 152aa891

type FlagArg* = object
  name*: string
  short*: Option[char]
  long*: Option[string]
  help*: Option[string]
  multiple*: bool
  occurrences*: uint8
  blacklist*: Option[seq[string]]
  requires*: Option[seq[string]]

type OptArg* = object
  name*: string
  short*: Option[char]
  long*: Option[string]
  help*: Option[string]
  required*: bool
  requires*: Option[seq[string]]
  blacklist*: Option[seq[string]]
  value*: Option[string]

type PosArg* = object
  name*: string
  help*: Option[string]
  required*: bool
  requires*: Option[seq[string]]
  blacklist*: Option[seq[string]]
  value*: Option[string]
  index*: uint8

type
  App* = object
    name*: string
    author*: Option[string] = none(string)
    version*: Option[string] = none(string)
    about*: Option[string] = none(string)

    flags*: Table[string, FlagArg]
    opts*: Table[string, OptArg]
    positionals_idx*: OrderedTable[uint8, PosArg]
    #positionals_name*: Table[string, PosArg]
    subcommands*: Table[string, App]
    needs_long_help*: bool = true
    needs_long_version*: bool = true
    needs_short_help*: bool = true
    needs_short_version*: bool = true
    needs_subcmd_help: bool = true
    required*: HashSet[string]
    arg_list*: HashSet[string]
    short_list*: HashSet[char]
    long_list*: HashSet[string]
    blacklist*: HashSet[string]
  AppRef* = ref App

proc initApp*(name: string): App =
  App(name: name)

func newApp*(name: string): AppRef =
  new(result)
  result[] = initApp(name)

#################
# subcommand.nim
#################
type SubCommand* = object
  name*: string
  matches*: ref ArgMatches

proc initSubCommand*(name: string): App =
  initApp(name)

func newSubCommand*(name: string): ref App =
  new(result)
  result[] = initSubCommand(name)


#############
# argmatches
#############
type ArgMatches* = object
  matches_of*: string
  flags*: Table[string, FlagArg]
  opts*: Table[string, OptArg]
  positionals*: Table[string, PosArg]
  subcommand: Option[(string, Subcommand)]

proc initArgMatches*(name: string): ArgMatches =
  ArgMatches(matches_of: name)

proc newArgMatches*(name: string): ref ArgMatches =
  new(result)
  result[] = initArgMatches(name)

proc value_of*(self: ArgMatches, name: string): Option[string] =
  if letHasKey(opt, self.opts, name):
    if letSome(v, opt.value):
      return some(v)
  if letHasKey(pos, self.positionals, name):
    if letSome(v, pos.value):
      return some(v)
  none(string)

proc is_present*(self: ArgMatches, name: string): bool =
  if self.subcommand.isSome:
    let (sc_name, _) = self.subcommand.unsafeGet
    if sc_name == name:
      return true
  if self.flags.hasKey(name) or self.opts.hasKey(name) or self.positionals.hasKey(name):
    return true
  return false

proc occurrences_of*(self: ArgMatches, name: string): uint8 =
  ## This **DOES NOT** work for option or positional arguments
  if letHasKey(f, self.flags, name):
    return f.occurrences
  0'u8

proc subcommand_matches*(self: var ArgMatches, name: string): Option[ArgMatches] =
  if self.subcommand.isSome:
    let (sc_name, sc) = self.subcommand.unsafeGet
    if sc_name != name:
      return none(ArgMatches)
    return some(sc.matches[])

  return none(ArgMatches)

proc subcommand_name*(self: var ArgMatches): Option[string] =
  if self.subcommand.isSome:
    let (name, _) = self.subcommand.unsafeGet
    return some(name)
  return none(string)


######
# arg
######
type
  Arg* = object
    name*: string
    short*: Option[char] = none(char)
    long*: Option[string] = none(string)
    help*: Option[string] = none(string)
    required*: bool = false
    takes_value*: bool = false
    index*: Option[uint8] = none(uint8)
    multiple*: bool = false
    blacklist*: Option[seq[string]] = some(newSeq[string]())
    requires*: Option[seq[string]] = some(newSeq[string]())
  ArgRef* = ref Arg

proc initArg*(name: string): Arg =
  Arg(name: name)

proc newArg*(name: string): ref Arg =
  new(result)
  result[] = initArg(name)

proc short*(self: var Arg, s: string): var Arg =
  # TODO: add exception
  self.short = some( (if s[0] == '-': s.substr(1) else: s)[0])
  self

proc long*(self: var Arg, s: string): var Arg =
  self.long = some(if s[0..1] == "--": s.substr(2) else: s)
  self

proc help*(self: var Arg, h: string): var Arg =
  self.help = some(h)
  self

proc required*(self: var Arg, r: bool): var Arg =
  self.required = r
  self

proc mutually_excludes*(self: var Arg, name: string): var Arg =
  let blacklist: ptr = self.blacklist.addr
  if blacklist[].isSome():
    let vec = blacklist[].get.addr
    vec[].add(name)
  else:
    blacklist[] = some(newSeq[string]())
  self

proc mutually_excludes_all*(self: var Arg, names: seq[string]): var Arg =
  let blacklist: ptr = self.blacklist.addr
  if blacklist[].isSome():
    let vec = blacklist[].get.addr
    for n in names:
      vec[].add(n)
  else:
    blacklist[] = some(newSeq[string]())
  self

proc requires*(self: var Arg, name: string): var Arg =
  let requires: ptr = self.requires.addr
  if requires[].isSome():
    let vec = requires[].get.addr
    vec[].add(name)
  else:
    requires[] = some(newSeq[string]())
  self

proc requires_all*(self: var Arg, names: seq[string]): var Arg =
  let requires: ptr = self.requires.addr
  if requires[].isSome():
    let vec = requires[].get.addr
    for n in names:
      vec[].add(n)
  else:
    requires[] = some(newSeq[string]())
  self

proc takes_value*(self: var Arg, tv: bool): var Arg =
  assert self.index == none(uint8)
  self.takes_value = tv
  self

proc index*(self: var Arg, idx: uint8): var Arg =
  assert self.takes_value == false
  if idx < 1:
    echo "Argument index must start at 1"
  self.index = some(idx)
  result = self

proc multiple*(self: var Arg, multi: bool): var Arg =
  assert self.takes_value == false
  assert self.index == none(uint8)
  self.multiple = multi
  self


######
# app
######

proc author*(self: var App, a: string): var App =
  self.author = some(a)
  self

# Why do some methods need dereferencing for proper chain
# combinations after newApp() without [] and others don't?

proc about*(self: var App, a: string): var App =
  self.about = some(a)
  self

proc version*(self: var App, a: string): var App =
  self.version = some(a)
  self

proc arg*(self: var App, a: Arg): var App =
  if self.arg_list.contains(a.name):
    echo("Argument name must be unique, \"{}\" is already in use")
    quit(22)
  else:
    self.arg_list.incl(a.name)

  # Shorts
  if letSome(s, a.short):
    if self.short_list.contains(s):
      echo("Argument short must be unique, -" & $s & " is already in use")
      quit(22)
    else:
      self.short_list.incl(s)

  # Longs
  if letSome(l, a.long):
    if self.long_list.contains(l):
      echo("Argument short must be unique, --" & $l & " is already in use")
      quit(22)
    else:
      self.long_list.incl(l)

  if a.required:
    self.required.incl(a.name)

  if letSome(i, a.index):
    self.positionals_idx[i] = PosArg(
      name: a.name,
      index: i,
      required: a.required,
      blacklist: a.blacklist,
      requires: a.requires,
      help: a.help,
      value: none(string),
    )
  elif a.takes_value:
    if a.short.isNone() and a.long.isNone():
      echo("An argument that takes a value must have either a .short() or .long() [or both] assigned")
      quit(22)

    self.opts[a.name] = OptArg(
      name: a.name,
      short: a.short,
      long: a.long,
      blacklist: a.blacklist,
      help: a.help,
      requires: a.requires,
      required: a.required,
      value: none(string),
    );

  else:
    if a.long.isSome():
      let l = a.long.get()
      if l == "-help":
        self.needs_long_help = false
      elif l == "-version":
        self.needs_long_version = false

    if a.short.isSome():
      let l = a.short.get()
      if l == 'h':
        self.needs_long_help = false
      elif l == 'v':
        self.needs_long_version = false

    if a.short.isNone() and a.long.isNone():
      echo("A flag argument must have either a .short() or .long() [or both] assigned")
      quit(22)

    # Flags can't be required
    if self.required.contains(a.name):
      self.required.excl(a.name)

    self.flags[a.name] = FlagArg(
      name: a.name,
      short: a.short,
      long: a.long,
      help: a.help,
      multiple: a.multiple,
      occurrences: 1,
      blacklist: a.blacklist,
      requires: a.requires,
    )
  self

proc arg*(self: AppRef, a: Arg): var App = arg(self[], a)

proc args*(self: var App, a: seq[Arg]): var App =
  for x in a:
    discard self.arg(x)
  self

proc args*(self: AppRef, a: seq[Arg]): var App = args(self[], a)

proc subcommand*(self: var App, subcmd: App): var App =
  if subcmd.name == "help":
    self.needs_subcmd_help = false
  self.subcommands[subcmd.name] = subcmd
  self

proc subcommand*(self: var App, subcmd: AppRef): var App = subcommand(self, subcmd[])
proc subcommand*(self: AppRef, subcmd: var App): var App = subcommand(self[], subcmd)
proc subcommand*(self: AppRef, subcmd: AppRef): var App = subcommand(self[], subcmd[])


proc subcommands*(self: var App, subcmds: seq[App]): var App =
  for subcmd in subcmds:
    discard self.subcommand(subcmd)
  self

proc subcommands*(self: var App, subcmds: seq[AppRef]): var App =
  for subcmd in subcmds:
    discard self.subcommand(subcmd[])
  self

proc exit*(self: var App) =
  quit(0)

proc print_version*(self: App, quit: bool = false) =
  if letSome(v, self.version):
    echo(self.name, " ", v)
  else:
    echo(self.name)
  if quit:
    quit(0)

proc print_help*(self: App) =
  self.print_version(false);
  var
    flags = false
    opts = false
    pos = false
    subcmds = false

  if letSome(author, self.author):
    echo author

  if letSome(about, self.about):
    echo about

  echo()
  echo("USAGE:")

  # Synopsis
  var usage_msg: string
  usage_msg &= "  " & self.name

  if self.flags.len() != 0:
    flags = true
    usage_msg &= " [FLAGS]"

  if self.opts.len() != 0:
    opts = true
    usage_msg &= " [OPTIONS]"

  if self.positionals_idx.len() != 0:
    pos = true
    usage_msg &= " [POSITIONAL]"

  if self.subcommands.len() != 0:
    subcmds = true
    usage_msg &= " [SUBCOMMANDS]"

  echo(usage_msg)

  if flags:
    echo()
    echo("FLAGS:")
    for k, v in self.flags.pairs:
      echo fmt"""  {(
        if letSome(short, v.short): "-" & $short else: "   "
      )}{(
        if letSome(long, v.long): ", --" & $long else: "   \t"
      )}""" & "\t\t" & fmt"""{(
        if letSome(help, v.help): $help else: "   "
      )}"""

  if opts:
    echo()
    echo("OPTIONS:")
    for k, v in self.opts.pairs:
      echo fmt"""  {(
        if v.short.isSome(): "-" & $v.short.get() else: "   "
      )}{(
        if v.long.isSome(): ", --" & $v.long.get() else: "   \t"
      )} <{v.name}>""" & "\t\t" & fmt"""{(
        if v.help.isSome(): $v.help.get() else: "   "
      )}"""

  if pos:
    echo()
    echo("POSITIONAL ARGUMENTS:")
    for k, v in self.positionals_idx.pairs:
      echo "  " & $v.name & "\t\t\t" & fmt"""{(
        if v.help.isSome(): $v.help.get() else: "   "
      )}"""

  if subcmds:
    echo()
    echo("SUBCOMMANDS:")
    for k, sc in self.subcommands.pairs:
      echo "  " & $sc.name & "\t\t" & fmt"""{(
        if sc.about.isSome(): $sc.about.get() else: "   "
      )}"""

  quit(22)


proc report_error*(self: App, msg: string, help: bool = false, quit: bool = false) =
  echo(msg)
  if help:
    self.print_help()
  if quit:
    quit(1)

proc check_for_help_and_version*(self: var App, arg: char) =
  if arg == 'h' and self.needs_short_help:
      self.print_help()
  elif arg == 'v' and self.needs_short_version:
      self.print_version(true);

proc parse_long_arg(self: var App, matches: var ArgMatches, full_arg: string): Option[string] =
  var
    arg = full_arg.substr(2)  #**recheck
    found = false

  if arg == "help" and self.needs_long_help:
    self.print_help()
  elif arg == "version" and self.needs_short_version:
    self.print_version(true)

  var arg_val: Option[string] = none(string)

  # get the word before "=" separator
  if arg.contains("="):
    let arg_vec = arg.split("=")
    arg = arg_vec[0]
    arg_val = some(arg_vec[1])

  for k, v in self.opts.pairs:
    if letSome(l, v.long):
      if l == arg:
        if self.blacklist.contains(k):
          self.report_error(fmt"The argument --{arg} is mutually exclusive with one or more other arguments", false, true)
        matches.opts[k] = OptArg(
          name: v.name,
          short: v.short,
          long: v.long,
          help: v.help,
          required: v.required,
          blacklist: none(seq[string]),
          requires: none(seq[string]),
          value: arg_val,
        )
        if arg_val.isSome():
          return none(string)
        else:
          return some(v.name)

  for k, v in self.flags.pairs:
    if letSome(l, v.long):
      if l != arg:
        continue
      found = true
      var multi = false

      let flags: ptr = matches.flags.addr
      if flags[].hasKey(k):
        let f: ptr = flags[][k].addr
        f.occurrences = if f.multiple: f.occurrences + 1 else: 1
        multi = true

      if not multi:
        if self.blacklist.contains(k):
          self.report_error(fmt"The argument --{arg} is mutually exclusive with one or more other arguments", false, true)

        matches.flags[k] = FlagArg(
          name: v.name,
          short: v.short,
          long: v.long,
          help: v.help,
          multiple: v.multiple,
          occurrences: v.occurrences,
          blacklist: none(seq[string]),
          requires: none(seq[string]),
        )

        if self.required.contains(k):
          self.required.excl(k)

        if letSome(bl, v.blacklist):
          if bl.len() != 0:
            for name in bl:
              self.blacklist.incl(name)

      if letSome(reqs, v.requires):
        if reqs.len() != 0:
          for n in reqs:
            if matches.opts.hasKey(n): continue
            if matches.flags.hasKey(n): continue
            if matches.positionals.hasKey(n): continue
            self.required.incl(n)

      break

  if not found:
    self.report_error(fmt"Argument --{arg} isn't valid", false, true)

  none(string)


proc parse_single_short_flag(self: var App, matches: var ArgMatches, arg: char): bool =
  for k, v in self.flags:
    if letSome(s, v.short):
      if s != arg:
        continue

      if not matches.flags.hasKey(k):
        if self.blacklist.contains(k):
          self.report_error(fmt"The argument -{arg} is mutually exclusive with one or more other arguments", false, true)

        matches.flags[k] = FlagArg(
          name: v.name,
          short: v.short,
          long: v.long,
          help: v.help,
          multiple: v.multiple,
          occurrences: v.occurrences,
          blacklist: none(seq[string]),
          requires: none(seq[string]),
        )

        if self.required.contains(k):
          self.required.excl(k)

        if letSome(reqs, v.requires):
          if reqs.len() != 0:
            for n in reqs:
              if matches.opts.hasKey(n): continue
              if matches.flags.hasKey(n): continue
              if matches.positionals.hasKey(n): continue
              self.required.incl(n)

        if letSome(bl, v.blacklist):
          if bl.len() != 0:
            for name in bl:
              self.blacklist.incl(name)

      elif matches.flags.hasKey(k):
        let k: ptr = matches.flags[k].addr
        if k.multiple:
          k.occurrences += 1

      return true
  false

proc parse_short_arg(self: var App, matches: var ArgMatches, full_arg: string): Option[string] =
  let arg = full_arg.substr(1)  #**recheck
  if arg.len() > 1:
    # Multiple combined short flags
    #for c in arg.runes():
    # to-do: accept unicode rune chars
    for c in arg:
      self.check_for_help_and_version(c)
      if not self.parse_single_short_flag(matches, c):
        self.report_error(fmt"Argument -{c} isn't valid", false, true)
  else:
    # Short flag or opt
    let arg_c = arg[0]
    # FIXME: when user sets custom -h or -v, don't use this
    self.check_for_help_and_version(arg_c)

    if not self.parse_single_short_flag(matches, arg_c):
      for k, v in self.opts:
        if letSome(s, v.short):
          if s == arg_c:
            return some(k)
      self.report_error(fmt"Argument -{arg_c} isn't valid", false, true)
  none(string)


proc validate_blacklist(self: var App, matches: ArgMatches) =
  if self.blacklist.len() != 0:
    for name in self.blacklist:
      for k, v in matches.flags:
        # todo: deduplicate
        if k == name:
          self.report_error(fmt"""The argument {(
          if letSome(s, v.short):
            "-" & s
          elif letSome(l, v.long):
            "--" & l
          else:
            "\"" & $v.name & "\""
          )} is mutually exclusive with one or more other arguments""", false, true)

      for k, v in matches.opts:
        if k == name:
          self.report_error(fmt"""The argument {(
          if letSome(s, v.short):
            "-" & s
          elif letSome(l, v.long):
            "--" & l
          else:
            "\"" & $v.name & "\""
          )} is mutually exclusive with one or more other arguments""", false, true)

      for k, v in matches.positionals:
        if k == name:
          self.report_error(fmt"The argument {v.name} is mutually exclusive with one or more other arguments", false, true)

proc create_help_and_version(self: var App): void =
  if self.needs_long_help:
    self.flags["clap_help"] = FlagArg(
      name: "clap_help",
      short: if self.needs_short_help: some('h') else: none(char),
      long: some("help"),
      help: some("Prints this message"),
      blacklist: none(seq[string]),
      multiple: false,
      requires: none(seq[string]),
      occurrences: 1,
    )

  if self.needs_long_version:
    self.flags["clap_version"] = FlagArg(
      name: "clap_version",
      short: if self.needs_short_help: some('v') else: none(char),
      long: some("version"),
      help: some("Prints version information"),
      blacklist: none(seq[string]),
      requires: none(seq[string]),
      multiple: false,
      occurrences: 1,
    )

  if self.needs_subcmd_help:
    var app = initApp("help")
    self.subcommands["help"] = app.about("Print this message")


proc get_matches_from*(self: var App, matches: var ArgMatches, it: ref Iterable[string]) =
  self.create_help_and_version()

  var subcmd_name: Option[string] = none(string)
  var needs_val_of: Option[string] = none(string)
  var pos_counter = 1'u8
  for arg in it.next():
    var skip = false

    if letSome(nvo, needs_val_of):
      if letHasKey(opt, self.opts, nvo):

        if self.blacklist.contains(opt.name):
          self.report_error(fmt"""The argument {(
            if opt.long.isSome():
              "--" & opt.long.get()
            elif opt.short.isSome():
              "-" & opt.short.get()
            else:
              ""
          )} is mutually exclusive with one or more other arguments""", false, true)

        # adding OptArg
        matches.opts[nvo] = OptArg(
          name: opt.name,
          short: opt.short,
          long: opt.long,
          help: opt.help,
          requires: none(seq[string]),
          blacklist: none(seq[string]),
          required: opt.required,
          value: some(arg),
        )

        if letSome(bl, opt.blacklist):
          if bl.len() != 0:
            for name in bl:
              self.blacklist.incl(name)

        if self.required.contains(opt.name):
          self.required.excl(opt.name)

        if letSome(reqs, opt.requires):
          if reqs.len() != 0:
            for n in reqs:
              if matches.opts.hasKey(n): continue
              if matches.flags.hasKey(n): continue
              if matches.positionals.hasKey(n): continue
              self.required.incl(n)
        skip = true

    if skip:
      needs_val_of = none(string)
      continue

    if arg.startsWith("--"):
      # Single flag, or option long version
      needs_val_of = self.parse_long_arg(matches, arg)
    elif arg.startsWith("-"):
      needs_val_of = self.parse_short_arg(matches, arg)
    else:
      # Positional or subcommand
      if letHasKey(sca, self.subcommands, arg):
        if sca.name == "help":
          self.print_help()
        subcmd_name = some(sca.name)
        break

      if self.positionals_idx.len() == 0:
        self.report_error(fmt"Found positional argument {arg}, but {self.name} doesn't accept any", false, true)

      if letHasKey(p, self.positionals_idx, pos_counter):
        if self.blacklist.contains(p.name):
          self.report_error(fmt"""The argument "{arg}" is mutually exclusive with one or more other arguments""", false, true)
        matches.positionals[p.name] = PosArg(
          name: p.name,
          help: p.help,
          required: p.required,
          blacklist: none(seq[string]),
          requires: none(seq[string]),
          value: some(arg),
          index: pos_counter,
        )
        if letSome(bl, p.blacklist):
          if bl.len() != 0:
            for name in bl:
              self.blacklist.incl(name)
        if self.required.contains(p.name):
          self.required.excl(p.name)
        if letSome(reqs, p.requires):
          if reqs.len() != 0:
            for n in reqs:
              if matches.opts.hasKey(n): continue
              if matches.flags.hasKey(n): continue
              if matches.positionals.hasKey(n): continue
              self.required.incl(n)
        pos_counter += 1
      else:
        self.report_error(fmt"""Positional argument "{arg}" was found, but {self.name} wasn't expecting any""", false, true);

  if letSome(a, needs_val_of):
    self.report_error(fmt"""Argument "{a}" requires a value but none was supplied""", false, true)

  if self.required.len() != 0:
    self.report_error("One or more required arguments were not supplied", false, true)

  self.validate_blacklist(matches);

  if letSome(sc_name, subcmd_name):
    let subcommands: ptr = self.subcommands.addr
    if subcommands[].hasKey(sc_name):
      var sc: ptr = subcommands[][sc_name].addr
      var new_matches = newArgMatches(sc_name)
      get_matches_from(sc[], new_matches[], it)
      matches.subcommand = some((sc_name, SubCommand(name: sc_name, matches: new_matches)))


proc get_matches_from*(self: var App, matches: var ArgMatches, it: var seq[string]) =
  get_matches_from(self, matches, it.newIterable())

proc get_matches*(self: var App): ArgMatches =
  var matches = initArgMatches(self.name)
  var args: seq[string] = commandLineParams()
  self.get_matches_from(matches, args.newIterable())
  matches
