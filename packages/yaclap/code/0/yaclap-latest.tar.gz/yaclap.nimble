# Package

version       = "0.1.0"
author        = "emanresu3"
description   = "Yet another command line argument parser"
license       = "MIT"
srcDir        = "src"

# Dependencies

requires "nim >= 2.0.4"
