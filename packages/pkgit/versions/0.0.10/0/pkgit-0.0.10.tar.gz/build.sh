nim c -d:release -o:pkgit src/pkgit.nim
