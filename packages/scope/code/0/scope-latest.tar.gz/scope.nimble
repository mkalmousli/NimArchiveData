# Package

version       = "0.1.00"
author        = "savannt"
description   = "Scope tracking for untyped macros"
license       = "MIT"
srcDir        = "src"


# Dependencies

requires "nim >= 1.0.0"
