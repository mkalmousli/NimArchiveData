import macros
import strutils, tables, sequtils, algorithm

import ../src/scope

macro analyzeScope(body: untyped): untyped =
  let scope = newScope()
  scope.walk(body)
  
  # Generate runtime code to show analysis
  var analysisStmts = newStmtList()
  
  analysisStmts.add quote do:
    echo "=== Scope Analysis ==="
    echo "All tracked identifiers:"
  
  # Add analysis for each identifier
  for name, info in scope:
    let nameStr = newLit(name)
    let totalUsages = newLit(info.all.len)
    
    analysisStmts.add quote do:
      echo "  ", `nameStr`, ": ", `totalUsages`, " total usages"
    
    for usage in info.all:
      let kindStr = case usage.kind:
        of ukDef: "DEF"
        of ukUse: "USE" 
        of ukShadow: "SHADOW"
      let kindLit = newLit(kindStr)
      let lineLit = newLit(usage.line)
      let depthLit = newLit(usage.scopeDepth)
      
      analysisStmts.add quote do:
        echo "    ", `kindLit`, " at line ", `lineLit`, ", scope depth ", `depthLit`
  
  # Analyze genericName specifically if it exists
  let genericInfo = scope.info("genericName")
  if genericInfo.name != "":
    let totalOccurrences = newLit(genericInfo.all.len)
    let isShadowed = newLit(scope.isShadowed("genericName"))
    let usageCount = newLit(scope.usagesOf("genericName").len)
    
    analysisStmts.add quote do:
      echo ""
      echo "Detailed analysis of 'genericName':"
      echo "  Total occurrences: ", `totalOccurrences`
      echo "  Is shadowed: ", `isShadowed`
      echo "  Usages only: ", `usageCount`
    
    for usage in genericInfo.all:
      let kindStr = case usage.kind:
        of ukDef: "defined"
        of ukUse: "used"
        of ukShadow: "shadowed"
      let kindLit = newLit(kindStr)
      let lineLit = newLit(usage.line)
      let depthLit = newLit(usage.scopeDepth)
      
      analysisStmts.add quote do:
        echo "    ", `kindLit`, " at line ", `lineLit`, " in scope depth ", `depthLit`
  
  # Show shadowed identifiers
  let shadowed = scope.shadowedIdents()
  if shadowed.len > 0:
    analysisStmts.add quote do:
      echo ""
      echo "Shadowed identifiers:"
    
    for info in shadowed:
      let nameLit = newLit(info.name)
      analysisStmts.add quote do:
        echo "  ", `nameLit`
  
  analysisStmts.add quote do:
    echo "=== End Analysis ==="
    echo ""
  
  # Combine analysis with original body
  result = newStmtList()
  result.add(analysisStmts)
  result.add(body)

macro inspectVariable(varName: static[string], body: untyped): untyped =
  let scope = newScope()
  scope.walk(body)
  
  let varInfo = scope.info(varName)
  var analysisStmts = newStmtList()
  
  if varInfo.name != "":
    let varNameLit = newLit(varName)
    let defDepth = newLit(varInfo.def.scopeDepth)
    let totalUsages = newLit(varInfo.all.len)
    let currentLevel = newLit(scope.currentScopeLevel())
    let inCurrentScope = newLit(scope.inCurrentScope(varName))
    let scopeWhere = newLit(scope.scopeOf(varName))
    
    analysisStmts.add quote do:
      echo "Variable '", `varNameLit`, "' analysis:"
      echo "  Defined at scope depth: ", `defDepth`
      echo "  Total usages: ", `totalUsages`
      echo "  Current scope level: ", `currentLevel`
      echo "  In current scope: ", `inCurrentScope`
      echo "  Scope where defined: ", `scopeWhere`
      echo ""
  else:
    let varNameLit = newLit(varName)
    analysisStmts.add quote do:
      echo "Variable '", `varNameLit`, "' not found in scope"
      echo ""
  
  result = newStmtList()
  result.add(analysisStmts)
  result.add(body)

macro showCurrentScope(body: untyped): untyped =
  let scope = newScope()
  
  # We'll track scope information and generate runtime output
  var scopeInfo: seq[tuple[line: int, level: int, symbols: seq[string]]]
  
  proc scopeCallback(n: NimNode, st: ScopeTracker) =
    if n.kind in {nnkBlockStmt, nnkIfStmt, nnkForStmt}:
      let lineInfo = n.lineInfoObj
      let currentLevel = st.currentScopeLevel()
      let symbols = st.currentScopeSymbols()
      scopeInfo.add((line: lineInfo.line, level: currentLevel, symbols: symbols))
  
  scope.walk(body, scopeCallback)
  
  # Generate runtime code to show scope information
  var analysisStmts = newStmtList()
  
  for info in scopeInfo:
    let lineLit = newLit(info.line)
    let levelLit = newLit(info.level)
    let symbolsLit = newLit(info.symbols.join(", "))
    
    analysisStmts.add quote do:
      echo "Entering scope at line ", `lineLit`, ", current level: ", `levelLit`
    
    if info.symbols.len > 0:
      analysisStmts.add quote do:
        echo "  Current scope contains: ", `symbolsLit`
  
  result = newStmtList()
  result.add(analysisStmts)
  result.add(body)

# Very simple test first - generate runtime output
macro basicTest(body: untyped): untyped =
  let scope = newScope()
  scope.walk(body)
  
  var outputStmts = newStmtList()
  outputStmts.add quote do:
    echo "=== BASIC TEST START ==="
    echo "Tracked identifiers:"
  
  for name, info in scope:
    let nameLit = newLit(name)
    let countLit = newLit(info.all.len)
    outputStmts.add quote do:
      echo "  ", `nameLit`, ": ", `countLit`, " usages"
    
    for usage in info.all:
      let kindStr = case usage.kind:
        of ukDef: "DEF"
        of ukUse: "USE"
        of ukShadow: "SHADOW"
      let kindLit = newLit(kindStr)
      let lineLit = newLit(usage.line)
      let depthLit = newLit(usage.scopeDepth)
      
      outputStmts.add quote do:
        echo "    ", `kindLit`, " at line ", `lineLit`, " depth ", `depthLit`
  
  outputStmts.add quote do:
    echo "=== BASIC TEST END ==="
  
  result = newStmtList()
  result.add(outputStmts)
  result.add(body)

basicTest:
  var a = 1
  if true:
    var a = 2

echo "\n" & "=".repeat(30) & "\n"

# Simple test to see what's being tracked - generate runtime output
macro simpleTest(body: untyped): untyped =
  let scope = newScope()
  
  var scopeCallbacks: seq[tuple[kind: NimNodeKind, line: int, level: int]]
  var identCallbacks: seq[tuple[name: string, line: int, level: int]]
  var varSectionInfo: seq[tuple[line: int, identCount: int, identNames: seq[string]]]
  
  proc simpleCallback(n: NimNode, st: ScopeTracker) =
    if n.kind in {nnkVarSection, nnkIfStmt, nnkElifBranch}:
      scopeCallbacks.add((kind: n.kind, line: n.lineInfoObj.line, level: st.currentScopeLevel()))
      
      # If this is a VarSection, let's see what identifiers it contains
      if n.kind == nnkVarSection:
        var identNames: seq[string]
        for child in n:
          if child.kind == nnkIdentDefs:
            for i in 0..<child.len-2:
              if child[i].kind == nnkIdent:
                identNames.add(child[i].strVal)
        varSectionInfo.add((line: n.lineInfoObj.line, identCount: identNames.len, identNames: identNames))
      
    elif n.kind == nnkIdent and n.strVal in ["debugVar", "testVar"]:
      identCallbacks.add((name: n.strVal, line: n.lineInfoObj.line, level: st.currentScopeLevel()))
  
  scope.walk(body, simpleCallback)
  
  var outputStmts = newStmtList()
  
  # Output scope callbacks
  for cb in scopeCallbacks:
    let kindLit = newLit($cb.kind)
    let lineLit = newLit(cb.line)
    let levelLit = newLit(cb.level)
    outputStmts.add quote do:
      echo "[SCOPE] ", `kindLit`, " at line ", `lineLit`, ", depth: ", `levelLit`
  
  # Output VarSection details
  for info in varSectionInfo:
    let lineLit = newLit(info.line)
    let countLit = newLit(info.identCount)
    let namesLit = newLit(info.identNames.join(", "))
    outputStmts.add quote do:
      echo "[VARSECTION] Line ", `lineLit`, " contains ", `countLit`, " identifiers: ", `namesLit`
  
  # Output ident callbacks
  for cb in identCallbacks:
    let nameLit = newLit(cb.name)
    let lineLit = newLit(cb.line)
    let levelLit = newLit(cb.level)
    outputStmts.add quote do:
      echo "[IDENT] ", `nameLit`, " at line ", `lineLit`, ", depth: ", `levelLit`
  
  outputStmts.add quote do:
    echo ""
    echo "Final tracking results:"
  
  # Output final results
  for name, info in scope:
    if name in ["debugVar", "testVar"]:
      let nameLit = newLit(name)
      let countLit = newLit(info.all.len)
      outputStmts.add quote do:
        echo `nameLit`, ": ", `countLit`, " occurrences"
      
      for usage in info.all:
        let kindStr = case usage.kind:
          of ukDef: "DEF"
          of ukUse: "USE"
          of ukShadow: "SHADOW"
        let kindLit = newLit(kindStr)
        let lineLit = newLit(usage.line)
        let depthLit = newLit(usage.scopeDepth)
        
        outputStmts.add quote do:
          echo "  ", `kindLit`, " at line ", `lineLit`, ", depth ", `depthLit`
  
  result = newStmtList()
  result.add(outputStmts)
  result.add(body)

simpleTest:
  var testVar = 1
  if true:
    var testVar = 2
    echo testVar
  echo testVar

# Specific test for procedure-related scope handling
macro procScopeTest(body: untyped): untyped =
  let scope = newScope()
  scope.walk(body)
  
  var outputStmts = newStmtList()
  outputStmts.add quote do:
    echo "=== PROCEDURE SCOPE VERIFICATION ==="
  
  # Verify specific procedure constructs
  var procAnalysis: seq[tuple[name: string, kind: string, depth: int, line: int]]
  
  for name, info in scope:
    for usage in info.all:
      let kindStr = case usage.kind:
        of ukDef: "DEF"
        of ukUse: "USE"
        of ukShadow: "SHADOW"
      procAnalysis.add((name: name, kind: kindStr, depth: usage.scopeDepth, line: usage.line))
  
  # Sort by line number for readable output
  procAnalysis.sort(proc(a, b: auto): int = cmp(a.line, b.line))
  
  for analysis in procAnalysis:
    let nameLit = newLit(analysis.name)
    let kindLit = newLit(analysis.kind)
    let depthLit = newLit(analysis.depth)
    let lineLit = newLit(analysis.line)
    
    outputStmts.add quote do:
      echo "Line ", `lineLit`, ": ", `nameLit`, " (", `kindLit`, ") at depth ", `depthLit`
  
  outputStmts.add quote do:
    echo "=== END PROCEDURE VERIFICATION ==="
    echo ""
  
  result = newStmtList()
  result.add(outputStmts)
  result.add(body)

procScopeTest:
  # Test method definition (should be depth 1)
  type TestObj = object
    field: int
  
  method testMethod(obj: TestObj, param: int): int =
    var methodLocal = obj.field + param
    return methodLocal
  
  # Test converter definition (should be depth 1)  
  converter intToString(x: int): string =
    var converterLocal = $x
    result = converterLocal
  
  # Test nested procedure scopes
  proc levelOne(): int =
    var l1var = 1
    
    proc levelTwo(): int =
      var l2var = 2
      
      proc levelThree(): int =
        var l3var = 3
        return l1var + l2var + l3var  # Access all levels
      
      return levelThree() + l2var
    
    return levelTwo() + l1var
  
  # Test parameter shadowing
  proc shadowTest(x: int): int =
    var x = x + 1  # Shadow parameter
    
    if true:
      var x = x * 2  # Double shadow
      result = x
  
  let testResult = levelOne()

# Final verification - run all the existing tests again to ensure nothing broke
echo "\n" & "FINAL VERIFICATION - Re-running original tests:" & "\n"

# Comprehensive scope test covering all constructs
macro comprehensiveTest(body: untyped): untyped =
  let scope = newScope()
  scope.walk(body)
  
  var outputStmts = newStmtList()
  outputStmts.add quote do:
    echo "=== COMPREHENSIVE SCOPE TEST ==="
    echo "Testing all scope-introducing constructs:"
  
  # Analyze scope depths and constructs
  var scopeDepths = initTable[int, seq[string]]()
  for name, info in scope:
    for usage in info.all:
      if usage.scopeDepth notin scopeDepths:
        scopeDepths[usage.scopeDepth] = @[]
      let kindStr = case usage.kind:
        of ukDef: "DEF"
        of ukUse: "USE" 
        of ukShadow: "SHADOW"
      scopeDepths[usage.scopeDepth].add(name & ":" & kindStr)
  
  # Output by scope depth
  for depth in 0..10:
    if depth in scopeDepths:
      let depthLit = newLit(depth)
      let itemsLit = newLit(scopeDepths[depth].join(", "))
      outputStmts.add quote do:
        echo "  Depth ", `depthLit`, ": ", `itemsLit`
  
  outputStmts.add quote do:
    echo ""
    echo "Variable shadowing analysis:"
  
  # Check for shadowing
  for name, info in scope:
    if scope.isShadowed(name):
      let nameLit = newLit(name)
      let shadowCount = newLit(info.all.countIt(it.kind == ukShadow))
      outputStmts.add quote do:
        echo "  ", `nameLit`, " is shadowed ", `shadowCount`, " time(s)"
  
  outputStmts.add quote do:
    echo ""
    echo "Cross-scope variable access:"
  
  # Analyze cross-scope access
  for name, info in scope:
    var accessPattern: seq[int]
    for usage in info.all:
      if usage.kind == ukUse:
        accessPattern.add(usage.scopeDepth)
    
    if accessPattern.len > 1:
      let nameLit = newLit(name)
      let patternLit = newLit(accessPattern.join(" → "))
      outputStmts.add quote do:
        echo "  ", `nameLit`, " accessed across depths: ", `patternLit`
  
  outputStmts.add quote do:
    echo "=== END COMPREHENSIVE TEST ==="
    echo ""
  
  result = newStmtList()
  result.add(outputStmts)
  result.add(body)

comprehensiveTest:
  # Global scope (depth 0)
  var globalVar = "global"
  let globalConst = 42
  
  # Procedure definition (depth 1)
  proc outerProc(procParam1: int, procParam2: string): string =
    var procLocal = "proc_local"
    let procConst = procParam1 * 2
    
    # Nested procedure (depth 2)
    proc innerProc(innerParam: int): int =
      var innerLocal = innerParam + procConst  # Cross-scope access
      
      # Block inside procedure (depth 3)
      block blockLabel:
        var blockVar = innerLocal + globalConst  # Multiple cross-scope
        if blockVar > 10:
          break blockLabel
        echo blockVar
      
      return innerLocal
    
    # Template definition (depth 2)
    template procTemplate(x: untyped): untyped =
      var templateVar = x
      echo templateVar
    
    # Macro definition (depth 2) 
    macro procMacro(arg: typed): untyped =
      var macroVar = "macro_local"
      result = arg
    
    # For loop (depth 2)
    for loopVar in 0..2:
      var forLocal = loopVar * procConst
      procTemplate(forLocal)
    
    # While loop (depth 2)
    var whileCounter = 0
    while whileCounter < 3:
      var whileLocal = whileCounter + 1
      echo whileLocal
      inc whileCounter
    
    # Try-except-finally (depth 2, 3, 3)
    try:
      var tryLocal = "try_block"
      raise newException(ValueError, tryLocal)
    except ValueError as e:
      var exceptLocal = e.msg
      echo exceptLocal
    finally:
      var finallyLocal = "cleanup"
      echo finallyLocal
    
    # Case statement (depth 2, 3)
    let caseValue = 1
    case caseValue:
    of 1:
      var case1Local = "case_one"
      echo case1Local
    of 2:
      var case2Local = "case_two" 
      echo case2Local
    else:
      var caseElseLocal = "case_else"
      echo caseElseLocal
    
    return procLocal & globalVar  # Cross-scope access
  
  # Function definition (depth 1)
  proc mathFunc(a: int, b: int): int =
    let funcLocal = a + b + globalConst  # Cross-scope access
    result = funcLocal
  
  # Top-level block (depth 1)
  block topBlock:
    var globalVar = "shadowed_global"  # Shadow global
    
    # Nested block (depth 2)
    block nestedBlock:
      var globalVar = "double_shadow"  # Double shadow
      echo globalVar  # Uses innermost
    
    echo globalVar  # Uses first shadow
  
  # Iterator definition (depth 1) 
  iterator countDown(n: int): int =
    var iterVar = n
    while iterVar >= 0:
      var yieldLocal = iterVar
      yield yieldLocal
      dec iterVar
  
  # Use the defined constructs
  let result1 = outerProc(5, "test")
  let result2 = mathFunc(10, 20)
  
  for val in countDown(3):
    echo val

echo "\n" & "=".repeat(50) & "\n"

# Debug macro to understand AST structure  
macro debugAST(body: untyped): untyped =
  proc printAST(n: NimNode, indent: int = 0) =
    let spaces = "  ".repeat(indent)
    echo spaces, n.kind, " (line ", n.lineInfoObj.line, ")"
    if n.kind == nnkIdent:
      echo spaces, "  -> ", n.strVal
    for child in n:
      printAST(child, indent + 1)
  
  echo "=== AST Structure ==="
  printAST(body)
  echo "=== End AST ==="
  
  result = body

# Test with simple case first
debugAST:
  var debugVar = 1
  if true:
    var debugVar = 2

echo "\n" & "=".repeat(50) & "\n"

# Example usage demonstrating scope tracking
analyzeScope:
  var genericName = "Hello, world!"
  let constantValue = 42
  
  if true:
    var genericName = "A duplicate!"  # This shadows the outer genericName
    echo genericName                  # Uses the inner genericName
    echo constantValue                # Uses the outer constantValue
  
  echo genericName                    # Uses the outer genericName again
  
  for i in 0..2:
    let loopVar = i * 2
    echo loopVar
  
  proc testProc(param: int) =
    var localVar = param + 1
    echo localVar

echo "\n" & "=".repeat(50) & "\n"

# Inspect a specific variable
inspectVariable("varName"):
  var varName = "test"
  if true:
    echo varName
    var varName = "shadow"
    echo varName
  echo varName

echo "\n" & "=".repeat(50) & "\n"

# Show scope changes in real-time
showCurrentScope:
  var scopeVar = 1
  
  block:
    var blockVar = 2
    
    if scopeVar > 0:
      var ifVar = 3
      echo scopeVar, blockVar, ifVar

# Example showing procedure scope tracking
analyzeScope:
  proc outerProc(a: int): int =
    var localA = a * 2
    
    proc innerProc(b: int): int =
      var localB = b + localA  # Uses localA from outer scope
      return localB
    
    let result = innerProc(localA)
    return result
  
  let value = outerProc(5)
  echo value