import tables, macros, sequtils

# Types
type
  UsageKind* = enum
    ukDef, ukUse, ukShadow

  UsageInfo* = object
    node*: NimNode
    kind*: UsageKind
    scopeDepth*: int
    line*: int
    col*: int

  IdentInfo* = object
    name*: string
    all*: seq[UsageInfo]
    def*: UsageInfo

  WalkCallback* = proc(n: NimNode, st: ScopeTracker)

  ScopeTracker* = ref object
    scopes: seq[Table[string, IdentInfo]]
    identMap: Table[int, IdentInfo]
    allIdentifiers: Table[string, IdentInfo]  # Persistent storage

# Helper procedures
proc getLineInfo(node: NimNode): tuple[line: int, col: int] =
  let info = node.lineInfoObj
  result = (line: info.line, col: info.column)

proc createUsageInfo(node: NimNode, kind: UsageKind, scopeDepth: int): UsageInfo =
  let (line, col) = getLineInfo(node)
  UsageInfo(
    node: node,
    kind: kind,
    scopeDepth: scopeDepth,
    line: line,
    col: col
  )

proc addIdent(st: ScopeTracker, name: string, usage: UsageInfo) =
  let currentLevel = st.scopes.len - 1
  
  if usage.kind == ukDef:
    # Check if this name exists in any outer scope (for shadowing detection)
    var existsInOuter = false
    for i in 0..<currentLevel:
      if name in st.scopes[i]:
        existsInOuter = true
        break
    
    # Determine if this is a shadow definition
    let actualKind = if existsInOuter: ukShadow else: ukDef
    let actualUsage = UsageInfo(
      node: usage.node,
      kind: actualKind,
      scopeDepth: usage.scopeDepth,
      line: usage.line,
      col: usage.col
    )
    
    # Add to current scope
    if name in st.scopes[currentLevel]:
      # Update existing entry in current scope
      var info = st.scopes[currentLevel][name]
      info.all.add(actualUsage)
      info.def = actualUsage
      st.scopes[currentLevel][name] = info
    else:
      # New entry in current scope
      var info = IdentInfo(
        name: name,
        all: @[actualUsage],
        def: actualUsage
      )
      st.scopes[currentLevel][name] = info
    
    # Update identMap
    if usage.node.kind == nnkIdent:
      st.identMap[cast[int](usage.node)] = st.scopes[currentLevel][name]
    
    # PERSIST TO GLOBAL STORAGE
    if name in st.allIdentifiers:
      var globalInfo = st.allIdentifiers[name]
      globalInfo.all.add(actualUsage)
      # Update def if this is more recent or higher priority
      if actualUsage.kind == ukDef or globalInfo.def.node == nil:
        globalInfo.def = actualUsage
      st.allIdentifiers[name] = globalInfo
    else:
      st.allIdentifiers[name] = IdentInfo(
        name: name,
        all: @[actualUsage],
        def: actualUsage
      )
  
  else:
    # This is a usage - find the identifier and add usage
    var foundScope = -1
    for i in countdown(currentLevel, 0):
      if name in st.scopes[i]:
        foundScope = i
        break
    
    if foundScope >= 0:
      # Found in existing scope
      var info = st.scopes[foundScope][name] 
      info.all.add(usage)
      st.scopes[foundScope][name] = info
      
      # Update identMap
      if usage.node.kind == nnkIdent:
        st.identMap[cast[int](usage.node)] = st.scopes[foundScope][name]
    else:
      # External/undeclared identifier - add to current scope for tracking
      var info = IdentInfo(
        name: name,
        all: @[usage],
        def: UsageInfo()
      )
      st.scopes[currentLevel][name] = info
      
      # Update identMap
      if usage.node.kind == nnkIdent:
        st.identMap[cast[int](usage.node)] = info
    
    # PERSIST TO GLOBAL STORAGE
    if name in st.allIdentifiers:
      var globalInfo = st.allIdentifiers[name]
      globalInfo.all.add(usage)
      st.allIdentifiers[name] = globalInfo
    else:
      st.allIdentifiers[name] = IdentInfo(
        name: name,
        all: @[usage],
        def: UsageInfo()
      )

proc findIdent(st: ScopeTracker, name: string): IdentInfo =
  # Search from innermost to outermost scope
  for i in countdown(st.scopes.len - 1, 0):
    if name in st.scopes[i]:
      return st.scopes[i][name]
  
  # Not found - create empty info
  result = IdentInfo(name: name, all: @[], def: UsageInfo())

proc introducesScope(node: NimNode): bool =
  case node.kind:
  of nnkProcDef, nnkFuncDef, nnkTemplateDef, nnkMacroDef, nnkMethodDef,
     nnkConverterDef, nnkIteratorDef, nnkBlockStmt, nnkForStmt, 
     nnkWhileStmt, nnkIfStmt, nnkElifBranch, nnkElse, nnkCaseStmt,
     nnkOfBranch, nnkExceptBranch, nnkFinally, nnkTryStmt:
    true
  else:
    false

proc isIdentDefiner(node: NimNode): bool =
  case node.kind:
  of nnkVarSection, nnkLetSection, nnkConstSection, nnkForStmt:
    true
  else:
    false

proc isInDefiningContext(node: NimNode, parent: NimNode): bool =
  # Check if this identifier is part of a definition
  if parent.isNil:
    return false
  
  case parent.kind:
  of nnkIdentDefs:
    # In IdentDefs, only the first child(ren) are definitions
    let defCount = parent.len - 2  # Subtract type and value slots
    for i in 0..<defCount:
      if parent[i] == node:
        return true
    return false
  of nnkVarSection, nnkLetSection, nnkConstSection:
    return true
  of nnkForStmt:
    # In for loops, early children are loop variables
    let varCount = parent.len - 2  # Subtract iterable and body
    for i in 0..<varCount:
      if parent[i] == node:
        return true
    return false
  else:
    return false

proc extractIdentDefs(node: NimNode): seq[NimNode] =
  case node.kind:
  of nnkVarSection, nnkLetSection, nnkConstSection:
    for child in node:
      if child.kind == nnkIdentDefs:
        for i in 0..<child.len-2:  # Skip type and value
          if child[i].kind == nnkIdent:
            result.add(child[i])
  of nnkIdentDefs:
    for i in 0..<node.len-2:
      if node[i].kind == nnkIdent:
        result.add(node[i])
  of nnkForStmt:
    for i in 0..<node.len-2:  # Skip iterable and body
      if node[i].kind == nnkIdent:
        result.add(node[i])
  else:
    discard

proc extractProcParams(node: NimNode): seq[NimNode] =
  if node.kind in {nnkProcDef, nnkFuncDef, nnkTemplateDef, nnkMacroDef, 
                   nnkMethodDef, nnkConverterDef, nnkIteratorDef}:
    let formalParams = node[3]  # FormalParams node
    if formalParams.kind == nnkFormalParams:
      for i in 1..<formalParams.len:  # Skip return type
        let identDefs = formalParams[i]
        if identDefs.kind == nnkIdentDefs:
          for j in 0..<identDefs.len-2:  # Skip type and default
            if identDefs[j].kind == nnkIdent:
              result.add(identDefs[j])

proc walkNode(st: ScopeTracker, node: NimNode, cb: WalkCallback = nil, parent: NimNode = nil) =
  if node.isNil:
    return
    
  # Call callback if provided
  if cb != nil:
    cb(node, st)
  
  # Handle scope introduction
  let needsNewScope = introducesScope(node)
  if needsNewScope:
    st.scopes.add(initTable[string, IdentInfo]())
  
  # Handle procedure parameters first (before processing body)
  if node.kind in {nnkProcDef, nnkFuncDef, nnkTemplateDef, nnkMacroDef, 
                   nnkMethodDef, nnkConverterDef, nnkIteratorDef}:
    let procParams = extractProcParams(node)
    for param in procParams:
      let usage = createUsageInfo(param, ukDef, st.scopes.len - 1)
      st.addIdent(param.strVal, usage)
  
  # Handle identifier definitions - ONLY process VarSection/LetSection/ConstSection
  if node.kind in {nnkVarSection, nnkLetSection, nnkConstSection}:
    let identDefs = extractIdentDefs(node)
    for ident in identDefs:
      let usage = createUsageInfo(ident, ukDef, st.scopes.len - 1)
      st.addIdent(ident.strVal, usage)
  
  # Handle for loop variables separately
  elif node.kind == nnkForStmt:
    let identDefs = extractIdentDefs(node)
    for ident in identDefs:
      let usage = createUsageInfo(ident, ukDef, st.scopes.len - 1)
      st.addIdent(ident.strVal, usage)
  
  # Handle identifier usage - only if not in a defining context
  elif node.kind == nnkIdent and not isInDefiningContext(node, parent):
    let name = node.strVal
    let usage = createUsageInfo(node, ukUse, st.scopes.len - 1)
    st.addIdent(name, usage)
  
  # Recursively walk children, passing current node as parent
  for child in node:
    st.walkNode(child, cb, node)
  
  # Exit scope if we entered one
  if needsNewScope:
    discard st.scopes.pop()

# API Implementation
proc newScope*(): ScopeTracker =
  ScopeTracker(
    scopes: @[initTable[string, IdentInfo]()],
    identMap: initTable[int, IdentInfo](),
    allIdentifiers: initTable[string, IdentInfo]()
  )

proc walk*(st: ScopeTracker, root: NimNode) =
  st.walkNode(root)

proc walk*(st: ScopeTracker, root: NimNode, cb: WalkCallback) =
  st.walkNode(root, cb)

proc info*(st: ScopeTracker, name: string): IdentInfo =
  if name in st.allIdentifiers:
    result = st.allIdentifiers[name]
  else:
    result = IdentInfo(name: "", all: @[], def: UsageInfo())

proc info*(st: ScopeTracker, ident: NimNode): IdentInfo =
  let key = cast[int](ident)
  if key in st.identMap:
    result = st.identMap[key]
  else:
    result = IdentInfo(name: "", all: @[], def: UsageInfo())

proc allTracked*(st: ScopeTracker): seq[IdentInfo] =
  # Simply return the persistent storage
  for name, info in st.allIdentifiers:
    result.add(info)

proc currentScopeSymbols*(st: ScopeTracker): seq[string] =
  if st.scopes.len > 0:
    for name in st.scopes[^1].keys:
      result.add(name)

proc currentScopeLevel*(st: ScopeTracker): int =
  st.scopes.len - 1

# Additional utility procedures
proc reset*(st: ScopeTracker) =
  st.scopes = @[initTable[string, IdentInfo]()]
  st.identMap = initTable[int, IdentInfo]()
  st.allIdentifiers = initTable[string, IdentInfo]()

proc scopeDepth*(st: ScopeTracker): int =
  st.currentScopeLevel()

proc inCurrentScope*(st: ScopeTracker, name: string): bool =
  if st.scopes.len > 0:
    name in st.scopes[^1]
  else:
    false

proc scopeOf*(st: ScopeTracker, name: string): int =
  if name in st.allIdentifiers:
    let info = st.allIdentifiers[name]
    if info.def.node != nil:
      return info.def.scopeDepth
  return -1

proc isDefined*(st: ScopeTracker, name: string): bool =
  name in st.allIdentifiers and st.allIdentifiers[name].def.node != nil

proc isShadowed*(st: ScopeTracker, name: string): bool =
  if name in st.allIdentifiers:
    let info = st.allIdentifiers[name]
    info.all.anyIt(it.kind == ukShadow)
  else:
    false

proc usagesOf*(st: ScopeTracker, name: string): seq[UsageInfo] =
  if name in st.allIdentifiers:
    let info = st.allIdentifiers[name]
    info.all.filterIt(it.kind == ukUse)
  else:
    @[]

proc shadowedIdents*(st: ScopeTracker): seq[IdentInfo] =
  result = @[]
  for name, info in st.allIdentifiers:
    if info.all.anyIt(it.kind == ukShadow):
      result.add(info)

# Iterators
iterator items*(st: ScopeTracker): IdentInfo =
  for name, info in st.allIdentifiers:
    yield info

iterator pairs*(st: ScopeTracker): (string, IdentInfo) =
  for name, info in st.allIdentifiers:
    yield (name, info)

iterator itemsInScope*(st: ScopeTracker, level: int): IdentInfo =
  for name, info in st.allIdentifiers:
    # Check if this identifier has any usage at the specified level
    if info.all.anyIt(it.scopeDepth == level):
      yield info