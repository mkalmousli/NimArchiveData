# Aegis Code of Conduct

1. **Practice Empathy and Respect.** Treat all contributors with basic
   decency and respect. Every individual brings with them personal
   experiences and challenges that may not be immediately
   visible. Regardless of your current circumstances, please engage
   with others in a way that you would consider fair and considerate
   under reversed roles.

2. **Engage Constructively and Charitably.** Avoid making premature
   and/or harsh judgments. If someone proposes an idea they find
   intuitive but appears underdeveloped or difficult to justify, aim
   to understand the underlying intent, refine their proposal and
   strengthen their reasonings with the same level of care you would
   wish for your own ideas. Conversely, if your own proposal is
   rejected, engage with the feedback thoughtfully, and continue the
   dialogue in a professional and constructive manner.

3. **Adhere to Merit-Based Evaluation.** We evaluate contributions
   based solely on their technical merit and relevance to the
   project. Personal identity, affiliations, or background are not
   factored into this evaluation, and should not be emphasized. Please
   refrain from emphasizing such details within project
   discussions. If, after reading this, you still choose to foreground
   such information, you accept sole responsibility for any resulting
   consequences or interpretations.

4. **Maintain Technological Focus and Ideological Neutrality.** This
   project is committed to technological excellence and neutrality. We
   do not take positions on political, ideological, or social issues
   in the name of the development team. Accordingly, please refrain
   from making such statements under the project's banner, even if
   they reflect personal beliefs or convictions; such declarations are
   not appropriate within the context of the project and should be
   kept separate from technical discourse.
	
