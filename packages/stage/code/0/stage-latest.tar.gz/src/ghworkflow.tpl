name: Test

on:
  push:
    paths-ignore:
      - README.md
  pull_request:
    paths-ignore:
      - README.md
  workflow_dispatch:

jobs:
  test:
    runs-on: ${{ matrix.os }}
    continue-on-error: ${{ matrix.experimental }}
    strategy:
      fail-fast: false
      matrix:
        os:
          - ubuntu-latest
        experimental: [false]
        nim-version:
          - stable
        include:
          - os: windows-latest
            experimental: true
            nim-version: stable
    steps:
    - name: Checkout
      uses: actions/checkout@v4

    - name: Cache choosenim
      id: cache-choosenim
      uses: actions/cache@v4
      with:
        path: ~/.choosenim
        key: ${{ runner.os }}-choosenim-${{ matrix.nim-version}}

    - name: Cache nimble
      id: cache-nimble
      uses: actions/cache@v4
      with:
        path: ~/.nimble
        key: ${{ runner.os }}-nimble-${{ matrix.nim-version}}-${{ hashFiles('*.nimble') }}

    - name: Setup nim
      uses: jiro4989/setup-nim-action@v2
      with:
        nim-version: ${{ matrix.nim-version }}

    - name: Install Packages
      run: nimble install -d -y
    - name: Test
      run: nimble --silent test
