====
Home
====

.. toctree::
   :caption: Contents
   :hidden:
   :maxdepth: 2

   usage/index
   changelog

Age is faster bump-version implementation written by Rust-lang.

Concept
=======

This is high-performance bumpversion tool.

Motivation
==========

There are some reason that I develop it.

* Bump version tool independent by programming language.
* Management real product for myself to learn Rust.
