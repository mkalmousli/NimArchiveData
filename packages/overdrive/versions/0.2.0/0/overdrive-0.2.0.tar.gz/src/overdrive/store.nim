## Store ops for overdrive
##
## Copyright (C) 2025-2026 Trayambak Rai (xtrayambak at disroot dot org)
import pkg/overdrive/[types, flags]
import pkg/shakar

{.push checks: off.}
when hasAvx2:
  template storeContainerAvx2Impl[U: Vectorizable](
      vec: var Vector[U], src: openArray[U]
  ): int =
    vec.reg = mm256_loadu_si256(cast[ptr M256i](src[0].addr))

    if src.len > vec.capacity:
      src.len - vec.capacity
    else:
      0

  template storePtrAvx2Impl[U: Vectorizable](vec: var Vector[U], src: ptr U) =
    vec.reg = mm256_loadu_si256(cast[ptr M256i](src))

  template storeOneAvx2Impl[U: Vectorizable](vec: var Vector[U], src: U) =
    when U is uint8 or U is int8 or U is char:
      # 32x u8
      vec.reg = mm256_set1_epi8(cast[uint8](src))
    elif U is uint16 or U is int16:
      # 16x u16
      vec.reg = mm256_set1_epi16(src)
    elif U is uint32 or U is int32:
      # 8x u32
      vec.reg = mm256_set1_epi32(src)
    elif U is uint64 or U is int64:
      # 4x u16
      vec.reg = mm256_set1_epi64x(src)
    else:
      {.error: "Unsupported type for storage in AVX2 register: " & $U.}

template storeContainerScalarImpl[U: Vectorizable](
    vec: var Vector[U], src: openArray[U]
): int =
  # Quickly copy the buffer of vectorizable units
  # into our software/scalar pseudo-register

  if src.len <= ScalarSWRegisterSize:
    copyMem(vec.reg[0].addr, src[0].addr, ScalarSWRegisterSize - src.len)
    0
  else:
    copyMem(vec.reg[0].addr, src[0].addr, ScalarSWRegisterSize)
    src.len - ScalarSWRegisterSize

template storeOneScalarImpl[U: Vectorizable](vec: var Vector[U], src: U) =
  var i = 0
  while i < ScalarSWRegisterSize:
    vec.reg[i] = src
    inc i

template storePtrScalarImpl[U: Vectorizable](vec: var Vector[U], src: ptr U) =
  for i in 0 ..< 32:
    vec.reg[i] = cast[U](src[])

when hasSse2:
  template storePtrSseImpl[U: Vectorizable](vec: var Vector[U], src: ptr U) =
    vec.reg = mm_loadu_si128(cast[ptr M128i](src))

  template storeContainerSseImpl[U: Vectorizable](
      vec: var Vector[U], src: openArray[U]
  ) =
    vec.reg = mm_loadu_si128(cast[ptr M128i](src[0].addr))

    if src.len > vec.capacity:
      return src.len - vec.capacity
    else:
      return 0

  template storeOneSseImpl[U: Vectorizable](vec: var Vector[U], src: U) =
    when U is uint8 or U is int8 or U is char:
      vec.reg = mm_set1_epi8(src)
    elif U is uint16 or U is int16:
      vec.reg = mm_set1_epi16(src)
    elif U is uint32 or U is int32:
      vec.reg = mm_set1_epi32(src)
    elif U is uint64 or U is int64:
      vec.reg = mm_set1_epi64x(src)
    else:
      {.error: "Unsupported type for storage in SSE register: " & $U.}

when hasNeon:
  template storeOneNeonImpl[U: Vectorizable](vec: var Vector[U], src: U) =
    when U is uint8 or U is int8 or U is char:
      vec.reg = vmovq_n_u8(cast[uint8](src))
    elif U is uint16 or U is int16:
      vec.reg = vmovq_n_u16(cast[uint16](src))
    elif U is uint32 or U is int32:
      vec.reg = vmovq_n_u32(cast[uint32](src))
    elif U is uint64 or U is int64:
      vec.reg = vmovq_n_u64(cast[uint64](src))
    else:
      {.error: "Unsupported type for storage in NEON register: " & $U.}

  template storeContainerNeonImpl[U: Vectorizable](
      vec: var Vector[U], src: openArray[U]
  ) =
    when U is uint8 or U is int8 or U is char:
      vec.reg = cast[RegisterImpl[U]](vld1q_u8(src[0].addr))
    elif U is uint16 or U is int16:
      vec.reg = cast[RegisterImpl[U]](vld1q_u16(src[0].addr))
    elif U is uint32 or U is int32:
      vec.reg = cast[RegisterImpl[U]](vld1q_u32(src[0].addr))
    elif U is uint64 or U is int64:
      vec.reg = cast[RegisterImpl[U]](vld1q_u64(src[0].addr))
    else:
      {.error: "Unsupported type for storage in NEON register: " & $U.}

  template storePtrNeonImpl[U: Vectorizable](vec: var Vector[U], src: ptr U) =
    when U is uint8 or U is int8 or U is char:
      vec.reg = cast[RegisterImpl[U]](vld1q_u8(src))
    elif U is uint16 or U is int16:
      vec.reg = cast[RegisterImpl[U]](vld1q_u16(src))
    elif U is uint32 or U is int32:
      vec.reg = cast[RegisterImpl[U]](vld1q_u32(src))
    elif U is uint64 or U is int64:
      vec.reg = cast[RegisterImpl[U]](vld1q_u16(src))
    else:
      {.error: "Unsupported type for storage in NEON register: " & $U.}

func store*[U: Vectorizable](
    vec: var Vector[U], src: openArray[U]
): int {.discardable.} =
  when hasAvx2:
    storeContainerAvx2Impl(vec, src)
  elif hasSse2:
    storeContainerSseImpl(vec, src)
  elif hasNeon:
    storeContainerNeonImpl(vec, src)
  else:
    storeContainerScalarImpl(vec, src)

func store*[U: Vectorizable](vec: var Vector[U], src: ptr U) {.discardable.} =
  when hasAvx2:
    storePtrAvx2Impl(vec, src)
  elif hasSse2:
    storePtrSseImpl(vec, src)
  elif hasNeon:
    storePtrNeonImpl(vec, src)
  else:
    storePtrScalarImpl(vec, src)

func store*[U: Vectorizable](vec: var Vector[U], src: U) =
  when hasAvx2:
    storeOneAvx2Impl(vec, src)
  elif hasSse2:
    storeOneSseImpl(vec, src)
  elif hasNeon:
    storeOneNeonImpl(vec, src)
  else:
    storeOneScalarImpl(vec, src)

{.pop.}
