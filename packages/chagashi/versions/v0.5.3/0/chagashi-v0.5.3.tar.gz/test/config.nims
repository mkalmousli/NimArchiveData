switch("path", "$projectDir/../src")
