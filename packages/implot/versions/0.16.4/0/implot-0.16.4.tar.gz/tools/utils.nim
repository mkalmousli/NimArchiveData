# Written by Leonardo Mariscal <leo@ldmd.mx>, 2019

const srcHeader* = """
# Written by Leonardo Mariscal <leo@ldmd.mx>, 2019

## ImGUI Bindings
## ====
## WARNING: This is a generated file. Do not edit
## Any edits will be overwritten by the generator.
##
## The aim is to achieve as much compatibility with C as possible.
## Optional helper functions have been created as a submodule
## ``imgui/imgui_helpers`` to better bind this library to Nim.
##
## You can check the original documentation `here <https://github.com/ocornut/imgui/blob/master/imgui.cpp>`_.
##
## Source language of ImGui is C++, since Nim is able to compile both to C
## and C++ you can select which compile target you wish to use. Note that to use
## the C backend you must supply a `cimgui <https://github.com/cimgui/cimgui>`_
## dynamic library file.
##
## HACK: If you are targeting Windows, be sure to compile the cimgui dll with
## visual studio and not with mingw.

import strutils
import imgui

## Tentative workaround [start]
type
  Imguidockrequest* = distinct object
  ImGuiDockNodeSettings* = distinct object
  const_cstringPtr* {.pure, inheritable, bycopy.} = object
    Size*: cint
    Capacity*: cint
    Data*: ptr ptr cschar
  tm {.pure, inheritable, bycopy.} = object
    tmsec*: cint
    tmmin*: cint
    tmhour*: cint
    tmmday*: cint
    tmmon*: cint
    tmyear*: cint
    tmwday*: cint
    tmyday*: cint
    tmisdst*: cint
  cfloat64* = cdouble
  double* = cdouble
  Ims32* = cint
const
  nullptr* = nil
  IMPLOT_AUTO* = -1 # from <implot.h>

#--------------------------------
# Enum: logical calculation definitions
#--------------------------------
# Assumed enum size is 32bit.
# or
template `or`*[E:enum](a,b:E):E =
  cast[E](a.uint32 or b.uint32)
template `or`*[E:enum,I:SomeInteger](a:E,b:I):E =
  cast[E](a.uint32 or b.uint32)
template `or`*[E:enum,I:SomeInteger](a:I,b:E):E =
  cast[E](a.uint32 or b.uint32 )

# xor
template `xor`*[E:enum](a,b:E):E =
  cast[E](a.uint32 xor b.uint32)
template `xor`*[E:enum,I:SomeInteger](a:E,b:I):E =
  cast[E](a.uint32 xor b)
template `xor`*[E:enum,I:SomeInteger](a:I,b:E):E =
  cast[E](a.uint32 xor b.uint32 )

# and
template `and`*[E:enum](a,b:E):E =
  cast[E](a.uint32 and b.uint32)
template `and`*[E:enum,I:SomeInteger](a:E,b:I):E =
  cast[E](a.uint32 and b.uint32 )
template `and`*[E:enum,I:SomeInteger](a:I,b:E):E =
  cast[E](cast[uint32](a) and cast[uint32](b) )

## Tentative workaround [end]

proc currentSourceDir(): string {.compileTime.} =
  result = currentSourcePath().replace("\\", "/")
  result = result[0 ..< result.rfind("/")]

{.passC:"-DImDrawIdx=\"unsigned int\"".}

{.compile: "implot/private/cimplot/cimplot.cpp",
  compile: "implot/private/cimplot/implot/implot.cpp",
  compile: "implot/private/cimplot/implot/implot_demo.cpp",
  compile: "implot/private/cimplot/implot/implot_items.cpp".}
{.passC:"-I" & currentSourceDir() & "/implot/private/cimplot".}
{.passC:"-I" & currentSourceDir() & "/implot/private/cimplot/implot".}
{.pragma: implot_header, header: currentSourceDir() & "/implot/private/ncimplot.h".}

when defined(windows):
  {.passC:"-static".}
  {.passL:"-static".}

"""
const notDefinedStructs* = """
  ImVector*[T] = object # Should I importc a generic?
    size* {.importc: "Size".}: int32
    capacity* {.importc: "Capacity".}: int32
    data* {.importc: "Data".}: ptr UncheckedArray[T]
  ImGuiStyleModBackup* {.union.} = object
    backup_int* {.importc: "BackupInt".}: int32 # Breaking naming convetion to denote "low level"
    backup_float* {.importc: "BackupFloat".}: float32
  #ImGuiStyleMod* {.importc: "ImGuiStyleMod", implot_header.} = object
    varIdx* {.importc: "VarIdx".}: ImGuiStyleVar
    backup*: ImGuiStyleModBackup
  ImGuiStoragePairData* {.union.} = object
    val_i* {.importc: "val_i".}: int32 # Breaking naming convetion to denote "low level"
    val_f* {.importc: "val_f".}: float32
    val_p* {.importc: "val_p".}: pointer
  #ImGuiStoragePair* {.importc: "ImGuiStoragePair", implot_header.} = object
    key* {.importc: "key".}: ImGuiID
    data*: ImGuiStoragePairData
  ImPairData* {.union.} = object
    val_i* {.importc: "val_i".}: int32 # Breaking naming convetion to denote "low level"
    val_f* {.importc: "val_f".}: float32
    val_p* {.importc: "val_p".}: pointer
  #ImPair* {.importc: "Pair", implot_header.} = object
    key* {.importc: "key".}: ImGuiID
    data*: ImPairData
  ImGuiInputEventData* {.union.} = object
    mousePos*: ImGuiInputEventMousePos
    mouseWheel*: ImGuiInputEventMouseWheel
    mouseButton*: ImGuiInputEventMouseButton
    key*: ImGuiInputEventKey
    text*: ImGuiInputEventText
    appFocused*: ImGuiInputEventAppFocused
  #ImGuiInputEvent* {.importc: "ImGuiInputEvent", implot_header.} = object
    `type`* {.importc: "`type`".}: ImGuiInputEventType
    source* {.importc: "Source".}: ImGuiInputSource
    data*: ImGuiInputEventData
    addedByTestEngine* {.importc: "AddedByTestEngine".}: bool

  # Undefined data types in cimgui

  ImDrawListPtr* = object
  ImChunkStream* = ptr object
  ImPool* = object
  ImSpanAllocator* = object # A little lost here. It is referenced in imgui_internal.h
  ImSpan* = object # ^^
  ImVectorImGuiColumns* {.importc: "ImVector_ImGuiColumns".} = object

  #
"""

const preProcs* = """
# Procs
{.push warning[HoleEnumConv]: off.}
when not defined(cpp) or defined(cimguiDLL):
  {.push dynlib: imgui_dll, cdecl, discardabl, header: currentSourceDir() & "/implot/private/ncimplot.h"e.}
else:
  {.push nodecl, discardable, header: currentSourceDir() & "/implot/private/ncimplot.h".}
"""

const postProcs* = """
{.pop.} # push dynlib / nodecl, etc...
{.pop.} # push warning[HoleEnumConv]: off
"""

let reservedWordsDictionary* = [
"end", "type", "out", "in", "ptr", "ref"
]

let blackListProc* = [ "" ]

const cherryTheme* = """
proc igStyleColorsCherry*(dst: ptr ImGuiStyle = nil): void =
  ## To conmemorate this bindings this style is included as a default.
  ## Style created originally by r-lyeh
  var style = igGetStyle()
  if dst != nil:
    style = dst

  const ImVec4 = proc(x: float32, y: float32, z: float32, w: float32): ImVec4 = ImVec4(x: x, y: y, z: z, w: w)
  const igHI = proc(v: float32): ImVec4 = ImVec4(0.502f, 0.075f, 0.256f, v)
  const igMED = proc(v: float32): ImVec4 = ImVec4(0.455f, 0.198f, 0.301f, v)
  const igLOW = proc(v: float32): ImVec4 = ImVec4(0.232f, 0.201f, 0.271f, v)
  const igBG = proc(v: float32): ImVec4 = ImVec4(0.200f, 0.220f, 0.270f, v)
  const igTEXT = proc(v: float32): ImVec4 = ImVec4(0.860f, 0.930f, 0.890f, v)

  style.colors[ImGuiCol.Text.int32]                 = igTEXT(0.88f)
  style.colors[ImGuiCol.TextDisabled.int32]         = igTEXT(0.28f)
  style.colors[ImGuiCol.WindowBg.int32]             = ImVec4(0.13f, 0.14f, 0.17f, 1.00f)
  style.colors[ImGuiCol.PopupBg.int32]              = igBG(0.9f)
  style.colors[ImGuiCol.Border.int32]               = ImVec4(0.31f, 0.31f, 1.00f, 0.00f)
  style.colors[ImGuiCol.BorderShadow.int32]         = ImVec4(0.00f, 0.00f, 0.00f, 0.00f)
  style.colors[ImGuiCol.FrameBg.int32]              = igBG(1.00f)
  style.colors[ImGuiCol.FrameBgHovered.int32]       = igMED(0.78f)
  style.colors[ImGuiCol.FrameBgActive.int32]        = igMED(1.00f)
  style.colors[ImGuiCol.TitleBg.int32]              = igLOW(1.00f)
  style.colors[ImGuiCol.TitleBgActive.int32]        = igHI(1.00f)
  style.colors[ImGuiCol.TitleBgCollapsed.int32]     = igBG(0.75f)
  style.colors[ImGuiCol.MenuBarBg.int32]            = igBG(0.47f)
  style.colors[ImGuiCol.ScrollbarBg.int32]          = igBG(1.00f)
  style.colors[ImGuiCol.ScrollbarGrab.int32]        = ImVec4(0.09f, 0.15f, 0.16f, 1.00f)
  style.colors[ImGuiCol.ScrollbarGrabHovered.int32] = igMED(0.78f)
  style.colors[ImGuiCol.ScrollbarGrabActive.int32]  = igMED(1.00f)
  style.colors[ImGuiCol.CheckMark.int32]            = ImVec4(0.71f, 0.22f, 0.27f, 1.00f)
  style.colors[ImGuiCol.SliderGrab.int32]           = ImVec4(0.47f, 0.77f, 0.83f, 0.14f)
  style.colors[ImGuiCol.SliderGrabActive.int32]     = ImVec4(0.71f, 0.22f, 0.27f, 1.00f)
  style.colors[ImGuiCol.Button.int32]               = ImVec4(0.47f, 0.77f, 0.83f, 0.14f)
  style.colors[ImGuiCol.ButtonHovered.int32]        = igMED(0.86f)
  style.colors[ImGuiCol.ButtonActive.int32]         = igMED(1.00f)
  style.colors[ImGuiCol.Header.int32]               = igMED(0.76f)
  style.colors[ImGuiCol.HeaderHovered.int32]        = igMED(0.86f)
  style.colors[ImGuiCol.HeaderActive.int32]         = igHI(1.00f)
  style.colors[ImGuiCol.ResizeGrip.int32]           = ImVec4(0.47f, 0.77f, 0.83f, 0.04f)
  style.colors[ImGuiCol.ResizeGripHovered.int32]    = igMED(0.78f)
  style.colors[ImGuiCol.ResizeGripActive.int32]     = igMED(1.00f)
  style.colors[ImGuiCol.PlotLines.int32]            = igTEXT(0.63f)
  style.colors[ImGuiCol.PlotLinesHovered.int32]     = igMED(1.00f)
  style.colors[ImGuiCol.PlotHistogram.int32]        = igTEXT(0.63f)
  style.colors[ImGuiCol.PlotHistogramHovered.int32] = igMED(1.00f)
  style.colors[ImGuiCol.TextSelectedBg.int32]       = igMED(0.43f)

  style.windowPadding     = ImVec2(x: 6f, y: 4f)
  style.windowRounding    = 0.0f
  style.framePadding      = ImVec2(x: 5f, y: 2f)
  style.frameRounding     = 3.0f
  style.itemSpacing       = ImVec2(x: 7f, y: 1f)
  style.itemInnerSpacing  = ImVec2(x: 1f, y: 1f)
  style.touchExtraPadding = ImVec2(x: 0f, y: 0f)
  style.indentSpacing     = 6.0f
  style.scrollbarSize     = 12.0f
  style.scrollbarRounding = 16.0f
  style.grabMinSize       = 20.0f
  style.grabRounding      = 2.0f

  style.windowTitleAlign.x = 0.50f

  style.colors[ImGuiCol.Border.int32] = ImVec4(0.539f, 0.479f, 0.255f, 0.162f)
  style.frameBorderSize  = 0.0f
  style.windowBorderSize = 1.0f

  style.displaySafeAreaPadding.y = 0
  style.framePadding.y = 1
  style.itemSpacing.y = 1
  style.windowPadding.y = 3
  style.scrollbarSize = 13
  style.frameBorderSize = 1
  style.tabBorderSize = 1
"""
