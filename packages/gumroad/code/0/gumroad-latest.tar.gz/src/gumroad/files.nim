# A Nim client for the Gumroad API - https://gumroad.com/api
#
# (c) 2026 George Lemon | MIT License
#          Made by Humans from OpenPeeps
#          https://github.com/openpeeps/gumroad-nim

import ./api

const
  GumroadMaxFileSizeBytes* = 20'i64 * 1024'i64 * 1024'i64 * 1024'i64 # 20 GB

type
  GumroadFilePresignPart* = object
    part_number*: int
    presigned_url*: string

  GumroadFileCompletePart* = object
    part_number*: int
    etag*: string

  GumroadFileAbortStatus* = enum
    abortAccepted = "accepted"
    abortAlreadyGone = "already_gone"

  GumroadFilePresignRequest = object
    filename*: string
    file_size*: int64

  GumroadFileCompleteRequest = object
    upload_id*: string
    key*: string
    parts*: seq[GumroadFileCompletePart]

  GumroadFileAbortRequest = object
    upload_id*: string
    key*: string

  GumroadApiResponseFilePresign* = object
    success*: bool
    upload_id*: string
    key*: string
    file_url*: string
    parts*: seq[GumroadFilePresignPart]

  GumroadApiResponseFileComplete* = object
    success*: bool
    file_url*: string

  GumroadApiResponseFileAbort* = object
    success*: bool
    status*: GumroadFileAbortStatus

proc shouldRetry*(res: GumroadApiResponseFileAbort): bool =
  ## True when /files/abort should be called again.
  res.status == abortAccepted

proc isGone*(res: GumroadApiResponseFileAbort): bool =
  ## True when multipart session no longer exists on S3.
  res.status == abortAlreadyGone

proc postPresignFile*(client: GumroadClient, filename: string,
            fileSize: int64): Future[GumroadApiResponseFilePresign] {.async.} =
  ## Starts a multipart upload and returns presigned URLs for each part.
  ## This endpoint requires `scopeEditProducts` OAuth scope.
  ## 
  ## The maximum file size is 20 GB. The client should split the file into parts
  ## of at least 5 MB each, then upload each part to S3 using the provided presigned URLs.
  ## 
  ## After all parts are uploaded, call `postCompleteFileUpload` to finalize the upload.
  if filename.len == 0:
    raise newException(GumroadClientError, "filename cannot be empty")
  if fileSize <= 0'i64:
    raise newException(GumroadClientError, "file_size must be greater than zero")
  if fileSize > GumroadMaxFileSizeBytes:
    raise newException(GumroadClientError, "file_size exceeds 20 GB")

  let payload = GumroadFilePresignRequest(
    filename: filename,
    file_size: fileSize
  )

  let res: AsyncResponse = await client.httpPost("files/presign", payload)
  let body = await res.body
  case res.code:
  of Http200:
    result = fromJson(body, GumroadApiResponseFilePresign)
  else:
    raise newException(GumroadClientError, body)

proc postCompleteFileUpload*(client: GumroadClient, uploadId, key: string,
            parts: seq[GumroadFileCompletePart]): Future[GumroadApiResponseFileComplete] {.async.} =
  ## Finalizes a multipart upload.
  ## Do not retry this endpoint with the same upload_id.
  if uploadId.len == 0:
    raise newException(GumroadClientError, "upload_id cannot be empty")
  if key.len == 0:
    raise newException(GumroadClientError, "key cannot be empty")
  if parts.len == 0:
    raise newException(GumroadClientError, "parts cannot be empty")

  let payload = GumroadFileCompleteRequest(
    upload_id: uploadId,
    key: key,
    parts: parts
  )

  let res: AsyncResponse = await client.httpPost("files/complete", payload)
  let body = await res.body
  case res.code:
  of Http200:
    result = fromJson(body, GumroadApiResponseFileComplete)
  else:
    raise newException(GumroadClientError, body)

proc postAbortFileUpload*(
    client: GumroadClient, uploadId, key: string
  ): Future[GumroadApiResponseFileAbort] {.async.} =
  ## Cancels a multipart upload.
  ## Call repeatedly while status is "accepted"; stop on "already_gone".
  if uploadId.len == 0:
    raise newException(GumroadClientError, "upload_id cannot be empty")
  if key.len == 0:
    raise newException(GumroadClientError, "key cannot be empty")

  let payload = GumroadFileAbortRequest(
    upload_id: uploadId,
    key: key
  )

  let res: AsyncResponse = await client.httpPost("files/abort", payload)
  let body = await res.body
  case res.code:
  of Http200:
    result = fromJson(body, GumroadApiResponseFileAbort)
  else:
    raise newException(GumroadClientError, body)