# A Nim client for the Gumroad API - https://gumroad.com/api
#
# (c) 2026 George Lemon | MIT License
#          Made by Humans from OpenPeeps
#          https://github.com/openpeeps/gumroad-nim

import std/[asyncdispatch, httpclient, times,
        options, tables, strutils, sequtils,
        uri]

import pkg/oauth2
import pkg/openparser/json

export asyncdispatch, httpclient, json, options, times, oauth2, tables

type
  GumroadScope* = enum
    scopeAccount = "account"
      ## full access to all API endpoints
    scopeViewProfile = "view_profile"
      ## read-only access to the user's profile information
    scopeEditProducts = "edit_products"
      ## read and write access to the user's products
    scopeViewSales = "view_sales"
      ## read-only access to the user's sales data
    scopeViewPayouts = "view_payouts"
      ## read-only access to the user's payout information
    scopeViewTaxData = "view_tax_data"
      ## read-only access to the user's tax data
    scopeMarkSalesAsShipped = "mark_sales_as_shipped"
      ## write access to mark the user's products' sales as shipped
    scopeEditSales = "edit_sales"
      ## write access to refund the user's products' sales and
      ## resend purchase receipts to customers

  GumroadClient* = ref object
    baseUri: string
      # The base URI for the Gumroad API
    api_key: string
      # The API key used for authentication with the Gumroad service
    client: AsyncHttpClient
      # The underlying HTTP client used for making requests to the
      # Gumroad service
    accessToken: Option[string]
      # OAuth access token
    refreshToken: Option[string]
      # OAuth refresh token
    tokenExpiry: Option[int]
      # Access token expiry time in seconds (optional)
    oauthClientId: Option[string]
      # OAuth app client_id
    oauthClientSecret: Option[string]
      # OAuth app client_secret
  
  QueryTable* = OrderedTable[string, string]
    ## A table for storing query parameters to be included in API requests.
    ## The keys and values are both strings.
  
  GumroadClientError* = object of CatchableError

const
  authorizeUrl = "https://gumroad.com/oauth/authorize"
  tokenUrl = "https://gumroad.com/oauth/token"

#
# OAuth helper functions
#
proc getAuthorizationUrl*(clientId, redirectUri: string, scopes: seq[GumroadScope], state = ""): string =
  ## Constructs the Gumroad OAuth2 authorization URL.
  let scopeStr = scopes.mapIt($it).join(" ")
  result = authorizeUrl & "?" &
    "client_id=" & clientId.encodeUrl & "&" &
    "redirect_uri=" & redirectUri.encodeUrl & "&" &
    "response_type=code&" &
    "scope=" & scopeStr.encodeUrl
  if state.len > 0:
    result.add("&state=" & state.encodeUrl)

proc exchangeCodeForToken*(
    clientId, clientSecret, code, redirectUri: string
  ): Future[JsonNode] {.async.} =
  ## Exchanges an authorization code for an access token.
  var client = newAsyncHttpClient()
  client.headers = newHttpHeaders({
    "Accept": "application/json",
    "Content-Type": "application/x-www-form-urlencoded"
  })

  let body =
    "client_id=" & clientId.encodeUrl &
    "&client_secret=" & clientSecret.encodeUrl &
    "&code=" & code.encodeUrl &
    "&grant_type=authorization_code" &
    "&redirect_uri=" & redirectUri.encodeUrl

  let resp = await client.post(tokenUrl, body)
  result = parseJson(await resp.body)

proc refreshAccessToken*(
    clientId, clientSecret, refreshToken: string
  ): Future[JsonNode] {.async.} =
  ## Refreshes the access token using a refresh token.
  var client = newAsyncHttpClient()
  client.headers = newHttpHeaders({
    "Accept": "application/json",
    "Content-Type": "application/x-www-form-urlencoded"
  })

  let body =
    "client_id=" & clientId.encodeUrl &
    "&client_secret=" & clientSecret.encodeUrl &
    "&refresh_token=" & refreshToken.encodeUrl &
    "&grant_type=refresh_token"

  let resp = await client.post(tokenUrl, body = body)
  result = parseJson(await resp.body)

#
# Gumroad API helper functions
#
proc `$`*(query: var QueryTable): string =
  ## Convert `query` QueryTable to string
  if query.len > 0:
    add result, "?"
    add result, join(query.keys.toSeq.mapIt(it & "=" & query[it]), "&")

proc configureOAuth*(client: GumroadClient, clientId, clientSecret: string) =
  ## Stores OAuth app credentials used for automatic token refresh.
  client.oauthClientId = some(clientId)
  client.oauthClientSecret = some(clientSecret)

proc setTokens*(client: GumroadClient, accessToken,
          refreshToken: string, expiresIn: Option[int] = none(int)) =
  ## Set OAuth tokens on the client.
  client.accessToken = some(accessToken)
  if refreshToken.len > 0:
    client.refreshToken = some(refreshToken)
  client.tokenExpiry = expiresIn

proc addAccessToken*(query: var QueryTable, client: GumroadClient) =
  ## Add access_token to query if present.
  if client.accessToken.isSome:
    query["access_token"] = client.accessToken.get

proc canAutoRefresh(client: GumroadClient): bool =
  client.refreshToken.isSome and client.oauthClientId.isSome and client.oauthClientSecret.isSome

proc tryAutoRefresh(client: GumroadClient): Future[bool] {.async.} =
  ## Refresh token once; returns true on success.
  if not client.canAutoRefresh:
    return false

  let refreshResp = await refreshAccessToken(
    client.oauthClientId.get,
    client.oauthClientSecret.get,
    client.refreshToken.get
  )

  if not refreshResp.hasKey("access_token"):
    return false

  let newAccessToken = refreshResp["access_token"].getStr()
  let newRefreshToken =
    if refreshResp.hasKey("refresh_token"): refreshResp["refresh_token"].getStr()
    else: client.refreshToken.get

  client.setTokens(newAccessToken, newRefreshToken)
  return true

proc httpGet*(client: GumroadClient, endpoint: string,
              query: var QueryTable): Future[AsyncResponse] {.async.} =
  ## GET with automatic token refresh on 401.
  addAccessToken(query, client)
  let url = client.baseUri & endpoint & $query
  result = await client.client.get(url)

  if result.code == Http401 and await client.tryAutoRefresh():
    var retryQ = query
    addAccessToken(retryQ, client)
    let retryUrl = client.baseUri & endpoint & $retryQ
    result = await client.client.get(retryUrl)

proc httpGet*(client: GumroadClient, endpoint: string): Future[AsyncResponse] {.async.} =
  ## GET with automatic token refresh on 401.
  var query = initOrderedTable[string, string]()
  addAccessToken(query, client)
  let url = client.baseUri & endpoint & $query
  result = await client.client.get(url)

  if result.code == Http401 and await client.tryAutoRefresh():
    var retryQ = initOrderedTable[string, string]()
    addAccessToken(retryQ, client)
    let retryUrl = client.baseUri & endpoint & $retryQ
    result = await client.client.get(retryUrl)

proc httpPost*[T](client: GumroadClient, endpoint: string, body: T): Future[AsyncResponse] {.async.} =
  ## POST with automatic token refresh on 401.
  var query = initOrderedTable[string, string]()
  addAccessToken(query, client)
  let url = client.baseUri & endpoint & $query
  result = await client.client.post(url, json.toJson(body))

  if result.code == Http401 and await client.tryAutoRefresh():
    var retryQ = initOrderedTable[string, string]()
    addAccessToken(retryQ, client)
    let retryUrl = client.baseUri & endpoint & $retryQ
    result = await client.client.post(retryUrl, json.toJson(body))

proc httpPost*(client: GumroadClient, endpoint: string): Future[AsyncResponse] {.async.} =
  ## POST with automatic token refresh on 401.
  var query = initOrderedTable[string, string]()
  addAccessToken(query, client)
  let url = client.baseUri & endpoint & $query
  result = await client.client.post(url)

  if result.code == Http401 and await client.tryAutoRefresh():
    var retryQ = initOrderedTable[string, string]()
    addAccessToken(retryQ, client)
    let retryUrl = client.baseUri & endpoint & $retryQ
    result = await client.client.post(retryUrl)

proc httpPost*(client: GumroadClient, endpoint: string, query: var QueryTable): Future[AsyncResponse] {.async.} =
  ## POST with automatic token refresh on 401.
  addAccessToken(query, client)
  let url = client.baseUri & endpoint & $query
  result = await client.client.post(url)

  if result.code == Http401 and await client.tryAutoRefresh():
    var retryQ = query
    addAccessToken(retryQ, client)
    let retryUrl = client.baseUri & endpoint & $retryQ
    result = await client.client.post(retryUrl)

proc httpDelete*(client: GumroadClient, endpoint: string): Future[AsyncResponse] {.async.} =
  ## DELETE with automatic token refresh on 401.
  var query = initOrderedTable[string, string]()
  addAccessToken(query, client)
  let url = client.baseUri & endpoint & $query
  result = await client.client.request(url, httpMethod = HttpDelete)

  if result.code == Http401 and await client.tryAutoRefresh():
    var retryQ = initOrderedTable[string, string]()
    addAccessToken(retryQ, client)
    let retryUrl = client.baseUri & endpoint & $retryQ
    result = await client.client.request(retryUrl, httpMethod = HttpDelete)

proc httpPut*[T](client: GumroadClient, endpoint: string, body: T): Future[AsyncResponse] {.async.} =
  ## PUT with automatic token refresh on 401.
  var query = initOrderedTable[string, string]()
  addAccessToken(query, client)
  let url = client.baseUri & endpoint & $query
  result = await client.client.request(url, httpMethod = HttpPut, body = json.toJson(body))

  if result.code == Http401 and await client.tryAutoRefresh():
    var retryQ = initOrderedTable[string, string]()
    addAccessToken(retryQ, client)
    let retryUrl = client.baseUri & endpoint & $retryQ
    result = await client.client.request(retryUrl, httpMethod = HttpPut, body = json.toJson(body))

proc httpPut*(client: GumroadClient, endpoint: string, query: var QueryTable): Future[AsyncResponse] {.async.} =
  ## PUT with automatic token refresh on 401.
  addAccessToken(query, client)
  let url = client.baseUri & endpoint & $query
  result = await client.client.request(url, httpMethod = HttpPut)

  if result.code == Http401 and await client.tryAutoRefresh():
    addAccessToken(query, client)
    let retryUrl = client.baseUri & endpoint & $query
    result = await client.client.request(retryUrl, httpMethod = HttpPut)

proc initGumroadClient*: GumroadClient =
  ## Creates a new `GumroadClient` with the provided API key. The API key is included in the Authorization header as
  ## a Bearer token for authentication with the Gumroad service.
  new(result)
  result.client = newAsyncHttpClient()
  result.baseUri = "https://api.gumroad.com/v2/"
  result.client.headers = newHttpHeaders({
    "Accept": "application/json",
  })
