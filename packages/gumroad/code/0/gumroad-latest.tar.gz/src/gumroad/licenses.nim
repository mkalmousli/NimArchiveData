# A Nim client for the Gumroad API - https://gumroad.com/api
#
# (c) 2026 George Lemon | MIT License
#          Made by Humans from OpenPeeps
#          https://github.com/openpeeps/gumroad-nim

import ./api

type
  GumroadCard* = object
    visual*: string           # Masked card numb
    `type`*: string           # Card ty

  GumroadCustomField* = object
    # Define fields as needed, placeholder for custom fields

  GumroadPurchase* = object
    seller_id*: string
    product_id*: string
    product_name*: string
    permalink*: string
    product_permalink*: string
    email*: string
    price*: int
    gumroad_fee*: int
    currency*: string
    quantity*: int
    discover_fee_charged*: bool
    can_contact*: bool
    referrer*: string
    card*: GumroadCard
    order_number*: int
    sale_id*: string
    sale_timestamp*: string
    purchaser_id*: string
    subscription_id*: Option[string]
    variants*: string
    license_key*: string
    is_multiseat_license*: bool
    ip_country*: string
    recurrence*: Option[string]
    is_gift_receiver_purchase*: bool
    refunded*: bool
    disputed*: bool
    dispute_won*: bool
    id*: string
    created_at*: string
    custom_fields*: seq[GumroadCustomField]
    chargebacked*: bool
    subscription_ended_at*: Option[string]
    subscription_cancelled_at*: Option[string]
    subscription_failed_at*: Option[string]

  GumroadLicense* = object
    success*: bool
    uses*: uint
    purchase: GumroadPurchase

proc postLicense*(client: GumroadClient, productId, licenseKey: string,
            incrementUses: Option[bool] = none(bool)): Future[GumroadLicense] {.async.} =
  ## Verifies a license key for a specific product and optionally increments the usage count.
  ## Returns a `GumroadLicense` object containing the verification result and purchase details.
  var queryParams = initOrderedTable[string, string]()
  queryParams["product_id"] = productId
  queryParams["license_key"] = licenseKey
  if incrementUses.isSome:
    queryParams["increment_uses"] = $incrementUses.get
  let res = await client.httpPost("/licenses/verify", query = queryParams)
  let body = await res.body
  case res.code
  of Http201:
    result = fromJSON(body, GumroadLicense)
  else:
    raise newException(GumroadClientError, body)

proc putLicenseEnable*(client: GumroadClient, productId, licenseKey: string): Future[GumroadLicense] {.async.} =
  ## Enables a license key for a specific product.
  var queryParams = initOrderedTable[string, string]()
  queryParams["product_id"] = productId
  queryParams["license_key"] = licenseKey
  let res = await client.httpPost("/licenses/enable", query = queryParams)
  let body = await res.body
  case res.code
  of Http200:
    result = fromJSON(body, GumroadLicense)    
  else:
    raise newException(GumroadClientError, body)

proc putLicenseDisable*(client: GumroadClient, productId, licenseKey: string): Future[GumroadLicense] {.async.} =
  ## Disables a license key for a specific product.
  var queryParams = initOrderedTable[string, string]()
  queryParams["product_id"] = productId
  queryParams["license_key"] = licenseKey
  let res = await client.httpPut("/licenses/disable", query = queryParams)
  let body = await res.body
  case res.code
  of Http201:
    result = fromJSON(body, GumroadLicense)    
  else:
    raise newException(GumroadClientError, body)

proc putLicenseDecrementUses*(client: GumroadClient, productId, licenseKey: string): Future[GumroadLicense] {.async.} =
  ## Decrements the usage count of a license key for a specific product.
  var queryParams = initOrderedTable[string, string]()
  queryParams["product_id"] = productId
  queryParams["license_key"] = licenseKey
  let res = await client.httpPut("/licenses/decrement_uses_count", query = queryParams)
  let body = await res.body
  case res.code
  of Http201:
    result = fromJSON(body, GumroadLicense)    
  else:
    raise newException(GumroadClientError, body)