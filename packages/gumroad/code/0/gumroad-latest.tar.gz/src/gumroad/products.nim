# A Nim client for the Gumroad API - https://gumroad.com/api
#
# (c) 2026 George Lemon | MIT License
#          Made by Humans from OpenPeeps
#          https://github.com/openpeeps/gumroad-nim

import std/[strformat, uri]
import ./api

type
  GumroadSubscriptionDuration* = enum
    durationMonthly = "monthly"
    durationQuarterly = "quarterly"
    durationBiannually = "biannually"
    durationAnnually = "annually"
    durationEveryTwoYears = "every_two_years"
  
  GumroadProductBundleProduct* = object
    product_id*: string ## External ID of the included product
    variant_id*: Option[string] ## External ID of the selected variant, if any
    quantity: uint ## Quantity of this item in the bundle
    position: uint ## Order of this item within the bundle

  GumroadCurrency* = enum
    usd = "usd"    ## US Dollar
    gbp = "gbp"    ## British Pound
    eur = "eur"    ## Euro
    jpy = "jpy"    ## Japanese Yen
    inr = "inr"    ## Indian Rupee
    aud = "aud"    ## Australian Dollar
    cad = "cad"    ## Canadian Dollar
    hkd = "hkd"    ## Hong Kong Dollar
    sgd = "sgd"    ## Singapore Dollar
    twd = "twd"    ## Taiwan Dollar
    nzd = "nzd"    ## New Zealand Dollar
    brl = "brl"    ## Brazilian Real
    zar = "zar"    ## South African Rand
    chf = "chf"    ## Swiss Franc
    ils = "ils"    ## Israeli Shekel
    php = "php"    ## Philippine Peso
    krw = "krw"    ## South Korean Won
    pln = "pln"    ## Polish Zloty
    czk = "czk"    ## Czech Koruna

  GumroadProductCover* = object
    id*: string
      ## Unique identifier for the cover
    url*: string
      ## Display URL (retina variant for non-GIF images; original URL for GIFs, videos, and oEmbed covers)
    original_url*: string
      ## URL of the original uploaded asset
    thumbnail*: Option[string]
      ## Thumbnail URL for oEmbed covers; null otherwise
    `type`*: string
      ## One of "image", "video", "oembed", or "unsplash"
    filetype*: Option[string]
      ## File extension; null when no file is attached
    width*: int
      ## Display width in pixels
    height*: int
      ## Display height in pixels
    native_width*: int
      ## Intrinsic width of the source asset in pixels
    native_height*: int
      ## Intrinsic height of the source asset in pixels

  GumroadProduct* = object
    custom_permalink*: Option[string]
      ## Custom URL slug for the product
    custom_receipt*: Option[string]
      ## Custom receipt text
    custom_summary*: Option[string]
      ## Custom summary text
    custom_fields*: Option[seq[string]]
      ## Custom fields for the product
    customizable_price*: Option[bool]
      ## Whether the product has a customizable price (Pay-what-you-want)
    description*: Option[string]
      ## Description of the product
    deleted*: bool
      ## Whether the product has been deleted
    max_purchase_count*: Option[int]
      ## Maximum number of purchases allowed for the product
    name*: string
      ## Name of the product
    preview_url*: Option[string]
      ## URL for previewing the product
    require_shipping*: bool
      ## Whether the product requires shipping
    subscription_duration: Option[GumroadSubscriptionDuration]
      ## Duration of the subscription if the product is a subscription
    published*: bool
      ## Whether the product is published and available for purchase
    id: string
      ## Unique identifier for the product
    price: int
      ## Price of the product in cents (e.g., 1000 for $10.00)
    purchasing_power_parity_prices: Option[OrderedTable[GumroadCurrency, int]]
      # Country-code-keyed prices adjusted for purchasing power parity
    currency*: GumroadCurrency
      ## Currency code for the product price (e.g., "USD")
    short_url: string
      ## Short URL for the product
    thumbnail_url: string
      ## URL for the product thumbnail image
    covers*: seq[GumroadProductCover]
      ## List of cover images for the product
    main_cover_id*: Option[string]
      ## ID of the main cover image for the product
    tags: seq[string]
      ## List of tags associated with the product
    formatted_price: string
      ## Human-readable formatted price (e.g., "$10.00")
      ## file_info*: 
    bundle_products*: seq[GumroadProductBundleProduct]
      ## List of products included in a bundle (if the product is a bundle)
  
  GumroadApiResponseProduct* = object
    success*: bool
    product*: GumroadProduct

  GumroadApiResponseProducts* = object
    success*: bool
    products*: seq[GumroadProduct]

proc isEmpty*(res: GumroadApiResponseProducts): bool =
  ## Checks if the API response contains an empty product.
  res.products.len == 0

proc len*(res: GumroadApiResponseProducts): int =
  ## Returns the number of products in the API response.
  res.products.len

proc getProducts*(client: GumroadClient): Future[GumroadApiResponseProducts] {.async.} =
  ## Retrieves a list of products for the authenticated user.
  let res: AsyncResponse = await client.httpGet("products")
  let body = await res.body
  case res.code:
  of Http200:
    result = fromJson(body, GumroadApiResponseProducts)
  else:
    raise newException(GumroadClientError, body)

proc getProduct*(client: GumroadClient, productId: string): Future[GumroadProduct] {.async.} =
  ## Retrieves the details of a specific product by its ID.
  if productId.len == 0:
    raise newException(GumroadClientError, "product_id cannot be empty")
  let res: AsyncResponse = await client.httpGet(fmt"products/{productId}")
  let body = await res.body
  case res.code:
  of Http200:
    let apiRes = fromJson(body, GumroadApiResponseProduct).product
  else:
    raise newException(GumroadClientError, body)

type
  GumroadProductType* = enum
    productDigital = "digital"
    productCourse = "course"
    productEbook = "ebook"
    productMembership = "membership"
    productBundle = "bundle"
    productCoffee = "coffee"
    productCall = "call"
    productCommission = "commission"

  HTMLContent* = string
  ProseMirrorDocument* = object
    id: string
    title: string
    description: string

  GumroadProductNew* = object
    case native_type*: GumroadProductType ## Type of the product
    of productMembership:
      subscription_duration*: Option[GumroadSubscriptionDuration]
        ## Duration of the subscription if the product is a subscription
    else: discard
    name*: string
      ## Name of the product
    description*: Option[HTMLContent]
      ## Optional, HTML-formatted description of the product
    price*: int64
      ## Price of the product in cents (e.g., 1000 for $10.00)
    price_currency_type*: GumroadCurrency
      ## Currency code for the product price (e.g., "USD")
    customizable_price*: Option[bool]
      ## Whether the product has a customizable price (Pay-what-you-want)
    suggested_price_cents*: Option[int64]
      ## Suggested price in cents for pay-what-you-want products
    max_purchase_count*: Option[int]
      ## Maximum number of purchases allowed for the product
    taxonomy_id*: Option[string]
      ## Optional taxonomy ID to categorize the product
    tags*: Option[seq[string]]
      ## Optional list of tags to associate with the product
    custom_summary*: Option[string]
      ## Optional custom summary text for the product
    rich_content*: Option[seq[ProseMirrorDocument]]
      ## Optional rich content sections for the product description
      ## Each section is a ProseMirror document with its own title and description, allowing
      ## for more complex formatting than a single HTML string.
    # files*: ??? not sure how to represent these yet

proc postProduct*(client: GumroadClient, product: GumroadProductNew): Future[GumroadProduct] {.async.} =
  ## Creates a new product with the specified type.
  let payload = toJson(product)
  let res: AsyncResponse = await client.httpPost("products", payload)
  let body = await res.body
  case res.code:
  of Http200:
    let apiRes = fromJson(body, GumroadApiResponseProduct).product
  else:
    raise newException(GumroadClientError, body)

#
# Product Covers API
#
type
  GumroadProductCoverRequest = object
    url*: string

  GumroadApiResponseProductsCovers* = object
    success*: bool
    covers*: seq[GumroadProductCover]
    main_cover_id*: Option[string]

proc postProductCover*(client: GumroadClient,
              productId, url: string): Future[GumroadApiResponseProductsCovers] {.async.} =
  ## Adds a cover to a product from a publicly accessible URL.
  if productId.len == 0:
    raise newException(GumroadClientError, "product_id cannot be empty")
  if url.len == 0:
    raise newException(GumroadClientError, "url cannot be empty")

  let payload = GumroadProductCoverRequest(url: url)
  let res: AsyncResponse = await client.httpPost(fmt"products/{productId}/covers", payload)
  let body = await res.body
  case res.code:
  of Http200:
    result = fromJson(body, GumroadApiResponseProductsCovers)
  else:
    raise newException(GumroadClientError, body)

proc deleteProductCover*(client: GumroadClient,
      productId, coverId: string): Future[GumroadApiResponseProductsCovers] {.async.} =
  ## Deletes a cover from a product.
  if productId.len == 0:
    raise newException(GumroadClientError, "product_id cannot be empty")
  if coverId.len == 0:
    raise newException(GumroadClientError, "cover_id cannot be empty")

  let res: AsyncResponse = await client.httpDelete(fmt"products/{productId}/covers/{coverId}")
  let body = await res.body
  case res.code:
  of Http200:
    result = fromJson(body, GumroadApiResponseProductsCovers)
  else:
    raise newException(GumroadClientError, body)

#
# Product Custom fields API
#
type

  GumroadProductCustomField* = object
    name*: string
    required*: string
    variant*: Option[string]

  GumroadProductCustomFieldCreateRequest = object
    name*: string
    required*: bool
    variant*: Option[string]

  GumroadProductCustomFieldUpdateRequest = object
    required*: bool
    variant*: Option[string]
    name*: Option[string]

  GumroadApiResponseProductsCustomFields* = object
    success*: bool
    custom_fields*: seq[GumroadProductCustomField]

  GumroadApiResponseProductsCustomField* = object
    success*: bool
    custom_field*: GumroadProductCustomField

  GumroadApiResponseDeleteProductCustomField* = object
    success*: bool
    message*: string


proc getProductCustomFields*(
    client: GumroadClient, productId: string
  ): Future[GumroadApiResponseProductsCustomFields] {.async.} =
  ## Retrieves all custom fields for a product.
  if productId.len == 0:
    raise newException(GumroadClientError, "product_id cannot be empty")
  let res: AsyncResponse = await client.httpGet(fmt"products/{productId}/custom_fields")
  let body = await res.body
  case res.code:
  of Http200:
    result = fromJson(body, GumroadApiResponseProductsCustomFields)
  else:
    raise newException(GumroadClientError, body)

proc postProductCustomField*(
    client: GumroadClient,
    productId, name: string,
    required: bool,
    variant: Option[string] = none(string)
  ): Future[GumroadApiResponseProductsCustomField] {.async.} =
  ## Creates a custom field for a product.
  if productId.len == 0:
    raise newException(GumroadClientError, "product_id cannot be empty")
  if name.len == 0:
    raise newException(GumroadClientError, "name cannot be empty")
  let payload = GumroadProductCustomFieldCreateRequest(
    name: name,
    required: required,
    variant: variant
  )

  let res: AsyncResponse = await client.httpPost(fmt"products/{productId}/custom_fields", payload)
  let body = await res.body
  case res.code:
  of Http200:
    result = fromJson(body, GumroadApiResponseProductsCustomField)
  else:
    raise newException(GumroadClientError, body)

proc putProductCustomField*(client: GumroadClient, productId, fieldName: string,
        required: bool, variant, name: Option[string] = none(string)
  ): Future[GumroadApiResponseProductsCustomField] {.async.} =
  ## Updates an existing custom field.
  if productId.len == 0:
    raise newException(GumroadClientError, "product_id cannot be empty")
  if fieldName.len == 0:
    raise newException(GumroadClientError, "custom_field name cannot be empty")

  let payload = GumroadProductCustomFieldUpdateRequest(
    required: required,
    variant: variant,
    name: name
  )

  let fieldNameEncoded = fieldName.encodeUrl()
  let res: AsyncResponse = await client.httpPut(fmt"products/{productId}/custom_fields/{fieldNameEncoded}", payload)
  let body = await res.body
  case res.code:
  of Http200:
    result = fromJson(body, GumroadApiResponseProductsCustomField)
  else:
    raise newException(GumroadClientError, body)

proc deleteProductCustomField*(client: GumroadClient,
        productId, fieldName: string): Future[GumroadApiResponseDeleteProductCustomField] {.async.} =
  ## Permanently deletes a custom field from a product.
  if productId.len == 0:
    raise newException(GumroadClientError, "product_id cannot be empty")
  if fieldName.len == 0:
    raise newException(GumroadClientError, "custom_field name cannot be empty")
  let fieldNameEncoded = fieldName.encodeUrl()
  let res: AsyncResponse = await client.httpDelete(fmt"products/{productId}/custom_fields/{fieldNameEncoded}")
  let body = await res.body
  case res.code:
  of Http200:
    result = fromJson(body, GumroadApiResponseDeleteProductCustomField)
  else:
    raise newException(GumroadClientError, body)


#
# Product Offer Codes API
#
type
  GumroadOfferCode* = object
    id*: string
    name*: string
    amount_cents*: Option[int]
    percent_off*: Option[int]
    max_purchase_count*: Option[int]
    universal*: Option[bool]
    times_used*: Option[int]

  GumroadApiResponseOfferCodes* = object
    success*: bool
    offer_codes*: seq[GumroadOfferCode]

  GumroadApiResponseOfferCode* = object
    success*: bool
    offer_code*: GumroadOfferCode

  GumroadApiResponseDeleteOfferCode* = object
    success*: bool
    message*: string

  GumroadOfferCodeCreateRequest = object
    name*: string
    amount_off*: int
    offer_type*: Option[string]
    max_purchase_count*: Option[int]
    universal*: Option[bool]

  GumroadOfferCodeUpdateRequest = object
    max_purchase_count*: Option[int]

proc getOfferCodes*(
    client: GumroadClient, productId: string
  ): Future[GumroadApiResponseOfferCodes] {.async.} =
  ## Retrieves all offer codes for a product.
  if productId.len == 0:
    raise newException(GumroadClientError, "product_id cannot be empty")
  let res: AsyncResponse = await client.httpGet(fmt"products/{productId}/offer_codes")
  let body = await res.body
  case res.code:
  of Http200:
    result = fromJson(body, GumroadApiResponseOfferCodes)
  else:
    raise newException(GumroadClientError, body)

proc getOfferCode*(
    client: GumroadClient, productId, offerCodeId: string
  ): Future[GumroadApiResponseOfferCode] {.async.} =
  ## Retrieves the details of a specific offer code.
  if productId.len == 0:
    raise newException(GumroadClientError, "product_id cannot be empty")
  if offerCodeId.len == 0:
    raise newException(GumroadClientError, "offer_code id cannot be empty")
  let res: AsyncResponse = await client.httpGet(fmt"products/{productId}/offer_codes/{offerCodeId}")
  let body = await res.body
  case res.code:
  of Http200:
    result = fromJson(body, GumroadApiResponseOfferCode)
  else:
    raise newException(GumroadClientError, body)

proc postOfferCode*(
    client: GumroadClient,
    productId, name: string,
    amountOff: int,
    offerType: Option[string] = none(string),
    maxPurchaseCount: Option[int] = none(int),
    universal: Option[bool] = none(bool)
  ): Future[GumroadApiResponseOfferCode] {.async.} =
  ## Creates a new offer code for a product.
  if productId.len == 0:
    raise newException(GumroadClientError, "product_id cannot be empty")
  if name.len == 0:
    raise newException(GumroadClientError, "name cannot be empty")
  let payload = GumroadOfferCodeCreateRequest(
    name: name,
    amount_off: amountOff,
    offer_type: offerType,
    max_purchase_count: maxPurchaseCount,
    universal: universal
  )
  let res: AsyncResponse = await client.httpPost(fmt"products/{productId}/offer_codes", payload)
  let body = await res.body
  case res.code:
  of Http200:
    result = fromJson(body, GumroadApiResponseOfferCode)
  else:
    raise newException(GumroadClientError, body)

proc putOfferCode*(
    client: GumroadClient,
    productId, offerCodeId: string,
    maxPurchaseCount: Option[int]
  ): Future[GumroadApiResponseOfferCode] {.async.} =
  ## Edits an existing offer code for a product.
  if productId.len == 0:
    raise newException(GumroadClientError, "product_id cannot be empty")
  if offerCodeId.len == 0:
    raise newException(GumroadClientError, "offer_code id cannot be empty")
  let payload = GumroadOfferCodeUpdateRequest(
    max_purchase_count: maxPurchaseCount
  )
  let res: AsyncResponse = await client.httpPut(fmt"products/{productId}/offer_codes/{offerCodeId}", payload)
  let body = await res.body
  case res.code:
  of Http200:
    result = fromJson(body, GumroadApiResponseOfferCode)
  else:
    raise newException(GumroadClientError, body)

proc deleteOfferCode*(
    client: GumroadClient,
    productId, offerCodeId: string
  ): Future[GumroadApiResponseDeleteOfferCode] {.async.} =
  ## Permanently deletes an offer code from a product.
  if productId.len == 0:
    raise newException(GumroadClientError, "product_id cannot be empty")
  if offerCodeId.len == 0:
    raise newException(GumroadClientError, "offer_code id cannot be empty")
  let res: AsyncResponse = await client.httpDelete(fmt"products/{productId}/offer_codes/{offerCodeId}")
  let body = await res.body
  case res.code:
  of Http200:
    result = fromJson(body, GumroadApiResponseDeleteOfferCode)
  else:
    raise newException(GumroadClientError, body)
