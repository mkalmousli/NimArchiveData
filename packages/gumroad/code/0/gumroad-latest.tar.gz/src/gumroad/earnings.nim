# A Nim client for the Gumroad API - https://gumroad.com/api
#
# (c) 2026 George Lemon | MIT License
#          Made by Humans from OpenPeeps
#          https://github.com/openpeeps/gumroad-nim

import ./api

type
  GumroadApiResponseEarnings* = object
    success*: bool
    year*: int
    currency*: string
    gross_cents*: int
    fees_cents*: int
    taxes_cents*: int
    affiliate_credit_cents*: int
    net_cents*: int

proc getEarnings*(client: GumroadClient, year: int): Future[GumroadApiResponseEarnings] {.async.} =
  ## Retrieves an annual earnings breakdown for the authenticated user.
  ## Requires the 'view_tax_data' scope.
  if year < 2000 or year > 2100:
    raise newException(GumroadClientError, "year must be a valid 4-digit year")
  
  var q = initOrderedTable[string, string]()
  q["year"] = $year

  let res: AsyncResponse = await client.httpGet("earnings", q)
  let body = await res.body
  case res.code:
  of Http200:
    result = fromJson(body, GumroadApiResponseEarnings)
  else:
    raise newException(GumroadClientError, body)