# Package

version       = "0.1.0"
author        = "George Lemon"
description   = "API client for Gumroad.com"
license       = "MIT"
srcDir        = "src"


# Dependencies

requires "nim >= 2.0.0"
requires "oauth2"
requires "openparser"