{.warning[UnusedImport]:off.}

import gdext/coronation/header/classes

import gdrefcounted; export gdrefcounted

expandOnClassImported(NavigationPathQueryResult2D, RefCounted)

proc setPath*(self: NavigationPathQueryResult2D; path: PackedVector2Array): void =
  expandMethodBind(className NavigationPathQueryResult2D, "set_path", 1509147220)
  methodbind.ptrcall(self, [getPtr path])

proc getPath*(self: NavigationPathQueryResult2D): PackedVector2Array =
  expandMethodBind(className NavigationPathQueryResult2D, "get_path", 2961356807)
  var ret: encoded PackedVector2Array
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(PackedVector2Array)

proc setPathTypes*(self: NavigationPathQueryResult2D; pathTypes: PackedInt32Array): void =
  expandMethodBind(className NavigationPathQueryResult2D, "set_path_types", 3614634198)
  methodbind.ptrcall(self, [getPtr pathTypes])

proc getPathTypes*(self: NavigationPathQueryResult2D): PackedInt32Array =
  expandMethodBind(className NavigationPathQueryResult2D, "get_path_types", 1930428628)
  var ret: encoded PackedInt32Array
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(PackedInt32Array)

proc setPathRids*(self: NavigationPathQueryResult2D; pathRids: Array[RID]): void =
  expandMethodBind(className NavigationPathQueryResult2D, "set_path_rids", 381264803)
  nilCheck pathRids
  methodbind.ptrcall(self, [getPtr pathRids])

proc getPathRids*(self: NavigationPathQueryResult2D): Array[RID] =
  expandMethodBind(className NavigationPathQueryResult2D, "get_path_rids", 3995934104)
  var ret: encoded Array[RID]
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(Array[RID])

proc setPathOwnerIds*(self: NavigationPathQueryResult2D; pathOwnerIds: PackedInt64Array): void =
  expandMethodBind(className NavigationPathQueryResult2D, "set_path_owner_ids", 3709968205)
  methodbind.ptrcall(self, [getPtr pathOwnerIds])

proc getPathOwnerIds*(self: NavigationPathQueryResult2D): PackedInt64Array =
  expandMethodBind(className NavigationPathQueryResult2D, "get_path_owner_ids", 235988956)
  var ret: encoded PackedInt64Array
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(PackedInt64Array)

proc setPathLength*(self: NavigationPathQueryResult2D; length: Float): void =
  expandMethodBind(className NavigationPathQueryResult2D, "set_path_length", 373806689)
  methodbind.ptrcall(self, [getPtr length])

proc getPathLength*(self: NavigationPathQueryResult2D): Float =
  expandMethodBind(className NavigationPathQueryResult2D, "get_path_length", 1740695150)
  var ret: encoded Float
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(Float)

proc reset*(self: NavigationPathQueryResult2D): void =
  expandMethodBind(className NavigationPathQueryResult2D, "reset", 3218959716)
  methodbind.ptrcall(self, [])

template path*(self: NavigationPathQueryResult2D): untyped = self.getPath()
template `path=`*(self: NavigationPathQueryResult2D; value) = self.setPath(value)

template pathTypes*(self: NavigationPathQueryResult2D): untyped = self.getPathTypes()
template `pathTypes=`*(self: NavigationPathQueryResult2D; value) = self.setPathTypes(value)

template pathRids*(self: NavigationPathQueryResult2D): untyped = self.getPathRids()
template `pathRids=`*(self: NavigationPathQueryResult2D; value) = self.setPathRids(value)

template pathOwnerIds*(self: NavigationPathQueryResult2D): untyped = self.getPathOwnerIds()
template `pathOwnerIds=`*(self: NavigationPathQueryResult2D; value) = self.setPathOwnerIds(value)

template pathLength*(self: NavigationPathQueryResult2D): untyped = self.getPathLength()
template `pathLength=`*(self: NavigationPathQueryResult2D; value) = self.setPathLength(value)
