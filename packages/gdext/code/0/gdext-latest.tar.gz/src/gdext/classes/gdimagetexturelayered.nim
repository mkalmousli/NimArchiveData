{.warning[UnusedImport]:off.}

import gdext/coronation/header/classes

import gdtexturelayered; export gdtexturelayered

expandOnClassImported(ImageTextureLayered, TextureLayered)

proc createFromImages*(self: ImageTextureLayered; images: Array[gdref Image]): Error =
  expandMethodBind(className ImageTextureLayered, "create_from_images", 2785773503)
  nilCheck images
  var ret: encoded Error
  methodbind.ptrcall(self, [getPtr images], addr ret)
  (addr ret).decode_result(Error)

proc updateLayer*(self: ImageTextureLayered; image: gdref Image; layer: int32): void =
  expandMethodBind(className ImageTextureLayered, "update_layer", 3331733361)
  methodbind.ptrcall(self, [getPtr image, getPtr layer])
