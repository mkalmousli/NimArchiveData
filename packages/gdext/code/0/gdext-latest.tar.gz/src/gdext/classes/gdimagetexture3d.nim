{.warning[UnusedImport]:off.}

import gdext/coronation/header/classes

import gdtexture3d; export gdtexture3d

expandOnClassImported(ImageTexture3D, Texture3D)

proc create*(self: ImageTexture3D; format: Image_Format; width: int32; height: int32; depth: int32; useMipmaps: bool; data: Array[gdref Image]): Error =
  expandMethodBind(className ImageTexture3D, "create", 1130379827)
  nilCheck data
  var ret: encoded Error
  methodbind.ptrcall(self, [getPtr format, getPtr width, getPtr height, getPtr depth, getPtr useMipmaps, getPtr data], addr ret)
  (addr ret).decode_result(Error)

proc update*(self: ImageTexture3D; data: Array[gdref Image]): void =
  expandMethodBind(className ImageTexture3D, "update", 381264803)
  nilCheck data
  methodbind.ptrcall(self, [getPtr data])
