{.warning[UnusedImport]:off.}

import gdext/coronation/header/classes

import gdobject; export gdobject

proc getDataDir*(self: EditorPaths): String =
  expandMethodBind(className EditorPaths, "get_data_dir", 201670096)
  var ret: encoded String
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(String)

proc getConfigDir*(self: EditorPaths): String =
  expandMethodBind(className EditorPaths, "get_config_dir", 201670096)
  var ret: encoded String
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(String)

proc getCacheDir*(self: EditorPaths): String =
  expandMethodBind(className EditorPaths, "get_cache_dir", 201670096)
  var ret: encoded String
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(String)

proc isSelfContained*(self: EditorPaths): bool =
  expandMethodBind(className EditorPaths, "is_self_contained", 36873697)
  var ret: encoded bool
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(bool)

proc getSelfContainedFile*(self: EditorPaths): String =
  expandMethodBind(className EditorPaths, "get_self_contained_file", 201670096)
  var ret: encoded String
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(String)

proc getProjectSettingsDir*(self: EditorPaths): String =
  expandMethodBind(className EditorPaths, "get_project_settings_dir", 201670096)
  var ret: encoded String
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(String)