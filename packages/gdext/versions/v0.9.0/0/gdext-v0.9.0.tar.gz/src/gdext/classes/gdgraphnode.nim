{.warning[UnusedImport]:off.}

import gdext/coronation/header/classes

import gdgraphelement; export gdgraphelement

method drawPort*(self: GraphNode; slotIndex: int32; position: Vector2i; left: bool; color: Color): void {.base.} = (discard)
proc registerVirtual_drawPort*[T: GraphNode](Self: typedesc[T]) =
  Self.vmethods[newStringName"_draw_port"] = proc (p_instance: ClassInstancePtr; p_args: ptr UncheckedArray[ConstTypePtr]; r_ret: TypePtr) {.gdcall.} =
    errproof: cast[GraphNode](p_instance).drawPort(p_args[0].decode(int32), p_args[1].decode(Vector2i), p_args[2].decode(bool), p_args[3].decode(Color))

proc setTitle*(self: GraphNode; title: String): void =
  expandMethodBind(className GraphNode, "set_title", 83702148)
  methodbind.ptrcall(self, [getPtr title])

proc getTitle*(self: GraphNode): String =
  expandMethodBind(className GraphNode, "get_title", 201670096)
  var ret: encoded String
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(String)

proc getTitlebarHbox*(self: GraphNode): HBoxContainer =
  expandMethodBind(className GraphNode, "get_titlebar_hbox", 3590609951)
  var ret: encoded HBoxContainer
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(HBoxContainer)

proc setSlot*(self: GraphNode; slotIndex: int32; enableLeftPort: bool; typeLeft: int32; colorLeft: Color; enableRightPort: bool; typeRight: int32; colorRight: Color; customIconLeft: gdref Texture2D = default gdref Texture2D; customIconRight: gdref Texture2D = default gdref Texture2D; drawStylebox: bool = true): void =
  expandMethodBind(className GraphNode, "set_slot", 2873310869)
  methodbind.ptrcall(self, [getPtr slotIndex, getPtr enableLeftPort, getPtr typeLeft, getPtr colorLeft, getPtr enableRightPort, getPtr typeRight, getPtr colorRight, getPtr customIconLeft, getPtr customIconRight, getPtr drawStylebox])

proc clearSlot*(self: GraphNode; slotIndex: int32): void =
  expandMethodBind(className GraphNode, "clear_slot", 1286410249)
  methodbind.ptrcall(self, [getPtr slotIndex])

proc clearAllSlots*(self: GraphNode): void =
  expandMethodBind(className GraphNode, "clear_all_slots", 3218959716)
  methodbind.ptrcall(self, [])

proc isSlotEnabledLeft*(self: GraphNode; slotIndex: int32): bool =
  expandMethodBind(className GraphNode, "is_slot_enabled_left", 1116898809)
  var ret: encoded bool
  methodbind.ptrcall(self, [getPtr slotIndex], addr ret)
  (addr ret).decode_result(bool)

proc setSlotEnabledLeft*(self: GraphNode; slotIndex: int32; enable: bool): void =
  expandMethodBind(className GraphNode, "set_slot_enabled_left", 300928843)
  methodbind.ptrcall(self, [getPtr slotIndex, getPtr enable])

proc setSlotTypeLeft*(self: GraphNode; slotIndex: int32; `type`: int32): void =
  expandMethodBind(className GraphNode, "set_slot_type_left", 3937882851)
  methodbind.ptrcall(self, [getPtr slotIndex, getPtr `type`])

proc getSlotTypeLeft*(self: GraphNode; slotIndex: int32): int32 =
  expandMethodBind(className GraphNode, "get_slot_type_left", 923996154)
  var ret: encoded int32
  methodbind.ptrcall(self, [getPtr slotIndex], addr ret)
  (addr ret).decode_result(int32)

proc setSlotColorLeft*(self: GraphNode; slotIndex: int32; color: Color): void =
  expandMethodBind(className GraphNode, "set_slot_color_left", 2878471219)
  methodbind.ptrcall(self, [getPtr slotIndex, getPtr color])

proc getSlotColorLeft*(self: GraphNode; slotIndex: int32): Color =
  expandMethodBind(className GraphNode, "get_slot_color_left", 3457211756)
  var ret: encoded Color
  methodbind.ptrcall(self, [getPtr slotIndex], addr ret)
  (addr ret).decode_result(Color)

proc setSlotCustomIconLeft*(self: GraphNode; slotIndex: int32; customIcon: gdref Texture2D): void =
  expandMethodBind(className GraphNode, "set_slot_custom_icon_left", 666127730)
  methodbind.ptrcall(self, [getPtr slotIndex, getPtr customIcon])

proc getSlotCustomIconLeft*(self: GraphNode; slotIndex: int32): gdref Texture2D =
  expandMethodBind(className GraphNode, "get_slot_custom_icon_left", 3536238170)
  var ret: encoded gdref Texture2D
  methodbind.ptrcall(self, [getPtr slotIndex], addr ret)
  (addr ret).decode_result(gdref Texture2D)

proc isSlotEnabledRight*(self: GraphNode; slotIndex: int32): bool =
  expandMethodBind(className GraphNode, "is_slot_enabled_right", 1116898809)
  var ret: encoded bool
  methodbind.ptrcall(self, [getPtr slotIndex], addr ret)
  (addr ret).decode_result(bool)

proc setSlotEnabledRight*(self: GraphNode; slotIndex: int32; enable: bool): void =
  expandMethodBind(className GraphNode, "set_slot_enabled_right", 300928843)
  methodbind.ptrcall(self, [getPtr slotIndex, getPtr enable])

proc setSlotTypeRight*(self: GraphNode; slotIndex: int32; `type`: int32): void =
  expandMethodBind(className GraphNode, "set_slot_type_right", 3937882851)
  methodbind.ptrcall(self, [getPtr slotIndex, getPtr `type`])

proc getSlotTypeRight*(self: GraphNode; slotIndex: int32): int32 =
  expandMethodBind(className GraphNode, "get_slot_type_right", 923996154)
  var ret: encoded int32
  methodbind.ptrcall(self, [getPtr slotIndex], addr ret)
  (addr ret).decode_result(int32)

proc setSlotColorRight*(self: GraphNode; slotIndex: int32; color: Color): void =
  expandMethodBind(className GraphNode, "set_slot_color_right", 2878471219)
  methodbind.ptrcall(self, [getPtr slotIndex, getPtr color])

proc getSlotColorRight*(self: GraphNode; slotIndex: int32): Color =
  expandMethodBind(className GraphNode, "get_slot_color_right", 3457211756)
  var ret: encoded Color
  methodbind.ptrcall(self, [getPtr slotIndex], addr ret)
  (addr ret).decode_result(Color)

proc setSlotCustomIconRight*(self: GraphNode; slotIndex: int32; customIcon: gdref Texture2D): void =
  expandMethodBind(className GraphNode, "set_slot_custom_icon_right", 666127730)
  methodbind.ptrcall(self, [getPtr slotIndex, getPtr customIcon])

proc getSlotCustomIconRight*(self: GraphNode; slotIndex: int32): gdref Texture2D =
  expandMethodBind(className GraphNode, "get_slot_custom_icon_right", 3536238170)
  var ret: encoded gdref Texture2D
  methodbind.ptrcall(self, [getPtr slotIndex], addr ret)
  (addr ret).decode_result(gdref Texture2D)

proc isSlotDrawStylebox*(self: GraphNode; slotIndex: int32): bool =
  expandMethodBind(className GraphNode, "is_slot_draw_stylebox", 1116898809)
  var ret: encoded bool
  methodbind.ptrcall(self, [getPtr slotIndex], addr ret)
  (addr ret).decode_result(bool)

proc setSlotDrawStylebox*(self: GraphNode; slotIndex: int32; enable: bool): void =
  expandMethodBind(className GraphNode, "set_slot_draw_stylebox", 300928843)
  methodbind.ptrcall(self, [getPtr slotIndex, getPtr enable])

proc setIgnoreInvalidConnectionType*(self: GraphNode; ignore: bool): void =
  expandMethodBind(className GraphNode, "set_ignore_invalid_connection_type", 2586408642)
  methodbind.ptrcall(self, [getPtr ignore])

proc isIgnoringValidConnectionType*(self: GraphNode): bool =
  expandMethodBind(className GraphNode, "is_ignoring_valid_connection_type", 36873697)
  var ret: encoded bool
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(bool)

proc getInputPortCount*(self: GraphNode): int32 =
  expandMethodBind(className GraphNode, "get_input_port_count", 2455072627)
  var ret: encoded int32
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(int32)

proc getInputPortPosition*(self: GraphNode; portIdx: int32): Vector2 =
  expandMethodBind(className GraphNode, "get_input_port_position", 3114997196)
  var ret: encoded Vector2
  methodbind.ptrcall(self, [getPtr portIdx], addr ret)
  (addr ret).decode_result(Vector2)

proc getInputPortType*(self: GraphNode; portIdx: int32): int32 =
  expandMethodBind(className GraphNode, "get_input_port_type", 3744713108)
  var ret: encoded int32
  methodbind.ptrcall(self, [getPtr portIdx], addr ret)
  (addr ret).decode_result(int32)

proc getInputPortColor*(self: GraphNode; portIdx: int32): Color =
  expandMethodBind(className GraphNode, "get_input_port_color", 2624840992)
  var ret: encoded Color
  methodbind.ptrcall(self, [getPtr portIdx], addr ret)
  (addr ret).decode_result(Color)

proc getInputPortSlot*(self: GraphNode; portIdx: int32): int32 =
  expandMethodBind(className GraphNode, "get_input_port_slot", 3744713108)
  var ret: encoded int32
  methodbind.ptrcall(self, [getPtr portIdx], addr ret)
  (addr ret).decode_result(int32)

proc getOutputPortCount*(self: GraphNode): int32 =
  expandMethodBind(className GraphNode, "get_output_port_count", 2455072627)
  var ret: encoded int32
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(int32)

proc getOutputPortPosition*(self: GraphNode; portIdx: int32): Vector2 =
  expandMethodBind(className GraphNode, "get_output_port_position", 3114997196)
  var ret: encoded Vector2
  methodbind.ptrcall(self, [getPtr portIdx], addr ret)
  (addr ret).decode_result(Vector2)

proc getOutputPortType*(self: GraphNode; portIdx: int32): int32 =
  expandMethodBind(className GraphNode, "get_output_port_type", 3744713108)
  var ret: encoded int32
  methodbind.ptrcall(self, [getPtr portIdx], addr ret)
  (addr ret).decode_result(int32)

proc getOutputPortColor*(self: GraphNode; portIdx: int32): Color =
  expandMethodBind(className GraphNode, "get_output_port_color", 2624840992)
  var ret: encoded Color
  methodbind.ptrcall(self, [getPtr portIdx], addr ret)
  (addr ret).decode_result(Color)

proc getOutputPortSlot*(self: GraphNode; portIdx: int32): int32 =
  expandMethodBind(className GraphNode, "get_output_port_slot", 3744713108)
  var ret: encoded int32
  methodbind.ptrcall(self, [getPtr portIdx], addr ret)
  (addr ret).decode_result(int32)

template title*(self: GraphNode): untyped = self.getTitle()
template `title=`*(self: GraphNode; value) = self.setTitle(value)

template ignoreInvalidConnectionType*(self: GraphNode): untyped = self.isIgnoringValidConnectionType()
template `ignoreInvalidConnectionType=`*(self: GraphNode; value) = self.setIgnoreInvalidConnectionType(value)
