{.warning[UnusedImport]:off.}

import gdext/coronation/header/classes

import gdnode3d; export gdnode3d

proc getRid*(self: NavigationLink3D): RID =
  expandMethodBind(className NavigationLink3D, "get_rid", 2944877500)
  var ret: encoded RID
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(RID)

proc setEnabled*(self: NavigationLink3D; enabled: bool): void =
  expandMethodBind(className NavigationLink3D, "set_enabled", 2586408642)
  methodbind.ptrcall(self, [getPtr enabled])

proc isEnabled*(self: NavigationLink3D): bool =
  expandMethodBind(className NavigationLink3D, "is_enabled", 36873697)
  var ret: encoded bool
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(bool)

proc setNavigationMap*(self: NavigationLink3D; navigationMap: RID): void =
  expandMethodBind(className NavigationLink3D, "set_navigation_map", 2722037293)
  methodbind.ptrcall(self, [getPtr navigationMap])

proc getNavigationMap*(self: NavigationLink3D): RID =
  expandMethodBind(className NavigationLink3D, "get_navigation_map", 2944877500)
  var ret: encoded RID
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(RID)

proc setBidirectional*(self: NavigationLink3D; bidirectional: bool): void =
  expandMethodBind(className NavigationLink3D, "set_bidirectional", 2586408642)
  methodbind.ptrcall(self, [getPtr bidirectional])

proc isBidirectional*(self: NavigationLink3D): bool =
  expandMethodBind(className NavigationLink3D, "is_bidirectional", 36873697)
  var ret: encoded bool
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(bool)

proc setNavigationLayers*(self: NavigationLink3D; navigationLayers: uint32): void =
  expandMethodBind(className NavigationLink3D, "set_navigation_layers", 1286410249)
  methodbind.ptrcall(self, [getPtr navigationLayers])

proc getNavigationLayers*(self: NavigationLink3D): uint32 =
  expandMethodBind(className NavigationLink3D, "get_navigation_layers", 3905245786)
  var ret: encoded uint32
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(uint32)

proc setNavigationLayerValue*(self: NavigationLink3D; layerNumber: int32; value: bool): void =
  expandMethodBind(className NavigationLink3D, "set_navigation_layer_value", 300928843)
  methodbind.ptrcall(self, [getPtr layerNumber, getPtr value])

proc getNavigationLayerValue*(self: NavigationLink3D; layerNumber: int32): bool =
  expandMethodBind(className NavigationLink3D, "get_navigation_layer_value", 1116898809)
  var ret: encoded bool
  methodbind.ptrcall(self, [getPtr layerNumber], addr ret)
  (addr ret).decode_result(bool)

proc setStartPosition*(self: NavigationLink3D; position: Vector3): void =
  expandMethodBind(className NavigationLink3D, "set_start_position", 3460891852)
  methodbind.ptrcall(self, [getPtr position])

proc getStartPosition*(self: NavigationLink3D): Vector3 =
  expandMethodBind(className NavigationLink3D, "get_start_position", 3360562783)
  var ret: encoded Vector3
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(Vector3)

proc setEndPosition*(self: NavigationLink3D; position: Vector3): void =
  expandMethodBind(className NavigationLink3D, "set_end_position", 3460891852)
  methodbind.ptrcall(self, [getPtr position])

proc getEndPosition*(self: NavigationLink3D): Vector3 =
  expandMethodBind(className NavigationLink3D, "get_end_position", 3360562783)
  var ret: encoded Vector3
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(Vector3)

proc setGlobalStartPosition*(self: NavigationLink3D; position: Vector3): void =
  expandMethodBind(className NavigationLink3D, "set_global_start_position", 3460891852)
  methodbind.ptrcall(self, [getPtr position])

proc getGlobalStartPosition*(self: NavigationLink3D): Vector3 =
  expandMethodBind(className NavigationLink3D, "get_global_start_position", 3360562783)
  var ret: encoded Vector3
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(Vector3)

proc setGlobalEndPosition*(self: NavigationLink3D; position: Vector3): void =
  expandMethodBind(className NavigationLink3D, "set_global_end_position", 3460891852)
  methodbind.ptrcall(self, [getPtr position])

proc getGlobalEndPosition*(self: NavigationLink3D): Vector3 =
  expandMethodBind(className NavigationLink3D, "get_global_end_position", 3360562783)
  var ret: encoded Vector3
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(Vector3)

proc setEnterCost*(self: NavigationLink3D; enterCost: Float): void =
  expandMethodBind(className NavigationLink3D, "set_enter_cost", 373806689)
  methodbind.ptrcall(self, [getPtr enterCost])

proc getEnterCost*(self: NavigationLink3D): Float =
  expandMethodBind(className NavigationLink3D, "get_enter_cost", 1740695150)
  var ret: encoded Float
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(Float)

proc setTravelCost*(self: NavigationLink3D; travelCost: Float): void =
  expandMethodBind(className NavigationLink3D, "set_travel_cost", 373806689)
  methodbind.ptrcall(self, [getPtr travelCost])

proc getTravelCost*(self: NavigationLink3D): Float =
  expandMethodBind(className NavigationLink3D, "get_travel_cost", 1740695150)
  var ret: encoded Float
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(Float)

template enabled*(self: NavigationLink3D): untyped = self.isEnabled()
template `enabled=`*(self: NavigationLink3D; value) = self.setEnabled(value)

template bidirectional*(self: NavigationLink3D): untyped = self.isBidirectional()
template `bidirectional=`*(self: NavigationLink3D; value) = self.setBidirectional(value)

template navigationLayers*(self: NavigationLink3D): untyped = self.getNavigationLayers()
template `navigationLayers=`*(self: NavigationLink3D; value) = self.setNavigationLayers(value)

template startPosition*(self: NavigationLink3D): untyped = self.getStartPosition()
template `startPosition=`*(self: NavigationLink3D; value) = self.setStartPosition(value)

template endPosition*(self: NavigationLink3D): untyped = self.getEndPosition()
template `endPosition=`*(self: NavigationLink3D; value) = self.setEndPosition(value)

template enterCost*(self: NavigationLink3D): untyped = self.getEnterCost()
template `enterCost=`*(self: NavigationLink3D; value) = self.setEnterCost(value)

template travelCost*(self: NavigationLink3D): untyped = self.getTravelCost()
template `travelCost=`*(self: NavigationLink3D; value) = self.setTravelCost(value)
