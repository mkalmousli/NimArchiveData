{.warning[UnusedImport]:off.}

import gdext/coronation/header/classes

import gdgpuparticlescollision3d; export gdgpuparticlescollision3d

expandOnClassImported(GPUParticlesCollisionHeightField3D, GPUParticlesCollision3D)

proc setSize*(self: GPUParticlesCollisionHeightField3D; size: Vector3): void =
  expandMethodBind(className GPUParticlesCollisionHeightField3D, "set_size", 3460891852)
  methodbind.ptrcall(self, [getPtr size])

proc getSize*(self: GPUParticlesCollisionHeightField3D): Vector3 =
  expandMethodBind(className GPUParticlesCollisionHeightField3D, "get_size", 3360562783)
  var ret: encoded Vector3
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(Vector3)

proc setResolution*(self: GPUParticlesCollisionHeightField3D; resolution: GPUParticlesCollisionHeightField3D_Resolution): void =
  expandMethodBind(className GPUParticlesCollisionHeightField3D, "set_resolution", 1009996517)
  methodbind.ptrcall(self, [getPtr resolution])

proc getResolution*(self: GPUParticlesCollisionHeightField3D): GPUParticlesCollisionHeightField3D_Resolution =
  expandMethodBind(className GPUParticlesCollisionHeightField3D, "get_resolution", 1156065644)
  var ret: encoded GPUParticlesCollisionHeightField3D_Resolution
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(GPUParticlesCollisionHeightField3D_Resolution)

proc setUpdateMode*(self: GPUParticlesCollisionHeightField3D; updateMode: GPUParticlesCollisionHeightField3D_UpdateMode): void =
  expandMethodBind(className GPUParticlesCollisionHeightField3D, "set_update_mode", 673680859)
  methodbind.ptrcall(self, [getPtr updateMode])

proc getUpdateMode*(self: GPUParticlesCollisionHeightField3D): GPUParticlesCollisionHeightField3D_UpdateMode =
  expandMethodBind(className GPUParticlesCollisionHeightField3D, "get_update_mode", 1998141380)
  var ret: encoded GPUParticlesCollisionHeightField3D_UpdateMode
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(GPUParticlesCollisionHeightField3D_UpdateMode)

proc setHeightfieldMask*(self: GPUParticlesCollisionHeightField3D; heightfieldMask: uint32): void =
  expandMethodBind(className GPUParticlesCollisionHeightField3D, "set_heightfield_mask", 1286410249)
  methodbind.ptrcall(self, [getPtr heightfieldMask])

proc getHeightfieldMask*(self: GPUParticlesCollisionHeightField3D): uint32 =
  expandMethodBind(className GPUParticlesCollisionHeightField3D, "get_heightfield_mask", 3905245786)
  var ret: encoded uint32
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(uint32)

proc setHeightfieldMaskValue*(self: GPUParticlesCollisionHeightField3D; layerNumber: int32; value: bool): void =
  expandMethodBind(className GPUParticlesCollisionHeightField3D, "set_heightfield_mask_value", 300928843)
  methodbind.ptrcall(self, [getPtr layerNumber, getPtr value])

proc getHeightfieldMaskValue*(self: GPUParticlesCollisionHeightField3D; layerNumber: int32): bool =
  expandMethodBind(className GPUParticlesCollisionHeightField3D, "get_heightfield_mask_value", 1116898809)
  var ret: encoded bool
  methodbind.ptrcall(self, [getPtr layerNumber], addr ret)
  (addr ret).decode_result(bool)

proc setFollowCameraEnabled*(self: GPUParticlesCollisionHeightField3D; enabled: bool): void =
  expandMethodBind(className GPUParticlesCollisionHeightField3D, "set_follow_camera_enabled", 2586408642)
  methodbind.ptrcall(self, [getPtr enabled])

proc isFollowCameraEnabled*(self: GPUParticlesCollisionHeightField3D): bool =
  expandMethodBind(className GPUParticlesCollisionHeightField3D, "is_follow_camera_enabled", 36873697)
  var ret: encoded bool
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(bool)

template size*(self: GPUParticlesCollisionHeightField3D): untyped = self.getSize()
template `size=`*(self: GPUParticlesCollisionHeightField3D; value) = self.setSize(value)

template resolution*(self: GPUParticlesCollisionHeightField3D): untyped = self.getResolution()
template `resolution=`*(self: GPUParticlesCollisionHeightField3D; value) = self.setResolution(value)

template updateMode*(self: GPUParticlesCollisionHeightField3D): untyped = self.getUpdateMode()
template `updateMode=`*(self: GPUParticlesCollisionHeightField3D; value) = self.setUpdateMode(value)

template followCameraEnabled*(self: GPUParticlesCollisionHeightField3D): untyped = self.isFollowCameraEnabled()
template `followCameraEnabled=`*(self: GPUParticlesCollisionHeightField3D; value) = self.setFollowCameraEnabled(value)

template heightfieldMask*(self: GPUParticlesCollisionHeightField3D): untyped = self.getHeightfieldMask()
template `heightfieldMask=`*(self: GPUParticlesCollisionHeightField3D; value) = self.setHeightfieldMask(value)
