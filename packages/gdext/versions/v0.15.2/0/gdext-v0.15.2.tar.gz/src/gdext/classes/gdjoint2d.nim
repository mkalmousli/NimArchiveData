{.warning[UnusedImport]:off.}

import gdext/coronation/header/classes

import gdnode2d; export gdnode2d

expandOnClassImported(Joint2D, Node2D)

proc setNodeA*(self: Joint2D; node: NodePath): void =
  expandMethodBind(className Joint2D, "set_node_a", 1348162250)
  methodbind.ptrcall(self, [getPtr node])

proc getNodeA*(self: Joint2D): NodePath =
  expandMethodBind(className Joint2D, "get_node_a", 4075236667)
  var ret: encoded NodePath
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(NodePath)

proc setNodeB*(self: Joint2D; node: NodePath): void =
  expandMethodBind(className Joint2D, "set_node_b", 1348162250)
  methodbind.ptrcall(self, [getPtr node])

proc getNodeB*(self: Joint2D): NodePath =
  expandMethodBind(className Joint2D, "get_node_b", 4075236667)
  var ret: encoded NodePath
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(NodePath)

proc setBias*(self: Joint2D; bias: Float): void =
  expandMethodBind(className Joint2D, "set_bias", 373806689)
  methodbind.ptrcall(self, [getPtr bias])

proc getBias*(self: Joint2D): Float =
  expandMethodBind(className Joint2D, "get_bias", 1740695150)
  var ret: encoded Float
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(Float)

proc setExcludeNodesFromCollision*(self: Joint2D; enable: bool): void =
  expandMethodBind(className Joint2D, "set_exclude_nodes_from_collision", 2586408642)
  methodbind.ptrcall(self, [getPtr enable])

proc getExcludeNodesFromCollision*(self: Joint2D): bool =
  expandMethodBind(className Joint2D, "get_exclude_nodes_from_collision", 36873697)
  var ret: encoded bool
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(bool)

proc getRid*(self: Joint2D): RID =
  expandMethodBind(className Joint2D, "get_rid", 2944877500)
  var ret: encoded RID
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(RID)

template nodeA*(self: Joint2D): untyped = self.getNodeA()
template `nodeA=`*(self: Joint2D; value) = self.setNodeA(value)

template nodeB*(self: Joint2D): untyped = self.getNodeB()
template `nodeB=`*(self: Joint2D; value) = self.setNodeB(value)

template bias*(self: Joint2D): untyped = self.getBias()
template `bias=`*(self: Joint2D; value) = self.setBias(value)

template disableCollision*(self: Joint2D): untyped = self.getExcludeNodesFromCollision()
template `disableCollision=`*(self: Joint2D; value) = self.setExcludeNodesFromCollision(value)
