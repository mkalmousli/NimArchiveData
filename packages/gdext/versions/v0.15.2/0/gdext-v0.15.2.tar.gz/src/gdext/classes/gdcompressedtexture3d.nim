{.warning[UnusedImport]:off.}

import gdext/coronation/header/classes

import gdtexture3d; export gdtexture3d

expandOnClassImported(CompressedTexture3D, Texture3D)

proc load*(self: CompressedTexture3D; path: String): Error =
  expandMethodBind(className CompressedTexture3D, "load", 166001499)
  var ret: encoded Error
  methodbind.ptrcall(self, [getPtr path], addr ret)
  (addr ret).decode_result(Error)

proc getLoadPath*(self: CompressedTexture3D): String =
  expandMethodBind(className CompressedTexture3D, "get_load_path", 201670096)
  var ret: encoded String
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(String)

template loadPath*(self: CompressedTexture3D): untyped = self.getLoadPath()
template `loadPath=`*(self: CompressedTexture3D; value) = self.load(value)
