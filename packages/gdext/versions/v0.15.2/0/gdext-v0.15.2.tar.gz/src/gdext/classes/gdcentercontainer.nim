{.warning[UnusedImport]:off.}

import gdext/coronation/header/classes

import gdcontainer; export gdcontainer

expandOnClassImported(CenterContainer, Container)

proc setUseTopLeft*(self: CenterContainer; enable: bool): void =
  expandMethodBind(className CenterContainer, "set_use_top_left", 2586408642)
  methodbind.ptrcall(self, [getPtr enable])

proc isUsingTopLeft*(self: CenterContainer): bool =
  expandMethodBind(className CenterContainer, "is_using_top_left", 36873697)
  var ret: encoded bool
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(bool)

template useTopLeft*(self: CenterContainer): untyped = self.isUsingTopLeft()
template `useTopLeft=`*(self: CenterContainer; value) = self.setUseTopLeft(value)
