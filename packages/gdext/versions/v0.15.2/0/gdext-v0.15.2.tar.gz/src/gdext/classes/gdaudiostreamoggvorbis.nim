{.warning[UnusedImport]:off.}

import gdext/coronation/header/classes

import gdaudiostream; export gdaudiostream

expandOnClassImported(AudioStreamOggVorbis, AudioStream)

proc loadFromBuffer*(_: typedesc[AudioStreamOggVorbis]; streamData: PackedByteArray): gdref AudioStreamOggVorbis =
  expandMethodBind(className AudioStreamOggVorbis, "load_from_buffer", 354904730)
  var ret: encoded gdref AudioStreamOggVorbis
  methodbind.ptrcall([getPtr streamData], addr ret)
  (addr ret).decode_result(gdref AudioStreamOggVorbis)

proc loadFromFile*(_: typedesc[AudioStreamOggVorbis]; path: String): gdref AudioStreamOggVorbis =
  expandMethodBind(className AudioStreamOggVorbis, "load_from_file", 797568536)
  var ret: encoded gdref AudioStreamOggVorbis
  methodbind.ptrcall([getPtr path], addr ret)
  (addr ret).decode_result(gdref AudioStreamOggVorbis)

proc setPacketSequence*(self: AudioStreamOggVorbis; packetSequence: gdref OggPacketSequence): void =
  expandMethodBind(className AudioStreamOggVorbis, "set_packet_sequence", 438882457)
  methodbind.ptrcall(self, [getPtr packetSequence])

proc getPacketSequence*(self: AudioStreamOggVorbis): gdref OggPacketSequence =
  expandMethodBind(className AudioStreamOggVorbis, "get_packet_sequence", 2801636033)
  var ret: encoded gdref OggPacketSequence
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(gdref OggPacketSequence)

proc setLoop*(self: AudioStreamOggVorbis; enable: bool): void =
  expandMethodBind(className AudioStreamOggVorbis, "set_loop", 2586408642)
  methodbind.ptrcall(self, [getPtr enable])

proc hasLoop*(self: AudioStreamOggVorbis): bool =
  expandMethodBind(className AudioStreamOggVorbis, "has_loop", 36873697)
  var ret: encoded bool
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(bool)

proc setLoopOffset*(self: AudioStreamOggVorbis; seconds: float64): void =
  expandMethodBind(className AudioStreamOggVorbis, "set_loop_offset", 373806689)
  methodbind.ptrcall(self, [getPtr seconds])

proc getLoopOffset*(self: AudioStreamOggVorbis): float64 =
  expandMethodBind(className AudioStreamOggVorbis, "get_loop_offset", 1740695150)
  var ret: encoded float64
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(float64)

proc setBpm*(self: AudioStreamOggVorbis; bpm: float64): void =
  expandMethodBind(className AudioStreamOggVorbis, "set_bpm", 373806689)
  methodbind.ptrcall(self, [getPtr bpm])

proc getBpm*(self: AudioStreamOggVorbis): float64 =
  expandMethodBind(className AudioStreamOggVorbis, "get_bpm", 1740695150)
  var ret: encoded float64
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(float64)

proc setBeatCount*(self: AudioStreamOggVorbis; count: int32): void =
  expandMethodBind(className AudioStreamOggVorbis, "set_beat_count", 1286410249)
  methodbind.ptrcall(self, [getPtr count])

proc getBeatCount*(self: AudioStreamOggVorbis): int32 =
  expandMethodBind(className AudioStreamOggVorbis, "get_beat_count", 3905245786)
  var ret: encoded int32
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(int32)

proc setBarBeats*(self: AudioStreamOggVorbis; count: int32): void =
  expandMethodBind(className AudioStreamOggVorbis, "set_bar_beats", 1286410249)
  methodbind.ptrcall(self, [getPtr count])

proc getBarBeats*(self: AudioStreamOggVorbis): int32 =
  expandMethodBind(className AudioStreamOggVorbis, "get_bar_beats", 3905245786)
  var ret: encoded int32
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(int32)

proc setTags*(self: AudioStreamOggVorbis; tags: Dictionary): void =
  expandMethodBind(className AudioStreamOggVorbis, "set_tags", 4155329257)
  methodbind.ptrcall(self, [getPtr tags])

proc getTags*(self: AudioStreamOggVorbis): Dictionary =
  expandMethodBind(className AudioStreamOggVorbis, "get_tags", 3102165223)
  var ret: encoded Dictionary
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(Dictionary)

template packetSequence*(self: AudioStreamOggVorbis): untyped = self.getPacketSequence()
template `packetSequence=`*(self: AudioStreamOggVorbis; value) = self.setPacketSequence(value)

template bpm*(self: AudioStreamOggVorbis): untyped = self.getBpm()
template `bpm=`*(self: AudioStreamOggVorbis; value) = self.setBpm(value)

template beatCount*(self: AudioStreamOggVorbis): untyped = self.getBeatCount()
template `beatCount=`*(self: AudioStreamOggVorbis; value) = self.setBeatCount(value)

template barBeats*(self: AudioStreamOggVorbis): untyped = self.getBarBeats()
template `barBeats=`*(self: AudioStreamOggVorbis; value) = self.setBarBeats(value)

template tags*(self: AudioStreamOggVorbis): untyped = self.getTags()
template `tags=`*(self: AudioStreamOggVorbis; value) = self.setTags(value)

template loop*(self: AudioStreamOggVorbis): untyped = self.hasLoop()
template `loop=`*(self: AudioStreamOggVorbis; value) = self.setLoop(value)

template loopOffset*(self: AudioStreamOggVorbis): untyped = self.getLoopOffset()
template `loopOffset=`*(self: AudioStreamOggVorbis; value) = self.setLoopOffset(value)
