{.warning[UnusedImport]:off.}

import gdext/coronation/header/classes

import gdobject; export gdobject

expandOnClassImported(Engine, Object)

proc setPhysicsTicksPerSecond*(self: Engine; physicsTicksPerSecond: int32): void =
  expandMethodBind(className Engine, "set_physics_ticks_per_second", 1286410249)
  methodbind.ptrcall(self, [getPtr physicsTicksPerSecond])

proc getPhysicsTicksPerSecond*(self: Engine): int32 =
  expandMethodBind(className Engine, "get_physics_ticks_per_second", 3905245786)
  var ret: encoded int32
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(int32)

proc setMaxPhysicsStepsPerFrame*(self: Engine; maxPhysicsSteps: int32): void =
  expandMethodBind(className Engine, "set_max_physics_steps_per_frame", 1286410249)
  methodbind.ptrcall(self, [getPtr maxPhysicsSteps])

proc getMaxPhysicsStepsPerFrame*(self: Engine): int32 =
  expandMethodBind(className Engine, "get_max_physics_steps_per_frame", 3905245786)
  var ret: encoded int32
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(int32)

proc setPhysicsJitterFix*(self: Engine; physicsJitterFix: float64): void =
  expandMethodBind(className Engine, "set_physics_jitter_fix", 373806689)
  methodbind.ptrcall(self, [getPtr physicsJitterFix])

proc getPhysicsJitterFix*(self: Engine): float64 =
  expandMethodBind(className Engine, "get_physics_jitter_fix", 1740695150)
  var ret: encoded float64
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(float64)

proc getPhysicsInterpolationFraction*(self: Engine): float64 =
  expandMethodBind(className Engine, "get_physics_interpolation_fraction", 1740695150)
  var ret: encoded float64
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(float64)

proc setMaxFps*(self: Engine; maxFps: int32): void =
  expandMethodBind(className Engine, "set_max_fps", 1286410249)
  methodbind.ptrcall(self, [getPtr maxFps])

proc getMaxFps*(self: Engine): int32 =
  expandMethodBind(className Engine, "get_max_fps", 3905245786)
  var ret: encoded int32
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(int32)

proc setTimeScale*(self: Engine; timeScale: float64): void =
  expandMethodBind(className Engine, "set_time_scale", 373806689)
  methodbind.ptrcall(self, [getPtr timeScale])

proc getTimeScale*(self: Engine): float64 =
  expandMethodBind(className Engine, "get_time_scale", 191475506)
  var ret: encoded float64
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(float64)

proc getFramesDrawn*(self: Engine): int32 =
  expandMethodBind(className Engine, "get_frames_drawn", 2455072627)
  var ret: encoded int32
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(int32)

proc getFramesPerSecond*(self: Engine): float64 =
  expandMethodBind(className Engine, "get_frames_per_second", 1740695150)
  var ret: encoded float64
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(float64)

proc getPhysicsFrames*(self: Engine): uint64 =
  expandMethodBind(className Engine, "get_physics_frames", 3905245786)
  var ret: encoded uint64
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(uint64)

proc getProcessFrames*(self: Engine): uint64 =
  expandMethodBind(className Engine, "get_process_frames", 3905245786)
  var ret: encoded uint64
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(uint64)

proc getMainLoop*(self: Engine): MainLoop =
  expandMethodBind(className Engine, "get_main_loop", 1016888095)
  var ret: encoded MainLoop
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(MainLoop)

proc getVersionInfo*(self: Engine): Dictionary =
  expandMethodBind(className Engine, "get_version_info", 3102165223)
  var ret: encoded Dictionary
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(Dictionary)

proc getAuthorInfo*(self: Engine): Dictionary =
  expandMethodBind(className Engine, "get_author_info", 3102165223)
  var ret: encoded Dictionary
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(Dictionary)

proc getCopyrightInfo*(self: Engine): TypedArray[Dictionary] =
  expandMethodBind(className Engine, "get_copyright_info", 3995934104)
  var ret: encoded TypedArray[Dictionary]
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(TypedArray[Dictionary])

proc getDonorInfo*(self: Engine): Dictionary =
  expandMethodBind(className Engine, "get_donor_info", 3102165223)
  var ret: encoded Dictionary
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(Dictionary)

proc getLicenseInfo*(self: Engine): Dictionary =
  expandMethodBind(className Engine, "get_license_info", 3102165223)
  var ret: encoded Dictionary
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(Dictionary)

proc getLicenseText*(self: Engine): String =
  expandMethodBind(className Engine, "get_license_text", 201670096)
  var ret: encoded String
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(String)

proc getArchitectureName*(self: Engine): String =
  expandMethodBind(className Engine, "get_architecture_name", 201670096)
  var ret: encoded String
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(String)

proc isInPhysicsFrame*(self: Engine): bool =
  expandMethodBind(className Engine, "is_in_physics_frame", 36873697)
  var ret: encoded bool
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(bool)

proc hasSingleton*(self: Engine; name: StringName): bool =
  expandMethodBind(className Engine, "has_singleton", 2619796661)
  var ret: encoded bool
  methodbind.ptrcall(self, [getPtr name], addr ret)
  (addr ret).decode_result(bool)

proc getSingleton*(self: Engine; name: StringName): Object =
  expandMethodBind(className Engine, "get_singleton", 1371597918)
  var ret: encoded Object
  methodbind.ptrcall(self, [getPtr name], addr ret)
  (addr ret).decode_result(Object)

proc registerSingleton*(self: Engine; name: StringName; instance: Object): void =
  expandMethodBind(className Engine, "register_singleton", 965313290)
  methodbind.ptrcall(self, [getPtr name, getPtr instance])

proc unregisterSingleton*(self: Engine; name: StringName): void =
  expandMethodBind(className Engine, "unregister_singleton", 3304788590)
  methodbind.ptrcall(self, [getPtr name])

proc getSingletonList*(self: Engine): PackedStringArray =
  expandMethodBind(className Engine, "get_singleton_list", 1139954409)
  var ret: encoded PackedStringArray
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(PackedStringArray)

proc registerScriptLanguage*(self: Engine; language: ScriptLanguage): Error =
  expandMethodBind(className Engine, "register_script_language", 1850254898)
  var ret: encoded Error
  methodbind.ptrcall(self, [getPtr language], addr ret)
  (addr ret).decode_result(Error)

proc unregisterScriptLanguage*(self: Engine; language: ScriptLanguage): Error =
  expandMethodBind(className Engine, "unregister_script_language", 1850254898)
  var ret: encoded Error
  methodbind.ptrcall(self, [getPtr language], addr ret)
  (addr ret).decode_result(Error)

proc getScriptLanguageCount*(self: Engine): int32 =
  expandMethodBind(className Engine, "get_script_language_count", 2455072627)
  var ret: encoded int32
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(int32)

proc getScriptLanguage*(self: Engine; index: int32): ScriptLanguage =
  expandMethodBind(className Engine, "get_script_language", 2151255799)
  var ret: encoded ScriptLanguage
  methodbind.ptrcall(self, [getPtr index], addr ret)
  (addr ret).decode_result(ScriptLanguage)

proc captureScriptBacktraces*(self: Engine; includeVariables: bool = false): TypedArray[gdref ScriptBacktrace] =
  expandMethodBind(className Engine, "capture_script_backtraces", 873284517)
  var ret: encoded TypedArray[gdref ScriptBacktrace]
  methodbind.ptrcall(self, [getPtr includeVariables], addr ret)
  (addr ret).decode_result(TypedArray[gdref ScriptBacktrace])

proc isEditorHint*(self: Engine): bool =
  expandMethodBind(className Engine, "is_editor_hint", 36873697)
  var ret: encoded bool
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(bool)

proc isEmbeddedInEditor*(self: Engine): bool =
  expandMethodBind(className Engine, "is_embedded_in_editor", 36873697)
  var ret: encoded bool
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(bool)

proc getWriteMoviePath*(self: Engine): String =
  expandMethodBind(className Engine, "get_write_movie_path", 201670096)
  var ret: encoded String
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(String)

proc setPrintToStdout*(self: Engine; enabled: bool): void =
  expandMethodBind(className Engine, "set_print_to_stdout", 2586408642)
  methodbind.ptrcall(self, [getPtr enabled])

proc isPrintingToStdout*(self: Engine): bool =
  expandMethodBind(className Engine, "is_printing_to_stdout", 36873697)
  var ret: encoded bool
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(bool)

proc setPrintErrorMessages*(self: Engine; enabled: bool): void =
  expandMethodBind(className Engine, "set_print_error_messages", 2586408642)
  methodbind.ptrcall(self, [getPtr enabled])

proc isPrintingErrorMessages*(self: Engine): bool =
  expandMethodBind(className Engine, "is_printing_error_messages", 36873697)
  var ret: encoded bool
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(bool)

template printErrorMessages*(self: Engine): untyped = self.isPrintingErrorMessages()
template `printErrorMessages=`*(self: Engine; value) = self.setPrintErrorMessages(value)

template printToStdout*(self: Engine): untyped = self.isPrintingToStdout()
template `printToStdout=`*(self: Engine; value) = self.setPrintToStdout(value)

template physicsTicksPerSecond*(self: Engine): untyped = self.getPhysicsTicksPerSecond()
template `physicsTicksPerSecond=`*(self: Engine; value) = self.setPhysicsTicksPerSecond(value)

template maxPhysicsStepsPerFrame*(self: Engine): untyped = self.getMaxPhysicsStepsPerFrame()
template `maxPhysicsStepsPerFrame=`*(self: Engine; value) = self.setMaxPhysicsStepsPerFrame(value)

template maxFps*(self: Engine): untyped = self.getMaxFps()
template `maxFps=`*(self: Engine; value) = self.setMaxFps(value)

template timeScale*(self: Engine): untyped = self.getTimeScale()
template `timeScale=`*(self: Engine; value) = self.setTimeScale(value)

template physicsJitterFix*(self: Engine): untyped = self.getPhysicsJitterFix()
template `physicsJitterFix=`*(self: Engine; value) = self.setPhysicsJitterFix(value)
