{.warning[UnusedImport]:off.}

import gdext/coronation/header/classes

import gdtexture2d; export gdtexture2d

expandOnClassImported(GradientTexture1D, Texture2D)

proc setGradient*(self: GradientTexture1D; gradient: gdref Gradient): void =
  expandMethodBind(className GradientTexture1D, "set_gradient", 2756054477)
  methodbind.ptrcall(self, [getPtr gradient])

proc getGradient*(self: GradientTexture1D): gdref Gradient =
  expandMethodBind(className GradientTexture1D, "get_gradient", 132272999)
  var ret: encoded gdref Gradient
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(gdref Gradient)

proc setWidth*(self: GradientTexture1D; width: int32): void =
  expandMethodBind(className GradientTexture1D, "set_width", 1286410249)
  methodbind.ptrcall(self, [getPtr width])

proc setUseHdr*(self: GradientTexture1D; enabled: bool): void =
  expandMethodBind(className GradientTexture1D, "set_use_hdr", 2586408642)
  methodbind.ptrcall(self, [getPtr enabled])

proc isUsingHdr*(self: GradientTexture1D): bool =
  expandMethodBind(className GradientTexture1D, "is_using_hdr", 36873697)
  var ret: encoded bool
  methodbind.ptrcall(self, [], addr ret)
  (addr ret).decode_result(bool)

template gradient*(self: GradientTexture1D): untyped = self.getGradient()
template `gradient=`*(self: GradientTexture1D; value) = self.setGradient(value)

template width*(self: GradientTexture1D): untyped = self.getWidth()
template `width=`*(self: GradientTexture1D; value) = self.setWidth(value)

template useHdr*(self: GradientTexture1D): untyped = self.isUsingHdr()
template `useHdr=`*(self: GradientTexture1D; value) = self.setUseHdr(value)
