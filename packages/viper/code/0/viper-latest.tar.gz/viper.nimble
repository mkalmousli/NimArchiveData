# Package

version       = "0.1.0"
author        = "Navid M"
description   = "Fluent SQL generation"
license       = "GPL-3.0-or-later"
srcDir        = "src"


# Dependencies

requires "nim >= 2.2.2"
