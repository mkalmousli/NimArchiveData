import unittest, tables, strutils, viper

suite "SqlValue Tests":
    test "String to SqlValue conversion":
        let val = toSqlValue("test")
        check val.kind == svkText
        check val.strVal == "test"
        check $val == "'test'"

    test "Integer to SqlValue conversion":
        let val = toSqlValue(42)
        check val.kind == svkInteger
        check val.intVal == 42
        check $val == "42"

    test "Float to SqlValue conversion":
        let val = toSqlValue(3.14)
        check val.kind == svkReal
        check val.realVal == 3.14
        check $val == "3.14"

    test "Null to SqlValue conversion":
        let val = toSqlValue(nil)
        check val.kind == svkNull
        check $val == "NULL"

    test "SqlValue escaping for strings with single quotes":
        let val = toSqlValue("O'Reilly")
        check $val == "'O''Reilly'"

suite "CREATE TABLE Tests":
    test "Basic table creation":
        let cols = {"id": "INTEGER PRIMARY KEY", "name": "TEXT",
                "age": "INTEGER"}.toTable
        let query = createTable("Person", cols)
        check query.contains("CREATE TABLE Person")
        check query.contains("id INTEGER PRIMARY KEY")
        check query.contains("name TEXT")
        check query.contains("age INTEGER")

    test "Table creation with IF NOT EXISTS":
        let cols = {"name": "TEXT"}.toTable
        let query = createTable("Person", cols, ifNotExists = true)
        check query.contains("CREATE TABLE IF NOT EXISTS Person")

suite "INSERT Tests":
    test "Basic insert":
        let query = insertIntoTable("Person", @["name", "age"], @["John Doe", $47])
        check query.contains("INSERT INTO")
        check query.contains("Person(name, age)")
        check query.contains("VALUES")
        check query.contains("('John Doe', 47)")

    test "Insert with different types":
        let query = insertIntoTable("TestTable", @["text_col", "int_col", "float_col", "null_col"],
                                   @["text", "42", "3.14", "nil"])
        check query.contains("TestTable(text_col, int_col, float_col, null_col)")
        check query.contains("('text', 42, 3.14, NULL)")

    test "Multiple row insert":
        let values = @[
          @["John", $25],
          @["Jane", $30],
          @["Bob", $45]
        ]
        let query = insertMultipleIntoTable("Person", @["name", "age"], values)
        check query.contains("INSERT INTO")
        check query.contains("Person(name, age)")
        check query.contains("VALUES")
        check query.contains("('John', 25)")
        check query.contains("('Jane', 30)")
        check query.contains("('Bob', 45)")

suite "SELECT Tests":
    test "Basic select all":
        let query = selectFrom("Person")
        check query == "SELECT *\nFROM Person;"

    test "Select with specific columns":
        let query = selectFrom("Person", @["name", "age"])
        check query == "SELECT name, age\nFROM Person;"

    test "Select with WHERE clause":
        let query = selectFrom("Person", @["name"], where = "age > 30")
        check query.contains("WHERE age > 30")

    test "Select with ORDER BY":
        let query = selectFrom("Person", orderBy = "age DESC")
        check query.contains("ORDER BY age DESC")

    test "Select with LIMIT":
        let query = selectFrom("Person", limit = 10)
        check query.contains("LIMIT 10")

    test "Complex select":
        let query = selectFrom("Person", @["name", "age"],
                              where = "age > 18",
                              orderBy = "name ASC",
                              limit = 5)
        check query.contains("SELECT name, age")
        check query.contains("FROM Person")
        check query.contains("WHERE age > 18")
        check query.contains("ORDER BY name ASC")
        check query.contains("LIMIT 5")

suite "UPDATE Tests":
    test "Basic update":
        let query = updateTable("Person", @["age"], @[50],
                where = "name = 'John'")
        check query.contains("UPDATE Person")
        check query.contains("SET")
        check query.contains("age = 50")
        check query.contains("WHERE name = 'John'")

    test "Update multiple columns":
        let query = updateTable("Person", @["name", "age"], @["Jane Doe", $35])
        check query.contains("name = 'Jane Doe'")
        check query.contains("age = 35")

suite "DELETE Tests":
    test "Delete all":
        let query = deleteFrom("Person")
        check query == "DELETE FROM Person;"

    test "Delete with WHERE clause":
        let query = deleteFrom("Person", where = "age < 18")
        check query.contains("DELETE FROM Person")
        check query.contains("WHERE age < 18")

suite "Schema Modification Tests":
    test "Add column":
        let query = addColumn("Person", "email", "TEXT NOT NULL")
        check query == "ALTER TABLE Person\nADD COLUMN email TEXT NOT NULL;"

    test "Drop table":
        let query = dropTable("Person")
        check query == "DROP TABLE Person;"

suite "Transaction Tests":
    test "Transaction wrapping":
        let queries = @[
          "INSERT INTO Person(name) VALUES ('John');",
          "UPDATE Person SET age = 30 WHERE name = 'John';"
        ]
        let txn = transaction(queries)
        check txn.startsWith("BEGIN TRANSACTION;")
        check txn.endsWith("COMMIT;")
        check txn.contains("INSERT INTO Person")
        check txn.contains("UPDATE Person")

suite "Foreign Key Tests":
    test "Basic foreign key":
        let fk = foreignKey("department_id", "Department", "id")
        check fk.contains("FOREIGN KEY (department_id)")
        check fk.contains("REFERENCES Department(id)")

    test "Foreign key with ON DELETE":
        let fk = foreignKey("department_id", "Department", "id",
                onDelete = "CASCADE")
        check fk.contains("ON DELETE CASCADE")

    test "Foreign key with ON UPDATE":
        let fk = foreignKey("department_id", "Department", "id",
                onUpdate = "SET NULL")
        check fk.contains("ON UPDATE SET NULL")

suite "Integration Tests":
    test "Create table with foreign key":
        var cols = {"id": "INTEGER PRIMARY KEY", "name": "TEXT",
                "dept_id": "INTEGER"}.toTable
        let createTable = createTable("Employee", cols)
        let fk = foreignKey("dept_id", "Department", "id", onDelete = "CASCADE")
        check createTable.contains("id INTEGER PRIMARY KEY")
        check fk.contains("FOREIGN KEY (dept_id)")

    test "Complex scenario - database setup":
        # Create department table
        let deptCols = {"id": "INTEGER PRIMARY KEY",
                "name": "TEXT NOT NULL"}.toTable
        let createDept = createTable("Department", deptCols)

        # Create employee table with foreign key
        let empCols = {
          "id": "INTEGER PRIMARY KEY",
          "name": "TEXT NOT NULL",
          "email": "TEXT",
          "dept_id": "INTEGER",
          "constraint_fk": foreignKey("dept_id", "Department", "id",
                  onDelete = "CASCADE")
        }.toTable
        let createEmp = createTable("Employee", empCols)

        # Insert department
        let insertDept = insertIntoTable("Department", @["id", "name"], @[$1,
                "Engineering"])

        # Insert employees
        let employees = @[
          @[$1, "John Doe", "john@example.com", $1],
          @[$2, "Jane Smith", "jane@example.com", $1]
        ]
        let insertEmps = insertMultipleIntoTable("Employee",
                                               @["id", "name", "email",
                                                       "dept_id"],
                                               employees)

        # Transaction
        let setup = transaction(@[createDept, createEmp, insertDept, insertEmps])

        check setup.contains("BEGIN TRANSACTION;")
        check setup.contains("Department")
        check setup.contains("Employee")
        check setup.contains("FOREIGN KEY")
        check setup.contains("Engineering")
        check setup.contains("john@example.com")
        check setup.contains("COMMIT;")

