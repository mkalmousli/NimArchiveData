import std/[
    tables,
    strutils,
    json,
    sequtils,
    options
]


type
    SqlValueKind* = enum
        svkText, svkInteger, svkReal, svkBlob, svkNull

    SqlValue* = object
        case kind*: SqlValueKind
        of svkText: strVal*: string
        of svkInteger: intVal*: int
        of svkReal: realVal*: float
        of svkBlob: blobVal*: seq[byte]
        of svkNull: nil


proc `$`*(val: SqlValue): string =
    case val.kind
    of svkText: return "'" & val.strVal.replace("'", "''") & "'"
    of svkInteger: return $val.intVal
    of svkReal: return $val.realVal
    of svkBlob: return "X'" & val.blobVal.mapIt(it.toHex(2)).join("") & "'"
    of svkNull: return "NULL"


proc toSqlValue*(s: string): SqlValue =
    SqlValue(kind: svkText, strVal: s)

proc toSqlValue*(i: int): SqlValue =
    SqlValue(kind: svkInteger, intVal: i)

proc toSqlValue*(f: float): SqlValue =
    SqlValue(kind: svkReal, realVal: f)

proc toSqlValue*(b: seq[byte]): SqlValue =
    SqlValue(kind: svkBlob, blobVal: b)

proc toSqlValue*(n: type(nil)): SqlValue =
    SqlValue(kind: svkNull)


proc toSqlValue*(j: JsonNode): SqlValue =
    case j.kind
    of JString: return toSqlValue(j.getStr)
    of JInt: return toSqlValue(j.getInt)
    of JFloat: return toSqlValue(j.getFloat)
    of JNull: return toSqlValue(nil)
    else: return toSqlValue($j)


proc toSqlValue*[T](val: T): SqlValue =
    ## Overarching function to auto-convert values to SqlValue

    when T is string:
        return toSqlValue(val)
    elif T is int:
        return toSqlValue(val)
    elif T is float:
        return toSqlValue(val)
    elif T is seq[byte]:
        return toSqlValue(val)
    elif T is JsonNode:
        return toSqlValue(val)
    else:
        return toSqlValue($val)


proc createTable*(
    name: string,
    columns: Table[string, string],
    ifNotExists: bool = false
): string =
    var query = "CREATE TABLE "
    if ifNotExists:
        query &= "IF NOT EXISTS "

    query &= name & "(\n"
    var columnDefs: seq[string] = @[]
    for colName, colType in columns:
        columnDefs.add("    " & colName & " " & colType)

    query &= columnDefs.join(",\n")
    query &= "\n);"
    return query


proc parseNumberOrNull(s: string): Option[int] =
    for c in s:
        if not (c in {'0'..'9'}):
            return none(int)

    if s.len == 0:
        return none(int)

    try:
        let num = parseInt(s)
        return some(num)

    except ValueError:
        return none(int)

proc parseFloatOrNull(s: string): Option[float] =
    for c in s:
        if not (c in {'0'..'9'}) and c != '.':
            return none(float)

    if s.len == 0:
        return none(float)

    try:
        let num = parseFloat(s)
        return some(num)

    except ValueError:
        return none(float)

proc insertIntoTable*(
    tableName: string,
    columns: seq[string],
    values: openArray[auto]
): string =
    if columns.len != values.len:
        raise newException(ValueError, "Number of columns must match number of values")

    var sqlValues = newSeq[SqlValue](values.len)
    for i, val in values:
        sqlValues[i] = toSqlValue(val)

    var query = "INSERT INTO\n    " & tableName
    query &= "(" & columns.join(", ") & ")"
    query &= "\nVALUES\n    "

    var valuesSql = "("
    for i, val in sqlValues:
        if i > 0:
            valuesSql &= ", "
        if parseFloatOrNull(val.strVal.replace("'", "")) != none(float):
            valuesSql &= ($val).replace("'", "")
            continue
        if parseNumberOrNull(val.strVal) != none(int):
            valuesSql &= ($val).replace("'", "")
            continue
        let cleansed = val.strVal.replace("'", "").strip().toLower()
        if cleansed == "nil" or cleansed == "null":
            valuesSql &= "NULL"
            continue

        valuesSql &= $val

    valuesSql &= ")"
    query &= valuesSql & ";"

    return query


proc insertMultipleIntoTable*(
    tableName: string,
    columns: seq[string],
    valuesList: seq[seq[auto]]
): string =
    if valuesList.len == 0:
        raise newException(ValueError, "No values provided for insertion")

    var query = "INSERT INTO\n    " & tableName

    query &= "(" & columns.join(", ") & ")"
    query &= "\nVALUES\n"

    var allRows: seq[string] = @[]

    for row in valuesList:
        if row.len != columns.len:
            raise newException(ValueError, "Number of columns must match number of values in each row")

        var sqlValues = newSeq[SqlValue](row.len)
        for i, val in row:
            sqlValues[i] = toSqlValue(val)

        var rowValues = "    ("
        for i, val in sqlValues:
            if i > 0:
                rowValues &= ", "
            let normVal = ($val).replace("'", "")
            if parseFloatOrNull(normVal) != none(float) or parseNumberOrNull(
                    normVal) != none(int):
                rowValues &= (normVal).replace("'", "")
            else:
                rowValues &= $val
        rowValues &= ")"

        allRows.add(rowValues)

    query &= allRows.join(",\n") & ";"

    return query


proc selectFrom*(
    tableName: string,
    columns: seq[string] = @["*"],
    where: string = "",
    orderBy: string = "",
    limit: int = 0
): string =
    var query = "SELECT " & columns.join(", ") & "\nFROM " & tableName

    if where.len > 0:
        query &= "\nWHERE " & where

    if orderBy.len > 0:
        query &= "\nORDER BY " & orderBy

    if limit > 0:
        query &= "\nLIMIT " & $limit

    query &= ";"
    return query


proc updateTable*(
    tableName: string,
    columns: seq[string],
    values: openArray[auto],
    where: string = ""
): string =
    if columns.len != values.len:
        raise newException(ValueError, "Number of columns must match number of values")

    var sqlValues = newSeq[SqlValue](values.len)
    for i, val in values:
        sqlValues[i] = toSqlValue(val)

    var query = "UPDATE " & tableName & "\nSET\n"
    var setPairs = newSeq[string](columns.len)

    for i in 0..<columns.len:
        var toadd = $sqlValues[i]
        if parseNumberOrNull(toadd.replace("'", "")) != none(int):
            toadd = toadd.replace("'", "")
        setPairs[i] = columns[i] & " = " & toadd

    query &= setPairs.join(",\n")

    if where.len > 0:
        query &= "\nWHERE " & where

    query &= ";"
    return query


proc deleteFrom*(tableName: string, where: string = ""): string =
    var query = "DELETE FROM " & tableName

    if where.len > 0:
        query &= "\nWHERE " & where

    query &= ";"
    return query


proc addColumn*(
    tableName: string,
    columnName: string,
    columnType: string
): string =
    return "ALTER TABLE " & tableName & "\nADD COLUMN " & columnName & " " &
           columnType & ";"


proc dropTable*(tableName: string): string =
    return "DROP TABLE " & tableName & ";"


proc transaction*(queries: seq[string]): string =
    return "BEGIN TRANSACTION;\n\n" & queries.join("\n\n") & "\n\nCOMMIT;"


proc foreignKey*(
    column: string,
    refTable: string,
    refColumn: string,
    onDelete: string = "",
    onUpdate: string = ""
): string =
    var constraint = "FOREIGN KEY (" & column & ") REFERENCES " & refTable &
            "(" & refColumn & ")"

    if onDelete.len > 0:
        constraint &= " ON DELETE " & onDelete

    if onUpdate.len > 0:
        constraint &= " ON UPDATE " & onUpdate

    return constraint
