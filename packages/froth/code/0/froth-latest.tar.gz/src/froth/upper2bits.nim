import ./common

type
  Upper2BitsImpl* = range[0..3]
  Upper2Bits* = distinct Upper2BitsImpl
    ## shifts pointer 2 bits to the right, shifts 2 bit tag 62 bits to the left

const remainingBits = sizeof(int) * 8 - 2

template withTagInline*(val: uint, tag: Upper2Bits): Tagged[uint, Upper2Bits] =
  rawTagged[uint, Upper2Bits]((val shr 2) or (tag.uint shl remainingBits))

template untagInline*(tagged: Tagged[uint, Upper2Bits]): uint =
  tagged.raw shl 2

template splitTagInline*(tagged: Tagged[uint, Upper2Bits]): Upper2Bits =
  Upper2Bits(tagged.raw shr remainingBits)

proc withTag*(val: uint, tag: Upper2Bits): Tagged[uint, Upper2Bits] {.inline.} = withTagInline(val, tag)
proc untag*(tagged: Tagged[uint, Upper2Bits]): uint {.inline.} = untagInline(tagged)
proc splitTag*(tagged: Tagged[uint, Upper2Bits]): Upper2Bits {.inline.} = splitTagInline(tagged)

implUintPointerTags(Upper2Bits)

type Upper2BitsTagged*[T] = Tagged[T, Upper2Bits]

proc tagUpper2Bits*[T](val: T, tag: Upper2BitsImpl): Upper2BitsTagged[T] {.inline.} =
  withTag(val, Upper2Bits(tag))

template getTag*[T](tagged: Upper2BitsTagged[T]): Upper2BitsImpl =
  Upper2BitsImpl(splitTag(tagged))
