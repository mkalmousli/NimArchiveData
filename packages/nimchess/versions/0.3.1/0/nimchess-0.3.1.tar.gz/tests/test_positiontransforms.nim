import unittest
import nimchess/[position, strchess, types]
import testdata/examplefens

suite "Position Transform Tests":
  template rotate(position: Position): Position =
    position.mirrorHorizontally.mirrorVertically()

  test "Identity transforms":
    for fen in someFens:
      let position = fen.toPosition(suppressWarnings = true)

      # Test double rotation (180 degrees twice = identity)
      let doubleRotated = position.rotate.rotate
      check position == doubleRotated

      # Test quadruple mirror operations
      let quadMirrored = position.mirrorHorizontally
        .mirrorVertically(swapColors = false).mirrorHorizontally
        .mirrorVertically(swapColors = false)
      check position == quadMirrored

  test "Complex transform combinations":
    for fen in someFens:
      let position = fen.toPosition(suppressWarnings = true)

      # Test rotate + mirror combinations that should return to original
      let transformed1 = position.rotate.mirrorVertically.rotate.mirrorVertically
      check position == transformed1

      # Test complex sequence that should be identity
      let transformed2 = position.mirrorVertically.mirrorHorizontally.rotate
        .mirrorVertically(swapColors = false).rotate.mirrorVertically
        .mirrorVertically(swapColors = false).mirrorHorizontally
      check position == transformed2

  test "Single transforms produce valid positions":
    for fen in someFens:
      let position = fen.toPosition(suppressWarnings = true)

      # Test vertical mirror
      let vertMirrored = position.mirrorVertically
      let vertMirroredFen = vertMirrored.fen(alwaysShowEnPassantSquare = true)

      # echo vertMirroredFen.toPosition.debugString
      # echo vertMirrored.debugString

      # assert false

      check vertMirroredFen.toPosition(suppressWarnings = true) == vertMirrored

      assert vertMirroredFen.toPosition(suppressWarnings = true) == vertMirrored

      # Test horizontal mirror
      let horizMirrored = position.mirrorHorizontally
      let horizMirroredFen = horizMirrored.fen(alwaysShowEnPassantSquare = true)
      check horizMirroredFen.toPosition(suppressWarnings = true) == horizMirrored

      # Test rotation
      let rotated = position.rotate
      let rotatedFen = rotated.fen(alwaysShowEnPassantSquare = true)
      check rotatedFen.toPosition(suppressWarnings = true) == rotated

  test "Transform properties":
    for fen in someFens:
      let position = fen.toPosition(suppressWarnings = true)

      # Test that horizontal mirror is its own inverse
      check position == position.mirrorHorizontally.mirrorHorizontally

      # Test that vertical mirror is its own inverse
      check position == position.mirrorVertically.mirrorVertically

  test "Color swapping in vertical mirror":
    let testFen = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"
    let position = testFen.toPosition

    # Test with color swapping (default)
    let mirrored = position.mirrorVertically(swapColors = true)
    check mirrored.us != position.us

    # Test without color swapping
    let mirroredNoSwap = position.mirrorVertically(swapColors = false)
    check mirroredNoSwap.us == position.us
