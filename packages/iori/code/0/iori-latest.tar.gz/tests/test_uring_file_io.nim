## Tests for uring_file_io: High-level file I/O API.

import std/[unittest, os, posix, importutils, monotimes, times]

import ../iori/uring_file_io
import ../iori/uring_raw

privateAccess(UringFileIO)

suite "uring_file_io":
  var io {.threadvar.}: UringFileIO

  setup:
    io = newUringFileIO(256)

  teardown:
    io.close()

  test "writeFile and readFile roundtrip":
    let path = getTempDir() / "iori_test_roundtrip.bin"
    defer:
      removeFile(path)

    let data = @[byte 1, 2, 3, 4, 5, 0xDE, 0xAD, 0xBE, 0xEF]

    proc run() {.async.} =
      {.cast(gcsafe).}:
        await io.writeFile(path, data)
        let readResult = await io.readFile(path)
        doAssert readResult == data

    waitFor run()

  test "writeFileString and readFileString roundtrip":
    let path = getTempDir() / "iori_test_roundtrip.txt"
    defer:
      removeFile(path)

    let content = "Hello, io_uring!\nLine 2\n"

    proc run() {.async.} =
      {.cast(gcsafe).}:
        await io.writeFileString(path, content)
        let readResult = await io.readFileString(path)
        doAssert readResult == content

    waitFor run()

  test "readFile on nonexistent file raises IOError":
    proc run() {.async.} =
      {.cast(gcsafe).}:
        var raised = false
        try:
          discard await io.readFile("/tmp/iori_nonexistent_" & $getpid())
        except IOError:
          raised = true
        doAssert raised

    waitFor run()

  test "large data roundtrip":
    let path = getTempDir() / "iori_test_large.bin"
    defer:
      removeFile(path)

    var data = newSeq[byte](65536)
    for i in 0 ..< data.len:
      data[i] = byte(i mod 256)

    proc run() {.async.} =
      {.cast(gcsafe).}:
        await io.writeFile(path, data)
        let readResult = await io.readFile(path)
        doAssert readResult.len == data.len
        doAssert readResult == data

    waitFor run()

  test "empty data writeFile and readFile":
    let path = getTempDir() / "iori_test_empty.bin"
    defer:
      removeFile(path)

    proc run() {.async.} =
      {.cast(gcsafe).}:
        await io.writeFile(path, @[])
        let readResult = await io.readFile(path)
        doAssert readResult.len == 0

    waitFor run()

  test "empty string writeFileString and readFileString":
    let path = getTempDir() / "iori_test_empty.txt"
    defer:
      removeFile(path)

    proc run() {.async.} =
      {.cast(gcsafe).}:
        await io.writeFileString(path, "")
        let readResult = await io.readFileString(path)
        doAssert readResult.len == 0

    waitFor run()

  test "writeFile overwrites existing file":
    let path = getTempDir() / "iori_test_overwrite.bin"
    defer:
      removeFile(path)

    proc run() {.async.} =
      {.cast(gcsafe).}:
        await io.writeFile(path, @[byte 1, 2, 3, 4, 5])
        await io.writeFile(path, @[byte 10, 20])
        let readBack = await io.readFile(path)
        doAssert readBack == @[byte 10, 20]

    waitFor run()

  test "concurrent read and write operations":
    let pathA = getTempDir() / "iori_test_concurrent_a.bin"
    let pathB = getTempDir() / "iori_test_concurrent_b.bin"
    defer:
      removeFile(pathA)
      removeFile(pathB)

    let dataA = @[byte 0xAA, 0xBB, 0xCC]
    let dataB = @[byte 0x11, 0x22, 0x33, 0x44]

    proc run() {.async.} =
      {.cast(gcsafe).}:
        # Write both files concurrently
        let futA = io.writeFile(pathA, dataA)
        let futB = io.writeFile(pathB, dataB)
        await futA
        await futB

        # Read both files concurrently
        let futReadA = io.readFile(pathA)
        let futReadB = io.readFile(pathB)
        let resultA = await futReadA
        let resultB = await futReadB

        doAssert resultA == dataA
        doAssert resultB == dataB

    waitFor run()

  test "writeFile to read-only path raises IOError":
    proc run() {.async.} =
      {.cast(gcsafe).}:
        var raised = false
        try:
          await io.writeFile("/proc/nonexistent_iori_test", @[byte 1])
        except IOError:
          raised = true
        doAssert raised

    waitFor run()

  test "writeFile with fsync=false skips fsync":
    let path = getTempDir() / "iori_test_no_fsync.bin"
    defer:
      removeFile(path)

    let data = @[byte 1, 2, 3, 4, 5]

    proc run() {.async.} =
      {.cast(gcsafe).}:
        await io.writeFile(path, data, fsync = false)
        let readResult = await io.readFile(path)
        doAssert readResult == data

    waitFor run()

  test "writeFileString with fsync=false skips fsync":
    let path = getTempDir() / "iori_test_no_fsync.txt"
    defer:
      removeFile(path)

    proc run() {.async.} =
      {.cast(gcsafe).}:
        await io.writeFileString(path, "no fsync test", fsync = false)
        let readResult = await io.readFileString(path)
        doAssert readResult == "no fsync test"

    waitFor run()

  test "full lifecycle inside async proc":
    ## Regression: newUringFileIO() must be callable from async procs.
    ## Without proper {.raises.} annotations, Chronos rejects sync calls
    ## that the compiler treats as raising Exception.
    proc run() {.async.} =
      {.cast(gcsafe).}:
        let io2 = newUringFileIO()
        let path = getTempDir() / "iori_test_async_lifecycle.txt"
        defer:
          removeFile(path)

        await io2.writeFileString(path, "async lifecycle test")
        let content = await io2.readFileString(path)
        doAssert content == "async lifecycle test"
        io2.close()

    waitFor run()

  test "close during pending operations does not crash":
    ## Exercises the processCqes closed-safety guard.
    ## Submit multiple operations, then close before completions arrive.
    var io2 = newUringFileIO(32)
    let path = getTempDir() / "iori_test_close_pending.bin"
    defer:
      removeFile(path)

    proc run() {.async.} =
      {.cast(gcsafe).}:
        # Write a file first so we can read it
        await io2.writeFile(path, @[byte 1, 2, 3, 4])

        # Start multiple reads concurrently
        var futs: seq[Future[seq[byte]]]
        for i in 0 ..< 4:
          futs.add(io2.readFile(path))

        # Close while operations are in flight
        io2.close()

        # All futures should either complete or fail with IOError
        for fut in futs:
          try:
            discard await fut
          except IOError:
            discard

    waitFor run()

  test "CancelledError is distinct from IOError":
    proc run() {.async.} =
      {.cast(gcsafe).}:
        # CancelledError must not be caught by except IOError
        var caughtCancel = false
        var caughtIO = false
        try:
          raise (ref CancelledError)(msg: "test")
        except IOError:
          caughtIO = true
        except CancelledError:
          caughtCancel = true
        doAssert caughtCancel
        doAssert not caughtIO

    waitFor run()

  test "submit failure in readFile raises IOError not CancelledError":
    var io2 = newUringFileIO(32)
    defer:
      io2.close()

    proc run() {.async.} =
      {.cast(gcsafe).}:
        let path = getTempDir() / "iori_test_cancel_read.txt"
        defer:
          removeFile(path)

        # Create file so path exists
        let fd = posix.open(path.cstring, O_WRONLY or O_CREAT or O_TRUNC, 0o644)
        doAssert fd >= 0
        discard posix.close(fd)

        # Queue readFile — it starts with statx, which becomes unsubmitted
        let readFileFut = io2.readFile(path)

        # Sabotage ring fd to force submit failure, then flush
        let savedFd = io2.ring.ringFd
        io2.ring.ringFd = -1
        io2.flush()
        io2.ring.ringFd = savedFd

        # Submit failure is IOError, not CancelledError
        var caughtIO = false
        try:
          discard await readFileFut
        except CancelledError:
          doAssert false, "should not be CancelledError"
        except IOError:
          caughtIO = true
        doAssert caughtIO

    waitFor run()

  test "readFile with timeout succeeds for normal file":
    let path = getTempDir() / "iori_test_timeout_read.bin"
    defer:
      removeFile(path)

    let data = @[byte 1, 2, 3, 4, 5]

    proc run() {.async.} =
      {.cast(gcsafe).}:
        await io.writeFile(path, data)
        let r = await io.readFile(path, timeoutMs = 5000)
        doAssert r == data

    waitFor run()

  test "writeFile with timeout succeeds for normal file":
    let path = getTempDir() / "iori_test_timeout_write.bin"
    defer:
      removeFile(path)

    let data = @[byte 10, 20, 30]

    proc run() {.async.} =
      {.cast(gcsafe).}:
        await io.writeFile(path, data, timeoutMs = 5000)
        let r = await io.readFile(path)
        doAssert r == data

    waitFor run()

  test "readFileString with timeout succeeds":
    let path = getTempDir() / "iori_test_timeout_readstr.txt"
    defer:
      removeFile(path)

    proc run() {.async.} =
      {.cast(gcsafe).}:
        await io.writeFileString(path, "timeout test")
        let r = await io.readFileString(path, timeoutMs = 5000)
        doAssert r == "timeout test"

    waitFor run()

  test "writeFileString with timeout succeeds":
    let path = getTempDir() / "iori_test_timeout_writestr.txt"
    defer:
      removeFile(path)

    proc run() {.async.} =
      {.cast(gcsafe).}:
        await io.writeFileString(path, "timeout test", timeoutMs = 5000)
        let r = await io.readFileString(path)
        doAssert r == "timeout test"

    waitFor run()

  test "TimeoutError is distinct from IOError and CancelledError":
    proc run() {.async.} =
      {.cast(gcsafe).}:
        var caughtTimeout = false
        var caughtIO = false
        var caughtCancel = false
        try:
          raise newException(TimeoutError, "test")
        except IOError:
          caughtIO = true
        except CancelledError:
          caughtCancel = true
        except TimeoutError:
          caughtTimeout = true
        doAssert caughtTimeout
        doAssert not caughtIO
        doAssert not caughtCancel

    waitFor run()

  test "timer + cancel pattern cancels blocked bridge read":
    ## Tests the timeout mechanism primitives: sleepMsAsync timer fires,
    ## uringCancel cancels the blocked kernel operation, read gets -ECANCELED.
    proc run() {.async.} =
      {.cast(gcsafe).}:
        var fds: array[2, cint]
        doAssert pipe(fds) == 0
        let readFd = fds[0]
        let writeFd = fds[1]
        defer:
          discard posix.close(readFd)
          discard posix.close(writeFd)

        var bufRef = new(seq[byte])
        bufRef[] = newSeq[byte](64)
        let readFut = io.uringRead(readFd, addr bufRef[][0], 64, 0'u64, bufRef)
        io.flush()

        # Manually replicate the awaitOrTimeout pattern
        let deadline = getMonoTime() + initDuration(milliseconds = 100)
        let remaining = deadline - getMonoTime()
        let timer = sleepMsAsync(int(remaining.inMilliseconds))
        await readFut or timer
        doAssert not readFut.finished, "read should still be blocked on empty pipe"

        # Cancel and drain
        try:
          discard await io.uringCancel(readFut)
        except IOError:
          discard
        let readRes = await readFut
        doAssert readRes == -125, "read should be -ECANCELED: " & $readRes

    waitFor run()

  test "writeFile on FIFO with timeout raises TimeoutError":
    ## Writing to a FIFO with no reader blocks. Tests that the shared deadline
    ## across all sub-operations (open, write, fsync, close) triggers TimeoutError.
    let path = getTempDir() / "iori_test_fifo_write_timeout"
    defer:
      removeFile(path)

    doAssert mkfifo(path.cstring, 0o644) == 0

    proc run() {.async.} =
      {.cast(gcsafe).}:
        var raised = false
        try:
          await io.writeFile(path, @[byte 1, 2, 3], timeoutMs = 100)
        except TimeoutError:
          raised = true
        doAssert raised, "should have raised TimeoutError"

    waitFor run()

  test "writeFile on FIFO with large data times out during write step":
    ## Open a FIFO reader so the write-side open succeeds quickly. Then write
    ## data larger than the pipe buffer (64KB default), which blocks the kernel
    ## write. With timeoutMs=1, the deadline expires during or before the write
    ## step, exercising the near-expiry / already-expired (ms <= 0) path in
    ## awaitOrTimeout.
    let path = getTempDir() / "iori_test_fifo_write_step_timeout"
    defer:
      removeFile(path)

    doAssert mkfifo(path.cstring, 0o644) == 0

    proc run() {.async.} =
      {.cast(gcsafe).}:
        # Open reader with O_NONBLOCK so writer's open doesn't block
        let readerFd = posix.open(path.cstring, O_RDONLY or O_NONBLOCK)
        doAssert readerFd >= 0
        defer:
          discard posix.close(readerFd)

        # 128KB exceeds default pipe buffer (64KB), so write blocks in kernel
        var bigData = newSeq[byte](128 * 1024)
        for i in 0 ..< bigData.len:
          bigData[i] = byte(i mod 256)

        var raised = false
        try:
          await io.writeFile(path, bigData, timeoutMs = 1, fsync = false)
        except TimeoutError:
          raised = true
        doAssert raised, "should have raised TimeoutError"

    waitFor run()

  test "readFile on unreadable file with timeout raises IOError":
    ## statx succeeds (file exists, size > 0) but open fails with EACCES.
    ## IOError must be raised — the timeout wrapper on uringOpen must not mask it.
    let path = getTempDir() / "iori_test_unreadable.bin"
    defer:
      discard chmod(path.cstring, 0o644)
      removeFile(path)

    proc run() {.async.} =
      {.cast(gcsafe).}:
        await io.writeFile(path, @[byte 1, 2, 3])
        discard chmod(path.cstring, 0o000)
        var caughtIO = false
        try:
          discard await io.readFile(path, timeoutMs = 5000)
        except TimeoutError:
          doAssert false, "should not be TimeoutError"
        except IOError:
          caughtIO = true
        doAssert caughtIO

    waitFor run()

  test "writeFile to read-only path with timeout raises IOError":
    ## When open fails immediately (EACCES), IOError must be raised even with
    ## a timeout set — the timeout wrapper must not mask the error.
    proc run() {.async.} =
      {.cast(gcsafe).}:
        var caughtIO = false
        try:
          await io.writeFile("/proc/nonexistent_iori_test", @[byte 1], timeoutMs = 5000)
        except TimeoutError:
          doAssert false, "should not be TimeoutError"
        except IOError:
          caughtIO = true
        doAssert caughtIO

    waitFor run()

  # Direct descriptor variants

  test "writeFileDirect and readFileDirect roundtrip":
    let path = getTempDir() / "iori_test_direct_roundtrip.bin"
    defer:
      removeFile(path)

    let data = @[byte 1, 2, 3, 4, 5, 0xDE, 0xAD, 0xBE, 0xEF]

    proc run() {.async.} =
      {.cast(gcsafe).}:
        io.registerFixedFileSlots(4)
        defer:
          io.unregisterFixedFiles()

        await io.writeFileDirect(path, data)
        let readResult = await io.readFileDirect(path)
        doAssert readResult == data

    waitFor run()

  test "writeFileStringDirect and readFileStringDirect roundtrip":
    let path = getTempDir() / "iori_test_direct_roundtrip.txt"
    defer:
      removeFile(path)

    let content = "Hello, direct descriptors!\nLine 2\n"

    proc run() {.async.} =
      {.cast(gcsafe).}:
        io.registerFixedFileSlots(4)
        defer:
          io.unregisterFixedFiles()

        await io.writeFileStringDirect(path, content)
        let readResult = await io.readFileStringDirect(path)
        doAssert readResult == content

    waitFor run()

  test "readFileDirect on nonexistent file raises IOError":
    proc run() {.async.} =
      {.cast(gcsafe).}:
        io.registerFixedFileSlots(4)
        defer:
          io.unregisterFixedFiles()

        var raised = false
        try:
          discard await io.readFileDirect("/tmp/iori_nonexistent_direct_" & $getpid())
        except IOError:
          raised = true
        doAssert raised

    waitFor run()

  test "writeFileDirect and readFileDirect large data":
    let path = getTempDir() / "iori_test_direct_large.bin"
    defer:
      removeFile(path)

    var data = newSeq[byte](65536)
    for i in 0 ..< data.len:
      data[i] = byte(i mod 256)

    proc run() {.async.} =
      {.cast(gcsafe).}:
        io.registerFixedFileSlots(4)
        defer:
          io.unregisterFixedFiles()

        await io.writeFileDirect(path, data)
        let readResult = await io.readFileDirect(path)
        doAssert readResult.len == data.len
        doAssert readResult == data

    waitFor run()

  test "writeFileDirect and readFileDirect empty data":
    let path = getTempDir() / "iori_test_direct_empty.bin"
    defer:
      removeFile(path)

    proc run() {.async.} =
      {.cast(gcsafe).}:
        io.registerFixedFileSlots(4)
        defer:
          io.unregisterFixedFiles()

        await io.writeFileDirect(path, @[])
        let readResult = await io.readFileDirect(path)
        doAssert readResult.len == 0

    waitFor run()

  test "writeFileDirect overwrites existing file":
    let path = getTempDir() / "iori_test_direct_overwrite.bin"
    defer:
      removeFile(path)

    proc run() {.async.} =
      {.cast(gcsafe).}:
        io.registerFixedFileSlots(4)
        defer:
          io.unregisterFixedFiles()

        await io.writeFileDirect(path, @[byte 1, 2, 3, 4, 5])
        await io.writeFileDirect(path, @[byte 10, 20])
        let readBack = await io.readFileDirect(path)
        doAssert readBack == @[byte 10, 20]

    waitFor run()

  test "writeFileDirect with fsync=false":
    let path = getTempDir() / "iori_test_direct_no_fsync.bin"
    defer:
      removeFile(path)

    let data = @[byte 1, 2, 3, 4, 5]

    proc run() {.async.} =
      {.cast(gcsafe).}:
        io.registerFixedFileSlots(4)
        defer:
          io.unregisterFixedFiles()

        await io.writeFileDirect(path, data, fsync = false)
        let readResult = await io.readFileDirect(path)
        doAssert readResult == data

    waitFor run()

  test "concurrent direct read and write operations":
    let pathA = getTempDir() / "iori_test_direct_concurrent_a.bin"
    let pathB = getTempDir() / "iori_test_direct_concurrent_b.bin"
    defer:
      removeFile(pathA)
      removeFile(pathB)

    let dataA = @[byte 0xAA, 0xBB, 0xCC]
    let dataB = @[byte 0x11, 0x22, 0x33, 0x44]

    proc run() {.async.} =
      {.cast(gcsafe).}:
        io.registerFixedFileSlots(4)
        defer:
          io.unregisterFixedFiles()

        let futA = io.writeFileDirect(pathA, dataA)
        let futB = io.writeFileDirect(pathB, dataB)
        await futA
        await futB

        let futReadA = io.readFileDirect(pathA)
        let futReadB = io.readFileDirect(pathB)
        let resultA = await futReadA
        let resultB = await futReadB

        doAssert resultA == dataA
        doAssert resultB == dataB

    waitFor run()

  test "writeFileDirect to read-only path raises IOError":
    proc run() {.async.} =
      {.cast(gcsafe).}:
        io.registerFixedFileSlots(4)
        defer:
          io.unregisterFixedFiles()

        var raised = false
        try:
          await io.writeFileDirect("/proc/nonexistent_iori_test", @[byte 1])
        except IOError:
          raised = true
        doAssert raised

    waitFor run()

  test "readFileDirect with timeout succeeds for normal file":
    let path = getTempDir() / "iori_test_direct_timeout_read.bin"
    defer:
      removeFile(path)

    let data = @[byte 1, 2, 3, 4, 5]

    proc run() {.async.} =
      {.cast(gcsafe).}:
        io.registerFixedFileSlots(4)
        defer:
          io.unregisterFixedFiles()

        await io.writeFileDirect(path, data)
        let r = await io.readFileDirect(path, timeoutMs = 5000)
        doAssert r == data

    waitFor run()

  test "writeFileDirect with timeout succeeds for normal file":
    let path = getTempDir() / "iori_test_direct_timeout_write.bin"
    defer:
      removeFile(path)

    let data = @[byte 10, 20, 30]

    proc run() {.async.} =
      {.cast(gcsafe).}:
        io.registerFixedFileSlots(4)
        defer:
          io.unregisterFixedFiles()

        await io.writeFileDirect(path, data, timeoutMs = 5000)
        let r = await io.readFileDirect(path)
        doAssert r == data

    waitFor run()

  test "writeFileDirect without registered slots raises IOError":
    proc run() {.async.} =
      {.cast(gcsafe).}:
        var raised = false
        try:
          await io.writeFileDirect("/tmp/iori_test_direct_no_slots.bin", @[byte 1])
        except IOError:
          raised = true
        doAssert raised

    waitFor run()

  test "readFileDirect slot not leaked on error":
    proc run() {.async.} =
      {.cast(gcsafe).}:
        io.registerFixedFileSlots(1)
        defer:
          io.unregisterFixedFiles()

        doAssert io.fixedFileSlotsAvailable == 1

        var raised = false
        try:
          discard await io.readFileDirect("/tmp/iori_nonexistent_leak_" & $getpid())
        except IOError:
          raised = true
        doAssert raised

        # Slot must have been returned to the pool
        doAssert io.fixedFileSlotsAvailable == 1

    waitFor run()

  test "writeFileDirect slot not leaked on error":
    proc run() {.async.} =
      {.cast(gcsafe).}:
        io.registerFixedFileSlots(1)
        defer:
          io.unregisterFixedFiles()

        doAssert io.fixedFileSlotsAvailable == 1

        var raised = false
        try:
          await io.writeFileDirect("/proc/nonexistent_iori_leak_test", @[byte 1])
        except IOError:
          raised = true
        doAssert raised

        # Slot must have been returned to the pool
        doAssert io.fixedFileSlotsAvailable == 1

    waitFor run()

  test "readFileDirect without registered slots raises IOError":
    let path = getTempDir() / "iori_test_direct_no_slots.txt"
    defer:
      removeFile(path)

    # Create a file with content so statx returns size > 0
    let fd = posix.open(path.cstring, O_WRONLY or O_CREAT or O_TRUNC, 0o644)
    doAssert fd >= 0
    let data = "test"
    doAssert posix.write(fd, data.cstring, data.len) == data.len
    discard posix.close(fd)

    proc run() {.async.} =
      {.cast(gcsafe).}:
        var raised = false
        try:
          discard await io.readFileDirect(path)
        except IOError:
          raised = true
        doAssert raised

    waitFor run()
