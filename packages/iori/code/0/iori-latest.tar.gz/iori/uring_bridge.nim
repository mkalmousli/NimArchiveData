## eventfd bridge + Low-level API for io_uring.
##
## Integrates io_uring with async event loop via eventfd.
## Provides low-level API returning `Future[int32]` for each io_uring operation.

when not defined(linux):
  {.fatal: "uring_bridge requires Linux".}

import std/[tables, posix, oserrors]

import ./async_backend
import ./uring_raw

export async_backend

const
  EFD_NONBLOCK = 0x00000800.cint
  EFD_CLOEXEC = 0x00080000.cint

proc eventfd(initval: cuint, flags: cint): cint {.importc, header: "<sys/eventfd.h>".}

type
  CompletionKind = enum
    ckOpen
    ckRead
    ckWrite
    ckFsync
    ckClose
    ckStatx
    ckRename
    ckCancel

  Completion = object
    future: Future[int32]
    kind: CompletionKind
    bufRef: ref seq[byte] # GC root for buffer
    strRef: ref string
      # GC root for path string (ref ensures stable cstring through copies)
    strRef2: ref string # GC root for second path string (rename)
    statxRef: ref Statx # GC root for statx output buffer

  UringFileIO* = ref object
    ## Handle for async file I/O via io_uring.
    ## Create with `newUringFileIO`, release with `close`.
    ring: IoUring
    eventFd: cint
    nextId: uint64
    pending: Table[uint64, Completion]
    futureToId: Table[pointer, uint64]
    closed: bool
    error: ref CatchableError # Propagated to pending futures
    selfRef: UringFileIO # GC root: prevents collection while poll loop holds raw pointer
    flushScheduled: bool # Prevents duplicate callSoon scheduling
    unsubmitted: seq[uint64] # IDs not yet submitted (for failing on submit error)
    chainActive: bool
    chainIds: seq[uint64] # SQE IDs queued during current chain (for rollback)
    chainFutures: seq[Future[int32]] # Futures queued during current chain
    chainFailed: bool # Whether a getSqe returned nil during chain
    fixedBufs: seq[seq[byte]] # Registered fixed buffers (GC root)
    fixedBufsRegistered: bool
    fixedFiles: seq[cint] # Registered fixed file descriptors (copy)
    fixedFilesRegistered: bool
    fixedFileSlotsFree: seq[int32] # Direct open: free slot stack

proc allocId(u: UringFileIO): uint64 =
  ## ID allocation
  result = u.nextId
  u.nextId += 1

proc stopPollLoop(u: UringFileIO) {.raises: [].} =
  try:
    unregisterFdReader(u.eventFd)
  except CatchableError as e:
    if u.error == nil:
      u.error = e
  u.selfRef = nil

proc processCqes(u: UringFileIO) {.raises: [].} =
  ## CQE processing
  while not u.closed:
    let cqe = peekCqe(u.ring)
    if cqe == nil:
      break
    let id = cqe.userData
    let res = cqe.res
    advanceCq(u.ring)

    var comp: Completion
    if u.pending.pop(id, comp):
      u.futureToId.del(cast[pointer](comp.future))
      # Each ID is unique and popped from pending, so double-completion is impossible.
      # cast(raises) suppresses the theoretical ValueError from Future.complete.
      {.cast(raises: []).}:
        comp.future.complete(res)

proc close*(u: UringFileIO) {.raises: [].} =
  ## Close the UringFileIO instance. Fails all pending futures and releases resources.
  ## If `u.error` is set, pending futures are failed with that error.
  if u.closed:
    return
  u.closed = true

  if u.chainActive:
    u.chainActive = false
    if u.chainIds.len > 0:
      rollbackSqes(u.ring, uint32(u.chainIds.len))

  stopPollLoop(u)
  u.flushScheduled = false
  u.unsubmitted.setLen(0)

  let err =
    if u.error != nil:
      u.error
    else:
      newException(IOError, "UringFileIO closed")

  # Collect and clear pending before failing — fail() may trigger callbacks
  # that attempt to modify the table.
  var pending: seq[Completion]
  for id, comp in u.pending:
    pending.add(comp)
  u.pending.clear()
  u.futureToId.clear()
  for comp in pending:
    {.cast(raises: []).}:
      comp.future.fail(err)

  # Fail chain futures not in pending (e.g. from chainFailed path)
  for fut in u.chainFutures:
    if not fut.finished:
      {.cast(raises: []).}:
        fut.fail(err)
  u.chainIds.setLen(0)
  u.chainFutures.setLen(0)

  if u.fixedFilesRegistered:
    unregisterFiles(u.ring)
    u.fixedFilesRegistered = false
    u.fixedFiles.setLen(0)
    u.fixedFileSlotsFree.setLen(0)

  if u.fixedBufsRegistered:
    unregisterBuffers(u.ring)
    u.fixedBufsRegistered = false
    u.fixedBufs.setLen(0)

  unregisterEventfd(u.ring)
  discard close(u.eventFd)
  u.eventFd = -1
  closeRing(u.ring)

proc drainEventfd(u: UringFileIO) =
  ## Read and discard the eventfd counter. Ignores EAGAIN.
  var buf: uint64
  let ret = read(u.eventFd, addr buf, sizeof(buf))
  if ret < 0:
    let err = errno
    if err != posix.EAGAIN and err != posix.EINTR:
      raiseOSError(OSErrorCode(err), "eventfd read failed")

proc startPollLoop(u: UringFileIO) {.raises: [OSError].} =
  u.selfRef = u
  try:
    registerFdReader(
      u.eventFd,
      proc() {.raises: [].} =
        if u.closed:
          return
        try:
          u.drainEventfd()
        except OSError as e:
          u.error = e
          u.close()
        u.processCqes(),
    )
  except CatchableError as e:
    u.selfRef = nil
    raise (ref OSError)(msg: "eventfd registration failed: " & e.msg)

proc flush*(u: UringFileIO) {.raises: [].} =
  ## Flush all queued SQEs to the kernel in a single io_uring_enter syscall.
  if u.chainActive:
    return # Keep flushScheduled; endChain will allow flush
  u.flushScheduled = false
  if u.closed or u.unsubmitted.len == 0:
    return

  let ret = submit(u.ring)
  if ret < 0:
    # Submit failed: fail only unsubmitted futures (already-submitted ones complete via CQE)
    for id in u.unsubmitted:
      var comp: Completion
      if u.pending.pop(id, comp):
        u.futureToId.del(cast[pointer](comp.future))
        {.cast(raises: []).}:
          comp.future.fail(
            newException(
              IOError, "io_uring submit failed: " & osErrorMsg(OSErrorCode(-ret))
            )
          )
  u.unsubmitted.setLen(0)

proc queueSqe(u: UringFileIO, comp: Completion): Future[int32] =
  ## Queue the most recently prepared SQE for batch submission.
  ## The caller must have already called getSqe and filled the SQE fields
  ## (except userData, which this proc sets).
  ## The SQE will be submitted on the next event loop tick via callSoon.
  let fut = comp.future
  let id = u.allocId()

  setLastSqeUserData(u.ring, id)

  if u.chainActive:
    setLastSqeFlags(u.ring, IOSQE_IO_LINK)
    u.chainIds.add(id)
    u.chainFutures.add(fut)

  u.pending[id] = comp
  u.futureToId[cast[pointer](fut)] = id
  u.unsubmitted.add(id)

  if not u.flushScheduled:
    u.flushScheduled = true
    scheduleSoon(
      proc() {.raises: [].} =
        u.flush()
    )

  return fut

proc uringOpen*(
    u: UringFileIO, path: string, flags: cint, mode: uint32 = 0o644
): Future[int32] =
  ## Submit OPENAT operation. Returns Future with fd on success or negative errno.
  let fut = newFuture[int32]("uringOpen")

  if u.closed:
    fut.fail(
      if u.error != nil:
        u.error
      else:
        newException(IOError, "UringFileIO closed")
    )
    return fut

  let sqe = getSqe(u.ring)
  if sqe == nil:
    if u.chainActive:
      u.chainFailed = true
      u.chainFutures.add(fut)
      return fut
    fut.fail(newException(IOError, "io_uring SQ full"))
    return fut

  # Keep path alive until CQE arrives (ref string ensures stable cstring pointer)
  var pathRef: ref string
  new(pathRef)
  pathRef[] = path

  sqe.opcode = IORING_OP_OPENAT
  sqe.fd = AT_FDCWD
  sqe.`addr` = cast[uint64](pathRef[].cstring)
  sqe.len = uint32(mode)
  sqe.opFlags = cast[uint32](flags)

  var comp = Completion(future: fut, kind: ckOpen, strRef: pathRef)
  return queueSqe(u, comp)

proc uringRead*(
    u: UringFileIO,
    fd: cint,
    buf: pointer,
    size: uint32,
    offset: uint64,
    bufRef: ref seq[byte],
): Future[int32] =
  ## Submit READ operation. Returns Future with bytes read or negative errno.
  ## bufRef keeps the buffer GC-rooted until completion.
  let fut = newFuture[int32]("uringRead")

  if u.closed:
    fut.fail(
      if u.error != nil:
        u.error
      else:
        newException(IOError, "UringFileIO closed")
    )
    return fut

  let sqe = getSqe(u.ring)
  if sqe == nil:
    if u.chainActive:
      u.chainFailed = true
      u.chainFutures.add(fut)
      return fut
    fut.fail(newException(IOError, "io_uring SQ full"))
    return fut

  sqe.opcode = IORING_OP_READ
  sqe.fd = fd
  sqe.`addr` = cast[uint64](buf)
  sqe.len = size
  sqe.off = offset

  var comp = Completion(future: fut, kind: ckRead, bufRef: bufRef)
  return queueSqe(u, comp)

proc uringWrite*(
    u: UringFileIO,
    fd: cint,
    buf: pointer,
    size: uint32,
    offset: uint64,
    bufRef: ref seq[byte],
): Future[int32] =
  ## Submit WRITE operation. Returns Future with bytes written or negative errno.
  ## bufRef keeps the buffer GC-rooted until completion.
  let fut = newFuture[int32]("uringWrite")

  if u.closed:
    fut.fail(
      if u.error != nil:
        u.error
      else:
        newException(IOError, "UringFileIO closed")
    )
    return fut

  let sqe = getSqe(u.ring)
  if sqe == nil:
    if u.chainActive:
      u.chainFailed = true
      u.chainFutures.add(fut)
      return fut
    fut.fail(newException(IOError, "io_uring SQ full"))
    return fut

  sqe.opcode = IORING_OP_WRITE
  sqe.fd = fd
  sqe.`addr` = cast[uint64](buf)
  sqe.len = size
  sqe.off = offset

  var comp = Completion(future: fut, kind: ckWrite, bufRef: bufRef)
  return queueSqe(u, comp)

proc uringFsync*(u: UringFileIO, fd: cint): Future[int32] =
  ## Submit FSYNC operation. Returns Future with 0 on success or negative errno.
  let fut = newFuture[int32]("uringFsync")

  if u.closed:
    fut.fail(
      if u.error != nil:
        u.error
      else:
        newException(IOError, "UringFileIO closed")
    )
    return fut

  let sqe = getSqe(u.ring)
  if sqe == nil:
    if u.chainActive:
      u.chainFailed = true
      u.chainFutures.add(fut)
      return fut
    fut.fail(newException(IOError, "io_uring SQ full"))
    return fut

  sqe.opcode = IORING_OP_FSYNC
  sqe.fd = fd

  var comp = Completion(future: fut, kind: ckFsync)
  return queueSqe(u, comp)

proc uringClose*(u: UringFileIO, fd: cint): Future[int32] =
  ## Submit CLOSE operation. Returns Future with 0 on success or negative errno.
  let fut = newFuture[int32]("uringClose")

  if u.closed:
    fut.fail(
      if u.error != nil:
        u.error
      else:
        newException(IOError, "UringFileIO closed")
    )
    return fut

  let sqe = getSqe(u.ring)
  if sqe == nil:
    if u.chainActive:
      u.chainFailed = true
      u.chainFutures.add(fut)
      return fut
    fut.fail(newException(IOError, "io_uring SQ full"))
    return fut

  sqe.opcode = IORING_OP_CLOSE
  sqe.fd = fd

  var comp = Completion(future: fut, kind: ckClose)
  return queueSqe(u, comp)

proc uringStatx*(
    u: UringFileIO, path: string, flags: cint, mask: uint32, statxBuf: ref Statx
): Future[int32] =
  ## Submit STATX operation. Returns Future with 0 on success or negative errno.
  ## Results are written to statxBuf.
  let fut = newFuture[int32]("uringStatx")

  if u.closed:
    fut.fail(
      if u.error != nil:
        u.error
      else:
        newException(IOError, "UringFileIO closed")
    )
    return fut

  let sqe = getSqe(u.ring)
  if sqe == nil:
    if u.chainActive:
      u.chainFailed = true
      u.chainFutures.add(fut)
      return fut
    fut.fail(newException(IOError, "io_uring SQ full"))
    return fut

  var pathRef: ref string
  new(pathRef)
  pathRef[] = path

  sqe.opcode = IORING_OP_STATX
  sqe.fd = AT_FDCWD
  sqe.`addr` = cast[uint64](pathRef[].cstring)
  sqe.len = mask
  sqe.off = cast[uint64](addr statxBuf[])
  sqe.opFlags = cast[uint32](flags)

  var comp = Completion(future: fut, kind: ckStatx, strRef: pathRef, statxRef: statxBuf)
  return queueSqe(u, comp)

proc uringStatxFd*(
    u: UringFileIO, fd: cint, mask: uint32, statxBuf: ref Statx
): Future[int32] =
  ## Submit STATX on an open fd (AT_EMPTY_PATH). Returns Future with 0 on success
  ## or negative errno. Results are written to statxBuf.
  let fut = newFuture[int32]("uringStatxFd")

  if u.closed:
    fut.fail(
      if u.error != nil:
        u.error
      else:
        newException(IOError, "UringFileIO closed")
    )
    return fut

  let sqe = getSqe(u.ring)
  if sqe == nil:
    if u.chainActive:
      u.chainFailed = true
      u.chainFutures.add(fut)
      return fut
    fut.fail(newException(IOError, "io_uring SQ full"))
    return fut

  # AT_EMPTY_PATH with empty path string performs statx on the fd itself.
  var pathRef: ref string
  new(pathRef)
  pathRef[] = ""

  sqe.opcode = IORING_OP_STATX
  sqe.fd = fd
  sqe.`addr` = cast[uint64](pathRef[].cstring)
  sqe.len = mask
  sqe.off = cast[uint64](addr statxBuf[])
  sqe.opFlags = cast[uint32](AT_EMPTY_PATH)

  var comp = Completion(future: fut, kind: ckStatx, strRef: pathRef, statxRef: statxBuf)
  return queueSqe(u, comp)

proc uringRenameat*(
    u: UringFileIO, oldPath: string, newPath: string, flags: uint32 = 0
): Future[int32] =
  ## Submit RENAMEAT operation. Returns Future with 0 on success or negative errno.
  let fut = newFuture[int32]("uringRenameat")

  if u.closed:
    fut.fail(
      if u.error != nil:
        u.error
      else:
        newException(IOError, "UringFileIO closed")
    )
    return fut

  let sqe = getSqe(u.ring)
  if sqe == nil:
    if u.chainActive:
      u.chainFailed = true
      u.chainFutures.add(fut)
      return fut
    fut.fail(newException(IOError, "io_uring SQ full"))
    return fut

  var oldPathRef: ref string
  new(oldPathRef)
  oldPathRef[] = oldPath
  var newPathRef: ref string
  new(newPathRef)
  newPathRef[] = newPath

  sqe.opcode = IORING_OP_RENAMEAT
  sqe.fd = AT_FDCWD
  sqe.`addr` = cast[uint64](oldPathRef[].cstring)
  sqe.len = cast[uint32](AT_FDCWD)
  sqe.off = cast[uint64](newPathRef[].cstring)
  sqe.opFlags = flags

  var comp =
    Completion(future: fut, kind: ckRename, strRef: oldPathRef, strRef2: newPathRef)
  return queueSqe(u, comp)

proc uringCancel*(u: UringFileIO, target: Future[int32]): Future[int32] =
  ## Submit ASYNC_CANCEL for a pending operation. Returns Future with 0 on success
  ## or negative errno. The cancelled target Future will complete with -ECANCELED (-125).
  let fut = newFuture[int32]("uringCancel")

  if u.closed:
    fut.fail(
      if u.error != nil:
        u.error
      else:
        newException(IOError, "UringFileIO closed")
    )
    return fut

  let targetPtr = cast[pointer](target)
  if targetPtr notin u.futureToId:
    fut.fail(newException(IOError, "target operation not found"))
    return fut

  let targetId = u.futureToId[targetPtr]

  # Check if target is still unsubmitted — cancel locally without kernel roundtrip
  var unsubIdx = -1
  for i, id in u.unsubmitted:
    if id == targetId:
      unsubIdx = i
      break

  if unsubIdx >= 0:
    u.unsubmitted.delete(unsubIdx)
    nopifySqe(u.ring, targetId)
    var comp: Completion
    if u.pending.pop(targetId, comp):
      u.futureToId.del(cast[pointer](comp.future))
      {.cast(raises: []).}:
        comp.future.complete(-125'i32)
    fut.complete(0'i32)
    return fut

  # Target is already submitted — ask the kernel to cancel it
  let sqe = getSqe(u.ring)
  if sqe == nil:
    fut.fail(newException(IOError, "io_uring SQ full"))
    return fut

  sqe.opcode = IORING_OP_ASYNC_CANCEL
  sqe.`addr` = targetId

  var comp = Completion(future: fut, kind: ckCancel)
  return queueSqe(u, comp)

proc beginChain*(u: UringFileIO) =
  ## Start a linked SQE chain. Subsequent uring* calls will have IOSQE_IO_LINK set.
  ## Call endChain to finalize the chain.
  if u.closed:
    raise newException(IOError, "UringFileIO closed")
  if u.chainActive:
    raise newException(IOError, "chain already active")
  u.chainActive = true
  u.chainFailed = false
  u.chainIds.setLen(0)
  u.chainFutures.setLen(0)

proc endChain*(u: UringFileIO): seq[Future[int32]] =
  ## Finalize a linked SQE chain. Returns the futures for all operations in the chain.
  ## If any getSqe failed during the chain, all SQEs are rolled back and all futures fail.
  if not u.chainActive:
    raise newException(IOError, "no active chain")
  u.chainActive = false

  if u.chainFutures.len == 0:
    # Empty chain
    return @[]

  if u.chainFailed:
    # Roll back all successfully allocated SQEs
    if u.chainIds.len > 0:
      rollbackSqes(u.ring, uint32(u.chainIds.len))
      # Remove from pending/futureToId/unsubmitted
      for id in u.chainIds:
        var comp: Completion
        if u.pending.pop(id, comp):
          u.futureToId.del(cast[pointer](comp.future))
        for i in countdown(u.unsubmitted.high, 0):
          if u.unsubmitted[i] == id:
            u.unsubmitted.delete(i)
            break
    # Fail all futures
    let err = newException(IOError, "chain aborted: io_uring SQ full")
    for fut in u.chainFutures:
      if not fut.finished:
        fut.fail(err)
    result = u.chainFutures
  else:
    # Clear IOSQE_IO_LINK from the last SQE (it must not link to the next unrelated SQE)
    if u.chainIds.len > 0:
      clearLastSqeFlags(u.ring, IOSQE_IO_LINK)
    result = u.chainFutures

  u.chainIds.setLen(0)
  u.chainFutures.setLen(0)

  # Allow pending flush to proceed
  if u.flushScheduled:
    u.flushScheduled = false
    if u.unsubmitted.len > 0:
      u.flushScheduled = true
      scheduleSoon(
        proc() {.raises: [].} =
          u.flush()
      )

proc newUringFileIO*(entries: uint32 = 256): UringFileIO {.raises: [OSError].} =
  ## Create a new UringFileIO instance. Initializes io_uring and starts poll loop.
  var ring = setupRing(entries)

  let efd = eventfd(0, EFD_NONBLOCK or EFD_CLOEXEC)
  if efd < 0:
    closeRing(ring)
    raiseOSError(osLastError(), "eventfd creation failed")

  try:
    registerEventfd(ring, efd)
  except OSError as e:
    discard close(efd)
    closeRing(ring)
    raise e

  result = UringFileIO(
    ring: ring,
    eventFd: efd,
    nextId: 1,
    pending: initTable[uint64, Completion](),
    closed: false,
  )
  try:
    startPollLoop(result)
  except OSError as e:
    unregisterEventfd(ring)
    discard close(efd)
    closeRing(ring)
    raise e

# Fixed buffers

proc registerFixedBuffers*(
    u: UringFileIO, sizes: openArray[int]
) {.raises: [IOError].} =
  ## Register fixed buffers with the kernel. `sizes` specifies the size of each buffer.
  ## Buffers are allocated and managed by UringFileIO.
  if u.closed:
    raise newException(IOError, "UringFileIO closed")
  if u.fixedBufsRegistered:
    raise newException(IOError, "fixed buffers already registered")
  if sizes.len == 0:
    raise newException(IOError, "sizes must not be empty")
  for s in sizes:
    if s <= 0:
      raise newException(IOError, "buffer size must be positive")

  u.fixedBufs = newSeq[seq[byte]](sizes.len)
  var iovecs = newSeq[IOVec](sizes.len)
  for i in 0 ..< sizes.len:
    u.fixedBufs[i] = newSeq[byte](sizes[i])
    iovecs[i].iov_base = addr u.fixedBufs[i][0]
    iovecs[i].iov_len = csize_t(sizes[i])

  try:
    registerBuffers(u.ring, addr iovecs[0], cuint(sizes.len))
  except OSError as e:
    u.fixedBufs.setLen(0)
    raise newException(IOError, "registerFixedBuffers failed: " & e.msg)

  u.fixedBufsRegistered = true

proc unregisterFixedBuffers*(u: UringFileIO) =
  ## Unregister fixed buffers from the kernel and free them.
  if not u.fixedBufsRegistered:
    return
  unregisterBuffers(u.ring)
  u.fixedBufsRegistered = false
  u.fixedBufs.setLen(0)

proc fixedBufferCount*(u: UringFileIO): int =
  ## Return the number of registered fixed buffers.
  u.fixedBufs.len

proc fixedBufferAddr*(u: UringFileIO, index: int): pointer =
  ## Return the address of a registered fixed buffer.
  addr u.fixedBufs[index][0]

proc fixedBufferSize*(u: UringFileIO, index: int): int =
  ## Return the size of a registered fixed buffer.
  u.fixedBufs[index].len

proc uringReadFixed*(
    u: UringFileIO,
    fd: cint,
    buf: pointer,
    size: uint32,
    offset: uint64,
    bufIndex: uint16,
): Future[int32] =
  ## Submit READ_FIXED operation using a pre-registered fixed buffer.
  ## `buf` must point into the registered buffer at `bufIndex`.
  ## No bufRef needed — UringFileIO owns the buffer.
  let fut = newFuture[int32]("uringReadFixed")

  if u.closed:
    fut.fail(
      if u.error != nil:
        u.error
      else:
        newException(IOError, "UringFileIO closed")
    )
    return fut

  let sqe = getSqe(u.ring)
  if sqe == nil:
    if u.chainActive:
      u.chainFailed = true
      u.chainFutures.add(fut)
      return fut
    fut.fail(newException(IOError, "io_uring SQ full"))
    return fut

  sqe.opcode = IORING_OP_READ_FIXED
  sqe.fd = fd
  sqe.`addr` = cast[uint64](buf)
  sqe.len = size
  sqe.off = offset
  sqe.bufInfo = bufIndex

  var comp = Completion(future: fut, kind: ckRead)
  return queueSqe(u, comp)

proc uringWriteFixed*(
    u: UringFileIO,
    fd: cint,
    buf: pointer,
    size: uint32,
    offset: uint64,
    bufIndex: uint16,
): Future[int32] =
  ## Submit WRITE_FIXED operation using a pre-registered fixed buffer.
  ## `buf` must point into the registered buffer at `bufIndex`.
  ## No bufRef needed — UringFileIO owns the buffer.
  let fut = newFuture[int32]("uringWriteFixed")

  if u.closed:
    fut.fail(
      if u.error != nil:
        u.error
      else:
        newException(IOError, "UringFileIO closed")
    )
    return fut

  let sqe = getSqe(u.ring)
  if sqe == nil:
    if u.chainActive:
      u.chainFailed = true
      u.chainFutures.add(fut)
      return fut
    fut.fail(newException(IOError, "io_uring SQ full"))
    return fut

  sqe.opcode = IORING_OP_WRITE_FIXED
  sqe.fd = fd
  sqe.`addr` = cast[uint64](buf)
  sqe.len = size
  sqe.off = offset
  sqe.bufInfo = bufIndex

  var comp = Completion(future: fut, kind: ckWrite)
  return queueSqe(u, comp)

# Fixed files

proc registerFixedFiles*(u: UringFileIO, fds: openArray[cint]) {.raises: [IOError].} =
  ## Register fixed files with the kernel. `fds` are file descriptors opened by the caller.
  ## The caller retains ownership of the fds (open/close responsibility).
  if u.closed:
    raise newException(IOError, "UringFileIO closed")
  if u.fixedFilesRegistered:
    raise newException(IOError, "fixed files already registered")
  if fds.len == 0:
    raise newException(IOError, "fds must not be empty")

  u.fixedFiles = @fds # Copy
  try:
    registerFiles(u.ring, addr u.fixedFiles[0], cuint(fds.len))
  except OSError as e:
    u.fixedFiles.setLen(0)
    raise newException(IOError, "registerFixedFiles failed: " & e.msg)

  u.fixedFilesRegistered = true

proc unregisterFixedFiles*(u: UringFileIO) =
  ## Unregister fixed files from the kernel. Does not close the fds.
  if not u.fixedFilesRegistered:
    return
  unregisterFiles(u.ring)
  u.fixedFilesRegistered = false
  u.fixedFiles.setLen(0)
  u.fixedFileSlotsFree.setLen(0)

proc fixedFileCount*(u: UringFileIO): int =
  ## Return the number of registered fixed files.
  u.fixedFiles.len

proc uringReadFixedFile*(
    u: UringFileIO,
    fileIndex: cint,
    buf: pointer,
    size: uint32,
    offset: uint64,
    bufRef: ref seq[byte],
): Future[int32] =
  ## Submit READ operation using a fixed file index.
  ## `fileIndex` is the index into the registered file table (not a real fd).
  ## bufRef keeps the buffer GC-rooted until completion.
  let fut = newFuture[int32]("uringReadFixedFile")

  if u.closed:
    fut.fail(
      if u.error != nil:
        u.error
      else:
        newException(IOError, "UringFileIO closed")
    )
    return fut

  let sqe = getSqe(u.ring)
  if sqe == nil:
    if u.chainActive:
      u.chainFailed = true
      u.chainFutures.add(fut)
      return fut
    fut.fail(newException(IOError, "io_uring SQ full"))
    return fut

  sqe.opcode = IORING_OP_READ
  sqe.flags = IOSQE_FIXED_FILE
  sqe.fd = fileIndex
  sqe.`addr` = cast[uint64](buf)
  sqe.len = size
  sqe.off = offset

  var comp = Completion(future: fut, kind: ckRead, bufRef: bufRef)
  return queueSqe(u, comp)

proc uringWriteFixedFile*(
    u: UringFileIO,
    fileIndex: cint,
    buf: pointer,
    size: uint32,
    offset: uint64,
    bufRef: ref seq[byte],
): Future[int32] =
  ## Submit WRITE operation using a fixed file index.
  ## `fileIndex` is the index into the registered file table (not a real fd).
  ## bufRef keeps the buffer GC-rooted until completion.
  let fut = newFuture[int32]("uringWriteFixedFile")

  if u.closed:
    fut.fail(
      if u.error != nil:
        u.error
      else:
        newException(IOError, "UringFileIO closed")
    )
    return fut

  let sqe = getSqe(u.ring)
  if sqe == nil:
    if u.chainActive:
      u.chainFailed = true
      u.chainFutures.add(fut)
      return fut
    fut.fail(newException(IOError, "io_uring SQ full"))
    return fut

  sqe.opcode = IORING_OP_WRITE
  sqe.flags = IOSQE_FIXED_FILE
  sqe.fd = fileIndex
  sqe.`addr` = cast[uint64](buf)
  sqe.len = size
  sqe.off = offset

  var comp = Completion(future: fut, kind: ckWrite, bufRef: bufRef)
  return queueSqe(u, comp)

proc uringFsyncFixedFile*(u: UringFileIO, fileIndex: cint): Future[int32] =
  ## Submit FSYNC operation using a fixed file index.
  ## `fileIndex` is the index into the registered file table (not a real fd).
  let fut = newFuture[int32]("uringFsyncFixedFile")

  if u.closed:
    fut.fail(
      if u.error != nil:
        u.error
      else:
        newException(IOError, "UringFileIO closed")
    )
    return fut

  let sqe = getSqe(u.ring)
  if sqe == nil:
    if u.chainActive:
      u.chainFailed = true
      u.chainFutures.add(fut)
      return fut
    fut.fail(newException(IOError, "io_uring SQ full"))
    return fut

  sqe.opcode = IORING_OP_FSYNC
  sqe.flags = IOSQE_FIXED_FILE
  sqe.fd = fileIndex

  var comp = Completion(future: fut, kind: ckFsync)
  return queueSqe(u, comp)

# Fixed file slots (for direct descriptors)

proc registerFixedFileSlots*(u: UringFileIO, count: int) {.raises: [IOError].} =
  ## Register `count` empty fixed file slots (fd=-1) for use with direct descriptors.
  ## Mutually exclusive with `registerFixedFiles` (io_uring supports one file table).
  if u.closed:
    raise newException(IOError, "UringFileIO closed")
  if u.fixedFilesRegistered:
    raise newException(IOError, "fixed files already registered")
  if count <= 0:
    raise newException(IOError, "count must be positive")

  u.fixedFiles = newSeq[cint](count)
  for i in 0 ..< count:
    u.fixedFiles[i] = -1

  try:
    registerFiles(u.ring, addr u.fixedFiles[0], cuint(count))
  except OSError as e:
    u.fixedFiles.setLen(0)
    raise newException(IOError, "registerFixedFileSlots failed: " & e.msg)

  u.fixedFilesRegistered = true
  u.fixedFileSlotsFree = newSeq[int32](count)
  for i in 0 ..< count:
    u.fixedFileSlotsFree[i] = int32(i)

proc allocFixedFileSlot*(u: UringFileIO): int32 {.raises: [IOError].} =
  ## Pop a free fixed file slot index. Raises IOError if none available.
  if u.fixedFileSlotsFree.len == 0:
    raise newException(IOError, "no free fixed file slots")
  result = u.fixedFileSlotsFree.pop()

proc freeFixedFileSlot*(u: UringFileIO, slot: int32) =
  ## Return a fixed file slot to the free pool.
  u.fixedFileSlotsFree.add(slot)

proc fixedFileSlotsAvailable*(u: UringFileIO): int =
  ## Return the number of free fixed file slots.
  u.fixedFileSlotsFree.len

# Direct descriptor operations

proc uringOpenDirect*(
    u: UringFileIO, path: string, flags: cint, mode: uint32, fileSlot: int32
): Future[int32] =
  ## Submit OPENAT operation that installs the fd directly into a fixed file slot.
  ## `fileSlot` is the 0-indexed slot from `allocFixedFileSlot`.
  ## CQE result: 0 on success (not an fd), negative errno on failure.
  let fut = newFuture[int32]("uringOpenDirect")

  if u.closed:
    fut.fail(
      if u.error != nil:
        u.error
      else:
        newException(IOError, "UringFileIO closed")
    )
    return fut

  let sqe = getSqe(u.ring)
  if sqe == nil:
    if u.chainActive:
      u.chainFailed = true
      u.chainFutures.add(fut)
      return fut
    fut.fail(newException(IOError, "io_uring SQ full"))
    return fut

  var pathRef: ref string
  new(pathRef)
  pathRef[] = path

  sqe.opcode = IORING_OP_OPENAT
  sqe.fd = AT_FDCWD
  sqe.`addr` = cast[uint64](pathRef[].cstring)
  sqe.len = uint32(mode)
  sqe.opFlags = cast[uint32](flags)
  sqe.spliceFdIn = fileSlot + 1 # 1-indexed: 0 means "normal fd"

  var comp = Completion(future: fut, kind: ckOpen, strRef: pathRef)
  return queueSqe(u, comp)

proc uringCloseDirect*(u: UringFileIO, fileSlot: int32): Future[int32] =
  ## Submit CLOSE operation on a direct descriptor slot.
  ## Closes the fd inside the slot and resets the slot to -1.
  ## CQE result: 0 on success, negative errno on failure.
  let fut = newFuture[int32]("uringCloseDirect")

  if u.closed:
    fut.fail(
      if u.error != nil:
        u.error
      else:
        newException(IOError, "UringFileIO closed")
    )
    return fut

  let sqe = getSqe(u.ring)
  if sqe == nil:
    if u.chainActive:
      u.chainFailed = true
      u.chainFutures.add(fut)
      return fut
    fut.fail(newException(IOError, "io_uring SQ full"))
    return fut

  sqe.opcode = IORING_OP_CLOSE
  sqe.fd = 0 # unused for direct close
  sqe.spliceFdIn = fileSlot + 1 # 1-indexed

  var comp = Completion(future: fut, kind: ckClose)
  return queueSqe(u, comp)
