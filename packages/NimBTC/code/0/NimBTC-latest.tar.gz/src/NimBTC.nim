import base64
import json
import jsony
import times
import strutils
import typetraits
import net
import std/options
import tables
import std/jsonutils
import puppy
type
  BTCResponse* = object
    errorMessage* : string
    errorCode* : RpcErrorCode
    hasResult* : bool
    resultObject* : JsonNode
  BTCClient* = object
    url : string
    auth : string

  SigHashType* = enum
    All = "ALL", None = "NONE", Single = "SINGLE"
  EstimateMode* = enum
    Unset = "unset", Economical = "economical", Conservative = "conservative"


  # See https://raw.githubusercontent.com/bitcoin/bitcoin/refs/heads/master/src/rpc/protocol.h
  # Slightly modified.
  RpcErrorCode* = enum
    RpcParseError = -32700
    RpcInternalError = -32603
    RpcInvalidParams = -32602
    RpcMethodNotFound = -32601
    RpcInvalidRequest = -32600
    RpcWalletAlreadyExists = -36
    RpcWalletAlreadyLoaded = -35
    RpcClientNodeCapacityReached = -34
    RpcClientMempoolDisabled = -33
    RpcMethodDeprecated = -32
    RpcClientP2pDisabled = -31
    RpcClientInvalidIpOrSubnet = -30
    RpcClientNodeNotConnected = -29
    RpcInWarmup = -28
    RpcVerifyAlreadyInUtxoSet = -27
    RpcRejected = -26
    RpcVerifyError = -25
    RpcClientNodeNotAdded = -24
    RpcClientNodeAlreadyAdded = -23

    RpcDeserializationError = -22

    RpcDatabaseError = -20

    RpcWalletNotSpecified = -19
    RpcWalletNotFound = -18
    RpcWalletAlreadyUnlocked = -17
    RpcWalletEncryptionFailed = -16
    RpcWalletWrongEncState = -15
    RpcWalletPassphraseIncorrect = -14

    RpcWalletUnlockNeeded = -13
    RpcWalletKeypoolRanOut = -12
    RpcWalletInvalidName = -11
    RpcClientInInitialDownload = -10
    RpcClientNotConnected = -9
    RpcInvalidParameter = -8
    RpcOutOfMemory = -7
    RpcWalletInsufficientFunds = -6
    RpcInvalidAddressOrKey = -5
    RpcWalletError = -4
    RpcTypeError = -3
    RpcForbiddenBySafeMode = -2
    RpcMiscError = -1

    RpcNoError = 0
  Verbosity* = enum
    LowVerbosity = 0, MediumVerbosity = 1, HighVerbosity = 2
  MemoryMode* = enum
    Stats = "stats",  MallocInfo = "mallocinfo"
  NodeCommand* = enum
    Add = "add", Remove = "remove", Onetry = "onetry"
  AddressType* = enum
    Legacy = "legacy", P2SH = "p2sh-segwit", BECH32 = "bech32"
  JsonStorable = concept
    func `%`(a : Self): JsonNode
    proc `%`(a : Self): JsonNode
  CanSerialize = concept
    proc `!`(a : Self): string

proc `!`(a : EstimateMode) : string =
  return $a

proc getOrNull[T](a : Option[T]) : JsonNode =
  when a.T isnot CanSerialize:
    {.error.}

  if a.isSome():
    let val = a.get()
    let string = $val
    return %val
  else:
    return newJNull()

proc seqToNode[T: JsonStorable](a : openArray[T]) : JsonNode =
  result = newJArray()
  for x in a:
    result.add(% x)

proc initParams(a: tuple) : JsonNode =
  result = newJArray()
  for x in a.fields:
    block add:
      when x is seq[JsonStorable]:
        result.add(seqToNode(x))
        break add
      else:
        when x is JsonStorable:
          result.add(% x)
        else:
          when x is Table:
            result.add(jsonutils.toJson x)
          else:
            when x is Option and x.T is JsonStorable or x is Option and x.T is seq[JsonStorable]:
              if x.isNone():
                result.add(newJNull())
              else:
                when x.T is seq[JsonStorable]:
                  result.add(seqToNode(x.get()))
                else:
                  result.add(% x.get())

            else:
              {.error: "Object type cannot be serialized into a JsonNode!".}

proc initBTCClient*(path, username, password : string) : BTCClient =

  let authy = encode(username & ":" & password)
  let headerTable = {
          "Authorization": "Basic" & " " & authy
        }

  result.auth = "Basic" & " " & authy
  result.url = path


let baseRequest = parseJson("""{
  "jsonrpc": "1.0",
}""" )

proc parseBTCResponse*(a : string) : BTCResponse =
  let jsonified = parseJson(a)
  if jsonified["error"].kind == JNull:
    result.errorCode = RpcNoError
  else:
    let errorValue = jsonified["error"]["code"].getInt()
    let error = RpcErrorCode(errorValue)
    let errorMessage = jsonified["error"]["message"].getStr()
    result.errorCode = error
    result.errorMessage = errorMessage

  if jsonified["result"].kind != JNull:
    result.resultObject = jsonified["result"]
    result.hasResult = true
  else:
    result.resultObject = newJNull()
    result.hasResult = false

proc isErr*(a : BTCResponse) : bool =
  ## shorthand BTCResponse.errorCode != RpcNoError
  a.errorCode != RpcNoError

proc isOk*(a : BTCResponse) : bool =
  ## shorthand BTCResponse.errorCode != RpcNoError
  a.errorCode == RpcNoError

proc callAPI(api : BTCClient, methody : string, body : JsonNode = newJNull()) : BTCResponse {.gcsafe.}=
  var baseRequest = newJObject()
  baseRequest["jsonrpc"] = %* "1.0"
  baseRequest["params"] = body
  baseRequest["method"] = %* methody
  baseRequest["id"] = %* $(now().utc.toTime().toUnix())
  #echo baseRequest
  let resultString = post(api.url, @[("Authorization", api.auth)], $baseRequest ).body
  #echo resultString
  return parseBTCResponse(resultString)

proc getBestBlockHash*(a : BTCClient) : BTCResponse =
  return callAPI(a, "getbestblockhash")

proc getBlock*(a : BTCClient, blockHash : string, verbosity = LowVerbosity) : BTCResponse =
  let params = initParams((blockHash, int(verbosity)))
  return callAPI(a, "getblock", params)

proc getBlockChainInfo*(a : BTCClient) : BTCResponse =
  return callAPI(a, "getblockchaininfo")


proc getBlockCount*(a : BTCClient) : BTCResponse =
  return callAPI(a, "getblockcount")


proc getBlockFilter*(a : BTCClient, blockHash : string, filterType = "basic") : BTCResponse =
  ##  Retrieve a BIP 157 content filter for a particular block.
  let params = initParams((blockHash, filterType))

  return callAPI(a, "getblockfilter", params)


proc getBlockHash*(a : BTCClient, height : uint) : BTCResponse =
  let params = initParams((height,))
  return callAPI(a, "getblockhash", params)

proc getBlockHeader*(a : BTCClient, hash : string, verbose : bool = true) : BTCResponse =
  let params = initParams((hash,verbose))
  return callAPI(a, "getblockheader", params)

proc getBlockStats*(a : BTCClient, HashOrHeight : string | uint) : BTCResponse =
  ##  Compute per block statistics for a given window. All amounts are in satoshis.
  ##  It won’t work for some heights with pruning.
  ##  I recommend using hashes and not height numbers
  let params = initParams((HashOrHeight,))
  return callAPI(a, "getblockstats", params)


proc getChainTips*(a : BTCClient) : BTCResponse =
  ##  Return information about all known tips in the block tree, including the main chain as well as orphaned branches.
  return callAPI(a, "getchaintips")



proc getChainTXStats*(a : BTCClient, nblocks : uint, endHash = "") : BTCResponse =
  ##  Compute statistics about the total number and rate of transactions in the chain.
  let params = initParams((nblocks,endHash))

  return callAPI(a, "getchaintxstats", params)



proc getDifficulty*(a : BTCClient) : BTCResponse =
  ## Returns the proof-of-work difficulty as a multiple of the minimum difficulty.

  return callAPI(a, "getdifficulty")


proc getMemPoolAncestors*(a : BTCClient, txid : string, verbose = false) : BTCResponse =
  ## If txid is in the mempool, returns all in-mempool ancestors.

  let params = initParams((txid,verbose))
  return callAPI(a, "getmempoolancestors", params)

proc getMemPoolDescendants*(a : BTCClient, txid : string, verbose = false) : BTCResponse =
  ##  If txid is in the mempool, returns all in-mempool descendants.

  let params = initParams((txid,verbose))
  return callAPI(a, "getmempooldescendants", params)


proc getMemPoolEntry*(a : BTCClient, txid : string) : BTCResponse =
  ##  Returns mempool data for given transaction

  let params = initParams((txid,))
  return callAPI(a, "getmempoolentry", params)


proc getMemPoolInfo*(a : BTCClient) : BTCResponse =
  ##  Returns details on the active state of the TX memory pool.

  return callAPI(a, "getmempoolinfo" )

proc getRawMemPool*(a : BTCClient, verbose = false, memPoolSequence = false) : BTCResponse =
  ##  Returns all transaction ids in memory pool as a json array of string transaction ids.

  let params = initParams((verbose,memPoolSequence))
  return callAPI(a, "getrawmempool", params)



proc getTxOut*(a : BTCClient, txid : string, n : uint, includeMemPool = false) : BTCResponse =
  ##  Returns details about an unspent transaction output.

  let params = initParams((txid,n,includeMemPool))
  return callAPI(a, "gettxout", params)

proc getTxOutProof*(a : BTCClient, txids : seq[string], hash : string = "") : BTCResponse =
  ##  Returns a hex-encoded proof that “txid” was included in a block.

  let params = initParams((txids,hash))
  return callAPI(a, "gettxoutproof", params)


proc getTxOutSetInfo*(a : BTCClient, hashType = "none") : BTCResponse =
  ##  Returns statistics about the unspent transaction output set.

  let params = initParams((hashType,))
  return callAPI(a, "gettxoutsetinfo", params)


proc setPreciousBlock*(a : BTCClient, blockhash : string) : BTCResponse =
  ##Treats a block as if it were received before others with the same work.
  ##A later preciousblock call can override the effect of an earlier one
  ##The effects of preciousblock are not retained across restarts.

  let params = initParams((blockhash,))
  return callAPI(a, "preciousblock", params)

proc pruneBlockChain*(a : BTCClient, endHeightOrTime : uint) : BTCResponse =
  ## The block height to prune up to. May be set to a discrete height, or to a UNIX epoch time
  ##  to prune blocks whose block time is at least 2 hours older than the provided timestamp.

  let params = initParams((endHeightOrTime,))
  return callAPI(a, "pruneblockchain", params)


proc saveMemPool*(a : BTCClient) : BTCResponse =
  ## The block height to prune up to. May be set to a discrete height, or to a UNIX epoch time
  ##  to prune blocks whose block time is at least 2 hours older than the provided timestamp.

  return callAPI(a, "savemempool")

proc verifyChain*(a : BTCClient, checklevel : uint, nblocks : uint) : BTCResponse =
  ##  Verifies blockchain database.
  ## MUST READ! https://developer.bitcoin.org/reference/rpc/verifychain.html

  let params = initParams((checklevel,nblocks))
  return callAPI(a, "verifychain", params)


proc verifyTxOutProof*(a : BTCClient, txProof : string) : BTCResponse =
  ## Verifies that a proof points to a transaction in a block,
  ## returning the transaction it commits to and throwing an
  ## RPC error if the block is not in our best chain

  let params = initParams((txProof,))
  return callAPI(a, "verifytxoutproof", params)

# Control RPC functions

proc getMemoryInfo*(a : BTCClient, mode : MemoryMode) : BTCResponse =
  let params = initParams(($mode,))
  return callAPI(a, "getmemoryinfo", params)

proc getRpcInfo*(a : BTCClient) : BTCResponse =
  return callAPI(a, "getrpcinfo")

proc help*(a : BTCClient, commandName : string) : BTCResponse =
  let params = initParams((commandName,))
  return callAPI(a, "help", params)

proc stop*(a : BTCClient) : BTCResponse=
  return callAPI(a, "stop")


proc uptime*(a : BTCClient) : BTCResponse=
  return callAPI(a, "uptime")

# Generating RPCs

proc generateBlock*(a : BTCClient, outputBtcAddress : string,  transactionsToMine : seq[string]) : BTCResponse =
  ##  Mine a block with a set of ordered transactions immediately to a specified address or descriptor (before the RPC call returns)
  ##  Txids must reference transactions currently in the mempool. All transactions must be valid and in valid order, otherwise the block will be rejected.

  let params = initParams((outputBtcAddress,transactionsToMine))
  return callAPI(a, "generateblock", params)

proc generateToAddress*(a : BTCClient, nblocks : uint, address : string, nmatrix : uint = 1000000) : BTCResponse =
  ##  Mine blocks immediately to a specified address (before the RPC call returns)

  let params = initParams((nblocks,address, nmatrix))
  return callAPI(a, "generatetoaddress", params)

proc generateToDescriptor*(a : BTCClient, nblocks : uint, descriptor  : string, nmatrix : uint = 1000000) : BTCResponse =
  ##  Mine blocks immediately to a specified descriptor (before the RPC call returns)

  let params = initParams((nblocks, descriptor, nmatrix))
  return callAPI(a, "generatetodescriptor", params)


proc getMiningInfo*(a : BTCClient) : BTCResponse =
  return callAPI(a, "getmininginfo")

proc getNetworkHashPS*(a : BTCClient, nblock : uint, startHeight : int = -1) : BTCResponse =
  ##  Returns the estimated network hashes per second based on the last n blocks.
  ##  Pass in [blocks] to override # of blocks, -1 specifies since last difficulty change.

  let params = initParams((nblock,startHeight))
  return callAPI(a, "getnetworkhashps", params)

proc prioritiseTransaction*(a : BTCClient, txid : string, deltaSatoshi : uint) : BTCResponse =
  ##  Returns the estimated network hashes per second based on the last n blocks.
  ##  Pass in [blocks] to override # of blocks, -1 specifies since last difficulty change.

  let params = initParams((txid,deltaSatoshi))
  return callAPI(a, "prioritisetransaction", params)

proc submitBlock*(a : BTCClient, hexData : string) : BTCResponse  =
  ##  Attempts to submit new block to network.
  ##  See https://en.bitcoin.it/wiki/BIP_0022 for full specification.

  let params = initParams((hexData,))
  return callAPI(a, "submitblock", params)


proc submitHeader*(a : BTCClient, hexData : string) : BTCResponse  =
  ## Decode the given hexdata as a header and submit it as a candidate chain tip if valid.
  let params = initParams((hexData,))
  return callAPI(a, "submitheader", params)

proc addNode*(a : BTCClient, ip : IpAddress, port : Port, nodeCommand : NodeCommand) : BTCResponse  =
  ##  Attempts to add or remove a node from the addnode list.
  ##  Or try a connection to a node once.
  ##  Nodes added using addnode (or -connect) are protected from DoS disconnection and are not required to be full nodes/support SegWit as other outbound peers are (though such peers will not be synced from).

  let ipPort = $ip & ":" & $port
  let params = initParams((ipPort,$nodeCommand))
  return callAPI(a, "addnode", params)

proc addNode*(a : BTCClient, ipPort : string, nodeCommand : NodeCommand) : BTCResponse  =
  ##  Attempts to add or remove a node from the addnode list.
  ##  Or try a connection to a node once.
  ##  Nodes added using addnode (or -connect) are protected from DoS disconnection and are not required to be full nodes/support SegWit as other outbound peers are (though such peers will not be synced from).

  let params = initParams((ipPort,$nodeCommand))
  return callAPI(a, "addnode", params)

proc clearBanned*(a : BTCClient) : BTCResponse   =
  ##  Clears all banned IPs

  return callAPI(a, "clearbanned")

proc disconnectNode*(a : BTCClient, ip : IpAddress, port : Port) : BTCResponse   =
  let ipPort = $ip & ":" & $port
  let params = initParams((ipPort,))
  return callAPI(a, "disconnectnode", params)


proc disconnectNode*(a : BTCClient, ipPort : string) : BTCResponse   =
  let params = initParams((ipPort,))
  return callAPI(a, "disconnectnode", params)


proc getAddedNodeInfo*(a : BTCClient, ip : IpAddress, port : Port) : BTCResponse  =
  let ipPort = $ip & ":" & $port
  let params = initParams((ipPort,))
  return callAPI(a, "getaddednodeinfo", params)

proc getAddedNodeInfo*(a : BTCClient) : BTCResponse  =
  ## Returns information about the given added node, or all added nodes (note that onetry addnodes are not listed here)
  let params = initParams(("",))

  return callAPI(a, "getaddednodeinfo", params)

proc getConnectionCount*(a : BTCClient) : BTCResponse =
  return callAPI(a, "getconnectioncount")

proc getNetTotals*(a : BTCClient) : BTCResponse =
  ##  Returns information about network traffic, including bytes in, bytes out, and current time.
  return callAPI(a, "getnettotals")


proc getNetworkInfo*(a : BTCClient) : BTCResponse =
  ##  Returns an object containing various state info regarding P2P networking.

  return callAPI(a, "getnetworkinfo")


proc getNodeAddresses*(a : BTCClient, n : uint = 1 ) : BTCResponse =
  ##  Return known addresses which can potentially be used to find new nodes in the network
  let params = initParams((n,))

  return callAPI(a, "getnodeaddresses", params)

proc getPeerInfo*(a : BTCClient) : BTCResponse =
  ##  Returns info on peer connections
  return callAPI(a, "getpeerinfo")

proc listBanned*(a : BTCClient) : BTCResponse =
  ##  lists banned connections
  return callAPI(a, "listbanned")

proc ping*(a : BTCClient) : BTCResponse =
  ##  Return known addresses which can potentially be used to find new nodes in the network
  return callAPI(a, "ping")


proc setBan*(a: BTCClient, ip : string | IpAddress, command : NodeCommand, lengthOfBan : uint, isAbsolute = false ) : BTCResponse =
  ##  Attempts to add or remove an IP/Subnet from the banned list.
  ##  Takes subnet in the string form. e.g 127.0.0.1/42
  ##  Does not take ports!
  ##  see: https://developer.bitcoin.org/reference/rpc/setban.html
  let ipString =
    when ip is string:
      ip
    else:
      $ip
  let params = initParams((ipString, $command, isAbsolute))
  return callAPI(a, "setban", params)

proc setNetworkActive*(a : BTCClient, active = true) : BTCResponse =
  ##  Disable/enable all p2p network activity.
  let params = initParams((active,))
  return callAPI(a, "setnetworkactive", params)

proc analyzePSBT*(a : BTCClient, psbt : string) : BTCResponse =
  ##  Analyzes and provides information about the current status of a PSBT and its inputs.
  let params = initParams((psbt,))
  return callAPI(a, "analyzepsbt", params)


proc combinePSBT*(a : BTCClient, tx : seq[string]) : BTCResponse =
  ##  Combine multiple partially signed Bitcoin transactions into one transaction.

  let params = initParams((tx,))
  return callAPI(a, "combinepsbt", params)

proc convertToPSBT*(a : BTCClient, hexstring : string, looseSigs = false) : BTCResponse =
  ##  Converts a network serialized transaction to a PSBT.
  ##  This should be used only with createrawtransaction and fundrawtransaction createpsbt and walletcreatefundedpsbt should be used for new applications..

  let params = initParams((hexstring,looseSigs))
  return callAPI(a, "converttopsbt", params)

proc createPSBT*(a : BTCClient, inputs : JsonNode, outputs : JsonNode, locktime : uint = 0, replaceable = false) : BTCResponse =
  ##  Converts a network serialized transaction to a PSBT.
  ##  This should be used only with createrawtransaction and fundrawtransaction createpsbt and walletcreatefundedpsbt should be used for new applications..

  let params = initParams((inputs,outputs,locktime,replaceable))
  return callAPI(a, "createpsbt", params)

proc createRawTransaction*(a : BTCClient, inputs : JsonNode, outputs : JsonNode, locktime : uint = 0, replaceable = false) : BTCResponse =
  ##  Converts a network serialized transaction to a PSBT.
  ##  This should be used only with createrawtransaction and fundrawtransaction createpsbt and walletcreatefundedpsbt should be used for new applications..

  let params = initParams((inputs,outputs))
  return callAPI(a, "createrawtransaction", params)

proc decodePSBT*(a : BTCClient, psbt : string) : BTCResponse =
  ##  Converts a network serialized transaction to a PSBT.
  let params = initParams((psbt,))
  return callAPI(a, "decodepsbt", params)


proc decodeRawTransaction*(a : BTCClient, rawtransaction : string, overrideIsWitness = false, isWitness = true) : BTCResponse =
  ##  Return a JSON object representing the serialized, hex-encoded transaction.
  ##  see: https://developer.bitcoin.org/reference/rpc/decoderawtransaction.html
  let params =
    if overrideIsWitness:
      initParams((rawtransaction,isWitness))
    else:
      initParams((rawtransaction,))

  return callAPI(a, "decoderawtransaction", params)


proc decodeScript*(a : BTCClient, script : string) : BTCResponse =
  ##  Decode a hex-encoded script.
  let params = initParams((script,))
  return callAPI(a, "decodescript", params)

proc finalizePSBT*(a : BTCClient, psbt : string, extract = true) : BTCResponse =
  ##  Finalize the inputs of a PSBT. If the transaction is fully signed,
  ##  it will produce a network serialized transaction which can
  ##  be broadcast with sendrawtransaction. Otherwise a PSBT will be
  ##  created which has the final_scriptSig and final_scriptWitness fields
  ##  filled for inputs that are complete.
  let params = initParams((psbt,extract))
  return callAPI(a, "finalizepsbt", params)

proc fundRawTransaction*(a : BTCClient, rawTxString : string, options : JsonNode = newJNull()) : BTCResponse =
  ##see: https://developer.bitcoin.org/reference/rpc/fundrawtransaction.html
  let params = initParams((rawTxString,options))
  return callAPI(a, "fundrawtransaction", params)

proc getRawTransaction*(a : BTCClient, txid : string, verbose = false, blockhash : Option[string] = none[string]()) : BTCResponse =
  ##see: https://developer.bitcoin.org/reference/rpc/fundrawtransaction.html
  let params = initParams((txid,verbose, blockhash))
  return callAPI(a, "getrawtransaction", params)

proc joinPSBTS*(a : BTCClient, txids : seq[string]) : BTCResponse =
  ## Joins multiple distinct PSBTs with different inputs and outputs into one PSBT
  ## with inputs and outputs from all of the PSBTs
  ## No input in any of the PSBTs can be in more than one of the PSBTs.

  let params = initParams((txids,))
  return callAPI(a, "joinpsbts", params)

proc sendRawTransaction*(a : BTCClient, rawTransaction : string, maxFeeRate : float = 0.10) : BTCResponse =
  ##  Note that the transaction will be sent unconditionally to all peers, so using
  ##  this for manual rebroadcast may degrade privacy by leaking the transaction’s
  ##  origin, as nodes will normally not rebroadcast non-wallet transactions
  ##  already in their mempool.

  let params = initParams((rawTransaction,maxFeeRate))
  return callAPI(a, "sendrawtransaction", params)

proc signRawTransactionWithKey*(
          a : BTCClient,
          rawTransaction : string, privateKeys : seq[string],
          prevtxs : JsonNode = newJNull(), sigHashType : SigHashType = All
          ) : BTCResponse =
  ##  Sign inputs for raw transaction (serialized, hex-encoded).

  let params = initParams((rawTransaction,privateKeys,prevtxs,$sigHashType))
  return callAPI(a, "signrawtransactionwithkey", params)

proc testMempoolAccept*(
          a : BTCClient,
          rawTxs : seq[string], maxFeeRate = 0.10,
          ) : BTCResponse =
  ##  Returns result of mempool acceptance tests indicating if raw transaction
  ## (serialized, hex-encoded) would be accepted by mempool.

  let params = initParams((rawTxs,maxfeerate))
  return callAPI(a, "testmempoolaccept", params)

proc utxOupdatePSBT*(a : BTCClient, psbt : string, descriptors : JsonNode = newJNull()) : BTCResponse =

  ##  Updates all segwit inputs and outputs in a PSBT with data from output descriptors, the UTXO set or the mempool.

  let params = initParams((psbt,descriptors))
  return callAPI(a, "utxoupdatepsbt", params)

proc createMultiSig*(a : BTCClient, nSigs : uint, pubKeys : seq[string], addressType = Legacy) : BTCResponse =
  ##  Creates a multi-signature address with n signature of m keys required.
  let params = initParams((nSigs,pubKeys,$addressType))
  return callAPI(a, "createmultisig", params)

proc deriveAddresses*(a : BTCClient, descriptor : string, start : uint, ending : uint) : BTCResponse =
  ##  Derives one or more addresses corresponding to an output descriptor.
  let params = initParams((descriptor,@[start,ending]))
  return callAPI(a, "deriveaddresses", params)

proc estimateSmartFee*(a : BTCClient, confTargetNBlocks : uint, estimateMode : Option[EstimateMode]) : BTCResponse =
  ##	Estimates the approximate fee per kilobyte needed for a transaction to
  ##	begin confirmation within conf_target blocks if possible and return the
  ##	number of blocks for which the estimate is valid. Uses virtual transaction
  ##	size as defined in BIP 141 (witness data is discounted).

  let params = initParams((confTargetNBlocks, getOrNull estimateMode))
  return callAPI(a, "estimatesmartfee", params)


proc getDescriptorInfo*(a : BTCClient, descriptor : string) : BTCResponse =
  let params = initParams((descriptor,))
  return callAPI(a, "getdescriptorinfo", params)


proc getIndexInfo*(a : BTCClient, indexName : string) : BTCResponse =
  let params = initParams((indexName,))
  return callAPI(a, "getindexinfo", params)

proc signMessageWithPrivKey*(a : BTCClient, privateKey : string, message : string) : BTCResponse =
  let params = initParams((privateKey,message))
  return callAPI(a, "signmessagewithprivkey", params)

proc validateAddress*(a : BTCClient, publicAddress : string) : BTCResponse {.gcsafe.} =
  let params = initParams((publicAddress,))
  return callAPI(a, "validateaddress", params)

proc verifyMessage*(a : BTCClient, publicAddress : string, signature : string) : BTCResponse =
  ##	Verify a signed message

  let params = initParams((publicAddress,))
  return callAPI(a, "validateaddress", params)

## Wallet RPC commands
##
proc abandonTransaction*(a : BTCClient, txid : string) : BTCResponse =
  ## Mark in-wallet transaction <txid> as abandoned This will mark this
  ## transaction and all its in-wallet descendants as abandoned which
  ## will allow for their inputs to be respent.
  ## It can be used to replace “stuck” or evicted transactions.

  let params = initParams((txid,))
  return callAPI(a, "abandontransaction", params)

proc abortRescan*(a : BTCClient) : BTCResponse =
  ##  Stops current wallet rescan triggered by an RPC call,
  ##  e.g. by an importprivkey call.
  return callAPI(a, "abortrescan")


proc addMultiSigAddress*(a : BTCClient, nrequired : uint, publicKeys : seq[string], label : Option[string], addressType : AddressType) : BTCResponse =
  ##  Add an nrequired-to-sign multisignature address to the wallet.
  let params = initParams((nrequired,publicKeys,label,$addressType))
  return callAPI(a, "addmultisigaddress", params)


proc backupWallet*(a : BTCClient, destination : string) : BTCResponse =
  ##  Safely copies current wallet file to destination,
  ##  which can be a directory or a path with filename.
  let params = initParams((destination,))
  return callAPI(a, "backupwallet", params)

proc bumpFee*(a : BTCClient, txid : string, options : JsonNode) : BTCResponse =
  ## see: https://developer.bitcoin.org/reference/rpc/bumpfee.html
  let params = initParams((txid,options))
  return callAPI(a, "bumpfree", params)

proc createWallet*(a : BTCClient,
            walletName : string, disablePrivateKeys = false, blank = false,
            passphrase : Option[string] = none[string](),
            avoidReuse = false, descriptors = true, loadOnStartup = false) : BTCResponse =
  ##  Creates and loads a new wallet.
  let params = initParams((walletName,disablePrivateKeys, blank, passphrase, avoidReuse, descriptors, loadOnStartup))
  return callAPI(a, "createwallet", params)

proc dumpWallet*(a : BTCClient, outFilePath : string) : BTCResponse =
  let params = initParams((outFilePath,))
  return callAPI(a, "dumpwallet", params)

proc dumpPrivKey*(a : BTCClient, address : string) : BTCResponse =
  let params = initParams((address,))
  return callAPI(a, "dumpprivkey", params)

proc encryptWallet*(a : BTCClient, passphrase : string) : BTCResponse =
  ##  Encrypts the wallet with ‘passphrase’. This is for first time encryption.
  ##  After this, any calls that interact with private keys such as sending or
  ##  signing will require the passphrase to be set prior the making these calls.
  ##  Use the walletpassphrase call for this, and then walletlock call.
  ##  If the wallet is already encrypted, use the walletpassphrasechange call.
  let params = initParams((passphrase,))
  return callAPI(a, "encryptwallet", params)

proc getAddressesByLabel*(a : BTCClient, label = "") : BTCResponse =
  let params = initParams((label,))
  return callAPI(a, "getaddressesbylabel", params)

proc getAddressinfo*(a : BTCClient, Address : string) : BTCResponse =
  let params = initParams((Address,))
  return callAPI(a, "getaddressinfo", params)

proc getBalance*(a : BTCClient,
        minConfimed : uint = 0, includeWatchOnly : Option[bool] = none[bool](), avoidReuse : Option[bool] = none[bool]()) : BTCResponse =
  let params = initParams(("*",minConfimed, includeWatchOnly, avoidReuse))
  return callAPI(a, "getbalance", params)

proc getBalances*(a : BTCClient) : BTCResponse =
  return callAPI(a, "getbalances")

proc getNewAddress*(a : BTCClient, label : string, addressType = Legacy) : BTCResponse =
  ##  Returns a new Bitcoin address, for receiving change.
  let params = initParams((label,$addressType))
  return callAPI(a, "getnewaddress",params)


proc getRawChangeAddress*(a : BTCClient, addressType = Legacy) : BTCResponse =
  ##  Returns a new Bitcoin address, for receiving change.
  ##  This is for use with raw transactions, NOT normal use.
  let params = initParams(($addressType,))
  return callAPI(a, "getrawchangeaddress", params)

proc getreceivedbyaddress*(a : BTCClient, address : string, minConfirmed : uint = 1) : BTCResponse =
  let params = initParams((address,minConfirmed))
  return callAPI(a, "getreceivedbyaddress", params)

proc getReceivedByLabel*(a : BTCClient, label : string, minConfirmed : uint = 1) : BTCResponse =
  let params = initParams((label,minConfirmed))
  return callAPI(a, "getreceivedbylabel", params)

proc getTransaction*(a : BTCClient, txid : string, includeWatchOnly = true, verbose = false) : BTCResponse =
  let params = initParams((txid,includeWatchOnly,verbose))
  return callAPI(a, "gettransaction", params)

proc getUnconfirmedBalance*(a : BTCClient) : BTCResponse =
  return callAPI(a, "getunconfirmedbalance")

proc getWalletInfo*(a : BTCClient) : BTCResponse =
  return callAPI(a, "getwalletinfo")

proc importAddress*(a : BTCClient, address : string,
                  label : Option[string] = none[string](),
                  rescan = true, p2sh = false) : BTCResponse =
  ## Adds an address or script (in hex) that can be watched as if it were in your wallet
  ## but cannot be used to spend. Requires a new wallet backup.
  let params = initParams((address,label,rescan,p2sh))
  return callAPI(a, "importaddress", params)

proc importDescriptors*(a : BTCClient, data : JsonNode) : BTCResponse =
  ##  see: https://developer.bitcoin.org/reference/rpc/importdescriptors.html
  let params = initParams((data,))
  return callAPI(a, "importdescriptors", params)


proc importMulti*(a : BTCClient, requests : JsonNode, options : JsonNode) : BTCResponse =
  ##  see: https://developer.bitcoin.org/reference/rpc/importmulti.html
  let params = initParams((requests,options))
  return callAPI(a, "importmulti", params)


proc importPrivKey*(a : BTCClient, privKey : string,
                  label : Option[string] = none[string](),
                  rescan = true) : BTCResponse =
  let params = initParams((privKey,label,rescan))
  return callAPI(a, "importprivkey", params)


proc importPrunedFunds*(a : BTCClient, rawTransaction : string, txoutproof : string) : BTCResponse =
  let params = initParams((rawTransaction,txoutproof))
  return callAPI(a, "importprunedfunds", params)

proc importPubKey*(a : BTCClient, pubKey : string,
                  label : Option[string] = none[string](),
                  rescan = true) : BTCResponse =
  let params = initParams((pubKey,label,rescan))
  return callAPI(a, "importpubkey", params)


proc importWallet*(a : BTCClient, filePath : string) : BTCResponse =
  let params = initParams((filePath,))
  return callAPI(a, "importwallet", params)

proc keyPoolRefill*(a : BTCClient, newSize : uint = 100) : BTCResponse =
  let params = initParams((newSize,))
  return callAPI(a, "keypoolrefill", params)

proc listAddressGroupings*(a : BTCClient) : BTCResponse =
  return callAPI(a, "listaddressgroupings")

proc listLabels*(a : BTCClient) : BTCResponse =
  return callAPI(a, "listlabels")

proc listLockUnspent*(a : BTCClient) : BTCResponse =
  return callAPI(a, "listlockunspent")

proc listReceivedByAddress*(a : BTCClient, minconf : uint = 1, includeEmpty = false, includeWatchonly = false, addressFilter : Option[string] = none[string]()) : BTCResponse =
  let params = initParams((minconf,includeEmpty,includeWatchonly,addressFilter))
  return callAPI(a, "listreceivedbyaddress", params)

proc listReceivedByLabel*(a : BTCClient, minconf : uint = 1, includeEmpty = false, includeWatchonly = false, addressFilter : Option[string] = none[string]()) : BTCResponse =
  let params = initParams((minconf,includeEmpty,includeWatchonly,addressFilter))
  return callAPI(a, "listreceivedbylabel", params)


proc listSinceBlock*(a : BTCClient, blockhash : string,
        targetConfirmations : uint = 1, includeWatchonly = true, includeRemoved = true) : BTCResponse =

  let params = initParams((blockhash,targetConfirmations,includeWatchonly,includeRemoved))
  return callAPI(a, "listsinceblock", params)

proc listTransactions*(a : BTCClient,
        label : Option[string] = none[string](), maxTransactions : uint = 10,
        skip : uint = 0, includeWatchonly = true) : BTCResponse =

  ##  If a label name is provided, this will return only incoming
  ##  transactions paying to addresses with the specified label.
  let params = initParams((label, maxTransactions,skip,includeWatchonly))
  return callAPI(a, "listsinceblock", params)


proc listUnspent*(a : BTCClient,
        minconf : uint = 1, maxconf : uint = 9999999,
        addresses : Option[seq[string]] = none[seq[string]](),
        includeUnsafe = true, queryOptions = newJNull()) : BTCResponse =

  ##  If a label name is provided, this will return only incoming
  ##  transactions paying to addresses with the specified label.
  let params = initParams((minconf, maxconf,addresses,includeUnsafe,queryOptions))
  return callAPI(a, "listsinceblock", params)

proc listWalletDir*(a : BTCClient) : BTCResponse =
  return callAPI(a, "listwalletdir")

proc listWallets*(a : BTCClient) : BTCResponse =
  return callAPI(a, "listwallets")

proc loadWallet*(a : BTCClient, walletPath : string, loadOnStartup = false) : BTCResponse =
  let params = initParams((walletPath, loadOnStartup))
  return callAPI(a, "loadwallet", params)

proc lockUnspent*(a : BTCClient, unlock : bool, transactions : JsonNode) : BTCResponse =
  let params = initParams((unlock, transactions))
  return callAPI(a, "lockunspent", params)

proc psbtBumpFee*(a : BTCClient, txid : string, options : JsonNode) : BTCResponse =
  #see: https://developer.bitcoin.org/reference/rpc/psbtbumpfee.html
  let params = initParams((txid, options))
  return callAPI(a, "psbtbumpfee", params)


proc removePrunedFunds*(a : BTCClient, txid : string, options : JsonNode) : BTCResponse =
  let params = initParams((txid, options))
  return callAPI(a, "removeprunedfunds", params)


proc rescanBlockChain*(a : BTCClient, startHeight, endHeight : uint) : BTCResponse =
  let params = initParams((startHeight, endHeight))
  return callAPI(a, "rescanblockchain", params)

proc send*(a : BTCClient, outputs : Table[string, float],
            confTarget : Option[uint] = none[uint](), estimateMode : Option[EstimateMode] = some(Unset),
            feeRate : Option[float] = none[float](), options : JsonNode = newJNull()) : BTCResponse =
  ##  see: https://developer.bitcoin.org/reference/rpc/send.html
  let params = initParams((outputs, confTarget, getOrNull(estimateMode), feeRate,options))
  return callAPI(a, "send", params)


proc sendMany*(a : BTCClient, outputs : Table[string, float],
            comment : Option[string] = none[string](),
            addressToSubtractFeesFrom : Option[seq[string]] = none[seq[string]](),
            replacable : Option[bool] = none[bool](),
            confTarget : Option[uint] = none[uint](),
            estimateMode : Option[EstimateMode] = some(Unset),
            feeRate : Option[float] = none[float](),
            verbose : bool = false
          ) : BTCResponse =
  ##  see: https://developer.bitcoin.org/reference/rpc/sendmany.html
  let params = initParams(("",
    outputs, 0, comment, addressToSubtractFeesFrom,
    replacable, confTarget, getOrNull(estimateMode), feeRate, verbose  ))
  return callAPI(a, "sendMany", params)

proc sendToAddress*(a : BTCClient, address : string, amount : float,
                    comment : Option[string] = none[string](),
                    commentTo : Option[string] = none[string](),
                    subtractFeeFromAmountSent = false,
                    replacable : Option[bool] = none[bool](),
                    confTarget : Option[bool] = none[bool](),
                    estimateMode : Option[EstimateMode] = some(Unset),
                    avoidReuse = false
                ) : BTCResponse =
  let params = initParams((
    address, amount, comment, commentTo,
    subtractFeeFromAmountSent, replacable, confTarget, getOrNull estimateMode, avoidReuse ))
  return callAPI(a, "sendtoaddress", params)

proc setHDSeed*(a : BTCClient, newKeyPool = true, seed : Option[string] = none[string]()) : BTCResponse =
  ##  DEPRECATED
  ## see: https://developer.bitcoin.org/reference/rpc/sethdseed.html

  let params = initParams((newKeyPool, seed))
  return callAPI(a, "sethdseed", params)

proc setLabel*(a : BTCClient, address : string, label : string) : BTCResponse =
  let params = initParams((address, label))
  return callAPI(a, "setlabel", params)


proc setTXFee*(a : BTCClient, amount : uint64) : BTCResponse =
  ##  Set the transaction fee per kB for this wallet.
  ##  Overrides the global -paytxfee command line parameter.

  let params = initParams((amount,))
  return callAPI(a, "settxfee", params)

proc setWalletFlag*(a : BTCClient, flag : string, value : bool) : BTCResponse =
  ##  Change the state of the given wallet flag for a wallet.
  let params = initParams((flag,value))
  return callAPI(a, "setwalletflag", params)

proc signMessage*(a : BTCClient, address : string, message : string) : BTCResponse =
  ##  Sign a message with the private key of an address Requires wallet passphrase
  ##  to be set with walletpassphrase call if wallet is encrypted.
  let params = initParams((address,message))
  return callAPI(a, "signmessage", params)


proc signRawTransactionWithWallet*(a : BTCClient,
      hexString : string, prevTxs : JsonNode = newJNull(),
      sigHashType : SigHashType = All) : BTCResponse =
  ##  Sign a message with the private key of an address. Requires wallet with passphrase
  ##  to be set with walletpassphrase call if wallet is encrypted.
  let params = initParams((hexString,prevTxs,$sigHashType))
  return callAPI(a, "signrawtransactionwithwallet", params)

proc unloadWallet*(a : BTCClient, walletName : string, loadOnStartup = false) : BTCResponse =
  let params = initParams((walletName, loadOnStartup))
  return callAPI(a, "unloadwallet", params)

proc upgradeWallet*(a : BTCClient, version : uint,) : BTCResponse =
  let params = initParams((version,))
  return callAPI(a, "upgradeWallet", params)

proc walletCreateFundedPSBT*(
    a : BTCClient, inputs : JsonNode,
    outputs : Table[string,uint], locktime : uint = 0,
    options : JsonNode = newJNull()): BTCResponse =

    let params = initParams((inputs,outputs,locktime,options))
    return callAPI(a, "walletcreatefundedpsbt", params)

proc walletLock*(a : BTCClient) : BTCResponse =
  return callAPI(a, "walletlock")


proc walletPassphrase*(a : BTCClient, passphrase : string, timeout : uint) : BTCResponse =
  let params = initParams((passphrase,timeout))
  return callAPI(a, "walletpassphrase", params)


proc walletPassphraseChange*(a : BTCClient, oldpassphrase : string, newpassphrase : string) : BTCResponse =
  let params = initParams((oldpassphrase,newpassphrase))
  return callAPI(a, "walletpassphrasechange", params)

proc walletProcessPSBT*(a : BTCClient,
                psbt : string, sign = true, sigHashType : SigHashType = All,
                bip32derivs = true) : BTCResponse =

  let params = initParams((psbt, sign, $sigHashType, bip32derivs ))
  return callAPI(a, "walletprocesspsbt", params)
