include bunnery

echo nimJsBuildCmd("src/main.nim")
