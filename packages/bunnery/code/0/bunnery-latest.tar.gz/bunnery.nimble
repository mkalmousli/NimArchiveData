version       = "0.3.0"
author        = "Jaremy Creechley"
description   = "bun helper scripts"
license       = "BSD-2-Clause"
srcDir        = "src"

