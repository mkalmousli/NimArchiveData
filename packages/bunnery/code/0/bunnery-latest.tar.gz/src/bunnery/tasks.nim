import ./build
import strutils

proc envOrDefault(name: string, defaultValue: string): string =
  result = getEnv(name)
  if result.len == 0:
    result = defaultValue

proc envCsv(name: string): seq[string] =
  let raw = getEnv(name).strip()
  if raw.len == 0:
    return @[]
  for token in raw.split(","):
    let path = token.strip()
    if path.len > 0:
      result.add(path)

task bunBuild, "Build Nim JS and bundle it with Bun":
  let nimEntry = envOrDefault("BUNNERY_NIM_ENTRY", "src/main.nim")
  let nimJsOut = getEnv("BUNNERY_NIM_JS_OUT")
  let bundleOut = getEnv("BUNNERY_BUNDLE_OUT")
  let cssEntries = envCsv("BUNNERY_CSS_ENTRIES")
  let nimFlags = getEnv("BUNNERY_NIM_FLAGS")
  let bunFlags = getEnv("BUNNERY_BUN_FLAGS")
  let resolvedNimJsOut =
    if nimJsOut.strip().len > 0:
      nimJsOut
    else:
      defaultNimJsOut(nimEntry)
  let resolvedBundleOut =
    if bundleOut.strip().len > 0:
      bundleOut
    else:
      defaultBundleOut(resolvedNimJsOut)
  discard buildNimAndBundleJs(
    nimEntry = nimEntry,
    nimJsOut = nimJsOut,
    bundleOut = bundleOut,
    cssEntries = cssEntries,
    nimFlags = nimFlags,
    bunFlags = bunFlags,
  )
  echo "bunBuild output: " & resolvedBundleOut

task bunCombine, "Bundle a prebuilt Nim JS output with additional JS":
  let prebuiltNimJs = envOrDefault("BUNNERY_PREBUILT_NIM_JS", "build/app.nim.js")
  let appJsEntry = envOrDefault("BUNNERY_APP_JS_ENTRY", "src/app.js")
  let bundleOut = getEnv("BUNNERY_BUNDLE_OUT")
  let cssEntries = envCsv("BUNNERY_CSS_ENTRIES")
  let bunFlags = getEnv("BUNNERY_BUN_FLAGS")
  let resolvedBundleOut =
    if bundleOut.strip().len > 0:
      bundleOut
    else:
      defaultBundleOut(prebuiltNimJs)
  discard combinePrebuiltNimJs(
    prebuiltNimJs = prebuiltNimJs,
    appJsEntry = appJsEntry,
    bundleOut = bundleOut,
    cssEntries = cssEntries,
    bunFlags = bunFlags,
  )
  echo "bunCombine output: " & resolvedBundleOut

