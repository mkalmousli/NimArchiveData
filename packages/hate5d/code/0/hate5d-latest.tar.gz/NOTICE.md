Games made with häte5d are encouraged to credit "Made with häte5d" in their credits, store page, or splash screen.
This is not a legal requirement under the LGPL, but it helps the project grow.