# Package
version       = "0.1.0"
author        = "akvilary"
description   = "IMAP and POP3 client library for Nim"
license       = "MIT"
srcDir        = "src"

# Dependencies
requires "nim >= 2.0.0"

task test, "Run tests":
  exec "nim c -r tests/test_pop3_parse.nim"
  exec "nim c -r tests/test_imap_parse.nim"
