# mailclient

IMAP and POP3 client library for Nim, written from scratch.

## Project goals
- Implement POP3 client (text protocol, ~10 commands, simpler to start with)
- Implement IMAP client (RFC 3501, more complex)
- Support both sync and async APIs
- SSL/TLS support
- Clean, idiomatic Nim code

## Design decisions
- No external dependencies beyond Nim stdlib
- POP3 first (simpler protocol), then IMAP
- Protocols are text-based and well-documented (RFC 1939 for POP3, RFC 3501 for IMAP)
