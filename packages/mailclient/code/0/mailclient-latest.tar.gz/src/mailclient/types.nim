type
  MailError* = object of IOError
  Pop3Error* = object of MailError
  ImapError* = object of MailError
  AuthenticationError* = object of MailError

proc newMailError*(msg: string): ref MailError =
  newException(MailError, msg)

proc newPop3Error*(msg: string): ref Pop3Error =
  newException(Pop3Error, msg)

proc newImapError*(msg: string): ref ImapError =
  newException(ImapError, msg)

proc newAuthError*(msg: string): ref AuthenticationError =
  newException(AuthenticationError, msg)
