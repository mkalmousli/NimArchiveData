import std/[net, asyncnet, asyncdispatch, strutils]
import ./types
export types

type
  ImapClientBase*[SocketType] = ref object
    socket: SocketType
    host*: string
    port*: Port
    useSsl*: bool
    connected: bool
    tagCounter: int
    capabilities*: seq[string]
    when defined(ssl):
      sslContext: SslContext

  ImapClient* = ImapClientBase[Socket]
  AsyncImapClient* = ImapClientBase[AsyncSocket]

  ImapResponseKind* = enum
    irkOk, irkNo, irkBad

  ImapResponse* = object
    kind*: ImapResponseKind
    tag*: string
    text*: string
    untagged*: seq[string]

  MailboxInfo* = object
    name*: string
    flags*: seq[string]
    delimiter*: string

  MailboxStatus* = object
    name*: string
    exists*: int
    recent*: int
    unseen*: int
    uidNext*: int
    uidValidity*: int
    flags*: seq[string]
    permanentFlags*: seq[string]

  FetchResult* = object
    id*: int
    uid*: int
    flags*: seq[string]
    size*: int
    headers*: string
    body*: string

  SearchResult* = seq[int]

# ---------------------------------------------------------------------------
# Constructors
# ---------------------------------------------------------------------------

proc newImapClient*(host: string, port = Port(143),
                    useSsl = false): ImapClient =
  result = ImapClient(host: host, port: port, useSsl: useSsl)
  when defined(ssl):
    if useSsl:
      result.sslContext = newContext(verifyMode = CVerifyNone)

proc newAsyncImapClient*(host: string, port = Port(143),
                         useSsl = false): AsyncImapClient =
  result = AsyncImapClient(host: host, port: port, useSsl: useSsl)
  when defined(ssl):
    if useSsl:
      result.sslContext = newContext(verifyMode = CVerifyNone)

# ---------------------------------------------------------------------------
# Tag generation
# ---------------------------------------------------------------------------

proc nextTag(client: ImapClientBase): string =
  inc client.tagCounter
  result = "A" & $client.tagCounter

# ---------------------------------------------------------------------------
# Parsing (pure functions — no I/O)
# ---------------------------------------------------------------------------

proc parseFlags*(s: string): seq[string] =
  ## Parse "(\\Seen \\Flagged \\Deleted)" into @["\\Seen", "\\Flagged", "\\Deleted"]
  var inner = s.strip()
  if inner.startsWith("(") and inner.endsWith(")"):
    inner = inner[1..^2]
  if inner.len == 0:
    return @[]
  for flag in inner.split(' '):
    let f = flag.strip()
    if f.len > 0:
      result.add(f)

proc parseCapabilities*(line: string): seq[string] =
  ## Parse "CAPABILITY IMAP4rev1 STARTTLS AUTH=PLAIN" into seq
  var s = line
  if s.startsWith("CAPABILITY "):
    s = s[11..^1]
  for cap in s.split(' '):
    let c = cap.strip()
    if c.len > 0:
      result.add(c)

proc parseSearchResponse*(line: string): SearchResult =
  ## Parse "SEARCH 1 2 3 4" into @[1, 2, 3, 4]
  var s = line
  if s.startsWith("SEARCH"):
    s = s[6..^1].strip()
  if s.len == 0:
    return @[]
  for part in s.split(' '):
    let p = part.strip()
    if p.len > 0:
      result.add(parseInt(p))

proc parseMailboxListLine*(line: string): MailboxInfo =
  ## Parse `LIST (\HasNoChildren) "." "INBOX"` or `LIST (\HasNoChildren) "." INBOX`
  var s = line
  if s.startsWith("LIST "):
    s = s[5..^1]
  elif s.startsWith("LSUB "):
    s = s[5..^1]

  # Parse flags (...)
  let flagStart = s.find('(')
  let flagEnd = s.find(')')
  if flagStart >= 0 and flagEnd > flagStart:
    result.flags = parseFlags(s[flagStart..flagEnd])
    s = s[flagEnd + 1..^1].strip()

  # Parse delimiter
  let parts = s.split(' ', maxsplit = 1)
  if parts.len >= 1:
    var delim = parts[0].strip()
    if delim == "NIL":
      result.delimiter = ""
    else:
      result.delimiter = delim.strip(chars = {'"'})

  # Parse name
  if parts.len >= 2:
    var name = parts[1].strip()
    name = name.strip(chars = {'"'})
    result.name = name

proc parseMailboxList*(lines: seq[string]): seq[MailboxInfo] =
  for line in lines:
    if line.startsWith("LIST ") or line.startsWith("LSUB "):
      result.add(parseMailboxListLine(line))

proc parseSelectResponse*(lines: seq[string]): MailboxStatus =
  for line in lines:
    let stripped = line.strip()
    if stripped.endsWith("EXISTS"):
      let parts = stripped.split(' ')
      if parts.len >= 1:
        try: result.exists = parseInt(parts[0])
        except ValueError: discard
    elif stripped.endsWith("RECENT"):
      let parts = stripped.split(' ')
      if parts.len >= 1:
        try: result.recent = parseInt(parts[0])
        except ValueError: discard
    elif stripped.startsWith("FLAGS "):
      result.flags = parseFlags(stripped[6..^1])
    elif stripped.startsWith("OK [PERMANENTFLAGS "):
      let s = stripped[19..^1]
      let bracket = s.find(']')
      if bracket > 0:
        result.permanentFlags = parseFlags(s[0..bracket - 1])
    elif stripped.startsWith("OK [UIDNEXT "):
      let s = stripped[12..^1]
      let bracket = s.find(']')
      if bracket > 0:
        try: result.uidNext = parseInt(s[0..bracket - 1])
        except ValueError: discard
    elif stripped.startsWith("OK [UIDVALIDITY "):
      let s = stripped[16..^1]
      let bracket = s.find(']')
      if bracket > 0:
        try: result.uidValidity = parseInt(s[0..bracket - 1])
        except ValueError: discard
    elif stripped.startsWith("OK [UNSEEN "):
      let s = stripped[11..^1]
      let bracket = s.find(']')
      if bracket > 0:
        try: result.unseen = parseInt(s[0..bracket - 1])
        except ValueError: discard

proc parseFetchResponseLine*(line: string): FetchResult =
  ## Parse a single FETCH response like "1 FETCH (FLAGS (\\Seen) UID 42 RFC822.SIZE 1024)"
  let fetchPos = line.find("FETCH ")
  if fetchPos < 0:
    return

  # Extract sequence number
  let seqStr = line[0..fetchPos - 1].strip()
  try: result.id = parseInt(seqStr)
  except ValueError: discard

  # Extract parenthesized data
  let parenStart = line.find('(', fetchPos)
  if parenStart < 0:
    return
  let data = line[parenStart + 1..^1]

  # Parse key-value pairs within FETCH response
  var i = 0
  while i < data.len:
    if data[i] == ')' and i == data.len - 1:
      break
    # Skip whitespace
    while i < data.len and data[i] == ' ':
      inc i
    if i >= data.len:
      break

    # Read key
    var key = ""
    while i < data.len and data[i] notin {' ', '(', ')'}:
      key.add(data[i])
      inc i
    key = key.toUpperAscii()

    # Skip space
    while i < data.len and data[i] == ' ':
      inc i
    if i >= data.len:
      break

    case key
    of "FLAGS":
      if i < data.len and data[i] == '(':
        let flagEnd = data.find(')', i)
        if flagEnd >= 0:
          result.flags = parseFlags(data[i..flagEnd])
          i = flagEnd + 1
    of "UID":
      var numStr = ""
      while i < data.len and data[i] in {'0'..'9'}:
        numStr.add(data[i])
        inc i
      if numStr.len > 0:
        result.uid = parseInt(numStr)
    of "RFC822.SIZE":
      var numStr = ""
      while i < data.len and data[i] in {'0'..'9'}:
        numStr.add(data[i])
        inc i
      if numStr.len > 0:
        result.size = parseInt(numStr)
    of "BODY[]", "BODY[HEADER]", "BODY[TEXT]", "RFC822", "RFC822.HEADER",
       "BODY.PEEK[]", "BODY.PEEK[HEADER]", "BODY.PEEK[TEXT]":
      # Handle literal {N} or quoted string
      if i < data.len and data[i] == '{':
        let braceEnd = data.find('}', i)
        if braceEnd > i:
          # Literal — the actual data follows on next lines
          # In full response parsing this is handled at the I/O level
          i = braceEnd + 1
      elif i < data.len and data[i] == '"':
        inc i
        var val = ""
        while i < data.len and data[i] != '"':
          val.add(data[i])
          inc i
        if i < data.len:
          inc i
        if key.contains("HEADER"):
          result.headers = val
        else:
          result.body = val
    else:
      # Skip unknown value
      if i < data.len and data[i] == '(':
        var depth = 1
        inc i
        while i < data.len and depth > 0:
          if data[i] == '(':
            inc depth
          elif data[i] == ')':
            dec depth
          inc i
      elif i < data.len and data[i] == '"':
        inc i
        while i < data.len and data[i] != '"':
          inc i
        if i < data.len:
          inc i
      elif i < data.len and data[i] == '{':
        let braceEnd = data.find('}', i)
        if braceEnd > i:
          i = braceEnd + 1
      else:
        while i < data.len and data[i] notin {' ', ')'}:
          inc i

proc parseFetchResponse*(lines: seq[string]): seq[FetchResult] =
  for line in lines:
    if line.contains("FETCH "):
      result.add(parseFetchResponseLine(line))

# ---------------------------------------------------------------------------
# Low-level I/O (multisync)
# ---------------------------------------------------------------------------

proc connect*(client: ImapClient | AsyncImapClient) {.multisync.} =
  when client is ImapClient:
    client.socket = newSocket()
    when defined(ssl):
      if client.useSsl:
        client.sslContext.wrapSocket(client.socket)
    client.socket.connect(client.host, client.port)
  else:
    client.socket = newAsyncSocket()
    when defined(ssl):
      if client.useSsl:
        client.sslContext.wrapSocket(client.socket)
    await client.socket.connect(client.host, client.port)
  client.connected = true
  let greeting = await client.socket.recvLine()
  if not greeting.startsWith("* "):
    raise newImapError("Invalid server greeting: " & greeting)
  # Extract capabilities from greeting if present
  let capPos = greeting.find("CAPABILITY ")
  if capPos >= 0:
    let bracketEnd = greeting.find(']', capPos)
    if bracketEnd >= 0:
      client.capabilities = parseCapabilities(greeting[capPos..bracketEnd - 1])

proc readResponse(client: ImapClient | AsyncImapClient,
                  tag: string): Future[ImapResponse] {.multisync.} =
  result.tag = tag
  result.untagged = @[]
  while true:
    var line = await client.socket.recvLine()
    if line == "":
      raise newImapError("Connection closed by server")

    # Handle literal data: if line ends with {N}
    while line.endsWith('}'):
      let braceStart = line.rfind('{')
      if braceStart < 0:
        break
      let sizeStr = line[braceStart + 1..^2]
      var litSize: int
      try:
        litSize = parseInt(sizeStr)
      except ValueError:
        break

      when client is ImapClient:
        var litData = ""
        while litData.len < litSize:
          let chunk = client.socket.recv(litSize - litData.len)
          if chunk.len == 0:
            raise newImapError("Connection closed during literal read")
          litData.add(chunk)
      else:
        var litData = ""
        while litData.len < litSize:
          let chunk = await client.socket.recv(litSize - litData.len)
          if chunk.len == 0:
            raise newImapError("Connection closed during literal read")
          litData.add(chunk)
      line = line[0..<braceStart] & litData
      let continuation = await client.socket.recvLine()
      if continuation.len > 0:
        line.add(continuation)
      else:
        break

    if line.startsWith(tag & " "):
      let rest = line[(tag.len + 1)..^1]
      if rest.startsWith("OK"):
        result.kind = irkOk
        result.text = if rest.len > 2: rest[3..^1] else: ""
      elif rest.startsWith("NO"):
        result.kind = irkNo
        result.text = if rest.len > 2: rest[3..^1] else: ""
      elif rest.startsWith("BAD"):
        result.kind = irkBad
        result.text = if rest.len > 3: rest[4..^1] else: ""
      break
    elif line.startsWith("* "):
      result.untagged.add(line[2..^1])
    # + continuation requests are ignored here (handled at higher level for APPEND)

proc sendCommand(client: ImapClient | AsyncImapClient,
                 command: string): Future[ImapResponse] {.multisync.} =
  let tag = client.nextTag()
  await client.socket.send(tag & " " & command & "\r\n")
  result = await client.readResponse(tag)

proc sendCommandChecked(client: ImapClient | AsyncImapClient,
                        command: string): Future[ImapResponse] {.multisync.} =
  result = await client.sendCommand(command)
  if result.kind == irkBad:
    raise newImapError("BAD: " & result.text)
  elif result.kind == irkNo:
    raise newImapError("NO: " & result.text)

# ---------------------------------------------------------------------------
# Authentication commands
# ---------------------------------------------------------------------------

proc login*(client: ImapClient | AsyncImapClient,
            username, password: string) {.multisync.} =
  let resp = await client.sendCommand("LOGIN " & username & " " & password)
  if resp.kind != irkOk:
    raise newAuthError("Login failed: " & resp.text)
  # Update capabilities if returned
  for line in resp.untagged:
    if line.startsWith("CAPABILITY "):
      client.capabilities = parseCapabilities(line)

proc capability*(client: ImapClient | AsyncImapClient): Future[seq[string]] {.multisync.} =
  let resp = await client.sendCommandChecked("CAPABILITY")
  for line in resp.untagged:
    if line.startsWith("CAPABILITY "):
      client.capabilities = parseCapabilities(line)
      return client.capabilities
  result = client.capabilities

proc logout*(client: ImapClient | AsyncImapClient) {.multisync.} =
  discard await client.sendCommand("LOGOUT")
  client.socket.close()
  client.connected = false

# ---------------------------------------------------------------------------
# Mailbox commands
# ---------------------------------------------------------------------------

proc select*(client: ImapClient | AsyncImapClient,
             mailbox: string): Future[MailboxStatus] {.multisync.} =
  let resp = await client.sendCommandChecked("SELECT " & mailbox)
  result = parseSelectResponse(resp.untagged)
  result.name = mailbox

proc examine*(client: ImapClient | AsyncImapClient,
              mailbox: string): Future[MailboxStatus] {.multisync.} =
  let resp = await client.sendCommandChecked("EXAMINE " & mailbox)
  result = parseSelectResponse(resp.untagged)
  result.name = mailbox

proc list*(client: ImapClient | AsyncImapClient,
           reference = "\"\"", pattern = "\"*\""): Future[seq[MailboxInfo]] {.multisync.} =
  let resp = await client.sendCommandChecked("LIST " & reference & " " & pattern)
  result = parseMailboxList(resp.untagged)

proc lsub*(client: ImapClient | AsyncImapClient,
           reference = "\"\"", pattern = "\"*\""): Future[seq[MailboxInfo]] {.multisync.} =
  let resp = await client.sendCommandChecked("LSUB " & reference & " " & pattern)
  result = parseMailboxList(resp.untagged)

proc status*(client: ImapClient | AsyncImapClient,
             mailbox: string,
             items: openArray[string]): Future[MailboxStatus] {.multisync.} =
  let itemStr = "(" & items.join(" ") & ")"
  let resp = await client.sendCommandChecked("STATUS " & mailbox & " " & itemStr)
  result.name = mailbox
  for line in resp.untagged:
    if line.startsWith("STATUS "):
      let parenStart = line.find('(')
      if parenStart >= 0:
        let data = line[parenStart + 1..^2]
        let parts = data.split(' ')
        var i = 0
        while i < parts.len - 1:
          case parts[i].toUpperAscii()
          of "MESSAGES":
            try: result.exists = parseInt(parts[i + 1])
            except ValueError: discard
          of "RECENT":
            try: result.recent = parseInt(parts[i + 1])
            except ValueError: discard
          of "UNSEEN":
            try: result.unseen = parseInt(parts[i + 1])
            except ValueError: discard
          of "UIDNEXT":
            try: result.uidNext = parseInt(parts[i + 1])
            except ValueError: discard
          of "UIDVALIDITY":
            try: result.uidValidity = parseInt(parts[i + 1])
            except ValueError: discard
          else: discard
          i += 2

proc create*(client: ImapClient | AsyncImapClient,
             mailbox: string) {.multisync.} =
  discard await client.sendCommandChecked("CREATE " & mailbox)

proc delete*(client: ImapClient | AsyncImapClient,
             mailbox: string) {.multisync.} =
  discard await client.sendCommandChecked("DELETE " & mailbox)

proc rename*(client: ImapClient | AsyncImapClient,
             oldName, newName: string) {.multisync.} =
  discard await client.sendCommandChecked("RENAME " & oldName & " " & newName)

proc subscribe*(client: ImapClient | AsyncImapClient,
                mailbox: string) {.multisync.} =
  discard await client.sendCommandChecked("SUBSCRIBE " & mailbox)

proc unsubscribe*(client: ImapClient | AsyncImapClient,
                  mailbox: string) {.multisync.} =
  discard await client.sendCommandChecked("UNSUBSCRIBE " & mailbox)

# ---------------------------------------------------------------------------
# Message commands
# ---------------------------------------------------------------------------

proc fetch*(client: ImapClient | AsyncImapClient,
            sequence: string,
            items: string): Future[ImapResponse] {.multisync.} =
  result = await client.sendCommandChecked("FETCH " & sequence & " " & items)

proc search*(client: ImapClient | AsyncImapClient,
             criteria: string): Future[SearchResult] {.multisync.} =
  let resp = await client.sendCommandChecked("SEARCH " & criteria)
  for line in resp.untagged:
    if line.startsWith("SEARCH"):
      return parseSearchResponse(line)
  result = @[]

proc store*(client: ImapClient | AsyncImapClient,
            sequence: string, action: string,
            flags: openArray[string]): Future[ImapResponse] {.multisync.} =
  let flagStr = "(" & flags.join(" ") & ")"
  result = await client.sendCommandChecked(
    "STORE " & sequence & " " & action & " " & flagStr)

proc copy*(client: ImapClient | AsyncImapClient,
           sequence: string, mailbox: string) {.multisync.} =
  discard await client.sendCommandChecked("COPY " & sequence & " " & mailbox)

proc expunge*(client: ImapClient | AsyncImapClient) {.multisync.} =
  discard await client.sendCommandChecked("EXPUNGE")

proc append*(client: ImapClient | AsyncImapClient,
             mailbox: string, message: string,
             flags: openArray[string] = []) {.multisync.} =
  var cmd = "APPEND " & mailbox
  if flags.len > 0:
    cmd.add(" (" & flags.join(" ") & ")")
  cmd.add(" {" & $message.len & "}")
  let tag = client.nextTag()
  await client.socket.send(tag & " " & cmd & "\r\n")
  # Wait for continuation response (+)
  let contLine = await client.socket.recvLine()
  if not contLine.startsWith("+"):
    raise newImapError("Expected continuation, got: " & contLine)
  # Send the message data
  await client.socket.send(message & "\r\n")
  let resp = await client.readResponse(tag)
  if resp.kind != irkOk:
    raise newImapError("APPEND failed: " & resp.text)

proc noop*(client: ImapClient | AsyncImapClient) {.multisync.} =
  discard await client.sendCommandChecked("NOOP")

proc closeMailbox*(client: ImapClient | AsyncImapClient) {.multisync.} =
  discard await client.sendCommandChecked("CLOSE")

# ---------------------------------------------------------------------------
# UID commands
# ---------------------------------------------------------------------------

proc uidFetch*(client: ImapClient | AsyncImapClient,
               sequence: string,
               items: string): Future[ImapResponse] {.multisync.} =
  result = await client.sendCommandChecked("UID FETCH " & sequence & " " & items)

proc uidSearch*(client: ImapClient | AsyncImapClient,
                criteria: string): Future[SearchResult] {.multisync.} =
  let resp = await client.sendCommandChecked("UID SEARCH " & criteria)
  for line in resp.untagged:
    if line.startsWith("SEARCH"):
      return parseSearchResponse(line)
  result = @[]

proc uidStore*(client: ImapClient | AsyncImapClient,
               sequence: string, action: string,
               flags: openArray[string]): Future[ImapResponse] {.multisync.} =
  let flagStr = "(" & flags.join(" ") & ")"
  result = await client.sendCommandChecked(
    "UID STORE " & sequence & " " & action & " " & flagStr)

proc uidCopy*(client: ImapClient | AsyncImapClient,
              sequence: string, mailbox: string) {.multisync.} =
  discard await client.sendCommandChecked("UID COPY " & sequence & " " & mailbox)

# ---------------------------------------------------------------------------
# Connection management
# ---------------------------------------------------------------------------

proc close*(client: ImapClient | AsyncImapClient) {.multisync.} =
  if client.connected:
    try:
      await client.logout()
    except CatchableError:
      client.socket.close()
      client.connected = false
