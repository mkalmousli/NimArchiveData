import std/[net, asyncnet, asyncdispatch, strutils]
import ./types
export types

type
  Pop3ClientBase*[SocketType] = ref object
    socket: SocketType
    host*: string
    port*: Port
    useSsl*: bool
    connected: bool
    greeting*: string
    when defined(ssl):
      sslContext: SslContext

  Pop3Client* = Pop3ClientBase[Socket]
  AsyncPop3Client* = Pop3ClientBase[AsyncSocket]

  Pop3Response* = object
    ok*: bool
    message*: string

  MessageStat* = object
    count*: int
    size*: int

  MessageInfo* = object
    id*: int
    size*: int

  MessageUid* = object
    id*: int
    uid*: string

# ---------------------------------------------------------------------------
# Constructors
# ---------------------------------------------------------------------------

proc newPop3Client*(host: string, port = Port(110),
                    useSsl = false): Pop3Client =
  result = Pop3Client(host: host, port: port, useSsl: useSsl)
  when defined(ssl):
    if useSsl:
      result.sslContext = newContext(verifyMode = CVerifyNone)

proc newAsyncPop3Client*(host: string, port = Port(110),
                         useSsl = false): AsyncPop3Client =
  result = AsyncPop3Client(host: host, port: port, useSsl: useSsl)
  when defined(ssl):
    if useSsl:
      result.sslContext = newContext(verifyMode = CVerifyNone)

# ---------------------------------------------------------------------------
# Parsing (pure functions — no I/O)
# ---------------------------------------------------------------------------

proc parseResponse*(line: string): Pop3Response =
  if line.startsWith("+OK"):
    result.ok = true
    if line.len > 3:
      result.message = line[4..^1]
  elif line.startsWith("-ERR"):
    result.ok = false
    if line.len > 4:
      result.message = line[5..^1]
  else:
    result.ok = false
    result.message = line

proc parseStat*(response: string): MessageStat =
  let parts = response.split(' ')
  if parts.len >= 2:
    result.count = parseInt(parts[0])
    result.size = parseInt(parts[1])

proc parseMessageInfo*(line: string): MessageInfo =
  let parts = line.strip().split(' ')
  if parts.len >= 2:
    result.id = parseInt(parts[0])
    result.size = parseInt(parts[1])

proc parseList*(lines: seq[string]): seq[MessageInfo] =
  for line in lines:
    let stripped = line.strip()
    if stripped.len > 0:
      result.add(parseMessageInfo(stripped))

proc parseMessageUid*(line: string): MessageUid =
  let parts = line.strip().split(' ')
  if parts.len >= 2:
    result.id = parseInt(parts[0])
    result.uid = parts[1]

proc parseUidl*(lines: seq[string]): seq[MessageUid] =
  for line in lines:
    let stripped = line.strip()
    if stripped.len > 0:
      result.add(parseMessageUid(stripped))

proc unstuffDot*(lines: seq[string]): seq[string] =
  for line in lines:
    if line.startsWith(".."):
      result.add(line[1..^1])
    else:
      result.add(line)

# ---------------------------------------------------------------------------
# Low-level I/O (multisync)
# ---------------------------------------------------------------------------

proc connect*(client: Pop3Client | AsyncPop3Client) {.multisync.} =
  when client is Pop3Client:
    client.socket = newSocket()
    when defined(ssl):
      if client.useSsl:
        client.sslContext.wrapSocket(client.socket)
    client.socket.connect(client.host, client.port)
  else:
    client.socket = newAsyncSocket()
    when defined(ssl):
      if client.useSsl:
        client.sslContext.wrapSocket(client.socket)
    await client.socket.connect(client.host, client.port)
  client.connected = true
  let line = await client.socket.recvLine()
  let resp = parseResponse(line)
  if not resp.ok:
    raise newPop3Error("Server rejected connection: " & resp.message)
  client.greeting = resp.message

proc sendCommand(client: Pop3Client | AsyncPop3Client,
                 command: string): Future[Pop3Response] {.multisync.} =
  await client.socket.send(command & "\r\n")
  let line = await client.socket.recvLine()
  result = parseResponse(line)

proc readMultiline(client: Pop3Client | AsyncPop3Client): Future[seq[string]] {.multisync.} =
  while true:
    let line = await client.socket.recvLine()
    if line == ".":
      break
    if line == "":
      raise newPop3Error("Connection closed during multi-line response")
    result.add(line)
  result = unstuffDot(result)

proc sendCommandChecked(client: Pop3Client | AsyncPop3Client,
                        command: string): Future[Pop3Response] {.multisync.} =
  result = await client.sendCommand(command)
  if not result.ok:
    raise newPop3Error(result.message)

proc sendCommandMulti(client: Pop3Client | AsyncPop3Client,
                      command: string): Future[seq[string]] {.multisync.} =
  discard await client.sendCommandChecked(command)
  result = await client.readMultiline()

# ---------------------------------------------------------------------------
# AUTHORIZATION commands
# ---------------------------------------------------------------------------

proc user*(client: Pop3Client | AsyncPop3Client,
           username: string) {.multisync.} =
  discard await client.sendCommandChecked("USER " & username)

proc pass*(client: Pop3Client | AsyncPop3Client,
           password: string) {.multisync.} =
  let resp = await client.sendCommand("PASS " & password)
  if not resp.ok:
    raise newAuthError("Authentication failed: " & resp.message)

proc login*(client: Pop3Client | AsyncPop3Client,
            username, password: string) {.multisync.} =
  await client.user(username)
  await client.pass(password)

proc apop*(client: Pop3Client | AsyncPop3Client,
           username, digest: string) {.multisync.} =
  let resp = await client.sendCommand("APOP " & username & " " & digest)
  if not resp.ok:
    raise newAuthError("APOP authentication failed: " & resp.message)

# ---------------------------------------------------------------------------
# TRANSACTION commands
# ---------------------------------------------------------------------------

proc stat*(client: Pop3Client | AsyncPop3Client): Future[MessageStat] {.multisync.} =
  let resp = await client.sendCommandChecked("STAT")
  result = parseStat(resp.message)

proc list*(client: Pop3Client | AsyncPop3Client): Future[seq[MessageInfo]] {.multisync.} =
  let lines = await client.sendCommandMulti("LIST")
  result = parseList(lines)

proc list*(client: Pop3Client | AsyncPop3Client,
           msgNum: int): Future[MessageInfo] {.multisync.} =
  let resp = await client.sendCommandChecked("LIST " & $msgNum)
  result = parseMessageInfo(resp.message)

proc retr*(client: Pop3Client | AsyncPop3Client,
           msgNum: int): Future[string] {.multisync.} =
  let lines = await client.sendCommandMulti("RETR " & $msgNum)
  result = lines.join("\r\n")

proc dele*(client: Pop3Client | AsyncPop3Client,
           msgNum: int) {.multisync.} =
  discard await client.sendCommandChecked("DELE " & $msgNum)

proc noop*(client: Pop3Client | AsyncPop3Client) {.multisync.} =
  discard await client.sendCommandChecked("NOOP")

proc rset*(client: Pop3Client | AsyncPop3Client) {.multisync.} =
  discard await client.sendCommandChecked("RSET")

proc top*(client: Pop3Client | AsyncPop3Client,
          msgNum, lines: int): Future[string] {.multisync.} =
  let data = await client.sendCommandMulti("TOP " & $msgNum & " " & $lines)
  result = data.join("\r\n")

proc uidl*(client: Pop3Client | AsyncPop3Client): Future[seq[MessageUid]] {.multisync.} =
  let lines = await client.sendCommandMulti("UIDL")
  result = parseUidl(lines)

proc uidl*(client: Pop3Client | AsyncPop3Client,
           msgNum: int): Future[MessageUid] {.multisync.} =
  let resp = await client.sendCommandChecked("UIDL " & $msgNum)
  result = parseMessageUid(resp.message)

proc quit*(client: Pop3Client | AsyncPop3Client) {.multisync.} =
  discard await client.sendCommand("QUIT")
  client.socket.close()
  client.connected = false

proc close*(client: Pop3Client | AsyncPop3Client) {.multisync.} =
  if client.connected:
    try:
      await client.quit()
    except CatchableError:
      client.socket.close()
      client.connected = false
