import std/unittest
import mailclient/pop3

suite "parseResponse":
  test "+OK with message":
    let r = parseResponse("+OK POP3 server ready")
    check r.ok == true
    check r.message == "POP3 server ready"

  test "+OK without message":
    let r = parseResponse("+OK")
    check r.ok == true
    check r.message == ""

  test "-ERR with message":
    let r = parseResponse("-ERR invalid password")
    check r.ok == false
    check r.message == "invalid password"

  test "-ERR without message":
    let r = parseResponse("-ERR")
    check r.ok == false
    check r.message == ""

  test "unknown response":
    let r = parseResponse("something unexpected")
    check r.ok == false
    check r.message == "something unexpected"

suite "parseStat":
  test "normal stat":
    let s = parseStat("5 10240")
    check s.count == 5
    check s.size == 10240

  test "empty mailbox":
    let s = parseStat("0 0")
    check s.count == 0
    check s.size == 0

  test "single message":
    let s = parseStat("1 512")
    check s.count == 1
    check s.size == 512

suite "parseMessageInfo":
  test "single entry":
    let m = parseMessageInfo("1 1024")
    check m.id == 1
    check m.size == 1024

  test "with leading spaces":
    let m = parseMessageInfo("  3 2048  ")
    check m.id == 3
    check m.size == 2048

suite "parseList":
  test "multiple messages":
    let lines = @["1 512", "2 1024", "3 2048"]
    let result = parseList(lines)
    check result.len == 3
    check result[0].id == 1
    check result[0].size == 512
    check result[1].id == 2
    check result[1].size == 1024
    check result[2].id == 3
    check result[2].size == 2048

  test "empty list":
    let result = parseList(@[])
    check result.len == 0

  test "skips empty lines":
    let lines = @["1 100", "", "2 200"]
    let result = parseList(lines)
    check result.len == 2

suite "parseMessageUid":
  test "single uid":
    let u = parseMessageUid("1 abc123")
    check u.id == 1
    check u.uid == "abc123"

suite "parseUidl":
  test "multiple uids":
    let lines = @["1 uid-aaa", "2 uid-bbb", "3 uid-ccc"]
    let result = parseUidl(lines)
    check result.len == 3
    check result[0].uid == "uid-aaa"
    check result[1].uid == "uid-bbb"
    check result[2].uid == "uid-ccc"

  test "empty list":
    let result = parseUidl(@[])
    check result.len == 0

suite "unstuffDot":
  test "no stuffing needed":
    let lines = @["Hello", "World"]
    let result = unstuffDot(lines)
    check result == @["Hello", "World"]

  test "unstuffs double dot":
    let lines = @["..This started with dot", "Normal line", "..Another dot line"]
    let result = unstuffDot(lines)
    check result == @[".This started with dot", "Normal line", ".Another dot line"]

  test "single dot not in terminator context":
    let lines = @[".."]
    let result = unstuffDot(lines)
    check result == @["."]

  test "empty list":
    let result = unstuffDot(@[])
    check result.len == 0

  test "mixed content":
    let lines = @["Header: value", "..dot-stuffed", "regular", "...triple"]
    let result = unstuffDot(lines)
    check result[0] == "Header: value"
    check result[1] == ".dot-stuffed"
    check result[2] == "regular"
    check result[3] == "..triple"
