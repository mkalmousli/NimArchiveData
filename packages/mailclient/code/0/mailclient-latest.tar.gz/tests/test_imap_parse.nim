import std/unittest
import mailclient/imap

suite "parseFlags":
  test "normal flags":
    let flags = parseFlags("(\\Seen \\Flagged \\Deleted)")
    check flags == @["\\Seen", "\\Flagged", "\\Deleted"]

  test "empty flags":
    let flags = parseFlags("()")
    check flags.len == 0

  test "single flag":
    let flags = parseFlags("(\\Seen)")
    check flags == @["\\Seen"]

  test "without parentheses":
    let flags = parseFlags("\\Seen \\Draft")
    check flags == @["\\Seen", "\\Draft"]

suite "parseCapabilities":
  test "full capability line":
    let caps = parseCapabilities("CAPABILITY IMAP4rev1 STARTTLS AUTH=PLAIN IDLE")
    check caps == @["IMAP4rev1", "STARTTLS", "AUTH=PLAIN", "IDLE"]

  test "without CAPABILITY prefix":
    let caps = parseCapabilities("IMAP4rev1 IDLE")
    check caps == @["IMAP4rev1", "IDLE"]

  test "single capability":
    let caps = parseCapabilities("CAPABILITY IMAP4rev1")
    check caps == @["IMAP4rev1"]

suite "parseSearchResponse":
  test "multiple results":
    let res = parseSearchResponse("SEARCH 1 4 7 12")
    check res == @[1, 4, 7, 12]

  test "single result":
    let res = parseSearchResponse("SEARCH 42")
    check res == @[42]

  test "empty search":
    let res = parseSearchResponse("SEARCH")
    check res.len == 0

  test "empty string":
    let res = parseSearchResponse("SEARCH ")
    check res.len == 0

suite "parseMailboxListLine":
  test "standard LIST response":
    let info = parseMailboxListLine("LIST (\\HasNoChildren) \".\" \"INBOX\"")
    check info.name == "INBOX"
    check info.delimiter == "."
    check info.flags == @["\\HasNoChildren"]

  test "LIST with multiple flags":
    let info = parseMailboxListLine("LIST (\\HasNoChildren \\Trash) \"/\" \"Trash\"")
    check info.name == "Trash"
    check info.delimiter == "/"
    check "\\HasNoChildren" in info.flags
    check "\\Trash" in info.flags

  test "LSUB response":
    let info = parseMailboxListLine("LSUB () \".\" \"INBOX.Sent\"")
    check info.name == "INBOX.Sent"
    check info.delimiter == "."

  test "NIL delimiter":
    let info = parseMailboxListLine("LIST (\\Noselect) NIL \"\"")
    check info.delimiter == ""

suite "parseMailboxList":
  test "multiple mailboxes":
    let lines = @[
      "LIST (\\HasNoChildren) \".\" \"INBOX\"",
      "LIST (\\HasNoChildren) \".\" \"Sent\"",
      "LIST (\\HasNoChildren \\Trash) \".\" \"Trash\""
    ]
    let result = parseMailboxList(lines)
    check result.len == 3
    check result[0].name == "INBOX"
    check result[1].name == "Sent"
    check result[2].name == "Trash"

  test "skips non-LIST lines":
    let lines = @[
      "OK some info",
      "LIST (\\HasNoChildren) \".\" \"INBOX\""
    ]
    let result = parseMailboxList(lines)
    check result.len == 1
    check result[0].name == "INBOX"

  test "empty list":
    let result = parseMailboxList(@[])
    check result.len == 0

suite "parseSelectResponse":
  test "full SELECT response":
    let lines = @[
      "172 EXISTS",
      "1 RECENT",
      "FLAGS (\\Answered \\Flagged \\Deleted \\Seen \\Draft)",
      "OK [PERMANENTFLAGS (\\Deleted \\Seen \\*)] Limited",
      "OK [UIDVALIDITY 3857529045] UIDs valid",
      "OK [UIDNEXT 4392] Predicted next UID",
      "OK [UNSEEN 12] Message 12 is first unseen"
    ]
    let status = parseSelectResponse(lines)
    check status.exists == 172
    check status.recent == 1
    check status.uidValidity == 3857529045
    check status.uidNext == 4392
    check status.unseen == 12
    check "\\Answered" in status.flags
    check "\\Flagged" in status.flags
    check "\\Deleted" in status.permanentFlags
    check "\\Seen" in status.permanentFlags

  test "minimal SELECT response":
    let lines = @["0 EXISTS", "0 RECENT"]
    let status = parseSelectResponse(lines)
    check status.exists == 0
    check status.recent == 0

suite "parseFetchResponseLine":
  test "flags and UID":
    let r = parseFetchResponseLine("1 FETCH (FLAGS (\\Seen) UID 42)")
    check r.id == 1
    check r.uid == 42
    check r.flags == @["\\Seen"]

  test "flags UID and size":
    let r = parseFetchResponseLine("3 FETCH (FLAGS (\\Seen \\Flagged) UID 100 RFC822.SIZE 2048)")
    check r.id == 3
    check r.uid == 100
    check r.size == 2048
    check "\\Seen" in r.flags
    check "\\Flagged" in r.flags

  test "empty flags":
    let r = parseFetchResponseLine("5 FETCH (FLAGS () UID 10)")
    check r.id == 5
    check r.uid == 10
    check r.flags.len == 0

  test "only flags":
    let r = parseFetchResponseLine("2 FETCH (FLAGS (\\Answered \\Seen))")
    check r.id == 2
    check "\\Answered" in r.flags
    check "\\Seen" in r.flags

suite "parseFetchResponse":
  test "multiple fetch results":
    let lines = @[
      "1 FETCH (FLAGS (\\Seen) UID 10)",
      "2 FETCH (FLAGS (\\Flagged) UID 20)",
      "3 FETCH (FLAGS () UID 30)"
    ]
    let results = parseFetchResponse(lines)
    check results.len == 3
    check results[0].id == 1
    check results[0].uid == 10
    check results[1].id == 2
    check results[1].uid == 20
    check results[2].id == 3
    check results[2].uid == 30

  test "skips non-FETCH lines":
    let lines = @[
      "OK some info",
      "1 FETCH (FLAGS (\\Seen) UID 10)"
    ]
    let results = parseFetchResponse(lines)
    check results.len == 1

  test "empty":
    let results = parseFetchResponse(@[])
    check results.len == 0
