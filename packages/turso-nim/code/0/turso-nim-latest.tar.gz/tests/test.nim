import
  unittest,
  json,
  options

import ../src/turso

test "connect":
  var
    url = "https://[databaseName]-[organizationName].turso.io"
    token = "token"
    turso = connect(url, token)

  check url & "/v2/pipeline" == turso.url
  check token == turso.token
  check turso.baton.isNone

test "execute with positional parameters":
  var
    turso = connect("https://test.turso.io", "token")
    args = @[%*"test_value"]
  
  expect TursoError:
    turso.execute("INSERT INTO test (value) VALUES (?)", args)

test "execute with named parameters":
  var
    turso = connect("https://test.turso.io", "token")
    named_args = %*{"value": "test_value"}
  
  expect TursoError:
    turso.execute("INSERT INTO test (value) VALUES (:value)", named_args = named_args)

test "getData response structure":
  var
    turso = connect("https://test.turso.io", "token")
    response: TursoResponse
  
  expect TursoError:
    response = turso.getData("SELECT * FROM test")
  
  check response.cols.len == 0
  check response.rows.len == 0
  check response.affected_row_count == 0
  check response.last_insert_rowid == 0
  check response.replication_index == ""
  check response.rows_read == 0
  check response.rows_written == 0
  check response.query_duration_ms == 0.0

test "transaction management":
  var turso = connect("https://test.turso.io", "token")
  
  expect TursoError:
    turso.startTransaction()
    turso.execute("INSERT INTO test (value) VALUES (?)", @[%*"test_value"])
    turso.commit()

  expect TursoError:
    turso.startTransaction()
    turso.execute("INSERT INTO test (value) VALUES (?)", @[%*"test_value"])
    turso.rollback()

test "vector search":
  var
    turso = connect("https://test.turso.io", "token")
    queryVector = @[0.1'f, 0.2'f, 0.3'f]
  
  expect TursoError:
    discard turso.vectorSearch("embeddings", "vector", queryVector)

test "insertId":
  var
    turso = connect("https://test.turso.io", "token")
    fields = @["name", "value"]
    values = @["test_name", "test_value"]
  
  expect TursoError:
    discard turso.insertId("test", fields, values)

test "error handling":
  var turso = connect("https://test.turso.io", "invalid_token")
  
  expect TursoError:
    turso.execute("SELECT * FROM non_existent_table")
  
  try:
    turso.execute("SELECT * FROM non_existent_table")
  except TursoError as e:
    check e.msg.len > 0
