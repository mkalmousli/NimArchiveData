import
  httpclient,
  json,
  strutils,
  sequtils,
  options,
  strformat

type
  TursoError* = object of CatchableError

  TursoResponse* = object
    cols*: seq[string]
    rows*: seq[JsonNode]
    affected_row_count*: int
    last_insert_rowid*: int64
    replication_index*: string
    rows_read*: int
    rows_written*: int
    query_duration_ms*: float

  Turso* = ref object
    url*: string
    token*: string
    client*: HttpClient
    baton*: Option[string]  # For interactive queries

proc connect*(url, token: string): Turso =
  ## Connect to the Turso API
  ## url: The URL of the Turso API
  ## token: The token to authenticate with the Turso API
  ## return: A Turso object
  ## Example:
  ## ```var turso = connect("https://api.turso.io", "your-token")```
  
  var
    url1 = url & "/v2/pipeline"
    url2 = url1

  if url1.contains("https"):
    url2 = url1.replace("libsql", "https")
  
  result = Turso(url: url2, token: token, client: newHttpClient())

proc execute*(turso: Turso, sql: string, args: openArray[JsonNode] = @[], named_args: JsonNode = newJObject()) =
  ## Execute a SQL statement with optional positional or named parameters
  ## turso: A Turso object
  ## sql: The SQL statement to execute
  ## args: Optional array of positional parameters
  ## named_args: Optional object of named parameters
  ## Example:
  ## ```turso.execute("SELECT * FROM table WHERE id = ?", @[%*1])```
  ## ```turso.execute("SELECT * FROM table WHERE id = :id", named_args = %*{"id": 1})```
  var
    stmt = %*{"sql": sql}
  
  if args.len > 0:
    stmt["args"] = %args
  if named_args.len > 0:
    stmt["named_args"] = named_args

  var body = %*{
    "requests": [
      { "type": "execute", "stmt": stmt },
      { "type": "close" }
    ]
  }

  if turso.baton.isSome:
    body["baton"] = %turso.baton.get

  turso.client.headers = newHttpHeaders({ "Authorization": "Bearer " & turso.token, "Content-Type": "application/json" })

  try:
    var response = turso.client.request(turso.url, httpMethod = HttpPost, body = $body, headers = turso.client.headers)
    if response.code != Http200:
      raise newException(TursoError, "HTTP " & $response.code & ": " & response.body)
    
    let respJson = parseJson(response.body)
    if respJson.hasKey("baton"):
      turso.baton = some(respJson["baton"].getStr)
  except:
    raise newException(TursoError, getCurrentExceptionMsg())

proc getData*(turso: Turso, sql: string, args: openArray[JsonNode] = @[], named_args: JsonNode = newJObject()): TursoResponse =
  ## Get data from a SQL statement with optional parameters
  ## turso: A Turso object
  ## sql: The SQL statement to execute
  ## args: Optional array of positional parameters
  ## named_args: Optional object of named parameters
  ## return: A TursoResponse object containing query results and metadata
  ## Example:
  ## ```var data = turso.getData("SELECT * FROM table WHERE id = ?", @[%*1])```
  ## ```var data = turso.getData("SELECT * FROM users WHERE name = :name", named_args = %*{"name": "John"})```
  var
    stmt = %*{"sql": sql}
  
  if args.len > 0:
    stmt["args"] = %args
  if named_args.len > 0:
    stmt["named_args"] = named_args

  var body = %*{
    "requests": [
      { "type": "execute", "stmt": stmt },
      { "type": "close" }
    ]
  }

  if turso.baton.isSome:
    body["baton"] = %turso.baton.get

  turso.client.headers = newHttpHeaders({ "Authorization": "Bearer " & turso.token, "Content-Type": "application/json" })

  try:
    var response = turso.client.request(turso.url, httpMethod = HttpPost, body = $body, headers = turso.client.headers)
    if response.code != Http200:
      raise newException(TursoError, "HTTP " & $response.code & ": " & response.body)
    
    let 
      respJson = parseJson(response.body)
      resultObj = respJson["results"][0]["response"]

    if respJson.hasKey("baton"):
      turso.baton = some(respJson["baton"].getStr)

    result = TursoResponse(
      cols: if resultObj.hasKey("cols"): resultObj["cols"].to(seq[string]) else: @[],
      rows: if resultObj.hasKey("rows"): resultObj["rows"].getElems else: @[],
      affected_row_count: if resultObj.hasKey("affected_row_count"): resultObj["affected_row_count"].getInt else: 0,
      last_insert_rowid: if resultObj.hasKey("last_insert_rowid"): resultObj["last_insert_rowid"].getBiggestInt else: 0,
      replication_index: if resultObj.hasKey("replication_index"): resultObj["replication_index"].getStr else: "",
      rows_read: if resultObj.hasKey("rows_read"): resultObj["rows_read"].getInt else: 0,
      rows_written: if resultObj.hasKey("rows_written"): resultObj["rows_written"].getInt else: 0,
      query_duration_ms: if resultObj.hasKey("query_duration_ms"): resultObj["query_duration_ms"].getFloat else: 0.0
    )
  except:
    raise newException(TursoError, getCurrentExceptionMsg())

proc close*(turso: Turso) =
  ## Close the connection to the Turso API
  ## turso: A Turso object
  ## Example:
  ## ```turso.close()```
  turso.client.close()

proc insertId*(turso: Turso, table: string, fields, values: seq[string]): int64 =
  ## Insert a row into a table
  ## turso: A Turso object
  ## table: The name of the table
  ## fields: The fields to insert into
  ## values: The values to insert
  ## return: The ID of the inserted row
  ## Example:
  ## ```var id = turso.insertId("table", @["field1", "field2"], @["value1", "value2"])```
  var
    fieldsStr = fields.join(", ")
    valuesStr = values.map(proc(x: string): string = "'" & x & "'").join(", ")
    sql = "INSERT INTO " & table & " (" & fieldsStr & ") VALUES (" & valuesStr & ");"

  result = turso.getData(sql).last_insert_rowid

proc vectorSearch*(turso: Turso, table, vectorColumn: string, queryVector: seq[float32], limit: int = 5): TursoResponse =
  ## Perform a vector similarity search
  ## turso: A Turso object
  ## table: The name of the table containing vectors
  ## vectorColumn: The column containing the vectors
  ## queryVector: The query vector to search for similar vectors
  ## limit: Maximum number of results to return
  ## Example:
  ## ```var results = turso.vectorSearch("embeddings", "vector", @[0.1'f32, 0.2'f32, 0.3'f32], 5)```
  let vectorStr = "[" & queryVector.map(proc(x: float32): string = $x).join(",") & "]"
  let sql = fmt"""SELECT *, vector_cosine_similarity({vectorColumn}, {vectorStr}) as similarity 
    FROM {table} 
    ORDER BY similarity DESC 
    LIMIT {limit};"""
  
  result = turso.getData(sql)

proc startTransaction*(turso: Turso) =
  ## Start a new transaction
  ## turso: A Turso object
  ## Example:
  ## ```turso.startTransaction()```
  turso.execute("BEGIN TRANSACTION;")

proc commit*(turso: Turso) =
  ## Commit the current transaction
  ## turso: A Turso object
  ## Example:
  ## ```turso.commit()```
  turso.execute("COMMIT;")

proc rollback*(turso: Turso) =
  ## Rollback the current transaction
  ## turso: A Turso object
  ## Example:
  ## ```turso.rollback()```
  turso.execute("ROLLBACK;")