import unittest, json, tables, options, httpcore, std/os
import jazzy/http/[types, context]

suite "Context Logic Tests":

  test "input() should prefer Query Params over Body":
    let req = JazzyRequest(
      queryParams: {"name": "QueryName"}.toTable,
      headers: newHttpHeaders(),
      body: """{"name": "BodyName"}"""
    )
    req.headers["Content-Type"] = "application/json"
    let ctx = newContext(req)

    check ctx.input("name") == "QueryName"

  test "input() should fallback to JSON Body":
    let req = JazzyRequest(
      queryParams: initTable[string, string](),
      headers: newHttpHeaders(),
      body: """{"name": "BodyName"}"""
    )
    req.headers["Content-Type"] = "application/json"
    let ctx = newContext(req)

    check ctx.input("name") == "BodyName"

  test "bodyAs[T] should deserialize JSON":
    type TestDto = ref object
      id: int
      name: string

    let req = JazzyRequest(
      body: """{"id": 123, "name": "Test"}"""
    )
    let ctx = newContext(req)
    let dto = ctx.bodyAs(TestDto)

    check dto.id == 123
    check dto.name == "Test"

  test "Responses should set body and headers":
    let req = JazzyRequest()
    let ctx = newContext(req)

    # Text
    ctx.text("Hello")
    check ctx.response.body == "Hello"
    check ctx.response.headers["Content-Type"] == "text/plain"

    # JSON
    ctx.json(%*{"a": 1})
    check ctx.response.body == """{"a":1}"""
    check ctx.response.headers["Content-Type"] == "application/json"

  test "JazzyRequest should store and retrieve client IP":
    let req = JazzyRequest(
      ip: "127.0.0.1"
    )
    let ctx = newContext(req)
    check ctx.request.ip == "127.0.0.1"
    check ctx.ip() == "127.0.0.1"

  test "Request ID should be generated and unique":
    let req1 = JazzyRequest()
    let ctx1 = newContext(req1)

    let req2 = JazzyRequest()
    let ctx2 = newContext(req2)

    # Format Check (8-4-4-4-12 hex format)
    # Example: 12345678-1234-1234-1234-123456789012
    let rid = ctx1.requestId
    check rid.len == 36
    check rid[8] == '-'
    check rid[13] == '-'
    check rid[18] == '-'
    check rid[23] == '-'

    # Uniqueness Check
    check ctx1.requestId != ctx2.requestId

    # Header check
    check ctx1.response.headers["X-Request-Id"] == ctx1.requestId



