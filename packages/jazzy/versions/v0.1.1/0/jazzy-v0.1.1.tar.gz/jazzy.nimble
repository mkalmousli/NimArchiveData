# Package

version       = "0.1.1"
author        = "canermastan"
description   = "Productive, developer-friendly web framework for Nim. Write less code, build more features."
license       = "MIT"
srcDir        = "src"
namedBin      = {"jazzy_cli": "jazzy"}.toTable()
installExt    = @["nim"]

# Dependencies

requires "nim >= 2.0.0"
requires "mummy >= 0.4.0"
requires "jwt >= 0.1.0"
requires "nimcrypto >= 0.5.4"
requires "tiny_sqlite >= 0.2.0"
