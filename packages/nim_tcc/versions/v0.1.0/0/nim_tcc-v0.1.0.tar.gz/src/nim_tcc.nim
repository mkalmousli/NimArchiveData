# src/nim_tcc.nim
import ./nim_tcc/private/bindings

type
  TccError* = object of CatchableError

  # Define base object first
  TccContextObj* = object
    state*: TccStatePtr
    errorBuffer*: string

# Define destructor immediately to prevent implicit generation
proc `=destroy`*(ctx: TccContextObj) =
  if ctx.state != nil:
    tcc_delete(ctx.state)

# Define the reference type
type TccContext* = ref TccContextObj

# Internal callback for error logging
proc errorCallback(opaque: pointer, msg: cstring) {.cdecl.} =
  let ctx = cast[TccContext](opaque)
  ctx.errorBuffer.add($msg & "\n")

# --- Public API ---

proc newTccContext*(outputType: int = 1): TccContext =
  ## Initializes a JIT context. Default is TCC_OUTPUT_MEMORY (1).
  result = TccContext(state: tcc_new(), errorBuffer: "")
  
  if result.state == nil:
    raise newException(TccError, "TinyCC initialization failed")
  
  # Set the error handler
  tcc_set_error_func(result.state, cast[pointer](result), errorCallback)
  
  # FIX: 'discard' the return value to resolve the "no type" error
  discard tcc_set_output_type(result.state, outputType.cint)

proc compile*(ctx: TccContext, code: string) =
  ## Compiles C source from a Nim string.
  ctx.errorBuffer = ""
  if tcc_compile_string(ctx.state, code.cstring) != 0:
    raise newException(TccError, "C Compilation Error:\n" & ctx.errorBuffer)

proc relocate*(ctx: TccContext) =
  ## Relocates code for memory execution.
  if tcc_relocate(ctx.state, cast[pointer](1)) < 0:
    raise newException(TccError, "Relocation failed")

proc bindSymbol*(ctx: TccContext, name: string, val: pointer) =
  ## Maps a Nim function/variable address to a C symbol.
  if tcc_add_symbol(ctx.state, name.cstring, val) != 0:
    raise newException(TccError, "Binding failed for symbol: " & name)

proc bindVariable*[T](ctx: TccContext, name: string, val: var T) =
  ## Maps a Nim variable directly to a C 'extern'.
  ctx.bindSymbol(name, addr(val))

proc getSymbol*[T](ctx: TccContext, name: string): T =
  ## Retrieves a JIT-compiled symbol and casts it to T.
  let res = tcc_get_symbol(ctx.state, name.cstring)
  if res == nil:
    raise newException(TccError, "Symbol not found: " & name)
  return cast[T](res)

proc listSymbols*(ctx: TccContext): seq[string] =
  ## Returns all active symbols in the JIT state via reflection.
  var syms: seq[string] = @[]
  proc cb(opaque: pointer, name: cstring, val: pointer) {.cdecl.} =
    cast[ptr seq[string]](opaque)[].add($name)
  
  tcc_list_symbols(ctx.state, addr(syms), cb)
  return syms

when isMainModule:
  let ctx = newTccContext()
  ctx.compile("int main() { return 42; }")
  echo "TCC is initialized and compiled successfully!"
