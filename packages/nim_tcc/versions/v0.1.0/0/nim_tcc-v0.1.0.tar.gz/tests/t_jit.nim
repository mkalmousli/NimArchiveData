# tests/t_jit.nim
import unittest
import ../src/nim_tcc

suite "nim-tcc JIT functionality":
  
  test "Compile and execute basic C":
    let ctx = newTccContext()
    ctx.compile("int add(int a, int b) { return a + b; }")
    ctx.relocate()
    
    type AddFunc = proc(a, b: cint): cint {.cdecl.}
    let add = ctx.getSymbol[AddFunc]("add")
    check add(10, 5) == 15

  test "Shared memory object mapping":
    type Status {.pure, packed.} = object
      id: cint
      active: bool

    var myStatus = Status(id: 7, active: false)
    let ctx = newTccContext()
    ctx.bindVariable("sys_status", myStatus)
    
    ctx.compile("""
      typedef struct { int id; int active; } Status;
      extern Status sys_status;
      void update() { sys_status.id = 101; sys_status.active = 1; }
    """)
    ctx.relocate()
    
    let update = ctx.getSymbol[proc() {.cdecl.}]("update")
    update()
    
    check myStatus.id == 101
    check myStatus.active == true

  test "Error catching":
    let ctx = newTccContext()
    expect TccError:
      ctx.compile("this is not valid c code")
