# src/nim_tcc.nim
# Static linking: compile with -d:tccStatic
# Dynamic linking: default

# Import bindings first (includes TccStatePtr type)
import ./nim_tcc/private/bindings

# Re-export the type
export bindings.TccStatePtr

# Type definitions (use same TccStatePtr from bindings)
type
  TccError* = object of CatchableError
  TccContextObj* = object
    state*: TccStatePtr
    errorBuffer*: string
  TccContext* = ref TccContextObj

# Static linking via command line flag
when defined(tccStatic):
  {.passL: "-L../../../".}
  {.link: "libtcc.a".}
  {.link: "libtcc1.a".}
  when defined(linux) or defined(android):
    {.passL: "-lm -ldl -lpthread".}
else:
  # Default: dynamic linking
  {.passL: "-L. -ltcc -ltcc1".}
  when defined(linux) or defined(android):
    {.passL: "-lm -ldl -lpthread".}

# Internal callback for error logging
proc errorCallback(opaque: pointer, msg: cstring) {.cdecl.} =
  let ctx = cast[TccContext](opaque)
  ctx.errorBuffer.add($msg & "\n")

# --- Public API ---

proc newTccContext*(outputType: int = 1): TccContext =
  ## Initializes a JIT context. Default is TCC_OUTPUT_MEMORY (1).
  result = TccContext(state: tcc_new(), errorBuffer: "")

  if result.state == nil:
    raise newException(TccError, "TinyCC initialization failed")

  tcc_set_error_func(result.state, cast[pointer](result), errorCallback)
  discard tcc_set_output_type(result.state, outputType.cint)

proc compile*(ctx: TccContext, code: string) =
  ## Compiles C source from a Nim string.
  ctx.errorBuffer = ""
  if tcc_compile_string(ctx.state, code.cstring) != 0:
    raise newException(TccError, "C Compilation Error:\n" & ctx.errorBuffer)

proc relocate*(ctx: TccContext) =
  ## Relocates code for memory execution.
  if tcc_relocate(ctx.state, cast[pointer](1)) < 0:
    raise newException(TccError, "Relocation failed")

proc bindSymbol*(ctx: TccContext, name: string, val: pointer) =
  ## Maps a Nim function/variable address to a C symbol.
  if tcc_add_symbol(ctx.state, name.cstring, val) != 0:
    raise newException(TccError, "Binding failed for symbol: " & name)

proc getSymbol*[T](ctx: TccContext, name: string): T =
  ## Retrieves a JIT-compiled symbol and casts it to T.
  let res = tcc_get_symbol(ctx.state, name.cstring)
  if res == nil:
    raise newException(TccError, "Symbol not found: " & name)
  return cast[T](res)

proc bindVariable*[T](ctx: TccContext, name: string, val: var T) =
  ## Maps a Nim variable directly to a C 'extern'.
  ctx.bindSymbol(name, addr(val))

proc listSymbols*(ctx: TccContext): seq[string] =
  ## Returns all active symbols in the JIT state via reflection.
  var syms: seq[string] = @[]
  proc cb(opaque: pointer, name: cstring, val: pointer) {.cdecl.} =
    cast[ptr seq[string]](opaque)[].add($name)
  tcc_list_symbols(ctx.state, addr(syms), cb)
  return syms

# --- Ultra Simple Function Calling API ---

import macros

macro ccall*(ctx: untyped, name: untyped, args: varargs[untyped]): untyped =
  ## Call a C function. That's it.
  ## Example: ccall(ctx, "add", 5, 3)
  let n = args.len
  let callName = case n
    of 0: "ccall0"
    of 1: "ccall1"
    of 2: "ccall2"
    of 3: "ccall3"
    of 4: "ccall4"
    else: "ccall0"  # fallback
  
  result = newCall(newIdentNode(callName))
  result.add(ctx)
  result.add(name)
  for arg in args:
    result.add(arg)

proc ccall0*(ctx: TccContext, name: string): cint =
  type FT = proc(): cint {.cdecl.}
  getSymbol[FT](ctx, name)()

proc ccall1*(ctx: TccContext, name: string, a: cint): cint =
  type FT = proc(a: cint): cint {.cdecl.}
  getSymbol[FT](ctx, name)(a)

proc ccall2*(ctx: TccContext, name: string, a, b: cint): cint =
  type FT = proc(a, b: cint): cint {.cdecl.}
  getSymbol[FT](ctx, name)(a, b)

proc ccall3*(ctx: TccContext, name: string, a, b, c: cint): cint =
  type FT = proc(a, b, c: cint): cint {.cdecl.}
  getSymbol[FT](ctx, name)(a, b, c)

proc ccall4*(ctx: TccContext, name: string, a, b, c, d: cint): cint =
  type FT = proc(a, b, c, d: cint): cint {.cdecl.}
  getSymbol[FT](ctx, name)(a, b, c, d)

when isMainModule:
  let ctx = newTccContext()
  ctx.compile("int main() { return 42; }")
  echo "TCC is initialized and compiled successfully!"
