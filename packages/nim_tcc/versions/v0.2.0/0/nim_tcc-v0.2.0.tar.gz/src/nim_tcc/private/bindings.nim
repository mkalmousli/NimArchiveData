# src/nim_tcc/private/bindings.nim
# Linking pragmas are applied in nim_tcc.nim

# Type definition (also defined in nim_tcc.nim for export purposes)
type
  TccStatePtr* = ptr object

# Functions mapped from your 'nm' output
proc tcc_new*(): TccStatePtr {.importc, cdecl.}
proc tcc_delete*(s: TccStatePtr) {.importc, cdecl.}
proc tcc_set_output_type*(s: TccStatePtr, t: cint): cint {.importc, cdecl.}
proc tcc_set_options*(s: TccStatePtr, options: cstring) {.importc, cdecl.}
proc tcc_compile_string*(s: TccStatePtr, buf: cstring): cint {.importc, cdecl.}
proc tcc_relocate*(s: TccStatePtr, p: pointer): cint {.importc, cdecl.}
proc tcc_get_symbol*(s: TccStatePtr, name: cstring): pointer {.importc, cdecl.}
proc tcc_add_symbol*(s: TccStatePtr, name: cstring, val: pointer): cint {.importc, cdecl.}
proc tcc_set_error_func*(s: TccStatePtr, error_opaque: pointer, error_func: proc(opaque: pointer, msg: cstring) {.cdecl.}) {.importc, cdecl.}
proc tcc_list_symbols*(s: TccStatePtr, ctx: pointer, callback: proc(ctx: pointer, name: cstring, val: pointer) {.cdecl.}) {.importc, cdecl.}
