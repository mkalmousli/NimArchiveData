# Package
version       = "0.2.0"
author        = "Deva"
description   = "A high-level, memory-safe Nim wrapper for the TinyCC (TCC) compiler engine."
license       = "MIT"
srcDir        = "src"

# Dependencies
requires "nim >= 2.2.6"

import std/os
import std/strutils

task setup, "Download and compile TinyCC locally":
  # In NimScript, we use & to join strings for paths to avoid the '/' type mismatch
  let tccDir = "vendor" & DirSep & "tinycc"

  if not dirExists("vendor"):
    mkDir("vendor")

  if not dirExists(tccDir):
    echo "--- Cloning TinyCC ---"
    exec "git clone --depth 1 https://repo.or.cz/tinycc.git " & tccDir

  withDir tccDir:
    # --config-pie for Android/Termux, --enable-static for static libtcc.a
    echo "--- Configuring TinyCC ---"
    exec "./configure --extra-cflags=-fPIC --config-pie --enable-static"
    echo "--- Building TinyCC ---"
    exec "make -j4"
    exec "make libtcc.a -j4"

  # Copy both static and shared libraries
  let
    staticLib = tccDir & DirSep & "libtcc.a"
    sharedLib = tccDir & DirSep & "libtcc.so"
    tcc1Lib = tccDir & DirSep & "libtcc1.a"

  if fileExists(staticLib):
    cpFile(staticLib, "libtcc.a")
    echo "--- Copied libtcc.a ---"

  if fileExists(sharedLib):
    cpFile(sharedLib, "libtcc.so")
    echo "--- Copied libtcc.so ---"

  # TCC sometimes puts libtcc1.a in a /lib subfolder depending on the 'make' version
  if fileExists(tcc1Lib):
    cpFile(tcc1Lib, "libtcc1.a")
  elif fileExists(tccDir & DirSep & "lib" & DirSep & "libtcc1.a"):
    cpFile(tccDir & DirSep & "lib" & DirSep & "libtcc1.a", "libtcc1.a")

  echo "--- TinyCC Build Successful ---"

before install:
  setupTask()
