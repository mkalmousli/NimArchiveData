# Example: Math Library - SIMPLE API
# Using the ergonomic callN helpers

import ../src/nim_tcc

let ctx = newTccContext()

# Compile a small math library
ctx.compile("""
  int factorial(int n) {
    if (n <= 1) return 1;
    return n * factorial(n - 1);
  }
  
  int fibonacci(int n) {
    if (n <= 0) return 0;
    if (n == 1) return 1;
    return fibonacci(n - 1) + fibonacci(n - 2);
  }
  
  int gcd(int a, int b) {
    while (b != 0) {
      int temp = b;
      b = a % b;
      a = temp;
    }
    return a;
  }
  
  int is_prime(int n) {
    if (n < 2) return 0;
    if (n == 2) return 1;
    if (n % 2 == 0) return 0;
    for (int i = 3; i * i <= n; i += 2) {
      if (n % i == 0) return 0;
    }
    return 1;
  }
""")

ctx.relocate()

# SIMPLE API - no type declarations needed!
echo "Factorial(5) = ", call1[cint, cint](ctx, "factorial", 5)
echo "Factorial(10) = ", call1[cint, cint](ctx, "factorial", 10)

echo "\nFibonacci(10) = ", call1[cint, cint](ctx, "fibonacci", 10)
echo "Fibonacci(15) = ", call1[cint, cint](ctx, "fibonacci", 15)

echo "\nGCD(48, 18) = ", call2[cint, cint, cint](ctx, "gcd", 48, 18)
echo "GCD(100, 35) = ", call2[cint, cint, cint](ctx, "gcd", 100, 35)

echo "\nIs 17 prime? ", if call1[cint, cint](ctx, "is_prime", 17) == 1: "Yes" else: "No"
echo "Is 20 prime? ", if call1[cint, cint](ctx, "is_prime", 20) == 1: "Yes" else: "No"
