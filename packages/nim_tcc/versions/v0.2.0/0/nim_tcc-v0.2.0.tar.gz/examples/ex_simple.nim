# Example: Ultra Simple API
# This is as simple as it gets!

import ../src/nim_tcc

let ctx = newTccContext()

ctx.compile("""
  int add(int a, int b) { return a + b; }
  int multiply(int a, int b) { return a * b; }
  int get_answer() { return 42; }
""")

ctx.relocate()

# THAT'S IT - just call it!
echo "5 + 3 = ", ccall(ctx, "add", 5, 3)
echo "4 * 7 = ", ccall(ctx, "multiply", 4, 7)
echo "Answer = ", ccall(ctx, "get_answer")
