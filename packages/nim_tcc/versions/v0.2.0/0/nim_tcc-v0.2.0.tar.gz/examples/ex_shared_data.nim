# Example 2: Bidirectional Data Sharing
# Share data between Nim and C

import ../src/nim_tcc

# Define a Nim struct that will be shared with C
type
  PlayerData {.pure.} = object
    health: cint
    score: cint
    name: array[32, char]

var player = PlayerData(health: 100, score: 0)
player.name[0..3] = ['H', 'e', 'r', 'o']

let ctx = newTccContext()

# Bind Nim variable to C
ctx.bindVariable("player_data", player)

# C code that modifies the shared data
ctx.compile("""
  typedef struct { int health; int score; char name[32]; } PlayerData;
  extern PlayerData player_data;
  
  void takeDamage(int amount) {
    player_data.health -= amount;
  }
  
  void addScore(int points) {
    player_data.score += points;
  }
""")

ctx.relocate()

echo "Initial state:"
echo "  Health: ", player.health
echo "  Score:  ", player.score

# Call C functions that modify Nim data
let takeDamage = getSymbol[proc(amount: cint) {.cdecl.}](ctx, "takeDamage")
let addScore = getSymbol[proc(points: cint) {.cdecl.}](ctx, "addScore")

takeDamage(30)
addScore(500)

echo "\nAfter C modifications:"
echo "  Health: ", player.health  # Should be 70
echo "  Score:  ", player.score   # Should be 500
