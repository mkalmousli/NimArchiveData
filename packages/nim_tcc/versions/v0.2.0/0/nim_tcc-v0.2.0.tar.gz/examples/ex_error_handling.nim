# Example 5: Error Handling
# Handle C compilation errors gracefully

import ../src/nim_tcc
import std/strutils

echo "=== Testing Error Handling ===\n"

# Test 1: Valid code
echo "Test 1: Compiling valid C code..."
try:
  let ctx1 = newTccContext()
  ctx1.compile("int valid_func() { return 42; }")
  ctx1.relocate()
  echo "  SUCCESS: Code compiled and relocated\n"
except TccError as e:
  echo "  FAILED: ", e.msg, "\n"

# Test 2: Syntax error
echo "Test 2: Compiling code with syntax error..."
try:
  let ctx2 = newTccContext()
  ctx2.compile("int broken_func( { return 42; }")  # Missing parameter name
  echo "  UNEXPECTED: Should have failed\n"
except TccError as e:
  echo "  EXPECTED ERROR:"
  let lines = e.msg.split('\n')
  for i in 0..min(2, lines.len-1):
    echo "    ", lines[i]
  echo ""

# Test 3: Type error
echo "Test 3: Compiling code with type error..."
try:
  let ctx3 = newTccContext()
  ctx3.compile("""
    int type_error() {
      int x = "hello";  // Type mismatch
      return x;
    }
  """)
  echo "  UNEXPECTED: Should have failed\n"
except TccError as e:
  echo "  EXPECTED ERROR:"
  let lines = e.msg.split('\n')
  for i in 0..min(2, lines.len-1):
    echo "    ", lines[i]
  echo ""

# Test 4: Symbol not found
echo "Test 4: Getting non-existent symbol..."
try:
  let ctx4 = newTccContext()
  ctx4.compile("int existing_func() { return 1; }")
  ctx4.relocate()
  type FuncType = proc(): cint {.cdecl.}
  let nonexistent = getSymbol[FuncType](ctx4, "nonexistent_func")
  echo "  UNEXPECTED: Should have failed\n"
except TccError as e:
  echo "  EXPECTED ERROR: ", e.msg, "\n"

echo "=== Error Handling Tests Complete ==="
