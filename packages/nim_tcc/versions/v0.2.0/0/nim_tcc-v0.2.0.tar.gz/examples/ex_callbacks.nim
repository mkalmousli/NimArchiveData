# Example 3: Callbacks - C Calling Nim Functions
# Register Nim functions as C callbacks

import ../src/nim_tcc

# Define a Nim callback function
proc nimLogger(msg: cstring) {.cdecl.} =
  echo "[Nim Logger] ", $msg

let ctx = newTccContext()

# Bind the Nim function so C can call it
ctx.bindSymbol("nim_log", nimLogger)

# C code that calls the Nim callback
ctx.compile("""
  extern void nim_log(const char* msg);
  
  void process_data(int value) {
    char buffer[64];
    // Simple logging via callback
    nim_log("Processing started");
    nim_log("Data processing complete");
  }
  
  const char* get_status() {
    return "OK";
  }
""")

ctx.relocate()

# Call the C function which will call back into Nim
type ProcessFunc = proc(value: cint) {.cdecl.}
type StatusFunc = proc(): cstring {.cdecl.}

let process = getSymbol[ProcessFunc](ctx, "process_data")
let getStatus = getSymbol[StatusFunc](ctx, "get_status")

echo "Calling C function with Nim callback:"
process(42)

echo "\nStatus: ", $getStatus()
