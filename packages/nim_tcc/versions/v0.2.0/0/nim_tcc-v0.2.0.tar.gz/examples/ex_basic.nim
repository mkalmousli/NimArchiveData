# Example 1: Basic JIT Compilation - SIMPLE API
# Compile and execute C code at runtime

import ../src/nim_tcc

let ctx = newTccContext()

# Define a C function
ctx.compile("""
  int add(int a, int b) {
    return a + b;
  }
""")

ctx.relocate()

# OLD WAY (still works):
# type AddFunc = proc(a, b: cint): cint {.cdecl.}
# let add = getSymbol[AddFunc](ctx, "add")
# echo "add(10, 5) = ", add(10, 5)

# NEW SIMPLE WAY - just specify return and arg types:
echo "add(10, 5) = ", call2[cint, cint, cint](ctx, "add", 10, 5)
echo "add(100, 200) = ", call2[cint, cint, cint](ctx, "add", 100, 200)
