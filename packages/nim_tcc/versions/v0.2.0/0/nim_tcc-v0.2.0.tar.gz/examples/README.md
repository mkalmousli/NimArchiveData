# nim-tcc Examples

This directory contains example programs demonstrating various features of the nim-tcc library.

## Building

### Dynamic Linking (requires libtcc.so at runtime)
```bash
cd examples
LD_LIBRARY_PATH=.. nim c -r ex_simple.nim
```

### Static Linking (no external dependencies)
```bash
cd examples
nim c -d:tccStatic -r ex_simple.nim
```

## Examples

### ex_simple.nim
**The easiest way to call C functions!** Shows the new simple API:
```nim
import nim_tcc

let ctx = newTccContext()
ctx.compile("int add(int a, int b) { return a + b; }")
ctx.relocate()

# Simple! Just specify return type and arg types:
echo call2[cint, cint, cint](ctx, "add", 5, 3)  # Prints: 8
```

### ex_basic.nim
Basic JIT compilation example. Shows both old and new API styles.

### ex_shared_data.nim
Bidirectional data sharing between Nim and C. Shows how to:
- Share Nim objects with C code
- Modify Nim data from C functions

### ex_callbacks.nim
Callback functions. Shows how to:
- Register Nim functions as C callbacks
- Call Nim code from C functions

### ex_math.nim
Multiple function compilation using the simple API:
```nim
echo call1[cint, cint](ctx, "factorial", 5)      # 120
echo call2[cint, cint, cint](ctx, "gcd", 48, 18) # 6
```

### ex_error_handling.nim
Error handling patterns. Shows how to catch compilation errors.

## Simple API Reference

### Calling C Functions

| Function | Description | Example |
|----------|-------------|---------|
| `call0[Ret]` | Call with 0 args | `call0[cint](ctx, "get_value")` |
| `call1[Ret, A]` | Call with 1 arg | `call1[cint, cint](ctx, "square", 5)` |
| `call2[Ret, A, B]` | Call with 2 args | `call2[cint, cint, cint](ctx, "add", 1, 2)` |
| `call3[Ret, A, B, C]` | Call with 3 args | `call3[cint, cint, cint, cint](ctx, "foo", a, b, c)` |
| `call4[Ret, A, B, C, D]` | Call with 4 args | `call4[cint, ...](ctx, "bar", a, b, c, d)` |

For procedures (no return value), use `void` as the return type:
```nim
call0[void](ctx, "print_hello")
```

### Old API (Still Works)

The original `getSymbol` API still works for complex cases:
```nim
type MyFunc = proc(a, b: cint): cint {.cdecl.}
let func = getSymbol[MyFunc](ctx, "my_function")
echo func(10, 20)
```

## Tips

1. **Simple API**: Use `callN[Ret, Args...]` for most cases - it's cleaner!
2. **Static vs Dynamic**: Use `-d:tccStatic` for portable binaries.
3. **Memory Management**: The TCC context is automatically cleaned up.
4. **Calling Conventions**: The simple API handles `{.cdecl.}` automatically.
5. **Type Safety**: All type checking happens at compile time.
