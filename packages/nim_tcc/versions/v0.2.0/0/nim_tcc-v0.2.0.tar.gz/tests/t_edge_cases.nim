# tests/t_edge_cases.nim
import std/unittest
import ../src/nim_tcc

suite "Edge Cases":

  test "Empty function":
    let ctx = newTccContext()
    ctx.compile("void noop() { }")
    ctx.relocate()
    type NoopFunc = proc() {.cdecl.}
    let noop = getSymbol[NoopFunc](ctx, "noop")
    noop()  # Should not crash

  test "Large return value":
    let ctx = newTccContext()
    ctx.compile("int large() { return 999999; }")
    ctx.relocate()
    type LargeFunc = proc(): cint {.cdecl.}
    let large = getSymbol[LargeFunc](ctx, "large")
    check large() == 999999

  test "Negative numbers":
    let ctx = newTccContext()
    ctx.compile("int negative() { return -42; }")
    ctx.relocate()
    type NegFunc = proc(): cint {.cdecl.}
    let negative = getSymbol[NegFunc](ctx, "negative")
    check negative() == -42

  test "Multiple contexts":
    let ctx1 = newTccContext()
    ctx1.compile("int func1() { return 1; }")
    ctx1.relocate()
    
    let ctx2 = newTccContext()
    ctx2.compile("int func2() { return 2; }")
    ctx2.relocate()
    
    type FuncType = proc(): cint {.cdecl.}
    let func1 = getSymbol[FuncType](ctx1, "func1")
    let func2 = getSymbol[FuncType](ctx2, "func2")
    
    check func1() == 1
    check func2() == 2

  test "String literal in C":
    let ctx = newTccContext()
    ctx.compile("""
      const char* get_hello() {
        return "Hello from C";
      }
    """)
    ctx.relocate()
    type StringFunc = proc(): cstring {.cdecl.}
    let getHello = getSymbol[StringFunc](ctx, "get_hello")
    check $getHello() == "Hello from C"

  test "Array access":
    let ctx = newTccContext()
    ctx.compile("""
      int get_element(int* arr, int index) {
        return arr[index];
      }
    """)
    ctx.relocate()
    type ArrayFunc = proc(arr: ptr cint, index: cint): cint {.cdecl.}
    let getElement = getSymbol[ArrayFunc](ctx, "get_element")
    
    var arr: array[5, cint] = [10, 20, 30, 40, 50]
    check getElement(addr(arr[0]), 2) == 30

  test "Pointer arithmetic":
    let ctx = newTccContext()
    ctx.compile("""
      int add_offset(int* p, int offset) {
        return *(p + offset);
      }
    """)
    ctx.relocate()
    type PtrFunc = proc(p: ptr cint, offset: cint): cint {.cdecl.}
    let addOffset = getSymbol[PtrFunc](ctx, "add_offset")
    
    var arr: array[5, cint] = [100, 200, 300, 400, 500]
    check addOffset(addr(arr[0]), 3) == 400
