# tests/t_stdlib.nim
import std/unittest
import ../src/nim_tcc

suite "C Standard Library":

  test "printf (compiles without error)":
    let ctx = newTccContext()
    ctx.compile("""
      #include <stdio.h>
      void print_hello() {
        printf("Hello\\n");
      }
    """)
    ctx.relocate()
    type PrintFunc = proc() {.cdecl.}
    let printHello = getSymbol[PrintFunc](ctx, "print_hello")
    printHello()  # Should not crash

  test "memset":
    let ctx = newTccContext()
    ctx.compile("""
      #include <string.h>
      void fill_array(int* arr, int size, int value) {
        memset(arr, value, size * sizeof(int));
      }
    """)
    ctx.relocate()
    type FillFunc = proc(arr: ptr cint, size: cint, value: cint) {.cdecl.}
    let fillArray = getSymbol[FillFunc](ctx, "fill_array")
    
    var arr: array[5, cint]
    fillArray(addr(arr[0]), 5, 0x42)
    # Note: memset works byte-wise, so 0x42 becomes 0x42424242 on little-endian
    check arr[0] == 0x42424242

  test "memcpy":
    let ctx = newTccContext()
    ctx.compile("""
      #include <string.h>
      void copy_array(int* src, int* dst, int count) {
        memcpy(dst, src, count * sizeof(int));
      }
    """)
    ctx.relocate()
    type CopyFunc = proc(src, dst: ptr cint, count: cint) {.cdecl.}
    let copyArray = getSymbol[CopyFunc](ctx, "copy_array")
    
    var src: array[5, cint] = [1, 2, 3, 4, 5]
    var dst: array[5, cint]
    copyArray(addr(src[0]), addr(dst[0]), 5)
    check dst[2] == 3

  test "strlen":
    let ctx = newTccContext()
    ctx.compile("""
      #include <string.h>
      int get_length(const char* str) {
        return (int)strlen(str);
      }
    """)
    ctx.relocate()
    type LenFunc = proc(str: cstring): cint {.cdecl.}
    let getLength = getSymbol[LenFunc](ctx, "get_length")
    check getLength("Hello") == 5

  test "malloc and free":
    let ctx = newTccContext()
    ctx.compile("""
      #include <stdlib.h>
      int* allocate_and_set(int value) {
        int* ptr = (int*)malloc(sizeof(int));
        *ptr = value;
        return ptr;
      }
      void free_int(int* ptr) {
        free(ptr);
      }
    """)
    ctx.relocate()
    type AllocFunc = proc(value: cint): ptr cint {.cdecl.}
    type FreeFunc = proc(p: ptr cint) {.cdecl.}

    let allocate = getSymbol[AllocFunc](ctx, "allocate_and_set")
    let freeInt = getSymbol[FreeFunc](ctx, "free_int")

    let p = allocate(42)
    check p[] == 42
    freeInt(p)  # Should not crash
