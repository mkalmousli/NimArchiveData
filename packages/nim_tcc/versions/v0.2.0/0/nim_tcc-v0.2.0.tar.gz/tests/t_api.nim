# tests/t_api.nim
import std/unittest
import ../src/nim_tcc

suite "API Tests":

  test "newTccContext returns non-nil":
    let ctx = newTccContext()
    check ctx != nil
    check ctx.state != nil

  test "compile returns error for invalid code":
    let ctx = newTccContext()
    expect TccError:
      ctx.compile("this is not valid c")

  test "getSymbol raises for missing symbol":
    let ctx = newTccContext()
    ctx.compile("int existing() { return 1; }")
    ctx.relocate()
    type FuncType = proc(): cint {.cdecl.}
    expect TccError:
      discard getSymbol[FuncType](ctx, "nonexistent")

  test "bindSymbol works":
    var nimValue: cint = 42
    let ctx = newTccContext()
    ctx.bindSymbol("my_value", addr(nimValue))
    ctx.compile("""
      extern int my_value;
      int get_value() { return my_value; }
    """)
    ctx.relocate()
    type GetFunc = proc(): cint {.cdecl.}
    let getValue = getSymbol[GetFunc](ctx, "get_value")
    check getValue() == 42
    
    # Modify from Nim side
    nimValue = 100
    check getValue() == 100

  test "bindVariable works":
    var myVar: cint = 5
    let ctx = newTccContext()
    ctx.bindVariable("c_var", myVar)
    ctx.compile("""
      extern int c_var;
      void set_var(int val) { c_var = val; }
    """)
    ctx.relocate()
    type SetFunc = proc(val: cint) {.cdecl.}
    let setVar = getSymbol[SetFunc](ctx, "set_var")
    
    setVar(99)
    check myVar == 99

  test "Multiple compiles on same context":
    let ctx = newTccContext()
    ctx.compile("int func_a() { return 1; }")
    # Second compile should work (appends)
    ctx.compile("int func_b() { return 2; }")
    ctx.relocate()
    
    type FuncType = proc(): cint {.cdecl.}
    let funcA = getSymbol[FuncType](ctx, "func_a")
    let funcB = getSymbol[FuncType](ctx, "func_b")
    
    check funcA() == 1
    check funcB() == 2

  test "listSymbols returns symbols":
    let ctx = newTccContext()
    ctx.compile("""
      int symbol_a() { return 1; }
      int symbol_b() { return 2; }
    """)
    ctx.relocate()
    
    let syms = listSymbols(ctx)
    check syms.len >= 2
    check "symbol_a" in syms
    check "symbol_b" in syms

  test "Context cleanup (no crash on destroy)":
    block:
      let ctx = newTccContext()
      ctx.compile("int test() { return 1; }")
      # Context should be cleaned up automatically when it goes out of scope
