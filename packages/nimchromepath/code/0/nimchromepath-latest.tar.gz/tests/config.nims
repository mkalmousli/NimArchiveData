
switch("path", "$projectDir/../src")
