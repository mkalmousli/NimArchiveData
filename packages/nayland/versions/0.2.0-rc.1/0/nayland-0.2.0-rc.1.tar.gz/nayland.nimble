# Package

version = "0.2.0"
author = "xTrayambak"
description = "High-level Nim wrapper around libwayland's client interface"
license = "BSD-3-Clause"
srcDir = "src"

# Dependencies

requires "nim >= 2.2.0"
