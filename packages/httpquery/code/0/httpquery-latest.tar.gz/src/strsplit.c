#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#if !defined(_WIN32)
	#include <sys/types.h>
#endif

#include "strsplit.h"

void strsplit_init(
	strsplit_t* const strsplit,
	strsplit_part_t* const part,
	const char* const string,
	const char* const sep
) {
	
	if (string == NULL) {
		return;
	}
	
	strsplit->sstart = string;
	strsplit->send = strchr(strsplit->sstart, '\0');
	
	strsplit->sep = sep;
	
	strsplit->cur_pbegin = NULL;
	strsplit->cur_pend = NULL;
	
	strsplit->pbegin = strsplit->sstart;
	strsplit->pend = strstr(strsplit->pbegin, strsplit->sep);
	
	strsplit->eof = 0;
	
	part->index = 0;
	part->size = 0;
	part->begin = NULL;
	
}

const strsplit_part_t* strsplit_next(
	strsplit_t* const strsplit,
	strsplit_part_t* const part
) {
	
	int seek = 0;
	
	size_t part_size = 0;
	
	if (strsplit->sstart == NULL) {
		return NULL;
	}
	
	if (strsplit->eof) {
		return NULL;
	}
	
	if (*strsplit->sep == '\0') {
		strsplit->eof = 1;
		return NULL;
	}
	
	if (strsplit->pend == NULL) {
		strsplit->pend = strsplit->send;
	}
	
	part_size = (size_t) (strsplit->pend - strsplit->pbegin);
	
	part->begin = (char*) strsplit->pbegin;
	part->size = part_size;
	
	if (part_size > 0) {
		const char* start = strsplit->pbegin;
		const char* end = strsplit->pend;
		
		while (start != end) {
			const char ch = *start;
			
			if (!isspace(ch)) {
				break;
			}
			
			start++;
		}
		
		seek = (start != end && end != strsplit->send);
		
		if (seek) {
			end -= strlen(strsplit->sep);
		}
		
		while (end != start) {
			const unsigned char ch = *end;
			
			if (!isspace(ch)) {
				break;
			}
			
			end--;
		}
		
		part->begin = NULL;
		part->size = 0;
		
		if (seek) {
			end++;
		}
		
		if (end != start) {
			part->begin = (char*) start;
			part->size = (size_t) (end - start);
		}
	}
	
	strsplit->eof = (strsplit->pend == strsplit->send);
	
	if (strsplit->eof && part_size < 1) {
		return NULL;
	}
	
	if (strsplit->pbegin != strsplit->sstart) {
		part->index++;
	}
	
	strsplit->cur_pbegin = strsplit->pbegin;
	strsplit->cur_pend = strsplit->pend;
	
	strsplit->pbegin = NULL;
	strsplit->pend = NULL;
	
	if (!strsplit->eof) {
		strsplit->pbegin = (strsplit->cur_pend + strlen(strsplit->sep));
		strsplit->pend = strstr(strsplit->pbegin, strsplit->sep);
	}
	
	return part;
	
}

int strsplit_resize(
	const strsplit_t* const strsplit,
	strsplit_part_t* const part
) {
	
	ssize_t value = 0;
	
	if ((part->begin + part->size) <= strsplit->cur_pend) {
		return 0;
	}
	
	value = (ssize_t) (strsplit->cur_pend - part->begin);
	
	if (value < 0) {
		return -1;
	}
	
	part->size = (size_t) value;
	
	return 0;
	
}

size_t strsplit_size(
	strsplit_t* const strsplit,
	strsplit_part_t* const part
) {
	
	strsplit_t strsplit2 = {0};
	strsplit_part_t part2 = {0};
	size_t size = 0;
	
	memcpy(&strsplit2, strsplit, sizeof(*strsplit));
	memcpy(&part2, part, sizeof(*part));
	
	while (strsplit_next(strsplit, part) != NULL) {
		size++;
	}
	
	memcpy(strsplit, &strsplit2, sizeof(strsplit2));
	memcpy(part, &part2, sizeof(part2));
	
	return size;
	
}

char* strsplit_findstr(strsplit_part_t* const part, const char* const pattern) {
	
	char* const begin = strstr(part->begin, pattern);
	const char* const end = (part->begin + part->size);
	
	if (begin > end) {
		return NULL;
	}
	
	return begin;
	
}