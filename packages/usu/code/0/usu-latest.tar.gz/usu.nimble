# Package

version       = "0.1.0"
author        = "Daylin Morgan"
description   = "usu parser/writer"
license       = "MIT"
srcDir        = "src"

# Dependencies

requires "nim >= 2.0.0"
