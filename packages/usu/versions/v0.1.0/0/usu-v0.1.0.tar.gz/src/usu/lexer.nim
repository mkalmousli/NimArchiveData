import std/strutils

const whitespaces = {' ', '\t', '\v', '\f', '\r'}

type
  TokenKind* = enum
    tokLCurly, tokRCurly,
    tokLBracket, tokRBracket
    tokKey, tokString,
    tokEnd
  Token* = object
    pos*: int ## start position of the token
    case kind*: TokenKind
    of tokString: stringVal*: string
    of tokKey: keyVal*: string
    else: discard
  LexerMode = enum
    ChompNewlines, InlineString, RespectNewlines
  Lexer = ref object
    input: string
    pos: int
    tokens: seq[Token]
    modes: set[LexerMode]

const Quotes = {'"', '\'', '`'}
const OpenBrackets = {'[', '{'}
const CloseBrackets = {'}', ']'}
const Brackets = OpenBrackets + CloseBrackets
const Syntax = Brackets + {'.', '>', '#'}

proc newTokKey(pos: int, val: string): Token =
  Token(kind: tokKey, pos: pos, keyVal: val)

proc newTokString(pos: int, val: string): Token =
  Token(kind: tokString, pos: pos, stringVal: val)

# TODO: support more escape sequences?
proc subEscapeSeqs(s: string): string =
  result = multiReplace(
    s, {
        "\\n": "\n",
        "\\t": "\t",
        "\\\\": "\\",
        "\\\"": "\""
      }
  )

when defined(debugUsu):
  proc debugUsu(pos: int, input: string, modes: set[LexerMode]) =
    for i, c in input:
      if pos == i:
        stdout.write("!>>>>")
        stdout.write(c)
        stdout.write("<<<<!")
      else:
        stdout.write(c)
    stdout.write("\n^^^^" & $modes & "^^^^^\n")

proc new(T: typedesc[Lexer], input: string): Lexer =
  new(result)
  result.input = input

proc curr(l: Lexer): char {.inline.} =
  if l.pos < l.input.len: l.input[l.pos]
  else: '\x00'

proc next(l: Lexer): char {.inline.} =
  if l.pos+1 < l.input.len: l.input[l.pos+1]
  else: '\x00'

proc prev(l: Lexer): char {.inline.} =
  if l.pos - 1 >= 0: l.input[l.pos-1]
  else: '\x00'

proc inc(l: var Lexer, n: Natural = 1) =
  inc l.pos, n

proc add(l: var Lexer, t: Token) =
  l.tokens.add t

proc set(l: var Lexer, mode: LexerMode) =
  l.modes.incl mode

proc drop(l: var Lexer, mode: LexerMode) =
  l.modes.excl mode

proc drop(l: var Lexer, modes: varargs[LexerMode]) =
  for m in modes:
    l.modes.excl m

proc isSet(l: var Lexer, mode: LexerMode): bool =
  mode in l.modes

proc skip(
  l: var Lexer,
  chars = whitespaces + {'\n', '\r'}
) =
  let startPos = l.pos
  while l.curr in chars:
    l.inc
  # why do I iterate then check the modes?
  if (l.curr notin Syntax + Quotes) and not l.isSet(InlineString):
    l.pos = startPos

proc skipComment(l: var Lexer) =
  inc l
  if l.curr == '(':
    inc l
    while (l.curr & l.next) != ")#": inc l
    inc l
  else:
    while l.curr notin NewLines:
      inc l
    inc l

func addBracket(l: var Lexer) =
  let kind = case l.curr
    of '[': tokLBracket
    of ']': tokRBracket
    of '{': tokLCurly
    of '}': tokRCurly
    else: raise newException(ValueError, "failed to lex token, unexpected char: " & $l.curr)
  l.add Token(pos: l.pos, kind: kind)

func lexBracket(l: var Lexer) =
  l.addBracket
  l.inc
  case l.prev:
  of OpenBrackets:
    if l.curr notin NewLines:
      l.set(InlineString)
  of CloseBrackets:
    l.drop(InlineString)
  of '\x00': discard
  else: assert false

proc lexKey(l: var Lexer) =
  var key = ""
  let start = l.pos
  l.inc
  if l.curr in Quotes:
    let q = l.curr
    l.inc
    while l.curr != q:
      # we need to escape periods to prevent path splitting in parser
      if l.curr == '.':
        key.add '\\'
      key.add(l.curr)
      l.inc
    l.inc
  else:
    while l.curr notin Newlines + {' ', '}'}:
      key.add(l.curr)
      l.inc
  l.add newTokKey(start, key)

  if l.curr == '\n':
    l.set RespectNewlines
  elif l.curr & l.next == " >":
    l.set ChompNewLines
    inc(l, 2)

proc lexQuotedVal(l: var Lexer) = 
  let quote = l.curr
  var str = ""
  let start = l.pos
  l.inc
  while true:
    str.add(l.curr)
    if (l.next == quote and l.curr != '\\') or (l.next == quote and l.curr & l.prev == "\\\\"):
      inc l, 2; break
    l.inc
  l.add newTokString(start, subEscapeSeqs(str))

proc lexUnquotedVal(l: var Lexer) =

# proc lexUnquoted(
#   pos: var int,
#   input: string,
#   tokens: var seq[Token],
#   modes: var set[LexerMode]
# ) =
  # template current: char =
  #   if pos < input.len: input[pos]
  #   else: '\x00'
  # template prev: char =
  #   if pos - 1 > 0: input[pos - 1]
  #   else: '\x00'
  # template next: char =
  #   if pos + 1 < input.len: input[pos + 1]
  #   else: '\x00'
  template keystart: bool =
    l.curr == '.' and l.prev in {' ', '\n', '\r'}
  template eof: bool = l.curr == '\x00'

  var str = ""

  let strEnd = {'}',']', '[', '{'} + (
    if l.isSet(InlineString) and l.tokens[^1].kind != tokKey: {' ', '\n'}
    elif l.tokens.len > 0 and l.tokens[^1].kind == tokKey: {'\x00'}
    else: {'\n'}
  )
  let start = l.pos
  while true:
    if l.curr == '#':
      # remove any trailing whitespace before comment
      str = strip(str, leading = false)
      l.skipComment
      if l.curr == '.': break
    else:
      str.add(l.curr)
    l.inc
    if keystart or (l.curr in strEnd) or eof: break
 
  str =
    if l.isSet(InlineString): strip(str)
    else: dedent(str)
  let newlineEnd = str.len > 0 and str[^1] in NewLines
  str = strip(str, chars = whitespaces + NewLines)
  str = subEscapeSeqs(str)
  if l.isSet(ChompNewLines): str = str.splitLines().join(" ")

  if str != "":
    if l.isSet(RespectNewlines) and newLineEnd:
      str.add "\n"
    l.add newTokString(start, str)

  l.drop RespectNewlines, ChompNewlines


proc lex*(l: var Lexer) =
  while l.pos < l.input.len:
    skip l
    when defined(debugUsu):
      debugUsu(l.pos, l.input, l.modes)
    case l.curr
    of '#': skipComment l
    of Brackets: l.lexBracket
    of Newlines: l.inc
    of '.': l.lexKey
    of '>': l.inc # skipping this newline will in effect activate InlineString
    of Quotes: l.lexQuotedVal
    else: l.lexUnquotedVal

  if l.tokens[0].kind == tokKey:
    l.tokens = @[Token(kind: tokLCurly, pos: -1)] & l.tokens & @[Token(kind: tokRCurly, pos: l.pos + 1)]

  l.add Token(kind: tokEnd)

proc lex*(s: string): seq[Token] =
  var lexer = Lexer.new(s)
  lexer.lex()
  result = lexer.tokens

