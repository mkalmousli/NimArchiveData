import std/unittest
import std/os
import std/strutils
import std/strformat
import opresult
import stfrunner
import tables
import comparelines

proc testGetAnyLine(line: string, eAnyLine: AnyLine): bool =

  let anyLineOr = getAnyLine(line)
  if anyLineOr.isMessage:
    echo "Error getting line:"
    echo anyLineOr.message
    return false

  let anyLine = anyLineOr.value
  result = true
  if anyLine.kind != eAnyLine.kind:
    echo "Did not get the expected line type:"
    echo fmt"     got: {anyLine.kind}"
    echo    "expected: {eAnyLine.kind}"
    result = false

  if $anyLine != $eAnyLine:
    echo "Did not get the expected line:"
    echo fmt"     got: {anyLine}"
    echo fmt"expected: {eAnyLine}"
    result = false

proc createFile*(filename: string, content: string) =
  ## Create a file with the given content.
  var file = open(filename, fmWrite)
  file.write(content)
  file.close()

proc showExpectedLines*[T](gotLines: seq[T], expectedLines: seq[T], 
    showSame = false, stopOnFirstDiff = false): bool =
  ## Compare two sets of lines and show the differences.  If no
  ## differences, return true.

  result = true
  for ix in countUp(0, max(gotLines.len, expectedLines.len)-1):
    var gLine = ""
    if ix < gotLines.len:
      gLine = $gotLines[ix]

    var eLine = ""
    if ix < expectedLines.len:
      eLine = $expectedLines[ix]

    var lineNum = $(ix+1)
    if eLine == gLine:
      if showSame:
        echo "$1     same: '$2'" % [lineNum, eLine]
    else:
      echo "$1      got: '$2'" % [lineNum, gLine]
      echo "$1 expected: '$2'" % [lineNum, eLine]
      result = false
      if stopOnFirstDiff:
        break

proc testMakeDirAndFiles(filename: string, content: string,
    expectedDirAndFilesOp: comparelines.OpResultStr[DirAndFiles]): bool =
  ## Test the makeDirAndFiles procedure. The filename is created with
  ## the content then the makeDirAndFiles procedure is called and then
  ## the result of comparing the result with the expected result is
  ## returned. The file and tempdir remain.

  # Remove the temp dir if it exists.
  let tempdir = filename & ".tempdir"
  removeDir(tempdir)

  # Create the file with the given content.
  createFile(filename, content)

  # proc makeDirAndFiles*(filename: string): OpResultStr[DirAndFiles] =

  # Call makeDirAndFiles.
  result = true
  let dirAndFilesOp = makeDirAndFiles(filename)
  if expectedDirAndFilesOp.isMessage and dirAndFilesOp.isValue:
    echo "Got value but expected message."
    echo "       got value: " & $dirAndFilesOp.value
    echo "expected message: " & expectedDirAndFilesOp.message
    result = false
  elif expectedDirAndFilesOp.isValue and dirAndFilesOp.isMessage:
    echo "Got message bu expected value."
    echo "   got message: " & dirAndFilesOp.message
    echo "expected value: " & $expectedDirAndFilesOp.value
    result = false
  elif expectedDirAndFilesOp.isValue and dirAndFilesOp.isValue:

    let got = dirAndFilesOp.value
    let expected = expectedDirAndFilesOp.value
    if got != expected:

      # expectedLines: seq[ExpectedLine]
      # runFileLines: seq[RunFileLine]

      if got.expectedLines == expected.expectedLines:
        echo "same expectedLines"
      else:
        echo "expectedLines:"
        discard showExpectedLines(got.expectedLines, expected.expectedLines)

      if got.runFileLines == expected.runFileLines:
        echo "same runFileLines"
      else:
        echo "runFileLines:"
        discard showExpectedLines(got.runFileLines, expected.runFileLines)

      result = false
  else:
    if expectedDirAndFilesOp.message != dirAndFilesOp.message:
      echo "     got message: '$1'" % dirAndFilesOp.message
      echo "expected message: '$1'" % expectedDirAndFilesOp.message
      result = false

proc removeFileAndTempdir(filename: string) =
  let tempdir = filename & ".tempdir"
  removeDir(tempdir)
  discard tryRemoveFile(filename)

type
  NameAndContent = object
    filename: string
    content: string

func newNameAndContent(filename: string, content: string): NameAndContent =
  result = NameAndContent(filename: filename, content: content)

proc testDir(filename: string, nameAndContentList: seq[NameAndContent]): bool =
  ## Check that the temp directory contains files with the correct
  ## content. The filename is the stf name. Remove the temp directory
  ## at the end.

  let tempdir = filename & ".tempdir"
  if dirExists(tempdir) == false:
    echo "The temp directory doesn't exist."
    echo tempdir
    return false

  var expectedFilenames = initTable[string, int]()
  result = true
  for nameAndContent in nameAndContentList:
    let filename = nameAndContent.filename
    expectedFilenames[filename] = 0
    let content = nameAndContent.content
    let path = joinPath(tempdir, filename)
    if not fileExists(path):
      echo "file doesn't exist: " & path
      result = false
    else:
      let gotContent = readFile(path)
      if gotContent != content:
        let (_, basename) = splitPath(path)
        echo "     got $1:" % basename
        echo gotContent
        echo "expected $1:" % basename
        echo content
        result = false

  for kind, path in walkDir(tempdir):
    # echo "kind: " & $kind
    # echo "path: " & path
    let (_, basename) = splitPath(path)
    if not (basename in expectedFilenames):
      echo "found extra file in temp dir: " & basename
      result = false

  if result == false:
    echo "========="
  removeFileAndTempdir(filename)

proc testParseRunFileLine(line: string, eRunFileLine: RunFileLine): bool =
  ## Test parseRunFileLine where it is expected to pass.
  let runFileLineOp = parseRunFileLine(line)
  if runFileLineOp.isMessage:
    echo runFileLineOp.message
    return false
  if runFileLineOp.value != eRunFileLine:
    echo "     got: " & $runFileLineOp.value
    echo "expected: " & $eRunFileLine
    return false
  result = true

proc testParseExpectedLine(line: string, eExpectedLine: ExpectedLine): bool =
  ## Test parseExpectedLine where it is expected to pass.
  let compareLineOp = parseExpectedLine(line)
  if compareLineOp.isMessage:
    echo compareLineOp.message
    return false
  if compareLineOp.value != eExpectedLine:
    echo "     got: " & $compareLineOp.value
    echo "expected: " & $eExpectedLine
    return false
  result = true

suite "stfrunner.nim":

  test "isRunFileLine":
    check isRunFileLine("### File ")
    check isRunFileLine("## File") == false
    check isRunFileLine("### File") == false
    check isRunFileLine("#  File") == false
    check isRunFileLine("#    File") == false
    check isRunFileLine("#\tFile") == false
    check isRunFileLine(" # File") == false
    check isRunFileLine("# # File") == false
    check isRunFileLine("### Expected") == false
    check isRunFileLine("~~~") == false

  test "isExpectedLine":
    check isExpectedLine("### Expected ")
    check isExpectedLine("### Expectedd ") == false
    check isExpectedLine("# Expected") == false
    check isExpectedLine("## Expected") == false
    check isExpectedLine("### File") == false

  test "getAnyLine expected":
    let expected = newExpectedLine("file1", "file2")
    let eAnyLine = newAnyLineExpectedLine(expected)
    check testGetAnyLine("### Expected file1 == file2", eAnyLine)

  test "getAnyLine ~~~ block":
    let blockLine = newBlockLine(blTildes, "~~~")
    let eAnyLine = newAnyLineBlockLine(blockLine)
    check testGetAnyLine("~~~", eAnyLine)

  test "getAnyLine ~~~ javascript":
    let blockLine = newBlockLine(blTildes, "~~~ javascript")
    let eAnyLine = newAnyLineBlockLine(blockLine)
    check testGetAnyLine("~~~ javascript", eAnyLine)

  test "getAnyLine ~~~nim":
    let blockLine = newBlockLine(blTildes, "~~~nim")
    let eAnyLine = newAnyLineBlockLine(blockLine)
    check testGetAnyLine("~~~nim", eAnyLine)

  test "getAnyLine ``` block":
    let blockLine = newBlockLine(blAccents, "```")
    let eAnyLine = newAnyLineBlockLine(blockLine)
    check testGetAnyLine("```", eAnyLine)

  test "getAnyLine comment":
    let eAnyLine = newAnyLineCommentLine("asdfasdfasdf")
    check testGetAnyLine("asdfasdfasdf", eAnyLine)

  test "id line":
    check runnerId == "stf file, version 0.1.0"

  test "getAnyLine id":
    let eAnyLine = newAnyLineIdLine(runnerId)
    check testGetAnyLine(runnerId, eAnyLine)

  test "getAnyLine file line":
    let eRunFileLine = newRunFileLine("server.json")
    let eAnyLine = newAnyLineRunFileLine(eRunFileLine)
    check testGetAnyLine("### File server.json", eAnyLine)

  test "getAnyLine file line command":
    let eRunFileLine = newRunFileLine("server.json", command = true)
    let eAnyLine = newAnyLineRunFileLine(eRunFileLine)
    check testGetAnyLine("### File server.json command", eAnyLine)

  test "getAnyLine file line attributes":
    let eRunFileLine = newRunFileLine("server.json", noLastEnding = true,
       command = true, nonZeroReturn = true)
    let eAnyLine = newAnyLineRunFileLine(eRunFileLine)
    check testGetAnyLine("### File server.json command nonZeroReturn noLastEnding",
      eAnyLine)

  test "createFolder":
    let tempDirName = "createFolderTest"
    let message = createFolder(tempDirName)
    check message == ""
    check dirExists(tempDirName)
    removeDir(tempDirName)
    check dirExists(tempDirName) == false

  test "createFolder error":
    # Try to create a folder in a readonly folder.

    # Create a folder in the temp folder then set it readonly.
    let parentFolder = joinPath(getTempDir(), "createFolderError")
    createDir(parentFolder)
    var permissions = getFilePermissions(parentFolder)
    # echo "permissions = " & $permissions
    setFilePermissions(parentFolder, {fpUserRead, fpGroupRead})
    permissions = getFilePermissions(parentFolder)
    # echo "permissions = " & $permissions

    # Try to create a folder in the readonly folder.
    let dirName = joinPath(parentFolder, "createFolderTest")
    let message = createFolder(dirName)
    check message != ""
    check dirExists(dirName) == false

    # Remove the temp dir.
    setFilePermissions(parentFolder, {fpUserRead, fpGroupRead, fpUserWrite})
    removeDir(parentFolder)
    check dirExists(parentFolder) == false

  test "openNewFile":
    let folder = getTempDir()
    let filename = "openNewFile"
    let fileOp = openNewFile(folder, filename)
    check fileOp.isValue
    let file = fileOp.value
    file.write("this is a test\n")
    file.close()

    let path = joinPath(folder, filename)
    check fileExists(path)
    discard tryRemoveFile(path)

  test "openNewFile error":

    # Create a temp folder and set it readonly.
    let folder = joinPath(getTempDir(), "createFolderError")
    createDir(folder)
    setFilePermissions(folder, {fpUserRead, fpGroupRead})

    let filename = "openNewFile"
    let fileOp = openNewFile(folder, filename)
    check fileOp.isMessage
    # echo fileOp.message
    check fileOp.message.startsWith("Unable to create the file")

    # Remove the temp dir.
    setFilePermissions(folder, {fpUserRead, fpGroupRead, fpUserWrite})
    removeDir(folder)
    check dirExists(folder) == false

  test "parseRunFileLine name":
    let line = "### File afile.txt"
    let eRunFileLine = newRunFileLine("afile.txt")
    check testParseRunFileLine(line, eRunFileLine)

  test "parseRunFileLine name newline":
    let line = "### File name.html\n"
    let eRunFileLine = newRunFileLine("name.html")
    check testParseRunFileLine(line, eRunFileLine)

  test "parseRunFileLine name and noLastEnding":
    let line = "### File name.html noLastEnding"
    let eRunFileLine = newRunFileLine("name.html", noLastEnding = true)
    check testParseRunFileLine(line, eRunFileLine)

  test "parseRunFileLine name noLastEnding command":
    let line = "### File name.html noLastEnding command"
    let eRunFileLine = newRunFileLine("name.html", noLastEnding =
      true, command = true)
    check testParseRunFileLine(line, eRunFileLine)

  test "parseRunFileLine name noLastEnding command nonZeroReturn":
    let line = "### File name.html noLastEnding command nonZeroReturn"
    let eRunFileLine = newRunFileLine("name.html", noLastEnding =
      true, command = true, nonZeroReturn = true)
    check testParseRunFileLine(line, eRunFileLine)

  test "parseRunFileLine unknown attribute":
    # Ignore unknown attributes.
    let line = "### File name.html asdf  noLastEnding command   nonZeroReturn  "
    let eRunFileLine = newRunFileLine("name.html", noLastEnding =
      true, command = true, nonZeroReturn = true)
    check testParseRunFileLine(line, eRunFileLine)

  test "parseRunFileLine name command nonZeroReturn":
    let line = "### File name.html command nonZeroReturn"
    let eRunFileLine = newRunFileLine("name.html", command = true,
      nonZeroReturn = true)
    check testParseRunFileLine(line, eRunFileLine)

  test "parseRunFileLine name command ":
    let line = "### File name.html command"
    let eRunFileLine = newRunFileLine("name.html", command = true)
    check testParseRunFileLine(line, eRunFileLine)

  test "parseRunFileLine error":
    let fileLineOp = parseRunFileLine("----------Filename.html")
    check fileLineOp.isMessage
    check fileLineOp.message == "Invalid file line: ----------Filename.html"

  test "parseExpectedLine happy path":
    let line = "### Expected file1 == file2"
    let eExpectedLine = newExpectedLine("file1", "file2")
    check testParseExpectedLine(line, eExpectedLine)

  test "parseExpectedLine 2":
    let line = "### Expected f == g"
    let eExpectedLine = newExpectedLine("f", "g")
    check testParseExpectedLine(line, eExpectedLine)

  test "parseExpectedLine spaces":
    let line = "### Expected   file1   ==  file2"
    let expectedLineOp = parseExpectedLine(line)
    check expectedLineOp.isMessage
    let expected = "Invalid expected line: ### Expected   file1   ==  file2"
    check expectedLineOp.message == expected

  test "parseExpectedLine error":
    let expectedLineOp = parseExpectedLine("----------filename.html")
    check expectedLineOp.isMessage
    check expectedLineOp.message == "Invalid expected line: ----------filename.html"

  test "parseExpectedLine missing file":
    let expectedLineOp = parseExpectedLine("expected file1")
    check expectedLineOp.isMessage
    check expectedLineOp.message == "Invalid expected line: expected file1"

  test "runFilename empty.stf":
    let filename = "stf-files/empty.stf"
    let content = ""
    let message = "Empty file: 'stf-files/empty.stf'."
    let expected = opMessageStr[DirAndFiles](message)
    check testMakeDirAndFiles(filename, content, expected)
    check testDir(filename, @[])

  test "runFilename not stf":
    let filename = "stf-files/not.stf"
    let content = "not a stf file"
    let message = """
Invalid stf file first line:
     got: not a stf file
expected: stf file, version 0.1.0"""
    let expected = opMessageStr[DirAndFiles](message)
    check testMakeDirAndFiles(filename, content, expected)

    # let e = newNameAndContent("afile.txt", "contents of\nthe file\n")
    check testDir(filename, @[])

  test "runFilename do nothing":
    let filename = "stf-files/do-nothing.stf"
    let content = """
stf file, version 0.1.0
"""
    let expected = opMessageStr[DirAndFiles]("No files run.")
    check testMakeDirAndFiles(filename, content, expected)
    check testDir(filename, @[])

  test "runFilename comments":
    let filename = "stf-files/comments.stf"
    let content = """
stf file, version 0.1.0
# This is a do nothing file with comments.
# Comments are non-command lines.
"""
    let expected = opMessageStr[DirAndFiles]("No files run.")
    check testMakeDirAndFiles(filename, content, expected)

    # let e = newNameAndContent("afile.txt", "contents of\nthe file\n")
    check testDir(filename, @[])

  test "make file":
    let filename = "stf-files/onefile.stf"
    let content = """
stf file, version 0.1.0
# This stf creates a file, that's all.
### File afile.txt
~~~
contents of
the file
~~~
"""
    let b = newRunFileLine("afile.txt")
    let dirAndFiles = newDirAndFiles(@[], @[b])
    let expected = opValueStr[DirAndFiles](dirAndFiles)
    check testMakeDirAndFiles(filename, content, expected)

    let e = newNameAndContent("afile.txt", "contents of\nthe file\n")
    check testDir(filename, @[e])

  test "make two files":
    let filename = "stf-files/twofiles.stf"
    let content = """
stf file, version 0.1.0
# This stf creates files.

### File afile.txt

~~~
contents of
the file
~~~

### File bfile.txt
~~~
contents of b
the second file
~~~

"""
    # let a = newExpectedLine("afile.txt", "bfile.txt")
    let b = newRunFileLine("afile.txt")
    let c = newRunFileLine("bfile.txt")
    let dirAndFiles = newDirAndFiles(@[], @[b, c])
    let expected = opValueStr[DirAndFiles](dirAndFiles)
    check testMakeDirAndFiles(filename, content, expected)

    let expectedAFileContent = """
contents of
the file
"""
    let expectedBFileContent = """
contents of b
the second file
"""
    let d = newNameAndContent("afile.txt", expectedAFileContent)
    let e = newNameAndContent("bfile.txt", expectedBFileContent)
    check testDir(filename, @[d, e])

  test "make empty file":
    let filename = "stf-files/emptyfile.stf"
    let content = """
stf file, version 0.1.0
# This stf creates an empty file.
### File emptyfile.txt
~~~
~~~
"""
    # let a = newExpectedLine("filea", "emptyfile.txt")
    let b = newRunFileLine("emptyfile.txt")
    let dirAndFiles = newDirAndFiles(@[], @[b])
    let expected = opValueStr[DirAndFiles](dirAndFiles)
    check testMakeDirAndFiles(filename, content, expected)

    let e = newNameAndContent("emptyfile.txt", "")
    check testDir(filename, @[e])

  test "missing endfile":
    let filename = "stf-files/missingendfile.stf"
    let content = """
stf file, version 0.1.0

### File missingfile.txt
~~~
testing
1
2
3
"""
    let message = "The end block line was missing."
    let expected = opMessageStr[DirAndFiles](message)
    check testMakeDirAndFiles(filename, content, expected)

    check testDir(filename, @[])

  test "noLastEnding":
    let filename = "stf-files/noLastEnding.stf"
    let content = """
stf file, version 0.1.0
# This stf creates a file with no ending newline.
### File afile.txt noLastEnding
~~~
contents of the file
~~~
"""
    let r = newRunFileLine("afile.txt", noLastEnding = true)
    let dirAndFiles = newDirAndFiles(@[], @[r])
    let expected = opValueStr[DirAndFiles](dirAndFiles)
    check testMakeDirAndFiles(filename, content, expected)

    let c = newNameAndContent("afile.txt", "contents of the file")
    check testDir(filename, @[c])

  test "command":
    let filename = "stf-files/command.stf"
    let content = """
stf file, version 0.1.0
# This stf creates a file with a command.
### File afile.txt noLastEnding command
~~~
ls
~~~
"""
    let r = newRunFileLine("afile.txt", command = true, noLastEnding = true)
    let dirAndFiles = newDirAndFiles(@[], @[r])
    let expected = opValueStr[DirAndFiles](dirAndFiles)
    check testMakeDirAndFiles(filename, content, expected)

    let c = newNameAndContent("afile.txt", "ls")
    check testDir(filename, @[c])

  test "command nonZeroReturn":
    let filename = "stf-files/nonZeroReturn.stf"
    let content = """
stf file, version 0.1.0
# This stf creates a file with a command with a nonZeroReturn.
### File afile.txt noLastEnding command nonZeroReturn
~~~
ls
~~~
"""
    let r = newRunFileLine("afile.txt", true, true, true)
    let dirAndFiles = newDirAndFiles(@[], @[r])
    let expected = opValueStr[DirAndFiles](dirAndFiles)
    check testMakeDirAndFiles(filename, content, expected)

    let c = newNameAndContent("afile.txt", "ls")
    check testDir(filename, @[c])

  test "file compare lines":
    let filename = "stf-files/filecomparelines.stf"
    let content = """
stf file, version 0.1.0

### File test.txt
~~~
~~~
### Expected file1.txt == file2.txt
### Expected file3.txt == file4.txt

"""
    let a = newExpectedLine("file1.txt", "file2.txt")
    let b = newExpectedLine("file3.txt", "file4.txt")
    let f1 = newRunFileLine("test.txt")
    let dirAndFiles = newDirAndFiles(@[a, b], @[f1])
    let expected = opValueStr[DirAndFiles](dirAndFiles)
    check testMakeDirAndFiles(filename, content, expected)
    let nc = newNameAndContent("test.txt", "")
    check testDir(filename, @[nc])

  test "runCommands":

    let folder = "stf-files"
    let cmdFilename = "cmd.sh"
    let cmdPath = joinPath(folder, cmdFilename)
    createFile(cmdPath, "echo 'hello there' >t.txt")

    let r = newRunFileLine(cmdFilename, command = true, nonZeroReturn = false)
    let runFileLines = @[r]
    let rc = runCommands(folder, runFileLines)
    check rc == 0

    # The current working directory is set to the stf-files folder.
    # t.txt file should appear in the folder.
    let tPath = joinPath(folder, "t.txt")
    check fileExists(tPath)
    check fileExists(cmdPath)

    discard tryRemoveFile(tPath)
    discard tryRemoveFile(cmdPath)

