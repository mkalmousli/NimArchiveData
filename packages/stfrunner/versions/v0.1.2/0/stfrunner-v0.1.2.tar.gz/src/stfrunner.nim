## A program to test command line programs.
##
## It runs Single Test File (stf) files. A stf file contains a test
## which the runner executes to determine whether the test passed. A
## stf file contains instructions for creating files, running files
## and comparing files and it is designed to look good in a markdown
## reader.
##
## See the runner help message (get_help) for more information about stf
## files, or run the nimble task "runhelp" to show the help text with
## glow.

import std/strutils
import std/os
import std/osproc
import std/options
import std/streams
import std/strformat
import std/tables
import linebuffer
import regexes
import opresult
import comparelines
import cmdLine
when not defined(test):
  import version

type
  Args = object
    ## Args holds all the command line arguments.
    help: bool
    leaveTempDir: bool
    version: bool
    filename: string
    directory: string

func `$`*(a: Args): string =
  ## Return a string representation of an Args object.
  result.add("arg.help: $1\n" % $a.help)
  result.add("arg.leaveTempDir: $1\n" % $a.leaveTempDir)
  result.add("arg.version: $1\n" % $a.version)
  result.add("arg.filename: '$1'\n" % $a.filename)
  result.add("arg.directory: '$1'\n" % $a.directory)

func newArgs(cmlArgs: CmlArgs): Args =
  ## Create an Args object from a CmlArgs object.
  result.help = "help" in cmlArgs
  result.leaveTempDir = "leaveTempDir" in cmlArgs
  result.version = "version" in cmlArgs
  let gotFilename = "filename" in cmlArgs
  if gotFilename:
    result.filename = cmlArgs["filename"][0]
  let gotDirectory = "directory" in cmlArgs
  if gotDirectory:
    result.directory = cmlArgs["directory"][0]
  if not (result.version or gotFilename or gotDirectory):
    result.help = true

proc parseCmdLine(): ArgsOrMessage =
  ## Parse the command line and return the arguments or an error message.

  # Define the supported options.
  var supportedOptions = newSeq[CmlOption]()
  supportedOptions.add(newCmlOption("help", 'h', cmlStopArgument))
  supportedOptions.add(newCmlOption("version", 'v', cmlStopArgument))
  supportedOptions.add(newCmlOption("leaveTempDir", 'l', cmlNoArgument))
  supportedOptions.add(newCmlOption("filename", 'f', cmlArgument0or1))
  supportedOptions.add(newCmlOption("directory", 'd', cmlArgument0or1))

  # Parse the command line.
  let cmlArgsOrMessage = cmdline(supportedOptions, collectArgs())
  return cmlArgsOrMessage

const
  runnerId* = "stf file, version 0.1.0"
    ## The first line of the stf file.

type
  Rc* = int
    ## Rc holds a return code where 0 is success.

  RunFileLine* = object
    ## RunFileLine holds the file line options.
    filename*: string
    noLastEnding*: bool
    command*: bool
    nonZeroReturn*: bool

  ExpectedLine* = object
    ## ExpectedLine holds the expected line options.
    gotFilename*: string
    expectedFilename*: string

  BlockLineType* = enum
    ## The kind of block line.
    blTildes,
    blAccents

  BlockLine* = object
    ## BlockLine holds a line that starts with tildas or accents.
    blockLineType*: BlockLineType
    line*: string

  LineKind* = enum
    ## The kind of line in a stf file.
    lkRunFileLine,
    lkExpectedLine,
    lkBlockLine,
    lkIdLine,
    lkCommentLine

  AnyLine* = object
    ## Contains the information about one line in a stf file.
    case kind*: LineKind
      of lkRunFileLine:
        runFileLine*: RunFileLine
      of lkExpectedLine:
        expectedLine*: ExpectedLine
      of lkBlockLine:
        blockLine*: BlockLine
      of lkIdLine:
        idLine*: string
      of lkCommentLine:
        commentLine*: string

  DirAndFiles* = object
    ## DirAndFiles holds the file and compare lines of the stf file.
    expectedLines*: seq[ExpectedLine]
    runFileLines*: seq[RunFileLine]

func newBlockLine*(blockLineType: BlockLineType, line: string): BlockLine =
  ## Create a new BlockLine type.
  result = BlockLine(blockLineType: blockLineType, line: line)

func newAnyLineRunFileLine*(runFileLine: RunFileLine): AnyLine =
  ## Create a new AnyLine object for a file line.
  result = AnyLine(kind: lkRunFileLine, runFileLine: runFileLine)

func newAnyLineExpectedLine*(expectedLine: ExpectedLine): AnyLine =
  ## Create a new AnyLine object for a expected line.
  result = AnyLine(kind: lkExpectedLine, expectedLine: expectedLine)

func newAnyLineBlockLine*(blockLine: BlockLine): AnyLine =
  ## Create a new AnyLine object for a block line.
  result = AnyLine(kind: lkBlockLine, blockLine: blockLine)

func newAnyLineCommentLine*(commentLine: string): AnyLine =
  ## Create a new AnyLine object for a comment line.
  result = AnyLine(kind: lkCommentLine, commentLine: commentLine)

func newAnyLineIdLine*(idLine: string): AnyLine =
  ## Create a new AnyLine object for a id line.
  result = AnyLine(kind: lkIdLine, idLine: idLine)

func newRunFileLine*(filename: string, noLastEnding = false, command = false,
    nonZeroReturn = false): RunFileLine =
  ## Create a new RunFileLine object.
  result = RunFileLine(filename: filename, noLastEnding: noLastEnding,
    command: command, nonZeroReturn: nonZeroReturn)

func newExpectedLine*(gotFilename: string, expectedFilename: string): ExpectedLine =
  ## Create a new ExpectedLine object.
  result = ExpectedLine(gotFilename: gotFilename, expectedFilename: expectedFilename)

func newDirAndFiles*(expectedLines: seq[ExpectedLine],
    runFileLines: seq[RunFileLine]): DirAndFiles =
  ## Create a new DirAndFiles object.
  result = DirAndFiles(expectedLines: expectedLines,
    runFileLines: runFileLines)

func `$`*(r: ExpectedLine): string =
  ## Return a string representation of a ExpectedLine object.
  result = "expected $1 == $2" % [r.gotFilename, r.expectedFilename]

func `$`*(r: RunFileLine): string =
  ## Return a string representation of a RunFileLine object.

  var noLastEnding: string
  if r.noLastEnding:
    noLastEnding = " noLastEnding"

  var command: string
  if r.command:
    command = " command"

  var nonZeroReturn: string
  if r.nonZeroReturn:
    nonZeroReturn = " nonZeroReturn"

  result = fmt"file {r.filename}{noLastEnding}{command}{nonZeroReturn}"

func stripLineEnding(line: string): string =
  ## Strip line endings from a string.
  result = line.strip(chars={'\n', '\r'}, trailing = true)

proc createFolder*(folder: string): string =
  ## Create a folder with the given name. When the folder cannot be
  ## created return a message telling why, else return "".
  try:
    createDir(folder)
  except CatchableError:
    result = getCurrentExceptionMsg()

proc deleteFolder*(folder: string): string =
  ## Delete a folder with the given name. When the folder cannot be
  ## deleted return a message telling why, else return "".
  try:
    removeDir(folder)
  except CatchableError:
    result = getCurrentExceptionMsg()

when not defined(test):
  const
    runnerHelp* = """
# Stf Runner

A program to test command line programs.

Run a single test file (stf) or run all stf files in a folder.

The runner reads a stf file, creates multiple small files in a test
working folder, runs files then verifies the files contain the correct
data.

A stf file is designed to look good in a markdown reader. You can use
the .stf or .stf.md extentions.

## Usage

stfrunner [-h] [-v] [-l] [-f filename] [-d directory]

-h --help          Show this help message.
-v --version       Show the version number.
-l --leaveTempDir  Leave the temp folder.
-f --filename filename  Run the stf file.
-d --directory dirname  Run the stf files (.stf or .stf.md) in the directory.

## Processing Steps

The stf file runner processes the file tasks in the following order:

* create working folder
* create files in the working folder
* runs command type files
* compares files
* removes the working folder

The working folder is created in the same folder as the stf file using
the stf name with ".tempdir" append.

Normally the working folder is removed after running. The -l option
leaves the folder for debugging purposes. If the working folder exists
when running, it is deleted, then recreated, then deleted when done.

Runner returns 0 when all the tests pass. When running multiple stf
files, it displays each test run and tells how many passed and failed.

## Stf File Format

The Single Test File format is a text file made up of single line
commands.

Command line types:

1. id line
2. file lines
3. file blocks
4. expected lines
5. comment lines

### Id Line

The first line of the stf file identifies it as a stf file and tells
the version. For example:

```
stf file, version 0.1.0
```

### File Line

The file line is used to create a file. It starts with "### File "
followed by the filename then some optional attributes. A line that
starts with "### File" must be a file type line.

The general form of a file line is:

```
### File filename [noLineEnding] [command] [nonZeroReturn]
```

Example file lines:

```
### File server.json
### File cmd.sh command
### File result.expected noLineEnding
### File cmd.sh command nonZeroReturn
### File cmd.sh command nonZeroReturn noLineEnding
```

File Attributes:

* **filename** -- the name of the file to create.

The name is required and cannot contain spaces. The file is created in
the working folder.

* **command** -- marks this file to be run.

All files are created before any command runs. The command file is run
in the working folder as the working directory. The commands are run
in the order specified in the stf file.

* **nonZeroReturn** -- the command returns non-zero on success

Normally the runner fails when a command returns a non-zero return
code.  With nonZeroReturn set, it fails when it returns zero.

* **noLineEnding** -- create the file without an ending newline.

### File Block Lines

The content of a file is bracketed by markdown code blocks, either
"~~~" or "```".  The block follows a file line. The first block found
is used, so you can have blocks as comments too.  All content up to
the ending code marker go in the file, even lines that look like
commands. You follow the ~~~ with a code name, e.g. javascript, for
syntax highlighting.

### Expected Line

The expected line compares files. You specify two files that should be
equal.  The compares are run after running the commands. You can use
the word "empty" for in place of a filename when you expect the file
to be empty. A line that starts with "### Expected " must be an
expected line.

```
### Expected gotFilename == expectedFilename
```

Examples:

```
### Expected result == result.expected
### Expected t.txt == t.txt.expected
### Expected t.txt == empty
```

### Comments

Comments are all the other lines of the file. So it is hard to make a
syntax error.  The only possible syntax errors are with the id line,
file lines and expected lines.

"""
      ## Runner help text.

proc isRunFileLine*(line: string): bool =
  ## Return true when the line is a file line.
  let pattern = r"^### File "
  let matchesO = matchPattern(line, pattern, 0, 0)
  result = matchesO.isSome

proc isExpectedLine*(line: string): bool =
  ## Return true when the line is an expected line.
  let pattern = r"^### Expected "
  let matchesO = matchPattern(line, pattern, 0, 0)
  result = matchesO.isSome

proc parseRunFileLine*(line: string): OpResultStr[RunFileLine] =
  ## Parse a file command line.

  let pattern = r"^### File ([^\s]+)(.*)$"

  let matchesO = matchPattern(line, pattern, 0, 2)
  if not matchesO.isSome:
    return opMessageStr[RunFileLine]("Invalid file line: $1" % [line])

  let (filename, attrs, _) = matchesO.get2GroupsLen()
  let attributes = attrs.split(" ")

  var noLastEnding, command, nonZeroReturn: bool
  for attr in attributes:
    let attribute = strutils.strip(attr, trailing = true)
    case attribute:
      of "noLastEnding":
        noLastEnding = true
      of "command":
        command = true
      of "nonZeroReturn":
        nonZeroReturn = true
      else:
        discard

  let runFileLine = newRunFileLine(filename, noLastEnding, command, nonZeroReturn)
  result = opValueStr[RunFileLine](runFileLine)

proc parseExpectedLine*(line: string): OpResultStr[ExpectedLine] =
  ## Parse an expected line.
  # # Expected stdout.expected == stdout
  let pattern = r"^### Expected ([^\s]+) == ([^\s]+)[\s]*$"

  let matchesO = matchPattern(line, pattern, 0, 2)
  if not matchesO.isSome:
    return opMessageStr[ExpectedLine]("Invalid expected line: $1" % [line])

  let (gotFilename, expectedFilename, _) = matchesO.get2GroupsLen()
  let expectedEqual = newExpectedLine(gotFilename, expectedFilename)
  result = opValueStr[ExpectedLine](expectedEqual)

proc openNewFile*(folder: string, filename: string): OpResultStr[File] =
  ## Create a new file in the given folder and return an open File
  ## object.

  var path = joinPath(folder, filename)
  if fileExists(path):
    return opMessageStr[File]("File already exists: $1" % [path])

  var file: File
  if not open(file, path, fmWrite):
    let message = "Unable to create the file: $1" % [path]
    return opMessageStr[File](message)

  result = opValueStr[File](file)

proc getAnyLine*(line: string): OpResultStr[AnyLine] =
  ## Return information about the stf line.

  if line == runnerId:
    return opValueStr(AnyLine(kind: lkIdLine, idLine: line))

  if line.startsWith("~~~"):
    let blockLine = newBlockLine(blTildes, line)
    return opValueStr(AnyLine(kind: lkBlockLine, blockLine: blockLine))

  if line.startsWith("```"):
    let blockLine = newBlockLine(blAccents, line)
    return opValueStr(AnyLine(kind: lkBlockLine, blockLine: blockLine))

  if isRunFileLine(line):
    let runFileLineOp = parseRunFileLine(line)
    if runFileLineOp.isValue:
      return opValueStr(newAnyLineRunFileLine(runFileLineOp.value))
    else:
      return opMessageStr[AnyLine](runFileLineOp.message)

  if isExpectedLine(line):
    let expectedEqualOp = parseExpectedLine(line)
    if expectedEqualOp.isValue:
      return opValueStr(AnyLine(kind: lkExpectedLine, expectedLine: expectedEqualOp.value))
    else:
      return opMessageStr[AnyLine](expectedEqualOp.message)

  result = opValueStr(AnyLine(kind: lkCommentLine, commentLine: line))

proc createSectionFile(lb: var LineBuffer, folder: string,
    runFileLine: RunFileLine): string =
  ## Create a file from lines in the stf file. Read starting at the
  ## current position until the start block line is found, then read
  ## the file lines until the matching end block is found.  Return a
  ## message when the file cannot be created, else return "".

  # Open a new file in the given folder.
  let filename = runFileLine.filename
  let noLastEnding = runFileLine.noLastEnding
  var fileOp = openNewFile(folder, filename)
  if fileOp.isMessage:
    return fileOp.message
  var file = fileOp.value

  # Look for the starting block line.
  var line: string
  var blockLine: BlockLine
  var lineNum = 0
  while true:
    line = linebuffer.readline(lb)
    if line == "":
      # The start block was missing. Close and delete the new file.
      file.close()
      let path = joinPath(folder, filename)
      discard tryRemoveFile(path)
      return "The start block line was missing."
    inc(lineNum)
    let anyLineOr = getAnyLine(line)
    if anyLineOr.isMessage:
      return fmt"{lineNum}: {anyLineOr.message}"
    let anyLine = anyLineOr.value
    if anyLine.kind == lkBlockLine:
      blockLine = anyLine.blockLine
      break

  # Write lines until the next endblock line is found.
  var previousLine: string
  var firstLine = true
  while true:
    line = linebuffer.readline(lb)
    if line == "":
      # The end block was missing. Close and delete the new file.
      file.close()
      let path = joinPath(folder, filename)
      discard tryRemoveFile(path)
      return "The end block line was missing."
    let anyLineOr = getAnyLine(line)
    if anyLineOr.isMessage:
      return fmt"{lineNum}: {anyLineOr.message}"
    let anyLine = anyLineOr.value
    if anyLine.kind == lkBlockLine and anyLine.blockLine.blockLineType == blockLine.blockLineType:
      break

    # Write the previous line to the file.
    if not firstLine:
      file.write(previousLine)
    previousLine = line
    firstLine = false

  # Write the last line.
  if noLastEnding:
    previousLine = previousLine.stripLineEnding()
  file.write(previousLine)

  # Close the new file.
  file.close()

proc makeDirAndFiles*(filename: string): OpResultStr[DirAndFiles] =
  ## Read the stf file and create its temp folder and files. Return the
  ## file lines and expected lines.

  var expectedLines = newSeq[ExpectedLine]()
  var runFileLines = newSeq[RunFileLine]()

  # Make sure the file exists.
  if not fileExists(filename):
    return opMessageStr[DirAndFiles]("File not found: '$1'." % [filename])

  # Open the file for reading.
  let stream = newFileStream(filename, fmRead)
  if stream == nil:
    return opMessageStr[DirAndFiles]("Unable to open file: '$1'." % [filename])
  defer:
    stream.close()

  # Create a temp folder next to the stf file. Remove it first if it
  # already exists.
  let tempDirName = filename & ".tempdir"
  if dirExists(tempDirName):
    removeDir(tempDirName)
  let message = createFolder(tempDirName)
  if message != "":
    return opMessageStr[DirAndFiles](message)

  # Allocate a buffer for reading lines.
  var lineBufferO = newLineBuffer(stream, filename = filename)
  if not lineBufferO.isSome():
    return opMessageStr[DirAndFiles]("Unable to allocate a line buffer.")
  var lb = lineBufferO.get()

  # Check the file type is supported. The first line contains the type
  # and version number.
  var line = linebuffer.readline(lb)
  if line == "":
    return opMessageStr[DirAndFiles]("Empty file: '$1'." % filename)
  if not line.startsWith(runnerId):
    let message = """Invalid stf file first line:
     got: $1
expected: $2""" % [line, runnerId]
    return opMessageStr[DirAndFiles](message)

  while true:
    # Read a line from the stf file.
    line = linebuffer.readline(lb)
    if line == "":
      break # No more lines.
    let anyLineOr = getAnyLine(line)
    if anyLineOr.isMessage:
      return opMessageStr[DirAndFiles](anyLineOr.message)
    let anyLine = anyLineOr.value
    case anyLine.kind
    of lkRunFileLine:
      # Create a new file.
      let runFileLine = anyLine.runFileLine
      runFileLines.add(runFileLine)
      let message = createSectionFile(lb, tempDirName, runFileLine)
      if message != "":
        return opMessageStr[DirAndFiles](message)
    of lkExpectedLine:
      # Remember the expected filenames to compare.
      expectedLines.add(anyLine.expectedLine)
    else:
      discard

  if runFileLines.len == 0:
    return opMessageStr[DirAndFiles]("No files run.")

  # if expectedLines.len == 0:
  #   return opMessageStr[DirAndFiles]("No expected lines.")

  let dirAndFiles = newDirAndFiles(expectedLines, runFileLines)
  result = opValueStr[DirAndFiles](dirAndFiles)

proc runCommands*(folder: string, runFileLines: seq[RunFileLine]):
    int =
  ## Run the command files and return 0 when they all returned their
  ## expected return code.

  # Set the working directory to the folder.
  assert(dirExists(folder))
  let oldDir = getCurrentDir()
  setCurrentDir(folder)

  # Run each command file.
  for runFileLine in runFileLines:
    if runFileLine.command:
      # Make the file executable.
      setFilePermissions(runFileLine.filename, {fpUserExec, fpUserRead, fpUserWrite})

      # Run the file and return the return code.
      let localFile = "./" & runFileLine.filename
      let cmdRc = execCmd(localFile)

      # Check the return code.
      if runFileLine.nonZeroReturn:
        if cmdRc == 0:
          echo "$1 generated an unexpected return code of 0." %
            runFileLine.filename
          result = 1
      elif cmdRc != 0:
        echo "$1 generated a non-zero return code. If this is expected, use the nonZeroReturn file attribute." %
          runFileLine.filename
        result = 1

  setCurrentDir(oldDir)

when false:
  proc dup(pattern: string, count: Natural): string =
    ## Duplicate the pattern count times. Return "" when the result
    ## would be longer than 1024 characters.
    if count < 1:
      return
    let length = count * pattern.len
    if length > 1024:
      return
    result = newStringOfCap(length)
    for ix in countUp(1, int(count)):
      result.add(pattern)

proc compareFileSets(folder: string, expectedLines: seq[ExpectedLine]):
    int =
  ## Compare multiple pairs of files and show the differences. When
  ## they are all the same return 0.

  for expectedLine in expectedLines:
    var gotPath = joinPath(folder, expectedLine.gotFilename)
    var expectedPath = joinPath(folder, expectedLine.expectedFilename)

    # Compare the two files.
    let stringOp = compareFiles(gotPath, expectedPath)

    if stringOp.isMessage:
      # Show the error.
      echo stringOp.message
      result = 1
    else:
      # Show the differences, if any.
      let differences = stringOp.value
      if differences != "":
        echo differences
        result = 1

proc runStfFilename*(filename: string): int =
  ## Run the stf file and leave the temp dir. Return 0 when all the
  ## tests passed.

  # Create the temp folder and files inside it.
  let dirAndFilesOp = makeDirAndFiles(filename)
  if dirAndFilesOp.isMessage:
    echo dirAndFilesOp.message
    return 1
  let dirAndFiles = dirAndFilesOp.value

  let folder = filename & ".tempdir"

  # Run the command files.
  var rc = runCommands(folder, dirAndFiles.runFileLines)
  if rc != 0:
    result = rc

  # Compare the files.
  rc = compareFileSets(folder, dirAndFiles.expectedLines)
  if rc != 0:
    result = rc


when not defined(test):

  proc runFilename(filename: string, leaveTempDir: bool): int =
    ## Run the stf file and optionally leave the temp dir. Return 0 when
    ## all the tests pass.

    result = runStfFilename(filename)

    # Remove the temp folder unless leave is specified.
    let tempDir = filename & ".tempdir"
    if leaveTempDir:
      echo "Leaving temp dir: " & tempDir
    else:
      if fileExists(filename):
        discard deleteFolder(tempDir)

  proc runDirectory(dir: string, leaveTempDir: bool): int =
    ## Run all the stf files in the specified directory. Return 0 when
    ## they all pass. Show progess and count of passed and failed.

    if not dirExists(dir):
      echo "The dir does not exist: " & dir
      return 1

    var failedTests: seq[string]
    var count = 0
    var passedCount = 0
    for kind, path in walkDir(dir):
      if path.endsWith(".stf") or ".stf." in path:
        let (_, basename) = splitPath(path)
        echo "Running: " & basename

        let runRc = runFilename(path, leaveTempDir)
        if runRc == 0:
          inc(passedCount)
        else:
          failedTests.add(path)
          result = 1
        inc(count)

    if count == passedCount:
      echo "All $1 tests passed!" % $passedCount
    else:
      echo "$1 Passed, $2 Failed\n" % [
        $passedCount, $(count - passedCount)]
      for failedTest in failedTests:
        echo failedTest

  proc processRunArgs(args: Args): int =
    ## Run what was specified on the command line. Return 0 when
    ## successful.

    if args.help:
      echo runnerHelp
    elif args.version:
      echo stfrunnerVersion
    elif args.filename != "":
      result = runFilename(args.filename, args.leaveTempDir)
    elif args.directory != "":
      result = runDirectory(args.directory, args.leaveTempDir)
    else:
      echo "Missing argments."
      result = 1

  proc main(cmlArgsOrMessage: ArgsOrMessage): int =
    ## Run the specified options. Return 0 when on success.

    # Setup control-c monitoring so ctrl-c stops the program.
    proc controlCHandler() {.noconv.} =
      quit 0
    setControlCHook(controlCHandler)

    # On error show the error message.
    if cmlArgsOrMessage.kind == cmlMessageKind:
      # Display the message and return.
      echo getMessage(cmlArgsOrMessage.messageId, cmlArgsOrMessage.problemArg)
      return 1

    let cmlArgs = cmlArgsOrMessage.args
    let args = newArgs(cmlArgs)

    try:
      result = processRunArgs(args)
    except CatchableError:
      echo "Unexpected exception: $1" % [getCurrentExceptionMsg()]
      # The stack trace is only available in the debug builds.
      when not defined(release):
        echo getCurrentException().getStackTrace()
      result = 1

when isMainModule:
  let cmlArgsOrMessage = parseCmdline()
  # echo $cmlArgsOrMessage

  let rc = main(cmlArgsOrMessage)
  if rc == 0:
    quit(QuitSuccess)
  else:
    quit(QuitFailure)
