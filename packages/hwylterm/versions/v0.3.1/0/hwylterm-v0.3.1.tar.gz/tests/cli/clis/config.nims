switch("path", "$projectDir/../../../src")
