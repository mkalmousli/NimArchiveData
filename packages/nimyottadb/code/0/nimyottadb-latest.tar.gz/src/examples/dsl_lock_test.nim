import yottadb
import ydbutils
import malebolgia

proc demoUpdate1(cnt: int, tn: int) =
    withlock 4711:
        discard Increment ^CNT(4711)
        discard Increment ^CNT(4711, tn)
        withlock "4711,1":
            discard Increment ^CNT("TEMPLATE_TEST")
            discard Increment ^CNT(4711.1)
            discard Increment ^CNT(4711.1, tn)

proc demoUpdate2(cnt: int, tn: int) =
    withlock "4711,1":
        discard Increment ^CNT(4711.1)
        discard Increment ^CNT(4711.1, tn)
        withlock 4711:
            discard Increment ^CNT("TEMPLATE_TEST")
            discard Increment ^CNT(4711)
            discard Increment ^CNT(4711, tn)


proc createThreads(cnt: int, numOfThreads: int) =
  var m = createMaster()
  m.awaitAll:
    for tn in 0..<numOfThreads:
        let tv = tn + 1
        if tv mod 2 == 0:
            m.spawn demoUpdate2(cnt, tn)
        else:
            m.spawn demoUpdate1(cnt, tn)


proc tryToCreateDeadlock() =
    let numOfThreads = 8
    const maxCount = 1000

    Kill:
        ^CNT(4711)
        ^CNT(4711.1)
    Killnode:
        ^CNT("TEMPLATE_TEST")
    
    let ms = timed_ms:
        var cnt = maxCount
        while cnt > 0:
            dec(cnt)
            createThreads(cnt, numOfThreads)

    # Test totals
    let iterations = maxCount * numOfThreads
    var v = Get ^CNT(4711).int
    assert v == iterations
    v = Get ^CNT("4711.1").int
    assert v == iterations
    v = Get ^CNT("TEMPLATE_TEST").int
    assert v == iterations
    echo "Number of Threads: ", numOfThreads, ", Total iterations:", iterations, ", Time per iteration: ", ms.float64 / v.float64, " ms."

    # Test numbers for each thread
    for tn in 0..<numOfThreads:
        v = Get ^CNT(4711, tn).int
        assert v == maxCount
        v = Get ^CNT(4711.1, tn).int
        assert v == maxCount


when isMainModule:
    tryToCreateDeadlock()
