# Changelog for version 0.3.1
## @ Indirection Index Extension
It is now allowed to extend the index of a variable that is defined as @ indirection.
```nim
var gbl = "^GBL"
setvar: @gbl(1) = 1
assert "1" == getvar @gbl(1)

setvar: @gbl(1,"A") = "1A"
assert "1A" == getvar @gbl(1, "A")

gbl = "^GBL(1,A)"
assert "1A" == getvar @gbl

# ---- test with index in the variable ----
gbl = "^GBL(123815)"
setvar: @gbl = "123815"
assert "123815" == getvar @gbl

# Index extended
setvar: @gbl(1) = "123815,1" # -> ^GBL(123815,1)
assert "123815,1" == getvar @gbl(1)
setvar: @gbl("ABC") = "ABC" # -> ^GBL(123815, "ABC")
assert "ABC" == getvar @gbl("ABC")
setvar: @gbl(123, "ABC") = "123ABC" # -> ^GBL(123815, 123, "ABC")
assert "123ABC" == getvar @gbl(123, "ABC")

# With variable in the index
let id = "4714"
setvar: @gbl(id, "ABC") = "idABC"
assert "idABC" == getvar @gbl(id, "ABC")
setvar: @gbl(@["XYZ", id, "ABC"]) = "XYZABC"
assert "XYZABC" == getvar @gbl("XYZ", id, "ABC")
```
A simple example to show customers data:
```nim
echo "Iterate over all customers Indirection"
    var (rc, gbl) = nextsubscript @"^CUSTOMER"
    while rc == YDB_OK:
      let name = getvar  @gbl("Name")
      let email = getvar @gbl("Email")
      echo fmt"{gbl}: name: {name}, email:{email}"
      (rc, gbl) = nextsubscript @gbl
```
Prints out:
```bash
Iterate over all customers Indirection
^CUSTOMER(1): name: John Doe, email:john-doe.@gmail.com
^CUSTOMER(2): name: Jane Smith, email:jane.smith.@yahoo.com
```


# Changelog for version 0.3.0

## Breaking Changes for version 0.3.0
- DSL `delnode` has been renamed to `killnode`. It kills (removes) a single node independent of descendents.
- DSL `deltree` has been renamed to `kill`. It removes the nodes and the descendents
This is to bring nim-yottadb more close to M naming.
Simply rename all `deltree` to `kill` and `delnode` to `killnode`.

- Utility functions are refactored `ydbutils` now. Rename `import utils` to `import ydbutils`.

- deletevar has been replaced through `kill` which does exactly that.

- `get` has been renamed to `getvar` to be more consistent with setvar.

# Changelog for version 0.2.0
## DSL rewrite
The code to implement the Domain Specific Language (DSL) has been rewritten. Most changes where related to `Indirection`.

## deletevar
Instead of calling `deleteGlobal("^solver")`you can now use the DSL `kill: ^solver`

## Indirektion with @
With the `@` (indirection) parameter you get now the full variablename with the key components `^global(1,A)`.
With that you can access all DSL methods:
killnode @gbl, getvar @gbl, setvar: @gbl, ...

The following examples show a typical usage:
```nim
proc getVars(): seq[string] =
    var (rc, gbl) = nextnode: ^hello
    while rc == YDB_OK:
        result.add(gbl)
        (rc, gbl) = nextnode: @gbl

for id in getVars():
    let val = getvar @id
```
 ## Tests
 Tests are now partially factored out to seperate files. Not yet complete.

## Breaking Changes for version 0.2.0
### next/prev
The familiy of next/prev node and next/prev subscript are now defaulting to the `@` indirection form.

That means that instead of a `seq[string]` which contains the key components, a single `string` with the variable name and the keys are now returned by default.

If you need the old `seq[string]` form, you have to add `.seq`to the variable.
```nim
var (rc: int, gbl: string) = nextnode: ^BENCHMARK2
```
Returns `^BENCHMARK(1,A)`.  With that, you can now call any further DSL command, like `getvar @gbl``
```nim
var (rc: int, subs: seq[string]) = nextnode: ^BENCHMARK2().seq
```
returns `@["1", "A"]`.

### getblob
The `getblob` DSL no longer exists. Instead you can use `getvar` and add `.binary` at the end of the variable. This can read data > 1MB.
```nim
let img = getvar ^images(subs).binary
```
