import cli_parse, strformat

const myProgramVersion = "0.5.4"

proc helpMessage(): string =
  result = """
  pico-nim project template builder
  Usage: example2 <subcommand> <subcommand options> <sillyArg>
  Available subcommands: 
    {...}
  """

commandline:
  argument(sillyArg, float) 
  exitoption(@["help", "h"], helpMessage())
  exitoption(@["version", "v"], myProgramVersion)
  option(nom, string, @["name"], required=true)
  errormsg("you have made some kind of mistake")
  subcommand init, @["init", "i"]:
    argument(name, string)
    flag(override, @["override", "O"])
    option(sdk, string, @["sdk", "s"])
    option(nimbase, string, @["nimbase", "n"])
    exitoption(@["help", "h"], "I wish i could help you, but I can't")
  subcommand build, @["build", "b"]:
    argument(mainProgram, string)
    option(output, string,@["output", "o"], "source/build")
  
if init:
  echo fmt"creating a new project directory, {name}. One second..."
elif build:
  echo fmt"writing {name}.uf2 to {output}..."
#else:
  #echo "please use either the 'init' or 'build' subcommand..."
  #echo helpMessage()

