# Package

version       = "0.1.0"
author        = "Jonathan Botchway Owusu"
description   = "Commodore is a simple CLI parsing library."
license       = "MIT"
srcDir        = "src"


# Dependencies

requires "nim >= 2.2.4"
