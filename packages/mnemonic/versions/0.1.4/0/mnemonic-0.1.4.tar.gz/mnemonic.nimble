version     = "0.1.4"
author      = "Mark Spanbroek"
description = "Create memorable sentences from byte sequences."
license     = "MIT"

requires "nimsha2 >= 0.1.1 & < 0.2.0"
