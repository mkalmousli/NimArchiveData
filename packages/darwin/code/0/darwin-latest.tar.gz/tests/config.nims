
switch("path", "$projectDir/..")
