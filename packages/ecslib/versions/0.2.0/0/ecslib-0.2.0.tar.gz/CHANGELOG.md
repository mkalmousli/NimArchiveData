# Change Log
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/)
and this project adheres to [Semantic Versioning](http://semver.org/).

## [Unreleased]

## [0.2.0] -2024-07-10
### Added
- `registerSystems`, `registerStartupSystems` to register systems

### Removed
- Remove `registerSystem`, `registerStartupSystem`

### Fixed
- Fix a compiling issue in `system` with no arguments

## 0.1.0 - 2024-07-08

[Unreleased]: https://github.com/glassesneo/ecslib/compare/0.2.0...HEAD
[0.2.0]: https://github.com/glassesneo/ecslib/compare/0.1.0...0.2.0
