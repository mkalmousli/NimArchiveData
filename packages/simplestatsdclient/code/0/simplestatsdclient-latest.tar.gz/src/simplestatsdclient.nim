import std/[net, asyncdispatch, asyncnet]


const MAX_UDP_SIZE = 1472


type
  StatsDClient* = ref StatsDClientObj
  AsyncStatsDClient* = ref AsyncStatsDClientObj

  StatsDBaseObj {.inheritable.} = object
    host: string
    port: Port
    buffered: bool
    buffer: string

  StatsDClientObj = object of StatsDBaseObj
    socket: Socket

  AsyncStatsDClientObj = object of StatsDBaseObj
    socket: AsyncSocket


proc initCommon(self: StatsDClient|AsyncStatsDClient, host: string, port: Port, buffered = false) =
  self.host = host
  self.port = port
  self.buffered = buffered
  if buffered:
    self.buffer = newStringOfCap(MAX_UDP_SIZE)


proc newStatsDClient*(host: string, port: Port, buffered = false): StatsDClient =
  result.new
  result.initCommon(host, port, buffered)
  result.socket = newSocket(AF_INET, SOCK_DGRAM, IPPROTO_UDP, buffered = false)


proc newAsyncStatsDClient*(host: string, port: Port, buffered = false): AsyncStatsDClient = 
  result.new
  result.initCommon(host, port, buffered)
  result.socket = newAsyncSocket(AF_INET, SOCK_DGRAM, IPPROTO_UDP, buffered = false)


proc realSend(self: StatsDClient|AsyncStatsDClient, data: sink string) {.multisync.} =
  await self.socket.sendTo(self.host, self.port, data)


proc flush*(self: StatsDClient|AsyncStatsDClient) {.multisync.} =
  if self.buffered:
    await self.realSend(self.buffer)
    self.buffer.setLen(0)


proc addToBufferOrFlush(self: StatsDClient|AsyncStatsDClient, data: sink string) {.multisync.} =
  if data.len + self.buffer.len > MAX_UDP_SIZE:
    await self.flush()
  self.buffer.add(data)


proc send(self: StatsDClient|AsyncStatsDClient, data: sink string) {.multisync.} =
  if self.buffered:
    await self.addToBufferOrFlush(data)
  else:
    await self.realSend(data)


proc counter*(self: StatsDClient|AsyncStatsDClient, key: string, value: SomeInteger|SomeFloat) {.multisync.} =
  let value = key & ":" & $value & "|c\n"
  await self.send(value)


proc timer*(self: StatsDClient|AsyncStatsDClient, key: string, value: SomeInteger|SomeFloat) {.multisync.} =
  let value = key & ":" & $value & "|ms\n"
  await self.send(value)


proc gauge*(self: StatsDClient|AsyncStatsDClient, key: string, value: SomeInteger|SomeFloat) {.multisync.} =
  let value = key & ":" & $value & "|g\n"
  await self.send(value)


proc increment*(self: StatsDClient|AsyncStatsDClient, key: string, value: SomeInteger|SomeFloat) {.multisync.} =
  let value = key & ":+" & $value & "|g\n"
  await self.send(value)


proc decrement*(self: StatsDClient|AsyncStatsDClient, key: string, value: SomeInteger|SomeFloat) {.multisync.} =
  let value = key & ":-" & $value & "|g\n"
  await self.send(value)


proc sets*(self: StatsDClient|AsyncStatsDClient, key: string, value: SomeInteger|SomeFloat) {.multisync.} =
  let value = key & ":" & $value & "|s\n"
  await self.send(value)
