import std/math, std/monotimes, std/times

import pixie

import sdfy
import sdfy/shapes

template timeIt(name: string, body: untyped) =
  let start = getMonoTime()
  body
  let stop = getMonoTime()
  echo name, ": ", inMilliseconds(stop - start), " ms"


proc main() =
  let image = newImage(300, 300)
  let center = vec2(image.width / 2, image.height / 2)
  let pos = rgba(255, 0, 0, 255)
  let neg = rgba(0, 0, 255, 255)
  let corners = vec4(0.0, 20.0, 40.0, 80.0)
  let wh = vec2(200.0, 200.0)

  timeIt "base":
    let rect = newImage(300, 300)
    let ctx = newContext(rect)
    ctx.fillStyle = pos
    ctx.fillRoundedRect(rect(center - wh/2, wh), 20.0)
    let shadow = rect.shadow(
      offset = vec2(0, 0),
      spread = 20.0,
      blur = 10.0,
      color = neg
      )
    
    image.draw(shadow)
    image.draw(rect)

  image.writeFile("tests/outputs/rounded_box_pixie.png")

  # Define test modes
  let testModes = [
    (mode: sdfModeClip, name: "clip", factor: 4.0, spread: 0.0, posColor: pos, negColor: neg),
    (mode: sdfModeClipAntiAlias, name: "clip_aliased", factor: 4.0, spread: 0.0, posColor: pos, negColor: neg),
    (mode: sdfModeFeather, name: "feather", factor: 4.0, spread: 0.0, posColor: pos, negColor: neg),
    (mode: sdfModeFeatherInv, name: "feather_inv", factor: 4.0, spread: 0.0, posColor: pos, negColor: neg),
    (mode: sdfModeFeatherGaussian, name: "feather_gaussian", factor: 4.0, spread: 0.0, posColor: pos, negColor: neg),
    (mode: sdfModeDropShadow, name: "drop_shadow", factor: 10.0, spread: 20.0, posColor: pos, negColor: pos)
  ]

  # Test rounded boxes
  for testMode in testModes:
    let testName = "rounded - " & testMode.name
    let fileName = "tests/outputs/rounded_box_" & testMode.name & ".png"
    
    timeIt testName:
      drawSdfShape(image,
                  center = center,
                  wh = wh,
                  params = RoundedBoxParams(r: corners),
                  pos = testMode.posColor,
                  neg = testMode.negColor,
                  factor = testMode.factor,
                  spread = testMode.spread,
                  mode = testMode.mode)

    image.writeFile(fileName)

  # Test chamfer boxes
  for testMode in testModes:
    let testName = "chamfer - " & testMode.name
    let fileName = "tests/outputs/chamfer_box_" & testMode.name & ".png"
    
    timeIt testName:
      drawSdfShape(image,
                  center = center,
                  wh = wh,
                  params = ChamferBoxParams(chamfer: 20.0),
                  pos = testMode.posColor,
                  neg = testMode.negColor,
                  factor = testMode.factor,
                  spread = testMode.spread,
                  mode = testMode.mode)

    image.writeFile(fileName)

for i in 0 ..< 1:
  main()
