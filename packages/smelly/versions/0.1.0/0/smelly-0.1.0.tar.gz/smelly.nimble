version     = "0.1.0"
author      = "Ryan Oldenburg"
description = "Sometimes you have to parse XML"
license     = "MIT"

srcDir = "src"

requires "nim >= 2.0.0"
requires "nimsimd >= 1.2.9"
requires "unicody >= 0.1.4"
