import valkey, unittest, asyncdispatch, os, strutils, options, std/sets

const TestDb = 15

proc getValkeyPassword(): string =
  let path = getHomeDir() / "valkey.creds"
  if fileExists(path):
    return readFile(path).strip()
  return ""

proc connectTest*(T: typedesc[Valkey], db: int = TestDb): Valkey =
  let pw = getValkeyPassword()
  if pw.len > 0:
    result = connectValkey(host = "localhost", db = db, password = pw)
  else:
    result = connectValkey(host = "localhost", db = db)

proc connectTest*(T: typedesc[AsyncValkey], db: int = TestDb): Future[AsyncValkey] {.async.} =
  let pw = getValkeyPassword()
  if pw.len > 0:
    result = await connectValkeyAsync(host = "localhost", db = db, password = pw)
  else:
    result = await connectValkeyAsync(host = "localhost", db = db)

template syncTests() =
  doAssert TestDb != 0, "Don't want to mess up an existing DB."
  let r = connectTest(Valkey)
  discard r.flushdb()
  doAssert r.keys("*").len == 0

  test "simple set and get":
    const expected = "Hello, World!"

    r.setk("redisTests:simpleSetAndGet", expected)
    let actual = r.get("redisTests:simpleSetAndGet")

    check actual == expected

  test "increment key by one":
    const expected = 3

    r.setk("redisTests:incrementKeyByOne", "2")
    let actual = r.incr("redisTests:incrementKeyByOne")

    check actual == expected

  test "increment key by five":
    const expected = 10

    r.setk("redisTests:incrementKeyByFive", "5")
    let actual = r.incrBy("redisTests:incrementKeyByFive", 5)

    check actual == expected

  test "decrement key by one":
    const expected = 2

    r.setk("redisTest:decrementKeyByOne", "3")
    let actual = r.decr("redisTest:decrementKeyByOne")

    check actual == expected

  test "decrement key by three":
    const expected = 7

    r.setk("redisTest:decrementKeyByThree", "10")
    let actual = r.decrBy("redisTest:decrementKeyByThree", 3)

    check actual == expected

  test "append string to key":
    const expected = "hello world"

    r.setk("redisTest:appendStringToKey", "hello")
    let keyLength = r.append("redisTest:appendStringToKey", " world")

    check keyLength == len(expected)
    check r.get("redisTest:appendStringToKey") == expected

  test "check key exists":
    r.setk("redisTest:checkKeyExists", "foo")
    check r.exists("redisTest:checkKeyExists") == true

  test "delete key":
    r.setk("redisTest:deleteKey", "bar")
    check r.exists("redisTest:deleteKey") == true

    check r.del(@["redisTest:deleteKey"]) == 1
    check r.exists("redisTest:deleteKey") == false

  test "rename key":
    const expected = "42"

    r.setk("redisTest:renameKey", expected)
    discard r.rename("redisTest:renameKey", "redisTest:meaningOfLife")

    check r.exists("redisTest:renameKey") == false
    check r.get("redisTest:meaningOfLife") == expected

  test "get key length":
    const expected = 5

    r.setk("redisTest:getKeyLength", "hello")
    let actual = r.strlen("redisTest:getKeyLength")

    check actual == expected

  test "push entries to list":
    for i in 1..5:
      check r.lPush("redisTest:pushEntriesToList", $i) == i

    check r.llen("redisTest:pushEntriesToList") == 5

  test "pfcount supports single key and multiple keys":
    discard r.pfadd("redisTest:pfcount1", @["foo"])
    check r.pfcount("redisTest:pfcount1") == 1

    discard r.pfadd("redisTest:pfcount2", @["bar"])
    check r.pfcount(@["redisTest:pfcount1", "redisTest:pfcount2"]) == 2

  test "engine detection (sync)":
    let valkeyFlag = r.isValkey()
    let redisFlag = r.isRedis()

    # they shouldn't both be true
    check not (valkeyFlag and redisFlag)

    check valkeyFlag or redisFlag

  test "wrongtype raises ResponseError (sync)":
    r.setk("redisTest:wrongType", "x")
    try:
      discard r.lPush("redisTest:wrongType", "y")
      check false # should not reach here
    except ResponseError as e:
      check e.code == "WRONGTYPE"

  test "pipeline flush works":
    r.startPipelining()
    r.setk("pipelineTest:key1", "value1")
    discard r.get("pipelineTest:key1")
    discard r.keys("pipelineTest:*")
    let replies = r.flushPipeline()
    check replies.contains("value1")
    check replies.contains("pipelineTest:key1")

    # pipeline should be reset
    check r.get("pipelineTest:key1") == "value1"
    let ks = r.keys("pipelineTest:*")
    check ks.contains("pipelineTest:key1")

  test "pipeline flush drains after server error":
    r.startPipelining()
    r.setk("pipelineTest:desync:key", "x")
    discard r.lPush("pipelineTest:desync:key", "y")  # wrong type error
    discard r.get("pipelineTest:desync:key")
    discard r.incr("pipelineTest:desync:counter")

    try:
      discard r.flushPipeline()
      check false # should not reach here
    except ResponseError as e:
      check e.code == "WRONGTYPE"

    # if flushPipeline didn't drain, this get would read leftover "x" and fail
    check r.get("pipelineTest:desync:counter") == "1"
    check r.get("pipelineTest:desync:key") == "x"
    check r.incr("pipelineTest:desync:counter") == 2

  # TODO: Ideally tests for all other procedures, will add these in the future

  # delete all keys in the DB at the end of the tests
  discard r.flushdb()
  r.quit()
suite "valkey tests":
  syncTests()

suite "valkey async tests":
  doAssert TestDb != 0, "Don't want to mess up an existing DB."
  let r = waitFor connectTest(AsyncValkey)
  discard waitFor r.flushdb()
  doAssert (waitFor r.keys("*")).len == 0

  test "wrongtype raises ResponseError (async)":
    proc main(): Future[bool] {.async.} =
      await r.setk("redisTestAsync:wrongType", "x")
      try:
        discard await r.lPush("redisTestAsync:wrongType", "y")
        return false # should not reach here
      except ResponseError as e:
        check e.code == "WRONGTYPE"
        check e.cmd.toUpperAscii() == "LPUSH"
        return true

    check waitFor main()

  test "issue #6":
    # See `tawaitorder` for a test that doesn't depend on Redis.
    const count = 5
    proc retr(key: string, expect: string) {.async.} =
      let val = await r.get(key)

      doAssert val == expect

    proc main(): Future[bool] {.async.} =
      for i in 0 ..< count:
        await r.setk("key" & $i, "value" & $i)

      var futures: seq[Future[void]] = @[]
      for i in 0 ..< count:
        futures.add retr("key" & $i, "value" & $i)

      for fut in futures:
        await fut

      return true

    check (waitFor main())

  test "subscribe then quit doesn't hang (issue #34)":
    proc main(): Future[bool] {.async.} =
      let sub = await connectTest(AsyncValkey)
      await sub.subscribe("channel_deadlock_test")
      let ok = await withTimeout(sub.quit(), 2000)
      return ok

    check waitFor main()

  test "pub/sub legacy":

    proc main() {.async.} =
      let sub = await connectTest(AsyncValkey)
      let pub = await connectTest(AsyncValkey)

      let listerns = await pub.publish("channel1", "hi there")
      doAssert listerns == 0

      await sub.subscribe("channel1")
      # you should only call sub.nextMessage() from now on

      discard await pub.publish("channel1", "one")
      discard await pub.publish("channel1", "two")
      discard await pub.publish("channel1", "three")

      doAssert (await sub.nextMessage()).message == "one"
      doAssert (await sub.nextMessage()).message == "two"
      doAssert (await sub.nextMessage()).message == "three"

    waitFor main()
  # TODO: Make new suite for pubsub v2 tests
  test "bad arity -> none":
    check parseEvent(["message", "chan"]).isNone

  test "lazy pubsub":
    let r = waitFor connectTest(AsyncValkey)
    let ps = r.pubsub(ignoreSubscribeMessages = true)
    check ps.conn.isNil
    check ps.ignoreSubscribeMessages == true
    check ps.params.host == "localhost"
    check int(ps.params.port) == 6379

  test "check subscribe acks with pubsub lazy connection":
    proc main(): Future[bool] {.async.} =
      let base = await connectTest(AsyncValkey, db = 3)
      let ps = base.pubsub(ignoreSubscribeMessages = false)
      doAssert ps.params.db == 3
      doAssert ps.conn.isNil

      let ch = "test_pubsub_sub_ack"

      # duplicates should be deduped to one subscribe ack
      await ps.subscribe(ch, ch, ch)
      doAssert ps.conn.isNil == false
      doAssert ps.params.db == 3

      # until ack is consumed, subscribe should be false
      doAssert ps.subscribed == false

      let frame = await ps.parseResponse()

      doAssert frame.len == 3
      doAssert frame[0] == "subscribe"
      doAssert frame[1] == ch
      doAssert frame[2] == "1"

      let evOpt = ps.handleMessage(frame)
      doAssert evOpt.isSome
      let ev = evOpt.get()
      doAssert ev.kind == pekSubscribe
      doAssert ev.channel == ch
      doAssert ev.count == 1

      doAssert ps.subscribed == true

      await ps.close()
      await base.close()
      return true
    check waitFor main()

  # TODO: This test can be flaky because publish may happen before subscribe is active
  test "pubsub ignoreSubscribeMessages":
    proc main(): Future[bool] {.async.} =
      let base = await connectTest(AsyncValkey)
      let pub = await connectTest(AsyncValkey)
      let ps = base.pubsub(ignoreSubscribeMessages = true)

      let ch1 = "test_pubsub_ignore_1"
      let ch2 = "test_pubsub_ignore_2"

      # subscribe to ch1 and don't consume its ack
      await ps.subscribe(ch1)

      # subscribe to ch2 and don't consume its ack
      await ps.subscribe(ch2)

      # publish to ch1, but retry until at least one listener is found
      # TODO: add subscribeWaitAcks helper to pubsub?
      var listeners = 0
      for _ in 0..< 100:
        listeners = await pub.publish(ch1, "hello")
        if listeners >= 1:
          break
        await sleepAsync(50)
      doAssert listeners >= 1

      # should get the message from ch1 not the acks from ch1 or ch2
      let fut = ps.receiveEvent()
      doAssert await withTimeout(fut, 2000)
      let event = await fut

      doAssert event.kind == pekMessage
      doAssert event.channel == ch1
      doAssert event.data == "hello"

      await ps.close()
      await pub.close()
      await base.close()
      return true

    check waitFor main()

  test "pubsub receiveMessage":
    proc main(): Future[bool] {.async.} =
      let base = await connectTest(AsyncValkey)
      let pub  = await connectTest(AsyncValkey)
      let ps   = base.pubsub(ignoreSubscribeMessages = false)

      let ch1 = "test_pubsub_receive_1"
      let ch2 = "test_pubsub_receive_2"

      try:
        await ps.subscribe(ch1)
        discard await ps.receiveEvent()  # consume subscribe ack for ch1

        await ps.subscribe(ch2)          # leave ch2 ack pending
        let msgFut = ps.receiveMessage() # should skip ch2 ack internally

        discard await pub.publish(ch1, "payload")

        doAssert await withTimeout(msgFut, 2000)
        let event = await msgFut

        doAssert event.kind == pekMessage
        doAssert event.channel == ch1
        doAssert event.data == "payload"
        return true
      finally:
        discard await withTimeout(ps.close(), 500)
        discard await withTimeout(pub.close(), 500)
        discard await withTimeout(base.close(), 500)

    check waitFor main()

  test "pubsub: PING returns PONG":
    proc main(): Future[bool] {.async.} =
      let base = await connectTest(AsyncValkey)
      let ps = base.pubsub(ignoreSubscribeMessages = false)

      # unsubscribed scalar ping
      await ps.ping()

      var fut = ps.receiveEvent()
      doAssert await withTimeout(fut, 2000)
      let ev = await fut

      doAssert ev.kind == pekPong
      doAssert ev.data == ""
      doAssert ev.channel == ""

      # unsubscribed ping with payload
      let payload = "hello"
      await ps.ping(payload)

      var futp =  ps.receiveEvent()
      doAssert await withTimeout(futp, 2000)
      let evp = await futp

      doAssert evp.kind == pekPong
      doAssert evp.data == payload
      doAssert evp.channel == ""

      # subscribed ping
      let ch = "test_pubsub_ping"
      await ps.subscribe(ch)

      fut = ps.receiveEvent()
      doAssert await withTimeout(fut, 2000)
      discard await fut  # consume subscribe ack

      await ps.ping()

      fut  = ps.receiveEvent()
      doAssert await withTimeout(fut, 2000)
      let ev2 = await fut
      doAssert ev2.kind == pekPong
      doAssert ev2.data == ""
      doAssert ev2.channel == ""

      await ps.close()
      await base.close()
      return true

    check waitFor main()

  test "unsubscribe":
    proc main(): Future[bool] {.async.} =
      let base = await connectTest(AsyncValkey)
      let ps = base.pubsub(ignoreSubscribeMessages = false)

      let ch1 = "test_unsub_1"
      let ch2 = "test_unsub_2"

      doAssert len(ps.pendingUnsubChannels) == 0

      # waitSubscribed shouldn't be finished yet
      let subFut0 = ps.waitSubscribed()
      doAssert subFut0.finished == false
      doAssert ps.subscribed == false

      await ps.subscribe(ch1, ch2)

      # consume ack 1
      discard await ps.receiveEvent()
      doAssert ps.subscribed == true
      doAssert subFut0.finished == true

      # consume ack 2
      discard await ps.receiveEvent()

      await ps.unsubscribe(ch1, ch1) # duplicate unsubs should be deduped
      doAssert ch1 in ps.pendingUnsubChannels
      doAssert len(ps.pendingUnsubChannels) == 1

      let ev = await ps.receiveEvent()
      doAssert ev.kind == pekUnsubscribe
      doAssert ev.channel == ch1
      doAssert ev.count == 1
      # once the ack is consumed, pending unsubs should be cleared
      doAssert ch1 notin ps.pendingUnsubChannels
      doAssert len(ps.pendingUnsubChannels) == 0

      # still subscribed to ch2
      doAssert ps.subscribed == true

      # unsubscribe from ch2 and make sure the subscribed resets
      let subFut1 = ps.waitSubscribed()
      doAssert subFut0.finished == true
      doAssert subFut1 == subFut0

      # no-args unsubscription should unsubscribe from all channels
      await ps.unsubscribe()
      doAssert ch2 in ps.pendingUnsubChannels
      doAssert len(ps.pendingUnsubChannels) == 1

      let ev2 = await ps.receiveEvent()
      doAssert ev2.kind == pekUnsubscribe
      doAssert ev2.channel == ch2
      doAssert ev2.count == 0
      doAssert ch2 notin ps.pendingUnsubChannels
      doAssert len(ps.pendingUnsubChannels) == 0

      doAssert ps.subscribed == false

      let subFut2 = ps.waitSubscribed()
      doAssert subFut2.finished == false
      doAssert subFut2 != subFut0

      await ps.close()
      await base.close()
      return true

    check waitFor main()

  test "engine detection (async)":
    let valkeyFlag = waitFor r.isValkey()
    let redisFlag = waitFor r.isRedis()

    # they shouldn't both be true
    check not (valkeyFlag and redisFlag)

    check valkeyFlag or redisFlag

  discard waitFor r.flushdb()
  waitFor r.quit()


when compileOption("threads"):
  proc threadFunc() {.thread.} =
    suite "valkey threaded tests":
      syncTests()

  var th: Thread[void]
  createThread(th, threadFunc)
  joinThread(th)

