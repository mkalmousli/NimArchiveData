# Package

version       = "0.0.19"
author        = "bitnom"
description   = "Nim SDK for Claude Code - A port of the Python SDK"
license       = "Apache-2.0"
srcDir        = "src"
installExt    = @["nim"]


# Dependencies

requires "nim >= 2.2.4"
requires "jsony >= 1.1.5"  # JSON parsing/serialization
requires "chronos >= 4.0.0"  # Async support
