# Tests for client module (safe unit tests only)

import std/[unittest, options]
import claude_code_sdk_nim/[simple_client, types, errors]

suite "SimpleClient Creation":
  test "default constructor":
    let client = newSimpleClient()
    check client != nil
    check client.options.max_thinking_tokens == 8000

  test "constructor with options":
    var options = newClaudeCodeOptions()
    options.max_thinking_tokens = 5000
    options.system_prompt = some("Test system prompt")
    
    let client = newSimpleClient(some(options))
    check client != nil
    check client.options.max_thinking_tokens == 5000
    check client.options.system_prompt.get() == "Test system prompt"

  test "constructor with none options":
    let client = newSimpleClient(none(ClaudeCodeOptions))
    check client != nil
    check client.options.max_thinking_tokens == 8000

suite "SimpleClient Error Handling":
  test "query when not connected":
    let client = newSimpleClient()
    expect CLIConnectionError:
      client.query("test prompt")

  test "connection flow":
    let client = newSimpleClient()
    check not client.isConnected()
    
    client.connect()
    check client.isConnected()
    
    client.disconnect()
    check not client.isConnected()

  test "query with empty prompt":
    let client = newSimpleClient()
    client.connect()
    
    expect ValueError:
      client.query("")

# Note: We don't test actual connection/communication as that would require
# Claude CLI to be installed and could potentially execute commands.
# These tests focus on the client's internal logic and error handling.