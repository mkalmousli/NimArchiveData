# Tests for message parser module

import std/[unittest, json, tables, options]
import claude_code_sdk_nim/[message_parser, types, errors]

suite "Message Parser - Valid Messages":
  test "parse user message with string content":
    let jsonData = %*{
      "type": "user",
      "message": {
        "content": "Hello Claude"
      }
    }
    
    let message = parseMessage(jsonData)
    check message.kind == mkUser
    check message.userMessage.content == "Hello Claude"

  test "parse assistant message with text blocks":
    let jsonData = %*{
      "type": "assistant", 
      "message": {
        "content": [
          {
            "type": "text",
            "text": "Hello there!"
          },
          {
            "type": "text", 
            "text": "How can I help?"
          }
        ]
      }
    }
    
    let message = parseMessage(jsonData)
    check message.kind == mkAssistant
    check message.assistantMessage.content.len == 2
    check message.assistantMessage.content[0].kind == cbkText
    check message.assistantMessage.content[0].textBlock.text == "Hello there!"
    check message.assistantMessage.content[1].textBlock.text == "How can I help?"

  test "parse assistant message with tool use":
    let jsonData = %*{
      "type": "assistant",
      "message": {
        "content": [
          {
            "type": "tool_use",
            "id": "tool-123",
            "name": "calculator",
            "input": {
              "expression": "2 + 2"
            }
          }
        ]
      }
    }
    
    let message = parseMessage(jsonData)
    check message.kind == mkAssistant
    check message.assistantMessage.content.len == 1
    check message.assistantMessage.content[0].kind == cbkToolUse
    check message.assistantMessage.content[0].toolUseBlock.id == "tool-123"
    check message.assistantMessage.content[0].toolUseBlock.name == "calculator"
    check message.assistantMessage.content[0].toolUseBlock.input["expression"].getStr() == "2 + 2"

  test "parse assistant message with tool result":
    let jsonData = %*{
      "type": "assistant",
      "message": {
        "content": [
          {
            "type": "tool_result",
            "tool_use_id": "tool-123",
            "content": "The result is 4",
            "is_error": false
          }
        ]
      }
    }
    
    let message = parseMessage(jsonData)
    check message.kind == mkAssistant
    check message.assistantMessage.content.len == 1
    check message.assistantMessage.content[0].kind == cbkToolResult
    check message.assistantMessage.content[0].toolResultBlock.tool_use_id == "tool-123"
    check message.assistantMessage.content[0].toolResultBlock.content.get() == "The result is 4"
    check message.assistantMessage.content[0].toolResultBlock.is_error.get() == false

  test "parse system message":
    let jsonData = %*{
      "type": "system",
      "subtype": "thinking",
      "data": {
        "content": "I need to think about this"
      }
    }
    
    let message = parseMessage(jsonData)
    check message.kind == mkSystem
    check message.systemMessage.subtype == "thinking"
    check message.systemMessage.data["type"].getStr() == "system"
    check message.systemMessage.data["subtype"].getStr() == "thinking"

  test "parse result message":
    let jsonData = %*{
      "type": "result",
      "subtype": "completion",
      "duration_ms": 1500,
      "duration_api_ms": 1200,
      "is_error": false,
      "num_turns": 2,
      "session_id": "session-abc",
      "total_cost_usd": 0.0025,
      "usage": {
        "input_tokens": 100,
        "output_tokens": 50
      },
      "result": "Task completed successfully"
    }
    
    let message = parseMessage(jsonData)
    check message.kind == mkResult
    check message.resultMessage.subtype == "completion"
    check message.resultMessage.duration_ms == 1500
    check message.resultMessage.duration_api_ms == 1200
    check message.resultMessage.is_error == false
    check message.resultMessage.num_turns == 2
    check message.resultMessage.session_id == "session-abc"
    check message.resultMessage.total_cost_usd.get() == 0.0025
    check message.resultMessage.usage.isSome()
    check message.resultMessage.result.get() == "Task completed successfully"

  test "parse result message with minimal fields":
    let jsonData = %*{
      "type": "result",
      "subtype": "error",
      "duration_ms": 500,
      "duration_api_ms": 300,
      "is_error": true,
      "num_turns": 1,
      "session_id": "session-xyz"
    }
    
    let message = parseMessage(jsonData)
    check message.kind == mkResult
    check message.resultMessage.is_error == true
    check message.resultMessage.total_cost_usd.isNone()
    check message.resultMessage.usage.isNone()
    check message.resultMessage.result.isNone()

suite "Message Parser - Error Cases":
  test "invalid message data type":
    let jsonData = %"not an object"
    expect MessageParseError:
      discard parseMessage(jsonData)

  test "missing type field":
    let jsonData = %*{
      "message": "content"
    }
    expect MessageParseError:
      discard parseMessage(jsonData)

  test "unknown message type":
    let jsonData = %*{
      "type": "unknown_type"
    }
    expect MessageParseError:
      discard parseMessage(jsonData)

  test "user message missing message field":
    let jsonData = %*{
      "type": "user"
    }
    expect MessageParseError:
      discard parseMessage(jsonData)

  test "assistant message missing content":
    let jsonData = %*{
      "type": "assistant",
      "message": {}
    }
    expect MessageParseError:
      discard parseMessage(jsonData)

  test "system message missing subtype":
    let jsonData = %*{
      "type": "system",
      "data": {}
    }
    expect MessageParseError:
      discard parseMessage(jsonData)

  test "result message missing required fields":
    let jsonData = %*{
      "type": "result",
      "subtype": "completion"
      # Missing other required fields
    }
    expect MessageParseError:
      discard parseMessage(jsonData)

  test "content block missing type":
    let jsonData = %*{
      "type": "assistant",
      "message": {
        "content": [
          {
            "text": "Hello"
            # Missing "type" field
          }
        ]
      }
    }
    expect MessageParseError:
      discard parseMessage(jsonData)

  test "unknown content block type":
    let jsonData = %*{
      "type": "assistant",
      "message": {
        "content": [
          {
            "type": "unknown_block_type"
          }
        ]
      }
    }
    expect MessageParseError:
      discard parseMessage(jsonData)

suite "Message Parser - JSON String":
  test "parse valid JSON string":
    let jsonStr = """{"type": "user", "message": {"content": "Test"}}"""
    let message = parseMessage(jsonStr)
    check message.kind == mkUser
    check message.userMessage.content == "Test"

  test "parse invalid JSON string":
    let jsonStr = """{"type": "user", "invalid": json}"""
    expect CLIJSONDecodeError:
      discard parseMessage(jsonStr)