# Main test suite for Claude SDK Nim
# 
# To run these tests, execute `nimble test`.

import std/[unittest, options]
import claude_code_sdk_nim

suite "Claude SDK Integration":
  test "version constant":
    check version == "0.0.19"

  test "main exports available":
    # Test that all main exports are accessible
    let options = newClaudeCodeOptions()
    let client = newSimpleClient(some(options))
    let textBlock = newTextBlock("test")
    let userMsg = newUserMessage("test")
    
    # Options is a value type, always valid
    check client != nil
    check textBlock.kind == cbkText
    check userMsg.kind == mkUser

  test "error types available":
    let error1 = newCLINotFoundError("test")
    let error2 = newProcessError("test")
    let error3 = newCLIJSONDecodeError("line", "error")
    let error4 = newMessageParseError("test")
    
    check error1 != nil
    check error2 != nil  
    check error3 != nil
    check error4 != nil

suite "Basic Functionality":
  test "can create and configure options":
    var options = newClaudeCodeOptions()
    options.max_thinking_tokens = 5000
    options.system_prompt = some("Test prompt")
    options.allowed_tools = @["tool1", "tool2"]
    
    check options.max_thinking_tokens == 5000
    check options.system_prompt.get() == "Test prompt"
    check options.allowed_tools == @["tool1", "tool2"]

  test "can create content blocks":
    let text = newTextBlock("Hello")
    let user = newUserMessage("Hello")
    let assistant = newAssistantMessage(@[text])
    
    check text.textBlock.text == "Hello"
    check user.userMessage.content == "Hello" 
    check assistant.assistantMessage.content.len == 1

  test "client creation and basic operations":
    let client = newSimpleClient()
    
    # Test error handling when not connected
    expect CLIConnectionError:
      client.query("test")
    
    # Test connection flow
    client.connect()
    check client.isConnected()
    
    # Test safe disconnect
    client.disconnect()
    check not client.isConnected()

# Note: All tests are safe unit tests that don't invoke external commands
# Integration tests requiring Claude CLI are intentionally omitted for safety
