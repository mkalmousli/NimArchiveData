# Tests for errors module

import std/[unittest, options, tables, json, strutils]
import claude_code_sdk_nim/errors

suite "Error Creation":
  test "CLINotFoundError with path":
    let error = newCLINotFoundError("Test message", "test/path")
    check error.msg == "Test message: test/path"
    check error.cli_path.isSome()
    check error.cli_path.get() == "test/path"

  test "CLINotFoundError without path":
    let error = newCLINotFoundError("Test message")
    check error.msg == "Test message"
    check error.cli_path.isNone()

  test "ProcessError with all fields":
    let error = newProcessError("Process failed", 1, "stderr output")
    check error.msg.contains("Process failed")
    check error.msg.contains("(exit code: 1)")
    check error.msg.contains("Error output: stderr output")
    check error.exit_code.get() == 1
    check error.stderr.get() == "stderr output"

  test "ProcessError minimal":
    let error = newProcessError("Process failed")
    check error.msg == "Process failed"
    check error.exit_code.isNone()
    check error.stderr.isNone()

  test "CLIJSONDecodeError":
    let error = newCLIJSONDecodeError("invalid json line", "JSON parsing error")
    check error.msg.contains("Failed to decode JSON")
    check error.msg.contains("invalid json line")
    check error.line == "invalid json line"
    check error.original_error == "JSON parsing error"

  test "CLIJSONDecodeError with long line":
    let longLine = "x".repeat(150)
    let error = newCLIJSONDecodeError(longLine, "error")
    check error.msg.contains("...")  # Should be truncated
    check error.line == longLine  # But full line stored

  test "MessageParseError with data":
    var data = initTable[string, JsonNode]()
    data["type"] = %"unknown"
    let error = newMessageParseError("Unknown message type", data)
    check error.msg == "Unknown message type"
    check error.data.isSome()
    check error.data.get()["type"].getStr() == "unknown"

  test "MessageParseError without data":
    let error = newMessageParseError("Parse error")
    check error.msg == "Parse error"
    check error.data.isNone()

suite "Error Raising":
  test "raiseCLIConnectionError":
    expect CLIConnectionError:
      raiseCLIConnectionError("Connection failed")

  test "raiseCLINotFoundError":
    expect CLINotFoundError:
      raiseCLINotFoundError("CLI not found", "/path/to/cli")

  test "raiseProcessError":
    expect ProcessError:
      raiseProcessError("Process failed", 2, "error output")

  test "raiseCLIJSONDecodeError":
    expect CLIJSONDecodeError:
      raiseCLIJSONDecodeError("bad json", "parse error")

  test "raiseMessageParseError":
    expect MessageParseError:
      raiseMessageParseError("Parse failed")