# Tests for types module

import std/[unittest, options, tables, json]
import claude_code_sdk_nim/types

suite "PermissionMode":
  test "enum values":
    check $pmDefault == "default"
    check $pmAcceptEdits == "acceptEdits"
    check $pmBypassPermissions == "bypassPermissions"

suite "ClaudeCodeOptions":
  test "default constructor":
    let options = newClaudeCodeOptions()
    check options.max_thinking_tokens == 8000
    check options.allowed_tools.len == 0
    check options.mcp_tools.len == 0
    check options.disallowed_tools.len == 0
    check options.add_dirs.len == 0
    check options.system_prompt.isNone()
    check options.permission_mode.isNone()
    check not options.continue_conversation

  test "field assignments":
    var options = newClaudeCodeOptions()
    options.max_thinking_tokens = 5000
    options.system_prompt = some("Test prompt")
    options.permission_mode = some(pmAcceptEdits)
    options.continue_conversation = true
    options.allowed_tools = @["tool1", "tool2"]
    
    check options.max_thinking_tokens == 5000
    check options.system_prompt.get() == "Test prompt"
    check options.permission_mode.get() == pmAcceptEdits
    check options.continue_conversation
    check options.allowed_tools == @["tool1", "tool2"]

suite "ContentBlock":
  test "TextBlock creation":
    let contentBlock = newTextBlock("Hello world")
    check contentBlock.kind == cbkText
    check contentBlock.textBlock.text == "Hello world"

  test "ToolUseBlock creation":
    var input = initTable[string, JsonNode]()
    input["param1"] = %"value1"
    input["param2"] = %42
    
    let contentBlock = newToolUseBlock("test-id", "test-tool", input)
    check contentBlock.kind == cbkToolUse
    check contentBlock.toolUseBlock.id == "test-id"
    check contentBlock.toolUseBlock.name == "test-tool"
    check contentBlock.toolUseBlock.input["param1"].getStr() == "value1"
    check contentBlock.toolUseBlock.input["param2"].getInt() == 42

  test "ToolResultBlock creation":
    let contentBlock1 = newToolResultBlock("tool-id", some("result content"), some(false))
    check contentBlock1.kind == cbkToolResult
    check contentBlock1.toolResultBlock.tool_use_id == "tool-id"
    check contentBlock1.toolResultBlock.content.get() == "result content"
    check contentBlock1.toolResultBlock.is_error.get() == false
    
    let contentBlock2 = newToolResultBlock("tool-id")
    check contentBlock2.toolResultBlock.content.isNone()
    check contentBlock2.toolResultBlock.is_error.isNone()

suite "Message":
  test "UserMessage creation":
    let msg = newUserMessage("Test user message")
    check msg.kind == mkUser
    check msg.userMessage.content == "Test user message"

  test "AssistantMessage creation":
    let content = @[
      newTextBlock("Hello"),
      newTextBlock("World")
    ]
    let msg = newAssistantMessage(content)
    check msg.kind == mkAssistant
    check msg.assistantMessage.content.len == 2
    check msg.assistantMessage.content[0].textBlock.text == "Hello"
    check msg.assistantMessage.content[1].textBlock.text == "World"

  test "SystemMessage creation":
    var data = initTable[string, JsonNode]()
    data["key1"] = %"value1"
    data["key2"] = %123
    
    let msg = newSystemMessage("test-subtype", data)
    check msg.kind == mkSystem
    check msg.systemMessage.subtype == "test-subtype"
    check msg.systemMessage.data["key1"].getStr() == "value1"
    check msg.systemMessage.data["key2"].getInt() == 123

  test "ResultMessage creation":
    let msg = newResultMessage("completion", 1000, 800, false, 3, "session-123")
    check msg.kind == mkResult
    check msg.resultMessage.subtype == "completion"
    check msg.resultMessage.duration_ms == 1000
    check msg.resultMessage.duration_api_ms == 800
    check msg.resultMessage.is_error == false
    check msg.resultMessage.num_turns == 3
    check msg.resultMessage.session_id == "session-123"
    check msg.resultMessage.total_cost_usd.isNone()
    check msg.resultMessage.usage.isNone()
    check msg.resultMessage.result.isNone()

suite "McpServerConfig":
  test "McpServerType enum":
    check $mstStdio == "stdio"
    check $mstSse == "sse" 
    check $mstHttp == "http"