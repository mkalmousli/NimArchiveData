## Claude SDK for Nim
##
## This is the main module for the Claude SDK for Nim, providing access to
## Claude Code functionality. This is a port of the Python SDK.

import claude_code_sdk_nim/[
  types, errors, message_parser, simple_client
]

# Re-export main types and functions  
export types, errors, message_parser, simple_client

# Version information
const version* = "0.0.19"

# Main exports for convenience
export SimpleClient, newSimpleClient
export ClaudeCodeOptions, newClaudeCodeOptions
export PermissionMode, Message, MessageKind
export ContentBlock, ContentBlockKind
export UserMessage, AssistantMessage, SystemMessage, ResultMessage
export TextBlock, ToolUseBlock, ToolResultBlock
export McpServerConfig, McpServerType
export ClaudeSDKError, CLIConnectionError, CLINotFoundError, ProcessError
export CLIJSONDecodeError, MessageParseError
