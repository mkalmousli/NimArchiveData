## Internal client implementation
##
## This module provides the internal client used by the query function,
## ported from the Python version.

import std/[json, asyncdispatch]
import chronos
import ./types
import ./message_parser
import ./subprocess_transport

type
  InternalClient* = ref object
    ## Internal client implementation

proc newInternalClient*(): InternalClient =
  ## Initialize the internal client
  InternalClient()

proc processQuery*(
  client: InternalClient,
  prompt: string,
  options: ClaudeCodeOptions
): AsyncIterator[Message] {.async.} =
  ## Process a query through transport
  let transport = newSubprocessCLITransport(
    prompt = prompt,
    options = options,
    closeStdinAfterPrompt = true
  )
  
  try:
    await transport.connect()
    
    # Iterate through messages from transport
    var messageIter = transport.receiveMessages()
    while true:
      let (hasData, data) = await messageIter.next()
      if not hasData:
        break
      
      let message = parseMessage(data)
      yield message
  
  finally:
    await transport.disconnect()