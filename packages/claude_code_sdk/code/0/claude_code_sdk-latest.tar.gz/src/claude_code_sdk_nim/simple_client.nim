## Simplified client implementation for testing
##
## This module provides a basic client implementation that can be tested
## without requiring complex async transport or CLI integration

import std/[options, os]
import ./types
import ./errors
import ./simple_transport

type
  SimpleClient* = ref object
    options*: ClaudeCodeOptions  # Make public for testing
    transport: SimpleTransport

proc newSimpleClient*(options: Option[ClaudeCodeOptions] = none(ClaudeCodeOptions)): SimpleClient =
  ## Create a new simplified client
  let opts = if options.isSome: options.get() else: newClaudeCodeOptions()
  
  result = SimpleClient(
    options: opts,
    transport: newSimpleTransport(opts)
  )
  
  # Set environment variable
  putEnv("CLAUDE_CODE_ENTRYPOINT", "sdk-nim-simple-client")

proc connect*(client: SimpleClient) =
  ## Connect to Claude (simplified)
  if client.transport == nil:
    raise newException(CLIConnectionError, "Transport not initialized")
  client.transport.connect()

proc disconnect*(client: SimpleClient) =
  ## Disconnect from Claude (simplified)
  if client.transport != nil:
    client.transport.disconnect()

proc isConnected*(client: SimpleClient): bool =
  ## Check if client is connected
  if client.transport == nil:
    return false
  return client.transport.isConnected()

proc query*(client: SimpleClient, prompt: string) =
  ## Send a query (simplified - doesn't actually send)
  if not client.isConnected():
    raise newException(CLIConnectionError, "Not connected. Call connect() first.")
  
  # In a real implementation, this would send the prompt to Claude
  # For testing, we just validate the input
  if prompt.len == 0:
    raise newException(ValueError, "Prompt cannot be empty")