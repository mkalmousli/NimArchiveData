## Claude SDK Client for interacting with Claude Code
##
## This module provides the main ClaudeSDKClient class for bidirectional,
## interactive conversations with Claude Code, ported from the Python version.

import std/[json, tables, options, os, asyncdispatch]
import chronos
import ./types
import ./errors
import ./message_parser
import ./subprocess_transport

type
  ClaudeSDKClient* = ref object
    ## Client for bidirectional, interactive conversations with Claude Code
    ##
    ## This client provides full control over the conversation flow with support
    ## for streaming, interrupts, and dynamic message sending. For simple one-shot
    ## queries, consider using the query() function instead.
    ##
    ## Key features:
    ## - **Bidirectional**: Send and receive messages at any time  
    ## - **Stateful**: Maintains conversation context across messages
    ## - **Interactive**: Send follow-ups based on responses
    ## - **Control flow**: Support for interrupts and session management
    options: ClaudeCodeOptions
    transport: SubprocessCLITransport

proc newClaudeSDKClient*(options: ClaudeCodeOptions = nil): ClaudeSDKClient =
  ## Initialize Claude SDK client
  let opts = if options != nil: options else: newClaudeCodeOptions()
  
  result = ClaudeSDKClient(
    options: opts,
    transport: nil
  )
  
  # Set environment variable for entrypoint identification
  putEnv("CLAUDE_CODE_ENTRYPOINT", "sdk-nim-client")

proc connect*(
  client: ClaudeSDKClient,
  prompt: string = ""
): Future[void] {.async.} =
  ## Connect to Claude with a prompt
  ## 
  ## Auto-connects with empty prompt if no prompt is provided for interactive use
  let actualPrompt = if prompt.len == 0: "" else: prompt
  
  client.transport = newSubprocessCLITransport(
    prompt = actualPrompt,
    options = client.options
  )
  
  await client.transport.connect()

proc receiveMessages*(client: ClaudeSDKClient): AsyncIterator[Message] {.async.} =
  ## Receive all messages from Claude
  if client.transport == nil or not client.transport.isConnected():
    raiseCLIConnectionError("Not connected. Call connect() first.")
  
  var messageIter = client.transport.receiveMessages()
  while true:
    let (hasData, data) = await messageIter.next()
    if not hasData:
      break
    
    let message = parseMessage(data)
    yield message

proc query*(
  client: ClaudeSDKClient,
  prompt: string,
  sessionId: string = "default"
): Future[void] {.async.} =
  ## Send a new request in streaming mode
  ##
  ## Args:
  ##   prompt: String message to send
  ##   sessionId: Session identifier for the conversation
  if client.transport == nil or not client.transport.isConnected():
    raiseCLIConnectionError("Not connected. Call connect() first.")
  
  # For now, simplified - this would be implemented for streaming mode
  raiseCLIConnectionError("Dynamic query not yet implemented - use connect() with initial prompt")

proc interrupt*(client: ClaudeSDKClient): Future[void] {.async.} =  
  ## Send interrupt signal (only works with streaming mode)
  if client.transport == nil or not client.transport.isConnected():
    raiseCLIConnectionError("Not connected. Call connect() first.")
  
  await client.transport.interrupt()

proc receiveResponse*(client: ClaudeSDKClient): AsyncIterator[Message] {.async.} =
  ## Receive messages from Claude until and including a ResultMessage
  ##
  ## This async iterator yields all messages in sequence and automatically terminates
  ## after yielding a ResultMessage (which indicates the response is complete).
  ## It's a convenience method over receiveMessages() for single-response workflows.
  ##
  ## **Stopping Behavior:**
  ## - Yields each message as it's received
  ## - Terminates immediately after yielding a ResultMessage
  ## - The ResultMessage IS included in the yielded messages
  ## - If no ResultMessage is received, the iterator continues indefinitely
  var messageIter = client.receiveMessages()
  while true:
    let (hasMessage, message) = await messageIter.next()
    if not hasMessage:
      break
    
    yield message
    
    if message.kind == mkResult:
      return

proc disconnect*(client: ClaudeSDKClient): Future[void] {.async.} =
  ## Disconnect from Claude
  if client.transport != nil:
    await client.transport.disconnect()
    client.transport = nil

# Async context manager-like functionality
proc use*[T](client: ClaudeSDKClient, body: proc(c: ClaudeSDKClient): Future[T] {.async.}): Future[T] {.async.} =
  ## Use client with automatic connection and cleanup
  ## 
  ## Example:
  ##   let client = newClaudeSDKClient()
  ##   await client.use(proc(c: ClaudeSDKClient): Future[void] {.async.} =
  ##     await c.connect("Hello Claude!")
  ##     # Process messages...
  ##   )
  try:
    await client.connect("")
    result = await body(client)
  except Exception as e:
    raise e
  finally:
    await client.disconnect()