## Message parser for Claude Code SDK responses
##
## This module parses JSON messages from the Claude CLI into typed Message objects,
## ported from the Python version.

import std/[json, tables, options, logging]
import jsony
import ./types
import ./errors

var logger = newConsoleLogger()

proc parseContentBlock(blockData: JsonNode): ContentBlock =
  ## Parse a content block from JSON data
  if not blockData.hasKey("type"):
    raiseMessageParseError("Content block missing 'type' field")
  
  let blockType = blockData["type"].getStr()
  case blockType:
  of "text":
    if not blockData.hasKey("text"):
      raiseMessageParseError("Text block missing 'text' field")
    return newTextBlock(blockData["text"].getStr())
  
  of "tool_use":
    if not blockData.hasKey("id") or not blockData.hasKey("name") or not blockData.hasKey("input"):
      raiseMessageParseError("Tool use block missing required fields")
    
    var inputTable = initTable[string, JsonNode]()
    let inputNode = blockData["input"]
    if inputNode.kind == JObject:
      for key, value in inputNode.pairs:
        inputTable[key] = value
    
    return newToolUseBlock(
      blockData["id"].getStr(),
      blockData["name"].getStr(), 
      inputTable
    )
  
  of "tool_result":
    if not blockData.hasKey("tool_use_id"):
      raiseMessageParseError("Tool result block missing 'tool_use_id' field")
    
    let content = if blockData.hasKey("content") and blockData["content"].kind != JNull:
      some(blockData["content"].getStr())
    else:
      none(string)
    
    let isError = if blockData.hasKey("is_error") and blockData["is_error"].kind != JNull:
      some(blockData["is_error"].getBool())
    else:
      none(bool)
    
    return newToolResultBlock(
      blockData["tool_use_id"].getStr(),
      content,
      isError
    )
  
  else:
    raiseMessageParseError("Unknown content block type: " & blockType)

proc parseMessage*(data: JsonNode): Message =
  ## Parse message from CLI output into typed Message objects
  ##
  ## Args:
  ##   data: Raw message JSON node from CLI output
  ##
  ## Returns:
  ##   Parsed Message object
  ##
  ## Raises:
  ##   MessageParseError: If parsing fails or message type is unrecognized
  if data.kind != JObject:
    raiseMessageParseError("Invalid message data type (expected object, got " & $data.kind & ")")
  
  if not data.hasKey("type"):
    raiseMessageParseError("Message missing 'type' field")
  
  let messageType = data["type"].getStr()
  
  case messageType:
  of "user":
    try:
      if not data.hasKey("message"):
        raiseMessageParseError("User message missing 'message' field")
      
      let messageData = data["message"]
      if not messageData.hasKey("content"):
        raiseMessageParseError("User message missing 'content' field")
      
      let contentNode = messageData["content"]
      if contentNode.kind == JArray:
        # Handle content blocks (simplified - just return as string for now)
        # TODO: Implement full content block parsing for user messages
        return newUserMessage("(Complex content blocks not yet supported)")
      else:
        return newUserMessage(contentNode.getStr())
    
    except JsonKindError:
      raiseMessageParseError("Invalid user message structure")
  
  of "assistant":
    try:
      if not data.hasKey("message"):
        raiseMessageParseError("Assistant message missing 'message' field")
      
      let messageData = data["message"]
      if not messageData.hasKey("content"):
        raiseMessageParseError("Assistant message missing 'content' field")
      
      let contentArray = messageData["content"]
      if contentArray.kind != JArray:
        raiseMessageParseError("Assistant message content must be an array")
      
      var contentBlocks: seq[ContentBlock] = @[]
      for blockNode in contentArray:
        contentBlocks.add(parseContentBlock(blockNode))
      
      return newAssistantMessage(contentBlocks)
    
    except JsonKindError:
      raiseMessageParseError("Invalid assistant message structure")
  
  of "system":
    try:
      if not data.hasKey("subtype"):
        raiseMessageParseError("System message missing 'subtype' field")
      
      var dataTable = initTable[string, JsonNode]()
      for key, value in data.pairs:
        dataTable[key] = value
      
      return newSystemMessage(
        data["subtype"].getStr(),
        dataTable
      )
    
    except JsonKindError:
      raiseMessageParseError("Invalid system message structure")
  
  of "result":
    try:
      # Check required fields
      let requiredFields = ["subtype", "duration_ms", "duration_api_ms", 
                          "is_error", "num_turns", "session_id"]
      for field in requiredFields:
        if not data.hasKey(field):
          raiseMessageParseError("Result message missing required field: " & field)
      
      var resultMsg = newResultMessage(
        data["subtype"].getStr(),
        data["duration_ms"].getInt(),
        data["duration_api_ms"].getInt(),
        data["is_error"].getBool(),
        data["num_turns"].getInt(),
        data["session_id"].getStr()
      )
      
      # Handle optional fields
      if data.hasKey("total_cost_usd") and data["total_cost_usd"].kind != JNull:
        resultMsg.resultMessage.total_cost_usd = some(data["total_cost_usd"].getFloat())
      
      if data.hasKey("usage") and data["usage"].kind != JNull:
        var usageTable = initTable[string, JsonNode]()
        let usageNode = data["usage"]
        if usageNode.kind == JObject:
          for key, value in usageNode.pairs:
            usageTable[key] = value
        resultMsg.resultMessage.usage = some(usageTable)
      
      if data.hasKey("result") and data["result"].kind != JNull:
        resultMsg.resultMessage.result = some(data["result"].getStr())
      
      return resultMsg
    
    except JsonKindError:
      raiseMessageParseError("Invalid result message structure")
  
  else:
    raiseMessageParseError("Unknown message type: " & messageType)

proc parseMessage*(jsonStr: string): Message =
  ## Parse message from JSON string
  try:
    let jsonData = parseJson(jsonStr)
    return parseMessage(jsonData)
  except JsonParsingError as e:
    raiseCLIJSONDecodeError(jsonStr, e.msg)