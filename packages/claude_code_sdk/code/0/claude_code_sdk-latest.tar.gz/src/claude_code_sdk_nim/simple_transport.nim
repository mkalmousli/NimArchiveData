## Simplified transport implementation for testing
##
## This module provides a minimal transport implementation for basic functionality

import std/[json, tables, options, os, osproc, strutils]
import ./types
import ./errors

type
  SimpleTransport* = ref object
    options: ClaudeCodeOptions
    cliPath: string
    connected: bool

proc newSimpleTransport*(options: ClaudeCodeOptions): SimpleTransport =
  ## Create a new simple transport (for testing)
  SimpleTransport(
    options: options,
    cliPath: "claude",  # Assume claude is in PATH for now
    connected: false
  )

proc connect*(transport: SimpleTransport) =
  ## Connect to transport (simplified)
  transport.connected = true

proc disconnect*(transport: SimpleTransport) = 
  ## Disconnect from transport (simplified)
  transport.connected = false

proc isConnected*(transport: SimpleTransport): bool =
  ## Check if connected
  transport.connected