## Transport implementations for Claude SDK
##
## This module defines the abstract transport interface and concrete implementations
## for communicating with Claude Code CLI.

import std/[json, tables, asyncdispatch, streams, options]
import chronos

# Abstract transport interface
type
  Transport* = ref object of RootObj

# Abstract methods that must be implemented by concrete transports
method connect*(transport: Transport): Future[void] {.base, async.} =
  ## Initialize connection
  raise newException(CatchableError, "Method must be implemented by subclass")

method disconnect*(transport: Transport): Future[void] {.base, async.} =
  ## Close connection
  raise newException(CatchableError, "Method must be implemented by subclass")

method sendRequest*(transport: Transport, messages: seq[JsonNode], options: JsonNode): Future[void] {.base, async.} =
  ## Send request to Claude
  raise newException(CatchableError, "Method must be implemented by subclass")

method receiveMessages*(transport: Transport): AsyncIterator[JsonNode] {.base.} =
  ## Receive messages from Claude
  raise newException(CatchableError, "Method must be implemented by subclass")

method isConnected*(transport: Transport): bool {.base.} =
  ## Check if transport is connected
  raise newException(CatchableError, "Method must be implemented by subclass")

method interrupt*(transport: Transport): Future[void] {.base, async.} =
  ## Send interrupt signal (for streaming mode)
  raise newException(CatchableError, "Method must be implemented by subclass")