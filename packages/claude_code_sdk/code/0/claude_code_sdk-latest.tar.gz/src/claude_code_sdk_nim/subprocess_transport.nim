## Subprocess transport implementation using Claude Code CLI
##
## This module implements the Transport interface using subprocess communication
## with the Claude Code CLI, ported from the Python version.

import std/[json, tables, asyncdispatch, streams, options, os, osproc, strutils, sequtils]
import ./transport
import ./types
import ./errors

var logger = newConsoleLogger()

const MAX_BUFFER_SIZE = 1024 * 1024  # 1MB buffer limit

type
  PromptType = enum
    ptString, ptAsyncIterable

  SubprocessCLITransport* = ref object of Transport
    prompt: string  # Simplified - just support string prompts for now
    promptType: PromptType
    options: ClaudeCodeOptions
    cliPath: string
    cwd: Option[string]
    process: Process
    outputBuffer: string
    connected: bool
    closeStdinAfterPrompt: bool
    stderrFile: File
    stderrPath: string

proc findCli(): string =
  ## Find Claude Code CLI binary
  
  # Try which/where command first
  when defined(windows):
    let whichCmd = "where claude"
  else:
    let whichCmd = "which claude"
  
  let (output, exitCode) = execCmdEx(whichCmd)
  if exitCode == 0 and output.strip().len > 0:
    return output.strip()
  
  # Try common locations
  let homeDir = getHomeDir()
  let locations = [
    homeDir / ".npm-global/bin/claude",
    "/usr/local/bin/claude", 
    homeDir / ".local/bin/claude",
    homeDir / "node_modules/.bin/claude",
    homeDir / ".yarn/bin/claude"
  ]
  
  for path in locations:
    if fileExists(path):
      return path
  
  # Check if Node.js is installed
  when defined(windows):
    let nodeCmd = "where node"
  else:
    let nodeCmd = "which node"
  
  let (nodeOutput, nodeExitCode) = execCmdEx(nodeCmd)
  let nodeInstalled = nodeExitCode == 0 and nodeOutput.strip().len > 0
  
  if not nodeInstalled:
    let errorMsg = "Claude Code requires Node.js, which is not installed.\n\n" &
                   "Install Node.js from: https://nodejs.org/\n" &
                   "\nAfter installing Node.js, install Claude Code:\n" &
                   "  npm install -g @anthropic-ai/claude-code"
    raiseCLINotFoundError(errorMsg)
  
  raiseCLINotFoundError("Claude Code not found. Install with:\n" &
                        "  npm install -g @anthropic-ai/claude-code\n" &
                        "\nIf already installed locally, try:\n" &
                        "  export PATH=\"$HOME/node_modules/.bin:$PATH\"\n" &
                        "\nOr specify the path when creating transport")

proc newSubprocessCLITransport*(
  prompt: string,
  options: ClaudeCodeOptions,
  cliPath: string = "",
  closeStdinAfterPrompt: bool = false
): SubprocessCLITransport =
  ## Create new subprocess CLI transport
  let actualCliPath = if cliPath.len > 0: cliPath else: findCli()
  
  result = SubprocessCLITransport(
    prompt: prompt,
    promptType: ptString,
    options: options,
    cliPath: actualCliPath,
    cwd: options.cwd,
    connected: false,
    closeStdinAfterPrompt: closeStdinAfterPrompt,
    outputBuffer: ""
  )

proc buildCommand(transport: SubprocessCLITransport): seq[string] =
  ## Build CLI command with arguments
  result = @[transport.cliPath, "--output-format", "stream-json", "--verbose"]
  
  if transport.options.system_prompt.isSome:
    result.add(["--system-prompt", transport.options.system_prompt.get()])
  
  if transport.options.append_system_prompt.isSome:
    result.add(["--append-system-prompt", transport.options.append_system_prompt.get()])
  
  if transport.options.allowed_tools.len > 0:
    result.add(["--allowedTools", transport.options.allowed_tools.join(",")])
  
  if transport.options.max_turns.isSome:
    result.add(["--max-turns", $transport.options.max_turns.get()])
  
  if transport.options.disallowed_tools.len > 0:
    result.add(["--disallowedTools", transport.options.disallowed_tools.join(",")])
  
  if transport.options.model.isSome:
    result.add(["--model", transport.options.model.get()])
  
  if transport.options.permission_prompt_tool_name.isSome:
    result.add(["--permission-prompt-tool", transport.options.permission_prompt_tool_name.get()])
  
  if transport.options.permission_mode.isSome:
    result.add(["--permission-mode", $transport.options.permission_mode.get()])
  
  if transport.options.continue_conversation:
    result.add("--continue")
  
  if transport.options.resume.isSome:
    result.add(["--resume", transport.options.resume.get()])
  
  if transport.options.settings.isSome:
    result.add(["--settings", transport.options.settings.get()])
  
  for directory in transport.options.add_dirs:
    result.add(["--add-dir", directory])
  
  if transport.options.mcp_servers.len > 0:
    let mcpConfig = %*{"mcpServers": transport.options.mcp_servers}
    result.add(["--mcp-config", $mcpConfig])
  
  # For now, only support string prompts (non-streaming)
  result.add(["--print", transport.prompt])

method connect*(transport: SubprocessCLITransport): Future[void] {.async.} =
  ## Start subprocess
  if transport.connected:
    return
  
  let cmd = transport.buildCommand()
  logger.log(lvlDebug, "Starting Claude CLI: " & cmd.join(" "))
  
  try:
    # Create temporary file for stderr
    let (stderrFd, stderrPath) = createTempFile("claude_stderr_", ".log")
    transport.stderrPath = stderrPath
    transport.stderrFile = fdopen(stderrFd, fmWrite)
    
    # Start process
    let workingDir = if transport.cwd.isSome: transport.cwd.get() else: getCurrentDir()
    
    # Set environment variable
    putEnv("CLAUDE_CODE_ENTRYPOINT", "sdk-nim")
    
    transport.process = startProcess(
      command = cmd[0],
      args = cmd[1..^1],
      workingDir = workingDir,
      options = {poUsePath, poStdErrToFile, poParentStreams}
    )
    
    transport.connected = true
    logger.log(lvlDebug, "Claude CLI started successfully")
    
  except OSError as e:
    # Check if error is due to working directory or CLI not found
    if transport.cwd.isSome and not dirExists(transport.cwd.get()):
      raiseCLIConnectionError("Working directory does not exist: " & transport.cwd.get())
    raiseCLINotFoundError("Claude Code not found at: " & transport.cliPath)
  except Exception as e:
    raiseCLIConnectionError("Failed to start Claude Code: " & e.msg)

method disconnect*(transport: SubprocessCLITransport): Future[void] {.async.} =
  ## Terminate subprocess
  if not transport.connected:
    return
  
  if transport.process != nil:
    if transport.process.running:
      transport.process.terminate()
      discard transport.process.waitForExit(timeout = 5000)
      if transport.process.running:
        transport.process.kill()
    transport.process.close()
    transport.process = nil
  
  # Clean up stderr file
  if transport.stderrFile != nil:
    transport.stderrFile.close()
    if fileExists(transport.stderrPath):
      removeFile(transport.stderrPath)
  
  transport.connected = false
  logger.log(lvlDebug, "Claude CLI disconnected")

method receiveMessages*(transport: SubprocessCLITransport): AsyncIterator[JsonNode] {.async.} =
  ## Receive messages from Claude
  if not transport.connected:
    raiseCLIConnectionError("Not connected. Call connect() first.")
  
  # For now, simplified implementation - read all output at once
  # In a full implementation, this would stream line by line
  try:
    let output = transport.process.outputStream.readAll()
    let lines = output.splitLines()
    
    for line in lines:
      if line.strip().len > 0:
        try:
          let jsonData = parseJson(line)
          yield jsonData
        except JsonParsingError as e:
          # Skip invalid JSON lines (may be debug output)
          logger.log(lvlWarn, "Skipping invalid JSON line: " & line[0..min(99, line.len-1)])
          continue
          
  except Exception as e:
    raiseProcessError("Failed to read from Claude CLI: " & e.msg)

method sendRequest*(transport: SubprocessCLITransport, messages: seq[JsonNode], options: JsonNode): Future[void] {.async.} =
  ## Send additional messages (not supported in non-streaming mode for now)
  raiseCLIConnectionError("sendRequest not supported in non-streaming mode")

method isConnected*(transport: SubprocessCLITransport): bool =
  ## Check if transport is connected
  return transport.connected and transport.process != nil and transport.process.running

method interrupt*(transport: SubprocessCLITransport): Future[void] {.async.} =
  ## Send interrupt signal (not supported in non-streaming mode for now)  
  raiseCLIConnectionError("interrupt not supported in non-streaming mode")