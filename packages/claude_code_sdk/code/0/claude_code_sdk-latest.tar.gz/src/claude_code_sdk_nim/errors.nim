## Error types for Claude SDK
##
## This module defines all the exception types used by the Claude SDK,
## ported from the Python version.

import std/[options, tables, json]

# Base exception for all Claude SDK errors
type ClaudeSDKError* = object of CatchableError

# Raised when unable to connect to Claude Code
type CLIConnectionError* = object of ClaudeSDKError

# Raised when Claude Code is not found or not installed
type CLINotFoundError* = object of CLIConnectionError
  cli_path*: Option[string]

# Raised when the CLI process fails
type ProcessError* = object of ClaudeSDKError
  exit_code*: Option[int]
  stderr*: Option[string]

# Raised when unable to decode JSON from CLI output
type CLIJSONDecodeError* = object of ClaudeSDKError
  line*: string
  original_error*: string

# Raised when unable to parse a message from CLI output
type MessageParseError* = object of ClaudeSDKError
  data*: Option[Table[string, JsonNode]]

# Constructor procedures for exceptions
proc newCLINotFoundError*(message: string, cli_path: string = ""): ref CLINotFoundError =
  ## Create a new CLINotFoundError
  let msg = if cli_path.len > 0: message & ": " & cli_path else: message
  result = newException(CLINotFoundError, msg)
  result.cli_path = if cli_path.len > 0: some(cli_path) else: none(string)

proc newProcessError*(message: string, exit_code: int = -1, stderr: string = ""): ref ProcessError =
  ## Create a new ProcessError
  var msg = message
  if exit_code != -1:
    msg = msg & " (exit code: " & $exit_code & ")"
  if stderr.len > 0:
    msg = msg & "\nError output: " & stderr
  
  result = newException(ProcessError, msg)
  result.exit_code = if exit_code != -1: some(exit_code) else: none(int)
  result.stderr = if stderr.len > 0: some(stderr) else: none(string)

proc newCLIJSONDecodeError*(line: string, original_error: string): ref CLIJSONDecodeError =
  ## Create a new CLIJSONDecodeError
  let truncated_line = if line.len > 100: line[0..99] & "..." else: line
  let msg = "Failed to decode JSON: " & truncated_line
  
  result = newException(CLIJSONDecodeError, msg)
  result.line = line
  result.original_error = original_error

proc newMessageParseError*(message: string, data: Table[string, JsonNode] = initTable[string, JsonNode]()): ref MessageParseError =
  ## Create a new MessageParseError
  result = newException(MessageParseError, message)
  result.data = if data.len > 0: some(data) else: none(Table[string, JsonNode])

# Convenience procedures for raising exceptions
proc raiseCLIConnectionError*(message: string) {.noReturn.} =
  ## Raise a CLIConnectionError
  raise newException(CLIConnectionError, message)

proc raiseCLINotFoundError*(message: string = "Claude Code not found", cli_path: string = "") {.noReturn.} =
  ## Raise a CLINotFoundError
  raise newCLINotFoundError(message, cli_path)

proc raiseProcessError*(message: string, exit_code: int = -1, stderr: string = "") {.noReturn.} =
  ## Raise a ProcessError
  raise newProcessError(message, exit_code, stderr)

proc raiseCLIJSONDecodeError*(line: string, original_error: string) {.noReturn.} =
  ## Raise a CLIJSONDecodeError
  raise newCLIJSONDecodeError(line, original_error)

proc raiseMessageParseError*(message: string, data: Table[string, JsonNode] = initTable[string, JsonNode]()) {.noReturn.} =
  ## Raise a MessageParseError
  raise newMessageParseError(message, data)