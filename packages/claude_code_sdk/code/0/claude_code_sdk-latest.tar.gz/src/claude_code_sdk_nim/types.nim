## Type definitions for Claude SDK
## 
## This module contains all the data types used by the Claude SDK,
## ported from the Python version.

import std/[options, tables, json]
import jsony

# Permission modes
type
  PermissionMode* = enum
    pmDefault = "default"
    pmAcceptEdits = "acceptEdits" 
    pmBypassPermissions = "bypassPermissions"

# MCP Server configurations
type
  McpServerType* = enum
    mstStdio = "stdio"
    mstSse = "sse"
    mstHttp = "http"

  McpStdioServerConfig* = object
    `type`*: Option[McpServerType]  # Optional for backwards compatibility
    command*: string
    args*: Option[seq[string]]
    env*: Option[Table[string, string]]

  McpSseServerConfig* = object
    `type`*: McpServerType
    url*: string
    headers*: Option[Table[string, string]]

  McpHttpServerConfig* = object
    `type`*: McpServerType
    url*: string
    headers*: Option[Table[string, string]]

  McpServerConfig* = object
    # Simplified - just use a generic config object for now
    serverType*: McpServerType
    command*: Option[string]
    url*: Option[string] 
    args*: Option[seq[string]]
    env*: Option[Table[string, string]]
    headers*: Option[Table[string, string]]

# Content block types
type
  TextBlock* = object
    text*: string

  ToolUseBlock* = object
    id*: string
    name*: string
    input*: Table[string, JsonNode]

  ToolResultBlock* = object
    tool_use_id*: string
    content*: Option[string]  # Can be string, list, or null
    is_error*: Option[bool]

  ContentBlockKind* = enum
    cbkText, cbkToolUse, cbkToolResult

  ContentBlock* = object
    case kind*: ContentBlockKind
    of cbkText:
      textBlock*: TextBlock
    of cbkToolUse:
      toolUseBlock*: ToolUseBlock
    of cbkToolResult:
      toolResultBlock*: ToolResultBlock

# Message types
type
  UserMessage* = object
    content*: string  # Can be string or list[ContentBlock] - simplified for now

  AssistantMessage* = object
    content*: seq[ContentBlock]

  SystemMessage* = object
    subtype*: string
    data*: Table[string, JsonNode]

  ResultMessage* = object
    subtype*: string
    duration_ms*: int
    duration_api_ms*: int
    is_error*: bool
    num_turns*: int
    session_id*: string
    total_cost_usd*: Option[float]
    usage*: Option[Table[string, JsonNode]]
    result*: Option[string]

  MessageKind* = enum
    mkUser, mkAssistant, mkSystem, mkResult

  Message* = object
    case kind*: MessageKind
    of mkUser:
      userMessage*: UserMessage
    of mkAssistant:
      assistantMessage*: AssistantMessage
    of mkSystem:
      systemMessage*: SystemMessage
    of mkResult:
      resultMessage*: ResultMessage

# Claude Code Options
type
  ClaudeCodeOptions* = object
    allowed_tools*: seq[string]
    max_thinking_tokens*: int
    system_prompt*: Option[string]
    append_system_prompt*: Option[string]
    mcp_tools*: seq[string]
    mcp_servers*: Table[string, McpServerConfig]
    permission_mode*: Option[PermissionMode]
    continue_conversation*: bool
    resume*: Option[string]
    max_turns*: Option[int]
    disallowed_tools*: seq[string]
    model*: Option[string]
    permission_prompt_tool_name*: Option[string]
    cwd*: Option[string]
    settings*: Option[string]
    add_dirs*: seq[string]

# Default constructor for ClaudeCodeOptions
proc newClaudeCodeOptions*(): ClaudeCodeOptions =
  ## Create a new ClaudeCodeOptions with default values
  ClaudeCodeOptions(
    allowed_tools: @[],
    max_thinking_tokens: 8000,
    system_prompt: none(string),
    append_system_prompt: none(string),
    mcp_tools: @[],
    mcp_servers: initTable[string, McpServerConfig](),
    permission_mode: none(PermissionMode),
    continue_conversation: false,
    resume: none(string),
    max_turns: none(int),
    disallowed_tools: @[],
    model: none(string),
    permission_prompt_tool_name: none(string),
    cwd: none(string),
    settings: none(string),
    add_dirs: @[]
  )

# Convenience constructors for ContentBlock
proc newTextBlock*(text: string): ContentBlock =
  ContentBlock(kind: cbkText, textBlock: TextBlock(text: text))

proc newToolUseBlock*(id, name: string, input: Table[string, JsonNode]): ContentBlock =
  ContentBlock(kind: cbkToolUse, toolUseBlock: ToolUseBlock(id: id, name: name, input: input))

proc newToolResultBlock*(tool_use_id: string, content: Option[string] = none(string), is_error: Option[bool] = none(bool)): ContentBlock =
  ContentBlock(kind: cbkToolResult, toolResultBlock: ToolResultBlock(tool_use_id: tool_use_id, content: content, is_error: is_error))

# Convenience constructors for Message
proc newUserMessage*(content: string): Message =
  Message(kind: mkUser, userMessage: UserMessage(content: content))

proc newAssistantMessage*(content: seq[ContentBlock]): Message =
  Message(kind: mkAssistant, assistantMessage: AssistantMessage(content: content))

proc newSystemMessage*(subtype: string, data: Table[string, JsonNode]): Message =
  Message(kind: mkSystem, systemMessage: SystemMessage(subtype: subtype, data: data))

proc newResultMessage*(subtype: string, duration_ms, duration_api_ms: int, is_error: bool, num_turns: int, session_id: string): Message =
  Message(kind: mkResult, resultMessage: ResultMessage(
    subtype: subtype,
    duration_ms: duration_ms,
    duration_api_ms: duration_api_ms,
    is_error: is_error,
    num_turns: num_turns,
    session_id: session_id,
    total_cost_usd: none(float),
    usage: none(Table[string, JsonNode]),
    result: none(string)
  ))