## Query function for one-shot interactions with Claude Code
##
## This module provides the query function for simple, stateless queries
## where you don't need bidirectional communication or conversation management,
## ported from the Python version.

import std/[os, asyncdispatch]
import chronos
import ./types
import ./internal_client

proc query*(
  prompt: string,
  options: ClaudeCodeOptions = nil
): AsyncIterator[Message] {.async.} =
  ## Query Claude Code for one-shot or unidirectional streaming interactions
  ##
  ## This function is ideal for simple, stateless queries where you don't need
  ## bidirectional communication or conversation management. For interactive,
  ## stateful conversations, use ClaudeSDKClient instead.
  ##
  ## Key differences from ClaudeSDKClient:
  ## - **Unidirectional**: Send all messages upfront, receive all responses
  ## - **Stateless**: Each query is independent, no conversation state  
  ## - **Simple**: Fire-and-forget style, no connection management
  ## - **No interrupts**: Cannot interrupt or send follow-up messages
  ##
  ## When to use query():
  ## - Simple one-off questions ("What is 2+2?")
  ## - Batch processing of independent prompts
  ## - Code generation or analysis tasks
  ## - Automated scripts and CI/CD pipelines
  ## - When you know all inputs upfront
  ##
  ## When to use ClaudeSDKClient:
  ## - Interactive conversations with follow-ups
  ## - Chat applications or REPL-like interfaces
  ## - When you need to send messages based on responses
  ## - When you need interrupt capabilities
  ## - Long-running sessions with state
  ##
  ## Args:
  ##   prompt: The prompt to send to Claude
  ##   options: Optional configuration (defaults to ClaudeCodeOptions() if nil)
  ##            Set options.permission_mode to control tool execution:
  ##            - 'default': CLI prompts for dangerous tools
  ##            - 'acceptEdits': Auto-accept file edits  
  ##            - 'bypassPermissions': Allow all tools (use with caution)
  ##            Set options.cwd for working directory.
  ##
  ## Yields:
  ##   Messages from the conversation
  ##
  ## Example - Simple query:
  ##   # One-off question
  ##   for message in query("What is the capital of France?"):
  ##     echo message
  ##
  ## Example - With options:
  ##   # Code generation with specific settings
  ##   var opts = newClaudeCodeOptions()
  ##   opts.system_prompt = some("You are an expert Python developer")
  ##   opts.cwd = some("/home/user/project")
  ##   
  ##   for message in query("Create a Python web server", opts):
  ##     echo message
  let opts = if options != nil: options else: newClaudeCodeOptions()
  
  # Set environment variable for entrypoint identification
  putEnv("CLAUDE_CODE_ENTRYPOINT", "sdk-nim")
  
  let client = newInternalClient()
  
  var messageIter = client.processQuery(prompt = prompt, options = opts)
  while true:
    let (hasMessage, message) = await messageIter.next()
    if not hasMessage:
      break
    yield message