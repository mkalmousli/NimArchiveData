# SPDX-License-Identifier: MIT


# Imports.
import std/[
    asyncdispatch,
    os,
    options,
    strformat,
    strutils
]
import illwill, argparse

import mcsrvstatpkg/base


# Primary run() procedure for the hybrid package.
proc run*(): Future[void] {.async.} =

    # The primary command-line parser.
    var
        parser = newParser:
            help("A hybrid and asynchronous Nim wrapper for the Minecraft Server Status API.")
            flag("-b", "--bedrock", help="Flags the server as a Minecraft: Bedrock Edition server.")
            arg("address", help="The address of the Minecraft server.")
        server: Server

    try:
        let opts = parser.parse()
        server = Server(
            address: opts.address,
            platform: if opts.bedrock: Platform.BEDROCK else: Platform.JAVA
        )
        await server.refreshData()

    except ShortCircuit as err:
        if err.flag == "argparse_help":
            echo err.help
            quit(1)

    except UsageError:
        stderr.writeLine getCurrentExceptionMsg()
        quit(1)

    except ConnectionError:
        echo "Make sure you've passed the correct IP for the server."
        quit(1)

    # Initialize an instance of illwave and run the TUI if the code above succeeds.
    # This includes a cursor-less window, so an exit procedure is also required.
    proc exitProc() {.noconv.} =
        illwillDeinit()
        showCursor()
        quit(0)

    illwillInit(fullscreen=true)
    setControlCHook(exitProc)
    hideCursor()

    var
        tb = newTerminalBuffer(terminalWidth(), terminalHeight())
        yCoord = 14

    # The top panel for the terminal.
    tb.setForegroundColor(fgWhite, true)
    tb.write(2, 1, "[ Press ", fgYellow, "esc", fgWhite, "/", fgYellow, "q", fgWhite, " to quit. ]")
    tb.drawRect(0, 0, 40, 7)
    tb.drawHorizLine(2, 38, 2, doubleStyle=true)

    # Display the status, IP address and port of the server.
    tb.write(2, 4, "Online: ", (if server.isOnline: fgGreen else: fgRed), $server.isOnline, fgWhite)
    tb.write(2, 5, "IP: ", server.ip)
    tb.write(2, 6, "Port: ", $server.port)

    # Display basic information like versions and protocols.
    tb.write(2, 9, fmt"Version: {server.version}")
    if server.protocol.isSome:
        tb.write(2, 10, fmt"Protocol: {server.protocol.get()}")

    # Display the current player count of the server.
    tb.drawVertLine(40, 20, 2)
    if server.playerCount.isSome:
        tb.write(2, 12, fmt"Players online: {server.playerCount.get().online} / {server.playerCount.get().max}")

    # Display API-related information.
    for (name, value) in [
        ("Cache Time", server.debug.cachetime),
        ("Cache Expire", server.debug.cacheexpire),
        ("API Version", server.debug.apiversion)
    ]:
        tb.write(2, yCoord, fmt"{name}: ", fgCyan, $value, fgWhite)
        yCoord += 1

    # Display additional information like hostname, software and gamemodes.
    yCoord = 1

    for (name, value) in [
        ("Hostname", server.hostname), 
        ("Software", server.software), 
        ("Map", server.map), 
        ("[ B ] Gamemode", server.gamemode), 
        ("[ B ] ID", server.serverid)
    ]:
        if value.isSome:
            tb.write(45, yCoord, fmt"{name}: {value.get()}")
            yCoord += 1

    if (
        server.isEulaBlocked.isSome
    ):
        let eulaStat = server.isEulaBlocked.get()
        tb.write(45, yCoord, "[ J ] Server has ", (if eulaStat: "blocked" else: "unblocked"), " EULA.")
        yCoord += 1

    # Display the debug values associated with the server.
    for (name, value) in [
        ("ping", server.debug.ping),
        ("query", server.debug.query),
        ("srv", server.debug.srv),
        ("querymismatch", server.debug.querymismatch),
        ("ipinsrv", server.debug.ipinsrv),
        ("cnameinsrv", server.debug.cnameinsrv),
        ("animatedmotd", server.debug.animatedmotd),
        ("cachehit", server.debug.cachehit)
    ]:
        yCoord += 1
        tb.write(45, yCoord, fmt"{name}: ", (if value: fgGreen else: fgRed), $value, fgWhite)

    # Finally, display the entire thing.
    # This also includes checking for keypress events in order for the user to quit the interface.
    while true:
        tb.display()

        var key = getKey()
        case key
        of Key.Escape, Key.Q: exitProc()
        else: discard

        sleep(20)


# Run the program.
# Also handle some of the root exceptions as needed.
when isMainModule:
    try:
        waitFor run()

    except DataError:
        echo "Make sure you've passed the proper platform for the server."
        quit(1)

    except IOError:
        echo "Can't run mcsrvstat.nim since proper support for SSL couldn't be found."
        quit(1)