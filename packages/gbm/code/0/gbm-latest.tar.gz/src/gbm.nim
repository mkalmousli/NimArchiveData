import pkg/gbm/wrapper

export wrapper
