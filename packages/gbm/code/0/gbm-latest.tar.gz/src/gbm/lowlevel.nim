## low-level gbm bindings for Nim
## Copyright (C) 2025 Trayambak Rai
import std/strutils

const PackageName = "gbm"

{.passC: gorge("pkg-config --cflags " & PackageName).strip().}
{.passL: gorge("pkg-config --libs " & PackageName).strip().}

const
  GBM_BO_IMPORT_WL_BUFFER* = 0x5501
  GBM_BO_IMPORT_EGL_IMAGE* = 0x5502
  GBM_BO_IMPORT_FD* = 0x5503
  GBM_BO_IMPORT_FD_MODIFIER* = 0x5504
  GBM_MAX_PLANES* = 4

{.push header: "<gbm.h>".}
type
  gbm_device* {.importc: "struct gbm_device".} = object
  gbm_bo* {.importc: "struct gbm_bo".} = object
  gbm_surface* {.importc: "struct gbm_surface".} = object

  gbm_bo_handle* {.union, importc: "union gbm_bo_handle".} = object
    ## Abstraction representing the handle to a buffer allocated by the manager
    `ptr`*: pointer
    s32*: int32
    u32*: uint32
    s64*: int64
    u64*: uint64

  gbm_bo_format* {.importc: "enum gbm_bo_format".} = enum
    ## Format of the allocated buffer:
    ## - **GBM_BO_FORMAT_XRGB8888**: RGB with 8 bits per channel in a 32 bit value
    ## - **GBM_BO_FORMAT_ARGB8888**: ARGB with 8 bits per channel in a 32 bit value
    GBM_BO_FORMAT_XRGB8888
    GBM_BO_FORMAT_ARGB8888

  gbm_format_name_desc* {.importc: "struct gbm_format_name_desc".} = object
    name*: array[5, char]

  gbm_bo_flags* {.importc: "enum gbm_bo_flags", size: sizeof(uint32).} = enum
    GBM_BO_USE_SCANOUT = 1 shl 0
    GBM_BO_USE_CURSOR = 1 shl 1
    GBM_BO_USE_RENDERING = 1 shl 2
    GBM_BO_USE_WRITE = 1 shl 3
    GBM_BO_USE_LINEAR = 1 shl 4
    GBM_BO_USE_PROTECTED = 1 shl 5
    GBM_BO_USE_FRONT_RENDERING = 1 shl 6
    GBM_BO_USE_FIXED_COMPRESSION_DEFAULT = 1 shl 7
    GBM_BO_FIXED_COMPRESSION_1BPC = 2 shl 7
    GBM_BO_FIXED_COMPRESSION_2BPC = 3 shl 7
    GBM_BO_FIXED_COMPRESSION_3BPC = 4 shl 7
    GBM_BO_FIXED_COMPRESSION_4BPC = 5 shl 7
    GBM_BO_FIXED_COMPRESSION_5BPC = 6 shl 7
    GBM_BO_FIXED_COMPRESSION_6BPC = 7 shl 7
    GBM_BO_FIXED_COMPRESSION_7BPC = 8 shl 7
    GBM_BO_FIXED_COMPRESSION_8BPC = 9 shl 7
    GBM_BO_FIXED_COMPRESSION_9BPC = 10 shl 7
    GBM_BO_FIXED_COMPRESSION_10BPC = 11 shl 7
    GBM_BO_FIXED_COMPRESSION_11BPC = 12 shl 7
    GBM_BO_FIXED_COMPRESSION_12BPC = 13 shl 7

  gbm_import_fd_data* {.importc: "struct gbm_import_fd_data".} = object
    fd*: cint
    width*, height*, stride*, format*: uint32

  gbm_import_fd_modifier_state* {.importc: "struct gbm_import_fd_modifier_state".} = object
    width*, height*, format*, num_fds*: uint32
    fds*, strides*, offsets*: array[GbmMaxPlanes, cint]
    modifier*: uint64

  gbm_bo_transfer_flags* {.importc: "enum gbm_bo_transfer_flags".} = enum
    GBM_BO_TRANSFER_READ = 1 shl 0
    GBM_BO_TRANSFER_WRITE = 1 shl 1
    GBM_BO_TRANSFER_READ_WRITE = ((1 shl 0) or (1 shl 1))

proc gbm_device_get_fd*(gbm: ptr gbm_device): cint
proc gbm_device_get_backend_name*(gbm: ptr gbm_device): cstring
proc gbm_device_is_format_supported*(
  gbm: ptr gbm_device, format: uint32, flags: uint32
): bool

proc gbm_device_get_format_modifier_plane_count*(
  gbm: ptr gbm_device, format: uint32, modifier: uint64
): int32

proc gbm_device_destroy*(gbm: ptr gbm_device): void
proc gbm_create_device*(fd: cint): ptr gbm_device
proc gbm_bo_create*(
  gbm: ptr gbm_device, width, height: uint32, format: uint32, flags: uint32
): ptr gbm_bo

proc gbm_bo_create_with_modifiers*(
  gbm: ptr gbm_device,
  width, height: uint32,
  format: uint32,
  modifiers: ptr UncheckedArray[uint64],
  count: uint32,
): ptr gbm_bo

proc gbm_bo_create_with_modifiers2*(
  gbm: ptr gbm_device,
  width, height: uint32,
  format: uint32,
  modifiers: ptr UncheckedArray[uint64],
  count: uint32,
  flags: uint32,
): ptr gbm_bo

proc gbm_bo_import*(
  gbm: ptr gbm_device, typ: uint32, buffer: pointer, flags: uint32
): ptr gbm_bo

proc gbm_bo_map*(
  bo: ptr gbm_bo,
  x, y, width, height, flags: uint32,
  stride: ptr UncheckedArray[uint32],
  map_data: ptr pointer,
): pointer

proc gbm_bo_unmap*(bo: ptr gbm_bo, map_data: pointer): void
proc gbm_bo_get_width*(bo: ptr gbm_bo): uint32
proc gbm_bo_get_height*(bo: ptr gbm_bo): uint32
proc gbm_bo_get_stride*(bo: ptr gbm_bo): uint32
proc gbm_bo_get_stride_for_plane*(bo: ptr gbm_bo): uint32
proc gbm_bo_get_format*(bo: ptr gbm_bo): uint32
proc gbm_bo_get_bpp*(bo: ptr gbm_bo): uint32
proc gbm_bo_get_offset*(bo: ptr gbm_bo): uint32
proc gbm_bo_get_device*(bo: ptr gbm_bo): ptr gbm_device
proc gbm_bo_get_handle*(bo: ptr gbm_bo): gbm_bo_handle
proc gbm_bo_get_fd*(bo: ptr gbm_bo): cint
proc gbm_bo_get_modifier*(bo: ptr gbm_bo): uint64
proc gbm_bo_get_plane_count*(bo: ptr gbm_bo): int32
proc gbm_bo_get_handle_for_plane*(bo: ptr gbm_bo, plane: int32): gbm_bo_handle
proc gbm_bo_get_fd_for_plane*(bo: ptr gbm_bo, plane: int32): cint
proc gbm_bo_write*(bo: ptr gbm_bo, buf: pointer, count: uint64): int32
proc gbm_bo_set_user_data*(
  bo: ptr gbm_bo,
  data: pointer,
  destroy_user_data: proc(bo: gbm_bo, data: pointer): void {.cdecl.},
)

proc gbm_bo_get_user_data*(bo: ptr gbm_bo): pointer
proc gbm_bo_destroy*(bo: ptr gbm_bo): void
proc gbm_surface_create*(
  gbm: ptr gbm_device, width, height, format, flags: uint32
): ptr gbm_surface

proc gbm_surface_create_with_modifiers*(
  gbm: ptr gbm_device,
  width, height, format: uint32,
  modifiers: ptr UncheckedArray[uint64],
  count: uint32,
  flags: uint32,
): ptr gbm_surface

proc gbm_surface_lock_front_buffer*(surface: ptr gbm_surface): ptr gbm_bo
proc gbm_surface_release_buffer*(surface: ptr gbm_surface, bo: gbm_bo): void
proc gbm_surface_has_free_buffers*(surface: ptr gbm_surface): bool
proc gbm_surface_destroy*(surface: ptr gbm_surface): void
proc gbm_format_get_name*(gbm_format: uint32, desc: ptr gbm_format_name_desc): cstring

{.pop.}

func fourcc*(
    a: static char = ' ',
    b: static char = ' ',
    c: static char = ' ',
    d: static char = ' ',
): uint32 {.compileTime.} =
  ((uint32) a) or (((uint32) b) shl 8) or (((uint32) c) shl 16) or (((uint32) d) shl 24)

const
  GBM_FORMAT_BIG_ENDIAN* = uint32(1 shl 31)
  GBM_FORMAT_C8* = fourcc('C', '8')
  GBM_FORMAT_R8* = fourcc('R', '8')
  GBM_FORMAT_R16* = fourcc('R', '1', '6')
  GBM_FORMAT_GR88* = fourcc('G', 'R', '8', '8')
  GBM_FORMAT_RG1616* = fourcc('R', 'G', '3', '2')
  GBM_FORMAT_GR1616* = fourcc('G', 'R', '3', '2')

  GBM_FORMAT_RGB332* = fourcc('R', 'G', 'B', '8')
  GBM_FORMAT_BGR233* = fourcc('B', 'G', 'R', '8')

  GBM_FORMAT_XRGB4444* = fourcc('X', 'R', '1', '2')
  GBM_FORMAT_XBGR4444* = fourcc('X', 'B', '1', '2')
  GBM_FORMAT_RGBX4444* = fourcc('R', 'X', '1', '2')
  GBM_FORMAT_BGRX4444* = fourcc('B', 'X', '1', '2')

  GBM_FORMAT_ARGB4444* = fourcc('A', 'R', '1', '2')
  GBM_FORMAT_ABGR4444* = fourcc('A', 'B', '1', '2')
  GBM_FORMAT_RGBA4444* = fourcc('R', 'A', '1', '2')
  GBM_FORMAT_BGRA4444* = fourcc('B', 'A', '1', '2')

  GBM_FORMAT_XRGB1555* = fourcc('X', 'R', '1', '5')
  GBM_FORMAT_XBGR1555* = fourcc('X', 'B', '1', '5')
  GBM_FORMAT_RGBX5551* = fourcc('R', 'X', '1', '5')
  GBM_FORMAT_BGRX5551* = fourcc('B', 'X', '1', '5')

  GBM_FORMAT_ARGB1555* = fourcc('A', 'R', '1', '5')
  GBM_FORMAT_ABGR1555* = fourcc('A', 'B', '1', '5')
  GBM_FORMAT_RGBA5551* = fourcc('R', 'A', '1', '5')
  GBM_FORMAT_BGRA5551* = fourcc('B', 'A', '1', '5')

  GBM_FORMAT_RGB565* = fourcc('R', 'G', '1', '6')
  GBM_FORMAT_BGR565* = fourcc('B', 'G', '1', '6')

  GBM_FORMAT_RGB888* = fourcc('R', 'G', '2', '4')
  GBM_FORMAT_BGR888* = fourcc('B', 'G', '2', '4')

  GBM_FORMAT_XRGB8888* = fourcc('X', 'R', '2', '4')
  GBM_FORMAT_XBGR8888* = fourcc('X', 'B', '2', '4')
  GBM_FORMAT_RGBX8888* = fourcc('R', 'X', '2', '4')
  GBM_FORMAT_BGRX8888* = fourcc('B', 'X', '2', '4')

  GBM_FORMAT_ARGB8888* = fourcc('A', 'R', '2', '4')
  GBM_FORMAT_ABGR8888* = fourcc('A', 'B', '2', '4')
  GBM_FORMAT_RGBA8888* = fourcc('R', 'A', '2', '4')
  GBM_FORMAT_BGRA8888* = fourcc('B', 'A', '2', '4')

  GBM_FORMAT_XRGB2101010* = fourcc('X', 'R', '3', '0')
  GBM_FORMAT_XBGR2101010* = fourcc('X', 'B', '3', '0')
  GBM_FORMAT_RGBX1010102* = fourcc('R', 'X', '3', '0')
  GBM_FORMAT_BGRX1010102* = fourcc('B', 'X', '3', '0')

  GBM_FORMAT_ARGB2101010* = fourcc('A', 'R', '3', '0')
  GBM_FORMAT_ABGR2101010* = fourcc('A', 'B', '3', '0')
  GBM_FORMAT_RGBA1010102* = fourcc('R', 'A', '3', '0')
  GBM_FORMAT_BGRA1010102* = fourcc('B', 'A', '3', '0')

  GBM_FORMAT_XBGR16161616* = fourcc('X', 'B', '4', '8')

  GBM_FORMAT_ABGR16161616* = fourcc('A', 'B', '4', '8')

  GBM_FORMAT_XBGR16161616F* = fourcc('X', 'B', '4', 'H')

  GBM_FORMAT_ABGR16161616F* = fourcc('A', 'B', '4', 'H')

  GBM_FORMAT_YUYV* = fourcc('Y', 'U', 'Y', 'V')
  GBM_FORMAT_YVYU* = fourcc('Y', 'V', 'Y', 'U')
  GBM_FORMAT_UYVY* = fourcc('U', 'Y', 'V', 'Y')
  GBM_FORMAT_VYUY* = fourcc('V', 'Y', 'U', 'Y')

  GBM_FORMAT_AYUV* = fourcc('A', 'Y', 'U', 'V')

  GBM_FORMAT_NV12* = fourcc('N', 'V', '1', '2')
  GBM_FORMAT_NV21* = fourcc('N', 'V', '2', '1')
  GBM_FORMAT_NV16* = fourcc('N', 'V', '1', '6')
  GBM_FORMAT_NV61* = fourcc('N', 'V', '6', '1')

  GBM_FORMAT_YUV410* = fourcc('Y', 'U', 'V', '9')
  GBM_FORMAT_YVU410* = fourcc('Y', 'V', 'U', '9')
  GBM_FORMAT_YUV411* = fourcc('Y', 'U', '1', '1')
  GBM_FORMAT_YVU411* = fourcc('Y', 'V', '1', '1')
  GBM_FORMAT_YUV420* = fourcc('Y', 'U', '1', '2')
  GBM_FORMAT_YVU420* = fourcc('Y', 'V', '1', '2')
  GBM_FORMAT_YUV422* = fourcc('Y', 'U', '1', '6')
  GBM_FORMAT_YVU422* = fourcc('Y', 'V', '1', '6')
  GBM_FORMAT_YUV444* = fourcc('Y', 'U', '2', '4')
  GBM_FORMAT_YVU444* = fourcc('Y', 'V', '2', '4')
