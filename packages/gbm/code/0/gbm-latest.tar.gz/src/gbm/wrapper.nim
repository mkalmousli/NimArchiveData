## high-level gbm wrapper for Nim
## Copyright (C) 2025 Trayambak Rai
import std/posix
import pkg/gbm/lowlevel

proc errmsg: string {.inline.} =
  ## Used internally as a shorthand to quickly get the POSIX error message.
  $strerror(errno)

type
  GBMError* = object of CatchableError
    ## A base exception for all errors emitted by this library.

  CannotOpenDevice* = object of GBMError
    ## Raised when a device's file descriptor is -1 (not openable)

  CannotInitDevice* = object of GBMError
    ## Raised when a device cannot be initialized by the GBM implementation.

  CannotAllocateBuffer* = object of GBMError
    ## Raised when the GBM device fails to allocate a requested buffer of GPU memory.

  BufferWriteFailure* = object of GBMError
    ## Raised when the GBM device fails to write a segment of data to a GPU buffer, 
    ## as requested by the caller.
  
  Device* = object
    ## A rendering device. This is the representation of a graphics processing unit attached to your system.
    gbm: ptr gbm_device
    path: string

  BufferObjectFormat* {.pure.} = enum
    ## Format of the allocated buffer.
    ## - **XRGB8888**: RGB with 8 bits per channel in a 32 bit value
    ## - **ARGB8888**: ARGB with 8 bits per channel in a 32 bit value
    XRGB8888 = GBM_BO_FORMAT_XRGB8888
    ARGB8888 = GBM_BO_FORMAT_ARGB8888

  BufferFlags* {.pure.} = enum
    ## Flags to indicate the intended use for the buffer. The caller must provide a set of these to any functions
    ## dealing with buffer allocation.
    UseScanout = GBM_BO_USE_SCANOUT
    UseCursor = GBM_BO_USE_CURSOR
    UseRendering = GBM_BO_USE_RENDERING
    UseWrite = GBM_BO_USE_WRITE
    UseLinear = GBM_BO_USE_LINEAR
    UseProtected = GBM_BO_USE_PROTECTED
    UseFrontRendering = GBM_BO_USE_FRONT_RENDERING
    FixedCompressionDefault = GBM_BO_USE_FIXED_COMPRESSION_DEFAULT
    FixedCompression1BPC = GBM_BO_FIXED_COMPRESSION_1BPC
    FixedCompression2BPC = GBM_BO_FIXED_COMPRESSION_2BPC
    FixedCompression3BPC = GBM_BO_FIXED_COMPRESSION_3BPC
    FixedCompression4BPC = GBM_BO_FIXED_COMPRESSION_4BPC
    FixedCompression5BPC = GBM_BO_FIXED_COMPRESSION_5BPC
    FixedCompression6BPC = GBM_BO_FIXED_COMPRESSION_6BPC
    FixedCompression7BPC = GBM_BO_FIXED_COMPRESSION_7BPC
    FixedCompression8BPC = GBM_BO_FIXED_COMPRESSION_8BPC
    FixedCompression9BPC = GBM_BO_FIXED_COMPRESSION_9BPC
    FixedCompression10BPC = GBM_BO_FIXED_COMPRESSION_10BPC
    FixedCompression11BPC = GBM_BO_FIXED_COMPRESSION_11BPC
    FixedCompression12BPC = GBM_BO_FIXED_COMPRESSION_12BPC

  GBMFormat* {.pure.} = enum
    ## All of the FourCC formats that GBM supports. This is the same as the DRM list.
    ## New GBM formats must not be added, unless they are identical ports from drm_fourcc.
    BigEndian = GBM_FORMAT_BIG_ENDIAN
    C8 = GBM_FORMAT_C8
    R8 = GBM_FORMAT_R8
    R16 = GBM_FORMAT_R16
    GR88 = GBM_FORMAT_GR88
    RG1616 = GBM_FORMAT_RG1616
    GR1616 = GBM_FORMAT_GR1616
    RGB332 = GBM_FORMAT_RGB332
    BGR233 = GBM_FORMAT_BGR233
    XRGB4444 = GBM_FORMAT_XRGB4444
    XBGR4444 = GBM_FORMAT_XBGR4444
    RGBX4444 = GBM_FORMAT_RGBX4444
    BGRX4444 = GBM_FORMAT_BGRX4444
    ARGB4444 = GBM_FORMAT_ARGB4444
    ABGR4444 = GBM_FORMAT_ABGR4444
    RGBA4444 = GBM_FORMAT_RGBA4444
    BGRA4444 = GBM_FORMAT_BGRA4444
    XRGB1555 = GBM_FORMAT_XRGB1555
    XBGR1555 = GBM_FORMAT_XBGR1555
    RGBX5551 = GBM_FORMAT_RGBX5551
    BGRX5551 = GBM_FORMAT_BGRX5551
    ARGB1555 = GBM_FORMAT_ARGB1555
    ABGR1555 = GBM_FORMAT_ABGR1555
    RGBA5551 = GBM_FORMAT_RGBA5551
    BGRA5551 = GBM_FORMAT_BGRA5551
    RGB565 = GBM_FORMAT_RGB565
    BGR565 = GBM_FORMAT_BGR565
    XRGB8888 = GBM_FORMAT_XRGB8888
    XBGR8888 = GBM_FORMAT_XBGR8888
    RGBX8888 = GBM_FORMAT_RGBX8888
    BGRX8888 = GBM_FORMAT_BGRX8888
    ARGB8888 = GBM_FORMAT_ARGB8888
    ABGR8888 = GBM_FORMAT_ABGR8888
    RGBA8888 = GBM_FORMAT_RGBA8888
    BGRA8888 = GBM_FORMAT_BGRA8888
    XRGB2101010 = GBM_FORMAT_XRGB2101010
    XBGR2101010 = GBM_FORMAT_XBGR2101010
    RGBX1010102 = GBM_FORMAT_RGBX1010102
    BGRX1010102 = GBM_FORMAT_BGRX1010102
    ARGB2101010 = GBM_FORMAT_ARGB2101010
    ABGR2101010 = GBM_FORMAT_ABGR2101010
    RGBA1010102 = GBM_FORMAT_RGBA1010102
    BGRA1010102 = GBM_FORMAT_BGRA1010102
    XBGR16161616 = GBM_FORMAT_XBGR16161616
    ABGR16161616 = GBM_FORMAT_ABGR16161616
    XBGR16161616F = GBM_FORMAT_XBGR16161616F
    ABGR16161616F = GBM_FORMAT_ABGR16161616F
    YUYV = GBM_FORMAT_YUYV
    YVYU = GBM_FORMAT_YVYU
    UYVY = GBM_FORMAT_UYVY
    VYUY = GBM_FORMAT_VYUY
    AYUV = GBM_FORMAT_AYUV
    NV12 = GBM_FORMAT_NV12
    NV21 = GBM_FORMAT_NV21
    NV16 = GBM_FORMAT_NV16
    NV61 = GBM_FORMAT_NV61
    YUV410 = GBM_FORMAT_YUV410
    YVU410 = GBM_FORMAT_YVU410
    YUV411 = GBM_FORMAT_YUV411
    YVU411 = GBM_FORMAT_YVU411
    YUV420 = GBM_FORMAT_YUV420
    YVU420 = GBM_FORMAT_YVU420
    YUV422 = GBM_FORMAT_YUV422
    YVU422 = GBM_FORMAT_YVU422
    YUV444 = GBM_FORMAT_YUV444
    YVU444 = GBM_FORMAT_YVU444

  BufferObject* = object
    ## A buffer of GPU memory.
    bo: ptr gbm_bo

template sanityCheck(value: BufferObject | Device) =
  ## This is an internal template to ensure that all of the wrapper functions don't
  ## accidentally perform a use-after-free or nil pointer dereference. You needn't worry about it.
  when not defined(release):
    when value is BufferObject:
      assert(value.bo != nil, "GUARD: BufferObject's internal `gbm_bo` was a nil pointer.")
    
    when value is Device:
      assert(value.gbm != nil, "GUARD: Device's internal `gbm_device` was a nil pointer.")

proc `=destroy`*(dev: Device) =
  sanityCheck(dev)
  gbm_device_destroy(dev.gbm)

proc `=destroy`*(buff: BufferObject) =
  sanityCheck(buff)
  gbm_bo_destroy(buff.bo)

func width*(buff: BufferObject): uint32 {.inline.} =
  ## Get the width of this buffer object.
  sanityCheck(buff)
  gbm_bo_get_width(buff.bo)

func height*(buff: BufferObject): uint32 {.inline.} =
  ## Get the height of this buffer object.
  sanityCheck(buff)
  gbm_bo_get_height(buff.bo)

func format*(buff: BufferObject): uint32 {.inline.} =
  ## Get the format that this buffer object is designated to use.
  sanityCheck(buff)
  gbm_bo_get_format(buff.bo)

func getFd*(buff: BufferObject): cint {.inline.} =
  ## Get the file descriptor assigned to this buffer object.
  sanityCheck(buff)
  gbm_bo_get_fd(buff.bo)

func planeCount*(buff: BufferObject): int32 {.inline.} =
  ## Get the number of planes this buffer object has.
  sanityCheck(buff)
  gbm_bo_get_plane_count(buff.bo)

func getFdForPlane*(buff: BufferObject, plane: int32): cint =
  ## Get the file descriptor for a particular plane.
  sanityCheck(buff)
  when not defined(release):
    if plane >= buff.planeCount:
      raise newException(ValueError, "Cannot get plane #" & $(plane+1) & "'s file descriptor as plane count is " & $buff.planeCount)

  gbm_bo_get_fd_for_plane(buff.bo, plane)

func getDevice*(buff: BufferObject): ptr gbm_device {.inline.} =
  ## Get the underlying internal GBM object that allocated this buffer.
  sanityCheck(buff)
  gbm_bo_get_device(buff.bo)

func getHandle*(dev: Device): ptr gbm_device {.inline.} =
  ## Get the raw handle that libgbm has provided us. Only use this if you know what you are doing
  ## and a wrapper function does not fulfill your requirements.
  sanityCheck(dev)
  dev.gbm

func path*(dev: Device): string {.inline.} =
  ## Get the path to this rendering device, if it exists.
  sanityCheck(dev)
  dev.path

func getFd*(dev: Device): cint {.inline.} =
  ## Get the file descriptor of this rendering device.
  sanityCheck(dev)
  gbm_device_get_fd(dev.gbm)

func backend*(dev: Device): string {.inline.} =
  ## Return the GBM backend that has been used to create this rendering device.
  sanityCheck(dev)
  $gbm_device_get_backend_name(dev.gbm)

proc openDevice*(deviceFd: cint, path: string = ""): Device {.raises: [CannotInitDevice].} =
  ## Open a GBM device by supplying its file descriptor.
  ##
  ## This function raises `CannotInitDevice` upon failure.
  var gbm = gbm_create_device(deviceFd)
  if gbm == nil:
    raise newException(CannotInitDevice, "Failed to create GBM device: " & errmsg())

  Device(
    gbm: gbm,
    path: path
  )

proc openDevice*(path: string): Device {.raises: [CannotOpenDevice, CannotInitDevice].} =
  ## Open a GBM device by supplying its file path.
  ##
  ## This function raises either of `CannotOpenDevice` or `CannotInitDevice` upon failure.
  ## They can be caught at once using the blanket `GBMError` exception.
  let deviceFd = open(path, O_RDWR or O_CLOEXEC)
  if deviceFd < 0:
    raise newException(CannotOpenDevice, "Failed to open GBM device `" & path & "`: " & errmsg())

  openDevice(deviceFd, path = path)

proc allocateBuffer*(
  device: var Device,
  width, height: SomeUnsignedInt,
  format: BufferObjectFormat = BufferObjectFormat.XRGB8888,
  flags: set[BufferFlags] = {}
): BufferObject {.raises: [CannotAllocateBuffer].} =
  ## Allocate a GPU buffer of width `width` and height `height`, 
  ## with the format `format` (`XRGB8888` by default) with a set of flags that you can specify (see `BufferFlags`).
  sanityCheck(device)
  var bFlags: uint32
  
  for flag in flags:
    bFlags = bFlags or ((uint32) flag)

  var bo = gbm_bo_create(device.gbm, uint32(width), uint32(height), (uint32) format, bFlags)
  if bo == nil:
    raise newException(CannotAllocateBuffer, "Failed to allocate GPU buffer: " & errmsg())

  BufferObject(bo: bo)

proc write*[T = uint8](buff: var BufferObject, data: seq[T]) {.raises: [BufferWriteFailure].} =
  ## Write `data` into the GPU buffer.
  ##
  ## This function raises `BufferWriteFailure` on failure and `ValueError` if the `data` vector is invalid.
  sanityCheck(buff)

  if data.len < 1:
    raise newException(ValueError, "Invalid data vector - the container is empty.")
  
  if gbm_bo_write(buff.bo, data[0].addr, data.len * sizeof(T)) != 0:
    raise newException(BufferWriteFailure, "Failed to write data into GPU buffer: " & errmsg())
