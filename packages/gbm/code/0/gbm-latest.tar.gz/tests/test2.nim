import std/posix
import gbm/wrapper

proc main() {.inline.} =
  var device = openDevice("/dev/dri/card1")
  echo "using gpu: " & device.path
  echo "backend: " & device.backend

  echo "allocating 1920x1080 buffer"
  var buffer = device.allocateBuffer(
    1920,
    1080,
    BufferObjectFormat.XRGB8888,
    {BufferFlags.UseScanout, BufferFlags.UseRendering},
  )
  echo "buffer format: " & $buffer.format
  echo "buffer fd: " & $buffer.getFd
  echo "plane count: " & $buffer.planeCount

  for p in 0 ..< buffer.planeCount:
    echo "plane fd: " & $buffer.getFdForPlane(p)

when isMainModule:
  main()
