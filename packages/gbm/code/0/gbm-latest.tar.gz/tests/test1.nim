import std/posix
import gbm/lowlevel

proc main() {.inline.} =
  var drmFd: cint
  var
    gbm: ptr gbm_device
    bo: ptr gbm_bo

  drmFd = open("/dev/dri/card1", O_RDWR or O_CLOEXEC)
  if drmFd < 0:
    echo strerror(errno)
    quit "Can't open DRM device"

  gbm = gbm_create_device(drmFd)
  if gbm == nil:
    echo strerror(errno)
    discard close(drmFd)
    quit "Can't create GBM device"

  bo = gbm_bo_create(
    gbm,
    1920,
    1080,
    GBM_FORMAT_XRGB8888,
    ((uint32) GBM_BO_USE_SCANOUT) or ((uint32) GBM_BO_USE_RENDERING),
  )
  if bo == nil:
    echo strerror(errno)
    discard close(drmFd)
    gbm_device_destroy(gbm)
    quit "Can't create GBM buffer object"

  echo "workie!!! :D"

  gbm_bo_destroy(bo)
  gbm_device_destroy(gbm)
  discard close(drmFd)

  quit(0)

when isMainModule:
  main()
