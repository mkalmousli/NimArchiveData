# Package

version = "0.1.0"
author = "xTrayambak"
description = "Nim bindings to Mesa's Generic Buffer Management API"
license = "MIT"
srcDir = "src"

# Dependencies

requires "nim >= 2.2.0"
