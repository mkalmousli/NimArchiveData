# Package

version       = "0.1.2"
author        = "Monsler"
description   = "gpt4free work-in-progress nim implementation"
license       = "MIT"
srcDir        = "src"


# Dependencies

requires "nim >= 2.2.8"
