# Package

version       = "0.1.0"
author        = "YuryKL"
description   = "A Nim SDK for https://data-star.dev"
license       = "MIT"
srcDir        = "src"

# Dependencies

requires "nim >= 2.2.6"

# Tasks

task test, "Run golden tests":
  exec "nim c -r test/test_golden.nim"

task counter, "Run example - counter":
  exec "nim c -r examples/counter.nim"

task testserver, "Run SDK test server on port 7331":
  exec "nim c -r test/server.nim"
