## Datastar SDK adapter for std/asynchttpserver.
##
## Example:
## ```nim
## import std/asynchttpserver
## import datastar
## import datastar/asynchttpserver as datastarAsync
##
## proc handler(req: Request) {.async.} =
##   let sse = await req.newSSEGenerator()
##   await sse.patchElements("<div id=\"foo\">Hello</div>")
## ```

import std/[asyncdispatch, asyncnet, strformat]
import std/asynchttpserver
import ../datastar

export HttpCode

proc buildHeaders(code: HttpCode): string =
  result = fmt"HTTP/1.1 {code.int} {code}" & "\r\n" &
           "Content-Type: " & SseContentType & "\r\n" &
           "Cache-Control: " & SseCacheControl & "\r\n" &
           "Connection: " & SseConnection & "\r\n\r\n"

proc newSSEGenerator*(req: Request, code = Http200): Future[ServerSentEventGenerator] {.async.} =
  ## Creates a ServerSentEventGenerator for an asynchttpserver Request.
  ##
  ## Parameters:
  ## - `req`: The asynchttpserver Request.
  ## - `code`: HTTP status code (default: 200 OK).
  ##
  ## Example:
  ## ```nim
  ## let sse = await req.newSSEGenerator()
  ## await sse.patchElements("<div id=\"hello\">Hello</div>")
  ## ```
  await req.client.send(buildHeaders(code))

  let sendProc: SendProc = proc(data: string): Future[void] {.async.} =
    await req.client.send(data)

  result = newSSEGenerator(sendProc)

proc closeSSE*(req: Request) =
  ## Close the SSE connection. Call after sending all events.
  req.client.close()
