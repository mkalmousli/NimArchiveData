## Datastar SDK adapter for Prologue framework.
## ( Implemented for the fork at github.com/YuryKL/prologue which adds SSE and Streaming Brotli Compression ) 
##
## Example:
## ```nim
## import prologue
## import datastar
## import datastar/prologue as datastarPrologue
##
## proc handler(ctx: Context) {.async.} =
##   let sse = await ctx.newSSEGenerator()
##   await sse.patchElements("<div id=\"foo\">Hello</div>")
## ```

import std/[asyncdispatch, options, strformat]
import ../datastar
import ../prologue/core/context
import ../prologue/core/httpcore/httplogue

# Optional brotli compression support
when (compiles do: import ../prologue/compression/brotli):
  import ../prologue/compression/brotli
  const hasBrotli* = true
else:
  const hasBrotli* = false

type
  BrotliConfig* = object
    ## Configuration for Brotli compression.
    quality*: int  ## 0-11, lower = faster, higher = smaller. Default 4.
    lgwin*: int    ## Log2 window size (10-24). Default 18 = 256KB.

proc brotli*(quality = 4, lgwin = 18): BrotliConfig =
  ## Creates Brotli compression config with optional tuning.
  BrotliConfig(quality: quality, lgwin: lgwin)

proc buildHeaders(code: HttpCode, compressed: bool): string =
  result = fmt"HTTP/1.1 {code.int} {code}" & "\r\n" &
           "Content-Type: " & SseContentType & "\r\n" &
           "Cache-Control: " & SseCacheControl & "\r\n" &
           "Connection: " & SseConnection & "\r\n"
  if compressed:
    result.add "Content-Encoding: br\r\n"
  result.add "\r\n"

proc newSSEGenerator*(ctx: Context, code = Http200,
                      compression = none(BrotliConfig)): Future[ServerSentEventGenerator] {.async.} =
  ## Creates a ServerSentEventGenerator for a Prologue Context.
  ##
  ## Parameters:
  ## - `ctx`: The Prologue context for the connection.
  ## - `code`: HTTP status code (default: 200 OK).
  ## - `compression`: Optional Brotli compression config.
  ##
  ## Example:
  ## ```nim
  ## # Default (200 OK, no compression)
  ## let sse = await ctx.newSSEGenerator()
  ##
  ## # Custom status code
  ## let sse = await ctx.newSSEGenerator(code = Http201)
  ##
  ## # With Brotli compression
  ## let sse = await ctx.newSSEGenerator(compression = some(brotli()))
  ## ```
  var sendProc: SendProc

  if compression.isSome:
    when hasBrotli:
      let cfg = compression.get()
      await ctx.send(buildHeaders(code, compressed = true))
      ctx.handled = true
      let stream = await initBrotliStream(ctx, quality = cfg.quality, lgwin = cfg.lgwin)
      sendProc = proc(data: string): Future[void] {.async.} =
        await stream.send(data)
    else:
      raise newException(ValueError,
        "Brotli compression requested but 'brotli' package is not installed. " &
        "Install with: nimble install brotli")
  else:
    await ctx.send(buildHeaders(code, compressed = false))
    ctx.handled = true
    sendProc = proc(data: string): Future[void] {.async.} =
      await ctx.send(data)

  result = newSSEGenerator(sendProc)
