## Datastar SDK adapter for Prologue framework.
##
## Example:
## ```nim
## import prologue
## import datastar
## import datastar/prologue as datastarPrologue
##
## proc handler(ctx: Context) {.async.} =
##   let sse = await ctx.newSSEGenerator(); defer: ctx.request.close()
##   await sse.patchElements("<div id=\"foo\">Hello</div>")
## ```

import std/[asyncdispatch, strformat]
import ../datastar
import prologue/core/context
import prologue/core/request
import prologue/core/httpcore/httplogue

func buildHeaders(code: HttpCode): string =
  result = fmt"HTTP/1.1 {code.int} {code}" & "\r\n" &
           "Content-Type: " & SseContentType & "\r\n" &
           "Cache-Control: " & SseCacheControl & "\r\n" &
           "Connection: " & SseConnection & "\r\n" & "\r\n"

proc newSSEGenerator*(ctx: Context, code = Http200): Future[ServerSentEventGenerator] {.async.} =
  ## Creates a ServerSentEventGenerator for a Prologue Context.
  ##
  ## Parameters:
  ## - `ctx`: The Prologue context for the connection.
  ## - `code`: HTTP status code (default: 200 OK).
  ##
  ## Example:
  ## ```nim
  ## # Default (200 OK)
  ## let sse = await ctx.newSSEGenerator()
  ##
  ## # Custom status code
  ## let sse = await ctx.newSSEGenerator(code = Http201)
  ##
  var sendProc: SendProc
  await ctx.send(buildHeaders(code))
  ctx.handled = true
  sendProc = proc(data: string): Future[void] {.async.} =
    await ctx.send(data)
  result = newSSEGenerator(sendProc)


proc closeSSE*(ctx: Context) =
  ctx.request.close()
