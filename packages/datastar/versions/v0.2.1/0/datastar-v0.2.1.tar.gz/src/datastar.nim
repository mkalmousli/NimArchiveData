import std/[asyncdispatch, json, strutils, uri, tables]

const
  DefaultRetryDuration* = 1000
  SseContentType* = "text/event-stream"
  SseCacheControl* = "no-cache"
  SseConnection* = "keep-alive"

type
  EventType* = enum
    PatchElements = "datastar-patch-elements"
    PatchSignals = "datastar-patch-signals"

  ElementPatchMode* = enum
    Outer = "outer"
    Inner = "inner"
    Replace = "replace"
    Prepend = "prepend"
    Append = "append"
    Before = "before"
    After = "after"
    Remove = "remove"

  SendProc* = proc(data: string): Future[void] {.closure, gcsafe.}

  ServerSentEventGenerator* = ref object
    sendRaw*: SendProc

proc newSSEGenerator*(sendProc: SendProc): ServerSentEventGenerator =
  ServerSentEventGenerator(sendRaw: sendProc)


proc send(sse: ServerSentEventGenerator, eventType: EventType,
          dataLines: seq[string], eventId = "",
          retryDuration = 0) {.async.} =
  var msg = "event: " & $eventType & "\n"
  if eventId.len > 0:
    msg.add("id: " & eventId & "\n")
  if retryDuration > 0:
    msg.add("retry: " & $retryDuration & "\n")
  for line in dataLines:
    msg.add("data: " & line & "\n")
  msg.add("\n")
  await sse.sendRaw(msg)

proc patchElements*(sse: ServerSentEventGenerator, elements: string,
                    selector = "", mode = Outer,
                    useViewTransition = false,
                    eventId = "", retryDuration = 0) {.async.} =
  ## Patch elements in the DOM
  var lines: seq[string]

  if mode == Remove and elements.len == 0:
    # Special ordering for remove mode without elements
    if useViewTransition:
      # With useViewTransition: selector, mode, useViewTransition
      lines.add("selector " & selector)
      lines.add("mode " & $mode)
      lines.add("useViewTransition true")
    else:
      # Without useViewTransition: mode, selector
      lines.add("mode " & $mode)
      lines.add("selector " & selector)
  else:
    # Standard ordering: selector, mode, useViewTransition, elements
    if selector.len > 0:
      lines.add("selector " & selector)
    if mode != Outer:
      lines.add("mode " & $mode)
    if useViewTransition:
      lines.add("useViewTransition true")
    # Split multiline elements into separate data lines
    for elementLine in elements.split('\n'):
      lines.add("elements " & elementLine)

  await sse.send(PatchElements, lines, eventId, retryDuration)

proc removeElements*(sse: ServerSentEventGenerator, selector: string,
                     useViewTransition = false,
                     eventId = "", retryDuration = 0) {.async.} =
  ## Remove elements matching the selector (uses patchElements with mode=remove)
  await sse.patchElements("", selector, Remove, useViewTransition, eventId, retryDuration)

proc patchSignals*(sse: ServerSentEventGenerator, signals: JsonNode,
                   onlyIfMissing = false,
                   eventId = "", retryDuration = 0) {.async.} =
  ## Patch signals (merge into existing signals)
  var lines: seq[string]
  if onlyIfMissing:
    lines.add("onlyIfMissing true")
  # Convert to compact JSON (no newlines)
  let signalStr = $signals
  for signalLine in signalStr.split('\n'):
    lines.add("signals " & signalLine)
  await sse.send(PatchSignals, lines, eventId, retryDuration)

proc patchSignals*(sse: ServerSentEventGenerator, signals: string,
                   onlyIfMissing = false,
                   eventId = "", retryDuration = 0) {.async.} =
  ## Patch signals from a JSON string
  var lines: seq[string]
  if onlyIfMissing:
    lines.add("onlyIfMissing true")
  # Split multiline signals into separate data lines
  for signalLine in signals.split('\n'):
    lines.add("signals " & signalLine)
  await sse.send(PatchSignals, lines, eventId, retryDuration)

proc removeSignals*(sse: ServerSentEventGenerator, paths: seq[string],
                    eventId = "", retryDuration = 0) {.async.} =
  ## Remove signals at the given paths (uses patchSignals with null values)
  var signals = newJObject()
  for path in paths:
    signals[path] = newJNull()
  await sse.patchSignals(signals, eventId = eventId, retryDuration = retryDuration)

proc executeScript*(sse: ServerSentEventGenerator, script: string,
                    autoRemove = true, attributes = initTable[string, string](),
                    eventId = "", retryDuration = 0) {.async.} =
  ## Execute a script by generating a <script> tag and using patchElements
  ## Order for executeScript: mode, selector, elements
  var scriptTag = "<script"
  for key, val in attributes:
    scriptTag.add " " & key & "=\"" & val & "\""
  if autoRemove:
    scriptTag.add " data-effect=\"el.remove()\""
  scriptTag.add ">" & script & "</script>"

  # executeScript always uses mode=append, selector=body with specific order
  var lines: seq[string]
  lines.add("mode " & $Append)
  lines.add("selector body")
  for elementLine in scriptTag.split('\n'):
    lines.add("elements " & elementLine)
  await sse.send(PatchElements, lines, eventId, retryDuration)

# Helper to extract datastar param from query string
proc extractDatastarParam(query: string): string =
  ## Extract and decode the 'datastar' parameter from a query string
  ## Handles: "datastar={...}" or "foo=bar&datastar={...}&baz=qux"
  const prefix = "datastar="
  var start = query.find(prefix)
  if start == -1:
    # No datastar param - return empty JSON object
    return "{}"
  start += prefix.len
  var stop = query.find('&', start)
  if stop == -1:
    stop = query.len
  result = decodeUrl(query[start..<stop])

# Dynamic API - returns JsonNode
proc readSignals*(query: string): JsonNode =
  ## Read signals from GET query string (extracts 'datastar' parameter)
  result = parseJson(extractDatastarParam(query))

proc readSignalsFromBody*(body: string): JsonNode =
  ## Read signals from POST/PUT/etc request body (raw JSON)
  result = parseJson(body)

# Static/Typed API - returns T
proc readSignals*[T](query: string, _: typedesc[T]): T =
  ## Read signals from GET query string into typed struct
  result = parseJson(extractDatastarParam(query)).to(T)

proc readSignalsFromBody*[T](body: string, _: typedesc[T]): T =
  ## Read signals from POST/PUT/etc body into typed struct
  result = parseJson(body).to(T)

# Escape hatch: bring your own deserializer
type Deserializer*[T] = proc(json: string): T

proc readSignals*[T](query: string, deserialize: Deserializer[T]): T =
  ## Read signals from GET query with custom deserializer
  result = deserialize(extractDatastarParam(query))

proc readSignalsFromBody*[T](body: string, deserialize: Deserializer[T]): T =
  ## Read signals from body with custom deserializer
  result = deserialize(body)
