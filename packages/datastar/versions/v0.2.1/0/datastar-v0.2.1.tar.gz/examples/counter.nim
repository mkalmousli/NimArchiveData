## Counter Example
##
## Run with: nim c -r examples/counter.nim
## Then open http://localhost:8080 in your browser

import std/[asyncdispatch, asynchttpserver, json]
import ../src/datastar
import ../src/datastar/asynchttpserver as DATASTAR

proc handleSignal() {.noconv.} =
  echo "\nShutting down..."
  quit(0)

setControlCHook(handleSignal)

# Server-side state
var count = 0

const indexHtml = """
<!DOCTYPE html>
<html>
<head>
  <title>Datastar Counter Example</title>
  <script type="module" src="https://cdn.jsdelivr.net/gh/starfederation/datastar@1.0.0-RC.7/bundles/datastar.js"></script>
  <style>
    body { font-family: system-ui; max-width: 600px; margin: 2rem auto; padding: 0 1rem; }
    button { padding: 0.5rem 1rem; margin: 0.25rem; cursor: pointer; }
    #count { font-size: 2rem; margin: 1rem 0; }
  </style>
</head>
<body>
  <h1>Datastar Counter</h1>
  <div data-signals:count=0>
    <div id="count">Count: <span data-text="$count">0</span></div>
    <button data-on:click="@get('/increment')">Increment</button>
    <button data-on:click="@get('/decrement')">Decrement</button>
    <button data-on:click="@get('/reset')">Reset</button>
  </div>
</body>
</html>
"""

proc handleIndex(req: Request) {.async.} =
  await req.respond(Http200, indexHtml, newHttpHeaders([("Content-Type", "text/html")]))

proc handleIncrement(req: Request) {.async.} =
  count += 1
  let sse = await req.newSSEGenerator() ; defer: req.closeSSE()
  await sse.patchSignals(%*{"count": count})

proc handleDecrement(req: Request) {.async.} =
  count -= 1
  let sse = await req.newSSEGenerator() ; defer: req.closeSSE()
  await sse.patchSignals(%*{"count": count})

proc handleReset(req: Request) {.async.} =
  count = 0
  let sse = await req.newSSEGenerator() ; defer: req.closeSSE()
  await sse.patchSignals(%*{"count": count})

proc handler(req: Request) {.async.} =
  case req.url.path
  of "/":
    await handleIndex(req)
  of "/increment":
    await handleIncrement(req)
  of "/decrement":
    await handleDecrement(req)
  of "/reset":
    await handleReset(req)
  else:
    await req.respond(Http404, "Not Found")

proc main() =
  let server = newAsyncHttpServer()
  echo "Server running at http://localhost:8080 (Ctrl+C to stop)"
  waitFor server.serve(Port(8080), handler)

main()
