## SDK Test Server
##
## Run with: nim c -r test/server.nim
## Then run: go run github.com/starfederation/datastar/sdk/tests/cmd/datastar-sdk-tests@latest

import std/[asyncdispatch, asynchttpserver, json, tables, strutils]
import ../src/datastar
import ../src/datastar/asynchttpserver as DATASTAR

proc handleTest(req: Request) {.async.} =
  # Parse input based on method
  let input = if req.reqMethod == HttpGet:
    readSignals(req.url.query)
  else:
    readSignalsFromBody(req.body)

  let sse = await req.newSSEGenerator()

  # Process each event
  for event in input["events"]:
    case event["type"].getStr:
    of "patchElements":
      let elements = event.getOrDefault("elements").getStr("")
      let selector = event.getOrDefault("selector").getStr("")
      let modeStr = event.getOrDefault("mode").getStr("outer")
      let mode = parseEnum[ElementPatchMode](modeStr)
      let useViewTransition = event.getOrDefault("useViewTransition").getBool(false)
      let eventId = event.getOrDefault("eventId").getStr("")
      let retryDuration = event.getOrDefault("retryDuration").getInt(0)
      await sse.patchElements(elements, selector, mode, useViewTransition, eventId, retryDuration)

    of "patchSignals":
      let onlyIfMissing = event.getOrDefault("onlyIfMissing").getBool(false)
      let eventId = event.getOrDefault("eventId").getStr("")
      let retryDuration = event.getOrDefault("retryDuration").getInt(0)
      if event.hasKey("signals-raw"):
        await sse.patchSignals(event["signals-raw"].getStr, onlyIfMissing, eventId, retryDuration)
      else:
        await sse.patchSignals(event["signals"], onlyIfMissing, eventId, retryDuration)

    of "executeScript":
      let script = event["script"].getStr
      let autoRemove = event.getOrDefault("autoRemove").getBool(true)
      let eventId = event.getOrDefault("eventId").getStr("")
      let retryDuration = event.getOrDefault("retryDuration").getInt(0)
      var attrs = initTable[string, string]()
      if event.hasKey("attributes"):
        for k, v in event["attributes"]:
          attrs[k] = v.getStr
      await sse.executeScript(script, autoRemove, attrs, eventId, retryDuration)

    else:
      discard

  req.closeSSE()

proc handler(req: Request) {.async.} =
  case req.url.path
  of "/test":
    await handleTest(req)
  else:
    await req.respond(Http404, "Not Found")

proc main() =
  let server = newAsyncHttpServer()
  echo "SDK Test Server running at http://localhost:7331"
  echo "Run: go run github.com/starfederation/datastar/sdk/tests/cmd/datastar-sdk-tests@latest"
  waitFor server.serve(Port(7331), handler)

main()
