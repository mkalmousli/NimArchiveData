import std/[unittest, os, json, strutils, asyncdispatch, tables]
import ../src/datastar

proc runGoldenTest(testDir: string) =
  let inputPath = testDir / "input.json"
  let outputPath = testDir / "output.txt"

  let input = parseFile(inputPath)
  let expected = readFile(outputPath)

  var output = ""
  let sendProc: SendProc = proc(data: string) {.async.} =
    output.add(data)

  let sse = newSSEGenerator(sendProc)

  for event in input["events"]:
    case event["type"].getStr:
    of "patchElements":
      let elements = event.getOrDefault("elements").getStr("")
      let selector = event.getOrDefault("selector").getStr("")
      let modeStr = event.getOrDefault("mode").getStr("outer")
      let mode = parseEnum[ElementPatchMode](modeStr)
      let useViewTransition = event.getOrDefault("useViewTransition").getBool(false)
      let eventId = event.getOrDefault("eventId").getStr("")
      let retryDuration = event.getOrDefault("retryDuration").getInt(0)
      waitFor sse.patchElements(
        elements = elements,
        selector = selector,
        mode = mode,
        useViewTransition = useViewTransition,
        eventId = eventId,
        retryDuration = retryDuration
      )
    of "patchSignals":
      let onlyIfMissing = event.getOrDefault("onlyIfMissing").getBool(false)
      let eventId = event.getOrDefault("eventId").getStr("")
      let retryDuration = event.getOrDefault("retryDuration").getInt(0)

      if event.hasKey("signals-raw"):
        # Raw string signals (for multiline JSON test)
        let signalsRaw = event["signals-raw"].getStr
        waitFor sse.patchSignals(
          signals = signalsRaw,
          onlyIfMissing = onlyIfMissing,
          eventId = eventId,
          retryDuration = retryDuration
        )
      else:
        # JSON object signals
        let signals = event["signals"]
        waitFor sse.patchSignals(
          signals = signals,
          onlyIfMissing = onlyIfMissing,
          eventId = eventId,
          retryDuration = retryDuration
        )
    of "executeScript":
      let script = event["script"].getStr
      let autoRemove = event.getOrDefault("autoRemove").getBool(true)
      let eventId = event.getOrDefault("eventId").getStr("")
      let retryDuration = event.getOrDefault("retryDuration").getInt(0)
      var attrs = initTable[string, string]()
      if event.hasKey("attributes"):
        for k, v in event["attributes"]:
          attrs[k] = v.getStr
      waitFor sse.executeScript(
        script = script,
        autoRemove = autoRemove,
        attributes = attrs,
        eventId = eventId,
        retryDuration = retryDuration
      )
    else:
      raise newException(ValueError, "Unknown event type: " & event["type"].getStr)

  check output == expected

suite "Golden Tests - GET":
  let getDir = currentSourcePath().parentDir() / "golden" / "get"
  for kind, path in walkDir(getDir):
    if kind == pcDir:
      let testName = path.splitPath.tail
      test testName:
        runGoldenTest(path)

suite "Golden Tests - POST":
  let postDir = currentSourcePath().parentDir() / "golden" / "post"
  for kind, path in walkDir(postDir):
    if kind == pcDir:
      let testName = path.splitPath.tail
      test testName:
        runGoldenTest(path)
