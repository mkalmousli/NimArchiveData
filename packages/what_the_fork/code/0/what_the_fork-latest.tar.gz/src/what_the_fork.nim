import std/[httpclient, json, strutils, strformat, os, re, algorithm, sequtils]

type
  Fork = object
    name: string
    fullName: string
    owner: string
    description: string
    stars: int
    forks: int
    lastUpdated: string
    defaultBranch: string
    url: string
    cloneUrl: string
    
  Commit = object
    sha: string
    message: string
    author: string
    date: string
    
  Analysis = object
    features: seq[string]
    bugfixes: seq[string]
    ideas: seq[string]
    commits: seq[Commit]
    
  SearchMatch = object
    keyword: string
    forkName: string
    commitSha: string
    commitMessage: string
    author: string
    date: string
    matchContext: string
    
  SearchResults = object
    matches: seq[SearchMatch]
    totalMatches: int
    keywordCounts: seq[tuple[keyword: string, count: int]]
    
  CliOptions = object
    githubUrl: string
    token: string
    searchKeywords: seq[string]
    isSearchMode: bool

proc parseCliArgs(): CliOptions =
  ## Parse command line arguments
  var options = CliOptions()
  var i = 1
  
  while i <= paramCount():
    let arg = paramStr(i)
    
    case arg:
    of "-h", "--help", "help":
      return options # Will trigger help display
    of "--search":
      if i + 1 <= paramCount():
        options.isSearchMode = true
        let searchStr = paramStr(i + 1)
        options.searchKeywords = searchStr.split(',').mapIt(it.strip().toLower())
        i += 2
      else:
        raise newException(ValueError, "--search requires keywords (comma-separated)")
    else:
      if arg.startsWith("--"):
        raise newException(ValueError, &"Unknown option: {arg}")
      elif "github.com" in arg or "/" in arg:
        options.githubUrl = arg
        i += 1
      elif arg.startsWith("ghp_") or arg.startsWith("github_pat_"):
        options.token = arg
        i += 1
      else:
        # Could be a token or unknown argument
        if options.token == "":
          options.token = arg
        i += 1
  
  return options

proc parseGitHubUrl(url: string): tuple[owner: string, repo: string] =
  ## Parse GitHub URL to extract owner and repository name
  let cleanUrl = url.strip()
  
  # Try different patterns for GitHub URLs
  let patterns = [
    re"https?://github\.com/([^/]+)/([^/]+?)(?:\.git)?/?$",  # https://github.com/owner/repo
    re"github\.com/([^/]+)/([^/]+?)(?:\.git)?/?$",           # github.com/owner/repo
    re"^([^/]+)/([^/]+?)(?:\.git)?$"                         # owner/repo
  ]
  
  var matches: array[2, string]
  
  for pattern in patterns:
    if cleanUrl.match(pattern, matches):
      var repo = matches[1]
      # Remove .git suffix if present
      if repo.endsWith(".git"):
        repo = repo[0..^5]
      return (owner: matches[0], repo: repo)
  
  # Debug output to help troubleshoot
  echo "Debug: Input URL = '", cleanUrl, "'"
  raise newException(ValueError, "Invalid GitHub URL format. Expected formats: https://github.com/owner/repo, github.com/owner/repo, or owner/repo")

proc makeGitHubRequest(client: HttpClient, endpoint: string, token: string = ""): JsonNode =
  ## Make authenticated GitHub API request
  var headers = newHttpHeaders([("User-Agent", "GitHub-Fork-Analyzer/1.0")])
  if token != "":
    headers["Authorization"] = "token " & token
  
  let response = client.request(endpoint, httpMethod = HttpGet, headers = headers)
  if response.status != "200 OK":
    echo "API request failed: ", response.status
    echo "Response: ", response.body
    return nil
  
  return parseJson(response.body)

proc getForks(client: HttpClient, owner: string, repo: string, token: string): seq[Fork] =
  ## Get all forks of a repository
  var forks: seq[Fork] = @[]
  var page = 1
  
  while true:
    let endpoint = &"https://api.github.com/repos/{owner}/{repo}/forks?page={page}&per_page=100"
    let response = makeGitHubRequest(client, endpoint, token)
    
    if response == nil or response.len == 0:
      break
    
    for forkJson in response:
      let fork = Fork(
        name: forkJson["name"].getStr(),
        fullName: forkJson["full_name"].getStr(),
        owner: forkJson["owner"]["login"].getStr(),
        description: forkJson["description"].getStr(""),
        stars: forkJson["stargazers_count"].getInt(),
        forks: forkJson["forks_count"].getInt(),
        lastUpdated: forkJson["updated_at"].getStr(),
        defaultBranch: forkJson["default_branch"].getStr(),
        url: forkJson["html_url"].getStr(),
        cloneUrl: forkJson["clone_url"].getStr()
      )
      forks.add(fork)
    
    page += 1
    if response.len < 100:
      break
  
  return forks

proc getCommits(client: HttpClient, owner: string, repo: string, branch: string, token: string, since: string = ""): seq[Commit] =
  ## Get commits from a repository
  var commits: seq[Commit] = @[]
  var page = 1
  
  while page <= 3: # Limit to first 3 pages to avoid rate limiting
    var endpoint = &"https://api.github.com/repos/{owner}/{repo}/commits?sha={branch}&page={page}&per_page=30"
    if since != "":
      endpoint &= &"&since={since}"
    
    let response = makeGitHubRequest(client, endpoint, token)
    
    if response == nil or response.len == 0:
      break
    
    for commitJson in response:
      let commit = Commit(
        sha: commitJson["sha"].getStr(),
        message: commitJson["commit"]["message"].getStr(),
        author: commitJson["commit"]["author"]["name"].getStr(),
        date: commitJson["commit"]["author"]["date"].getStr()
      )
      commits.add(commit)
    
    page += 1
    if response.len < 30:
      break
  
  return commits

proc searchCommitsForKeywords(commits: seq[Commit], keywords: seq[string], forkName: string): seq[SearchMatch] =
  ## Search commits for specific keywords
  var matches: seq[SearchMatch] = @[]
  
  for commit in commits:
    let lowerMessage = commit.message.toLower()
    let messageLines = commit.message.split('\n')
    
    for keyword in keywords:
      if keyword in lowerMessage:
        # Find the context around the keyword
        var context = ""
        for line in messageLines:
          if keyword.toLower() in line.toLower():
            context = line.strip()
            break
        
        if context == "":
          context = messageLines[0].strip() # Fallback to first line
        
        let match = SearchMatch(
          keyword: keyword,
          forkName: forkName,
          commitSha: commit.sha[0..6], # Short SHA
          commitMessage: messageLines[0].strip(), # First line only
          author: commit.author,
          date: commit.date,
          matchContext: context
        )
        matches.add(match)
  
  return matches

proc performKeywordSearch(forks: seq[Fork], keywords: seq[string], client: HttpClient, token: string): SearchResults =
  ## Perform keyword search across all forks
  var allMatches: seq[SearchMatch] = @[]
  var keywordCounts: seq[tuple[keyword: string, count: int]] = @[]
  
  # Initialize keyword counts
  for keyword in keywords:
    keywordCounts.add((keyword: keyword, count: 0))
  
  echo &"🔍 Searching for keywords: {keywords.join(\", \")}"
  echo &"📊 Searching across {forks.len} forks..."
  
  # Sort forks by stars for better results first
  var sortedForks = forks
  sortedForks.sort do (a, b: Fork) -> int:
    result = cmp(b.stars, a.stars)
  
  # Limit search to top forks to avoid rate limiting
  let maxForks = min(20, sortedForks.len)
  
  for i in 0..<maxForks:
    let fork = sortedForks[i]
    echo &"  🔎 Searching in {fork.fullName} ({i+1}/{maxForks})..."
    
    let commits = getCommits(client, fork.owner, fork.name, fork.defaultBranch, token)
    let matches = searchCommitsForKeywords(commits, keywords, fork.fullName)
    
    allMatches.add(matches)
    
    # Update keyword counts
    for match in matches:
      for j in 0..<keywordCounts.len:
        if keywordCounts[j].keyword == match.keyword:
          keywordCounts[j].count += 1
          break
    
    # Small delay to be nice to GitHub API
    sleep(500)
  
  return SearchResults(
    matches: allMatches,
    totalMatches: allMatches.len,
    keywordCounts: keywordCounts
  )

proc printSearchResults(results: SearchResults) =
  ## Print keyword search results
  echo "\n" & "=".repeat(80)
  echo "🔍 KEYWORD SEARCH RESULTS"
  echo "=".repeat(80)
  
  if results.totalMatches == 0:
    echo "❌ No matches found for the specified keywords"
    return
  
  echo &"📊 Total Matches: {results.totalMatches}"
  
  # Print keyword frequency
  echo "\n📈 KEYWORD FREQUENCY:"
  echo "-".repeat(40)
  for kc in results.keywordCounts:
    if kc.count > 0:
      echo &"  🔑 '{kc.keyword}': {kc.count} matches"
  
  # Group matches by keyword
  for kc in results.keywordCounts:
    if kc.count > 0:
      echo &"\n🎯 MATCHES FOR '{kc.keyword.toUpper()}' ({kc.count}):"
      echo "-".repeat(50)
      
      var keywordMatches = results.matches.filterIt(it.keyword == kc.keyword)
      # Sort by date (newest first)
      keywordMatches.sort do (a, b: SearchMatch) -> int:
        result = cmp(b.date, a.date)
      
      let maxShow = min(15, keywordMatches.len)
      for i in 0..<maxShow:
        let match = keywordMatches[i]
        echo &"  📍 {match.forkName}"
        echo &"     💬 {match.commitMessage}"
        echo &"     👤 {match.author} | 📅 {match.date[0..9]} | 🔗 {match.commitSha}"
        if match.matchContext != match.commitMessage:
          echo &"     🎯 Context: {match.matchContext}"
        echo ""
      
      if keywordMatches.len > maxShow:
        echo &"     ... and {keywordMatches.len - maxShow} more matches\n"

proc categorizeCommit(message: string): tuple[isFeature: bool, isBugfix: bool, isIdea: bool] =
  ## Categorize commit based on message patterns
  let lowerMsg = message.toLower()
  
  # Feature patterns
  let featurePatterns = [
    "feat:", "feature:", "add:", "implement", "new:", "enhancement:",
    "support for", "introduce", "enable", "allow"
  ]
  
  # Bugfix patterns  
  let bugfixPatterns = [
    "fix:", "bug:", "patch:", "hotfix:", "repair", "resolve", "correct",
    "issue", "problem", "error", "crash", "failure"
  ]
  
  # Ideas/improvements patterns
  let ideaPatterns = [
    "improve:", "refactor:", "optimize:", "performance:", "cleanup:",
    "update:", "upgrade:", "modernize", "simplify", "enhance", "better"
  ]
  
  var isFeature = false
  var isBugfix = false
  var isIdea = false
  
  for pattern in featurePatterns:
    if pattern in lowerMsg:
      isFeature = true
      break
  
  for pattern in bugfixPatterns:
    if pattern in lowerMsg:
      isBugfix = true
      break
  
  for pattern in ideaPatterns:
    if pattern in lowerMsg:
      isIdea = true
      break
  
  return (isFeature: isFeature, isBugfix: isBugfix, isIdea: isIdea)

proc analyzeCommits(commits: seq[Commit]): Analysis =
  ## Analyze commits to categorize them
  var analysis = Analysis()
  
  for commit in commits:
    let category = categorizeCommit(commit.message)
    let shortMsg = commit.message.split('\n')[0] # Get first line only
    
    if category.isFeature:
      analysis.features.add(&"[{commit.author}] {shortMsg}")
    elif category.isBugfix:
      analysis.bugfixes.add(&"[{commit.author}] {shortMsg}")
    elif category.isIdea:
      analysis.ideas.add(&"[{commit.author}] {shortMsg}")
    
    analysis.commits.add(commit)
  
  return analysis

proc printAnalysis(fork: Fork, analysis: Analysis) =
  ## Print analysis results for a fork
  echo "\n" & "=".repeat(80)
  echo &"🍴 FORK: {fork.fullName}"
  echo "=".repeat(80)
  echo &"⭐ Stars: {fork.stars} | 🍴 Forks: {fork.forks}"
  echo &"📝 Description: {fork.description}"
  echo &"🔗 URL: {fork.url}"
  echo &"📅 Last Updated: {fork.lastUpdated}"
  echo &"📊 Total Commits Analyzed: {analysis.commits.len}"
  
  if analysis.features.len > 0:
    echo "\n🚀 FEATURES (" & $analysis.features.len & "):"
    echo "-".repeat(40)
    for i, feature in analysis.features:
      if i < 10: # Limit output
        echo &"  • {feature}"
      elif i == 10:
        echo &"  ... and {analysis.features.len - 10} more features"
        break
  
  if analysis.bugfixes.len > 0:
    echo "\n🐛 BUGFIXES (" & $analysis.bugfixes.len & "):"
    echo "-".repeat(40)
    for i, bugfix in analysis.bugfixes:
      if i < 10: # Limit output
        echo &"  • {bugfix}"
      elif i == 10:
        echo &"  ... and {analysis.bugfixes.len - 10} more bugfixes"
        break
  
  if analysis.ideas.len > 0:
    echo "\n💡 IDEAS & IMPROVEMENTS (" & $analysis.ideas.len & "):"
    echo "-".repeat(40)
    for i, idea in analysis.ideas:
      if i < 10: # Limit output
        echo &"  • {idea}"
      elif i == 10:
        echo &"  ... and {analysis.ideas.len - 10} more improvements"
        break
  
  if analysis.features.len == 0 and analysis.bugfixes.len == 0 and analysis.ideas.len == 0:
    echo "\n❌ No significant changes detected or commits don't follow conventional patterns"

proc printHelp() =
  echo """
GitHub Fork Analyzer - Analyze features, bugfixes, and ideas in repository forks

USAGE:
  what_the_fork <github_url> [github_token] [--search "keyword1,keyword2"]
  what_the_fork --search "keyword1,keyword2" <github_url> [github_token]

ARGUMENTS:
  github_url    GitHub repository URL in one of these formats:
                • https://github.com/owner/repo
                • https://github.com/owner/repo.git
                • github.com/owner/repo
                • owner/repo

  github_token  Optional GitHub personal access token for higher API rate limits
                (Without token: 60 requests/hour, With token: 5000 requests/hour)
                Get token at: https://github.com/settings/tokens

OPTIONS:
  --search      Search for specific keywords in commit messages across forks
                Provide comma-separated keywords (case-insensitive)
                Example: --search "async,performance,memory"

EXAMPLES:
  # Standard analysis
  what_the_fork https://github.com/nim-lang/Nim
  what_the_fork nim-lang/Nim ghp_your_token_here
  
  # Keyword search
  what_the_fork --search "async,coroutine" https://github.com/nim-lang/Nim
  what_the_fork https://github.com/nim-lang/Nim ghp_token --search "memory,gc"

OUTPUT:
  Standard Mode:
  🚀 FEATURES      - New functionality and enhancements
  🐛 BUGFIXES      - Bug fixes and problem resolutions  
  💡 IDEAS         - Improvements, refactoring, and optimizations
  
  Search Mode:
  🔍 KEYWORD SEARCH RESULTS - Matches for specified keywords
  📈 KEYWORD FREQUENCY      - Count of matches per keyword
  🎯 MATCHES FOR KEYWORD    - Detailed results per keyword

NOTES:
  • Standard mode analyzes up to 10 most active forks (by stars)
  • Search mode searches up to 20 most active forks
  • Examines up to 90 recent commits per fork
  • Uses commit message patterns to categorize changes
  • Respects GitHub API rate limits with automatic delays

For more information, visit: https://github.com
"""

proc main() =
  if paramCount() == 0:
    printHelp()
    quit(1)
  
  var options: CliOptions
  
  try:
    options = parseCliArgs()
  except ValueError as e:
    echo &"❌ Error: {e.msg}"
    echo "\nUse --help for usage information"
    quit(1)
  
  # Check if help was requested
  if paramCount() > 0 and paramStr(1) in ["-h", "--help", "help"]:
    printHelp()
    quit(0)
  
  # Validate required arguments
  if options.githubUrl == "":
    echo "❌ Error: GitHub URL is required"
    echo "\nUse --help for usage information"
    quit(1)
  
  if options.isSearchMode and options.searchKeywords.len == 0:
    echo "❌ Error: --search requires keywords"
    quit(1)
  
  try:
    let (owner, repo) = parseGitHubUrl(options.githubUrl)
    echo &"🔍 Analyzing forks of {owner}/{repo}..."
    
    if options.isSearchMode:
      echo &"🎯 Search mode: Looking for keywords: {options.searchKeywords.join(\", \")}"
    
    let client = newHttpClient()
    defer: client.close()
    
    # Get all forks
    echo "📥 Fetching forks..."
    let forks = getForks(client, owner, repo, options.token)
    
    if forks.len == 0:
      echo "❌ No forks found for this repository"
      return
    
    echo &"✅ Found {forks.len} forks"
    
    if options.isSearchMode:
      # Perform keyword search
      let searchResults = performKeywordSearch(forks, options.searchKeywords, client, options.token)
      printSearchResults(searchResults)
    else:
      # Standard analysis mode
      # Sort forks by activity (stars + recent updates)
      var sortedForks = forks
      sortedForks.sort do (a, b: Fork) -> int:
        result = cmp(b.stars, a.stars) # Sort by stars descending
      
      # Analyze top forks (limit to prevent rate limiting)
      let maxForks = min(10, sortedForks.len)
      echo &"🔬 Analyzing top {maxForks} most active forks..."
      
      var totalFeatures = 0
      var totalBugfixes = 0
      var totalIdeas = 0
      
      for i in 0..<maxForks:
        let fork = sortedForks[i]
        echo &"\n⏳ Analyzing {fork.fullName} ({i+1}/{maxForks})..."
        
        # Get commits from the fork
        let commits = getCommits(client, fork.owner, fork.name, fork.defaultBranch, options.token)
        
        if commits.len > 0:
          let analysis = analyzeCommits(commits)
          printAnalysis(fork, analysis)
          
          totalFeatures += analysis.features.len
          totalBugfixes += analysis.bugfixes.len
          totalIdeas += analysis.ideas.len
        else:
          echo &"❌ Could not fetch commits for {fork.fullName}"
        
        # Small delay to be nice to GitHub API
        sleep(1000)
      
      # Summary
      echo "\n" & "=".repeat(80)
      echo "📊 SUMMARY"
      echo "=".repeat(80)
      echo &"🍴 Total Forks: {forks.len}"
      echo &"🔬 Analyzed: {maxForks}"
      echo &"🚀 Total Features Found: {totalFeatures}"
      echo &"🐛 Total Bugfixes Found: {totalBugfixes}"
      echo &"💡 Total Ideas/Improvements Found: {totalIdeas}"
      echo &"📈 Total Insights: {totalFeatures + totalBugfixes + totalIdeas}"
    
  except ValueError as e:
    echo &"❌ Error: {e.msg}"
  except Exception as e:
    echo &"❌ Unexpected error: {e.msg}"

when isMainModule:
  main()
