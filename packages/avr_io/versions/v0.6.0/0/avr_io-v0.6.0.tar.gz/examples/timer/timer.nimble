# Package

version       = "0.1.0"
author        = "mar"
description   = "Simple application showcasing the timer features."
license       = "BSD-3-Clause"
srcDir        = "src"
bin           = @["timer"]


# Dependencies

requires "nim >= 2.0.6"
requires "avr_io >= 0.5.0"

after build:
  when defined(windows):
    mvFile(bin[0] & ".exe", bin[0] & ".elf")
  else:
    mvFile(bin[0], bin[0] & ".elf")
  exec("avr-objcopy -O ihex " & bin[0] & ".elf " & bin[0] & ".hex")
  exec("avr-objcopy -O binary " & bin[0] & ".elf " & bin[0] & ".bin")

task clear, "Deletes the previously built compiler artifacts":
  rmFile(bin[0] & ".elf")
  rmFile(bin[0] & ".hex")
  rmFile(bin[0] & ".bin")
  rmDir(".nimcache")

task flash, "Loads the compiled binary onto the MCU":
  let (dev_port, code) = gorge_ex("avrman device -p UNO")
  if code != 0:
    echo dev_port
    return
  exec("avrdude -c arduino -p atmega328p -b 115200 -P " & dev_port & " -U flash:w:" & bin[0] & ".hex:i")

task flash_debug, "Loads the elf binary onto the MCU":
  let (dev_port, code) = gorge_ex("avrman device -p UNO")
  if code != 0:
    echo dev_port
    return
  exec("avrdude -c arduino -p atmega328p -b 115200 -P " & dev_port & " -U flash:w:" & bin[0] & ".elf:e")
