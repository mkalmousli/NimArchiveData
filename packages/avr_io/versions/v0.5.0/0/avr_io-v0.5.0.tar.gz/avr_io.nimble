# Package

version       = "0.5.0"
author        = "Gianmarco Marcello"
description   = "AVR registers, interrupts, progmem and peripheral support in nim!"
license       = "BSD-3-Clause"
srcDir        = "src"


# Dependencies

requires "nim >= 2.0.6"
