import streams, json, anonimongo
import well_parser / [types, drillingPermits, aiders, well_api, injectionUIC]




proc getDrillingData*(file: string): JsonNode =
    let eof = "01#############EOF################"
    var 
        strmW = newFileStream(file, fmAppend)
        strm = newFileStream(file, fmRead)
        line = ""
        le: seq[FinalDrillingObject]
        ds: FinalDrillingObject

    if not isNil(strmW):
        strmW.writeLine(eof)
        strmW.close()
    
    while strm.readLine(line):
        if line.len() <= 1:
            continue
        let 
            row = line[0..1]
        if row == "01" and ds.root.rrcTapeRecordId == "01":
            le.add ds
            ds = FinalDrillingObject()
        if line == eof:
            break
        else:
            try:
                ds.parseLine(line)
            except IndexDefect:
                echo "---------ERROR---------------"
                echo "row " & row
                echo len(line)
                echo strm.getPosition()
                echo getCurrentExceptionMsg()
                echo line
                quit()
    strm.close()
    le.delete(0)
    return %le

proc writeJson*(json: JsonNode, file: string) = 
    var 
        e = newFileStream(file, fmWrite)
    if not isNil(e):
        e.write($json)
        e.close()

proc getDrillingDataMongo*(file: string): seq[BsonDocument] =
    let eof = "01#############EOF################"
    var 
        strmW = newFileStream(file, fmAppend)
        strm = newFileStream(file, fmRead)
        line = ""
        le: seq[BsonDocument]
        ds: FinalDrillingObject
        bs: BsonDocument

    if not isNil(strmW):
        strmW.writeLine(eof)
        strmW.close()
    
    while strm.readLine(line):
        if line.len() <= 1:
            continue
        let 
            row = line[0..1]
        if row == "01" and ds.root.rrcTapeRecordId == "01":
            bs = obToBson(ds)
            le.add bs
            ds = FinalDrillingObject()
        if line == eof:
            break
        else:
            try:
                ds.parseLine(line)
            except IndexDefect:
                echo "---------ERROR---------------"
                echo "row " & row
                echo len(line)
                echo strm.getPosition()
                echo getCurrentExceptionMsg()
                echo line
                quit()
    strm.close()
    le.delete(0)
    return(le)

#[ not functional yet
proc getWellData*(file: string): JsonNode =
    var 
        strm = newFileStream(file, fmRead)
        line = ""
        le: seq[FinalWellObject]
        ds: FinalWellObject
    
    while strm.readLine(line):
        if line.len() <= 1:
            continue
        try:
            ds = uniqueRow(line)
            echo ds
            le.add ds
        except IndexDefect:
            echo "---------ERROR---------------"
            echo len(line)
            echo strm.getPosition()
            echo getCurrentExceptionMsg()
            echo line
            quit()
    strm.close()
    return %le
]#

proc getInjectionData*(file: string, output: string, size: int) =
    let eof = "01#############EOF################"
    var 
        strmW = newFileStream(file, fmAppend)
        strm = newFileStream(file, fmRead)
        line = ""
        le: seq[FinalInjectionObject]
        ds: FinalInjectionObject
        obname: int = 0
        name: string

    if not isNil(strmW):
        strmW.writeLine(eof)
        strmW.close()
    
    while strm.readLine(line):
        if line.len() <= 1:
            continue
        let 
            row = line[0..1]
        if row == "01" and ds.uicRoot.rrcTapeRecordId == "01":
            le.add ds
        # echo %ds
            ds = FinalInjectionObject()
        if line == eof:
            break
        if le.len == size:
            obname += 1
            name = "sequence-" & $obname & ".json"
            writeJson(%le, output & name)
            le = newSeq[FinalInjectionObject](0)
            echo name
        else:
            try:
                ds.parseLine(line)
            except IndexDefect:
                echo "---------ERROR---------------"
                echo "row " & row
                echo len(line)
                echo strm.getPosition()
                echo getCurrentExceptionMsg()
                echo line
                quit()
        
    strm.close()

#getInjectionData("/media/steamgames/uif700a.txt", "/media/steamgames/test/", 500)


proc getInjectionDataMongo*(col: Collection, file: string, checkExisting: bool = false) =
    let 
        eof = "01#############EOF################"
    var 
        strmW = newFileStream(file, fmAppend)
        strm = newFileStream(file, fmRead)
        line = ""
        ds: FinalInjectionObject
        bs: BsonDocument
        existing: seq[string]

    if not isNil(strmW):
        strmW.writeLine(eof)
        strmW.close()
    if checkExisting: 
        let dis = waitFor col.`distinct`("uicRoot.uicCNTLNO")
        for el in dis:
            existing.add el.ofString

    while strm.readLine(line):
        if line.len() <= 1:
            continue
        let 
            row = line[0..1]
        if row == "01" and ds.uicRoot.rrcTapeRecordId == "01":
            bs = obToBson(ds)
            ds.checkE(existing):
                let insertM = waitFor col.insert(@[bs])
                if not insertM.success:
                    echo "Something went wrong!"
                    break
            ds = FinalInjectionObject()
        if line == eof:
            break
        else:
            try:
                ds.parseLine(line)
            except IndexDefect:
                echo "---------ERROR---------------"
                echo "row " & row
                echo len(line)
                echo strm.getPosition()
                echo getCurrentExceptionMsg()
                echo line
                quit()
    strm.close()
