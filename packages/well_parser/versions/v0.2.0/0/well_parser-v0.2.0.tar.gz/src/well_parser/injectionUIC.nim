import types, aiders, strutils



proc rowOne(line: string): UICRoot = 
    result.uicType = UIROOT
    result.rrcTapeRecordId = line <- [1,3]
    result.uicCNTLNO = line <- [3, 12]
    result.uicNextCTLnum = UICnextCTLnum(uicNEXTAVAILABLE: line <- [12, 21],
                                         uicNEXTDUMMYLEASE: line <- [21, 27])
    result.uicAltKEY1 = UICaltKEY1(
                                    uicOGTYPE: line <- [12, 13],
                                    uicLEASEID: line <- [13, 19],
                                    uicDist: line <- [19, 21],
                                    uicWellNo: line <- [21, 27]
                                    )
    result.uicOPER = line <- [27, 33]
    result.uicApiNUMBER = UICapiNUMBER(
                                        uicCNTYNO: line <- [33, 36],
                                        uicAPINO: line <- [36, 41]
                                        )
    result.uicClass = line <- [49, 50]
    result.uicAPPRDATE = DaDAT(
                                dACENTURY: line <- [50, 52],
                                dAYEAR: line <- [52, 54],
                                dAMONTH: line <- [54, 56],
                                dADAY: line <- [56, 58]
                                )
    result.uicW14DATE = DaDAT(
                                dACENTURY: line <- [58, 60],
                                dAYEAR: line <- [60, 62],
                                dAMONTH: line <- [62, 64],
                                dADAY: line <- [64, 66]
                                )
    result.uicH1DATE = DaDAT(
                                dACENTURY: line <- [66, 68],
                                dAYEAR: line <- [68, 70],
                                dAMONTH: line <- [70, 72],
                                dADAY: line <- [72, 74]
                                )
    result.uicLETTERDATE = DaDAT(
                                dACENTURY: line <- [74, 76],
                                dAYEAR: line <- [76, 78],
                                dAMONTH: line <- [78, 80],
                                dADAY: line <- [80, 82]
                                )
    result.uicPERMITADDEDDATE = DaDAT(
                                dACENTURY: line <- [82, 84],
                                dAYEAR: line <- [84, 86],
                                dAMONTH: line <- [86, 88],
                                dADAY: line <- [88, 90]
                                )
    result.uicACTIVATEDFLAG = line <- [90, 91]
    result.uicCANCELDATE = DaDAT(
                                dACENTURY: line <- [91, 93],
                                dAYEAR: line <- [93, 95],
                                dAMONTH: line <- [95, 97],
                                dADAY: line <- [97, 99]
                                )
    result.uicW2G1DATE = DaDAT(
                                dACENTURY: line <- [99, 101],
                                dAYEAR: line <- [101, 103],
                                dAMONTH: line <- [103, 105],
                                dADAY: line <- [105, 107]
                                )
    result.uicW3DATE = DaDAT(
                                dACENTURY: line <- [107, 109],
                                dAYEAR: line <- [109, 111],
                                dAMONTH: line <- [111, 113],
                                dADAY: line <- [113, 115]
                                )
    result.uicTYPEINJ = line <- [115, 116]
    result.uicTYPEINJCMT = line <- [116, 146]
    result.uicTYPEFLUCMT = line <- [146, 176]
    result.uicBBLVOLINJ = line <- [176, 185]
    result.uicMCFVOLINJ = line <- [185, 194]
    result.uicTOPINJZONE = line <- [194, 199]
    result.uicBOTINJZONE = line <- [199, 204]
    result.uicMAXINJPRESSURE = line <- [204, 209]
    result.uicH1NO = line <- [209, 214]
    result.uicW14NO = line <- [214, 219]
    result.uicINJFLUIDS = UICinjFLUIDS(
                                        uicINJsw: line <- [219, 220],
                                        uicINJfw: line <- [220, 221],
                                        uicINJfracWater: line <- [221, 222],
                                        uicINJnorm: line <- [222, 223],
                                        uicINJCO2: line <- [223, 224],
                                        uicINJgas: line <- [224, 225],
                                        uicINJh2s: line <- [225, 226],
                                        uicINJpolymer: line <- [226, 227],
                                        uicINJsteam: line <- [227, 228],
                                        uicINJair: line <- [228, 229],
                                        uicINJnitrogen: line <- [229, 230],
                                        uicINJother: line <- [230, 231],
                                        uicINJbw: line <- [231, 232],
                                        uicINJlpg: line <- [232, 233]
                                        )
    result.uicMAXINJPRESSURE2 = line <- [233, 238]
    result.uicSPECIALCONDITIONS = UICspecialCONDITIONS(
                                                        uicSPECANNPRESSTEST: line <- [238, 239],
                                                        uicSPECANNRADTRACERSUR: line <- [239, 240],
                                                        uicSPECANNTEMPSURVEY: line <- [240, 241],
                                                        uicSPECDOWNHOLESURVEY: line <- [241, 242],
                                                        uicSPECSEMIANNUALPT: line <- [242, 243],
                                                        uicSPECTBGCSGANNULUS: line <- [243, 244],
                                                        uicSPECTBGCSGFREQ: line <- [244, 245],
                                                        uicSPECMONTRPRESS: line <- [245, 246],
                                                        uicSPECMONTRPRESSCODE1: line <- [246, 248],
                                                        uicSPECMO0NTRPRESSCODE2: line <- [248, 250],
                                                        uicSPECMONTRPRESSFREQ: line <- [250, 251],
                                                        uicSPECMEASFLUIDLEVEL: line <- [251, 252],
                                                        uicSPECMEASFLUIDFREQ: line <- [252, 253],
                                                        uicSPECCOMMERCIAL: line <- [253, 254],
                                                        uicSPECCEMENTSQZ: line <- [254, 255],
                                                        uicSPECCEMENTSQZAMT1: line <- [255, 261],
                                                        uicSPECCEMENTSQZAMT2: line <- [261, 264],
                                                        uicSPECCEMENTSQZ2: line <- [264, 265],
                                                        uicSPECCEMENTSQZ2AMT1: line <- [265, 271],
                                                        uicSPECCEMENTSQZ2AMT2: line <- [271, 274],
                                                        uicSPECBLOCKSQZSX: line <- [274, 275],
                                                        uicSPECBLOCKSQZSXAMT1: line <- [275, 281],
                                                        uicSPECBLOCKSQZSXAMT2: line <- [281, 284],
                                                        uicSPECBLOCKSQZ: line <- [284, 285],
                                                        uicSPECBLOCKSQZAMT: line <- [285, 291],
                                                        uicSPECSQZPERF: line <- [291, 292],
                                                        uicSPECSQZPERFDPTH: line <- [292, 298],
                                                        uicSPECBRIDGEPLUG: line <- [298, 299],
                                                        uicSPECBRIDGEPLUGDPTH: line <- [299, 305],
                                                        uicSPECFLUIDSOURCELIMIT: line <- [305, 306],
                                                        uicSPECPLUGAREAWELLS: line <- [306, 307],
                                                        uicSPECPLUGAREAWELLSNO: line <- [307, 309],
                                                        uicSPECPERMITEXP: line <- [309, 310],
                                                        uicSPECPERMITEXPDATE: DaDAT(
                                                                                    dACENTURY: line <- [310, 312],
                                                                                    dAYEAR: line <- [312, 314],
                                                                                    dAMONTH: line <- [314, 316],
                                                                                    dADAY: line <- [316, 318]
                                                                                    ),
                                                        uicSPECGASPLANT: line <- [318, 319],
                                                        uicSPECOTHER: line <- [319, 320]
                                                        )
    result.uicEXCEPTIONS = UICexpections(
                                            uicEXCTUBINGPACKER: line <- [320, 321],
                                            uicEXCTUBINGPACKERDATE: DaDAT(
                                                                            dACENTURY: line <- [321, 323],
                                                                            dAYEAR: line <- [323, 325],
                                                                            dAMONTH: line <- [325, 327],
                                                                            dADAY: line <- [327, 329]
                                                                            ),  
                                            uicEXCPACKERDEPTH: line <- [329, 330],
                                            uicEXCPACKERDEPTHDATE: DaDAT(
                                                                            dACENTURY: line <- [330, 332],
                                                                            dAYEAR: line <- [332, 334],
                                                                            dAMONTH: line <- [334, 336],
                                                                            dADAY: line <- [336, 338]
                                                                            ),  
                                            uicEXCPACKERDEPTHAM: line <- [338, 344],
                                            uicEXCOBSERVVALUE: line <- [344, 345],
                                            uicEXCOBSERVVALUEDATE: DaDAT(
                                                                            dACENTURY: line <- [345, 347],
                                                                            dAYEAR: line <- [347, 349],
                                                                            dAMONTH: line <- [349, 351],
                                                                            dADAY: line <- [351, 353]
                                                                            ), 

                                            )
    result.uicBASEUSUABLEQUALITYWATER = UICbaseUsuableQUALITYWATER(
                                                                    uicDPTHBOTOFTOPZONE: line <- [353, 357],
                                                                    uicDPTHTOPOFSPLITZONE: line <- [357, 361],
                                                                    uicDPTHBOTOFSPLITZONE: line <- [361, 365]
                                                                    )
    result.uicLOCATION = line <- [365, 417]
    result.uicSURVEYLINES = line <- [417, 445]
    result.uicSTATUS = line <- [445, 446]
    result.uicGEOTHERMAL = line <- [446, 447]
    result.uicMISMATCH = line <- [447,448]
    result.uicDEPTHBOZ = line <- [448, 453]
    result.uicDEPTHPKR = line <- [453, 458]
    result.uicINJMODE = line <- [458, 459]
    result.uicTECHNICIANDATA = UICtechnicianDATA(
                                                    uicTECHNICIANREVIEWDATE: DaDAT(
                                                                                dACENTURY: line <- [459, 461],
                                                                                dAYEAR: line <- [461, 463],
                                                                                dAMONTH: line <- [463, 465],
                                                                                dADAY: line <- [465, 467]
                                                                                ),
                                                    uicTECHNICIANINITIALS: line <- [467, 470],
                                                    uicTECHNICIANRESULTS: line <- [470, 476]
                                                    )
    result.uicPRODCASING = UICprodCASING(
                                            uicPRODCASINGAMT: line <- [476, 478],
                                            uicPRODCASINGFRACTION1: line <- [478, 480],
                                            uicPRODCASINGFRACTION2: line <- [480, 482],
                                            uicPRODCASINGDEPTH: line <- [482, 487],
                                            uicPRODCASINGCEMENT: line <- [487, 491],
                                            uicPRODCASINGTOPCEMENT: line <- [491, 496],
                                            uicPRODCASINGPKRDEPTH: line <- [496, 501]
                                            )
    result.uicGASPLANTCOMMENT = line <- [501, 521]
    result.uicSPECIALCONDCMT = line <- [521, 549]
    result.uicFILEREVIEWDATE = DaDAT(
                                        dACENTURY: line <- [549, 551],
                                        dAYEAR: line <- [551, 553],
                                        dAMONTH: line <- [553, 555],
                                        dADAY: line <- [555, 557]
                                        )
    result.uicFILEREVIEWINIT = line <- [557, 560]
    result.uicDOCKETNODIST = line <- [560, 562]
    result.uicDOCKETNO = UICdocketNO(
                                        filler: line <- [562, 564],
                                        uicOLDDOCKETNO: line <- [564, 569]
                                        )
    result.uicUIROOTFILLER = line <- [569, 620]
    result.uicH10BATCH = UICh10BATCH(
                                        uicH10BATCHCYCLE: line <- [569, 573],
                                        uicH10BATCHCURR: line <- [573, 577],
                                        uicH10BATCHPREV: line <- [577, 581],
                                        uicMISCTYPEMIT: line <- [581, 603],
                                        uicMISCTYPEMITFREQUENCY: line <- [603, 606],
                                        uicTYPEOFWELLCOMPLETION: line <- [606, 614],
                                        filler: line <- [614, 620]
                                        )


proc rowTwo(line: string): UICRmk =
    result.uicType = UIRMK
    result.rrcTapeRecordId = line <- [1,3]
    try:
        result.uicREMARKSKEY = UICremarksKEY(
                                                uicREMARKSRMK: line <- [3, 6],
                                                uicREMARKSLINE: line <- [6, 8]
                                                )
        result.uicREMARKSTYPE = line <- [8, 10]
        result.uicREMARKS = line <- [10, 70]
        result.uicREMARKID = line <- [70, 73]
        result.uicREMARKDATE = DaDAT(
                                        dACENTURY: line <- [73, 75],
                                        dAYEAR: line <- [75, 77],
                                        dAMONTH: line <- [77, 79],
                                        dADAY: line <- [79, 81]
                                        )
        result.filler = line <- [81, 88]
        result.filler2 = line <- [88, 88]
    except IndexDefect:
        result.filler = "ERROR - Index Defect"


proc rowThree(line: string): UICMontr = 
    result.uicType = UIMONTR
    result.rrcTapeRecordId = line <- [1, 3]
    result.uicMONTRWSTATUS = line <- [3, 4]
    result.uicMONTRFLUIDS = UICmontrFLUIDS(
                                            uicMONTRSW: line <- [4, 5],
                                            uicMONTRFW: line <- [5, 6],
                                            uicMONTRFRACWATER: line <- [6, 7],
                                            uicMONTRNRM: line <- [7, 8],
                                            uicMONTRCO2: line <- [8, 9],
                                            uicMONTRCO2A: line <- [9, 10],
                                            uicMONTRGAS: line <- [10, 11],
                                            uicMONTRH2S: line <- [11, 12],
                                            uicMONTRPOLYMER: line <- [12, 13],
                                            uicMONTRSTEAM: line <- [13, 14],
                                            uicMONTRAIR: line <- [14, 15],
                                            uicMONTRNITROGEN: line <- [15, 16],
                                            uicMONTROTH: line <- [16, 17],
                                            uicMONTRBW: line <- [17, 18],
                                            uicMONTRLPG: line <- [18, 19]
                                            )
    result.uicMONTRFLUIDSPCTS = UICmontrFLUIDSPCTS(
                                                    uicMONTRSWPCT: line <- [19, 22],
                                                    uicMONTRFWPCT: line <- [22, 25],
                                                    uicMONTRFRACWATERPCT: line <- [25, 28],
                                                    uicMONTRNORMPCT: line <- [28, 31],
                                                    uicMONTRCO2PCT: line <- [31, 34],
                                                    uicMONTRCO2APCT: line <- [34, 37],
                                                    uicMONTRGASPCT: line <- [37, 40],
                                                    uicMONTRH2SPCT: line <- [40, 43],
                                                    uicMONTRPOLYMERPCT: line <- [43, 46],
                                                    uicMONTRSTEAMPCT: line <- [46, 49],
                                                    uicMONTRAIRPCT: line <- [49, 52],
                                                    uicMONTRNITROGENPCT: line <- [52, 55],
                                                    uicMONTROTHERPCT: line <- [55, 58],
                                                    uicMONTRBWPCT: line <- [58, 61],
                                                    uicMONTRLPGPCT: line <- [61, 64]
                                                    )
    result.uicMONTREXCEPTIONS = UICmontrEXCEPTIONS(
                                                    uicMONTREXCALTTEST: line <- [64, 65],
                                                    uicMONTREXCALTTESTDATE: DaDAT( 
                                                                                    dACENTURY: line <- [65, 67],
                                                                                    dAYEAR: line <- [67, 69],
                                                                                    dAMONTH: line <- [69, 71],
                                                                                    dADAY: line <- [71, 73]
                                                                                    )

                                                    )
    result.uicMONTRRECFLG = line <- [73, 74]
    result.uicMONTRHOLD = line <- [74, 75]
    result.uicMONTRISSDTE = DaDAT(
                                    dACENTURY: line <- [75, 77],
                                    dAYEAR: line <- [77, 79],
                                    dAMONTH: line <- [79, 81],
                                    dADAY: line <- [81, 83]
                                    )
    result.uicMONTRRECDTE = DaDAT(
                                    dACENTURY: line <- [83, 85],
                                    dAYEAR: line <- [85, 87],
                                    dAMONTH: line <- [87, 89],
                                    dADAY: line <- [89, 91]
                                    )
    result.uicMONTR2NDNOTICE = DaDAT(
                                        dACENTURY: line <- [91, 93],
                                        dAYEAR: line <- [93, 95],
                                        dAMONTH: line <- [95, 97],
                                        dADAY: line <- [97, 99]
                                        )
    result.uicMONTRDELNOTICE = DaDAT(
                                        dACENTURY: line <- [99, 101],
                                        dAYEAR: line <- [101, 103],
                                        dAMONTH: line <- [103, 105],
                                        dADAY: line <- [105, 107]
                                        )
    result.uicMONTRCYCLECCYY = DaDAT(
                                        dACENTURY: line <- [107, 109],
                                        dAYEAR: line <- [109, 111]
                                        )
    result.uicMONTRFWAVGORMAX = line <- [111, 112]
    result.uicMONTRFWBBLSDAY = line <- [112, 117]
    result.uicMONTRFWSOURCE = line <- [117, 132]
    result.uicMONTRALTRPTING = line <- [132, 133]
    result.uicMONTROPTRPTING = line <- [133, 134]
    result.uicMONTRINJFLUFLAG = line <- [134, 135]
    result.uicMONTRFLUIDCMT = line <- [135, 210]
    result.uicMONTRWSTATCMT = line <- [210, 230]
    result.uicMONTRTOPINJZONE = line <- [230, 235]
    result.uicMONTRTBGCSGANNTSTDTE = DaDAT(
                                            dACENTURY: line <- [235, 237],
                                            dAYEAR: line <- [237, 239],
                                            daMONTH: line <- [239, 241]
                                            )
    result.uicMONTRPRESSGTZERO = line <- [241, 242]
    result.uicMONTRTBGCSGANNMON = line <- [242, 246]
    result.uicMONTRTBGCSGAVGREAD = line <- [246, 248]
    result.uicOLDSTATUS5FLAG = line <- [248, 249]
    result.uicNEWFORMFLAG = line <- [249, 250]
    result.uicMONTRDUEDATE = DaDAT(
                                    dAYEAR: line <- [250, 254],
                                    daMONTH: line <- [254, 256]
                                    )
    result.uicMONTRH10TYPEFLAG = line <- [256, 257]
    result.filler = line <- [257, 280]

proc rowFour(line: string): UICMNh10 =
    const forward = -2
    result.uicType = UIMNH10
    result.rrcTapeRecordId = line <- [1, 3]
    result.mnH10KEY = DaDAT(
                                dACENTURY: line <- [1, 3] ~ forward,
                                dAYEAR: line <- [3, 5] ~ forward,
                                dAMONTH: line <- [5, 7] ~ forward
                                )
    result.mnH10AVGINJPRESSURE = line <- [7, 11] ~ forward
    result.mnH10MAXINJPRESSURE = line <- [11, 15] ~ forward
    result.mnH10TOTALVOLBBL = line <- [15, 23] ~ forward
    result.mnH10TOTALVOLMCF = line <- [23, 31] ~ forward
    result.mnH10ANNULUSMINIMUM = line <- [31, 35] ~ forward
    result.mnH10ANNULUSMAXIMUM = line <- [35, 39] ~ forward 
    result.mnH10ANNULUSCOUNT = line <- [39, 41] ~ forward
    result.mnh10DOCUMENTID = MNh10dOCUMENTiD(
                                                mhH10DOCUMENTCYCLE: line <- [41, 45] ~ forward,
                                                mnH10DOCUMENTBATCH: line <- [45, 49] ~ forward,
                                                mnH10DOCUMENTITEM: line <- [49, 52] ~ forward
                                                )

proc rowFive(line: string): UICMNh10H =
    result.uicType = UIMNH10H
    result.rrcTapeRecordId = line <- [1, 3]
    result.mnH10HKEY = DaDAT(
                            dACENTURY: line <- [3, 5],
                            dAYEAR: line <- [5, 7],
                            dAMONTH: line <- [7, 9]
                            )
    result.mnH10HMAXHYDROCARBPSIG = line <- [9, 14]
    result.mnH10HMAXBRINEPSIG = line <- [14, 19]
    result.mnH10HINJBRINEBBLSSIGN = line <- [19, 20]
    result.mnH10HINJBRINEBBLS = line <- [20, 25]
    result.mnH10HINJHYDROBBLSSIGN = line <- [25, 26]
    result.mnH10HINJHYDROCARBBBLS = line <- [26, 31]
    result.mnH10HINJGASMCFSIGN = line <- [31, 32]
    result.mnH10HINJGASMCF = line <- [32, 37]
    result.mnH10HDOCUMENTID = MNh10dOCUMENTiD(
                                            mhH10DOCUMENTCYCLE: line <- [37, 41],
                                            mnH10DOCUMENTBATCH: line <- [41, 45],
                                            mnH10DOCUMENTITEM: line <- [45, 49]
                                            )

proc rowSix(line: string): UICmnrmk =
    result.uicType = UIMNH10H
    result.rrcTapeRecordId = line <- [1, 3]
    result.uicMNremarksSegment = MNremakrsSegment(
                                                    mnRemarksType: line <- [3, 5],
                                                    mnRemarks: line <- [5, 65],
                                                    filler: line <- [65, 68]
                                                    )

proc rowSeven(line: string): UICh5 = 
    result.uicType = UIH5
    result.rrcTapeRecordId = line <- [1, 3]
    result.uicH5KEY = UICh5KEY(
                                uicH5TESTDATEKEY: line <- [3, 11],
                                uicH5TESTSEQNUM: line <- [11, 13]
                                )
    result.uicH5SEGMPRIOR1992 = UICh5SEGMPRIOR1992(
                                                        uicH5DUEDATE: DaDAT(
                                                                             dACENTURY: line <- [13, 15],
                                                                             dAYEAR: line <- [15, 17],
                                                                             dAMONTH: line <- [17, 19],
                                                                             dADAY: line <- [19, 21]
                                                                             ),
                                                        uicH5RECEIVEDDATE: DaDAT(
                                                                                  dACENTURY: line <- [21, 23],
                                                                                  dAYEAR: line <- [23, 25],
                                                                                  dAMONTH: line <- [25, 27],
                                                                                  dADAY: line <- [27, 29]
                                                                                    ),
                                                        uicH5SCHEDULETYPE: line <- [29, 30],
                                                        uicH5SCHEDULEFLAG: line <- [30, 31],
                                                        uicH5SCHEDULEDDATE: DaDAT(
                                                                                    dACENTURY: line <- [31, 33],
                                                                                    dAYEAR: line <- [33, 35],
                                                                                    dAMONTH: line <- [35, 37],
                                                                                    dADAY: line <- [37, 39]
                                                                                    ),
                                                        uicH52NDNOTICEDATE: DaDAT(
                                                                                    dACENTURY: line <- [39, 41],
                                                                                    dAYEAR: line <- [41, 43],
                                                                                    dAMONTH: line <- [43, 45],
                                                                                    dADAY: line <- [45, 47]
                                                                                    ),
                                                        uicH5MITCYCLETYPE: line <- [47, 48],
                                                        uicH5MITCYCLETODATE: DaDAT(
                                                                                    dACENTURY: line <- [48, 50],
                                                                                    dAYEAR: line <- [50, 52],
                                                                                    dAMONTH: line <- [52, 54]
                                                                                    ),
                                                        uicH5PACKERDEPTH: line <- [54, 59],
                                                        uicH5TESTDATE: DaDAT(
                                                                             dACENTURY: line <- [59, 61],
                                                                             dAYEAR: line <- [61, 63],
                                                                             dAMONTH: line <- [63, 65],
                                                                             dADAY: line <- [65, 67]
                                                                             ),
                                                        uicH5COMPLTOPINJ: line <- [67, 72],
                                                        uicH5COMPLBOTINJ: line <- [72, 77],
                                                        uicH5TBGCSGMNTRDT: DaDAT(
                                                                                    dACENTURY: line <- [77, 79],
                                                                                    dAYEAR: line <- [79, 81],
                                                                                    dAMONTH: line <- [81, 83],
                                                                                    ),
                                                        )
    result.uicH5POSITIVEPRESS = line <- [83, 84]
    result.uicH5TESTDATE = line <- [84, 87]
    result.uicH5ALTERNATECODE = line <- [87, 88]
    result.uicH5WELLSTATUS = line <- [88, 89]
    result.uicH5WELLSTATUSCMT = line <- [89, 112]
    result.uicH5REASONFORTEST = line <- [112, 116]
    result.uicH5OTHERTESTREASON = line <- [116, 136]
    result.uicH5RETESTFLAG = line <- [136, 137]
    result.uicH5PRIORTESTDATE = DaDAT(
                                        dACENTURY: line <- [137, 139],
                                        dAYEAR: line <- [139, 141],
                                        dAMONTH: line <- [141, 143],
                                        dADAY: line <- [143, 145]
                                        )
    result.uicH5OTHERTESTSFLAG = line <- [145, 146]
    result.uicH5OTHERTESTSCOMM = line <- [146, 176]
    result.uicH5REPAIRSMADE = UICh5REPAIRSMADE(
                                                uicH5TUBING: line <- [176, 177],
                                                uicH5PACKER: line <- [177, 178],
                                                uicH5CASING: line <- [178, 179],
                                                uicH5WELLHEAD: line <- [179, 180],
                                                uicH5MISCREPAIRS: UICh5MISCREPAIRS(
                                                                                        uicH5MISCREPAIR: line <- [180, 181],
                                                                                        uicH5REPAIRCOMM: line <- [181, 201]
                                                                                        )
                                                )
    result.uicH5WITNESSEDFLAG = line <- [201, 202]
    result.uicH5TESTRESULTS = line <- [202, 203]
    result.uicH5INCONCLUSIVEREASONS = line <- [203, 239]
    result.uicH5LETTERSIGN = line <- [239, 240]
    result.uicH5INCONCLUSIVEOTHER = UICh5INCONCLUSIVEOTHER(
                                                            uicH5INCONCLU: line <- [240, 241],
                                                            uicH5INCONCLUCOMM: line <- [241, 263]
                                                            )
    result.uicH5ALTTESTCOMMENT = line <- [263, 292]
    result.uicH5P12ITEMS = line <- [292, 303]

proc rowEight(line: string): UICh5RMK =
    result.uicType = UIH5RMK
    result.rrcTapeRecordId = line <- [1, 3]
    try:
        result.h5REMARKSTYPE = line <- [3, 5]
        result.h5REMARKS = line <- [5, 65]
        result.filler = line <- [65, 68]
    except IndexDefect:
        result.h5REMARKS = "PARSE ERROR"

proc rowNine(line: string): UICenf =
    result.uicType = UIENF
    result.rrcTapeRecordId = line <- [1, 3]
    result.uicENFKEY = line <- [3, 4]
    result.uicENFMANFILEFLAG = line <- [4, 5]
    result.filler = line <- [5, 23]

proc rowTen(line: string): UICenFACT = 
    result.uicType = UIENFACT
    result.rrcTapeRecordId = line <- [1, 3]
    result.enfACTDATECODE = ENFactDATEcode(
                                            enfACTVIOLDATE: DaDAT(
                                                                    dACENTURY: line <- [3, 5],
                                                                    dAYEAR: line <- [5, 7],
                                                                    dAMONTH: line <- [7, 9],
                                                                    dADAY: line <- [9, 11]
                                                                    ),
                                            enfACTVIOLCODE: line <- [11, 13]
                                            )
    result.enfACTNOTICEDATE = DaDAT(
                                    dACENTURY: line <- [13, 15],
                                    dAYEAR: line <- [15, 17],
                                    dAMONTH: line <- [17, 19],
                                    dADAY: line <- [19, 21]
                                    )
    result.enfACTNOTICETYPE = line <- [21, 23]
    result.enfACTCOMPDATE = DaDAT(
                                    dACENTURY: line <- [23, 25],
                                    dAYEAR: line <- [25, 27],
                                    dAMONTH: line <- [27, 29],
                                    dADAY: line <- [29, 31]
                                    )
    result.enfACTCOMPMETHOD = line <- [31, 33]
    result.enfACTSNCFLAG = line <- [33, 34]
    result.enfACTVIOLONHOLDFLAG = line <- [34, 35]
    result.filler = line <- [35, 43]

proc rowEleven(line: string): UICenfOTH =
    result.uicType = UIENFOTH
    result.rrcTapeRecordId = line <- [1, 3]
    try:
        result.enfOTHCOMPMETHOD = line <- [3, 7]
        result.enfOTHENFORCETYPE = line <- [7, 12]
        result.enfOTHCOMPLAINTNUM = line <- [12, 22]
        result.filler = line <- [22, 40]
    except IndexDefect:
        result.filler = "PARSE ERROR"

proc rowTwelve(line: string): UICenfRMK =
    result.uicType = UIENFOTH
    result.rrcTapeRecordId = line <- [1, 3]
    try:
        result.enfREMARKSTYPE = line <- [3, 5]
        result.enfREMARKS = line <- [5, 65]
        result.filler = line <- [65, 68]
    except IndexDefect:
        result.filler = "PARSE ERROR"

proc rowThirteen(line: string): UICmon10H =
    result.uicType = UIMON10H
    result.rrcTapeRecordId = line <- [1, 3]
    result.uicH10HMONTRKEY = line <- [3, 9]
    result.uicH10HMONTRDATE = line <- [9, 15]
    result.uicH10HMONTRDATE2 = DaDAT(
                                      dACENTURY: line <- [9, 11],
                                      dAYEAR: line <- [11, 13],
                                      dAMONTH: line <- [13, 15],
                                      )
    result.uicH10HMONTRWSTATUS = line <- [15, 16]
    result.uicH10HMONTRFLUIDS = UICh10HMONTRFLUIDS(
                                                    uicH10HMONTRCRUDE: line <- [16, 17],
                                                    uicH10HMONTRGAS: line <- [17, 18],
                                                    uicH10HMONTRLPG: line <- [18, 19],
                                                    uicH10HMONTROTHER: line <- [19, 20]
                                                    )
    result.uicH10HMONTRPRESSGTZERO = line <- [20, 21]
    result.uicH10HMONTRSURFACEVESSEL = line <- [21, 22]
    result.uicH10HMONTRRECFLG = line <- [22, 23]
    result.uicH10HMULTWELLCAVERNFLAG = line <- [23, 24]
    result.uicH10HMONTRISSDTE = DaDAT(
                                      dACENTURY: line <- [24, 26],
                                      dAYEAR: line <- [26, 28],
                                      dAMONTH: line <- [28, 30],
                                      dADAY: line <- [30, 32]
                                      )
    result.uicH10HMONTRRECDTE = DaDAT(
                                      dACENTURY: line <- [32, 34],
                                      dAYEAR: line <- [34, 36],
                                      dAMONTH: line <- [36, 38],
                                      dADAY: line <- [38, 40]
                                      )
    result.uicH10HMONTR2NDNOTICE = DaDAT(
                                      dACENTURY: line <- [40, 42],
                                      dAYEAR: line <- [42, 44],
                                      dAMONTH: line <- [44, 46],
                                      dADAY: line <- [46, 48]
                                      )
    result.uicH10HMONTRDELNOTICE = DaDAT(
                                            dACENTURY: line <- [48, 50],
                                            dAYEAR: line <- [50, 52],
                                            dAMONTH: line <- [52, 54],
                                            dADAY: line <- [54, 56]
                                            )
    result.uicH10HMONTRCYCLECCYR = DaDAT(
                                            dACENTURY: line <- [56, 58],
                                            dAYEAR: line <- [58, 60],
                                            )
    result.uicH10HCAVERNCAPACITY = line <- [60, 68]
    result.uicH10HMAXMBBLS = line <- [68, 76]
    result.uicH10HMAXMCF = line <- [76, 84]
    result.uicH10HINVENTORYOFMBBLS = line <- [84, 92]
    result.uicH10HINVENTORYOFMCF = line <- [92, 100]
    result.uicH10HOTHERWELL1 = line <- [100, 106]
    result.uicH10HOTHERWELL2 = line <- [106, 112]
    result.uicH10HOTHERWELL3 = line <- [112, 118]
    result.uicH10HMONTRWSTATCMT = line <- [118, 138]
    result.uicH10HPRODUCTSPECIFIC = line <- [138, 178]
    result.uicH10HNEWFORMFLAG = line <- [178, 179]
    result.uicH10HMONTRDUEDATE = DaDAT(
                                        dACENTURY: line <- [179, 183],
                                        dAMONTH: line <- [183, 185],
                                        )
    result.uicH10HMONTRFLAG = line <- [185, 186]
    result.filler = line <- [186, 203]

proc rowFourTeen(line: string): UICh10VIO =
    result.uicType = UIH10VIO
    result.rrcTapeRecordId = line <- [1, 3]
    result.uicH10VIOLBEGINDATE = DaDAT(
                                        dACENTURY: line <- [3, 7],
                                        dAMONTH: line <- [7, 9],
                                        )
    result.uicH10VIOLENDDATE = DaDAT(
                                      dACENTURY: line <- [9, 13],
                                      dAMONTH: line <- [13, 15],
                                      )
    result.uicH10VIOLCODE = line <- [15, 17]
    result.uicH10VIOLLETTERKEY = line <- [17, 25]
    result.uicH10VIOLLETTERDATE = DaDAT(
                                            dAYEAR: line <- [25, 29],
                                            dAMONTH: line <- [29, 31],
                                            dADAY: line <- [31, 33]
                                            )
    result.uicH10VIOLRESOLVEDATE = DaDAT(
                                            dAYEAR: line <- [33, 37],
                                            dAMONTH: line <- [37, 39],
                                            dADAY: line <- [39, 41]
                                            )
    result.uicH10VIOLRESOLVEBYFLAG = line <- [41, 42]
    result.uicH10VIOLP4CERTLTRKEY = UICh10VIOLp4CERTltrKEY(
                                                            uicH10VIOLP4CERTDTEKEY: line <- [42, 50],
                                                            uicH10VIOLP4CERTSECTION: line <- [50, 52],
                                                            uicH10VIOLP4CERTREASON: line <- [52, 54]
                                                            )
    result.uicH10VIOLSEVERLTRDATE = DaDAT(
                                            dAYEAR: line <- [54, 58],
                                            dAMONTH: line <- [58, 60],
                                            dADAY: line <- [60, 62]
                                            )
    result.uicH10VIOLONHOLDFLAG = line <- [62, 63]
    result.filler = line <- [63, 103]

proc parseLine*(obj: var FinalInjectionObject, line: string) =
    let row = line[0..1]
    case row:
        of "01":
            obj.uicRoot = line.rowOne()
            #echo %rowOne(line)
        of "02":
            obj.uicRMK = line.rowTwo()
            #echo %rowTwo(line)
        of "03":
            obj.uicMONTR = line.rowThree()
            #echo %rowThree(line)
        of "04":
            obj.uicMNh10 = line.rowFour()
           # echo %rowFour(line)
        of "05":
            obj.uicMNh10H = line.rowFive()
           # echo %rowFive(line)
        of "06":
            obj.uicMNRMK = line.rowSix()
           # echo %rowSix(line)
        of "07":
            obj.uicH5 = line.rowSeven()
            #echo %rowSeven(line)
        of "08":
            obj.uicH5RMK = line.rowEight()
            #echo %rowEight(line)
        of "09":
            obj.uicEnf = line.rowNine()
            #echo %rowNine(line)
        of "10":
            obj.uicENFACT = line.rowTen()
            #echo %rowTen(line)
        of "11":
            obj.uicENFOTH = line.rowEleven()
            #echo %rowEleven(line)
        of "12":
            obj.uicENFRMK = line.rowTwelve()
            #echo %rowTwelve(line)
        of "13":
            obj.uicMON10H = line.rowThirteen()
            #echo %rowThirteen(line)
        of "14":
            obj.uicH10VIO = line.rowFourTeen()
            #echo %rowFourTeen(line)

template checkE*(d: FinalInjectionObject, list: seq[string], body) =
    case list.len:
    of 0:
        body
    else:
        if not list.contains(d.uicRoot.uicCNTLNO):
            body
