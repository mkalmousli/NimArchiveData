import types, aiders, strutils, json

proc rowOne(line: string): Root = 
    result.daType = DAROOT
    result.rrcTapeRecordId = line <- [1,3]
    result.daStatusRoot.daPrimaryKey.daStatusNumber = line <- [3, 10]
    result.daStatusRoot.daPrimaryKey.daStatusSequenceNumber = line <- [10, 12]
    result.daStatusRoot.daSecondaryKeys.daCountyCode = line <- [12, 15]
    result.daStatusRoot.daSecondaryKeys.daLeaseName = line <- [15, 47]
    result.daStatusRoot.daSecondaryKeys.daDistrict = line <- [47, 49]
    result.daStatusRoot.daSecondaryKeys.daOperatorNumber = line <- [49, 55]
    result.daStatusRoot.daSecondaryKeys.daConvertedDate = line <- [55, 59]
    result.daStatusRoot.daSecondaryKeys.daDateAppReceived = DaDAT(dACENTURY: line <- [59, 61], 
                                                                    dAYEAR: line <- [61, 63], 
                                                                    dAMONTH: line <- [63, 65], 
                                                                    dADAY: line <- [65, 67]
                                                                )
    result.daOperatorName = line <- [67, 99]
    result.hB1407PROBLEM = line <- [100, 101]
    result.dASTATUSOFAPPFLAG = line <- [101, 102]
    result.dAPROBLEMFLAGS =  DaPROBLEMFLAGS(dANOTENOUGHMONEYFLAG: line <- [102, 103],
                                                dATOOMUCHMONEYFLAG: line <- [103, 104],
                                                dAP5PROBLEMFLAG: line <- [104, 105],
                                                dAP12PROBLEMFLAG: line <- [105, 106],
                                                dAPLATPROBLEMFLAG: line <- [106, 107],
                                                dAW1APROBLEMFLAG: line <- [107, 108],
                                                dAOTHERPROBLEMFLAG: line <- [108, 109],
                                                dARULE37PROBLEMFLAG: line <- [109, 110],
                                                dARULE38PROBLEMFLAG: line <- [110, 111],
                                                dARULE39PROBLEMFLAG: line <- [111, 112],
                                                dANOMONEYFLAG: line <- [112, 113]
                                            )
    result.daPermit = line <- [113, 120]
    result.daIssueDat = DaDAT(dACENTURY: line <- [120, 122],
                                dAYEAR: line <- [122, 124],
                                dAMONTH: line <- [124, 126], 
                                dADAY: line <- [126, 128]
                            )
    result.daWithdraw = DaDAT(dACENTURY: line[127..128].strip(), 
                                dAYEAR: line[129..130].strip(), 
                                dAMONTH: line[130..132].strip(), 
                                dADAY: line[133..134].strip()
                            )
    result.dAWALKTHROUGHFLAG = line <- [136, 137]
    result.dAOTHERPROBLEMTEXT = line <- [137, 157]
    result.dAWELLNUMBER = line <- [157, 163]
    result.dABUILTFROMOLDMASTERFLAG = line <- [163, 164]
    result.dASTATUSRENUMBEREDTO = line <- [164, 173]
    result.dASTATUSRENUMBEREDFROM = line <- [173, 182]
    result.dAAPPLICATIONRETURNEDFLAG = line <- [182, 183]
    result.dAECAPFILINGFLAG = line <- [183, 184]


proc rowTwo(line: string): PermitMaster =
    const back = 2
    result.daType = DAPERMIT
    result.rrcTapeRecordId = line <- [1, 3]
    result.rrcTapeRecordId2 = line <- [3, 5]
    let 
        daPermitKey = DaPermitKey(daPermitNumber: line <- [5, 12] ~ back, 
                                                        daPermitSequenceNumber: line <- [12, 14] ~ back
                                                    )
        daZIPCode = DaZIPCode(dAZIPCODEPREFIX: line <- [106, 111] ~ back, dAZIPCODESUFFIX: line <- [111, 115] ~ back)
        dARECEIVEDDATE = DaDAT(dACENTURY: line <- [124, 126] ~ back,
                                    dAYEAR: line <- [126, 128] ~ back,
                                    dAMONTH: line <- [128, 130] ~ back,
                                    dADAY: line <- [130, 132] ~ back
                                )
        dAPERMITISSUEDDATE = DaDAT(dACENTURY: line <- [132, 134] ~ back,
                                    dAYEAR: line <- [134, 136] ~ back,
                                    dAMONTH: line <- [136, 138] ~ back,
                                    dADAY: line <- [138, 140] ~ back
                                )
        dAPERMITAMENDEDDATE = DaDAT(dACENTURY: line <- [140, 142] ~ back,
                                    dAYEAR: line <- [142, 144] ~ back,
                                    dAMONTH: line <- [144, 146] ~ back,
                                    dADAY: line <- [146, 148] ~ back
                                )
        dAPERMITEXTENDEDDATE = DaDAT(dACENTURY: line <- [148, 150] ~ back,
                                    dAYEAR: line <- [150, 152] ~ back,
                                    dAMONTH: line <- [152, 154] ~ back,
                                    dADAY: line <- [154, 156] ~ back
                                )
        dAPERMITSPUDDATE = DaDAT(dACENTURY: line <- [156, 158] ~ back,
                                    dAYEAR: line <- [158, 160] ~ back,
                                    dAMONTH: line <- [160, 162] ~ back,
                                    dADAY: line <- [162, 164] ~ back
                                )
        dAPERMITSURFACECASINGDATE = DaDAT(dACENTURY: line <- [164, 166] ~ back,
                                    dAYEAR: line <- [166, 168] ~ back,
                                    dAMONTH: line <- [168, 170] ~ back,
                                    dADAY: line <- [170, 172] ~ back
                                )
        dAPERMITWELLSTATUSDATE = DaDAT(dACENTURY: line <- [173, 175] ~ back,
                                    dAYEAR: line <- [175, 177] ~ back,
                                    dAMONTH: line <- [177, 179] ~ back,
                                    dADAY: line <- [179, 181] ~ back
                                )
        dAPERMITEXPIREDDATE = DaDAT(dACENTURY: line <- [181, 183] ~ back,
                                    dAYEAR: line <- [183, 185] ~ back,
                                    dAMONTH: line <- [185, 187] ~ back,
                                    dADAY: line <- [187, 189] ~ back
                                )
        dAPERMITCANCELLEDDATE = DaDAT(dACENTURY: line <- [189, 191] ~ back,
                                    dAYEAR: line <- [191, 193] ~ back,
                                    dAMONTH: line <- [193, 195] ~ back,
                                    dADAY: line <- [195, 197] ~ back
                                )
        dANEWSURFACELOCATION = DaNEWSURFACELOCATION(dASURFACESECTION: line <- [246, 254] ~ back,
                                                        dASURFACEBLOCK: line <- [254, 264] ~ back,
                                                        dASURFACESURVEY: line <- [264, 319] ~ back,
                                                        dASURFACEABSTRACT: line <- [319, 325] ~ back,
                                                        filler: line <- [325, 328] ~ back
                                                    )
        dASURFACELEASEDISTANCE = DaSURFDistance(dASURFACELEASEFEET1: line <- [361, 369] ~ back,
                                                                dASURFACELEASEDIRECTION1: line <- [369, 382] ~ back,
                                                                dASURFACELEASEFEET2: line <- [382, 390] ~ back,
                                                                dASURFACELEASEDIRECTION2: line <- [390, 403] ~ back
                                                            )
        dASURFACESURVEYDISTANCE = DaSURFDistance(dASURFACELEASEFEET1: line <- [403, 411] ~ back,
                                                                dASURFACELEASEDIRECTION1: line <- [411, 424] ~ back,
                                                                dASURFACELEASEFEET2: line <- [424, 432] ~ back,
                                                                dASURFACELEASEDIRECTION2: line <- [432, 445] ~ back
                                                            )
        dAFINALUPDATE = DaDAT(dACENTURY: line <- [474, 476] ~ back,
                                    dAYEAR: line <- [476, 478] ~ back,
                                    dAMONTH: line <- [478, 480] ~ back,
                                    dADAY: line <- [480, 482] ~ back
                                )
    result.daPermitSegment = DaPermitSegment(daPermitKey: daPermitKey,
                                                dAPERMITCOUNTYCODE: line <- [14, 17] ~ back,
                                                dAPERMITLEASENAME: line <- [17, 49] ~ back,
                                                dAPERMITDISTRICT: line <- [49, 51] ~ back,
                                                dAPERMITWELLNUMBER: line <- [51, 57] ~ back,
                                                dAPERMITTOTALDEPTH: line <- [57, 62] ~ back,
                                                dAPERMITOPERATORNUMBER: line <- [62, 68] ~ back,
                                                dATYPEAPPLICATION: line <- [68, 70] ~ back,
                                                dAOTHEREXPLANATION: line <- [70, 100] ~ back,
                                                dAADDRESSUNIQUENUMBER: line <- [100, 106] ~ back,
                                                daZIPCode: daZIPCode,
                                                dAFICHESETNUMBER: line <- [115, 121] ~ back,
                                                dAONSHORECOUNTY: line <- [121, 124] ~ back, 
                                                dARECEIVEDDATE: dARECEIVEDDATE,
                                                dAPERMITISSUEDDATE: dAPERMITISSUEDDATE,
                                                dAPERMITAMENDEDDATE: dAPERMITAMENDEDDATE,
                                                dAPERMITEXTENDEDDATE: dAPERMITEXTENDEDDATE,
                                                dAPERMITSPUDDATE: dAPERMITSPUDDATE,
                                                dAPERMITSURFACECASINGDATE: dAPERMITSURFACECASINGDATE,
                                                dAWELLSTATUS: line <- [172, 173] ~ back,
                                                dAPERMITWELLSTATUSDATE: dAPERMITWELLSTATUSDATE,
                                                dAPERMITEXPIREDDATE: dAPERMITEXPIREDDATE,
                                                dAPERMITCANCELLEDDATE: dAPERMITCANCELLEDDATE,
                                                dACANCELLATIONREASON: line <- [197, 227] ~ back,
                                                dAP12FILEDFLAG: line <- [227, 228] ~ back,
                                                dASUBSTANDARDACREAGEFLAG: line <- [228, 229] ~ back,
                                                dARULE36FLAG: line <- [229, 230] ~ back,
                                                dAH9FLAG: line <- [230, 231] ~ back,
                                                dARULE37CASENUMBER: line <- [231, 238] ~ back,
                                                dARULE38DOCKETNUMBER: line <- [238, 245] ~ back,
                                                dALOCATIONFORMATIONFLAG: line <- [245, 246] ~ back,
                                                dANEWSURFACELOCATION: dANEWSURFACELOCATION,
                                                dASURFACEACRES: line <- [328, 336] ~ back,
                                                dASURFACEMILESFROMCITY: line <- [336, 342] ~ back,
                                                dASURFACEDIRECTIONFROMCITY: line <- [342, 348] ~ back,
                                                dASURFACENEARESTCITY: line <- [348, 361] ~ back,
                                                dASURFACELEASEDISTANCE: dASURFACELEASEDISTANCE,
                                                dASURFACESURVEYDISTANCE: dASURFACESURVEYDISTANCE,
                                                dANEARESTWELL: line <- [445, 473] ~ back,
                                                dANEARESTWELLFORMATFLAG: line <- [473, 474] ~ back,
                                                dACANCELLEDFLAG: line <- [482, 483] ~ back,
                                                dASPUDINFLAG: line <- [483, 484] ~ back,
                                                dADIRECTIONALWELLFLAG: line <- [484, 485] ~ back,
                                                dASIDETRACKWELLFLAG: line <- [485, 486] ~ back,
                                                dAMOVEDINDICATOR: line <- [486, 487] ~ back,
                                                dAPERMITCONVISSUEDDATE: line <- [487, 495] ~ back,
                                                dARULE37GRANTEDCODE: line <- [495, 496] ~ back,
                                                dAHORIZONTALWELLFLAG: line <- [496, 497] ~ back,
                                                dADUPLICATEPERMITFLAG: line <- [497, 498] ~ back,
                                                dANEARESTLEASELINE: line <- [498, 505] ~ back,
                                                dAFINALUPDATE: dAFINALUPDATE,
                                                apiNumber: line <- [505, 513] ~ back
                                            )
    
proc rowThree(line: string): FieldSegment =
    result.daType = DAFIELD
    result.rrcTapeRecordId = line <- [1, 3]
    result.dAFIELDNUMBER = line <- [3, 11]
    result.dAFIELDAPPLICATIONWELLCODE = line <- [11, 12]
    result.dAFIELDCOMPLETIONWELLCODE = line <- [12, 13]
    result.dAFIELDCOMPLETIONCODE = line <- [13, 14]
    result.dAFIELDTRANSFERCODE = line <- [14, 15]
    result.dAFIELDVALIDATIONDATE = DaDAT(dACENTURY: line <- [15, 17],
                                            dAYEAR: line <- [17, 19],
                                            dAMONTH: line <- [19, 21],
                                            dADAY: line <- [21, 23]
                                        )
    result.dAFIELDCOMPLETIONDATE = DaDAT(dACENTURY: line <- [23, 25],
                                            dAYEAR: line <- [25, 27],
                                            dAMONTH: line <- [27, 29],
                                            dADAY: line <- [29, 31]
                                        )
    result.dAFIELDRULE37FLAG = line <- [31, 32]
    result.dAFIELDRULE38FLAG = line <- [32, 33]

proc rowFour(line: string): FieldSpecificDataSegement =
    result.daType = DAFLDSPC
    result.rrcTapeRecordId = line <- [1,3]
    result.dAFIELDDISTRICT = line <- [3, 5]
    result.dAFIELDLEASENAME = line <- [5, 37]
    result.dAFIELDTOTALDEPTH = line <- [37, 42]
    result.dAFIELDWELLNUMBER = line <- [46, 56]
    result.dAFIELDACRES = line <- [46, 56]

proc rowFive(line: string): FieldBottomHoleLocationSegment =
    result.daType = DAFLDBHL
    result.rrcTapeRecordId = line <- [1,3]
    result.dAFLDBHLSECTION = line <- [3, 11]
    result.dAFLDBHLBLOCK = line <- [11, 21]
    result.dAFLDBHLABSTRACT = line <- [21, 27]
    result.dAFLDBHLSURVEY = line <- [27, 82]
    result.dAFLDBHLACRES = line <- [82, 90]
    result.dAFLDBHLNEARESTWELL = line <- [90, 118]
    result.dAFLDBHLLEASEFEET1 = line <- [118, 126]
    result.dAFLDBHLLEASEDIRECTION1 = line <- [126, 139]
    result.dAFLDBHLLEASEFEET2 = line <- [139, 147]
    result.dAFLDBHLLEASEDIRECTION2 = line <- [147, 160]
    result.dAFLDBHLSURVEYFEET1 = line <- [160, 168]
    result.dAFLDBHLSURVEYDIRECTION1 = line <- [168, 181]
    result.dAFLDBHLSURVEYFEET2 = line <- [181, 189]
    result.dAFLDBHLSURVEYDIRECTION2 = line <- [189, 202]
    result.dAFLDBHLCOUNTY = line <- [202, 215]
    result.dAFLDBHLPNTRTDIST1 = line <- [215, 223]
    result.dAFLDBHLPNTRTDIR1 = line <- [223, 236]
    result.dAFLDBHLPNTRTDIST2 = line <- [236, 244]
    result.dAFLDBHLPNTRTDIR2 = line <- [244, 257]

proc rowSix(line: string): CannedRestrictions =
    result.daType = DACANRES
    result.rrcTapeRecordId = line <- [1,3]
    result.dACANRESTRKEY = line <- [3, 5]
    result.dACANRESTRTYPE = line <- [5, 7]
    result.dACANRESTRREMARKOld = line <- [7, (7 + 35)]

proc rowSeven(line: string): CannedRestrictionFields =
    result.daType = DACANFLD
    result.rrcTapeRecordId = line <- [1,3]
    result.dACANRESTRFLDNUMBER = line <- [3, 11]

proc rowEight(line: string): FreeFormRestrictions =
    result.daType = DAFRERES
    result.rrcTapeRecordId = line <- [1,3]
    result.dAFREERESTRKEY = line <- [3, 5]
    result.dAFREERESTRTYPE = line <- [5, 7]
    try:
        result.dAFREERESTRREMARK = line <- [7, 77]
        result.dAFREERESTRFLAG = line <- [77, 78]
    except IndexDefect:
        result.dAFREERESTRREMARK = "ERROR"
        result.dAFREERESTRFLAG = "ERROR"

proc rowNine(line: string): FreeFormRestrictionFields = 
    result.daType = DAFREFLD
    result.rrcTapeRecordId = line <- [1,3]
    result.dAFREERESTRFLDNUMBER = line <- [3, 11]

proc rowTen(line: string): BottomHoleLocationSegement =
    result.daType = DAPMTBHL
    result.rrcTapeRecordId = line <- [1,3]
    result.dAPMTBHLSECTION = line <- [3, 11]
    result.dAPMTBHLBLOCK = line <- [11, 21]
    result.dAPMTBHLABSTRACT = line <- [21, 27]
    result.dAPMTBHLSURVEY = line <- [27, 82]
    result.dAPMTBHLACRES = line <- [82, 90]
    result.dAPMTBHLNEARESTWELL = line <- [90, 118]
    result.dAPMTBHLLEASEFEET1 = line <- [118, 126]
    result.dAPMTBHLLEASEDIRECTION1 = line <- [126, 139]
    result.dAPMTBHLLEASEFEET2 = line <- [139, 147]
    result.dAPMTBHLLEASEDIRECTION2 = line <- [147, 160]
    result.dAPMTBHLSURVEYFEET1 = line <- [160, 168]
    result.dAPMTBHLSURVEYDIRECTION1 = line <- [168, 181]
    result.dAPMTBHLSURVEYFEET2 = line <- [181, 189]
    result.dAPMTBHLSURVEYDIRECTION2 = line <- [189, 202]
    result.dAPMTBHLCOUNTY = line <- [202, 215]
    result.dAPMTBHLPNTRTDIST1 = line <- [215, 223]
    result.dAPMTBHLPNTRTDIR1 = line <- [223, 236]
    result.dAPMTBHLPNTRTDIST2 = line <- [236, 244]
    result.dAPMTBHLPNTRTDIR2 = line <- [244, 257]

proc rowEleven(line: string): AlternateAddressSegment =
    result.daType = DAALTADD
    result.rrcTapeRecordId = line <- [1,3]
    result.alternateAddress = AlternateAddress(dAALTADDRESSKEY: line <- [3, 5],
                                                dAALTADDRESSLINE1: line <- [5, 6]
                                              )

proc rowTwelve(line: string): PermitRemarks =
    result.daType = DAREMARK
    result.rrcTapeRecordId = line <- [1,3]
    result.dAREMARKSEQUENCENUMBER = line <- [3, 6]
    result.dAREMARKFILEDATE = DaDAT(dACENTURY: line <- [6, 8],
                                            dAYEAR: line <- [8, 10],
                                            dAMONTH: line <- [10, 12],
                                            dADAY: line <- [12, 14]
                                        )
    result.dAREMARKLINE = line <- [14, 84]

proc rowThirteen(line: string): CheckRegisterSegment =
    result.daType = DACHECK
    result.rrcTapeRecordId = line <- [1,3]
    result.dACHECKREGISTERKEY = DaCHECKREGISTERKEY(
                                                    dACHECKREGISTERDATE: DaDAT(dACENTURY: line <- [3, 5],
                                                      dAYEAR: line <- [5, 7],
                                                      dAMONTH: line <- [7, 9],
                                                      dADAY: line <- [9, 11]
                                                    ),
                                                    dACHECKREGISTERNUMBER: line <- [11, 19]
                                                  )

proc rowFourTeen(line: string): GisSurfaceLocationCoordinates =
    result.daType = DAW999A1
    result.rrcTapeRecordId = line <- [1,3]
    let 
        size = len(line) - 1
        coords = line[2..size]
        coordProcessed = coords.split(" ")
    #echo(coordProcessed)
    var finalCoords: seq[float]
    for coor in coordProcessed:
        if coor != "":
            let numCoord = coor.parseFloat()
            finalCoords.add(numCoord)
    #echo finalCoords
    result.coordinates = finalCoords

proc rowFifteen(line: string): GisBottomHoleLocationCoordinates =
    result.daType = DAW999B1
    result.rrcTapeRecordId = line <- [1,3]
    let 
        size = len(line) - 1
        coords = line[2..size]
        coordProcessed = coords.split(" ")
    #echo(coordProcessed)
    var finalCoords: seq[float]
    for coor in coordProcessed:
        if coor != "":
            let numCoord = coor.parseFloat()
            finalCoords.add(numCoord)
    #echo finalCoords
    result.coordinates = finalCoords

proc parseLine*(obj: var FinalDrillingObject, line: string) =
    let row = line[0..1]
    case row:
        of "01":
            obj.root = line.rowOne()
            #echo %rowOne(line)
        of "02":
            obj.permitMaster = line.rowTwo()
            #echo %rowTwo(line)
        of "03":
            obj.fieldSegment.add line.rowThree()
            #echo %rowThree(line)
        of "04":
            obj.fieldSpecificDataSegement = line.rowFour()
            #echo %rowFour(line)
        of "05":
            obj.fieldBottomHoleLocationSegment = line.rowFive()
            #echo %rowFive(line)
        of "06":
            obj.cannedRestrictions.add line.rowSix()
            #echo %rowSix(line)
        of "07":
            obj.cannedRestrictionFields.add line.rowSeven()
            #echo %rowSeven(line)
        of "08":
            obj.freeFormRestrictions.add line.rowEight()
            #echo %rowEight(line)
        of "09":
            obj.freeFormRestrictionFields.add line.rowNine()
            #echo %rowNine(line)
        of "10":
            obj.bottomHoleLocationSegement = line.rowTen()
            #echo %rowTen(line)
        of "11":
            obj.alternateAddressSegment = line.rowEleven()
            #echo %rowEleven(line)
        of "12":
            obj.permitRemarks.add line.rowTwelve()
            #echo %rowTwelve(line)
        of "13":
            obj.checkRegisterSegment.add line.rowThirteen()
            #echo %rowThirteen(line)
        of "14":
            obj.gisSurfaceLocationCoordinates.add line.rowFourTeen()
            #echo %rowFourTeen(line)
        of "15":
            obj.disBottomHoleLocationCoordinates.add line.rowFifteen()
            #echo %rowFifteen(line)
