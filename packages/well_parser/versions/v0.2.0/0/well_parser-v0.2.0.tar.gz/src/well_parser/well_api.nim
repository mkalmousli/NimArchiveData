import types, aiders, strutils, json

#[
    It's not working

proc uniqueRow*(line: string): FinalWellObject =
    result.maType = MAF016
    result.mAF016QUADNUM = line <- [1, 8]
    result.mAF016APINUM = line <- [8, 16]
    result.mAF016SURVEY = line <- [16, 71]
    result.mAF016BLOCK = line <- [71, 81]
    result.mAF016SECTION = line <- [81, 89]
    result.mAF016ABSTRACT = line <- [89, 95]
    result.mAF016OPERATOR = line <- [95, 127]
    result.mAF016TOTALDEPTH = line <- [127, 132]
    result.mAF016WELLNUMBER = line <- [132, 138]
    result.mAF016LEASENAME = line <- [138, 170]
    result.mAF016PERMITNUM = line <- [170, 176]
    result.mAF016GASRRCID = line <- [176, 182]
    result.mAF016FIELDNAME = line <- [182, 214]
    result.mAF016COMPLETIONDATE = line <- [214, 222]
    result.mAF016PLUGDATE = line <- [222, 230]
    result.mAF016REFERTOAPI = line <- [230, 238]
    result.mAF016ONOFFSCHEDULE = line <- [238, 239]
    result.mAF016OILGASCODE = line <- [239, 240]

    ]#