import macros, anonimongo

proc obToBson*[T: object](obj: T): BsonDocument

proc obToBson*(sequence: seq[object]): seq[BsonBase] =
  var listNew = newSeq[BsonBase]()
  for stuff in sequence:
    let bs = obToBson(stuff)
    listNew.add(bs)
  return(listNew)

proc obToBson*(sequence: seq[string]): seq[BsonBase] =
  var listNew = newSeq[BsonBase]()
  for stuff in sequence:
    listNew.add(stuff)
  return(listNew)

proc obToBson*(sequence: seq[float]): seq[BsonBase] =
  var listNew = newSeq[BsonBase]()
  for stuff in sequence:
    let ss = stuff.toBson()
    listNew.add(ss)
  return(listNew)

proc obToBson*(sequence: seq[int | int64]): seq[BsonBase] =
  var listNew = newSeq[BsonBase]()
  for stuff in sequence:
    let ss = stuff.obToBson()
    listNew.add(ss)
  return(listNew)

proc obToBson*(number: int64 | int): BsonBase =
  if number notin -2147483648 .. 2147483647:
    let finalNumber: int64 = number.int64
    result = finalNumber
    result.kind = bkInt64
  else:
    let finalNumber: int = number.int
    result = finalNumber
    result.kind = bkInt32

proc obToBson*[T: object](obj: T): BsonDocument =
  result = bson()
  for k, v in obj.fieldPairs:
    when type(v) is seq:
      result[k] = obToBson(v)
    elif type(v) is enum:
      result[k] = $v
    elif type(v) is string:
      result[k] = v
    elif type(v) is float:
      result[k] = v
    elif type(v) is int or type(v) is int64 or type(v) is int32:
      let 
        d = obToBson(v)
      result[k] = d
    elif type(v) is object:
      result[k] = obToBson(v)

proc parseStuff(s: NimNode, f: int, to: int): NimNode = 
    var stringData: NimNode 
    if s.kind == nnkSym: 
        stringData = newIdentNode(s.toStrLit().strVal)
    elif s.kind == nnkStrLit:
        stringData = newLit(s)

    result = nnkStmtList.newTree(
                nnkCall.newTree(
                    nnkDotExpr.newTree(
                    nnkBracketExpr.newTree(
                        stringData,
                        nnkInfix.newTree(
                        newIdentNode(".."),
                        newLit(f),
                        newLit(to)
                        )
                    ),
                    newIdentNode("strip")
                    )
                )
                )

macro `<-`*(s: string, move: array[0..1, int | int64]): untyped =
    let 
        f = move[0].intVal - 1
        to = move[1].intVal - 2
    let e = parseStuff(s, f, to)
    result = e

macro `~`*(a: array[0..1, int], i:int): untyped =
   # echo i.toStrLit
    let
        f: int = a[0].intVal
        to: int = a[1].intVal
    var intData: NimNode 
    if i.kind == nnkSym: 
        intData = newLit(i.intVal)
    elif i.kind == nnkIntLit:
        intData = newLit(i.intVal)

    let s = nnkStmtList.newTree(
                nnkBracket.newTree(
                    nnkInfix.newTree(
                    newIdentNode("-"),
                    newLit(f),
                    intData),
                    nnkInfix.newTree(
                    newIdentNode("-"),
                    newLit(to),
                    intData)
                    )
                )
    #echo s.repr
    result = s
