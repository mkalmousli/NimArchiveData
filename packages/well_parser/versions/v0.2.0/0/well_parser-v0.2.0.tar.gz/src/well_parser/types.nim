
  #[
    ---------------------------------------------------------------------------
    Drilling Permits with Coordinates
    ---------------------------------------------------------------------------
  ]#


type
  RowsDrilling* = enum   
    DAROOT,
    DAPERMIT,
    DAFIELD,
    DAFLDSPC,
    DAFLDBHL,
    DACANRES,
    DACANFLD,
    DAFRERES,
    DAFREFLD,
    DAPMTBHL,
    DAALTADD,
    DAREMARK,
    DACHECK,
    DAW999A1,
    DAW999B1
  #root
  
  DaPrimaryKey* = object
    daStatusNumber*: string
    daStatusSequenceNumber*: string
  
  DaDAT* = object
    dACENTURY*: string
    dAYEAR*: string
    dAMONTH*: string
    dADAY*: string

  DaSecondaryKeys* = object
    daCountyCode*: string
    daLeaseName*: string
    daDistrict*: string
    daOperatorNumber*: string
    daConvertedDate*: string
    daDateAppReceived*: DaDAT
   # daDateAppRedef*: string
  
  DaStatusRoot* = object
   daPrimaryKey*: DaPrimaryKey
   daSecondaryKeys*: DaSecondaryKeys
  
  DaPROBLEMFLAGS* = object
    dANOTENOUGHMONEYFLAG*: string
    dATOOMUCHMONEYFLAG*: string
    dAP5PROBLEMFLAG*: string
    dAP12PROBLEMFLAG*: string
    dAPLATPROBLEMFLAG*: string
    dAW1APROBLEMFLAG*: string
    dAOTHERPROBLEMFLAG*: string
    dARULE37PROBLEMFLAG*: string
    dARULE38PROBLEMFLAG*: string
    dARULE39PROBLEMFLAG*: string
    dANOMONEYFLAG*: string

  DaPermitKey* = object
    daPermitNumber*: string
    daPermitSequenceNumber*: string
  
  DaZIPCode* = object
    dAZIPCODEPREFIX*: string
    dAZIPCODESUFFIX*: string

  DaNEWSURFACELOCATION* = object
    dASURFACESECTION*: string
    dASURFACEBLOCK*: string
    dASURFACESURVEY*: string
    dASURFACEABSTRACT*: string
    filler*: string
  
  DaSURFDistance* = object
    dASURFACELEASEFEET1*: string
    dASURFACELEASEDIRECTION1*: string
    dASURFACELEASEFEET2*: string
    dASURFACELEASEDIRECTION2*: string

  DaPermitSegment* = object
    daPermitKey*: DaPermitKey
    dAPERMITCOUNTYCODE*: string
    dAPERMITLEASENAME*: string
    dAPERMITDISTRICT*: string
    dAPERMITWELLNUMBER*: string
    dAPERMITTOTALDEPTH*: string
    dAPERMITOPERATORNUMBER*: string
    dATYPEAPPLICATION*: string
    dAOTHEREXPLANATION*: string
    dAADDRESSUNIQUENUMBER*: string
    daZIPCode*: DaZIPCode
    dAFICHESETNUMBER*: string
    dAONSHORECOUNTY*: string
    dARECEIVEDDATE*: DaDat
    dAPERMITISSUEDDATE*: DaDat
    dAPERMITAMENDEDDATE*: DaDAT
    dAPERMITEXTENDEDDATE*: DaDAT
    dAPERMITSPUDDATE*: DaDAT
    dAPERMITSURFACECASINGDATE*: DaDAT
    dAWELLSTATUS*: string
    dAPERMITWELLSTATUSDATE*: DaDAT
    dAPERMITEXPIREDDATE*: DaDAT
    dAPERMITCANCELLEDDATE*: DaDAT
    dACANCELLATIONREASON*: string
    dAP12FILEDFLAG*: string
    dASUBSTANDARDACREAGEFLAG*: string
    dARULE36FLAG*: string
    dAH9FLAG*: string
    dARULE37CASENUMBER*: string
    dARULE38DOCKETNUMBER*: string
    dALOCATIONFORMATIONFLAG*: string
    dANEWSURFACELOCATION*: DaNEWSURFACELOCATION
    dASURFACEACRES*: string
    dASURFACEMILESFROMCITY*: string
    dASURFACEDIRECTIONFROMCITY*: string
    dASURFACENEARESTCITY*: string
    dASURFACELEASEDISTANCE*: DaSURFDistance
    dASURFACESURVEYDISTANCE*: DaSURFDistance
    dANEARESTWELL*: string
    dANEARESTWELLFORMATFLAG*: string
    dAFINALUPDATE*: DaDAT
    dACANCELLEDFLAG*: string
    dASPUDINFLAG*: string
    dADIRECTIONALWELLFLAG*: string
    dASIDETRACKWELLFLAG*: string
    dAMOVEDINDICATOR*: string
    dAPERMITCONVISSUEDDATE*: string
    dARULE37GRANTEDCODE*: string
    dAHORIZONTALWELLFLAG*: string
    dADUPLICATEPERMITFLAG*: string
    dANEARESTLEASELINE*: string
    apiNumber*: string
  
  AlternateAddress* = object
    dAALTADDRESSKEY*: string
    dAALTADDRESSLINE1*: string
  
  DaCHECKREGISTERKEY* = object
    dACHECKREGISTERDATE*: DaDAT
    dACHECKREGISTERNUMBER*: string

  Root* = object
    daType*: RowsDrilling
    rrcTapeRecordId*: string
    daStatusRoot*: DaStatusRoot
    daOperatorName*: string
    hB1407PROBLEM*: string
    dASTATUSOFAPPFLAG*: string
    dAPROBLEMFLAGS*: DaPROBLEMFLAGS
    daPermit*: string
    daIssueDat*: DaDAT
    daWithdraw*: DaDAT
    dAWALKTHROUGHFLAG*: string
    dAOTHERPROBLEMTEXT*: string
    dAWELLNUMBER*: string
    dABUILTFROMOLDMASTERFLAG*: string
    dASTATUSRENUMBEREDTO*: string
    dASTATUSRENUMBEREDFROM*: string
    dAAPPLICATIONRETURNEDFLAG*: string
    dAECAPFILINGFLAG*: string
    
  PermitMaster* = object
    daType*: RowsDrilling
    rrcTapeRecordId*: string
    rrcTapeRecordId2*: string
    daPermitSegment*: DaPermitSegment
  
  FieldSegment* = object
    daType*: RowsDrilling
    rrcTapeRecordId*: string
    dAFIELDNUMBER*: string
    dAFIELDAPPLICATIONWELLCODE*: string
    dAFIELDCOMPLETIONWELLCODE*: string
    dAFIELDCOMPLETIONCODE*: string
    dAFIELDTRANSFERCODE*: string
    dAFIELDVALIDATIONDATE*: DaDAT
    dAFIELDCOMPLETIONDATE*: DaDAT
    dAFIELDRULE37FLAG*: string
    dAFIELDRULE38FLAG*: string

  FieldSpecificDataSegement* = object
    daType*: RowsDrilling
    rrcTapeRecordId*: string
    dAFIELDDISTRICT*: string
    dAFIELDLEASENAME*: string
    dAFIELDTOTALDEPTH*: string
    dAFIELDWELLNUMBER*: string
    dAFIELDACRES*: string

  FieldBottomHoleLocationSegment* = object
    daType*: RowsDrilling
    rrcTapeRecordId*: string
    dAFLDBHLSECTION*: string
    dAFLDBHLBLOCK*: string
    dAFLDBHLABSTRACT*: string
    dAFLDBHLSURVEY*: string
    dAFLDBHLACRES*: string
    dAFLDBHLNEARESTWELL*: string
    dAFLDBHLLEASEFEET1*: string
    dAFLDBHLLEASEDIRECTION1*: string
    dAFLDBHLLEASEFEET2*: string
    dAFLDBHLLEASEDIRECTION2*: string
    dAFLDBHLSURVEYFEET1*: string
    dAFLDBHLSURVEYDIRECTION1*: string
    dAFLDBHLSURVEYFEET2*: string
    dAFLDBHLSURVEYDIRECTION2*: string
    dAFLDBHLCOUNTY*: string
    dAFLDBHLPNTRTDIST1*: string
    dAFLDBHLPNTRTDIR1*: string
    dAFLDBHLPNTRTDIST2*: string
    dAFLDBHLPNTRTDIR2*: string

  CannedRestrictions* = object
    daType*: RowsDrilling
    rrcTapeRecordId*: string
    dACANRESTRKEY*: string
    dACANRESTRTYPE*: string
    dACANRESTRREMARKOld*: string

  CannedRestrictionFields* = object
    daType*: RowsDrilling
    rrcTapeRecordId*: string
    dACANRESTRFLDNUMBER*: string

  FreeFormRestrictions* = object
    daType*: RowsDrilling
    rrcTapeRecordId*: string
    dAFREERESTRKEY*: string
    dAFREERESTRTYPE*: string
    dAFREERESTRREMARK*: string
    dAFREERESTRFLAG*: string

  FreeFormRestrictionFields* = object
    daType*: RowsDrilling
    rrcTapeRecordId*: string
    dAFREERESTRFLDNUMBER*: string

  BottomHoleLocationSegement* = object
    daType*: RowsDrilling
    rrcTapeRecordId*: string
    dAPMTBHLSECTION*: string
    dAPMTBHLBLOCK*: string
    dAPMTBHLABSTRACT*: string
    dAPMTBHLSURVEY*: string
    dAPMTBHLACRES*: string
    dAPMTBHLNEARESTWELL*: string
    dAPMTBHLLEASEFEET1*: string
    dAPMTBHLLEASEDIRECTION1*: string
    dAPMTBHLLEASEFEET2*: string
    dAPMTBHLLEASEDIRECTION2*: string
    dAPMTBHLSURVEYFEET1*: string
    dAPMTBHLSURVEYDIRECTION1*: string
    dAPMTBHLSURVEYFEET2*: string
    dAPMTBHLSURVEYDIRECTION2*: string
    dAPMTBHLCOUNTY*: string
    dAPMTBHLPNTRTDIST1*: string
    dAPMTBHLPNTRTDIR1*: string
    dAPMTBHLPNTRTDIST2*: string
    dAPMTBHLPNTRTDIR2*: string

  AlternateAddressSegment* = object
    daType*: RowsDrilling
    rrcTapeRecordId*: string
    alternateAddress*: AlternateAddress

  PermitRemarks* = object
    daType*: RowsDrilling
    rrcTapeRecordId*: string
    dAREMARKSEQUENCENUMBER*: string
    dAREMARKFILEDATE*: DaDAT
    dAREMARKLINE*: string
  
  CheckRegisterSegment* = object
    daType*: RowsDrilling
    rrcTapeRecordId*: string
    dACHECKREGISTERKEY*: DaCHECKREGISTERKEY

  GisSurfaceLocationCoordinates* = object
    daType*: RowsDrilling
    rrcTapeRecordId*: string
    coordinates*: seq[float]

  GisBottomHoleLocationCoordinates* = object
    daType*: RowsDrilling
    rrcTapeRecordId*: string
    coordinates*: seq[float]

  FinalDrillingObject* = object
    root*: Root
    permitMaster*: PermitMaster
    fieldSegment*: seq[FieldSegment]
    fieldSpecificDataSegement*: FieldSpecificDataSegement
    fieldBottomHoleLocationSegment*: FieldBottomHoleLocationSegment
    cannedRestrictions*: seq[CannedRestrictions]
    cannedRestrictionFields*: seq[CannedRestrictionFields]
    freeFormRestrictions*: seq[FreeFormRestrictions]
    freeFormRestrictionFields*: seq[FreeFormRestrictionFields]
    bottomHoleLocationSegement*: BottomHoleLocationSegement
    alternateAddressSegment*: AlternateAddressSegment
    permitRemarks*: seq[PermitRemarks]
    checkRegisterSegment*: seq[CheckRegisterSegment]
    gisSurfaceLocationCoordinates*: seq[GisSurfaceLocationCoordinates]
    disBottomHoleLocationCoordinates*: seq[GisBottomHoleLocationCoordinates]


  #[
    ---------------------------------------------------------------------------
    Well Api Data
    ---------------------------------------------------------------------------
  ]#

  WellApi* = enum
    MAF016

  FinalWellObject* = object
     maType*: WellApi
     mAF016QUADNUM*: string
     mAF016APINUM*: string
     mAF016SURVEY*: string
     mAF016BLOCK*: string
     mAF016SECTION*: string
     mAF016ABSTRACT*: string
     mAF016OPERATOR*: string
     mAF016TOTALDEPTH*: string
     mAF016WELLNUMBER*: string
     mAF016LEASENAME*: string
     mAF016PERMITNUM*: string
     mAF016GASRRCID*: string
     mAF016FIELDNAME*: string
     mAF016COMPLETIONDATE*: string
     mAF016PLUGDATE*: string
     mAF016REFERTOAPI*: string
     mAF016ONOFFSCHEDULE*: string
     mAF016OILGASCODE*: string
 
   #[
    ---------------------------------------------------------------------------
    Injection wells
    ---------------------------------------------------------------------------
    ]#

  RowsInjection* = enum
    UIROOT,
    UIRMK,
    UIMONTR,
    UIMNH10,
    UIMNH10H,
    UIMNRMK,
    UIH5,
    UIH5RMK,
    UIENF,
    UIENFACT,
    UIENFOTH,
    UIENFRMK,
    UIMON10H,
    UIH10VIO

  UICnextCTLnum* = object
    uicNEXTAVAILABLE*: string
    uicNEXTDUMMYLEASE*: string
  
  UICaltKEY1* = object
    uicOGTYPE*: string
    uicLEASEID*: string
    uicDist*: string
    uicWellNo*: string
  
  UICapiNUMBER* = object
    uicCNTYNO*: string
    uicAPINO*: string
  
  UICinjFLUIDS* = object
    uicINJsw*: string
    uicINJfw*: string
    uicINJfracWater*: string
    uicINJnorm*: string
    uicINJCO2*: string
    uicINJgas*: string
    uicINJh2s*: string
    uicINJpolymer*: string
    uicINJsteam*: string
    uicINJair*: string
    uicINJnitrogen*: string
    uicINJother*: string
    uicINJbw*: string
    uicINJlpg*: string
  
  UICspecialCONDITIONS* = object
    uicSPECANNPRESSTEST*: string
    uicSPECANNRADTRACERSUR*: string
    uicSPECANNTEMPSURVEY*: string
    uicSPECDOWNHOLESURVEY*: string
    uicSPECSEMIANNUALPT*: string
    uicSPECTBGCSGANNULUS*: string
    uicSPECTBGCSGFREQ*: string
    uicSPECMONTRPRESS*: string
    uicSPECMONTRPRESSCODE1*: string
    uicSPECMO0NTRPRESSCODE2*: string
    uicSPECMONTRPRESSFREQ*: string
    uicSPECMEASFLUIDLEVEL*: string
    uicSPECMEASFLUIDFREQ*: string
    uicSPECCOMMERCIAL*: string
    uicSPECCEMENTSQZ*: string
    uicSPECCEMENTSQZAMT1*: string
    uicSPECCEMENTSQZAMT2*: string
    uicSPECCEMENTSQZ2*: string
    uicSPECCEMENTSQZ2AMT1*: string
    uicSPECCEMENTSQZ2AMT2*: string
    uicSPECBLOCKSQZSX*: string
    uicSPECBLOCKSQZSXAMT1*: string
    uicSPECBLOCKSQZSXAMT2*: string
    uicSPECBLOCKSQZ*: string
    uicSPECBLOCKSQZAMT*: string
    uicSPECSQZPERF*: string
    uicSPECSQZPERFDPTH*: string
    uicSPECBRIDGEPLUG*: string
    uicSPECBRIDGEPLUGDPTH*: string
    uicSPECFLUIDSOURCELIMIT*: string
    uicSPECPLUGAREAWELLS*: string
    uicSPECPLUGAREAWELLSNO*: string
    uicSPECPERMITEXP*: string
    uicSPECPERMITEXPDATE*: DaDAT
    uicSPECGASPLANT*: string
    uicSPECOTHER*: string

  UICbaseUsuableQUALITYWATER* = object
    uicDPTHBOTOFTOPZONE*: string
    uicDPTHTOPOFSPLITZONE*: string
    uicDPTHBOTOFSPLITZONE*: string
  
  UICexpections* = object
    uicEXCTUBINGPACKER*: string
    uicEXCTUBINGPACKERDATE*: DaDAT
    uicEXCPACKERDEPTH*: string
    uicEXCPACKERDEPTHDATE*: DaDAT
    uicEXCPACKERDEPTHAM*: string
    uicEXCOBSERVVALUE*: string
    uicEXCOBSERVVALUEDATE*: DaDAT

  UICtechnicianDATA* = object
    uicTECHNICIANREVIEWDATE*: DaDAT
    uicTECHNICIANINITIALS*: string
    uicTECHNICIANRESULTS*: string

  UICprodCASING* = object
    uicPRODCASINGAMT*: string
    uicPRODCASINGFRACTION1*: string
    uicPRODCASINGFRACTION2*: string
    uicPRODCASINGDEPTH*: string
    uicPRODCASINGCEMENT*: string
    uicPRODCASINGTOPCEMENT*: string
    uicPRODCASINGPKRDEPTH*: string

  UICdocketNO* = object
    filler*: string
    uicOLDDOCKETNO*: string
  
  UICh10BATCH* = object
    uicH10BATCHCYCLE*: string
    uicH10BATCHCURR*: string
    uicH10BATCHPREV*: string
    uicMISCTYPEMIT*: string
    uicMISCTYPEMITFREQUENCY*: string
    uicTYPEOFWELLCOMPLETION*: string
    filler*: string
  
  UICremarksKEY* = object
    uicREMARKSRMK*: string
    uicREMARKSLINE*: string
 
  UICmontrFLUIDS* = object
    uicMONTRSW*: string
    uicMONTRFW*: string
    uicMONTRFRACWATER*: string
    uicMONTRNRM*: string
    uicMONTRCO2*: string
    uicMONTRCO2A*: string
    uicMONTRGAS*: string
    uicMONTRH2S*: string
    uicMONTRPOLYMER*: string
    uicMONTRSTEAM*: string
    uicMONTRAIR*: string
    uicMONTRNITROGEN*: string
    uicMONTROTH*: string
    uicMONTRBW*: string
    uicMONTRLPG*: string
  
  UICmontrFLUIDSPCTS* = object
     uicMONTRSWPCT*: string
     uicMONTRFWPCT*: string
     uicMONTRFRACWATERPCT*: string
     uicMONTRNORMPCT*: string
     uicMONTRCO2PCT*: string
     uicMONTRCO2APCT*: string
     uicMONTRGASPCT*: string
     uicMONTRH2SPCT*: string
     uicMONTRPOLYMERPCT*: string
     uicMONTRSTEAMPCT*: string
     uicMONTRAIRPCT*: string
     uicMONTRNITROGENPCT*: string
     uicMONTROTHERPCT*: string
     uicMONTRBWPCT*: string
     uicMONTRLPGPCT*: string
  
  UICmontrEXCEPTIONS* = object
    uicMONTREXCALTTEST*: string
    uicMONTREXCALTTESTDATE*: DaDAT

  MNh10dOCUMENTiD* = object
    mhH10DOCUMENTCYCLE*: string
    mnH10DOCUMENTBATCH*: string
    mnH10DOCUMENTITEM*: string

  MNremakrsSegment* = object
    mnRemarksType*: string
    mnRemarks*: string
    filler*: string

  UICh5KEY* = object
    uicH5TESTDATEKEY*: string
    uicH5TESTSEQNUM*: string
  
  UICh5SEGMPRIOR1992* = object
    uicH5DUEDATE*: DaDAT
    uicH5RECEIVEDDATE*: DaDAT
    uicH5SCHEDULETYPE*: string
    uicH5SCHEDULEFLAG*: string
    uicH5SCHEDULEDDATE*: DaDAT
    uicH52NDNOTICEDATE*: DaDAT
    uicH5MITCYCLETYPE*: string
    uicH5MITCYCLETODATE*: DaDAT
    uicH5PACKERDEPTH*: string
    uicH5TESTDATE*: DaDAT
    uicH5COMPLTOPINJ*: string
    uicH5COMPLBOTINJ*: string
    uicH5TBGCSGMNTRDT*: DaDAT

  UICh5MISCREPAIRS* = object
    uicH5MISCREPAIR*: string
    uicH5REPAIRCOMM*: string

  UICh5REPAIRSMADE* = object
    uicH5TUBING*: string
    uicH5PACKER*: string
    uicH5CASING*: string
    uicH5WELLHEAD*: string
    uicH5MISCREPAIRS*: UICh5MISCREPAIRS

  UICh5INCONCLUSIVEOTHER* = object
    uicH5INCONCLU*: string
    uicH5INCONCLUCOMM*: string
  
  ENFactDATEcode* = object
    enfACTVIOLDATE*: DaDAT
    enfACTVIOLCODE*: string
  
  UICh10HMONTRFLUIDS* = object
    uicH10HMONTRCRUDE*: string
    uicH10HMONTRGAS*: string
    uicH10HMONTRLPG*: string
    uicH10HMONTROTHER*: string
  
  UICh10VIOLp4CERTltrKEY* = object
    uicH10VIOLP4CERTDTEKEY*: string
    uicH10VIOLP4CERTSECTION*: string
    uicH10VIOLP4CERTREASON*: string

  UICRoot* = object
    uicType*: RowsInjection
    rrcTapeRecordId*: string
    uicCNTLNO*: string
    uicNextCTLnum*: UICnextCTLnum
    uicAltKEY1*: UICaltKEY1
    uicOPER*: string
    uicApiNUMBER*: UICapiNUMBER
    uicClass*: string
    uicAPPRDATE*: DaDAT
    uicW14DATE*: DaDAT
    uicH1DATE*: DaDAT
    uicLETTERDATE*: DaDAT
    uicPERMITADDEDDATE*: DaDAT
    uicACTIVATEDFLAG*: string
    uicCANCELDATE*: DaDAT
    uicW2G1DATE*: DaDAT
    uicW3DATE*: DaDAT
    uicTYPEINJ*: string
    uicTYPEINJCMT*: string
    uicTYPEFLUCMT*: string
    uicBBLVOLINJ*: string
    uicMCFVOLINJ*: string
    uicTOPINJZONE*: string
    uicBOTINJZONE*: string
    uicMAXINJPRESSURE*: string
    uicH1NO*: string
    uicW14NO*: string
    uicINJFLUIDS*: UICinjFLUIDS
    uicMAXINJPRESSURE2*: string
    uicSPECIALCONDITIONS*: UICspecialCONDITIONS
    uicEXCEPTIONS*: UICexpections
    uicBASEUSUABLEQUALITYWATER*: UICbaseUsuableQUALITYWATER
    uicLOCATION*: string
    uicSURVEYLINES*: string
    uicSTATUS*: string
    uicGEOTHERMAL*: string
    uicMISMATCH*: string
    uicDEPTHBOZ*: string
    uicDEPTHPKR*: string
    uicINJMODE*: string
    uicTECHNICIANDATA*: UICtechnicianDATA
    uicPRODCASING*: UICprodCASING
    uicGASPLANTCOMMENT*: string
    uicSPECIALCONDCMT*: string
    uicFILEREVIEWDATE*: DaDAT
    uicFILEREVIEWINIT*: string
    uicDOCKETNODIST*: string
    uicDOCKETNO*: UICdocketNO
    uicUIROOTFILLER*: string
    uicH10BATCH*: UICh10BATCH

  UICRmk* = object
    uicType*: RowsInjection
    rrcTapeRecordId*: string
    uicREMARKSKEY*: UICremarksKEY
    uicREMARKSTYPE*: string
    uicREMARKS*: string
    uicREMARKID*: string
    uicREMARKDATE*: DaDAT
    filler*: string
    filler2*: string

  UICMontr* = object
    uicType*: RowsInjection
    rrcTapeRecordId*: string
    uicMONTRWSTATUS*: string
    uicMONTRFLUIDS*: UICmontrFLUIDS
    uicMONTRFLUIDSPCTS*: UICmontrFLUIDSPCTS
    uicMONTREXCEPTIONS*: UICmontrEXCEPTIONS
    uicMONTRRECFLG*: string
    uicMONTRHOLD*: string
    uicMONTRISSDTE*: DaDAT
    uicMONTRRECDTE*: DaDAT
    uicMONTR2NDNOTICE*: DaDAT
    uicMONTRDELNOTICE*: DaDAT
    uicMONTRCYCLECCYY*: DaDAT
    uicMONTRFWAVGORMAX*: string
    uicMONTRFWBBLSDAY*: string
    uicMONTRFWSOURCE*: string
    uicMONTRALTRPTING*: string
    uicMONTROPTRPTING*: string
    uicMONTRINJFLUFLAG*: string
    uicMONTRFLUIDCMT*: string
    uicMONTRWSTATCMT*: string
    uicMONTRTOPINJZONE*: string
    uicMONTRTBGCSGANNTSTDTE*: DaDAT
    uicMONTRPRESSGTZERO*: string
    uicMONTRTBGCSGANNMON*: string
    uicMONTRTBGCSGAVGREAD*: string
    uicOLDSTATUS5FLAG*: string
    uicNEWFORMFLAG*: string
    uicMONTRDUEDATE*: DaDAT
    uicMONTRH10TYPEFLAG*: string
    filler*: string

  UICMNh10* = object
    uicType*: RowsInjection
    rrcTapeRecordId*: string
    mnH10KEY*: DaDAT
    mnH10AVGINJPRESSURE*: string
    mnH10MAXINJPRESSURE*: string
    mnH10TOTALVOLBBL*: string
    mnH10TOTALVOLMCF*: string
    mnH10ANNULUSMINIMUM*: string
    mnH10ANNULUSMAXIMUM*: string
    mnH10ANNULUSCOUNT*: string
    mnh10DOCUMENTID*: MNh10dOCUMENTiD
  
  UICMNh10H* = object
    uicType*: RowsInjection
    rrcTapeRecordId*: string
    mnH10HKEY*: DaDAT
    mnH10HMAXHYDROCARBPSIG*: string
    mnH10HMAXBRINEPSIG*: string
    mnH10HINJBRINEBBLSSIGN*: string
    mnH10HINJBRINEBBLS*: string
    mnH10HINJHYDROBBLSSIGN*: string
    mnH10HINJHYDROCARBBBLS*: string
    mnH10HINJGASMCFSIGN*: string
    mnH10HINJGASMCF*: string
    mnH10HDOCUMENTID*: MNh10dOCUMENTiD

  UICmnrmk* = object
    uicType*: RowsInjection
    rrcTapeRecordId*: string
    uicMNremarksSegment*: MNremakrsSegment

  UICh5* = object
    uicType*: RowsInjection
    rrcTapeRecordId*: string
    uicH5KEY*: UICh5KEY
    uicH5SEGMPRIOR1992*: UICh5SEGMPRIOR1992
    uicH5POSITIVEPRESS*: string
    uicH5TESTDATE*: string
    uicH5ALTERNATECODE*: string
    uicH5WELLSTATUS*: string
    uicH5WELLSTATUSCMT*: string
    uicH5REASONFORTEST*: string
    uicH5OTHERTESTREASON*: string
    uicH5RETESTFLAG*: string
    uicH5PRIORTESTDATE*: DaDAT
    uicH5OTHERTESTSFLAG*: string
    uicH5OTHERTESTSCOMM*: string
    uicH5REPAIRSMADE*: UICh5REPAIRSMADE
    uicH5WITNESSEDFLAG*: string
    uicH5TESTRESULTS*: string
    uicH5INCONCLUSIVEREASONS*: string
    uicH5LETTERSIGN*: string
    uicH5INCONCLUSIVEOTHER*: UICh5INCONCLUSIVEOTHER
    uicH5ALTTESTCOMMENT*: string
    uicH5P12ITEMS*: string
  
  UICh5RMK* = object
    uicType*: RowsInjection
    rrcTapeRecordId*: string
    h5REMARKSTYPE*: string
    h5REMARKS*: string
    filler*: string

  UICenf* = object
    uicType*: RowsInjection
    rrcTapeRecordId*: string
    uicENFKEY*: string
    uicENFMANFILEFLAG*: string
    filler*: string

  UICenFACT* = object
    uicType*: RowsInjection
    rrcTapeRecordId*: string
    enfACTDATECODE*: ENFactDATEcode
    enfACTNOTICEDATE*: DaDAT
    enfACTNOTICETYPE*: string
    enfACTCOMPDATE*: DaDAT
    enfACTCOMPMETHOD*: string
    enfACTSNCFLAG*: string
    enfACTVIOLONHOLDFLAG*: string
    filler*: string
  
  UICenfOTH* = object
    uicType*: RowsInjection
    rrcTapeRecordId*: string
    enfOTHCOMPMETHOD*: string
    enfOTHENFORCETYPE*: string
    enfOTHCOMPLAINTNUM*: string
    filler*: string

  UICenfRMK* = object
    uicType*: RowsInjection
    rrcTapeRecordId*: string
    enfREMARKSTYPE*: string
    enfREMARKS*: string
    filler*: string
  
  UICmon10H* = object
    uicType*: RowsInjection
    rrcTapeRecordId*: string
    uicH10HMONTRKEY*: string
    uicH10HMONTRDATE*: string
    uicH10HMONTRDATE2*: DaDAT
    uicH10HMONTRWSTATUS*: string
    uicH10HMONTRFLUIDS*: UICh10HMONTRFLUIDS
    uicH10HMONTRPRESSGTZERO*: string
    uicH10HMONTRSURFACEVESSEL*: string
    uicH10HMONTRRECFLG*: string
    uicH10HMULTWELLCAVERNFLAG*: string
    uicH10HMONTRISSDTE*: DaDAT
    uicH10HMONTRRECDTE*: DaDAT
    uicH10HMONTR2NDNOTICE*: DaDAT
    uicH10HMONTRDELNOTICE*: DaDAT
    uicH10HMONTRCYCLECCYR*: DaDAT
    uicH10HCAVERNCAPACITY*: string
    uicH10HMAXMBBLS*: string
    uicH10HMAXMCF*: string
    uicH10HINVENTORYOFMBBLS*: string
    uicH10HINVENTORYOFMCF*: string
    uicH10HOTHERWELL1*: string
    uicH10HOTHERWELL2*: string
    uicH10HOTHERWELL3*: string
    uicH10HMONTRWSTATCMT*: string
    uicH10HPRODUCTSPECIFIC*: string
    uicH10HNEWFORMFLAG*: string
    uicH10HMONTRDUEDATE*: DaDAT
    uicH10HMONTRFLAG*: string
    filler*: string
  
  UICh10VIO* = object
    uicType*: RowsInjection
    rrcTapeRecordId*: string
    uicH10VIOLBEGINDATE*: DaDAT
    uicH10VIOLENDDATE*: DaDAT
    uicH10VIOLCODE*: string
    uicH10VIOLLETTERKEY*: string
    uicH10VIOLLETTERDATE*: DaDAT
    uicH10VIOLRESOLVEDATE*: DaDAT
    uicH10VIOLRESOLVEBYFLAG*: string
    uicH10VIOLP4CERTLTRKEY*: UICh10VIOLp4CERTltrKEY
    uicH10VIOLSEVERLTRDATE*: DaDAT
    uicH10VIOLONHOLDFLAG*: string
    filler*: string
 
  FinalInjectionObject* = object
    uicRoot*: UICRoot
    uicRMK*: UICRmk
    uicMONTR*: UICMontr
    uicMNh10*: UICMNh10
    uicMNh10H*: UICMNh10H
    uicMNRMK*: UICmnrmk
    uicH5*: UICh5
    uicH5RMK*: UICh5RMK
    uicEnf*: UICenf
    uicENFACT*: UICenFACT
    uicENFOTH*: UICenfOTH
    uicENFRMK*: UICenfRMK
    uicMON10H*: UICmon10H
    uicH10VIO*: UICh10VIO