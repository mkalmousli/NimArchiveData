# Package

version       = "0.2.0"
author        = "Empower, LLC"
description   = "Parsing the Texas RRC data on wells"
license       = "GPL-3.0"
srcDir        = "src"


# Dependencies

requires "nim >= 2.0"
requires "anonimongo >= 0.7.2"
