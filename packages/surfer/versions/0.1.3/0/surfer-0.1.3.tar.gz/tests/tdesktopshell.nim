# Requires: pixie, chroma
# Only works when targetting Wayland with a compatible compositor (which is our only backend for now anyways!)

import pkg/[vmath, shakar, surfer, chroma, pixie]

proc genImage(width, height: int32): Image =
  let image = newImage(width, height)
  for i in 0 ..< image.data.len:
    image.data[i] = rgbx(255, 255, 255, 255) # Make the image fully white

  var font = readFont("tests/IBMPlexSans-Regular.ttf") # Replace this with a font path
  font.size = 20

  # Just add some text for fun :^)
  image.fillText(
    font.typeset(
      "This can be used in status bars, notification centers, desktop shells, etc!",
      vec2(180, 180),
    ),
    translate(vec2(10, 10)),
  )

  image

proc main() {.inline.} =
  let app = newApp("Surfer Desktop Shell", appId = "xyz.xtrayambak.surfer.shell")
  app.initialize()
  app.createLayerSurface(
    Layer.Top,
    anchors = {Anchor.Bottom, Anchor.Left, Anchor.Right, Anchor.Top},
    keyboardInteractivity = KeyboardInteractivity.None,
    renderer = Renderer.Software,
    namespace = "xyz.xtrayambak.surfer.shell",
    requestedSize = ivec2(0, 0),
  )

  echo "Has keyboard: " & $hasKeyboard(app)
  echo "Has cursor: " & $hasCursor(app)

  # Use ControlFlow.Wait for simple GUI apps that don't need
  # precise timing, and use ControlFlow.Async for high-performance
  # apps like game engines that need precise timing, at the cost
  # of increased CPU usage.
  app.controlFlow = ControlFlow.Wait

  # Create a Pixie image
  var image = genImage(640, 480)

  while true:
    let eventOpt = app.flushQueue()
    if !eventOpt:
      # If we have no event to consume, continue.
      continue

    let event = &eventOpt
    case event.kind
    of EventKind.RedrawRequested:
      # Redrawing logic
      let stride = image.width * sizeof(ColorRGBX)

      # Wayland specific logic: Copy pixie image buffer to the mapped buffer
      # that surfer allocated.
      for y in 0 ..< image.height:
        copyMem(
          cast[pointer](cast[uint](app.pools.surfaceDest) + uint(y * stride)),
          addr image.data[y * image.width],
          stride,
        )

      app.markDamaged()

      # Tell the compositor that we're ready to draw another frame, if it wishes so.
      app.queueRedraw()
    of EventKind.KeyboardFocusObtained:
      echo "Keyboard focus on surface"
    of EventKind.KeyboardFocusLost:
      echo "Keyboard focus lost"
    of EventKind.KeyReleased:
      echo "Key released: " & $event.key.code
    of EventKind.KeyPressed:
      echo "Key pressed: " & $event.key.code
    of EventKind.KeyRepeated:
      echo "Key repeated: " & $event.key.code
    of EventKind.WindowResized:
      echo "Window resized: " & $event.windowSize
      image = genImage(event.windowSize.x, event.windowSize.y)
    else:
      discard

when isMainModule:
  main()
