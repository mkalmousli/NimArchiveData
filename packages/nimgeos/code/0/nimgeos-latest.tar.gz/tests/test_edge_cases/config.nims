switch("path", "$projectDir/../../src")
