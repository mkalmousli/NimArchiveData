# Package

version       = "0.2.0"
author        = "Nycto"
description   = "Dithering algorithms in Nim"
license       = "Apache-2.0"
srcDir        = "src"


# Dependencies

requires "nim >= 1.6.14", "chroma >= 0.2.7"
