{
  pkgs ? import <nixpkgs> { },
  bomPath ? ./sbom.json,
  excludes ? [ ],
  extraConfig ? [ ],
  extraPaths ? [ ],
}:

let
  inherit (pkgs)
    lib
    fetchgit
    fetchzip
    runCommand
    xorg
    ;

  fetchers = {
    fetchzip =
      { url, sha256, ... }:
      fetchzip {
        name = "source";
        inherit url sha256;
      };
    git =
      {
        fetchSubmodules ? false,
        leaveDotGit ? false,
        rev,
        sha256,
        url,
        ...
      }:
      fetchgit {
        inherit
          fetchSubmodules
          leaveDotGit
          rev
          sha256
          url
          ;
      };
  };

  filterPropertiesToAttrs =
    prefix: properties:
    properties
    |> builtins.filter ({ name, ... }: (lib.strings.hasPrefix prefix name))
    |> map (
      { name, value }:
      {
        name = lib.strings.removePrefix prefix name;
        inherit value;
      }
    )
    |> builtins.listToAttrs;

  buildNimCfg =
    { backend, components, ... }:
    let
      componentSrcDirs =
        components
        |> builtins.filter ({ name, ... }: !(builtins.elem name excludes))
        |> map (
          {
            properties ? [ ],
            ...
          }:
          let
            fodProps = filterPropertiesToAttrs "nix:fod:" properties;
          in
          if fodProps == { } then
            null
          else
            let
              fod = fetchers.${fodProps.method} fodProps;
              srcDir = fodProps.srcDir or "";
            in
            if srcDir == "" then fod else "${fod}/${srcDir}"
        )
        |> builtins.filter (e: e != null);
    in
    runCommand "nim.cfg"
      {
        outputs = [
          "out"
          "src"
        ];
        nativeBuildInputs = [ pkgs.s6-portable-utils ];
      }
      ''
        cat << EOF >> $out
        backend:${backend}
        path:"$src"
        ${lib.strings.concatLines (map (p: ''path:"${toString p}"'') extraPaths)}
        ${lib.strings.concatLines extraConfig}
        EOF
        s6-update-symlinks "$src" ${toString (map lib.escapeShellArg componentSrcDirs)}
      '';

  sbom = with builtins; fromJSON (readFile bomPath);
  metaProps = builtins.listToAttrs sbom.metadata.component.properties;
in
buildNimCfg {
  backend = metaProps."nim:backend";
  inherit (sbom) components;
}
