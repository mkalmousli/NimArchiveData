let
  pkgs = import <nixpkgs> { };
in
pkgs.nim_lk.overrideAttrs (
  {
    buildInputs ? [ ],
    nativeBuildInputs ? [ ],
    ...
  }:
  {
    buildInputs = buildInputs ++ [ pkgs.openssl ];
    nativeBuildInputs = nativeBuildInputs ++ [ pkgs.yajsv ];
  }
)
