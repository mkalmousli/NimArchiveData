{
  pkgs ? import <nixpkgs> { },
  bomPath ? ./sbom.json,
  excludes ? [ ],
}:

let
  inherit (pkgs) lib;

  getProperty =
    properties: name:
    if properties == [ ] then
      ""
    else
      let
        e = builtins.head properties;
      in
      if e.name == name then e.value else getProperty (builtins.tail properties) name;

  callFromProperties =
    properties: func:
    func (
      builtins.mapAttrs (name: _: getProperty properties "nix:fod:${name}") (builtins.functionArgs func)
    );

  fetchers = {
    fetchzip =
      { url, sha256 }:
      pkgs.fetchzip {
        name = "source";
        inherit url sha256;
      };
    git =
      {
        fetchSubmodules,
        leaveDotGit,
        rev,
        sha256,
        url,
      }:
      pkgs.fetchgit {
        inherit
          fetchSubmodules
          leaveDotGit
          rev
          sha256
          url
          ;
      };
  };

  buildPkgDir =
    components:
    let
      srcDirs = map (
        { properties, ... }:
        let
          getProp = getProperty properties;
          method = getProp "nix:fod:method";
          srcDir = getProp "nix:fod:srcDir";
          fod = callFromProperties properties fetchers.${method};
        in

        if srcDir == "" then fod else "${fod}/${srcDir}"
      ) components;
    in
    pkgs.runCommand "nim.cfg"
      {
        outputs = [
          "out"
          "src"
        ];
        nativeBuildInputs = [ pkgs.xorg.lndir ];
        passthru = {
          inherit components srcDirs;
        };
      }
      ''
        pkgDir=$src/pkg
        cat << EOF >> $out
        noNimblePath
        path:"$src"
        path:"$pkgDir"
        EOF
        mkdir -p "$pkgDir"
        ${lib.strings.concatMapStrings (d: ''
          lndir "${d}" "$pkgDir"
        '') srcDirs}
      '';
in
with builtins;
lib.pipe bomPath [
  readFile
  fromJSON
  (getAttr "components")
  (filter ({ name, ... }: !(elem name excludes)))
  buildPkgDir
]
