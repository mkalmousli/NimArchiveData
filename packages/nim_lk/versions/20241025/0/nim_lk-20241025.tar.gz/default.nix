{
  pkgs ? import <nixpkgs> { },
}:

let
  inherit (pkgs) lib;
  buildNimSbom = pkgs.callPackage (import ./build-nim-sbom.nix) { };
in
buildNimSbom {
  src = if lib.inNixShell then null else lib.cleanSource ./.;
  buildInputs = [ pkgs.openssl ];
} ./sbom.json
