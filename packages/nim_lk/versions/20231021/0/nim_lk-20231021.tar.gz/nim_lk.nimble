author = "Emery Hemingway"
bin = @["nim_lk"]
description = "Tool for generating Nim lockfiles"
license = "BSD-3-Clause"
srcDir = "src"
version = "20231021"

requires "nim >= 2.0.0", "preserves >= 20231021"
