let pkgs = import <nixpkgs> { }; in pkgs.nitter
