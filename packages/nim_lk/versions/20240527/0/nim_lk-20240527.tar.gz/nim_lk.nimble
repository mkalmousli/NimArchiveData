author = "Emery Hemingway"
bin = @["nim_lk"]
description = "Tool for generating Nim lockfiles"
license = "BSD-3-Clause"
srcDir = "src"
version = "20240527"

requires "nim >= 2.0.0", "nimble#f8bd7b5fa6ea7a583b411b5959b06e6b5eb23667"
