# SPDX-FileCopyrightText: ☭ Emery Hemingway
# SPDX-License-Identifier: Unlicense

# https://cyclonedx.org/docs/1.6/json/

import
  std/[algorithm, deques, httpclient, json, options, os, osproc, parseutils, parseopt, streams, strutils, tables, uri],
  pkg/nimblepkg/common,
  pkg/nimblepkg/options,
  pkg/nimblepkg/packageinfo,
  pkg/nimblepkg/packageinfotypes,
  pkg/nimblepkg/packageparser,
  pkg/nimblepkg/version,
  ./nim_lk/purl

const githubPackagesUrl =
  "https://raw.githubusercontent.com/nim-lang/packages/master/packages.json"


var nimbleOptions: Options

let bomBase = %*
  {
    # "$schema": "http://cyclonedx.org/schema/bom-1.6.schema.json",
    "bomFormat": "CycloneDX",
    "specVersion": "1.6",
    "metadata": { },
    "components": [],
    "dependencies": []
  }

proc toComponentJson(pkgInfo: PackageInfo): JsonNode =
  let typ =
    if pkgInfo.bin.len == 0: "library"
    else: "application"
  %* {
    "type": typ,
    "bom-ref": pkgInfo.name,
    "name": pkgInfo.name,
    "description": pkgInfo.description,
    "version": pkgInfo.basicInfo.version,
    "authors": [ { "name": pkgInfo.author } ],
    "licenses": [ { "license": { "id": pkgInfo.license } } ]
  }

proc registryCachePath: string =
  result = getEnv("XDG_CACHE_HOME")
  if result == "":
    let home = getEnv("HOME")
    if home == "":
      result = getEnv("TMPDIR", "/tmp")
    else:
      result = home / ".cache"
  result.add "/packages.json"

proc isGitUrl(uri: Uri): bool =
  uri.scheme == "git" or
    uri.scheme.startsWith("git+") or
    uri.path.endsWith(".git") or
    uri.hostname.contains("git")

proc startProcess(cmd: string; cmdArgs: varargs[string]): Process =
  # stderr.writeLine(cmd, " ", join(cmdArgs, " "))
  startProcess(cmd, args = cmdArgs, options = {poUsePath})

proc gitLsRemote(url: string; withTags: bool): seq[tuple[tag: string, rev: string]] =
  var line, rev, refer: string
  var process =
    if withTags:
      startProcess("git", "ls-remote", "--tags", url)
    else:
      startProcess("git", "ls-remote", url)
  while process.outputStream.readLine(line):
    var off = 0
    off.inc parseUntil(line, rev, Whitespace, off)
    off.inc skipWhile(line, Whitespace, off)
    refer = line[off..line.high]
    const
      refsTags = "refs/tags/"
      headsTags = "refs/heads/"
    if refer.startsWith(refsTags):
      refer.removePrefix(refsTags)
      result.add((refer, rev,))
    elif refer.startsWith(headsTags):
      refer.removePrefix(headsTags)
      result.add((refer, rev,))
  stderr.write(process.errorStream.readAll)
  close(process)
  if withTags and result.len == 0:
    result = gitLsRemote(url, not withTags)

proc matchRev(url: string; wanted: VersionRange): tuple[tag: string, rev: string] =
  if wanted.kind == verSpecial:
    let special = $wanted.spe
    if special[0] == '#':
      result[1] = special[1..special.high]
    else:
      quit("unhandled version " & url & " " & $wanted)
  else:
    let withTags = wanted.kind != verAny
    let pairs = gitLsRemote(url, withTags)
    var resultVersion: Version
    for (tag, rev) in pairs:
      try:
        var tagVer = tag.newVersion
        if tagVer.withinRange(wanted) and resultVersion < tagVer:
          resultVersion = tagVer
          result = (tag, rev)
      except ParseVersionError: discard
    if result.rev == "" and pairs.len > 0:
      result = pairs[pairs.high]
    doAssert result.rev != "", url

proc collectMetadata(data: JsonNode) =
  let storePath = data{"path"}.getStr
  var packageNames = newSeq[string]()
  for (kind, path) in walkDir(storePath):
    if kind in {pcFile, pcLinkToFile} and path.endsWith(".nimble"):
      var (_, name, _) = splitFile(path)
      packageNames.add name
  if packageNames.len == 0:
    quit("no .nimble files found in " & storePath)
  packageNames.sort()
  data{"packages"} = %packageNames
  var
    nimbleFilePath = findNimbleFile(storePath, true)
    pkg = getPkgInfoFromFile(nimbleFilePath, nimbleOptions)
  data{"srcDir"} = %pkg.srcDir

proc prefetchGit(uri: Uri; version: VersionRange): JsonNode =
  var
    uri = uri
    subdir = ""
  uri.scheme.removePrefix("git+")
  if uri.query != "":
    if uri.query.startsWith("subdir="):
      subdir = uri.query[7 .. ^1]
    uri.query = ""
  let cloneUrl = $uri
  let (tag, rev) = matchRev(cloneUrl, version)
  var archiveUri = uri
  archiveUri.scheme = "https"
  archiveUri.path.removeSuffix ".git"
  archiveUri.path = archiveUri.path / "archive" / rev & ".tar.gz"
  let client = newHttpClient()
  defer: close(client)
  let
    archiveUrl = $archiveUri
    resp = head(client, archiveUrl)
  if resp.code in {Http200, Http302}:
    stderr.writeLine "prefetch ", archiveUrl
    var lines = execProcess(
      "nix-prefetch-url",
      args = @[archiveUrl, "--type", "sha256", "--print-path", "--unpack", "--name", "source"],
      options = {poUsePath})
    var
      hash, storePath: string
      off: int
    off.inc parseUntil(lines, hash, {'\n'}, off).succ
    off.inc parseUntil(lines, storePath, {'\n'}, off).succ
    doAssert off == lines.len, "unrecognized nix-prefetch-url output:\n" & lines
    result = %*
      {
        "method":  "fetchzip",
        "path":  storePath,
        "rev":  rev,
        "sha256":  hash,
        "url":  archiveUrl
      }
    if subdir != "":
      result{"subdir"} = %subdir
        # a Nim attribute not used by the fetcher
  else:
    stderr.writeLine "fetch of ", archiveUrl, " returned ", resp.code
    var args = @["--quiet", "--fetch-submodules", "--url", cloneUrl, "--rev", rev]
    stderr.writeLine "prefetch ", cloneUrl
    let dump = execProcess(
      "nix-prefetch-git",
      args = args,
      options = {poUsePath})
    try: result = dump.parseJson
    except CatchableError:
      stderr.writeLine "failed to parse output of nix-prefetch-git ", join(args, " ")
      quit(dump)
    if subdir != "":
      result{"subdir"} = %subdir
        # a Nim attribute not used by the fetcher
    result{"method"} = %"git"
  if tag != "":
    result{"ref"} = %tag
  collectMetadata(result)

proc containsPackageUri(lockAttrs: JsonNode; pkgUrl: string): bool =
  for e in lockAttrs.items:
    if e{"url"}.getStr == pkgUrl:
      return true

proc containsPackage(lockAttrs: JsonNode; pkgName: string): bool =
  for e in lockAttrs.items:
    for other in e{"packages"}.items:
      if other.getStr == pkgName:
        return true

proc collectRequires(pending: var Deque[PkgTuple]; pkgPath: string) =
  var
    nimbleFilePath = findNimbleFile(pkgPath, true)
    pkg = getPkgInfoFromFile(nimbleFilePath, nimbleOptions)
  for pair in pkg.requires:
    if pair.name != "nim" and pair.name != "compiler":
      pending.addLast(pair)

var globalRegistry: JsonNode

type NimbleSource = object
  url, meth: string

proc containsGit(s: string): bool {.inline.} = contains(s, "git")

proc getPackageUrl(name: string): tuple[url: Uri, meth: string] =
  result.url = name.parseUri
  if result.url.scheme != "":
    if result.url.scheme.containsGit or
        result.url.hostname.containsGit or
        result.url.path.endsWith(".git"):
      # TODO: better git heuristic
      result.meth = "git"
  else:
    if globalRegistry.isNil:
      let registryPath = registryCachePath()
      if fileExists(registryPath):
        globalRegistry = parseFile(registryPath)
      else:
        let client = newHttpClient()
        var raw = client.getContent(githubPackagesUrl)
        close(client)
        writeFile(registryPath, raw)
        globalRegistry = parseJson(raw)
    var
      name = name
      i = 0
    while i < globalRegistry.len:
      var e = globalRegistry[i]
      if e["name"].getStr == name:
        if e.hasKey "alias":
          var alias = e["alias"].getStr
          doAssert alias != name
          name = alias
          i = 0
        else:
          try:
            result.url = e["url"].getStr.parseUri
            result.meth = e["method"].getStr
            return
          except CatchableError:
            quit("Failed to parse shit JSON " & $e)
      inc i
    raise newException(KeyError, "package not in global registry: " & name)

proc generateLockfile(directoryPath: string): JsonNode =
  let deps = newJArray()
  var pending: Deque[PkgTuple]
  collectRequires(pending, directoryPath)
  while pending.len > 0:
    let batchLen = pending.len
    for i in 1..batchLen:
      var pkgData: JsonNode
      let pkg = pending.popFirst()
      if pkg.name == "nim" or pkg.name == "compiler":
        continue
      var uri = parseUri(pkg.name)
      if uri.scheme == "":
        if not deps.containsPackage(pkg.name):
          pending.addLast(pkg)
      elif not deps.containsPackageUri(pkg.name):
        if uri.isGitUrl:
          pkgData = prefetchGit(uri, pkg.ver)
        else:
          quit("unhandled URI " & $uri)
        collectRequires(pending, pkgData{"path"}.getStr)
        deps.add pkgData

    if batchLen == pending.len:
      var
        pkgData: JsonNode
        pkg = pending.popFirst()
        info = getPackageUrl(pkg.name)
      case info.meth
      of "git":
        pkgData = prefetchGit(info.url, pkg.ver)
      else:
        quit("unhandled fetch method " & $info.meth & " for " & $info.url)
      collectRequires(pending, pkgData{"path"}.getStr)
      deps.add pkgData
  return %*{"depends": deps}

proc containsComponent(bom: JsonNode; bomRef: string): bool =
  for c in bom{"components"}.items:
    if c{"bom-ref"}.getStr == bomRef:
      return true

type
  Dependency = object
    bomRef, meth: string
    ver: VersionRange
    url: Uri
    purl: Purl

  Dependencies = Deque[Dependency]

proc addComponent(bom: JsonNode; dep: Dependency): PackageInfo =
  ## Add a component that was discovered as a dependency.
  var
    purl = dep.purl
    props = newJArray()
    version, nimbleFilePath: string
  case dep.meth
  of "git":
    let pkgData = prefetchGit(dep.url, dep.ver)
    purl.version = pkgData{"rev"}.getStr
      # store the git commit in the purl
    let gitRef = pkgData{"ref"}.getStr
    if gitRef != "": version = gitRef
      # store the git ref in the component
    nimbleFilePath = pkgData{"path"}.getStr.findNimbleFile(true)
    for (key, val) in pkgData.pairs:
      let vs = val.getStr
      if vs != "":
        var prop = %* { "name": ("nix:fod:" & key), "value": vs }
        props.add prop
  else:
    quit("unhandled fetch method " & dep.meth & " for " & $dep.url)
  result = getPkgInfoFromFile(nimbleFilePath, nimbleOptions)
  if version == "":
    version = purl.version
  var comp = %*
    {
      "type": "library",
      "bom-ref": dep.bomRef,
      "name": result.name,
      "purl": $purl,
      "version": version,
        # git tag as a version, ignore what is in the nimble file
      "properties": props
    }
  assert not bom.containsComponent(dep.bomRef)
  bom{"components"}.add comp

proc populate(
    bom: JsonNode; bomRef: string; pkgInfo: PackageInfo; queue: var Dependencies) =
  let dependsOn = newJArray()
  bom{"dependencies"}.add(%*{ "ref": bomRef, "dependsOn": dependsOn })
  for (dn, dv) in pkgInfo.requires:
    var dep = Dependency(bomRef: dn, ver: dv)
    case dep.bomRef
    of "nim", "compiler": discard # TODO
    else:
      dep.purl = Purl(name: dep.bomRef)
        # set a fallback name
      (dep.url, dep.meth) = getPackageUrl(dep.bomRef)
      dep.purl.setSourceUrl dep.url
      if dep.purl.`type` == "generic":
        dep.purl.`type` = "nim"
          # the purl should have a reasonable name now
      dep.bomRef = dep.purl.name
      dependsOn.add %dep.bomRef
      queue.addLast dep

proc generateBom(nimblePath: string): JsonNode =
  ## Dependencies are processed using a queue.
  ## Deps are appended to the queue in the order that
  ## they appear within a package and each level of the
  ## tree is processed before moving towards an edge.
  ## This has the effect that if a package is specified multiple
  ## times in the tree with the same name and different versions
  ## then the package specified closest to the root is selected.
  var queue: Dependencies
  var pkgInfo =
    if nimblePath.fileExists:
      nimblePath.getPkgInfoFromFile(nimbleOptions)
    else:
      findNimbleFile(nimblePath, true).getPkgInfoFromFile(nimbleOptions)
  result = bomBase
  result{"metadata","component"} = pkgInfo.toComponentJson
  result.populate(pkgInfo.name, pkgInfo, queue)
  while queue.len > 0:
    let dependency = queue.popFirst()
    if not result.containsComponent(dependency.bomRef):
      pkgInfo = result.addComponent(dependency)
      result.populate(dependency.bomRef, pkgInfo, queue)

type Mode = enum
  unspecifiedMode, lockFileMode, bomFromNimbleMode

proc main =
  var
    packagePath: string
    mode = unspecifiedMode
    recursive = true

  proc setMode(m: Mode) =
    if mode notin {unspecifiedMode, mode}:
      quit("nim_lk mode can be specified only once")
    mode = m

  for kind, key, val in getopt():
    case kind
    of cmdArgument:
      case key
      of "bom-from-nimble", "nimble-to-bom", "nimble-to-sbom", "sbom-from-nimble":
        setMode bomFromNimbleMode
      of "nix-from-nimble", "nimble-to-nix":
        mode = lockFileMode
      else:
        if packagePath != "":
          quit("no more than a single package path may be specified")
        packagePath = key
    of cmdShortOption, cmdLongOption:
      case key
      of "recursive", "r":
        recursive = true
      of "flat":
        recursive = false
      else:
        quit("unrecognized flag " & key)
    of cmdEnd: discard

  if packagePath == "":
    packagePath = getCurrentDir()
  elif packagePath.fileExists:
    packagePath = packagePath.parentDir

  nimbleOptions = parseCmdLine()
  nimbleOptions.nimBin = findExe("nim")

  var data =
    case mode
    of unspecifiedMode, lockFileMode:
      generateLockfile(packagePath)
    of bomFromNimbleMode:
      generateBom(packagePath)
  stdout.writeLine data.pretty

main()
