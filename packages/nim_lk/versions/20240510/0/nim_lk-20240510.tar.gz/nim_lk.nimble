author = "Emery Hemingway"
bin = @["nim_lk"]
description = "Tool for generating Nim lockfiles"
license = "BSD-3-Clause"
srcDir = "src"
version = "20240510"

requires "nim >= 2.0.0", "preserves >= 20240114", "https://github.com/nim-lang/atlas.git"
