# SPDX-FileCopyrightText: ☭ Emery Hemingway
# SPDX-License-Identifier: Unlicense

import compiledpatterns, nimbleparser, parse_requires, pkgurls, reporters, versions
  # atlas imports

import std/[algorithm, cmdline, deques, httpclient, json, options, os, osproc, parseutils, streams, strutils, tempfiles, uri]
import preserves

type PkgTuple = tuple
  name: PkgUrl
  ver: VersionInterval

const githubPackagesUrl =
  "https://raw.githubusercontent.com/nim-lang/packages/master/packages.json"

proc registryCachePath: string =
  result = getEnv("XDG_CACHE_HOME")
  if result == "":
    let home = getEnv("HOME")
    if home == "":
      result = getEnv("TMPDIR", "/tmp")
    else:
      result = home / ".cache"
  result.add "/packages.json"

proc isGitUrl(uri: Uri): bool =
  uri.scheme == "git" or
    uri.scheme.startsWith("git+") or
    uri.path.endsWith(".git") or
    uri.hostname.contains("git")

proc startProcess(cmd: string; cmdArgs: varargs[string]): Process =
  startProcess(cmd, args = cmdArgs, options = {poUsePath})

proc gitLsRemote(url: string; withTags: bool): seq[Commit] =
  var process =
    if withTags:
      startProcess("git", "ls-remote", "--tags", url)
    else:
      startProcess("git", "ls-remote", url)
  let outp = process.outputStream.readAll()
  stderr.write(process.errorStream.readAll)
  close(process)
  result = parseTaggedVersions(outp)
  if withTags and result.len == 0:
    result = gitLsRemote(url, not withTags)

proc matchRev(url: string; wanted: VersionInterval): string =
  result = extractSpecificCommit(wanted)
  if result == "":
    const withTags = true
    let commits = gitLsRemote(url, withTags)
    result = selectBestCommitMaxVer(commits, wanted)

proc `[]`(dict: Value; key: string): Value =
  dict[key.toPreserves]

proc `[]=`(dict: var Value; key: string; val: Value) =
  dict[key.toPreserves] = val

proc `[]=`(dict: var Value; key: string; val: string) =
  dict[key.toPreserves] = val.toPreserves

proc collectMetadata(report: var Reporter; data: var Value) =
  let storePath = data["path"].string
  var packageNames = newSeq[string]()
  for (kind, path) in walkDir(storePath):
    if kind in {pcFile, pcLinkToFile} and path.endsWith(".nimble"):
      var (_, name, _) = splitFile(path)
      packageNames.add name
  if packageNames.len == 0:
    quit("no .nimble files found in " & storePath)
  sort(packageNames)
  data["packages"] = packageNames.toPreserves
  var
    ambiguous = true
    nimbleFilePath = findNimbleFile(report, storePath, ambiguous)
    info = extractRequiresInfo(nimbleFilePath)
  data["srcDir"] = info.srcDir.toPreserves

proc prefetchGit(report: var Reporter; uri: Uri; version: VersionInterval): Value =
  var
    uri = uri
    subdir = ""
  uri.scheme.removePrefix("git+")
  if uri.query != "":
    if uri.query.startsWith("subdir="):
      subdir = uri.query[7 .. ^1]
    uri.query = ""
  let cloneUrl = $uri
  let rev = matchRev(cloneUrl, version)
  var archiveUri = uri
  archiveUri.scheme = "https"
  archiveUri.path.removeSuffix ".git"
  archiveUri.path = archiveUri.path / "archive" / rev & ".tar.gz"
  let client = newHttpClient()
  defer: close(client)
  let
    archiveUrl = $archiveUri
    resp = head(client, archiveUrl)
  if resp.code in {Http200, Http302}:
    stderr.writeLine "prefetch ", archiveUrl
    var lines = execProcess(
      "nix-prefetch-url",
      args = @[archiveUrl, "--type", "sha256", "--print-path", "--unpack", "--name", "source"],
      options = {poUsePath})
    var
      hash, storePath: string
      off: int
    off.inc parseUntil(lines, hash, {'\n'}, off).succ
    off.inc parseUntil(lines, storePath, {'\n'}, off).succ
    doAssert off == lines.len, "unrecognized nix-prefetch-url output:\n" & lines
    result = initDictionary()
    result["method"] = "fetchzip"
    result["path"] = storePath
    result["rev"] = rev
    result["sha256"] = hash
    result["url"] = archiveUrl
    if subdir != "":
      result["subdir"] = subdir
  else:
    stderr.writeLine "fetch of ", archiveUrl, " returned ", resp.code
    var args = @["--quiet", "--fetch-submodules", "--url", cloneUrl, "--rev", rev]
    stderr.writeLine "prefetch ", cloneUrl
    let dump = execProcess(
      "nix-prefetch-git",
      args = args,
      options = {poUsePath})
    try: result = parsePreserves dump
    except CatchableError:
      stderr.writeLine "failed to parse output of nix-prefetch-git ", join(args, " ")
      quit(dump)
    if subdir != "":
      result["subdir"] = subdir
    result["method"] = "git"
  collectMetadata(report, result)

proc containsPackageUri(lockAttrs: Value; pkgUri: string): bool =
  for e in lockAttrs.items:
    var val = e.step("url".toPreserves)
    if val.isSome and val.get.string == pkgUri:
      return true

proc containsPackage(lockAttrs: Value; pkgName: string): bool =
  for e in lockAttrs.items:
    for other in e["packages"].items:
      if pkgName == other.string:
        return true

proc missingPackages(lockAttrs, packages: Value): bool =
  result = false
  for pkgName in packages.items:
    var found = false
    for e in lockAttrs.items:
      if found: break
      for name in e["packages"].items:
        found = pkgName == name
        if found: break
    result = not found
    if not result: break

proc collectRequires(report:  var Reporter; ctx: NimbleContext; pending: var Deque[PkgTuple]; pkgPath: string) =
  var
    ambiguous = true
    nimbleFilePath = findNimbleFile(report, pkgPath, ambiguous)
    info = parseNimbleFile(ctx, nimbleFilePath, initPatterns())
  for pair in info.deps:
    if pair[0].projectName != "nim" and pair[0].projectName != "compiler":
      pending.addLast(pair)

var globalRegistry: JsonNode

proc getPackgeUri(name: string): tuple[uri: string, meth: string] =
  if globalRegistry.isNil:
    let registryPath = registryCachePath()
    if fileExists(registryPath):
      globalRegistry = parseFile(registryPath)
    else:
      let client = newHttpClient()
      var raw = client.getContent(githubPackagesUrl)
      close(client)
      writeFile(registryPath, raw)
      globalRegistry = parseJson(raw)
  var
    name = name
    i = 0
  while i < globalRegistry.len:
    var e = globalRegistry[i]
    if e["name"].getStr == name:
      if e.hasKey "alias":
        var alias = e["alias"].getStr
        doAssert alias != name
        name = alias
        i = 0
      else:
        try:
          return (e["url"].getStr, e["method"].getStr,)
        except CatchableError:
          quit("Failed to parse shit JSON " & $e)
    inc i

proc generateLockfile(report: var Reporter; ctx: NimbleContext; directoryPath: string): Value =
  result = initDictionary()
  var
    deps = initSequence()
    pending: Deque[PkgTuple]
  collectRequires(report, ctx, pending, directoryPath)
  while pending.len > 0:
    let batchLen = pending.len
    for i in 1..batchLen:
      var pkgData: Value
      let
        pkg = pending.popFirst()
        pkgName = pkg[0].projectName
        pkgUri = pkg[0].url
      if pkgName == "nim" or pkgName == "compiler":
        continue
      var uri = pkgUri.parseUri
      if uri.scheme == "":
        if not deps.containsPackage(pkgName):
          pending.addLast(pkg)
      elif not deps.containsPackageUri(pkgUri):
        if uri.isGitUrl:
          pkgData = prefetchGit(report, uri, pkg.ver)
        else:
          quit("unhandled URI " & pkgUri)
        if deps.missingPackages pkgData["packages"]:
          collectRequires(report, ctx, pending, pkgData["path"].string)
          deps.sequence.add pkgData

    if batchLen == pending.len:
      var
        pkgData: Value
        pkg = pending.popFirst()
        info = getPackgeUri(pkg[0].projectName)
        uri = parseUri info.uri
      case info.meth
      of "git":
        pkgData = prefetchGit(report, uri, pkg.ver)
      else:
        quit("unhandled fetch method " & $info.meth & " for " & info.uri & " of " & pkg[0].projectName)
      collectRequires(report, ctx, pending, pkgData["path"].string)
      deps.sequence.add pkgData
  sort(deps.sequence)
  result["depends".toPreserves] = deps

proc main =
  var packagePath = getCurrentDir()
  case paramCount()
  of 0: discard
  of 1:
    packagePath = commandLineParams()[0]
  else:
    quit "no more than a single package path may be specified"
  var
    stream = newFileStream(stdout)
    report = Reporter()
    context = createNimbleContext(report, createTempDir("atlas", "deps"))
    lockInfo = generateLockfile(report, context, packagePath)
  cannonicalize(lockInfo)
  writeText(stream, lockInfo, textJson)
  writeLine(stream)
  close(stream)

main()
