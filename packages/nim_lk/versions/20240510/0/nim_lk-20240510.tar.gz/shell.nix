let pkgs = import <nixpkgs> { }; in pkgs.nim_lk
