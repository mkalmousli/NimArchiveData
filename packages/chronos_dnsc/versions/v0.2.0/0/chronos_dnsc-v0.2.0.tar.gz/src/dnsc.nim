# (c) Copyright 2024 Shuhei Nogawa
# This software is released under the MIT License, see LICENSE.
#
# Copyright (c) 2020 rockcavera
# https://github.com/rockcavera/nim-ndns/blob/main/LICENSE

import std/[nativesockets, sysrand]

import
  pkg/[
    chronos,
    chronos/transports/common,
    chronos/osdefs,
    chronos/apps/http/httpcommon,
    dnsprotocol,
    stew/endians2,
  ]

export chronos, dnsprotocol, Port

when defined(nimdoc):
  import ./dnsc/platforms/winapi
  import ./dnsc/platforms/resolv except getSystemDnsServer
else:
  when defined(linux) or defined(bsd) or defined(dnscUseResolver):
    import ./dnsc/platforms/resolv
  elif defined(windows):
    import ./dnsc/platforms/winapi

type
  DnsClient* = object ## Contains information about the DNS server.
    ip: string ## Dns server IP.
    port: Port ## DNS server listening port.
    domain: Domain

  UnexpectedDisconnectionError* = object of CatchableError
    ## Raised if an unexpected disconnect occurs (only TCP).

  ResponseIdNotEqualError* = object of CatchableError
    ## Raised if the query ID does not match the response ID.

  IsNotAnResponseError* = object of CatchableError
    ## Raised if not a response (!= QR.Response).

  OpCodeNotEqualError* = object of CatchableError
    ## Raised if the OpCode is different between the query and the response.

  DnsResponseError* = object of CatchableError
    ## Raised if the DNS response contains an error (rcode != NoError).
    rcode*: RCode

const
  ipv4Arpa = "in-addr.arpa" ## Special domain reserved for reverse IP lookup for IPv4
  ipv6Arpa = "ip6.arpa" ## Special domain reserved for IP reverse query for IPv6
  dnscDnsServerIp* {.strdefine.} = "8.8.8.8"
    ## Default dns server ip for queries. You can change by compiling with
    ## `-d:dnscDnsServerIp=1.1.1.1`.
  dnscDnsServerIpDomain =
    case parseIpAddress(dnscDnsServerIp).family
    of IpAddressFamily.IPv6: Domain.AF_INET6
    of IpAddressFamily.IPv4: Domain.AF_INET
  dnscClient =
    DnsClient(ip: dnscDnsServerIp, port: Port(53), domain: dnscDnsServerIpDomain)

proc initDnsClient*(strIp: string = "", port: Port = Port(53)): DnsClient =
  ## Returns a created `DnsClient` object.
  ##
  ## If `strIp` is empty (default), uses the system DNS server. If the system
  ## DNS server cannot be determined, falls back to `dnscDnsServerIp`.
  ##
  ## **Parameters**
  ## - `strIp` is a DNS server IP. It can be IPv4 or IPv6. It cannot be a domain
  ##   name. If empty, the system DNS server is used.
  ## - `port` is a DNS server listening port.
  ##
  ## Currently system DNS detection is implemented for:
  ## - `Windows<ndns/platforms/winapi.html>`_
  ## - `Linux<ndns/platforms/resolv.html>`_
  ## - `BSD<ndns/platforms/resolv.html>`_
  ##
  ## Notes:
  ## - If your platform is not listed above and uses a `resolver configuration
  ##   file<ndns/platforms/resolv.html>`_, compile with `-d:dnscUseResolver`.
  ## - It just creates a `DnsClient` object with the IP used by the system. Does
  ##   not use the system's native DNS resolution implementation unless the
  ##   system provides a proxy.

  var ipStr = strIp

  if ipStr == "":
    when declared(getSystemDnsServer):
      ipStr = getSystemDnsServer()
    if ipStr == "":
      ipStr = dnscDnsServerIp

  let ip = parseIpAddress(ipStr)

  result.ip = $ip
  result.port = port

  case ip.family
  of IpAddressFamily.IPv6:
    result.domain = AF_INET6
  of IpAddressFamily.IPv4:
    result.domain = AF_INET

proc getUpdatedSystemDnsClient*(port: Port = Port(53)): DnsClient =
  ## Returns a `DnsClient` reflecting the current system DNS server.
  ##
  ## On Linux/BSD, this leverages cached file metadata detection, so repeated
  ## calls are cheap when `/etc/resolv.conf` hasn't changed. On Windows, this
  ## queries the system API each time.
  ##
  ## If the system DNS server cannot be determined, falls back to
  ## `dnscDnsServerIp`.
  ##
  ## This is useful for long-lived applications that need to track system DNS
  ## configuration changes.

  when declared(getSystemDnsServer):
    let ipServDns = getSystemDnsServer()

    if ipServDns != "":
      try:
        return initDnsClient(ipServDns, port)
      except ValueError:
        discard

  result = DnsClient(ip: dnscDnsServerIp, port: port, domain: dnscDnsServerIpDomain)

proc getIp*(client: DnsClient): string =
  ## Returns the IP defined in the `client`.
  client.ip

proc getPort*(client: DnsClient): Port =
  ## Returns the port defined in the `client`.
  client.port

proc parseBinMessage(msg: BinMsg): Message =
  {.cast(gcsafe).}:
    # dnsprotocol procs lack gcsafe and raises annotations.
    # Cast wrappers are used to integrate them with chronos async procs.
    {.cast(raises: [CatchableError]).}:
      result = parseMessage(msg)

proc checkResponse(rBinMsg: string, msg: Message): Message =
  result = parseBinMessage(rBinMsg)

  if result.header.id != msg.header.id:
    raise newException(
      ResponseIdNotEqualError, "The query ID does not match the response ID"
    )

  if result.header.flags.qr != QR.Response:
    raise newException(IsNotAnResponseError, "Not a response (!= QR.Response)")

  if result.header.flags.opcode != msg.header.flags.opcode:
    raise newException(
      OpCodeNotEqualError, "The OpCode is different between the query and the response"
    )

proc toBinTcpMsg(msg: Message): string =
  {.cast(gcsafe).}:
    {.cast(raises: [CatchableError]).}:
      result = toBinMsg(msg, true)

proc toBinMsg(msg: Message): string =
  {.cast(gcsafe).}:
    {.cast(raises: [CatchableError]).}:
      result = toBinMsg(msg, false)

proc dnsTcpQuery*(
    client: DnsClient, msg: Message, timeout: Duration = 5000.milliseconds
): Future[Message] {.async.} =
  ## Returns a `Message` of the DNS query response performed using the TCP
  ## protocol
  ##
  ## **Parameters**
  ## - `client` is a `DnsClient` object that contains the IP and Port of the DNS
  ##   server.
  ## - `msg` is a `Message` object that contains the DNS query.
  ## - `timeout` is the maximum waiting time, in milliseconds, to connect to the
  ##   DNS server. When it is negative (less than 0), it will try to connect for
  ##   an unlimited time.
  ##
  ## **Note:** This proc does not check the response rcode. The caller should
  ## inspect `result.header.flags.rcode` to handle DNS errors (e.g., NXDomain,
  ## ServFail). For automatic rcode checking, use the high-level `resolveIpv4`,
  ## `resolveIpv6`, or `resolveRDns` procs instead.

  let
    qBinMsg = toBinTcpMsg(msg)
    address = initTAddress(client.ip, client.port)
    deadline = Moment.now() + timeout
    transpFut = connect(address)
    transp =
      if await transpFut.withTimeout(timeout):
        transpFut.read
      else:
        raise newException(IOError, "timeout")

  try:
    block:
      let remaining = deadline - Moment.now()
      if remaining <= ZeroDuration:
        raise newException(IOError, "timeout")
      if not await transp.write(qBinMsg).withTimeout(remaining):
        raise newException(IOError, "timeout")

    let lenRecv = block:
      let remaining = deadline - Moment.now()
      if remaining <= ZeroDuration:
        raise newException(IOError, "timeout")
      let lenRecvFut = transp.read(2)
      if await lenRecvFut.withTimeout(remaining):
        lenRecvFut.read
      else:
        raise newException(IOError, "timeout")

    if lenRecv.len < 2:
      raise newException(
        UnexpectedDisconnectionError, "Connection closed while reading message length"
      )

    let messageLen = int(
      fromBytes(uint16, [uint8(ord(lenRecv[0])), uint8(ord(lenRecv[1]))], bigEndian)
    )

    if messageLen == 0:
      raise newException(
        UnexpectedDisconnectionError, "Received empty DNS message (length = 0)"
      )

    var
      remainderRecv = messageLen
      rBinMsg = newStringOfCap(remainderRecv)

    while remainderRecv > 0:
      let remaining = deadline - Moment.now()
      if remaining <= ZeroDuration:
        raise newException(IOError, "timeout")

      let
        recvFut = transp.read(remainderRecv)
        recv =
          if await recvFut.withTimeout(remaining):
            recvFut.read
          else:
            raise newException(IOError, "timeout")

      if recv.len == 0:
        raise newException(UnexpectedDisconnectionError, "Unexpected disconnection")

      rBinMsg.add bytesToString(recv)
      remainderRecv = remainderRecv - recv.len

    result = checkResponse(rBinMsg, msg)
  finally:
    await transp.closeWait

proc dnsQuery*(
    client: DnsClient,
    msg: Message,
    timeout: Duration = 500.milliseconds,
    retransmit = false,
    tcpTimeout: Duration = 5000.milliseconds,
): Future[Message] {.async.} =
  ## Returns a `Message` of the DNS query response performed using the UDP
  ## protocol.
  ##
  ## **Parameters**
  ## - `client` is a `DnsClient` object that contains the IP and Port of the DNS
  ##   server.
  ## - `msg` is a `Message` object that contains the DNS query.
  ## - `timeout` is the maximum waiting time, in milliseconds, to receive the
  ##   response from the DNS server. When it is negative (less than 0), it will
  ##   try to receive the response for an unlimited time.
  ## - `retransmit` when `true`, determine the retransmission of the query to
  ##   TCP protocol when the received response is truncated
  ##   (`header.flags.tc == true`).
  ## - `tcpTimeout` is the maximum waiting time for TCP fallback when
  ##   `retransmit` is `true`. Defaults to 5000ms since TCP connections
  ##   typically need more time than UDP.
  ##
  ## **Note:** This proc does not check the response rcode. The caller should
  ## inspect `result.header.flags.rcode` to handle DNS errors (e.g., NXDomain,
  ## ServFail). For automatic rcode checking, use the high-level `resolveIpv4`,
  ## `resolveIpv6`, or `resolveRDns` procs instead.

  let qBinMsg = toBinMsg(msg)

  var receivedDataFuture = newFuture[void]("dnsQuery.receive")
  var remoteAddr: TransportAddress
  var receivedData: seq[byte]

  proc datagramDataReceived(
      transp: DatagramTransport, raddr: TransportAddress
  ): Future[void] {.async: (raises: []).} =
    remoteAddr = raddr
    try:
      receivedData = transp.getMessage()
    except TransportError:
      return
    if not receivedDataFuture.finished:
      receivedDataFuture.complete()

  let sock = newDatagramTransport(datagramDataReceived)

  let address = initTAddress(client.ip, client.port)

  try:
    let deadline = Moment.now() + timeout

    if not await sock.sendTo(address, qBinMsg).withTimeout(timeout):
      raise newException(IOError, "timeout")

    while true:
      let remaining = deadline - Moment.now()
      if remaining <= ZeroDuration:
        raise newException(IOError, "timeout")

      if not (await receivedDataFuture.withTimeout(remaining)):
        raise newException(IOError, "timeout")

      if remoteAddr.toIpAddress() == address.toIpAddress() and
          remoteAddr.port == address.port:
        let rBinMsg = bytesToString(receivedData)

        try:
          result = checkResponse(rBinMsg, msg)
        except ResponseIdNotEqualError, IsNotAnResponseError, OpCodeNotEqualError:
          receivedDataFuture = newFuture[void]("dnsQuery.receive")
          continue

        if retransmit and result.header.flags.tc:
          result = await dnsTcpQuery(client, msg, tcpTimeout)
        return

      # Invalid source address, wait for the next packet
      receivedDataFuture = newFuture[void]("dnsQuery.receive")
  finally:
    await sock.closeWait

template domainNameRDns(strIp, domainV4, domainV6: string) =
  let ip = parseIpAddress(strIp)

  case ip.family
  of IpAddressFamily.IPv4:
    # 15 characters for IPv4 +
    # 1 character for the dot of connection between IPv4 and `domainV4` +
    # `len(domainV4)`
    result = newStringOfCap(16 + len(domainV4))

    for i in countdown(3, 0):
      result.add($ip.address_v4[i])
      result.add('.')

    result.add(domainV4)
  of IpAddressFamily.IPv6:
    const hexDigits = "0123456789abcdef"
    # 63 characters for IPv6 +
    # 1 character for the dot of connection between IPv6 and `domainV6` +
    # `len(domainV6)`

    result = newStringOfCap(64 + len(domainV6))

    for i in countdown(15, 0):
      let
        hi = (ip.address_v6[i] shr 4) and 0xF
        lo = ip.address_v6[i] and 0xF

      add(result, hexDigits[lo])
      add(result, '.')
      add(result, hexDigits[hi])
      add(result, '.')

    result.add(domainV6)

proc checkRcode(msg: Message) =
  if msg.header.flags.rcode != RCode.NoError:
    let err = newException(
      DnsResponseError, "DNS query failed with rcode: " & $msg.header.flags.rcode
    )
    err.rcode = msg.header.flags.rcode
    raise err

proc prepareRDns*(strIp: string): string =
  ## Returns a domain name for reverse DNS lookup.
  ##
  ## **Parameters**
  ## - `ip` is the IP address you want to query. It can be an IPv4 or IPv6. It
  ##   cannot be a domain name.

  domainNameRDns(strIp, ipv4Arpa, ipv6Arpa)

proc prepareDnsBL*(strIp, dnsbl: string): string =
  ## Returns a domain name for DnsBL query.
  ##
  ## **Parameters**
  ## - `ip` is the IP address you want to query. It can be an IPv4 or IPv6. It
  ##   cannot be a domain name.
  ## - `dnsbl` is the domain name that maintains the blacklist.

  domainNameRDns(strIp, dnsbl, dnsbl)

proc randId*(): uint16 =
  ## Returns a `uint16`, randomly generated, to be used as an id.

  var buf: array[2, byte]
  doAssert urandom(buf)
  result = fromBytes(uint16, buf, bigEndian)

proc resolveIp(
    client: DnsClient, domain: string, timeout: Duration, qtype: QType
): Future[seq[string]] {.async.} =
  let
    msg = initMessage(
      initHeader(id = randId(), rd = true), @[initQuestion(domain, qtype, QClass.IN)]
    )
    rmsg = await dnsQuery(client, msg, timeout, true)

  checkRcode(rmsg)

  for rr in rmsg.answers:
    if rr.class != Class.IN:
      continue

    case qtype
    of QType.A:
      if rr.`type` == Type.A:
        let ip =
          IpAddress(family: IpAddressFamily.IPv4, address_v4: RDataA(rr.rdata).address)
        add(result, $ip)
    of QType.AAAA:
      if rr.`type` == Type.AAAA:
        let ip = IpAddress(
          family: IpAddressFamily.IPv6, address_v6: RDataAAAA(rr.rdata).address
        )
        add(result, $ip)
    else:
      discard

proc resolveIpv4*(
    client: DnsClient, domain: string, timeout: Duration = 500.milliseconds
): Future[seq[string]] {.async.} =
  ## Returns all IPv4 addresses, in a `seq[string]`, that have been resolved
  ## from `domain`. The `seq[string]` can be empty.
  ##
  ## **Parameters**
  ## - `client` is a `DnsClient` object that contains the IP and Port of the DNS
  ##   server.
  ## - `domain` is the domain name that you wish to obtain IPv4 addresses.
  ## - `timeout` is the maximum waiting time, in milliseconds, to connect to the
  ##   DNS server or to receive the response from the DNS server. When it is
  ##   negative (less than 0), it will try to connect for an unlimited time or
  ##   to receive the response for an unlimited time.

  result = await resolveIp(client, domain, timeout, QType.A)

proc resolveIpv6*(
    client: DnsClient, domain: string, timeout: Duration = 500.milliseconds
): Future[seq[string]] {.async.} =
  ## Returns all IPv6 addresses, in a `seq[string]`, that have been resolved
  ## from `domain`. The `seq[string]` can be empty.
  ##
  ## **Parameters**
  ## - `client` is a `DnsClient` object that contains the IP and Port of the DNS
  ##   server.
  ## - `domain` is the domain name that you wish to obtain IPv6 addresses.
  ## - `timeout` is the maximum waiting time, in milliseconds, to connect to the
  ##   DNS server or to receive the response from the DNS server. When it is
  ##   negative (less than 0), it will try to connect for an unlimited time or
  ##   to receive the response for an unlimited time.

  result = await resolveIp(client, domain, timeout, QType.AAAA)

proc resolveRDns*(
    client: DnsClient, strIp: string, timeout: Duration = 500.milliseconds
): Future[seq[string]] {.async.} =
  ## Returns all domain names, in a `seq[string]`, which is obtained by the
  ## "reverse" query of `ip`. The `seq[string]` can be empty.
  ##
  ## **Parameters**
  ## - `client` is a `DnsClient` object that contains the IP and Port of the DNS
  ##   server.
  ## - `ip` is the IPv4 or IPv6 address that is intended to obtain the domain
  ##   name, which represents the reverse address.
  ## - `timeout` is the maximum waiting time, in milliseconds, to connect to the
  ##   DNS server or to receive the response from the DNS server. When it is
  ##   negative (less than 0), it will try to connect for an unlimited time or
  ##   to receive the response for an unlimited time.

  let
    msg = initMessage(
      initHeader(id = randId(), rd = true),
      @[initQuestion(prepareRDns(strIp), QType.PTR, QClass.IN)],
    )
    rmsg = await dnsQuery(client, msg, timeout, true)

  checkRcode(rmsg)

  for rr in rmsg.answers:
    if rr.name != msg.questions[0].qname or rr.`type` != Type.PTR or rr.class != Class.IN:
      continue

    add(result, RDataPTR(rr.rdata).ptrdname)

proc resolveDnsBL*(
    client: DnsClient, strIp, dnsbl: string, timeout: Duration = 500.milliseconds
): Future[seq[string]] {.async.} =
  ## Returns IPv4 addresses. Usually the loopback address (127.0.0.0/24), in
  ## which the last octet of IPv4 represents something on the black list.
  ##
  ## **Parameters**
  ## - `client` is a `DnsClient` object that contains the IP and Port of the DNS
  ##   server.
  ## - `ip` is the IPv4 or IPv6 address that you want to know if it is
  ##   blacklisted.
  ## - `dnsbl` is the domain name for DnsBL queries.
  ## - `timeout` is the maximum waiting time, in milliseconds, to connect to the
  ##   DNS server or to receive the response from the DNS server. When it is
  ##   negative (less than 0), it will try to connect for an unlimited time or
  ##   to receive the response for an unlimited time.
  ##
  ## **Note:** Returns an empty `seq` when the IP is not blacklisted (NXDOMAIN).
  ## Other DNS errors still raise `DnsResponseError`.

  let
    domain = prepareDnsBL(strIp, dnsbl)
    msg = initMessage(
      initHeader(id = randId(), rd = true), @[initQuestion(domain, QType.A, QClass.IN)]
    )
    rmsg = await dnsQuery(client, msg, timeout, true)

  if rmsg.header.flags.rcode == RCode.NameError:
    return

  checkRcode(rmsg)

  for rr in rmsg.answers:
    if rr.class != Class.IN or rr.`type` != Type.A:
      continue
    let ip =
      IpAddress(family: IpAddressFamily.IPv4, address_v4: RDataA(rr.rdata).address)
    add(result, $ip)
