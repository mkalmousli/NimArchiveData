switch("mm", "markAndSweep")
