## Markdown rendering with caching and template application
## Handles date extraction, HTML caching, link processing, and page generation.
## See `blg <blg.html>`_ for template override instructions.

import std/[os, times, strutils, options]
import md, types, datetime, dynload

var helperLib*: TemplateLib  ## Set by blg.nim to enable template overrides

proc isIsoDate*(line: string): bool =
  ## True if line starts with YYYY-MM-DD, optionally with HH:MM[:SS].
  let s = line.strip
  if s.len < 10: return false
  # Check format: 4 digits, hyphen, 2 digits, hyphen, 2 digits
  if s.len >= 10 and
     s[0].isDigit and s[1].isDigit and s[2].isDigit and s[3].isDigit and
     s[4] == '-' and
     s[5].isDigit and s[6].isDigit and
     s[7] == '-' and
     s[8].isDigit and s[9].isDigit:
    # Date only - must be end of line or followed by whitespace
    if s.len == 10:
      return true
    # Must have whitespace after date
    if s[10] notin Whitespace:
      return false
    # Check for optional time HH:MM
    if s.len >= 16:
      let timeStart = 11
      if s[timeStart].isDigit and s[timeStart+1].isDigit and
         s[timeStart+2] == ':' and
         s[timeStart+3].isDigit and s[timeStart+4].isDigit:
        # HH:MM format - check if end or has seconds
        if s.len == 16:
          return true
        if s[16] in Whitespace:
          return true
        # Check for seconds :SS
        if s.len >= 19 and s[16] == ':' and
           s[17].isDigit and s[18].isDigit:
          return s.len == 19 or s[19] in Whitespace
        return false
    # Just date followed by whitespace (no valid time)
    return true
  false

proc extractIsoDate*(content: string): Option[(Time, bool)] =
  ## Parse date from first line; returns (Time, hasTime) or none.
  var i = 0
  while i < content.len and content[i] in Whitespace:
    inc i

  var lineEnd = i
  while lineEnd < content.len and content[lineEnd] notin {'\n', '\r'}:
    inc lineEnd

  let firstLine = content[i..<lineEnd].strip
  if not isIsoDate(firstLine):
    return none((Time, bool))

  try:
    # Try parsing with time (HH:MM:SS)
    if firstLine.len >= 19 and firstLine[10] in Whitespace and firstLine[13] == ':' and firstLine[16] == ':':
      let dateTimeStr = firstLine[0..9] & " " & firstLine[11..18]
      return some((parse(dateTimeStr, "yyyy-MM-dd HH:mm:ss").toTime, true))
    # Try parsing with time (HH:MM)
    if firstLine.len >= 16 and firstLine[10] in Whitespace and firstLine[13] == ':':
      let dateTimeStr = firstLine[0..9] & " " & firstLine[11..15]
      return some((parse(dateTimeStr, "yyyy-MM-dd HH:mm").toTime, true))
    # Date only
    let dateStr = firstLine[0..9]  # YYYY-MM-DD
    result = some((parse(dateStr, "yyyy-MM-dd").toTime, false))
  except:
    result = none((Time, bool))

proc stripDateLine*(content: string): string =
  ## Remove leading ISO date line before markdown rendering.
  # Skip leading whitespace
  var i = 0
  while i < content.len and content[i] in Whitespace:
    inc i

  # Find end of first line
  var lineEnd = i
  while lineEnd < content.len and content[lineEnd] notin {'\n', '\r'}:
    inc lineEnd

  let firstLine = content[i..<lineEnd]
  if not isIsoDate(firstLine):
    return content

  # Skip past the date line and any following whitespace
  i = lineEnd
  while i < content.len and content[i] in Whitespace:
    inc i

  content[i..^1]

proc formatDate*(t: Time, hasTime = false): string =
  ## Format date, appending time if hasTime is true.
  result = formatTime(t)
  if hasTime:
    let dt = t.local
    # Check if seconds are non-zero to decide format
    if dt.second != 0:
      result &= " " & dt.format("HH:mm:ss")
    else:
      result &= " " & dt.format("HH:mm")

proc generatePageLinks*(listSlug: string, current, total: int, urlSuffix = ".html"): seq[PageLink] =
  ## Generate pagination with ellipsis for large page counts.
  if total <= 1:
    return @[]

  proc pageUrl(p: int): string =
    if p == 1: listSlug & urlSuffix
    else: listSlug & "-" & $p & urlSuffix

  var pages: seq[int]

  if total <= 7:
    # Show all pages if 7 or fewer
    for i in 1..total:
      pages.add(i)
  else:
    # Always show first page
    pages.add(1)

    # Window around current page (2 on each side)
    let windowStart = max(2, current - 2)
    let windowEnd = min(total - 1, current + 2)

    # Add ellipsis if gap after first
    if windowStart > 2:
      pages.add(-1)  # -1 = ellipsis

    for i in windowStart..windowEnd:
      pages.add(i)

    # Add ellipsis if gap before last
    if windowEnd < total - 1:
      pages.add(-1)

    # Always show last page
    pages.add(total)

  for p in pages:
    if p == -1:
      result.add(PageLink(ellipsis: true))
    else:
      result.add(PageLink(page: p, url: pageUrl(p), current: p == current))

include "templates/helpers.nimf"

# Dispatch procs - check dynlib override, fallback to builtin
proc renderMenuItem(item: MenuItem): string =
  if helperLib.renderMenuItem != nil:
    helperLib.renderMenuItem(item)
  else:
    builtinRenderMenuItem(item)

proc renderHead(fullTitle: string, config: SiteConfig): string =
  if helperLib.renderHead != nil:
    helperLib.renderHead(fullTitle, config)
  else:
    builtinRenderHead(fullTitle, config)

proc renderTopNav(topMenu: seq[MenuItem]): string =
  if helperLib.renderTopNav != nil:
    helperLib.renderTopNav(topMenu)
  else:
    builtinRenderTopNav(topMenu)

proc renderSiteHeader(config: SiteConfig): string =
  if helperLib.renderSiteHeader != nil:
    helperLib.renderSiteHeader(config)
  else:
    builtinRenderSiteHeader(config)

proc renderFooter(bottomMenu: seq[MenuItem], hasMultipleMenus: bool): string =
  if helperLib.renderFooter != nil:
    helperLib.renderFooter(bottomMenu, hasMultipleMenus)
  else:
    builtinRenderFooter(bottomMenu, hasMultipleMenus)

include "templates/page.nimf"
include "templates/post.nimf"
include "templates/list.nimf"

proc renderMarkdown*(path: string, cacheDir: string, force = false): tuple[content: string, changed: bool] =
  ## Render markdown to HTML with caching; returns (html, wasRerendered).
  let cachePath = cacheDir / path.splitFile.name & ".html"
  let srcMtime = getFileInfo(path).lastWriteTime

  if not force and fileExists(cachePath):
    let cacheMtime = getFileInfo(cachePath).lastWriteTime
    if cacheMtime > srcMtime:
      return (readFile(cachePath), false)

  let content = readFile(path).stripDateLine.insertReadMoreMarker
  let rendered = markdown(content)
  createDir(cacheDir)
  writeFile(cachePath, rendered)
  (rendered, true)

proc linkFirstH1*(content: string, url: string): string =
  ## Wrap first <h1> content in a link for clickable post titles.
  let h1Start = content.find("<h1>")
  if h1Start < 0:
    return content
  let h1End = content.find("</h1>", h1Start)
  if h1End < 0:
    return content
  let tagEnd = h1Start + 4  # after "<h1>"
  let inner = content[tagEnd..<h1End]
  result = content[0..<tagEnd] & "<a href=\"" & url & "\">" & inner & "</a>" & content[h1End..^1]

proc extractPreview*(content: string): string =
  ## Return content up to <read-more/> or first </p>.
  let marker = "<read-more/>"
  let markerPos = content.find(marker)
  if markerPos >= 0:
    result = content[0..<markerPos]
  else:
    # Take first paragraph if no marker found
    let pEnd = content.find("</p>")
    if pEnd >= 0:
      result = content[0..pEnd+3]
    else:
      result = content

proc isExternalUrl(url: string, baseUrl: string): bool =
  ## True if URL points to a different domain.
  if url.len == 0 or url[0] == '#':
    return false  # anchor link
  if url[0] == '/':
    return false  # root-relative (internal)
  if not url.startsWith("http://") and not url.startsWith("https://"):
    return false  # relative path (internal)
  if baseUrl.len > 0 and url.startsWith(baseUrl):
    return false  # matches our base URL (internal)
  return true

proc processLinks*(html: string, config: SiteConfig): string =
  ## Rewrite relative URLs to absolute; mark external links with target="_blank".
  result = html

  if config.baseUrl.len == 0:
    # No base URL - only process external links in href (not src)
    # Look for <a with href="http(s)://..." that doesn't match any base
    var i = 0
    while i < result.len:
      let aStart = result.find("<a ", i)
      if aStart < 0:
        break
      let aEnd = result.find(">", aStart)
      if aEnd < 0:
        break

      # Extract the <a ...> tag
      let tag = result[aStart..aEnd]
      let hrefStart = tag.find("href=\"")
      if hrefStart >= 0:
        let urlStart = hrefStart + 6
        let urlEnd = tag.find("\"", urlStart)
        if urlEnd > urlStart:
          let url = tag[urlStart..<urlEnd]
          if isExternalUrl(url, ""):
            # Add external link attributes
            var newTag = tag
            # Add class
            let classPos = newTag.find("class=\"")
            if classPos >= 0:
              let classInsert = classPos + 7
              newTag = newTag[0..<classInsert] & "external " & newTag[classInsert..^1]
            else:
              newTag = newTag[0..1] & " class=\"external\"" & newTag[2..^1]
            # Add target and rel if not present
            if not newTag.contains("target="):
              newTag = newTag[0..^2] & " target=\"_blank\">"
            if not newTag.contains("rel="):
              newTag = newTag[0..^2] & " rel=\"noopener noreferrer\">"
            result = result[0..<aStart] & newTag & result[aEnd+1..^1]
            i = aStart + newTag.len
            continue

      i = aEnd + 1
  else:
    # Have base URL - process both root-relative and external links
    var i = 0
    while i < result.len:
      # Find href=" or src="
      let hrefPos = result.find("href=\"", i)
      let srcPos = result.find("src=\"", i)

      var attrPos = -1
      var attrLen = 0
      var isHref = false

      if hrefPos >= 0 and (srcPos < 0 or hrefPos < srcPos):
        attrPos = hrefPos
        attrLen = 6  # len of href="
        isHref = true
      elif srcPos >= 0:
        attrPos = srcPos
        attrLen = 5  # len of src="
        isHref = false

      if attrPos < 0:
        break

      let urlStart = attrPos + attrLen
      let urlEnd = result.find("\"", urlStart)
      if urlEnd < 0:
        i = urlStart
        continue

      let url = result[urlStart..<urlEnd]

      # Handle "." (current directory) specially for index/home links
      if url == ".":
        if config.baseUrl.len > 0:
          # With baseUrl, convert "." to "baseUrl/"
          let absoluteUrl = config.baseUrl & "/"
          result = result[0..<urlStart] & absoluteUrl & result[urlEnd..^1]
          i = urlStart + absoluteUrl.len + 1
        else:
          # Without baseUrl, leave "." as-is
          i = urlEnd + 1
        continue

      # Convert relative URLs to absolute (both /path and path.html forms)
      if url.len > 0 and url[0] notin {'#', '/'} and
         not url.startsWith("http://") and not url.startsWith("https://") and
         not url.startsWith("mailto:") and not url.startsWith("data:"):
        # Relative path like "index.html" -> "https://base.url/index.html"
        let absoluteUrl = config.baseUrl & "/" & url
        result = result[0..<urlStart] & absoluteUrl & result[urlEnd..^1]
        i = urlStart + absoluteUrl.len + 1
        continue

      if url.len > 0 and url[0] == '/':
        # Root-relative path like "/path" -> "https://base.url/path"
        let absoluteUrl = config.baseUrl & url
        result = result[0..<urlStart] & absoluteUrl & result[urlEnd..^1]
        i = urlStart + absoluteUrl.len + 1
        continue

      # Mark external links (only for href, not src)
      if isHref and isExternalUrl(url, config.baseUrl):
        # Find the <a tag start
        var tagStart = attrPos
        while tagStart > 0 and result[tagStart] != '<':
          dec tagStart
        if tagStart >= 0 and result[tagStart..<tagStart+3] == "<a ":
          let tagEnd = result.find(">", attrPos)
          if tagEnd > attrPos:
            var tag = result[tagStart..tagEnd]
            var modified = false

            # Add class
            let classPos = tag.find("class=\"")
            if classPos >= 0:
              let classInsert = classPos + 7
              tag = tag[0..<classInsert] & "external " & tag[classInsert..^1]
              modified = true
            else:
              # Insert after <a
              tag = tag[0..1] & " class=\"external\"" & tag[2..^1]
              modified = true

            # Add target and rel if not present
            if not tag.contains("target="):
              tag = tag[0..^2] & " target=\"_blank\">"
              modified = true
            if not tag.contains("rel="):
              tag = tag[0..^2] & " rel=\"noopener noreferrer\">"
              modified = true

            if modified:
              result = result[0..<tagStart] & tag & result[tagEnd+1..^1]
              i = tagStart + tag.len
              continue

      i = urlEnd + 1

proc renderPage*(src: SourceFile, menus: seq[seq[MenuItem]], config: SiteConfig): string =
  ## Render a static page (no date/tags shown).
  pageTemplate(src.title, src.content, src.createdAt, src.modifiedAt, menus, config).processLinks(config)

proc renderPost*(src: SourceFile, menus: seq[seq[MenuItem]], config: SiteConfig): string =
  ## Render a blog post with date and tags.
  postTemplate(src.title, src.content, src.createdAt, src.modifiedAt, src.createdAtHasTime, menus, src.tags, config).processLinks(config)

proc renderList*(listTitle: string, posts: seq[SourceFile], menus: seq[seq[MenuItem]], page, totalPages: int, urlSuffix = ".html", config: SiteConfig): string =
  ## Render paginated post list for index or tag pages.
  var previews: seq[PostPreview]
  for post in posts:
    let url = post.slug & urlSuffix
    previews.add(PostPreview(
      slug: post.slug,
      preview: linkFirstH1(extractPreview(post.content), url),
      url: url,
      date: post.createdAt,
      dateHasTime: post.createdAtHasTime,
      tags: post.tags
    ))
  listTemplate(listTitle, previews, menus, page, totalPages, urlSuffix, config).processLinks(config)
