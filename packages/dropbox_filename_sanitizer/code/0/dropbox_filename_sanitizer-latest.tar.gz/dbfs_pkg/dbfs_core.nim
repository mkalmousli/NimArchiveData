import
  strutils, macros, bb_os


macro read_rst_list(rst_filename: static[string]): expr =
  ## Reads `rst_filename` and returns a sequence of strings found in it.
  ##
  ## This is used in const blocks, the returned value is like you writing
  ## @[...] with the ellipsis replaced with the contents of the file.
  let input = slurp(rst_filename)
  result = newNimNode(nnkStmtList)
  let brackets = newNimNode(nnkBracket)

  for line in input.split_lines:
    let
      first = line.find("``")
      last = line.rfind("``")
    if last <= first: continue
    var text = line[first + 2 .. last - 1]
    text = text.replace("\\r", "\r")
    #echo "Found '", text, "'"
    brackets.add(newStrLitNode(text))

  result.add(prefix(brackets, "@"))


const
  version_int* = (major: 0, minor: 4, maintenance: 1) ## \
  ## Module version as an integer tuple.
  ##
  ## Major versions changes mean a break in API backwards compatibility, either
  ## through removal of symbols or modification of their purpose.
  ##
  ## Minor version changes can add procs (and maybe default parameters). Minor
  ## odd versions are development/git/unstable versions. Minor even versions
  ## are public stable releases.
  ##
  ## Maintenance version changes mean I'm not perfect yet despite all the kpop
  ## I watch.
  version_str* = ($version_int.major & "." & $version_int.minor & "." &
      $version_int.maintenance) ## \
    ## Module version as a string. Something like ``1.9.2``.

  ignored_paths* = read_rst_list("docs"/"ignored_paths.rst")

  last_run_witness_filename* = ".dropbox_filename_sanitizer_last_run"


proc replace_bad_dropbox_chars*(TEXT: var string): bool {.discardable.} =
  ## Modifies `TEXT` to contain only dropbox approved characters.
  ##
  ## Returns ``true`` if `TEXT` had to be modified, ``false`` if there was no
  ## change. You should pass as `TEXT` only the **base** name of the path, or
  ## the slashes will be changed malforming the path!
  ##
  ## See https://www.dropbox.com/help/145 for information about bad chars.
  let original = TEXT
  TEXT = TEXT.strip()
  TEXT = TEXT.replace('/', '_')
  TEXT = TEXT.replace('\\', '_')
  TEXT = TEXT.replace(':', ',')
  TEXT = TEXT.replace('<', '[')
  TEXT = TEXT.replace('>', ']')
  TEXT = TEXT.replace('|', '_')
  TEXT = TEXT.replace('"', '\'')
  TEXT = TEXT.replace('?', '_')
  TEXT = TEXT.replace('*', '_')
  # Trim trailing dots.
  while TEXT.len > 0:
    let last = high(TEXT)
    if TEXT[last] == '.':
      TEXT.setLen(last)
    else:
      break
  result = not (original == TEXT)


proc sanitize*(path: string, mutate = true): bool =
  ## Sanitizes a specific path, file or directory.
  ##
  ## The path will be sanitized, and then if a directory recursively iterated.
  ## If `mutate` is false, actions will be reported on stdout but not done.
  ##
  ## Returns false if something went wrong and the program should quit with a
  ## non zero status.
  let
    is_dir = path.exists_dir
    is_file = path.exists_file
  if (not is_dir) and (not is_file):
    echo "Invalid '" & path & "' not a file or directory."
    return

  # From here on, presume we succeeded and report failures.
  result = true

  let (dir, name, ext) = path.split_file
  var VALID = name & ext
  # Ignore some paths anyway.
  for ignored_path in ignored_paths:
    if cmp_ignore_case(VALID, ignored_path) == 0:
      return
  if replace_bad_dropbox_chars(VALID):
    if mutate:
      let target = dir / VALID
      echo "'" & path & "' -> '" & target & "'"
      move_file(path, target)
    else:
      echo "Would change '" & path & "' to '" & dir / VALID & "'"

  # Initiate recursion? Only for directories.
  if is_dir:
    let final_path = dir / VALID
    for kind, path in final_path.dot_walk_dir:
      if not sanitize(path):
        result = false
