[Package]
name          = "dropbox_filename_sanitizer"
version       = "0.4.1"
author        = "Grzegorz Adam Hankiewicz"
description   = """Mangles filename for dropbox compatibility."""
license       = "MIT"
bin           = "dropbox_filename_sanitizer"


installDirs = """

dbfs_pkg
docs
lazy_rest_pkg

"""

InstallFiles = """

LICENSE.rst
README.rst
nakefile.nim

"""

[Deps]
Requires: """

nake >= 1.2
argument_parser >= 0.1.2
https://github.com/gradha/badger_bits.git >= 0.2.5
nim >= 0.10.2


"""
