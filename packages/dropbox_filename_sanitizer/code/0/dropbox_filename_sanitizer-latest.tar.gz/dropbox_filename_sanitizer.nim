import
  argument_parser, os, tables, strutils, times, dbfs_pkg/dbfs_core


type
  Tglobal = object ## \
    ## Holds all the global variables of the process.
    params: Tcommandline_results
    mutate: bool ## True if the user is mutating problematic files.
    period: int ## Less than 1 if not used, or the minimum elapsed time.


var G: Tglobal


const
  param_help = @["-h", "--help"]
  help_help = "Displays commandline help and exits."

  param_version = @["-v", "--version"]
  help_version = "Displays the current version and exists."

  param_period = @["-p", "--period"]
  help_period = "Require elapsed seconds since last run."

  param_mutate = @["-m", "--mutate"]
  help_mutate = "Mangle bad characters into common placeholders, " &
    "by default files are only displayed."

when ignored_paths.len < 1:
  {.fatal: "Could not read any paths to ignore, that's bad.".}

proc process_commandline() =
  ## Parses the commandline, modifying the global structure.
  var PARAMS: seq[Tparameter_specification] = @[]
  PARAMS.add(new_parameter_specification(PK_HELP,
    names = param_help, help_text = help_help))
  PARAMS.add(new_parameter_specification(PK_INT, names = param_period,
    help_text = help_period))
  PARAMS.add(new_parameter_specification(names = param_version,
    help_text = help_version))
  PARAMS.add(new_parameter_specification(names = param_mutate,
    help_text = help_mutate))

  G.params = parse(PARAMS)

  if G.params.options.has_key(param_version[0]):
    echo "dropbox_filename_sanitizer version ", dbfs_core.version_str
    quit()

  if G.params.options.has_key(param_mutate[0]):
    G.mutate = true

  if G.params.options.has_key(param_period[0]):
    G.period = G.params.options[param_period[0]].int_val
    if G.period < 1:
      echo "Period can't be less than 1 second"
      PARAMS.echo_help
      quit()

  if G.params.positional_parameters.len < 1:
    echo "You need to specify files/directories to sanitize."
    PARAMS.echo_help
    quit()


proc ignore_due_to_recent_run(): bool =
  ## Returns true if the program was run within the specified period time.
  ##
  ## The period time is obtained form G.period. The check for the time is
  ## stored using the witness `last_run_witness_filename
  ## <dbfs_pkg/dbfs_core.nim#last_run_witness_filename>`_ file's modification
  ## time. If there is a serious problem the proc will quit with an error.
  ##
  ## Invoking this proc will overwrite the witness file if the period has
  ## elapsed or the file does not exist.
  assert G.period > 0, "Invalid period!"
  let
    witness = get_home_dir() / last_run_witness_filename
    now = to_seconds(get_time())

  var WITNESS_TIME: float
  try:
    WITNESS_TIME = to_seconds(getLastModificationTime(witness)) +
      float(G.period)
    if WITNESS_TIME > now:
      result = true
    else:
      witness.write_file("")
  except OSError:
    witness.write_file("")



when isMainModule:
  # Gets parameters and extracts them for easy access.
  process_commandline()
  if G.period > 0:
    if ignore_due_to_recent_run():
      quit()

  var DID_FAIL: bool
  for parameter in G.params.positional_parameters:
    if not sanitize(parameter.str_val):
      DID_FAIL = true

  if DID_FAIL: quit(QuitFailure)
