======================================
Dropbox filename sanitizer changes log
======================================

Changes for `dropbox_filename_sanitizer
<https://github.com/gradha/dropbox_filename_sanitizer>`_.

v0.4.1, ????-??-??
------------------

* `Added testing of installation instructions
  <https://github.com/gradha/dropbox_filename_sanitizer/issues/12>`_.
* `Improved shell test script
  <https://github.com/gradha/dropbox_filename_sanitizer/issues/14>`_.
* `Updated to compile with nim and nimble
  <https://github.com/gradha/dropbox_filename_sanitizer/issues/17>`_.
* `Split into importable module and command line tool
  <https://github.com/gradha/dropbox_filename_sanitizer/issues/16>`_.
* `Displays program name in version switch
  <https://github.com/gradha/dropbox_filename_sanitizer/issues/13>`_.

v0.4.0, 2014-04-14
------------------

* `Reversed git-flow branches
  <https://github.com/gradha/dropbox_filename_sanitizer/issues/5>`_.
* `Avoids entering .dropbox.cache dir
  <https://github.com/gradha/dropbox_filename_sanitizer/issues/4>`_.
* `Upgraded nakefile to nake-1.2
  <https://github.com/gradha/dropbox_filename_sanitizer/issues/7>`_.
* `Added binary distribution tasks
  <https://github.com/gradha/dropbox_filename_sanitizer/issues/3>`_.
* `Changed versioning scheme, bumps to 0.4.0
  <https://github.com/gradha/dropbox_filename_sanitizer/issues/6>`_.

v0.2.1, 2013-11-29
------------------

* `Update babel installation instructions
  <https://github.com/gradha/dropbox_filename_sanitizer/issues/1>`_.

v0.2.0, 2013-11-26
------------------

* Initial release.
