* ``..``
* ``.``
* ``.dropbox.cache``
* ``icon\r``
