# Package

version = "0.8.0"
author = "fox0430"
description = "SMTP client implementation using chronos"
license = "MIT"

# Dependencies

requires "nim >= 2.0.16", "chronos >= 4.0.0", "chronicles >= 0.10.3"
