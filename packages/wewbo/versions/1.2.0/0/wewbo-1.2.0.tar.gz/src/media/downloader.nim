
discard """
  Pernah kah kau merasa? Jrek Jrek.
  Saat. AAA. Bayangmupun tak mampu ku lihat lagiiiii
"""

discard """
  ffmpeg -headers \"Referer: https://megacloud.blog/\" -i URL -vcodec libx264 -crf 28 -preset veryfast -r 25 output.mp4
  ffmpeg -headers \"Referer: https://megacloud.blog/\" -i \"$#\" -vf \"ass=local_$#\" sj.mp4
"""

import
  os,
  options,
  strutils,
  sequtils,
  tables

import  
  ../process,
  ../media/[format, types],
  ../tui/logger

type
  FfmpegDownloaderOption* = tuple[
    crf = 28,
    fps = 25,
    sub = true,
    keepFormat = true
  ]    

  FfmpegMediaInput* = tuple[
    media: MediaFormatData,
    outputName: string,
    formatIdentity: FormatIdentity
  ]

  FfmpegDownloader* = ref object of CliApplication
    outdir*: string
    targetExt {.deprecated.}: string = "mp4"
    options*: FfmpegDownloaderOption

proc newFfmpegDownloader*(outdir: string; options: FfmpegDownloaderOption) : FfmpegDownloader =
  result = FfmpegDownloader(
    name: "ffmpeg",
    outdir: outdir,
    options: options
  ).setUp()

method failureHandler(ffmpeg: FfmpegDownloader, context: CLiError) =
  raise newException(ValueError, "ffmpeg is not detected on your system.")

method specialLine*(cli: FfmpegDownloader; text: string) : bool =
  text.contains("time=") 

proc setHeader(ffmpeg: FfmpegDownloader, ty, val: string) =
  let ngantukCok = {
    "userAgent" : "User-Agent",
    "referer" : "Referer",
    "cookie" : "Cookie"
  }.toTable

  ffmpeg.addArg "-headers"
  ffmpeg.addArg "$#: $#" % [ngantukCok[ty], val]

proc setUpHeader(ffmpeg: FfmpegDownloader, headers: Option[MediaHttpHeader]) =
  if headers.isNone :
    return

  for chi, no in headers.get.fieldPairs() :
    if no != "" :
      ffmpeg.setHeader(chi, no)

proc setGatauIniApa(ffmpeg: FfmpegDownloader) {.deprecated.} =
  # Vcodec
  ffmpeg.addArg "-vcodec"
  ffmpeg.addArg "libx264"

  # Crf
  ffmpeg.addArg "-crf"
  ffmpeg.addArg $ffmpeg.options.crf

  # Fps
  ffmpeg.addArg "-r"
  ffmpeg.addArg $ffmpeg.options.fps

proc setInput(ffmpeg: FfmpegDownloader, media: MediaFormatData) =
  ffmpeg.addArg "-i"
  ffmpeg.addArg media.video

proc setOutput(ffmpeg: FfmpegDownloader, output: string, targetExt: string) =
  proc parseTargetFile(s: string) : string = 
    const nega = ["[", "]", "/", "\\", "?", ","]
    result = s.replace(" ", "-")
    
    for ne in nega:
      result = result.replace(ne)

  if not dirExists(ffmpeg.outdir) :
    createDir(ffmpeg.outdir)
  
  ffmpeg.addArg "$#.$#" % [ffmpeg.outdir / output.parseTargetFile(), targetExt]

proc handleSubtite(ffmpeg: FfmpegDownloader, media: MediaFormatData) =
  # Download and convert the sub-file to ass format.
  # Burn the subtitle.
  let
    file = media.subtitle.get.url
    tempFile = "wewbo_sub_file" & ".ass"

  # Set Input
  ffmpeg.addArg "-i"
  ffmpeg.addArg file

  # Set Subtite Codec [ASS]
  ffmpeg.addArg "-c:s"
  ffmpeg.addArg "ass"

  # Download
  ffmpeg.addArg tempFile

  if ffmpeg.execute("Downloading Subtitle...") < 1 :
    ffmpeg.setUpHeader(media.headers)
    ffmpeg.setInput(media)
    ffmpeg.addArg "-vf"
    ffmpeg.addArg "ass=" & tempFile

  else :
    raise newException(ValueError, "Gagal Download Subtitle Jir")

proc deleteTempFile {.nimcall.} = removeFile("wewbo_sub_file.ass")

proc download*(ffmpeg: FfmpegDownloader, input: MediaFormatData, output: string, targetExt: string = "mp4") : int =
  if input.subtitle.isSome and ffmpeg.options.sub:
    ffmpeg.log.info("Extracting subtitle.")
    ffmpeg.setUpHeader(input.headers)
    ffmpeg.handleSubtite(input)
  else:  
    ffmpeg.setUpHeader(input.headers)
    ffmpeg.setInput(input)

  if ffmpeg.options.keepFormat:
    ffmpeg.addArg "-c"
    ffmpeg.addArg "copy"

  ffmpeg.setOutput(output, targetExt)
  ffmpeg.execute("Downloading " & output, after = some(deleteTempFile))

proc downloadAll*(ffmpeg: FfmpegDownloader, inputs: openArray[MediaFormatData], outputs: openArray[string]) : seq[int] {.deprecated.} =
  assert inputs.len == outputs.len

  ffmpeg.log.info("Downloading Options: " & $ffmpeg.options)    
  sleep(3_000)

  for (input, output) in zip(inputs, outputs) :
    result.add(
      ffmpeg.download(input, output))

proc downloadAll*(ffmpeg: FfmpegDownloader; inputs: openArray[FfmpegMediaInput]): seq[int] =
  var targetExt: string

  for (input, output, fmIdentity) in inputs:
    if not ffmpeg.options.keepFormat:
      targetExt = "mp4"
    else:
      targetExt = $fmIdentity.ext
    result.add ffmpeg.download(input, output, targetExt)
