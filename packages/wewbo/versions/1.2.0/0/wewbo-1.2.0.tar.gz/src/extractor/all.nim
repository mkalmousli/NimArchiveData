import
  base,
  tables,
  types,
  strutils,
  options,
  extractors/[
    animepahe,
    kuramanime,
    otakudesu,
    hianime,
    tokyoinsider,
    kickass
  ]

import
  ../tui/[ask, logger],
  media/format

type
  ExtractorInitProc = proc(ex: var BaseExtractor) {.gcsafe.}

proc sukamtoList(): Table[string, ExtractorInitProc] =
  result["pahe"] = newAnimepahe
  result["hime"] = newHianime
  result["kura"] = newKuramanime
  result["taku"] = newOtakudesu
  result["toyo"] = newTokyoInsider
  result["kass"] = newKickass

const sukamto = sukamtoList()

proc listExtractor*() : seq[string] {.gcsafe.} =
  for k in sukamto.keys: result.add(k)

proc getExtractor(name: string, mode: string = "tui"): BaseExtractor {.gcsafe.} = 

  if not sukamto.hasKey(name) :
    raise newException(ValueError, "No source found: " & "'$#'" % [name]) 
  
  sukamto[name](result)
  result.init(
    logMode=detectLogMode(mode)
  )

proc parseTitleAndSource(title, extractorName: string): tuple[anTitle: string, exName: string] =
  var
    exName = extractorName
    anTitle = title

  if title.contains(":"):
    for ex in listExtractor():
      if title.contains(ex) and title.endsWith(ex):
        exName = title.split(":")[^1]
        anTitle = title.replace(exName)[ 0 ..< ^1]

  return (anTitle: anTitle, exName: exName)        

proc ask*(ex: BaseExtractor, title: string) : AnimeData =
  var listAnime = ex.animes(title)
  if listAnime.len < 1 :
    raise newException(AnimeNotFoundError, "No Anime Found")
  return listAnime.ask(title)

proc ask*(ex: BaseExtractor, ad: AnimeData) : tuple[index: int, episodes: seq[EpisodeData]] =
  var
    index: int
    episode: EpisodeData
  let
    animeUrl = ex.get(ad)
    listEpisode = ex.episodes(animeUrl)

  if listEpisode.len < 1 :
    raise newException(EpisodeNotFoundError, "No Episode Found")

  episode = listEpisode.ask()
  index = listEpisode.find(episode)

  return (index: index, episodes: listEpisode)  

proc ask*(ex: BaseExtractor; formats: seq[ExFormatData]; prevSelectedFormat: Option[FormatIdentity] = none(FormatIdentity)): ExFormatData =
  if prevSelectedFormat.isSome:
    for format in formats:
      if prevSelectedFormat.get == detectFormat(format.title):
        return format

  formats.ask("Select Format")    

proc findMatch*(listFormat: seq[ExFormatData]; prevSelectedFormat: Option[FormatIdentity]) : ExFormatData =
  if prevSelectedFormat.isSome:
    for fmt in listFormat:
      if detectFormat(fmt.title) == prevSelectedFormat.get:
        return fmt
  
  listFormat.ask("Select Format")

export
  BaseExtractor,
  AnimeData,
  EpisodeData,
  ExFormatData,
  AllEpisodeFormats

export
  getExtractor

export  
  init, animes, episodes, formats

export  
  getAllEpisodeFormats, get, subtitles, parseTitleAndSource
