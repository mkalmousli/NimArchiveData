# Basic example of using nextract

import nextract
import std/options
import std/strutils

# Sample HTML article
const sampleHtml = """
<!DOCTYPE html>
<html>
<head>
  <title>Sample News Article</title>
  <meta name="author" content="Jane Smith">
  <meta name="description" content="An example article demonstrating content extraction">
</head>
<body>
  <header>
    <nav><a href="/">Home</a> | <a href="/news">News</a></nav>
  </header>
  
  <article class="main-content">
    <h1>Breaking: New Discovery in Science</h1>
    <p class="byline">By Jane Smith | March 20, 2026</p>
    
    <p>Scientists have made a groundbreaking discovery that could change our understanding
    of the natural world. The research, published today in a leading scientific journal,
    reveals new insights into the fundamental properties of matter and energy.</p>
    
    <p>The discovery came after years of careful experimentation and data analysis.
    Researchers at the international laboratory have been working on this project since 2020,
    collecting data from multiple sources and collaborating with institutions worldwide.</p>
    
    <p>"This is a major breakthrough," said Dr. Johnson, lead researcher on the project.
    "The implications of our findings extend far beyond the laboratory and could impact
    various fields including medicine, energy production, and materials science."</p>
    
    <p>The team plans to continue their research with additional experiments scheduled
    for later this year. Funding for the project has been secured through 2028, allowing
    the researchers to expand their work and explore new applications of their discovery.</p>
  </article>
  
  <aside>
    <h3>Related Articles</h3>
    <ul>
      <li><a href="/article1">Previous research</a></li>
      <li><a href="/article2">Related study</a></li>
    </ul>
  </aside>
  
  <footer>
    <p>&copy; 2026 News Site. All rights reserved.</p>
  </footer>
</body>
</html>
"""

proc main() =
  echo "=== nextract Basic Example ===\n"
  
  # Method 1: Quick check if content is readable
  echo "1. Checking if article is readable..."
  if isArticle(sampleHtml):
    echo "   ✓ Content appears to be an article\n"
  else:
    echo "   ✗ Content does not appear to be an article\n"
  
  # Method 2: Simple extraction with convenience function
  echo "2. Extracting article content..."
  let articleOpt = extractArticle(sampleHtml, "https://example.com")
  
  if articleOpt.isSome:
    let article = articleOpt.get
    echo "   ✓ Article extracted successfully!\n"
    
    echo "   Title: ", article.title
    echo "   Author: ", article.byline
    echo "   Excerpt: ", article.excerpt
    echo "   Length: ", article.length, " characters\n"
    
    echo "   Text content (first 200 chars):"
    echo "   \"", article.textContent.substr(0, 200), "...\"\n"
    
    echo "   HTML content (first 300 chars):"
    echo "   ", article.content.substr(0, 300), "...\n"
  else:
    echo "   ✗ Failed to extract article\n"
  
  # Method 3: Using Extractor object with custom options
  echo "3. Using custom options..."
  let opts = initOptions(
    charThreshold = 300,      # Lower threshold
    keepClasses = false       # Strip classes
  )
  
  let e = newExtractor(sampleHtml, "https://example.com", opts)
  let article2 = e.parse()
  
  if article2.isSome:
    echo "   ✓ Extracted with custom options"
    echo "   Title: ", article2.get.title
    echo "   Word count: ", article2.get.textContent.splitWhitespace.len

when isMainModule:
  main()
