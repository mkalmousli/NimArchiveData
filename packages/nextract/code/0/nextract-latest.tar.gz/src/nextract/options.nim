# Configuration options for content extraction

type
  ExtractOptions* = object
    charThreshold*: int                 ## Min characters for valid article
    classesToPreserve*: seq[string]     ## Classes to preserve when cleaning
    keepClasses*: bool                  ## Preserve all classes

proc defaultOptions*(): ExtractOptions =
  result = ExtractOptions(
    charThreshold: 500,
    classesToPreserve: @[],
    keepClasses: false
  )

proc initOptions*(
  charThreshold: int = 500,
  classesToPreserve: seq[string] = @[],
  keepClasses: bool = false
): ExtractOptions =
  result = ExtractOptions(
    charThreshold: charThreshold,
    classesToPreserve: classesToPreserve,
    keepClasses: keepClasses
  )
