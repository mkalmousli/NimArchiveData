# Types and data structures for nextract
#
# DESIGN NOTES on object vs ref object:
#
# 1. Article = object (value type)
#    - Articles are returned to users and should be owned by them
#    - Contains only strings (ref-counted) and int - cheap to copy
#    - Users can modify their copy without affecting others
#    - Safer API than ref (no shared mutable state surprises)
#
# 2. Extractor = ref object
#    - Holds the parsed Document with DOM nodes (chame Node refs)
#    - Has internal mutable state during parsing (scores, flags)
#    - Must be ref to avoid expensive DOM copying
#    - Single-use object, not meant to be copied
#
# 3. ExtractOptions = object (value type)
#    - Small configuration struct (no heap allocation)
#    - Passed to constructor, typically short-lived
#    - Value semantics are appropriate

import std/options
import std/times

type
  Article* = object
    ## Extracted article content and metadata.
    ## This is a value type - users own their copy and can modify freely.
    title*: string
    content*: string           ## Clean HTML content
    textContent*: string       ## Plain text content (no HTML)
    length*: int               ## Character count
    excerpt*: string           ## Short description/excerpt
    byline*: string            ## Author information
    dir*: string               ## Text direction (ltr/rtl)
    siteName*: string          ## Site name
    lang*: string              ## Content language
    publishedTime*: Option[DateTime]  ## Publication time

  ExtractError* = object of CatchableError
    ## Error during content extraction

proc `$`*(a: Article): string =
  result = "Article(\n"
  result.add "  title: " & $a.title & "\n"
  result.add "  byline: " & $a.byline & "\n"
  result.add "  siteName: " & $a.siteName & "\n"
  result.add "  length: " & $a.length & "\n"
  result.add "  excerpt: " & $a.excerpt[0..<min(50, a.excerpt.len)] & "...\n"
  result.add ")"
