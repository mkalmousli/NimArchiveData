# Content extraction algorithm implementation for Nim using chame

import std/options
import std/re
import std/strutils
import std/tables
import std/math
import std/uri
import std/times
import std/streams
import chame/minidom
import ./types
import ./options

# Regex patterns for scoring
const
  POSITIVE_PATTERNS = [
    "article", "body", "content", "entry", "hentry", "h-entry",
    "main", "page", "pagination", "post", "text", "blog", "story",
    "entry-content", "main-content"
  ]
  
  NEGATIVE_PATTERNS = [
    "-ad-", "hidden", "banner", "combx", "comment", "com-",
    "contact", "foot", "footer", "footnote", "gdpr", "masthead",
    "media", "meta", "outbrain", "promo", "related", "scroll",
    "share", "shopping", "sidebar", "skyscraper", "sponsor",
    "supplemental", "widget", "popup", "overlay", "nav",
    "navigation", "menu", "breadcrumb", "breadcrumb-navigation",
    "site-nav"
  ]
  
  DIV_TO_P_ELEMS = ["blockquote", "dl", "div", "img", "ol", "p", "pre", "table", "ul"]

type
  Extractor* = ref object
    ## Main content extractor
    doc*: Document
    articleByline*: string
    articleTitle*: string
    baseUri*: string
    options*: ExtractOptions

# Helper type aliases for clarity
type
  NodePtr = Node

# Forward declarations
proc grabArticle(r: Extractor): Option[Node]
proc prepArticle(r: Extractor, articleContent: Node)
proc initializeNode(r: Extractor, node: Node)
proc getClassWeight(r: Extractor, node: Node): float
proc scoreParagraph(r: Extractor, node: Node): float
proc getLinkDensity(node: Node): float
proc getArticleTitle(r: Extractor): string

# DESIGN NOTE on Table vs TableRef:
# We use Table (value type) for metadata, not TableRef because:
# 1. Metadata tables are small (typically < 10 entries)
# 2. Fresh table created for each extraction - no shared state needed
# 3. Return value optimization (RVO) makes this efficient
# 4. Value semantics are safer - caller owns the data
proc getArticleMetadata(r: Extractor): Table[string, string]

proc postProcessContent(r: Extractor, articleContent: Node)
proc fixRelativeUris(r: Extractor, articleContent: Node)
proc simplifyNestedElements(articleContent: Node)
proc cleanStyles(node: Node)
proc cleanConditionally(r: Extractor, node: Node, tag: string)
proc clean(node: Node, tag: string)
proc killBreaks(node: Node)

# Helper functions for node manipulation
proc nodeName(node: Node): string =
  if node of Element:
    return Element(node).localNameStr
  elif node of Text:
    return "#text"
  elif node of Comment:
    return "#comment"
  elif node of Document:
    return "#document"
  elif node of DocumentType:
    return "DOCTYPE"
  return "#unknown"

proc nodeNameLower(node: Node): string =
  result = node.nodeName.toLowerAscii

proc childNodes(node: Node): seq[Node] =
  result = node.childList

proc parentNode(node: Node): Node =
  result = node.parentNode

proc firstChild(node: Node): Node =
  if node.childList.len > 0:
    result = node.childList[0]
  else:
    result = nil

proc nextSibling(node: Node): Node =
  if node.parentNode == nil:
    return nil
  let siblings = node.parentNode.childList
  for i in 0 ..< siblings.len:
    if siblings[i] == node:
      if i + 1 < siblings.len:
        return siblings[i + 1]
      break
  return nil

proc previousSibling(node: Node): Node =
  if node.parentNode == nil:
    return nil
  let siblings = node.parentNode.childList
  for i in 0 ..< siblings.len:
    if siblings[i] == node:
      if i > 0:
        return siblings[i - 1]
      break
  return nil

proc textContent(node: Node): string =
  if node of CharacterData:
    return CharacterData(node).data
  result = ""
  for child in node.childList:
    result.add textContent(child)

proc innerHTML(node: Node): string =
  if node of Text:
    return Text(node).data
  elif node of Comment:
    return "<!--" & Comment(node).data & "-->"
  elif node of Element:
    let elem = Element(node)
    let tag = elem.localNameStr
    result = "<" & tag
    
    for attr in elem.attrs:
      let attrName = elem.document.factory.atomToStr(attr.name)
      result.add " " & attrName & "=\"" & attr.value & "\""
    
    if elem.childList.len == 0:
      # Self-closing for void elements
      if tag in ["area", "base", "br", "col", "embed", "hr", "img", "input",
                 "link", "meta", "param", "source", "track", "wbr"]:
        result.add " />"
      else:
        result.add "></" & tag & ">"
    else:
      result.add ">"
      for child in elem.childList:
        result.add innerHTML(child)
      result.add "</" & tag & ">"
  else:
    # Document or other - just serialize children
    for child in node.childList:
      result.add innerHTML(child)

proc getAttribute(node: Node, name: string): string =
  if node of Element:
    let elem = Element(node)
    for attr in elem.attrs:
      let attrName = elem.document.factory.atomToStr(attr.name)
      if attrName.toLowerAscii == name.toLowerAscii:
        return attr.value
  return ""

proc hasAttribute(node: Node, name: string): bool =
  if node of Element:
    let elem = Element(node)
    for attr in elem.attrs:
      let attrName = elem.document.factory.atomToStr(attr.name)
      if attrName.toLowerAscii == name.toLowerAscii:
        return true
  return false

proc setAttribute(node: Node, name, value: string) =
  if not (node of Element):
    return
  let elem = Element(node)
  let factory = elem.document.factory
  
  for attr in elem.attrs.mitems:
    let attrName = factory.atomToStr(attr.name)
    if attrName.toLowerAscii == name.toLowerAscii:
      attr.value = value
      return
  
  let atom = factory.strToAtom(name)
  elem.attrs.add((NO_PREFIX, NO_NAMESPACE, atom, value))

proc removeAttribute(node: Node, name: string) =
  if not (node of Element):
    return
  let elem = Element(node)
  let factory = elem.document.factory
  var idx = -1
  for i, attr in elem.attrs:
    let attrName = factory.atomToStr(attr.name)
    if attrName.toLowerAscii == name.toLowerAscii:
      idx = i
      break
  if idx >= 0:
    elem.attrs.delete(idx)

proc removeChild(parent: Node, child: Node) =
  let idx = parent.childList.find(child)
  if idx >= 0:
    parent.childList.delete(idx)
    child.parentNode = nil

proc removeNode(node: Node) =
  if node.parentNode != nil:
    node.parentNode.removeChild(node)

proc appendChild(parent, child: Node) =
  if child.parentNode != nil:
    child.parentNode.removeChild(child)
  parent.childList.add(child)
  child.parentNode = parent

proc insertBefore(parent, newChild, refChild: Node) =
  if refChild == nil or refChild.parentNode != parent:
    parent.appendChild(newChild)
    return
  
  if newChild.parentNode != nil:
    newChild.parentNode.removeChild(newChild)
  
  let idx = parent.childList.find(refChild)
  if idx >= 0:
    parent.childList.insert(newChild, idx)
    newChild.parentNode = parent

proc createElement(doc: Document, tagName: string): Node =
  let factory = doc.factory
  let atom = factory.strToAtom(tagName)
  let elem = Element(
    localName: atom,
    namespace: Namespace.HTML,
    document: doc,
    attrs: @[]
  )
  return elem

proc createTextNode(doc: Document, text: string): Node =
  return Text(data: text)

proc cloneNode(node: Node, deep: bool = true): Node =
  if node of Text:
    return Text(data: Text(node).data)
  elif node of Element:
    let elem = Element(node)
    let newElem = Element(
      localName: elem.localName,
      namespace: elem.namespace,
      document: elem.document,
      attrs: elem.attrs  # Shallow copy of attrs
    )
    if deep:
      for child in elem.childList:
        newElem.appendChild(cloneNode(child, true))
    return newElem
  elif node of Comment:
    return Comment(data: Comment(node).data)
  return node  # Fallback

proc getElementsByTagName(node: Node, tagName: string): seq[Node] =
  var res: seq[Node] = @[]
  let targetTag = tagName.toLowerAscii
  
  proc walk(n: Node; acc: var seq[Node]) =
    if n of Element:
      if n.nodeNameLower == targetTag:
        acc.add(n)
      for child in n.childList:
        walk(child, acc)
    elif n of Document:
      # For Document, search through its children (like html element)
      for child in n.childList:
        walk(child, acc)
  
  walk(node, res)
  return res

proc getElementById(node: Node, id: string): Option[Node] =
  proc walk(n: Node): Option[Node] =
    if n of Element:
      if n.getAttribute("id") == id:
        return some(n)
      for child in n.childList:
        let found = walk(child)
        if found.isSome:
          return found
    return none(Node)
  
  return walk(node)

proc getInnerText(node: Node, normalizeSpaces: bool = true): string =
  result = node.textContent
  if normalizeSpaces:
    result = result.replace(re"\s+", " ").strip

proc getCharCount(node: Node, s: string = ","): int =
  let text = node.getInnerText
  result = text.count(s)

proc cleanStyles(node: Node) =
  if not (node of Element):
    return
  if node.hasAttribute("style"):
    node.removeAttribute("style")
  if node.hasAttribute("align"):
    let tag = node.nodeNameLower
    if tag notin ["table", "th", "td"]:
      node.removeAttribute("align")

proc getLinkDensity(node: Node): float =
  let textLength = node.getInnerText.len
  if textLength == 0:
    return 0.0
  
  var linkLength = 0
  for link in node.getElementsByTagName("a"):
    linkLength += link.getInnerText.len
  
  result = linkLength.float / textLength.float

proc getClassWeight(r: Extractor, node: Node): float =
  if not (node of Element):
    return 0.0
  
  result = 0.0
  let className = node.getAttribute("class").toLowerAscii
  let id = node.getAttribute("id").toLowerAscii
  let combined = className & " " & id
  
  for pattern in POSITIVE_PATTERNS:
    if combined.contains(pattern):
      result += 25.0
  
  for pattern in NEGATIVE_PATTERNS:
    if combined.contains(pattern):
      result -= 25.0
  
  return result

proc initializeNode(r: Extractor, node: Node) =
  if not (node of Element):
    return
  
  let tag = node.nodeNameLower
  var score = 0
  case tag:
  of "div": score = 5
  of "pre", "td", "blockquote": score = 3
  of "address", "ol", "ul", "dl", "dd", "dt", "li", "form": score = -3
  of "h1", "h2", "h3", "h4", "h5", "h6", "th": score = -5
  else: discard
  
  node.setAttribute("data-extract-score", $score)

proc scoreParagraph(r: Extractor, node: Node): float =
  let text = node.getInnerText
  
  if text.len < 25:
    return 0.0
  
  var score = 1.0
  score += text.count(',').float
  score += min(3.0, (text.len / 100).floor)
  
  return score

proc newExtractor*(html: string, baseUri: string = "", options: ExtractOptions = defaultOptions()): Extractor =
  result = Extractor()
  result.baseUri = baseUri
  result.options = options
  
  var stream = newStringStream(html)
  result.doc = parseHTML(stream)
  stream.close()

proc newExtractor*(doc: Document, baseUri: string = "", options: ExtractOptions = defaultOptions()): Extractor =
  result = Extractor()
  result.doc = doc
  result.baseUri = baseUri
  result.options = options

proc getBody(doc: Document): Node =
  for child in doc.childList:
    if child of Element:
      if child.nodeNameLower == "html":
        for htmlChild in child.childList:
          if htmlChild of Element and htmlChild.nodeNameLower == "body":
            return htmlChild
      elif child.nodeNameLower == "body":
        return child
  return nil

proc prepDocument(r: Extractor) =
  let doc = r.doc
  
  if doc.getBody() == nil:
    return
  
  # Remove scripts
  for script in doc.getBody().getElementsByTagName("script"):
    script.removeNode()
  
  # Remove styles
  for style in doc.getBody().getElementsByTagName("style"):
    style.removeNode()
  
  # Remove noscript (unwrap content)
  for noscript in doc.getBody().getElementsByTagName("noscript"):
    var child = noscript.firstChild
    while child != nil:
      let next = child.nextSibling
      noscript.parentNode.insertBefore(child, noscript)
      child = next
    noscript.removeNode()

proc getArticleTitle(r: Extractor): string =
  let doc = r.doc
  var curTitle = ""
  var origTitle = ""
  
  let titles = doc.getElementsByTagName("title")
  if titles.len > 0:
    origTitle = titles[0].getInnerText
    curTitle = origTitle
  
  let h1s = doc.getElementsByTagName("h1")
  if h1s.len == 1:
    curTitle = h1s[0].getInnerText
  
  let metas = doc.getElementsByTagName("meta")
  for meta in metas:
    if meta.hasAttribute("property"):
      let prop = meta.getAttribute("property").toLowerAscii
      if prop in ["og:title", "twitter:title"]:
        curTitle = meta.getAttribute("content")
        break
    if meta.hasAttribute("name"):
      let name = meta.getAttribute("name").toLowerAscii
      if name == "title":
        curTitle = meta.getAttribute("content")
        break
  
  for sep in [" | ", " - ", " : ", " :: ", " • "]:
    if curTitle.contains(sep):
      curTitle = curTitle.split(sep)[0]
      break
  
  if curTitle.len > 150:
    for sep in [";", "\\", "«", "›"]:
      if curTitle.contains(sep):
        curTitle = curTitle.split(sep)[0]
        if curTitle.len < 150:
          break
    if curTitle.len > 150:
      curTitle = curTitle.substr(0, 150)
  
  curTitle = curTitle.strip
  return if curTitle.len > 0: curTitle else: origTitle

proc getArticleMetadata(r: Extractor): Table[string, string] =
  result = initTable[string, string]()
  let doc = r.doc
  
  let metas = doc.getElementsByTagName("meta")
  for meta in metas:
    let name = meta.getAttribute("name").toLowerAscii
    let prop = meta.getAttribute("property").toLowerAscii
    let content = meta.getAttribute("content")
    
    if name == "author" or prop == "author":
      result["byline"] = content
    if name == "description" or prop == "og:description":
      result["excerpt"] = content
    if prop == "og:site_name":
      result["siteName"] = content
    if prop == "article:published_time":
      result["publishedTime"] = content
    if name == "language" or prop == "og:locale":
      result["lang"] = content

proc clean(node: Node, tag: string) =
  let elements = node.getElementsByTagName(tag)
  for i in countdown(elements.len - 1, 0):
    elements[i].removeNode()

proc killBreaks(node: Node) =
  let breaks = node.getElementsByTagName("br")
  for br in breaks:
    var next = br.nextSibling
    var brCount = 0
    while next != nil and brCount < 2:
      if next of Element and next.nodeNameLower == "br":
        brCount += 1
        let toRemove = next
        next = next.nextSibling
        toRemove.removeNode()
      elif next of Text and next.textContent.strip.len == 0:
        next = next.nextSibling
      else:
        break
    if brCount >= 1:
      br.removeNode()

proc cleanConditionally(r: Extractor, node: Node, tag: string) =
  let elements = node.getElementsByTagName(tag)
  
  for e in elements:
    if not (e of Element):
      continue
    
    if e.hasAttribute("data-extract-score"):
      continue
    
    let weight = r.getClassWeight(e)
    if weight < 0:
      e.removeNode()
      continue
    
    let text = e.getInnerText
    if text.len < 10:
      let links = e.getElementsByTagName("a")
      if links.len > 0 and links.len >= e.childNodes.len div 2:
        e.removeNode()

proc fixRelativeUris(r: Extractor, articleContent: Node) =
  if r.baseUri.len == 0:
    return
  
  let baseUri = parseUri(r.baseUri)
  
  for link in articleContent.getElementsByTagName("a"):
    if link.hasAttribute("href"):
      let href = link.getAttribute("href")
      if href.len > 0:
        try:
          let absUri = baseUri / href
          link.setAttribute("href", $absUri)
        except CatchableError:
          discard
  
  for img in articleContent.getElementsByTagName("img"):
    if img.hasAttribute("src"):
      let src = img.getAttribute("src")
      if src.len > 0:
        try:
          let absUri = baseUri / src
          img.setAttribute("src", $absUri)
        except CatchableError:
          discard

proc simplifyNestedElements(articleContent: Node) =
  proc simplify(n: Node) =
    if not (n of Element):
      return
    
    let tag = n.nodeNameLower
    
    if tag == "div" and n.childNodes.len == 1:
      let child = n.childNodes[0]
      if child of Element and child.nodeNameLower == "div":
        n.parentNode.insertBefore(child, n)
        n.removeNode()
        simplify(child)
        return
    
    for child in n.childNodes:
      simplify(child)
  
  simplify(articleContent)

proc postProcessContent(r: Extractor, articleContent: Node) =
  if r.baseUri.len > 0:
    r.fixRelativeUris(articleContent)
  
  simplifyNestedElements(articleContent)
  
  if not r.options.keepClasses:
    proc removeClasses(n: Node) =
      if n of Element:
        if n.hasAttribute("class"):
          let cls = n.getAttribute("class")
          var keep = false
          for c in r.options.classesToPreserve:
            if c in cls:
              keep = true
              break
          if not keep:
            n.removeAttribute("class")
        for child in n.childNodes:
          removeClasses(child)
    removeClasses(articleContent)

proc grabArticle(r: Extractor): Option[Node] =
  let doc = r.doc
  
  if doc.getBody() == nil:
    return none(Node)
  
  var bestCandidate: tuple[element: Node, score: float]
  var bestScore = 0.0
  var candidates: seq[tuple[element: Node, score: float]] = @[]
  var nodesToScore: seq[Node] = @[]
  
  for p in doc.getBody().getElementsByTagName("p"):
    nodesToScore.add p
  for pre in doc.getBody().getElementsByTagName("pre"):
    nodesToScore.add pre
  for td in doc.getBody().getElementsByTagName("td"):
    nodesToScore.add td
  
  for divElem in doc.getBody().getElementsByTagName("div"):
    let text = divElem.getInnerText
    if text.len > 50 and ',' in text:
      nodesToScore.add divElem
  
  for node in nodesToScore:
    let parent = node.parentNode
    let grandParent = if parent != nil: parent.parentNode else: nil
    
    let innerText = node.getInnerText
    if innerText.len < 25:
      continue
    
    if parent != nil and not parent.hasAttribute("data-extract-score"):
      r.initializeNode(parent)
      candidates.add (parent, 0.0)
    
    if grandParent != nil and not grandParent.hasAttribute("data-extract-score"):
      r.initializeNode(grandParent)
      candidates.add (grandParent, 0.0)
    
    var contentScore = r.scoreParagraph(node)
    contentScore += r.getClassWeight(node)
    
    if parent != nil:
      var parentScore = parseFloat(parent.getAttribute("data-extract-score"))
      parentScore += contentScore
      parent.setAttribute("data-extract-score", $parentScore)
    
    if grandParent != nil:
      var grandScore = parseFloat(grandParent.getAttribute("data-extract-score"))
      grandScore += contentScore / 2.0
      grandParent.setAttribute("data-extract-score", $grandScore)
  
  # Find best candidate
  for cand in candidates:
    var score = parseFloat(cand.element.getAttribute("data-extract-score"))
    let linkDensity = cand.element.getLinkDensity
    score = score * (1.0 - linkDensity)
    
    if score > bestScore:
      bestScore = score
      bestCandidate = (cand.element, score)
  
  if bestScore < 1.0 or bestCandidate.element == nil:
    if doc.getBody() != nil:
      bestCandidate = (doc.getBody(), 0.0)
    else:
      return none(Node)
  
  # Create article content
  let articleContent = doc.createElement("div")
  articleContent.setAttribute("id", "extract-content")
  
  let siblingScoreThreshold = max(10.0, bestScore * 0.2)
  let parent = bestCandidate.element.parentNode
  
  if parent != nil:
    for sibling in parent.childNodes:
      var append = false
      
      if sibling == bestCandidate.element:
        append = true
      elif sibling of Element:
        let siblingScore = r.getClassWeight(sibling)
        if siblingScore >= siblingScoreThreshold:
          append = true
        elif sibling.nodeNameLower in ["p", "pre", "td"]:
          let linkDensity = sibling.getLinkDensity
          let text = sibling.getInnerText
          let textLength = text.len
          
          if textLength > 80 and linkDensity < 0.25:
            append = true
          elif textLength < 80 and linkDensity == 0.0 and text.contains("."):
            append = true
      
      if append:
        articleContent.appendChild(cloneNode(sibling, true))
  else:
    articleContent.appendChild(cloneNode(bestCandidate.element, true))
  
  return some(articleContent)

proc prepArticle(r: Extractor, articleContent: Node) =
  proc cleanStylesRecursive(n: Node) =
    cleanStyles(n)
    for child in n.childNodes:
      cleanStylesRecursive(child)
  cleanStylesRecursive(articleContent)
  
  r.cleanConditionally(articleContent, "form")
  r.cleanConditionally(articleContent, "object")
  r.cleanConditionally(articleContent, "embed")
  r.cleanConditionally(articleContent, "footer")
  r.cleanConditionally(articleContent, "aside")
  
  clean(articleContent, "input")
  clean(articleContent, "textarea")
  clean(articleContent, "select")
  clean(articleContent, "button")
  
  killBreaks(articleContent)
  
  for h in articleContent.getElementsByTagName("h1"):
    if h.getInnerText.len < 5:
      h.removeNode()
  
  for p in articleContent.getElementsByTagName("p"):
    let imgCount = p.getElementsByTagName("img").len
    let embedCount = p.getElementsByTagName("embed").len
    let objectCount = p.getElementsByTagName("object").len
    let text = p.getInnerText.strip
    
    if text.len == 0 and imgCount == 0 and embedCount == 0 and objectCount == 0:
      p.removeNode()

proc parse*(r: Extractor): Option[Article] =
  if r.doc.getBody() == nil:
    return none(Article)
  
  r.prepDocument()
  let metadata = r.getArticleMetadata()
  let title = r.getArticleTitle()
  
  var articleContent = r.grabArticle()
  
  if articleContent.isNone:
    return none(Article)
  
  r.prepArticle(articleContent.get)
  r.postProcessContent(articleContent.get)
  
  let textContent = articleContent.get.getInnerText
  if textContent.len < r.options.charThreshold:
    return none(Article)
  
  var article: Article
  article.title = title
  article.content = articleContent.get.innerHTML
  article.textContent = textContent
  article.length = textContent.len
  article.byline = metadata.getOrDefault("byline", "")
  article.excerpt = metadata.getOrDefault("excerpt", "")
  article.siteName = metadata.getOrDefault("siteName", "")
  article.lang = metadata.getOrDefault("lang", "")
  
  if metadata.hasKey("publishedTime"):
    try:
      article.publishedTime = some(parse(metadata["publishedTime"], "yyyy-MM-dd'T'HH:mm:sszzz"))
    except CatchableError:
      try:
        article.publishedTime = some(parse(metadata["publishedTime"], "yyyy-MM-dd"))
      except CatchableError:
        discard
  
  let htmls = r.doc.getElementsByTagName("html")
  if htmls.len > 0 and htmls[0].hasAttribute("dir"):
    article.dir = htmls[0].getAttribute("dir")
  else:
    article.dir = "auto"
  
  return some(article)

proc isProbablyReaderable*(r: Extractor, minContentLength: int = 140, minScore: int = 20): bool =
  if r.doc.getBody() == nil:
    return false
  
  var score = 0
  var nodes = r.doc.getBody().getElementsByTagName("p")
  nodes.add r.doc.getBody().getElementsByTagName("pre")
  nodes.add r.doc.getBody().getElementsByTagName("article")
  
  for node in nodes:
    let text = node.getInnerText
    let textLength = text.len
    
    if textLength < minContentLength:
      continue
    
    score += textLength
    
    if score >= minScore * minContentLength:
      return true
  
  return false
