# nextract - A content extraction library for Nim
#
# This library implements a content extraction algorithm (inspired by Mozilla Readability) for extracting
# article content from HTML web pages. It uses chame for HTML5 parsing
# and chagashi for character encoding support.
#
# Example usage:
#   import nextract
#
#   let html = readFile("article.html")
#   let extractor = newExtractor(html, "https://example.com")
#   let article = extractor.parse()
#
#   if article.isSome:
#     echo article.get.title
#     echo article.get.content

import std/options
import nextract/types
import nextract/options
import nextract/extract

export types
export options
export extract

proc extractArticle*(html: string, baseUri: string = "",
                     opts: ExtractOptions = defaultOptions()): Option[Article] =
  ## Convenience function to extract article content from HTML.
  ##
  ## Example:
  ##   let article = extractArticle(html, "https://example.com")
  ##   if article.isSome:
  ##     echo article.get.title
  ##     echo article.get.textContent
  let e = newExtractor(html, baseUri, opts)
  return e.parse()

proc isArticle*(html: string, minContentLength: int = 140, minScore: int = 20): bool =
  ## Quick check if HTML contains readable article content.
  ##
  ## Example:
  ##   if isArticle(html):
  ##     let article = extractArticle(html)
  let e = newExtractor(html)
  return e.isProbablyReaderable(minContentLength, minScore)
