# Package

version       = "0.1.0"
author        = "bung87"
description   = "A Mozilla Readability-like content extraction library for Nim"
license       = "MIT"
srcDir        = "src"


# Dependencies

requires "nim >= 1.6.18"
requires "chame >= 1.0.0"
requires "chagashi >= 0.7.0"
