# Tests for nextract

import std/unittest
import std/options
import std/strutils
import nextract

suite "Content extraction basic tests":
  
  test "parse simple article":
    let html = """
<!DOCTYPE html>
<html>
<head>
  <title>Test Article</title>
  <meta name="author" content="John Doe">
  <meta name="description" content="A test article description">
</head>
<body>
  <header>
    <nav>Navigation links here</nav>
  </header>
  <article>
    <h1>The Main Article Title</h1>
    <p>This is the main content of the article. It has multiple sentences, with commas, 
    and is quite long to ensure it gets a good content score. The article continues
    with more text about the topic at hand.</p>
    <p>Second paragraph with more details about the subject. This helps ensure the content
    is substantial enough for the extraction algorithm to detect it as the main content.</p>
    <p>Third paragraph with additional information, context, and conclusions about the article topic.
    The content is designed to be article-like with proper structure and formatting.</p>
  </article>
  <aside>Sidebar content</aside>
  <footer>Footer content</footer>
</body>
</html>
"""
    
    let extractor = newExtractor(html, "https://example.com")
    let article = extractor.parse()
    
    check article.isSome
    if article.isSome:
      check article.get.title.len > 0
      check article.get.length > 100
      check "content" in article.get.textContent.toLowerAscii
      # Metadata extraction works
      check article.get.byline == "John Doe"
      check article.get.excerpt == "A test article description"
  
  test "isProbablyReaderable true for articles":
    let html = """
<html>
<body>
  <article>
    <p>This is a long paragraph with many words and sentences. It should be detected as 
    readable content because it contains substantial text that looks like an article.
    The paragraph continues with more text to ensure it meets the minimum length requirements.</p>
    <p>Another paragraph with more content. This ensures the document has enough text 
    to be considered readable by the algorithm. More sentences with commas and proper structure.</p>
  </article>
</body>
</html>
"""
    
    let extractor = newExtractor(html)
    # Use lower thresholds for this short test content
    check extractor.isProbablyReaderable(minContentLength = 50, minScore = 1) == true
  
  test "isProbablyReaderable false for non-articles":
    let html = """
<html>
<body>
  <nav><a href="/">Home</a> <a href="/about">About</a></nav>
  <ul>
    <li>Item 1</li>
    <li>Item 2</li>
  </ul>
</body>
</html>
"""
    
    let extractor = newExtractor(html)
    check extractor.isProbablyReaderable() == false
  
  test "handle empty document":
    let html = "<html><body></body></html>"
    let extractor = newExtractor(html)
    let article = extractor.parse()
    check article.isNone
  
  test "handle document with only navigation":
    let html = """
<html>
<head><title>Home Page</title></head>
<body>
  <nav>
    <a href="/">Home</a>
    <a href="/products">Products</a>
    <a href="/about">About</a>
    <a href="/contact">Contact</a>
  </nav>
  <h1>Welcome</h1>
  <p>Short welcome message.</p>
</body>
</html>
"""
    let extractor = newExtractor(html)
    let article = extractor.parse()
    # Should return none for pages without enough content
    check article.isNone

  test "custom options":
    let opts = initOptions(
      charThreshold = 100,
      keepClasses = true
    )
    
    let html = """
<html>
<head><title>Test</title></head>
<body>
  <article>
    <p>This is a test article with sufficient content length to pass the custom threshold setting.
    It has multiple sentences and enough words to be detected as content.</p>
  </article>
</body>
</html>
"""
    let extractor = newExtractor(html, "", opts)
    let article = extractor.parse()
    check article.isSome

  test "article with low threshold":
    let html = """
<html>
<head><title>Short Article</title></head>
<body>
  <div class="content">
    <p>This is some content. It has multiple sentences, with commas, to look like real text.</p>
  </div>
</body>
</html>
"""
    # With default threshold (500), this should fail
    let r1 = newExtractor(html)
    check r1.parse().isNone
    
    # With lower threshold (50), this should succeed
    let opts = initOptions(charThreshold = 50)
    let r2 = newExtractor(html, "", opts)
    let article = r2.parse()
    check article.isSome
    if article.isSome:
      check article.get.title == "Short Article"

  test "title extraction":
    let html = """
<html>
<head>
  <title>My Page Title</title>
</head>
<body>
  <h1>Heading One</h1>
  <p>This is a paragraph with enough text to be considered content. It has multiple sentences 
  and should be detected by the algorithm. The text continues to meet the minimum length.</p>
  <p>Second paragraph with more content to ensure we meet the default threshold of 500 characters.
  This is important because the algorithm needs sufficient text to identify the main content area.
  More text here with commas, and proper sentence structure to score well.</p>
  <p>Third paragraph with additional information and details to make sure the content is substantial.
  The extraction algorithm looks for article-like content with multiple paragraphs and good structure.</p>
</body>
</html>
"""
    let extractor = newExtractor(html)
    let article = extractor.parse()
    check article.isSome
    if article.isSome:
      # Should use h1 if there's only one
      check article.get.title == "Heading One"

  test "content extraction from article element":
    let html = """
<html>
<body>
  <nav><a href="/">Home</a></nav>
  <article>
    <h1>News Article</h1>
    <p>This is the first paragraph of the news article. It contains substantial text with commas,
    and multiple sentences to ensure it scores well. The content needs
    to be long enough to meet the threshold of 500 characters for the extraction to succeed.</p>
    <p>This is the second paragraph with additional content and details about the news story.
    We need to add more text here to make sure the total content length is sufficient for detection.
    The algorithm analyzes the text density, punctuation, and paragraph structure to find main content.</p>
    <p>Third paragraph with more information about the topic being discussed in this news article.
    The nextract library implements a content extraction algorithm to extract article content.</p>
  </article>
  <footer>Copyright 2024</footer>
</body>
</html>
"""
    let extractor = newExtractor(html)
    let article = extractor.parse()
    check article.isSome
    if article.isSome:
      let text = article.get.textContent.toLowerAscii
      check "news article" in text or "paragraph" in text
