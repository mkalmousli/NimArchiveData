#!/bin/bash
#installs besides the rust deps.
sudo apt install clang cargo llvm pkg-config nettle-dev -y
cargo install --force cbindgen
