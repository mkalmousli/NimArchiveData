#!/bin/bash
#move to higher directory at somepoint 
cd  rust/
cargo build  -v --release
sudo rm -f ../headers/nimPGP.h 
cbindgen ./src/lib.rs -l c > ../headers/nimPGP.h 