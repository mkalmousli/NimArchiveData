#!/bin/bash
nim doc --out=docs/ ./src/nimPGP