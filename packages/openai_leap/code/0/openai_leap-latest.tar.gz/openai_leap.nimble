version     = "14.0.0"
author      = "Andrew Brower"
description = "OpenAI API for Nim"
license     = "MIT"

srcDir = "src"

requires "nim >= 2.0.0"
requires "curly >= 1.1.1"
requires "crunchy >= 0.1.11"
requires "jsony >= 1.1.5"
requires "webby >= 0.2.1"
requires "ws >= 0.5.0"
