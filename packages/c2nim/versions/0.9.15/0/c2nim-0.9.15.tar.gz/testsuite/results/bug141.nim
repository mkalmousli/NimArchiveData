proc x*() =
  discard
