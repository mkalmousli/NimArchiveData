type
  test* = void
