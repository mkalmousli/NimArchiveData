# Package

version       = "0.1.1"
author        = "bung87"
description   = "fs memory zip finder implement in Nim"
license       = "MIT"
srcDir        = "src"



# Dependencies

requires "nim >= 1.2.0"
requires "zip"
