sudoku generator in nim
