# Groovebox - A CLI application for live streaming pre-recorded media
# to Icecast servers and RTMP platforms like Twitch and YouTube. 
#
# (c) 2026 George Lemon | AGPLv3 License
#          Made by Humans from OpenPeeps
#          https://github.com/openpeeps/groovebox

## This module defines the CLI commands for Groovebox using the kapsis package
## Each command corresponds to a specific functionality of Groovebox, such as initializing
## a configuration file, streaming to an Icecast server, running a local RTMP server,
## streaming to an RTMP server, and converting media files to formats suitable for streaming.

import std/[os, osproc, unidecode, strutils,
            posix, strformat, sequtils]
from std/net import Port, `$`

import pkg/[malebolgia, nyml]
import pkg/kapsis/runtime
import pkg/kapsis/interactive/[spinny, widgets, prompts]

import ./ice, ./config
export icecastCommand

proc initCommand*(v: Values) =
  ## Initialize a new Groovebox Configuration file
  display("""
    ________                               __________              
   /  _____/______  ____   _______  __ ____\______   \ _______  ___
  /   \  __\_  __ \/  _ \ /  _ \  \/ // __ \|    |  _//  _ \  \/  /
  \    \_\  \  | \(  <_> |  <_> )   /\  ___/|    |   (  <_> >    < 
   \______  /__|   \____/ \____/ \_/  \___  >______  /\____/__/\_ \
          \/                              \/       \/            \/
  """)
  var answer =
    promptInteractive("Choose configuration type:",
      answers = ["RTMP Server", "RTMP Stream", "Icecast Stream"],
      activeIcon = "🍕")

  if answer == -1:
    displayError("Please, choose a configuration type to initialize.", quitProcess = true)
  var grooveboxConfig: string
  if answer == 0:
    # handle RTMP server config initialization
    grooveboxConfig = fmt"""# Groovebox RTMP Server Configuration
type: rtmpserver"""
  
  elif answer == 1:
    # handle RTMP stream config initialization
    let url = prompt("SMTP Server URL", default = "rtmp://localhost/live/livestream")
    var psVideo: seq[string] # todo support multiple playlists in the future
    var psAudio: seq[string] # todo support multiple playlists in the future
    psvideo.add(prompt("Video playlist", default = "videoplaylist.txt"))
    psAudio.add(prompt("Audio playlist", default = "audioplaylist.txt"))

    for path in psvideo & psAudio:
      if not path.fileExists:
        displayInfo("Creating " & path & " ...")
        writeFile(path, "")

    var psVideoStr = psVideo.mapIt("- \"" & it & "\"").join("\n    ")
    var psAudioStr = psAudio.mapIt("- \"" & it & "\"").join("\n    ")
    grooveboxConfig = fmt"""
# Groovebox RTMP Stream Configuration
type: rtmpstream
stream:
  url: {url}
  video:
    {psVideoStr}
  audio:
    {psAudioStr}"""
    writeFile("groovebox_config.yml", grooveboxConfig)
    displaySuccess("Groovebox configuration file created: groovebox_config.yml")

  elif answer == 2:
    # handle icecast config initialization
    let sourceName = prompt("Icecast Source Name", default = "Groovebox Stream")
    let sourceMount = prompt("Icecast Mount Point", default = "/stream")
    let address  = prompt("Icecast Server Address", default = "localhost")
    let port: Port = Port(parseInt(prompt("Icecast Server Port", default = "8000")))
    let username = prompt("Icecast Username", default = "admin")
    let password = prompt("Icecast Password", default = "hackme")
    var psAudio: seq[string] # todo support multiple playlists in the future
    psAudio.add(prompt("Audio playlist", default = "playlist1.txt"))
    for path in psAudio:
      if not path.fileExists:
        displayInfo("Creating " & path & " ...")
        writeFile(path, "")
    var psAudioStr = psAudio.mapIt("- \"" & it & "\"").join("\n    ")
    grooveboxConfig = fmt"""# Groovebox Icecast Stream Configuration
type: icecast
icecast:
  connection:
    address: "{address}"
    port: {port}
    mount: "{sourceMount}"
    username: "{username}"
    password: "{password}"
  playlists:
    {psAudioStr}"""
    writeFile("groovebox_config.yml", grooveboxConfig)
    displaySuccess("Groovebox configuration file created: groovebox_config.yml")

proc slugify*(str: string, sep: static char = '-', allowSlash: bool = false): string =
  ## Convert `input` string to a ascii slug. Taken from Supranim package
  var x = unidecode(str.strip())
  result = newStringOfCap(x.len)
  var i = 0
  while i < x.len:
    case x[i]
    of Whitespace:
      inc i
      try:
        while x[i] notin IdentChars:
          inc i
        add result, sep
      except IndexDefect: discard
    of PunctuationChars:
      inc i
      if result.len == 0: continue
      if allowSlash and x[i - 1] == '/':
        add result, '/'
        continue
      try:
        while x[i] notin IdentChars:
          inc i
        add result, sep
      except IndexDefect:
        discard
    else:
      add result, x[i].toLowerAscii
      inc i

import pkg/rtmp

proc rtmpServerCommand*(v: Values) =
  ## Kapsis command for running RTMP server
  display(cliHeading)
  let configPath = v.get("config").getPath
  var rtmpServer = newRTMPServer()
  display("Starting RTMP server on port " & $rtmpServer.settings.rtmpPort)
  rtmpServer.startServer()

proc rtmpStreamCommand*(v: Values) =
  ## Kapsis command for runningg RTMP client with playlist support
  display(cliHeading)
  let configPath = normalizedPath(getCurrentDir() / $(v.get("config").getPath))
  if configPath.endsWith(".yml") or configPath.endsWith(".yaml"):
    GConfig = fromYaml(readFile(configPath), GrooveboxConfig)
  elif configPath.endsWith(".json"):
    GConfig = fromJson(readFile(configPath), GrooveboxConfig)
  else:
    display("No Groovebox Config found in the current directory (.yml/.yaml/.json)")
    QuitFailure.quit
  display("Streaming to RTMP server: " & GConfig.stream.url)
  let client = newRtmpClient(GConfig.stream.url)
  # Load and shuffle playlists
  client.ps = PlaylistState(
    videoFiles: loadPlaylist("videoplaylist.txt"),
    audioFiles: loadPlaylist("audioplaylist.txt"),
    videoIdx: 0,
    audioIdx: 0
  )
  proc startNextVideo(client: RtmpClient, ps: PlaylistState) =
    # Start next video in playlist, or loop back to start if at
    # end and audio is still playing
    let videoPath = nextVideo(ps)
    if videoPath.len == 0 or (ps.currentAudioPath.len == 0 and ps.audioFiles.len > 0):
      ## debugEcho "[rtmp] No video or audio to play"
      return
    ## debugEcho "[rtmp] Streaming next video: ", videoPath, " with audio: ", ps.currentAudioPath
    startStreamFlvZeroCopy(client, videoPath, client.msgStreamId, startTs = ps.globalTs)

  proc startNextAudioAndVideo(client: RtmpClient, ps: PlaylistState) =
    # Start both audio and video
    client.ps.currentAudioPath = nextAudio(ps)
    client.ps.currentAudioDone = ps.currentAudioPath.len == 0
    if client.ps.audioFiles.len > 0 and client.ps.currentAudioDone:
      ## debugEcho "[rtmp] All audio files sent"
      return
    # client.ps.videoIdx = 0 # Optionally reset video playlist for each new audio
    let videoPath = client.ps.nextVideo()
    ## debugEcho "[rtmp] Streaming video: ", videoPath, " audio: ", client.ps.currentAudioPath
    startStreamFlvZeroCopy(client, videoPath, client.msgStreamId, startTs = client.ps.globalTs)
    startStreamAacAdtsZeroCopy(client, client.ps.currentAudioPath,
              client.msgStreamId, 4'u8, startTs = client.ps.globalTs)

  proc startNextAudioOnly(client: RtmpClient, ps: PlaylistState) =
    # Start only audio when video ended
    ps.currentAudioPath = nextAudio(ps)
    ps.currentAudioDone = ps.currentAudioPath.len == 0
    if ps.currentAudioDone: return # no more audio
    # Clear previous AAC state before starting new audio
    if client.aac != nil:
      if client.aac.fd >= 0:
        # close previous AAC file descriptor
        discard posix.close(client.aac.fd)
      client.aac = nil
    startStreamAacAdtsZeroCopy(client, ps.currentAudioPath,
          client.msgStreamId, 4'u8, startTs = ps.globalTs)

  client.onPublishOk = proc(c: RtmpClient) =
    # call startPacer and immediately start audio+video via the callback
    startPacer(c, proc(c2: RtmpClient) = startNextAudioAndVideo(c2, c2.ps))

  client.onStreamEnd =
    proc(c: RtmpClient, st: StreamState, sent: int) =
      ## debugEcho "[rtmp] Stream end, bytes=", sent
      ## debugEcho st.msgType
      if st.msgType == 0x09'u8: # Video ended
        if c.ps.videoIdx < c.ps.videoFiles.len:
          # check if there is more video to play
          startNextVideo(c, client.ps)
        elif c.ps.videoIdx == c.ps.videoFiles.len:
          # we are at the end of the video playlist
          # restart the video playlist if audio is still playing
          if not c.ps.currentAudioDone:
            c.ps.videoIdx = 0
            startNextVideo(c, client.ps)
      elif st.msgType == 0x08'u8: # Audio ended
        # c.ps.currentAudioDone = true
        startNextAudioOnly(c, c.ps)

  client.onStreamProgress =
    proc(c: RtmpClient, st: StreamState, sent: int) =
      ## debugEcho "[rtmp] Progress: ", st.offset, " / ", st.totalSize

  client.onStreamError =
    proc(c: RtmpClient, st: StreamState, err: cstring) =
      ## debugEcho "[rtmp] Stream error: ", err

  ## debugEcho "[rtmp] Starting event loop"
  discard event_base_dispatch(client.base)

  # Cleanup after loop exits
  if client.bev != nil: bufferevent_free(client.bev)
  if client.base != nil: event_base_free(client.base)

proc flvCommand*(v: Values) =
  ## Convert video files to FLV format for streaming
  let input = v.get("in").getPath
  let output = v.get("out").getFilepath()
  # twitch and youtube accept a max bitrate of 6000 kbps for streaming
  let kbs =
    if v.has("--kbs"):
      v.get("--kbs").getInt
    else: 6000

  let size = if v.has("--size"):
    v.get("--size").getStr
  else: "1280x720" # default to 720p

  let fps =
    if v.has("--fps"):
      v.get("--fps").getFloat
    else: 29.97 # default to 29.97 fps
  
  # checking if output file exists
  if output.fileExists:
    if not promptConfirm("Output file already exists. Overwrite? (y/n): "): return
  # let vfFilter = " -vf \"scale=" & size.replace("x", ":") & ":flags=lanczos,unsharp=5:5:0.8\" "
  let cmd =
    "ffmpeg -y -i \"" & $input & "\"" &
    " -c:v libx264 -preset veryfast -tune grain -profile:v main -level 4.0 -pix_fmt yuv420p" &
    " -r " & $fps &
    " -g 60" &
    # " -b:v " & $kbs & "k -maxrate " & $kbs & "k -bufsize " & $(kbs * 2) & "k" &
    " -b:v 2500k -maxrate 2500k -bufsize 5000k" &
    # " -bf 0 -refs 3" &
    # " -x264-params \"repeat-headers=1:nal-hrd=cbr:force-cfr=1:vbv-maxrate=" & $kbs & ":vbv-bufsize=" & $(kbs * 2) & "\"" &
    " -f flv \"" & output & "\""
# ffmpeg -y -i input.mov -c:v libx264 -preset veryfast -profile:v main -level 4.0 -pix_fmt yuv420p -r 30 -g 60 -b:v 2500k -maxrate 2500k -bufsize 5000k -c:a aac -ar 44100 -ac 2 -b:a 128k -f flv output.flv
  let res = execCmdEx(cmd)
  display(res.output) # always display ffmpeg output
  if not res.exitCode != 0: displaySuccess("Done!")

type
  ConvertAudioType* = enum
    ## Enum to specify audio conversion type for the aac and ogg commands
    ctOgg = "ogg", ctAac = "aac"

proc convertAudio*(audioType: ConvertAudioType, i, o: string, kbs: int) =
  ## Convert audio file to specified format using ffmpeg. This is a helper function used by the aac and ogg commands.
  let cmd = case audioType
    of ctOgg:
      "ffmpeg -y -i \"" & i & "\" -c:a libvorbis " & " -b:a " & $kbs & "k \"" & o & "\""
    of ctAac:
      "ffmpeg -y -i \"" & i & "\" -c:a aac -b:a " & $kbs & "k \"" & o & "\""
  let res = execCmdEx(cmd)

proc convertAudioProcess*(audioType: ConvertAudioType, input, output: string, kbs: int) =
  ## This is a helper function that handles both single file and batch conversion
  ## for the aac and ogg commands.
  let inputPath = absolutePath(input)
  let outputDir = absolutePath(output)
  if inputPath.dirExists():
    # passing a directory will walk through all files in 
    # the directory and convert them to OGG format in the same directory
    discard existsOrCreateDir(outputDir)
    var m = createMaster()
    var sp = newSpinny("Converting audio to $1 format..." % $audioType, skDots)
    sp.start()
    m.awaitAll:
      for entry in walkFiles(inputPath / "*"):
        if not entry.isHidden and entry.splitFile()[2] in [".mp3", ".wav", ".flac"]:
          let outFile = outputDir / slugify(entry.splitFile()[1], sep = '_') & "." & $audioType
          m.spawn(convertAudio(audioType, absolutePath(entry), outFile, kbs))
    sp.success("Conversion completed!")
    displayInfo("Output directory: " & outputDir)
  elif inputPath.fileExists():
    # single file conversion
    var sp = newSpinny("Converting audio to " & $audioType & " format...", skDots)
    sp.start()
    let outputSplit = outputDir.splitFile()
    let outFile =
      if outputSplit.ext != "": outputSplit.dir / slugify(outputSplit.name, sep = '_') & "." & $audioType
      else: outputSplit.dir / slugify(inputPath.splitFile().name, sep = '_') & "." & $audioType
    convertAudio(audioType, inputPath.normalizedPath, outFile, kbs)
    sp.success("Conversion completed!")

proc aacCommand*(v: Values) =
  ## Convert audio files to AAC format
  let input = v.get("in").getPath
  let output = v.get("out").getFilepath()
  let kbs =
    if v.has("--kbs"):
      v.get("--kbs").getInt
    else: 128
  # checking if output file exists
  if output.fileExists:
    if not promptConfirm("Output file already exists. Overwrite? (y/n): "): return
  convertAudioProcess(ConvertAudioType.ctAac, input.path, output, kbs)

proc oggCommand*(v: Values) =
  ## Convert audio files to OGG format
  let input = v.get("in").getPath
  let output = v.get("out").getFilepath()
  let kbs =
    if v.has("--kbs"):
      v.get("--kbs").getInt
    else: 128
  # checking if output file exists
  if output.fileExists:
    if not promptConfirm("Output file already exists. Overwrite? (y/n): "): return
  convertAudioProcess(ConvertAudioType.ctOgg, input.path, output, kbs)