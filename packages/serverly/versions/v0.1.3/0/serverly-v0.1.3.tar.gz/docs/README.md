# Serverly
HTTP serving made easy

## Version
The current latest version is [v0.1.3](https://github.com/roger-padrell/serverly/releases/tag/v0.1.3) (you cant check it [here](https://github.com/roger-padrell/serverly/releases), if you want).

## Installation 
You need nim and nimble, which can be installed [here](https://nim-lang.org/install.html)

To download and install `Serverly`, run the following command on your terminal:
```
nimble install serverly
```
If you have a project and you want to add `serverly` as a dependency, run:
`nimble add serverly`
and it will also install `serverly` if it is not on the device.

## Usage and documentation
Go to the [documentation](https://roger-padrell.github.io/serverly/docs.html) to learn how to use `Serverly`.

## License
This project is open source and under the [MIT](https://opensource.org/licenses/MIT) license