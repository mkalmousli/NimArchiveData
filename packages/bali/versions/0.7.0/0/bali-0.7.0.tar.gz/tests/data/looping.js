var outputs1 = new Set;

for (var x = 0; x < 32; x++) {
	outputs1.add(x)
}

assert.sameValue(outputs1.toString(), "{ 0.0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31 }")

var outputs2 = new Set;
for (var x = 32; x > 0; x--)
{
	outputs2.add(x)
}

assert.sameValue(outputs2.toString(), "{ 32, 31, 30, 29, 28, 27, 26, 25, 24, 23, 22, 21, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1 }")
