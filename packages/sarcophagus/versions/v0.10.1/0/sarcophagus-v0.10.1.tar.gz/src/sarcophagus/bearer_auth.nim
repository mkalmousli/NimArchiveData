import std/macros

import mummy
import chroniclers

import ./core/jwt_bearer_tokens
import ./tapis_utils

export tapis_utils

type
  BearerAuthFailurePayload* = object
    ## Bearer auth error details serialized in error responses.
    code*: string
    message*: string

  BearerAuthErrorResponse* = object ## JSON returned by bearer auth error responses.
    status*: string
    error*: BearerAuthFailurePayload

  BearerAuthApiError* = ApiResponse[BearerAuthErrorResponse]

  AuthErrorResponder* =
    proc(failure: TokenValidationFailure): BearerAuthApiError {.gcsafe.}
    ## Callback used to build bearer-token validation error responses.

  AuthenticatedRequestHandler* =
    proc(request: Request, claims: BearerTokenClaims) {.gcsafe.}
    ## Mummy handler shape for endpoints that need validated bearer-token claims.

const routeRegistrationNames =
  ["addRoute", "get", "head", "post", "put", "delete", "options", "patch"]

proc bearerAuthFailurePayload(
    failure: TokenValidationFailure
): BearerAuthFailurePayload =
  BearerAuthFailurePayload(code: failure.code, message: failure.message)

proc bearerAuthErrorResponse*(
    statusCode: int, failure: TokenValidationFailure
): BearerAuthApiError =
  ## Builds a typed bearer auth error response.
  apiResponse(
    BearerAuthErrorResponse(status: "error", error: failure.bearerAuthFailurePayload()),
    statusCode,
  )

proc defaultAuthErrorResponder*(
    failure: TokenValidationFailure
): BearerAuthApiError {.gcsafe.} =
  ## Builds the default JSON error response for bearer-token validation failures.
  bearerAuthErrorResponse(failure.statusCode, failure)

proc validateBearerRequest*(
    request: Request, config: BearerTokenConfig, requiredScopes: openArray[string] = []
): TokenValidationResult {.gcsafe.} =
  ## Validates the request's `Authorization: Bearer ...` token.
  ##
  ## `requiredScopes` must all be present in the token for validation to pass.
  trace "validating bearer request",
    httpMethod = request.httpMethod,
    path = request.path,
    authorizationHeaderPresent = request.headers["Authorization"].strip().len > 0,
    requiredScopeCount = requiredScopes.len
  let token = bearerTokenFromAuthorizationHeader(request.headers["Authorization"])
  result = validateBearerToken(config, token, requiredScopes)
  if result.ok:
    debug "bearer request authorized",
      httpMethod = request.httpMethod,
      path = request.path,
      subject = result.claims.subject,
      scopeCount = result.claims.scopes.len
  else:
    notice "bearer request denied",
      httpMethod = request.httpMethod,
      path = request.path,
      statusCode = result.failure.statusCode,
      code = result.failure.code,
      message = result.failure.message,
      requiredScopeCount = requiredScopes.len

proc requireBearerAuth*(
    request: Request,
    config: BearerTokenConfig,
    requiredScopes: openArray[string] = [],
    onError: AuthErrorResponder = defaultAuthErrorResponder,
): bool {.gcsafe.} =
  ## Validates bearer auth and writes an error response on failure.
  ##
  ## Returns true when the request may continue to the protected handler.
  let validation = validateBearerRequest(request, config, requiredScopes)
  if validation.ok:
    return true

  request.respondTypedApiValue(onError(validation.failure))
  false

proc bearerTokAuth*(
    wrapped: RequestHandler,
    config: BearerTokenConfig,
    requiredScopes: openArray[string],
    onError: AuthErrorResponder = defaultAuthErrorResponder,
): RequestHandler =
  ## Wraps a plain Mummy handler with bearer-token authorization.
  let scopes = @requiredScopes
  return proc(request: Request) {.gcsafe.} =
    if not requireBearerAuth(request, config, scopes, onError):
      return
    wrapped(request)

proc bearerTokAuth*(
    wrapped: AuthenticatedRequestHandler,
    config: BearerTokenConfig,
    requiredScopes: openArray[string],
    onError: AuthErrorResponder = defaultAuthErrorResponder,
): RequestHandler =
  ## Wraps a Mummy handler and passes validated token claims to it.
  let scopes = @requiredScopes
  return proc(request: Request) {.gcsafe.} =
    let validation = validateBearerRequest(request, config, scopes)
    if not validation.ok:
      request.respondTypedApiValue(onError(validation.failure))
      return
    wrapped(request, validation.claims)

proc isRouteRegistrationCall(node: NimNode): bool =
  if node.kind notin {nnkCall, nnkCommand} or node.len == 0:
    return false
  let callee = node[0]
  if callee.kind != nnkDotExpr or callee.len != 2:
    return false
  if callee[1].kind != nnkIdent:
    return false
  let name = $callee[1]
  name in routeRegistrationNames

proc rewriteWithBearerTokAuth(
    node: NimNode, config: NimNode, requiredScopes: NimNode
): NimNode =
  case node.kind
  of nnkStmtList:
    result = newStmtList()
    for child in node:
      result.add(rewriteWithBearerTokAuth(child, config, requiredScopes))
  of nnkCall, nnkCommand:
    result = copyNimTree(node)
    if isRouteRegistrationCall(node):
      if result.len < 3:
        error(
          "withBearerTokAuth expects route registrations with a handler argument", node
        )
      let handlerIdx = result.len - 1
      result[handlerIdx] =
        newCall(bindSym"bearerTokAuth", result[handlerIdx], config, requiredScopes)
    else:
      for idx in 1 ..< result.len:
        result[idx] = rewriteWithBearerTokAuth(result[idx], config, requiredScopes)
  else:
    result = copyNimTree(node)
    for idx in 0 ..< result.len:
      result[idx] = rewriteWithBearerTokAuth(result[idx], config, requiredScopes)

macro withBearerTokAuth*(config: typed, requiredScopes: typed, body: untyped): untyped =
  ## Applies `bearerTokAuth` to route registrations inside `body`.
  ##
  ## The macro rewrites Mummy route calls such as `router.get(...)` so their
  ## handler argument is wrapped with bearer-token authorization.
  rewriteWithBearerTokAuth(body, config, requiredScopes)
