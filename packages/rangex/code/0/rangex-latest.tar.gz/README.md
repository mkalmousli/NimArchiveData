Comptime range builder
