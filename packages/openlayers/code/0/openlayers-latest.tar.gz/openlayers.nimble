version       = "0.3.0"
author        = "Jaremy Creechley"
description   = "openlayer javascript bindings"
license       = "BSD-2-Clause"
srcDir        = "src"

requires "https://github.com/elcritch/bunnery >= 0.3"


feature "dev":
  requires "karax"

feature "reference":
  requires "p5nim"
  requires "ajax"
  requires "https://github.com/openlayers/openlayers"

