import
  os,
  parseopt,
  std/[terminal],
  strformat,
  strutils,
  tables

import config
import lib


proc parseArguments(): CommandLineOptions =
  var
    searchQuery = ""
    options = to_table({"musicOnly": false, "feelingLucky": false, "fullScreen": false, "download": false})

  for kind, key, value in getopt():
    case kind
    of cmdArgument:
      searchQuery = key
    of cmdShortOption, cmdLongOption:
      case key
      of "m", "music": options["musicOnly"] = true
      of "l", "lucky": options["feelingLucky"] = true
      of "f", "full-screen": options["fullScreen"] = true
      of "d", "download": options["download"] = true
    of cmdEnd: discard

  return (searchQuery, options)


proc isValidOptions*(options: Options): bool =
  # Check for invalid combinations of options
  var invalidCombinations = [("musicOnly", "fullScreen"), ("download", "fullScreen")]
  for combination in invalidCombinations:
    if options[combination[0]] and options[combination[1]]:
     stderr.writeLine fmt"Incompatible options provided: {combination[0]} and {combination[1]}"
     return false
  return true


proc main() =
  let
    player = selectMediaPlayer()
    (searchQuery, options) = parseArguments()

  if(not isValidOptions(options)):
    quit(1)

  if searchQuery.startswith("https:") or searchQuery.startswith("magnet:"):
    if options["download"]:
      directDownload(sanitizeURL(searchQuery), options["musicOnly"])
    else:
      directPlay(sanitizeURL(searchQuery), player, options["musicOnly"])
    quit(0)

  let searchResults = extractTitlesAndUrls(getYoutubePage(searchQuery))

  proc getUserInput(): string =
    if options["feelingLucky"]: "0"
    else:
      presentVideoOptions(searchResults[..(limit-1)])
      stdout.styledWrite(fgYellow, "Choose video number: ")
      readLine(stdin)

  # This is a pure function with no side effects
  func buildPlayerArgs(number: int): seq[string] =
    var args = @[searchResults[number].url]
    if options["musicOnly"]: args.add("--no-video")
    if options["fullScreen"]: args.add("--fullscreen")
    return args

  proc handleUserInput(number: int) =
    if options["download"]:
      if options["musicOnly"]:
        download(buildMusicDownloadArgs(searchResults[number].url), searchResults[number].title)
      else:
        download(buildVideoDownloadArgs(searchResults[number].url), searchResults[number].title)
    else:
      play(player, buildPlayerArgs(number), searchResults[number].title)


  while(true):
    let userInput = getUserInput()

    if userInput == "all":
      for number in 0..(len(searchResults)):
        # TODO `spawn` this?
        handleUserInput(number)

    if userInput == "q":
      break

    # Play the video using the preferred/available media player
    let videoNumber = parseInt(userInput)
    handleUserInput(videoNumber)
    if options["feelingLucky"]:
      break


when isMainModule:
  main()
