import
  htmlparser,
  httpClient,
  os,
  osproc,
  sequtils,
  sugar,
  strformat,
  std/[terminal],
  strformat,
  strtabs,
  strutils,
  tables,
  uri,
  xmltree

import config

type
  Options* = Table[string, bool]
  SearchResult* = tuple[title: string, url: string]
  CommandLineOptions* = tuple[searchQuery: string, options: Options]

# poEchoCmd can be added to options for debugging
let processOptions = {poStdErrToStdOut, poUsePath, poEchoCmd}

proc selectMediaPlayer*(): string =
  let availablePlayers = filterIt(supportedPlayers, execProcess("which " & it).len != 0)
  if len(availablePlayers) == 0:
    stderr.writeLine &"Please install one of the supported media players: {supportedPlayers}"
    raise newException(OSError, "No supported media player found")
  else:
    return availablePlayers[0]

proc getYoutubePage*(searchQuery: string): string =
  let queryParam = encodeUrl(searchQuery)
  let client = newHttpClient()
  let response = get(client, &"https://www.youtube.com/results?hl=en&search_query={queryParam}")
  return $response.body

func extractTitlesAndUrls*(html: string): seq[SearchResult] =
  {.noSideEffect.}:
    parseHtml(html).findAll("a").
      filter(a => "watch" in a.attrs["href"] and a.attrs.hasKey "title").
      map(a => (a.attrs["title"], "https://www.youtube.com" & a.attrs["href"]))

proc presentVideoOptions*(searchResults: seq[SearchResult]) =
  eraseScreen()
  for index, (title, url) in searchResults:
    styledEcho $index, ". ", styleBright, fgMagenta, title, "\n", resetStyle, fgCyan, url, "\n"

proc play*(player: string, args: openArray[string], title: string) =
  styledEcho "\n", fgGreen, "Playing ", styleBright, fgMagenta, title
  if "--no-video" in args:
    discard execShellCmd(&"{player} {args.join(\" \")}")
  else:
    discard execProcess(player, args=args, options=processOptions)

func buildMusicDownloadArgs*(url: string): seq[string] =
  {.noSideEffect.}:
    var args = @["--ignore-errors", "-f", "bestaudio", "--extract-audio", "--audio-format", "mp3", "--audio-quality", "0", "-o"]
    let downloadLocation = &"'{expandTilde(musicDownloadDirectory)}/%(title)s.%(ext)s'"
    args.add(downloadLocation)
    args.add(url)
    return args

func buildVideoDownloadArgs*(url: string): seq[string] =
  {.noSideEffect.}:
    var args = @["-f", "best", "-o"]
    let downloadLocation = &"'{expandTilde(videoDownloadDirectory)}/%(title)s.%(ext)s'"
    args.add(downloadLocation)
    args.add(url)
    return args

proc download*(args: openArray[string], title: string) =
  styledEcho "\n", fgGreen, "Downloading ", styleBright, fgMagenta, title
  discard execShellCmd(&"youtube-dl {args.join(\" \")}")

func urlLongen(url: string): string =
  url.replace("youtu.be/", "www.youtube.com/watch?v=")

func stripZshEscaping(url: string): string =
  url.replace("\\", "")

func sanitizeURL*(url: string): string =
  urlLongen(stripZshEscaping(url))

proc directPlay*(url: string, player: string, musicOnly: bool) =
  if url.startswith("magnet:"):
    if musicOnly:
      discard execShellCmd(&"peerflix '{url}' -a --{player} -- --no-video")
    else:
      discard execProcess("peerflix", args=[url, &"--{player}"], options=processOptions)
  else:
    if musicOnly:
      discard execShellCmd(&"{player} --no-video {url}")
    else:
      discard execProcess(player, args=[url], options=processOptions)

proc directDownload*(url: string, musicOnly: bool) =
  let args =
    if musicOnly: buildMusicDownloadArgs(url)
    else: buildVideoDownloadArgs(url)
  discard execShellCmd(&"youtube-dl {args.join(\" \")}")
