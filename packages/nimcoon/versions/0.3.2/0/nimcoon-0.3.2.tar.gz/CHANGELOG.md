# 0.3.2

- Reimplement streaming of YouTube playlists

# 0.3.1

- Fix mistake with tagging.

# 0.3.0

- Add support for playing playlists of videos and songs from YouTube
- Playlists can be played by providing the first video in the list or by directly providing the playlist url

# 0.2.2

- Fix bug with paginated result selection

# 0.2.1

- Fix minor regression in pagination

# 0.2.0

- Implement pagination with shortcuts "n" and "p" to navigate between pages

# 0.1.0

- Search for videos using keywords
- Stream videos and music from YouTube
- Play direct links from YouTube and PeerTube
- Stream video and music from magnet links
- Download music
- Download video
