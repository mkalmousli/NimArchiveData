;;; nimcoon.el -*- lexical-binding: t; -*-
;;;
;;; Usage in Doom Emacs
;;; Place or symlink the file into ~/.doom.d/
;;; (load! "nimcoon")

;;; Non-interactive functions to respond to URL clicks
(defun nimcoon-play-url (url &rest args)
  "Play given URL in NimCoon."
  (start-process "nimcoon" nil "nimcoon" url))

;; Play all YouTube URLs in NimCoon
(setq browse-url-browser-function
      (quote
       (("youtu\\.?be" . nimcoon-play-url)
        ("." . browse-url-default-browser))))

(defun run-nimcoon(args query)
  "Search by QUERY and play in NimCoon."
  (call-process "nimcoon" nil 0 nil args query))

;;; Interactive functions
(defun nimcoon-feeling-lucky-music(query)
  (interactive "sSearch query: ")
  (run-nimcoon "-ml" query))

(defun nimcoon-feeling-lucky-video(query)
  (interactive "sSearch query: ")
  (run-nimcoon "-l" query))

(defun nimcoon-download-video(query)
  (interactive "sSearch query: ")
  (run-nimcoon "-dl" query))

(defun nimcoon-download-music(query)
  (interactive "sSearch query: ")
  (run-nimcoon "-dlm" query))

;; Assumes only one process exists. Must capture the pid of the running NimCoon process and only kill it.
(defun nimcoon-kill-background-processes()
  "Kill NimCoon process running in the background. Useful for stopping background music."
  (interactive)
  (shell-command "kill `pgrep nimcoon` `pgrep mpv` `pgrep vlc`"))

(defun nimcoon-search-video(query)
  "Search for a video by QUERY."
  (interactive "sSearch query: ")
  (with-output-to-temp-buffer "*NimCoon search results*"
    (call-process "nimcoon" nil "*NimCoon search results*" t "--non-interactive" query)
    (with-current-buffer "*NimCoon search results*"
      (org-mode))))

(defun nimcoon-search-music(query)
  "Search for a video by QUERY."
  (interactive "sSearch query: ")
  (with-output-to-temp-buffer "*NimCoon search results*"
    (call-process "nimcoon" nil "*NimCoon search results*" t "--music" "--non-interactive" query)
    (with-current-buffer "*NimCoon search results*"
      (org-mode))))

;;; Keybindings
(map! :leader
      ;;; <leader> N --- NimCoon
      (:prefix-map ("N" . "NimCoon")
       (:prefix ("d" . "Download")
        :desc "Video" "v" #'nimcoon-download-video
        :desc "Music" "m" #'nimcoon-download-music)
       (:prefix ("s" . "Search")
        :desc "Video" "v" #'nimcoon-search-video
        :desc "Music" "m" #'nimcoon-search-music)
       :desc "Kill"  "k" #'nimcoon-kill-process
       :desc "Video" "v" #'nimcoon-feeling-lucky-video
       :desc "Music" "m" #'nimcoon-feeling-lucky-music))
