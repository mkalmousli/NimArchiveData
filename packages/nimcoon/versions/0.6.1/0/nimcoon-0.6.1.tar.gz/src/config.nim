# Your configuration here.

# Supported video players in order of preference.
# Should be able to play YouTube videos directly.
let supportedPlayers* = ["mpv", "vlc"]

# Only show these many results
let limit* = 10

# Download videos to this directory
let videoDownloadDirectory* = "~/Videos"

# Download music to this directory
let musicDownloadDirectory* = "~/Music"

# Rewrite Invidious URLs to YouTube
# Using Invidious as a proxy makes loading YouTube videos much slower
let rewriteInvidiousURLs* = false
