import
  httpClient,
  json,
  os,
  osproc,
  re,
  sequtils,
  std/[terminal],
  strformat,
  strutils,
  tables

import
  config,
  types


let
  processOptions = {poStdErrToStdOut, poUsePath} # poEchoCmd can be added to options for debugging
  PEERTUBE_REGEX = re"videos\/watch\/[0-9a-f]{8}\b-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-\b[0-9a-f]{12}"


proc isInstalled(program: string): bool =
  execProcess("which " & program).len != 0


proc selectMediaPlayer*(): string =
  let availablePlayers = supportedPlayers.filter(isInstalled)
  if len(availablePlayers) == 0:
    stderr.writeLine &"Please install one of the supported media players: {supportedPlayers}"
    raise newException(OSError, "No supported media player found")
  else:
    return availablePlayers[0]


proc getPeerTubeMagnetLink(url: string): string =
  ## Gets the magnet link of the best possible resolution from PeerTube
  let uuid = url.substr(find(url, PEERTUBE_REGEX) + "videos/watch/".len)
  let domainName = url.substr(8, find(url, '/', start=8) - 1)
  let apiURL = &"https://{domainName}/api/v1/videos/{uuid}"
  let client = newHttpClient()
  let response = get(client, apiURL)
  let jsonNode = parseJson($response.body)
  jsonNode["files"][0]["magnetUri"].getStr()


proc presentVideoOptions*(searchResults: SearchResults) =
  eraseScreen()
  for index, (title, url) in searchResults:
    styledEcho $index, ". ", styleBright, fgMagenta, title, "\n", resetStyle, fgCyan, "   ", url, "\n"

func buildPlayerArgs(url: string, options: Table[string, bool], player: string): seq[string] =
  let musicOnly = if options["musicOnly"]: "--no-video" else: ""
  let fullScreen = if options["fullScreen"]: "--fullscreen" else: ""
  filterIt([url, musicOnly, fullScreen], it != "")


proc play*(player: string, options: Table[string, bool], url: string, title: string = "") =
  let args = buildPlayerArgs(url, options, player)
  if title != "":
    styledEcho "\n", fgGreen, "Playing ", styleBright, fgMagenta, title
  if "--no-video" in args:
    discard execShellCmd(&"{player} {args.join(\" \")}")
  else:
    discard startProcess(player, args=args, options=processOptions)


func buildMusicDownloadArgs(url: string): seq[string] =
  {.noSideEffect.}:
    let downloadLocation = &"'{expandTilde(musicDownloadDirectory)}/%(title)s.%(ext)s'"
    @["--ignore-errors", "-f", "bestaudio", "--extract-audio", "--audio-format", "mp3",
      "--audio-quality", "0", "-o", downloadLocation, url]


func buildVideoDownloadArgs(url: string): seq[string] =
  {.noSideEffect.}:
    let downloadLocation = &"'{expandTilde(videoDownloadDirectory)}/%(title)s.%(ext)s'"
    @["-f", "best", "-o", downloadLocation, url]


proc download*(args: openArray[string], title: string) =
  styledEcho "\n", fgGreen, "Downloading ", styleBright, fgMagenta, title
  discard execShellCmd(&"youtube-dl {args.join(\" \")}")


func urlLongen(url: string): string = url.replace("youtu.be/", "www.youtube.com/watch?v=")


func rewriteInvidiousToYouTube(url: string): string =
  {.noSideEffect.}:
    if rewriteInvidiousURLs: url.replace("invidio.us", "www.youtube.com") else: url


func stripZshEscaping(url: string): string = url.replace("\\", "")


func sanitizeURL*(url: string): string =
  rewriteInvidiousToYouTube(urlLongen(stripZshEscaping(url)))


proc directPlay*(url: string, player: string, options: Table[string, bool]) =
  let url =
    if find(url, PEERTUBE_REGEX) != -1 and isInstalled("webtorrent"):
      getPeerTubeMagnetLink(url)
    else: url
  if url.startswith("magnet:") or url.endswith(".torrent"):
    if options["musicOnly"]:
      # TODO Replace with WebTorrent once it supports media player options
      discard execShellCmd(&"peerflix '{url}' -a --{player} -- --no-video")
    else:
      # WebTorrent is so much faster!
      discard execProcess("webtorrent", args=[url, &"--{player}"], options=processOptions)
  else:
    play(player, options, url)


proc directDownload*(url: string, musicOnly: bool) =
  let args =
    if musicOnly: buildMusicDownloadArgs(url)
    else: buildVideoDownloadArgs(url)
  if isInstalled("aria2c"):
    discard execShellCmd(&"youtube-dl {args.join(\" \")} --external-downloader aria2c --external-downloader-args '-x 16 -s 16 -k 2M'")
  else:
    discard execShellCmd(&"youtube-dl {args.join(\" \")}")


proc offerSelection(searchResults: SearchResults, options: Table[string, bool], selectionRange: SelectionRange): string =
  if options["feelingLucky"]: "0"
  else:
    presentVideoOptions(searchResults[selectionRange.begin .. selectionRange.until])
    stdout.styledWrite(fgYellow, "Choose video number: ")
    readLine(stdin)


proc handleUserInput(searchResult: SearchResult, options: Table[string, bool], player: string) =
  if options["download"]:
    if options["musicOnly"]:
      download(buildMusicDownloadArgs(searchResult.url), searchResult.title)
    else:
      download(buildVideoDownloadArgs(searchResult.url), searchResult.title)
  else:
    play(player, options, searchResult.url, searchResult.title)


proc present*(searchResults: SearchResults, options: Table[string, bool], selectionRange: SelectionRange, player: string) =
  ##[ Continuously present options till the user quits the application

        selectionRange: Currently available range to choose from depending on pagination
  ]##

  let userInput = offerSelection(searchResults, options, selectionRange)

  case userInput
  of "all":
    for selection in selectionRange.begin .. selectionRange.until:
      handleUserInput(searchResults[selection], options, player)
    quit(0)
  of "n":
    if selectionRange.until + 1 < len(searchResults):
      let newSelectionRange = (selectionRange.until + 1, min(len(searchResults) - 1, selectionRange.until + limit))
      present(searchResults, options, newSelectionRange, player)
    else:
      present(searchResults, options, selectionRange, player)
  of "p":
    if selectionRange.begin > 0:
      let newSelectionRange = (selectionRange.begin - limit, selectionRange.until - limit)
      present(searchResults, options, newSelectionRange, player)
    else:
      present(searchResults, options, selectionRange, player)
  of "q":
    quit(0)
  else:
    let searchResult = searchResults[selectionRange.begin .. selectionRange.until][parseInt(userInput)]
    handleUserInput(searchResult, options, player)
    if options["feelingLucky"]:
      quit(0)
    else:
      present(searchResults, options, selectionRange, player)
