import
  httpClient,
  json,
  re,
  strformat,
  strutils

let PEERTUBE_REGEX = re"videos\/watch\/[0-9a-f]{8}\b-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-\b[0-9a-f]{12}"

proc getPeerTubeMagnetLink*(url: string): string =
  ## Gets the magnet link of the best possible resolution from PeerTube
  let uuid = url.substr(find(url, PEERTUBE_REGEX) + "videos/watch/".len)
  let domainName = url.substr(8, find(url, '/', start=8) - 1)
  let apiURL = &"https://{domainName}/api/v1/videos/{uuid}"
  let client = newHttpClient()
  let response = get(client, apiURL)
  let jsonNode = parseJson($response.body)
  jsonNode["files"][0]["magnetUri"].getStr()
