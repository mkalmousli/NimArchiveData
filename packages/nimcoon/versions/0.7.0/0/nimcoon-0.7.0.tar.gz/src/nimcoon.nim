import
  parseopt,
  strformat,
  strutils,
  tables

import
  config,
  lib,
  types,
  youtube


proc parseArguments(): CommandLineOptions =

  var
    searchQuery = ""
    options = to_table({
      "musicOnly": false,
      "feelingLucky": false,
      "fullScreen": false,
      "download": false,
      "non-interactive": false
    })

  for kind, key, value in getopt():
    case kind
    of cmdArgument:
      searchQuery = key
    of cmdShortOption, cmdLongOption:
      case key
      of "m", "music": options["musicOnly"] = true
      of "l", "lucky": options["feelingLucky"] = true
      of "f", "full-screen": options["fullScreen"] = true
      of "d", "download": options["download"] = true
      of "n", "non-interactive": options["non-interactive"] = true
    of cmdEnd: discard

  if searchQuery == "":
    stderr.writeLine "NimCoon doesn't permit browsing. You must provide a search query."
    quit(1)

  (searchQuery, options)


proc isValidOptions*(options: Options): bool =
  # Check for invalid combinations of options
  var invalidCombinations = [("musicOnly", "fullScreen"), ("download", "fullScreen")]
  result = true
  for combination in invalidCombinations:
    if options[combination[0]] and options[combination[1]]:
     stderr.writeLine fmt"Incompatible options provided: {combination[0]} and {combination[1]}"
     result = false


proc main() =
  let
    player = selectMediaPlayer()
    (searchQuery, options) = parseArguments()

  if(not isValidOptions(options)):
    quit(1)

  if searchQuery.startswith("http") or searchQuery.startswith("magnet"):
    if options["download"]:
      directDownload(sanitizeURL(searchQuery), options["musicOnly"])
    else:
      directPlay(sanitizeURL(searchQuery), player, options)
    quit(0)

  let searchResults = getSearchResults(searchQuery)
  if options["non-interactive"]:
    for index, (title, url) in searchResults:
      echo title
      echo url
      echo ""
    quit(0)

  let numResults = min(limit, len(searchResults))

  present(searchResults, options, (0, numResults-1), player)


when isMainModule:
  main()
