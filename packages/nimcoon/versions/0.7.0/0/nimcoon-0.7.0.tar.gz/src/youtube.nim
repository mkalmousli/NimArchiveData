import
  httpClient,
  json,
  strformat,
  uri

import
  config,
  types


discard """
Using Invidious API to retrieve the search results but playing the results directly from YouTube.

API reference:
https://github.com/iv-org/documentation/blob/master/API.md#get-apiv1search
"""

proc getSearchResults*(searchQuery: string): SearchResults =
  let queryParam = encodeUrl(searchQuery)
  let client = newHttpClient()
  let response = get(client, &"{invidiousInstance}/api/v1/search?q={queryParam}")
  let jsonData = parseJson($response.body)
  var searchResults: SearchResults = @[]
  for item in jsonData:
    if item["type"].getStr() == "video":
      searchResults.add((item["title"].getStr(), "https://www.youtube.com/watch?v=" & item["videoId"].getStr()))
    elif item["type"].getStr() == "playlist":
      searchResults.add((item["title"].getStr(), "https://www.youtube.com/watch?v=" & item["playlistId"].getStr()))
    # Not handling type = channel for now
  searchResults
