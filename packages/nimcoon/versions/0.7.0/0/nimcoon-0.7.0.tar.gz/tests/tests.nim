import
  tables,
  unittest

import lib
import nimcoon

suite "Playing direct links":

  test "sanitize URL":
    let expected = "https://www.youtube.com/watch?v=QOEMv0S8AcA"
    check(sanitizeURL("https://youtu.be/QOEMv0S8AcA") == expected)
    check(sanitizeURL("https://www.youtube.com/watch\\?v\\=QOEMv0S8AcA") == expected)

  test "validate options":
    let invalidOptionsList = [
      to_table({"musicOnly": true, "feelingLucky": false, "fullScreen": true, "download": false}),
      to_table({"musicOnly": false, "feelingLucky": true, "fullScreen": true, "download": true})
    ]
    for invalidOptions in invalidOptionsList:
      check(not isValidOptions(invalidOptions))
    let validOptionsList = [
      to_table({"musicOnly": false, "feelingLucky": true, "fullScreen": false, "download": true}),
      to_table({"musicOnly": false, "feelingLucky": true, "fullScreen": true, "download": false})
    ]
    for validOptions in validOptionsList:
      check(isValidOptions(validOptions))

  test "rewrite invidious urls":
    let url = "https://invidious.snopyta.org/watch?v=sZhxCUay5ks"
    check(rewriteInvidiousToYouTube(url) == "https://www.youtube.com/watch?v=sZhxCUay5ks")
