# Package

version       = "0.3.1"
author        = "Joseph Nuthalapati"
description   = "A command-line YouTube player and more"
license       = "GPL-3.0"
srcDir        = "src"
bin           = @["nimcoon"]

# Dependencies

requires "nim >= 1.0.2"
