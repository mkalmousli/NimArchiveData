# 0.2.1

- Fix minor regression in pagination

# 0.2.0

- Implement pagination with shortcuts "n" and "p" to navigate between pages

# 0.1.0

- Search for videos using keywords
- Stream videos and music from YouTube
- Play direct links from YouTube and PeerTube
- Stream video and music from magnet links
- Download music
- Download video
