# 0.8.0

- Interactive options
- YouTube auto-play

# 0.7.0

- Fix broken direct play.
- Use Invidious instance for retrieving search results but use YouTube to get content.

# 0.6.1

- Minor bug fix

# 0.6.0

- Scrape from YouTube directly, no dependence on Invidious instances
- Doom Emacs integration

# 0.5.1

- Fix crash when search has <10 results
- Find alternative to invidio.us instance

# 0.5.0

- Use Invidio.us to retrieve search results
- Support http in addition to https
- README: Add section on Motivation
- README: Add comprehensive feature list
- Update README with a progress report on features
- Use aria2c download manager if available
- VLC is better than CVLC
- Minor formatting changes

# 0.4.0

- Allow picking up torrent links from http urls (PeerTube provides these in download options)
- Given a PeerTube link, automatically pick the best resolution video and stream it using WebTorrent

# 0.3.2

- Reimplement streaming of YouTube playlists

# 0.3.1

- Fix mistake with tagging.

# 0.3.0

- Add support for playing playlists of videos and songs from YouTube
- Playlists can be played by providing the first video in the list or by directly providing the playlist url

# 0.2.2

- Fix bug with paginated result selection

# 0.2.1

- Fix minor regression in pagination

# 0.2.0

- Implement pagination with shortcuts "n" and "p" to navigate between pages

# 0.1.0

- Search for videos using keywords
- Stream videos and music from YouTube
- Play direct links from YouTube and PeerTube
- Stream video and music from magnet links
- Download music
- Download video
