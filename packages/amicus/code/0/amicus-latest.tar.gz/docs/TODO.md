# TODO list for amicus

* Implement everything required by Mastodon's API

* Potentially look into sqlite support
This might not work due to sqlite missing support for the `UUID` datatype which we can easily polyfilled with either `BLOB` or `TEXT` but sqlite doesn't support arrays the way that postgres does, forcing us to create more tables for the integer arrays (such as user roles)

