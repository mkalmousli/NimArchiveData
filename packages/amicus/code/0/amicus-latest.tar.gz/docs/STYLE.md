# Database procedures shouldn't check for anything.

Procedures that connect to the database should do *one thing only* without **any** checks.

These procedures are meant to be a simple abstraction over the raw database,
we don't want procedures to excessively call other procedures because then
it can be hard to trace and profile where queries are actually coming from.

And yes, this means absolutely no checks. The client should be doing checks

# Multiple database engine support in one build.

Amicus is meant to be a database-neutral way for the client to store data in a structured manner.
Onbox, the main client app, should not care if we are using postgres or sqlite,
this library is meant to abstract away those differences into a nice interface.

In theory, Amicus supports different database engines through the `dbEngine` compile-time constant.
It's defined like so:

```nim
# in amicus/shared

const dbEngine*{.strdefine.} = "postgres"
```

If and when we add support for different engines, we can simply add a new compile-time comparison/directive
Like so

```nim

proc userExists*(db: DbConn, id: string): bool =
  when dbEngine == "postgres":
    ...

  when dbEngine == "sqlite":
    ...
```

There are problems with this approach:

1. We are locked into the `db_connector` interface, since we use `DbConn` object in the proc parameters.
2. Users will need to download the Onbox binary (or client binary) that matches their database engine
3. Package maintainers will have to package binaries for every database engine, which is painful.
4. This approach complicates the build process and makes developing/using Amicus less flexible
   (It'd be nice to develop using sqlite and deploy using postgres with relative ease)

On August 5th, I started working on a way to support different database engines in a single build.
I wanna solve all the problems above, and an easy way would be to develop our own db interface which clients can pass with ease.
This custom interface looks like so:

```nim

type
  ADbType* {.pure.} = enum
    Postgres, Sqlite

  AmicusDb* = object
    # `pgc` and `sqc` will contain the actual db handle
    case kind: ADbType
    of ADbType.Postgres:
      pgc: PostgresDbConn 
    of ADbType.Sqlite:
      sqc: SqliteDbConn   

```

We could just make our own database interface by wrapping sqlite and postgres's C libraries.
I'd like to do that, I know it's gonna be hard but it'd be more enjoyable and rewarding than merely wrapping a database connector library.
We could also eliminate the dependency on `db_connector`, which is something I've been wanting to do for a while.

For the most part, we only use four features from `db_connector`
1. `exec`: Run a SQL query, return no rows.
2. `getRow`: Run a SQL query, return a single row
3. `getAllRows`: Run a SQL query, return all rows given
4. `open`: Obviously...

Also, minor nitpicking but the `Row` object in `db_connector` is just so stupid...
It's so bad at representing the different datatypes used in modern relational databases, and I've easily spent hours writing parsers to convert back and forth between these different formats. I hate it!
I know at the end, I'm gonna have to end up re-writing everything but I wanna make a nice API at least.

We could kill two birds with one stone by making a nice API that automatically converts rows into their respective datatypes.
Kinda like `tiny_sqlite` does with its [DbValue](https://gulpf.github.io/tiny_sqlite/tiny_sqlite.html#DbValue) object.
I think I wanna implement that type of API, it's gonna require a large-scale re-write of *all* the code we have so far.
Still, it's better to do it now rather than later.

Note: This API will be used heavily inside of Amicus but it must **never** be exposed to client apps. So, here's a list of requirements for the API I end up making.

1. Must have a `DbConn`-like object to be passed by clients with all the neccessary info.  

So, all that a client has to do in order to call the public Amicus API, is:

```nim
let db = openSqlite(...)
# OR
let db = openPostgres(...)

assert db.userIdExists(...)
```

The user need not worry about database engine differences, that's Amicus's job.
The only thing they need to worry about is calling the right `open()` and `close()` procedures for the database engine being used.

2. Maximum flexibility for each database engine

If this proposal is implemented, then writing database logic will look like so:

```nim
proc userIdExists(db: AmicusDbConn, id: string): bool = 
  case db.kind:
  of Postgres:
    # one() returns a single row
    return postgres.one(db,"SELECT EXISTS(SELECT 0 FROM users WHERE id = ?;)",id)[0].boolVal 
  of Sqlite:
    # one() returns a single row
    return sqlite.one(db,"SELECT EXISTS(SELECT 1 FROM users WHERE id = ?;)",id)[0].boolVal

proc setMetaKey(db: AmicusDbConn, k,v: string) =
  case db.kind:
  of Postgres:
    # exec() runs a single query
    postgres.exec(db, "INSERT INTO meta VALUES (?,?);", k, v)
  of Sqlite:
    # exec() runs a single query
    sqlite.exec(db, "INSERT INTO meta VALUES (?,?);", k, v)

proc getAllMetaKeys(db: AmicusDbConn): Table[string, string] =
  case db.kind:
  of Postgres:
    # all() returns multiple rows
    for row in postgres.all(db, "SELECT k,v FROM meta;"):
      result[row[0].strVal]= row[1].strVal
  of Sqlite:
    # all() returns multiple rows
    for row in sqlite.all(db, "SELECT k,v FROM meta;"):
      result[row[0].strVal]= row[1].strVal
```

The idea is that inside each case statement, the developers should be able to utilize the
specific functions for the database engine to their hearts content. This avoids ugly abstraction problems.
And it keeps the codebase cleaner.

3. Modular structure

The `sqlite.exec()` and `postgres.exec()` calls look a bit confusing until you realize that `sqlite` and `postgres`
are namespaces and that we're merely calling the `exec()` procedure in the `postgres.nim` and `sqlite.nim` modules.
In order to implement that kinda API, we're gonna have a special structure for this proposal.

* `amicus/private/sqlite`: Exposes all sqlite-related db functions
* `amicus/private/postgres`: Exposes all postgres-related db functions
* `amicus/private/common`: Exposes `AmicusDb` and `ADbType`
* `amicus/private/all`: Exposes all three, each one can be accessed using namespaces.

4. Each database engine must provide the `exec`, `one` and `all` private procedures

This naming scheme is inspired by `tiny_sqlite` and the way these procedures work is also inspired by `tiny_sqlite`.
(Listen, it's not my fault that GULPF made a nice and easy-to-use API)

`tiny_sqlite` has an interesting way of doing `exec`, [look here](https://gulpf.github.io/tiny_sqlite/tiny_sqlite.html#exec%2CDbConn%2Cstring%2Cvarargs%5BDbValue%2CtoDbValue%5D)
Thanks to the `DbValue` object, the parameters do not need to be converted into strings (Like we do with `amicus/private/strconv.nim`)

The procedures provided by each database engine should attempt to do the same..

8. Client should **only** be able to use `openSqlite`, `openPostgres`, etc.

Do not expose `exec` or `getRow` or anything that we use except for the procedures to open databases.
Maybe in the future, we'll reconsider and let clients run arbitrary SQL. (Would be useful for extending amicus at the client-level)

Status for sqlite

1. `openSqlite()`, `closeSqlite()` and all the basic stuff works.
2. `exec()` works with no parameters
3. `exec()` works with parameters
4. Missing: `one()` and `all()`

Status for postgres:

1. I am afraid to start

This entire approach is a lot like Java's [`JDBC`](https://en.wikipedia.org/wiki/Java_Database_Connectivity) or [ODBC](https://en.wikipedia.org/wiki/Open_Database_Connectivity), except for the fact that the library using this, in this case, Amicus, **has** to care about the database engine differences.

Distributing this as a standalone library would be interesting, it would allow pretty much every Nim app developer to interoperate easily with both sqlite and postgres. Right now, this remains an Amicus-specific (and Onbox-specific) feature to simplify development, deployment and usage.

## Future ideas.

1. Look into using prepared statements for performance optimizations
2. Allow clients to access the provided `exec`, `one` and `all` procedures.
3. Distribute this as a standalone library.