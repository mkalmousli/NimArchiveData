# Copyright © Leo Gavilieau 2022-2023 <xmoo@privacyrequired.com>
# Copyright © penguinite 2024-2025 <penguinite@tuta.io>
#
# This file is part of Onbox.
# 
# Onbox is free software: you can redistribute it and/or modify it under the terms of
# the GNU Affero General Public License as published by the Free Software Foundation,
# either version 3 of the License, or (at your option) any later version.
# 
# Onbox is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License
# for more details.
# 
# You should have received a copy of the GNU Affero General Public License
# along with Onbox. If not, see <https://www.gnu.org/licenses/>. 
#
# db/users.nim:
## This module contains various functions and procedures for handling users.
import private/[dbutils, strconv], shared, crypto,
       std/[strutils, tables],
       db_connector/db_postgres

const
  handleFilter*: set[char] = {
    'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k',
    'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v',
    'w', 'x', 'y', 'z', '1', '2', '3', '4', '5', '6', '7',
    '8', '9', '0'
  } ## This filter permits only the valid characters for use in a local handle

  domainFilter*: set[char] = {
    'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k',
    'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v',
    'w', 'x', 'y', 'z', '1', '2', '3', '4', '5', '6', '7',
    '8', '9', '0', '.', '-'
  } ## This filter permits the only valid characters for use in a domain handle. (@ symbol not included)

func filterString*(str: string, charset: set[char] = handleFilter): string =
  ## Filter a string against a character set
  ## (such as handleFilter for the handles of users and
  ## domainFilter for the domains of remote users)
  runnableExamples "-r:off -c:off":
    import amicus
    assert filterString("john") == "john"
    assert filterString("john donald") == "johndonald"
    assert filterString("..'!)#)¤()'!.") == ""
  for ch in toLowerAscii(str):
    if ch in charset:
      result.add(ch)

proc createUser*(handle: string, local = true, password = "", domain = ""): User =
  ## Creates a new `User` object and fills in some common fields.
  ## (Such as the ID, roles and whatnot)
  ## 
  ## This procedure fills in the fields:
  ## 1. The ID field with a UUIDv4
  ## 2. The handle will be sanitized against ``handleFilter``
  ## 3. (If a domain is provided) the domain will be sanitized against the ``domainFilter``
  ## 4. (If a password is provided) then a salt will be generated,
  ##    the ``KDF`` field will be set and the password will be hashed.
  ## 5. The roles will be automatically set to plain user (0)
  ## 6. The user won't be discoverable by default
  ## 7. The user's email will be marked as unverified (though the email field won't be set)
  ## 
  ## It's highly recommended to use this procedure instead of
  ## manually creating a User object as it prevents the common gotchas
  ## by setting sane defaults.
  result.id = uuidv4()
  result.handle = filterString(handle, handleFilter)

  if domain != "":
    result.domain = filterString(domain, domainFilter)

  if local:
    result.domain = ""
    if password != "":
      result.salt = randstr(20)
      result.kdf = latestKdf
      result.password = hash(password, result.salt)
  
  # Set some defaults
  result.roles = @[0]
  result.discoverable = false
  result.email_verified = false

proc insertUser*(db: DbConn, user: User) = 
  ## Inserts a user into the database.
  ## 
  ## **Note:** You should *absolutely* be verifying the user and
  ## its fields are valid before running this operation.
  when dbEngine == "postgres":
    db.exec(
      sql"INSERT INTO users VALUES (?,?,?,?,?,?,?,?,?,?,?,?);",
      user.id, !$(user.kdf), !$(user.roles), $(user.discoverable),
      $(user.email_verified), user.handle, user.domain, user.name,
      user.email, user.bio, user.password, user.salt
    )
  else: {.warning: "insertUser() unimplemented".}

proc getAdmins*(db: DbConn): seq[string] = 
  ## Retrieve the user IDs of all the administrators. (Users with role nr. 3)
  runnableExamples "-r:off -c:off":
    # ignore these lines
    import amicus
    var db: DbConn

    assert db.getHandleFromId(db.getAdmins()[0]) == "bill"
    assert db.getHandleFromId(db.getAdmins()[1]) == "laura"
    assert db.getHandleFromId(db.getAdmins()[2]) == "kate"

    import std/strutils
    var html = "<h1>Administrators<h1>"
    for user in db.getAdmins():
      html.add("<p>$#</p>" % [db.getHandleFromId(user)])
  when dbEngine == "postgres":
    # TODO: Same problem as amicus/boosts.getBoostsQuick() where we have an extra for loop.
    for row in db.getAllRows(sql"SELECT id FROM users WHERE roles @> '{3}';"):
      result.add(row[0])
  else: {.warning: "getAdmins() unimplemented".}
  
proc getTotalLocalUsers*(db: DbConn): int =
  ## Retrieve the *total number* of local users.
  runnableExamples "-r:off":
    # ignore these lines
    import amicus
    var db: DbConn

    assert db.getTotalLocalUsers() > 9000

    import std/strutils
    var msg = "Local users: 100 out of $#" % [$(db.getTotalLocalUsers())]
  when dbEngine == "postgres":
    len(db.getAllRows(sql"SELECT 0 FROM users WHERE domain = '';"))
  else: {.warning: "getTotalLocalUsers() unimplemented".}

proc getDomains*(db: DbConn): CountTable[string] =
  ## A procedure to get the all of the domains known by this server in a CountTable
  when dbEngine == "postgres":
    for handle in db.getAllRows(sql"SELECT domain FROM users WHERE domain != '';"):
      result.inc(handle[0])
  else: {.warning: "getDomains() unimplemented".}

proc getTotalDomains*(db: DbConn): int =
  ## Return the total number of domains known by this server.
  when dbEngine == "postgres":
    len(db.getAllRows(sql"SELECT DISTINCT ON (domain) 0 FROM users WHERE domain != '';"))
  else: {.warning: "getTotalDomains() unimplemented".}

proc userIdExists*(db: DbConn, id:string): bool =
  ## A procedure to check if a user exists by id
  when dbEngine == "postgres":
    db.getRow(
      sql"SELECT EXISTS(SELECT 0 FROM users WHERE id = ?);", id
    )[0] == "t"
  else: {.warning: "userIdExists() unimplemented".}

proc userHandleExists*(db: DbConn, handle:string, domain = ""): bool =
  ## A procedure to check if a user exists by handle
  ## This procedure does sanitize and escape handles by default
  when dbEngine == "postgres":
    db.getRow(
      sql"SELECT EXISTS(SELECT 0 FROM users WHERE handle = ? AND domain = ?);", handle, domain
    )[0] == "t"
  else: {.warning: "userHandleExists() unimplemented".}

proc emailExists*(db: DbConn, email: string): bool =
  ## Checks if a user with a specific email address already exists.
  when dbEngine == "postgres":
    db.getRow(
      sql"SELECT EXISTS(SELECT 0 FROM users WHERE email = ?);", email
    )[0] == "t"
  else: {.warning: "emailExists() unimplemented".}

proc getUserEmail*(db: DbConn, id: string): string =
  ## Retrieves the email of a user (given with ID)
  when dbEngine == "postgres":
    db.getRow(sql"SELECT email FROM users WHERE id = ?;", id)[0]
  else: {.warning: "getUserEmail() unimplemented".}

proc getUserByEmail*(db: DbConn, email: string): string =
  ## Retrieves the user id by using the email associated with the user
  when dbEngine == "postgres":
    db.getRow(sql"SELECT id FROM users WHERE email = ?;", email)[0]
  else: {.warning: "getUserByEmail() unimplemented".}

proc getUserSalt*(db: DbConn, user_id: string): string = 
  when dbEngine == "postgres":
    db.getRow(sql"SELECT salt FROM users WHERE id = ?;", user_id)[0]
  else: {.warning: "getUserSalt() unimplemented".}

proc getUserPass*(db: DbConn, user_id: string): string = 
  when dbEngine == "postgres":
    db.getRow(sql"SELECT pass FROM users WHERE id = ?;", user_id)[0]
  else: {.warning: "getUserPass() unimplemented".}

proc userHasRole*(db: DbConn, user_id: string, role: int): bool =
  when dbEngine == "postgres":
    db.getRow(
      sql"SELECT EXISTS(SELECT 0 FROM users WHERE roles @> ? AND id = ?);",
      !$[role], user_id
    )[0] == "t"
  else: {.warning: "userHasRole() unimplemented".}

proc isAdmin*(db: DbConn, user_id: string): bool
  {.deprecated: "Use userHasRole and roles.txt in docs/".} =
  when dbEngine == "postgres":
    db.userHasRole(user_id, 3)
  else: {.warning: "isAdmin() unimplemented".}
  
proc isModerator*(db: DbConn, user_id: string): bool 
  {.deprecated: "Use userHasRole and roles.txt in docs/".} =
  when dbEngine == "postgres":
    db.userHasRole(user_id, 2)
  else: {.warning: "isModerator() unimplemented".}

proc userFrozen*(db: DbConn, user_id: string): bool
  {.deprecated: "Use userHasRole and roles.txt in docs/".} =
  ## Returns whether or not a user is frozen. ID must be a user id.
  when dbEngine == "postgres":
    db.userHasRole(user_id, -1)
  else: {.warning: "userFrozen() unimplemented".}

proc userApproved*(db: DbConn, user_id: string): bool
  {.deprecated: "Use userHasRole and roles.txt in docs/".} =
  ## Returns whether or not a user is approved. ID must be a user id.
  when dbEngine == "postgres":
    db.userHasRole(user_id, 1)
  else: {.warning: "userApproved() unimplemented".}
  
proc getUserKDF*(db: DbConn, user_id: string): KDF =
  ## Return the KDF of a user
  when dbEngine == "postgres":
    toKDF(db.getRow(sql"SELECT kdf FROM users WHERE id = ?;", user_id)[0])
  else: {.warning: "getUserKDF() unimplemented".}

proc constructUserFromRow*(row: Row): User =
  ## A procedure that takes a database Row (From the users table)
  ## And turns it into a User object, ready for processing.
  ## It unescapes users by default

  # This looks ugly, I know, I had to wrap it with
  # two specific functions but we don't have to re-write this
  # even if we add new things to the User object. EXCEPT!
  # if we introduce new data types to the User object
  when dbEngine == "postgres":
    var i: int = -1;
  
    for key,value in result.fieldPairs:
      inc(i)
      # If its string, add it surrounding quotes
      # Otherwise add it whole
      when result.get(key) is bool:
        result.get(key) = (row[i] == "t")
      when result.get(key) is string:
        result.get(key) = row[i]
      when result.get(key) is int:
        result.get(key) = parseInt(row[i])
      when result.get(key) is seq[int]:
        result.get(key) = toIntSeq(row[i])
      when result.get(key) is KDF:
        result.get(key) = toKdf(row[i])
  else: {.warning: "constructUserFromRow() unimplemented".}

proc userVerified*(db: DbConn, user_id: string): bool =
  ## Returns whether or not a user has a verifd email address. ID must be a user id.
  when dbEngine == "postgres":
    db.getRow(sql"SELECT email_verified FROM users WHERE id = ?;", user_id)[0] == "t"
  else: {.warning: "userVerified() unimplemented".}

proc getFirstAdmin*(db: DbConn): string =
  ## Returns the ID of a single (no special order) administrator.
  when dbEngine == "postgres":
    db.getRow(sql"SELECT id FROM users WHERE roles @> '{3}' LIMIT 1;")[0]
  else: {.warning: "getFirstAdmin() unimplemented".}

proc adminExists*(db: DbConn): bool =
  ## Returns whether or not an account with administrator privileges exists at all.
  when dbEngine == "postgres":
    db.getRow(sql"SELECT EXISTS(SELECT 0 FROM users WHERE roles @> '{3}');")[0] == "t"
  else: {.warning: "adminExists() unimplemented".}

proc getUserBio*(db: DbConn, id: string): string = 
  ## Retrieve the biography of a user
  when dbEngine == "postgres":
    db.getRow(sql"SELECT bio FROM users WHERE id = ?;", id)[0]
  else: {.warning: "getUserBio() unimplemented".}

proc getUserById*(db: DbConn, id: string): User =
  ## Retrieve a user from the database using their id
  ## This procedure returns a fully unescaped user, you do not need to do anything to it.
  ## This procedure expects a regular ID, it will sanitize and escape it by default.
  when dbEngine == "postgres":
    constructUserFromRow(db.getRow(sql"SELECT * FROM users WHERE id = ?;", id))
  else: {.warning: "getUserById() unimplemented".}

proc getUserByHandle*(db: DbConn, handle: string, domain = ""): User =
  ## Retrieve a user from the database using their handle
  ## This procedure returns a fully unescaped user, you do not need to do anything to it.
  ## This procedure expects a regular handle, it will sanitize and escape it by default.
  when dbEngine == "postgres":
    constructUserFromRow(db.getRow(sql"SELECT * FROM users WHERE handle = ? AND domain = ?;", handle, domain))
  else: {.warning: "getUserByHandle() unimplemented".}

proc updateUserById*(db: DbConn, id, column, value: string) = 
  ## A procedure to update any user (The user is identified by their ID)
  when dbEngine == "postgres":
    db.exec(sql("UPDATE users SET " & column & " = ? WHERE id = ?;"), value, id)
  else: {.warning: "updateUserById() unimplemented".}

proc getIdFromHandle*(db: DbConn, handle: string, domain = ""): string =
  ## A function to convert a user handle to an id.
  ## This procedure expects a regular handle, it will sanitize and escape it by default.
  when dbEngine == "postgres":
    db.getRow(sql"SELECT id FROM users WHERE handle = ? AND domain = ?;", handle, domain)[0]
  else: {.warning: "getIdFromHandle() unimplemented".}

proc getHandleFromId*(db: DbConn, id: string): string =
  ## A function to convert a  id to a handle.
  ## This procedure expects a regular ID, it will sanitize and escape it by default.
  when dbEngine == "postgres":
    db.getRow(sql"SELECT handle FROM users WHERE id = ?;", id)[0]
  else: {.warning: "getHandleFromId() unimplemented".}

proc getUserDisplay*(db: DbConn, id: string): string =
  ## A function to retrieve a user's display name.
  ## This procedure expects a regular ID, it will sanitize and escape it by default.
  when dbEngine == "postgres":
    db.getRow(sql"SELECT display FROM users WHERE id = ?;", id)[0]
  else: {.warning: "getHandleFromId() unimplemented".}

proc deleteUser*(db: DbConn, id: string) =
  ## Deletes a user and marks their visible content as null.
  ## You don't need to do anything before running this proc.
  # TODO: This is just too much all at once... But it'll be alright... right?
  # Delete stuff no one will ever see
  when dbEngine == "postgres":
    db.exec(sql"DELETE FROM auth_codes WHERE uid = ?;", id)
    db.exec(sql"DELETE FROM email_codes WHERE uid = ?;", id)
    db.exec(sql"DELETE FROM fields WHERE uid = ?;", id)
    db.exec(sql"DELETE FROM tag_follows WHERE follower = ?;", id)
    db.exec(sql"DELETE FROM user_follows WHERE follower = ?;", id)
    db.exec(sql"DELETE FROM user_follows WHERE following = ?;", id)

    # For the stuff we suspect to be heavy, we will just
    # mark the user's data as "null" and it'll all be deleted at some point later.
    db.exec(sql"UPDATE oauth_tokens SET uid = '00000000-0000-0000-0000-000000000000' WHERE uid = ?;", id)
    db.exec(sql"UPDATE logins SET uid = '00000000-0000-0000-0000-000000000000' WHERE uid = ?;", id)
    db.exec(sql"UPDATE reactions SET uid = '00000000-0000-0000-0000-000000000000' WHERE uid = ?;", id)
    db.exec(sql"UPDATE boosts SET uid = '00000000-0000-0000-0000-000000000000' WHERE uid = ?;", id)
    db.exec(sql"UPDATE bookmarks SET uid = '00000000-0000-0000-0000-000000000000' WHERE uid = ?;", id)
    db.exec(sql"UPDATE posts SET sender = '00000000-0000-0000-0000-000000000000' WHERE sender = ?;", id)

    # Finally delete the user
    db.exec(sql"DELETE FROM users WHERE id = ?;", id)
  else: {.warning: "deleteUser() unimplemented".}