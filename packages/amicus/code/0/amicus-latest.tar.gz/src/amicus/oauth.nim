# Copyright © penguinite 2024-2025 <penguinite@tuta.io>
#
# This file is part of Onbox. Specifically, the Quark repository.
# 
# Onbox is free software: you can redistribute it and/or modify it under the terms of
# the GNU Affero General Public License as published by the Free Software Foundation,
# either version 3 of the License, or (at your option) any later version.
# 
# Onbox is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License
# for more details.
# 
# You should have received a copy of the GNU Affero General Public License
# along with Onbox. If not, see <https://www.gnu.org/licenses/>. 
import shared, db_connector/db_postgres, apps, private/strconv

## This module contains all database logic for handling oauth tokens.

proc tokenExists*(db: DbConn, id: string): bool =
  when dbEngine == "postgres":
    db.getRow(
      sql"SELECT EXISTS(SELECT 0 FROM oauth_tokens WHERE id = ?);", id
    )[0] == "t"
  else: {.warning: "tokenExists() unimplemented".}

proc createToken*(db: DbConn, client, user: string, scopes: openArray[string]): string =
  result = randstr(32)
  when dbEngine == "postgres":
    db.exec(
      sql"INSERT INTO oauth_tokens VALUES (?,?,?,?);",
      result, client, user, !$scopes
    )
  else: {.warning: "createToken() unimplemented".}

proc getTokenUser*(db: DbConn, id: string): string =
  ## Returns ID of the user associated with a token.
  ## If this is empty, then there is no user associated with a token
  when dbEngine == "postgres":
    db.getRow(sql"SELECT uid FROM oauth_tokens WHERE id = ?;", id)[0]
  else: {.warning: "getTokenUser() unimplemented".}

proc getTokenApp*(db: DbConn, id: string): string =
  ## Returns ID of the app associated with a token.
  ## If this is empty, then there is no app associated with this token
  ## (heartbreaking, I know.)
  when dbEngine == "postgres":
    db.getRow(sql"SELECT cid FROM oauth_tokens WHERE id = ?;", id)[0]
  else: {.warning: "getTokenApp() unimplemented".}

proc getTokenScopes*(db: DbConn, id: string): seq[string] =
  ## Returns the list of scopes that a token has access to.
  ## Use this for verifying permissions requested by a token app client.
  when dbEngine == "postgres":
    toStrSeq(db.getRow(sql"SELECT scopes FROM oauth_tokens WHERE id = ?;", id)[0])
  else: {.warning: "getTokenScopes() unimplemented".}

proc deleteOAuthToken*(db: DbConn, id: string) =
  ## Deletes an oauth token from the db. Forcing the app to regenerate it.
  when dbEngine == "postgres":
    db.exec(sql"DELETE FROM oauth_tokens WHERE id = ?;", id)
  else: {.warning: "deleteOAuthToken() unimplemented".}

proc tokenHasScope*(db: DbConn, id:string, scope: string): bool =
  ## Checks if an app has a scope (or its parent scope)
  let start = scope.getBroadScope()

  for tokenScope in db.getTokenScopes(id):
    if tokenScope == scope or tokenScope == start:
      result = true
      break

# TODO: Consider implement a "last_used" attribute
# to clean up old oauth tokens.
# Or, maybe we could consider oauth tokens to be the same as apps.
# Which is to say, they last forever.
# But also, we *could* delete them...
# We could just delete them every month or so, and have apps regenerate them.
# or provide an onboxctl command to delete oauth tokens