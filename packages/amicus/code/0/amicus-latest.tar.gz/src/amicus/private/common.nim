## This module implements the "Multiple db engine support in one build." proposal
##
import std/[locks, tables, strtabs]
from sqlite3_wrap import Sqlite3, Stmt
from postgres_wrap import PGConn

type
  ADbType* {.pure.} = enum ## The specific database engine used for this connection. Postgres is currently the only supported type.
    Postgres, Sqlite

  DbError* = object of CatchableError

  AmicusDb* = ref object ## Amicus uses this object to abstract away different database engines all into one object.
    case kind*: ADbType
    of ADbType.Sqlite:
      sql3*: sqlite3_wrap.Sqlite3
      sql3cache*: Table[string, sqlite3_wrap.Stmt]
    of AdbType.Postgres:
      pq*: postgres_wrap.PGConn
      pqcache*: StringTableRef

  AmicusDbPoolObj = object
    cond: Cond
    lock: Lock
    conns: seq[AmicusDb]

  AmicusDbPool* = ptr AmicusDbPoolObj

proc borrow*(p: AmicusDbPool): AmicusDb {.raises: [], gcsafe.} =
  withLock(p.lock):
    while len(p.conns) == 0:
      wait(p.cond, p.lock)
    result = pop(p.conns)

proc recycle*(p: AmicusDbPool, h: AmicusDb) {.raises: [], gcsafe.} =
  withLock(p.lock):
    p.conns.add(h)
  signal(p.cond)

template withDb*(p: AmicusDbPool, h, body) =
  block:
    let h = borrow(p)
    try:
      body
    finally:
      p.recycle(h)

proc newDbError*(msg: string): ref DbError = 
  newException(DbError, msg)

proc getDbEngine*(db: AmicusDb): ADbType =
  return db.kind