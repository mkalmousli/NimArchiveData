## Wraps over sqlite3_wrap.nim and provides easy-to-use functions.
## Heavily based off of tiny_sqlite (Because it has a nice API)
## Compared to tiny_sqlite, this is missing a lot of features.
## The most important thing, performance-wise, is this interface has no
## support for prepared statements and the statement cache.
## Those two features might be worth looking into, especially
## the statement cache since it's a drop-in performance boost
import common, sqlite3_wrap, std/tables
type
  SqliteDbValueKind* = enum
    SQL3Text, SQL3Integer, SQL3Blob, SQL3Float, SQL3Null

  SqliteDbValue* = object
    case kind*: SqliteDbValueKind
    of SQL3Text: strVal*: string
    of SQL3Blob: blobVal*: seq[byte]
    of SQL3Integer: intVal*: int64
    of SQL3Float: floatVal*: float64
    of SQL3Null: nil

  SqliteRow* = seq[SqliteDbValue]

# Generics boilerplate to autoconvert every value into a SqliteDbValue object
proc toSqliteDbValue*[T: SomeInteger](v: T): SqliteDbValue =
  SqliteDbValue(kind: SQL3Integer, intVal: int64(v))
proc toSqliteDbValue*[T: SomeFloat](v: T): SqliteDbValue =
  SqliteDbValue(kind: SQL3Float, floatVal: v)
proc toSqliteDbValue*[T: string](v: T): SqliteDbValue =
  SqliteDbValue(kind: SQL3Text, strVal: v)
proc toSqliteDbValue*[T: seq[byte]](v: T): SqliteDbValue =
  SqliteDbValue(kind: SQL3Blob, blobVal: v)
proc toSqliteDbValue*[T: type(nil)](v: T): SqliteDbValue =
  SqliteDbValue(kind: SQL3Null)

# More boilerplate! This time, we're doing comparison operators!

proc `==`*(a, b: SqliteDbValue): bool =
  if a.kind != b.kind: return false
  case a.kind:
  of SQL3Text: return a.strVal == b.strVal
  of SQL3Integer: return a.intVal == b.intVal
  of SQL3Blob: return a.blobVal == b.blobVal
  of SQL3Float: return a.floatVal == b.floatVal
  of SQL3Null: return a == b

proc `==`*(a: SqliteDbValue, b: SomeInteger): bool =
  return (a.kind == SQL3Integer) and (a.intVal == b)
proc `==`*(a: SqliteDbValue, b: SomeFloat): bool =
  return (a.kind == SQL3Float) and (a.floatVal == b)
proc `==`*(a: SqliteDbValue, b: string): bool =
  return (a.kind == SQL3Text) and (a.strVal == b)
proc `==`*(a: SqliteDbValue, b: seq[byte]): bool =
  return (a.kind == SQL3Blob) and (a.blobVal == b)
proc `==`*(a: SqliteDbValue, b: type(nil)): bool =
  return (a.kind == SQL3Null) and (a == b)

proc newDbError(h: AmicusDb): ref DbError = 
  newException(DbError, "sqlite error: " & $(errmsg(h[].sql3)))
proc newDbError(h: Sqlite3): ref DbError = 
  newException(DbError, "sqlite error: " & $(errmsg(h)))

# Even more boilerplate!
# Now we're doing the statement cache.
#[
  The statement cache is a field within the AmicusDb
  object. It's used behind the scenes by the database interface
  to speed up converting the query to bytecode.
  The performance benefits are probably negligible as it skips
  past a single prepare_v2() call.
]#

proc prepare(h: AmicusDb, query: string, params: varargs[SqliteDbValue, toSqliteDbValue]): Stmt =
  ## Used internally to convert a query into sqlite bytecode.
  
  # A bit ugly
  # Check if stmt was in cache beforehand.
  if h.sql3cache.hasKey(query):
    result = h.sql3cache[query]
  else:
    if prepare_v2(h.sql3, cstring(query), cint(query.len + 1), result, nil) != SQLITE_OK:
      raise newDbError(h)
    h.sql3cache[query] = result

  var i: int32 = 1
  for v in params:
    var rc: int32
    case v.kind:
    of SQL3Text: rc = bind_text(result, i, cstring(v.strVal), int32(len(v.strVal)), SQLITE_TRANSIENT)
    of SQL3Blob: rc = bind_blob(result, i, cstring(cast[string](v.blobVal)), int32(len(v.blobVal)), SQLITE_TRANSIENT)
    of SQL3Integer: rc = bind_int64(result, i, v.intVal)
    of SQL3Float: rc = bind_double(result, i, v.floatVal) 
    of SQL3Null: rc = bind_null(result, i)
    if rc != SQLITE_OK: raise newDbError(h)
    inc(i)
  
proc exec*(h: AmicusDb, query: string, params: varargs[SqliteDbValue, toSqliteDbValue]) =
  ## Executes a single SQL query.
  ## 
  ## Parameter substitution can be done with the question mark symbol.
  ## And only one instruction will be executed, if there are multiple in a line
  ## then the rest will be skipped.
  var stmtVar = h.prepare(query, params)
  if step(stmtVar) notin [SQLITE_DONE, SQLITE_OK, sqlite3_wrap.SQLITE_ROW]:
    raise newDbError(h)
  if reset(stmtVar) != SQLITE_OK:
    h.sql3cache[query] = nil

proc parseSqliteRow(stmtVar: Stmt): SqliteRow =
  ## Parses a proper SqliteRow out of a Stmt object that has finished executing.
  ## 
  result = newSeq[SqliteDbValue](column_count(stmtVar))
  for i in 0 ..< column_count(stmtVar):
    case column_type(stmtVar, i):
    of SQLITE_TEXT: result[i] = toSqliteDbValue($(column_text(stmtVar, i)))
    of SQLITE_INTEGER: result[i] = toSqliteDbValue(column_int64(stmtVar, i))
    of SQLITE_FLOAT: result[i] = toSqliteDbValue(column_double(stmtVar, i))
    of SQLITE_NULL: result[i] = toSqliteDbValue(nil)
    of SQLITE_BLOB:
      let bytes = column_bytes(stmtVar, i)
      var value = newSeq[byte](bytes)
      if bytes != 0: copyMem(addr(value[0]), column_blob(stmtVar, i), bytes)
      result[i] = toSqliteDbValue(value)
    else: raise newDbError("Unknown datatype")

iterator iterate*(h: AmicusDb, query: string, params: varargs[SqliteDbValue, toSqliteDbValue]): SqliteRow =
  var stmtVar = h.prepare(query, params)
  try:
    while true:
      case step(stmtVar):
      of SQLITE_OK, SQLITE_DONE: break
      of sqlite3_wrap.SQLITE_ROW: yield parseSqliteRow(stmtVar)
      else:
        # Reset stmt before returning error.
        let x = newDbError(h)
        if reset(stmtVar) != SQLITE_OK:
          h.sql3cache[query] = nil
        raise x
  finally:
    if reset(stmtVar) != SQLITE_OK:
      h.sql3cache[query] = nil

proc one*(h: AmicusDb, query: string, params: varargs[SqliteDbValue, toSqliteDbValue]): SqliteRow =
  ## Returns a single row.
  for row in h.iterate(query, params):
    return row

proc all*(h: AmicusDb, query: string, params: varargs[SqliteDbValue, toSqliteDbValue]): seq[SqliteRow] =
  ## Returns multiple rows.
  ## 
  ## If you're iterating then it's best to use the provided `iterate` for a slight performance boost.
  for row in h.iterate(query, params):
    result.add row

proc openSqlite*(fn: string): AmicusDb =
  var pSql: Sqlite3
  if open(cstring(fn), pSql) != SQLITE_OK:
    raise newDbError(pSql)
  
  result = AmicusDb(
    kind: ADbType.Sqlite,
    sql3: pSql,
    sql3cache: initTable[string, Stmt]()
  )

  result.exec("PRAGMA foreign_keys = ON;")

proc closeSqlite*(h: AmicusDb) =
  if h[].sql3.isNil() or h.isNil():
    return

  # Loop over every Statement in the cache
  # and free it.
  for s in h.sql3cache.keys:
    if finalize(h.sql3cache[s]) != SQLITE_OK:
      raise newDbError(h)

  if close_v2(h[].sql3) != SQLITE_OK:
    raise newDbError(h)
  h[].sql3 = nil

proc newSqlitePool*(size: int, fn: string): AmicusDbPool =
  ## Creates a new thread-safe pool.
  result = cast[AmicusDbPool](allocShared(sizeof(AmicusDbPoolObj)))
  initLock(result.lock)
  initCond(result.cond)
  for _ in 0 ..< size:
    result.recycle(openSqlite(fn))
  return result

proc closeSqlitePool*(p: AmicusDbPool) {.raises: [].} =
  for db in p.conns:
    try: db.closeSqlite()
    except: discard
  deinitLock(p.lock)
  deinitCond(p.cond)
  `=destroy`(p[])
  deallocShared(p)