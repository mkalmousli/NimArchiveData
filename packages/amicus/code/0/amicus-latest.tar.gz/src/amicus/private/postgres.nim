## Sqlite database interface
## Wraps over sqlite3_wrap.nim and provides easier-to-use functions.
## 
## Heavily based off of tiny_sqlite
## (Because it has a nice API)
## 
## Compared to tiny_sqlite, this is missing a lot of features.
## The most important thing, performance-wise, is this interface has no
## support for prepared statements and the statement cache.
##
## Those two features might be worth looking into, especially
## the statement cache since it's a drop-in performance enhancement
## feature.

import common, postgres_wrap, std/[times, strtabs]

type
  #PostgresDbValueKind* = enum
  #  PQBool, PQSmallInt, PQInt, PQBigInt, PQText, PQTimestamp, PQArray, PQNull
  
  # Contains the string representation to be used in exec()
  PGValRep* = object
    str: string
    n: bool # True if nil value 

  #PostgresRow* = seq[PostgresDbValue]

# Through the power of generics!
# I will automate the conversion of object to Postgres's
# network text representation!
template `!$`*[T: bool](v: T): PGValRep = PGValRep(str: $v, n: false)
template `!$`*[T: SomeInteger](v: T): PGValRep = PGValRep(str: $v, n: false)
template `!$`*[T: string](v: T): PGValRep = PGValRep(str: v, n: false)
template `!$`*[T: type(nil)](v: T): PGValRep = PGValRep(str: "", n: true)
template `!$`*[T: DateTime](v: T): PGValRep =
  PGValRep(str: format(v, "yyyy-MM-dd HH:mm:ss"), n: false)

proc allocParamValues(a: varargs[PGValRep]): cstringArray =
  result = cast[cstringArray](alloc0((a.len+1) * sizeof(cstring)))
  var i = -1
  for val in a:
    inc i
    if val.n:
      # Literally set to null
      result[i] = nil
    else:
      result[i] = cast[cstring](alloc0(len(val.str) + 1))
      copyMem(result[i], cstring(val.str), len(val.str))

proc deallocParamValues(a: cstringArray, l: int) =
  var i = 0
  while i < l:
    dealloc(a[i])
    inc(i)
  dealloc(a)

func basicEscape(s: PGValRep): string =
  # Used for escaping strings in an array
  for ch in s.str:
    case ch:
    of '\\', ',', '"': result.add "\\" & ch
    else: result.add ch
  return "\"" & result & "\","

proc `!$`*[T](v: openArray[T]): PGValRep =
  when T is type(nil):
    return PGValRep(str: "", n: true)
  else:
    result = PGValRep(str: "", n: false)
    for i in v:
      result.str.add(basicEscape(!$i))
    result.str = result.str[0..^2] # Remove last comma
    result.str = "{" & result.str & "}"


#[
  NULL values are a bit weird in postgres.
  They require literally that we have a "NULL"
  as in, in the actual cstringArray...
  The only way we can get away with this is if we allocate
  and deallocate our own cstringArray.
]#

proc closePostgres*(h: AmicusDb) =
  if isNil(h[].pq) or isNil(h):
    return
  pqfinish(h[].pq)

proc closePostgres(h: PGConn) =
  if isNil(h):
    return
  pqfinish(h)

proc newDbError(h: AmicusDb): ref DbError =
  return newException(DbError, $pqErrorMessage(h[].pq))

proc newDbError(h: PGConn): ref DbError =
  return newException(DbError, $pqErrorMessage(h))

proc openPostgres*(host, port, user, pass, name: string): AmicusDb =
  ## Creates a new postgres database connection using `PQsetdbLogin`
  ## 
  ## Leave port empty if its not needed.
  var h = pqsetdbLogin(
    cstring(host), cstring(port),
    nil, nil,
    name, user,
    pass
  )
  
  if pqStatus(h) != CONNECTION_OK:
    try:
      raise newDbError(h)
    finally:
      # Free memory used for connection
      closePostgres(h)
  
  result = AmicusDb(
    kind: ADbType.Postgres,
    pq: h,
    pqcache: newStringTable()
  )

#[
  Game plan for executing queries:
  For a near drop-in boost in performance, we could create a statement cache.
  Prepared statements in postgres are referred to by name, which poses an interesting problem.

  We *could* devise a sort of algorithm that gives sensible names to prepared statements
  just from the query string alone. That's the approach I've taken.
  Anyway, when a statement is prepared, and properly cached,
  we simply pass it on with the correct parameters to PQexecPrepared.

  In theory this should not only speed up the parsing process but also the type determination process.
]#

proc queryToStmtName(query: string): string =
  for ch in query:
    if ch in {'a'..'z','A'..'Z','0'..'9'}:
      result.add ch

proc getCachedQuery(db: AmicusDb, query: string): string =
  ## Retrieves a cached query, creating it and caching it
  ## if it doesn't exist.
  # It does seem rather wasteful to use a string table
  # but whatever...
  result = queryToStmtName(query)
  if not db[].pqcache.hasKey(query):
    let rsPrepare = pqprepare(
      db[].pq,
      cstring(result),
      cstring(query),
      cint(len(params)),
      nil, # Let postgres automatically deduce types
    )
    try:
      if isNil(rsPrepare) or pqresultstatus(rsPrepare) != PGRES_COMMAND_OK:
        raise newDbError(db)
    finally:
      pqclear(rsPrepare)
    db[].pqcache[query] = result

proc exec*(db: AmicusDb, query: string, params: varargs[PGValRep, `!$`]) =
  let stmtName = db.getCachedQuery(query)

  var paramValues: cstringArray = nil
  if len(params) > 0:
    paramValues = allocParamValues(params)
  
  rs = pqexecprepared(
    db[].pq,
    stmtName,
    int32(len(params)),
    paramValues,
    nil, # paramLength: No need since we use text mode
    nil, # paramFormats: No need since the default is text either way
    int32(0) # Retrieve results in text
  )
  
  if not isNil(paramValues):
    deallocParamValues(paramValues, len(params))

  if isNil(rs) or pqresultstatus(rs) notin [PGRES_COMMAND_OK, PGRES_TUPLES_OK]:
    let x = newDbError(db)
    pqclear(rs)
    raise x
  pqclear(rs)

#[
  TODO: To implement iterate*
  Implementing iterate can be done by using pqsendqueryprepared() instead of pqexecprepared()
  and by running a couple more procedures to set single row mode.
  Then after all that, we can fetch each row one by one and process it.
  (PS: Look into instantRows* iterator from db_connector/db_postgres)
]#

type
  PostgresRowKind* = enum
    PQInt, PQText, PQBool, PQDate, PQArray

  PostgresRowEntry* = object
    case kind*: PostgresRowKind
    of PQInt:
      intVal*: int64
    of PQText:
      strVal*: string
    of PQBool
      boolVal*: bool
    of PQDate:
      dateVal*: DateTime
    of PQArray:
      arrayVal*: seq[PostgresRowEntry]
  
  PostgresRow* = seq[PostgresRowEntry]

iterator iterate*(db: AmicusDb, query: string, params: varargs[PGValRep, `!$`]): PostgresRow =
  ## Running a query in the middle of this iterator might be unsupported.
  ## Use `all()` in that case. 
  let stmtName = db.getCachedQuery(query)

  var paramValues: cstringArray = nil
  if len(params) > 0:
    paramValues = allocParamValues(params)
  
  if pqsendqueryprepared(db[].pq, stmtName, int32(len(params)), paramValues, nil, nil, int32(0)) != 1 or pqsetsinglerowmode(db) != 1:
    if len(params) > 0:  
      deallocParamValues(paramValues, len(params))
    raise newDbError(db)
  
  if len(params) > 0:  
    deallocParamValues(paramValues, len(params))
  
  var rs: PGresult = nil
  try:
    while true:
      rs = pqgetresult(db[].pq)
      if isNil(rs):
        break
      
      let status = pqresultstatus(rs) 
      notin [PGRES_COMMAND_OK, PGRES_TUPLES_OK]
      if status != 

      pqclear(res)
  finally:
    if not isNil(rs):
      pqclear(rs)

proc one*(db: AmicusDb, query: string, params: varargs[PGValRep, `!$`]): PostgresRow=
  for row in db.iterate(query, params):
    return row

proc all*(db: AmicusDb, query: string, params: varargs[PGValRep, `!$`]): seq[PostgresRow] =
  for row in db.iterate(query, params):
    result.add row

