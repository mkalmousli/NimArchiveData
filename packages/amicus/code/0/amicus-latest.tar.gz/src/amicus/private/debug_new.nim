## Common procedures for debugging
when not defined(amicusDebug):
  {.error: "do not use".}

import ../amicus
export amicus

proc openDb*(): AmicusDb =
  when defined(amicusPostgres):
    return openPostgres("127.0.0.1", "5432", "onbox", "SOMETHING_SECRET", "onbox")
  else:
    return openSqlite("test.db")

proc closeDb*(db: AmicusDb): AmicusDb =
  when defined(amicusPostgres):
    closePostgres(db)
  else:
    closeSqlite(db)