
# This module contains the definitions for structures and externs for
# functions used by frontend postgres applications. It is based on
# Postgresql's libpq-fe.h.
#
# It is for postgreSQL version 7.4 and higher with support for the v3.0
# connection-protocol.
#

when defined(staticAmicus):
  # libpq has several indirect dependencies, such as
  # libssl and libcrypto and libldap.
  
  # Here we instruct the C compiler to literally statically compile
  # every dependency. This means we are forced to use musl as glibc
  # doesn't do well with static linking.
  # (But we already know that, and we already have a musl build script ready)
  {.warning: "Statically compiling libpq doesn't work completely.".}
  {.passc: "-static -optl-pthread -optl-static".}
  {.passc: gorge("pkg-config --cflags libpq").}
  {.passl: gorge("pkg-config --libs libpq").}
  {.pragma libpq, cdecl.}
else:
  when defined(windows):
    const lib = "libpq.dll"
  elif defined(macosx):
    const lib = "libpq.dylib"
  else:
    const lib = "libpq.so(.5|)"
  {.pragma: libpq, cdecl, dynlib: lib.}

const
  ERROR_MSG_LENGTH* = 4096
  CMDSTATUS_LEN* = 40

type
  Oid* = int32
  POid* = ptr Oid

  SockAddr* = array[1..112, int8]
  PGresAttDesc*{.pure, final.} = object
    name*: cstring
    adtid*: Oid
    adtsize*: int

  PPGresAttDesc* = ptr PGresAttDesc
  PPPGresAttDesc* = ptr PPGresAttDesc
  PGresAttValue*{.pure, final.} = object
    length*: int32
    value*: cstring

  PPGresAttValue* = ptr PGresAttValue
  PPPGresAttValue* = ptr PPGresAttValue
  PExecStatusType* = ptr ExecStatusType
  ExecStatusType* = enum
    PGRES_EMPTY_QUERY = 0, PGRES_COMMAND_OK, PGRES_TUPLES_OK, PGRES_COPY_OUT,
    PGRES_COPY_IN, PGRES_BAD_RESPONSE, PGRES_NONFATAL_ERROR, PGRES_FATAL_ERROR,
    PGRES_COPY_BOTH, PGRES_SINGLE_TUPLE
  PGlobjfuncs*{.pure, final.} = object
    fn_lo_open*: Oid
    fn_lo_close*: Oid
    fn_lo_creat*: Oid
    fn_lo_unlink*: Oid
    fn_lo_lseek*: Oid
    fn_lo_tell*: Oid
    fn_lo_read*: Oid
    fn_lo_write*: Oid

  PPGlobjfuncs* = ptr PGlobjfuncs
  PConnStatusType* = ptr ConnStatusType
  ConnStatusType* = enum
    CONNECTION_OK, CONNECTION_BAD, CONNECTION_STARTED, CONNECTION_MADE,
    CONNECTION_AWAITING_RESPONSE, CONNECTION_AUTH_OK, CONNECTION_SETENV,
    CONNECTION_SSL_STARTUP, CONNECTION_NEEDED, CONNECTION_CHECK_WRITABLE,
    CONNECTION_CONSUME, CONNECTION_GSS_STARTUP, CONNECTION_CHECK_TARGET
  
  PGConnObj = object
    pghost*: cstring
    pgtty*: cstring
    pgport*: cstring
    pgoptions*: cstring
    dbName*: cstring
    status*: ConnStatusType
    errorMessage*: array[0..(ERROR_MSG_LENGTH) - 1, char]
    Pfin*: File
    Pfout*: File
    Pfdebug*: File
    sock*: int32
    laddr*: SockAddr
    raddr*: SockAddr
    salt*: array[0..(2) - 1, char]
    asyncNotifyWaiting*: int32
    notifyList*: pointer
    pguser*: cstring
    pgpass*: cstring
    lobjfuncs*: PPGlobjfuncs
  PGConn* = ptr PGconnObj

  PGresultObj = object
    ntups*: int32
    numAttributes*: int32
    attDescs*: PPGresAttDesc
    tuples*: PPPGresAttValue
    tupArrSize*: int32
    resultStatus*: ExecStatusType
    cmdStatus*: array[0..(CMDSTATUS_LEN) - 1, char]
    binary*: int32
    conn*: PGConn
  PGresult* = ptr PGresultObj

  PPostgresPollingStatusType* = ptr PostgresPollingStatusType
  PostgresPollingStatusType* = enum
    PGRES_POLLING_FAILED = 0, PGRES_POLLING_READING, PGRES_POLLING_WRITING,
    PGRES_POLLING_OK, PGRES_POLLING_ACTIVE
  PPGTransactionStatusType* = ptr PGTransactionStatusType
  PGTransactionStatusType* = enum
    PQTRANS_IDLE, PQTRANS_ACTIVE, PQTRANS_INTRANS, PQTRANS_INERROR,
    PQTRANS_UNKNOWN
  PPGVerbosity* = ptr PGVerbosity
  PGVerbosity* = enum
    PQERRORS_TERSE, PQERRORS_DEFAULT, PQERRORS_VERBOSE, PQERRORS_SQLSTATE
  PPGNotify* = ptr pgNotify
  pgNotify*{.pure, final.} = object
    relname*: cstring
    be_pid*: int32
    extra*: cstring

  PQnoticeReceiver* = proc (arg: pointer, res: PGresult){.cdecl.}
  PQnoticeProcessor* = proc (arg: pointer, message: cstring){.cdecl.}
  
  pqbool* = char
  Ppqbool* = ptr pqbool
  
  PQprintOpt* = object
    header*: pqbool
    align*: pqbool
    standard*: pqbool
    html3*: pqbool
    expanded*: pqbool
    pager*: pqbool
    fieldSep*: cstring
    tableOpt*: cstring
    caption*: cstring
    fieldName*: ptr cstring
  PPQprintOpt* = ptr PQprintOpt

  PQconninfoOption* = object
    keyword*: cstring
    envvar*: cstring
    compiled*: cstring
    val*: cstring
    label*: cstring
    dispchar*: cstring
    dispsize*: int32
  PPQconninfoOption* = ptr PQconninfoOption

  PQArgBlock* = object
    length*: int32
    isint*: int32
    p*: pointer
  PPQArgBlock* = ptr PQArgBlock

proc pqinitOpenSSL*(do_ssl: int32, do_crypto: int32) {.libpq, importc: "PQinitOpenSSL".}
proc pqconnectStart*(conninfo: cstring): PGConn{.libpq, importc: "PQconnectStart".}
proc pqconnectPoll*(conn: PGConn): PostgresPollingStatusType{.libpq, importc: "PQconnectPoll".}
proc pqconnectdb*(conninfo: cstring): PGConn{.libpq, importc: "PQconnectdb".}
proc pqsetdbLogin*(pghost: cstring, pgport: cstring, pgoptions: cstring, pgtty: cstring, dbName: cstring, login: cstring, pwd: cstring): PGConn{.libpq, importc: "PQsetdbLogin".}
proc pqsetdb*(M_PGHOST, M_PGPORT, M_PGOPT, M_PGTTY, M_DBNAME: cstring): PGConn
proc pqfinish*(conn: PGConn){.libpq, importc: "PQfinish".}
proc pqconndefaults*(): PPQconninfoOption{.libpq, importc: "PQconndefaults".}
proc pqconninfoFree*(connOptions: PPQconninfoOption){.libpq, importc: "PQconninfoFree".}
proc pqresetStart*(conn: PGConn): int32{.libpq, importc: "PQresetStart".}
proc pqresetPoll*(conn: PGConn): PostgresPollingStatusType{.libpq, importc: "PQresetPoll".}
proc pqreset*(conn: PGConn){.libpq, importc: "PQreset".}
proc pqrequestCancel*(conn: PGConn): int32{.libpq, importc: "PQrequestCancel".}
proc pqdb*(conn: PGConn): cstring{.libpq, importc: "PQdb".}
proc pquser*(conn: PGConn): cstring{.libpq, importc: "PQuser".}
proc pqpass*(conn: PGConn): cstring{.libpq, importc: "PQpass".}
proc pqhost*(conn: PGConn): cstring{.libpq, importc: "PQhost".}
proc pqport*(conn: PGConn): cstring{.libpq, importc: "PQport".}
proc pqtty*(conn: PGConn): cstring{.libpq, importc: "PQtty".}
proc pqoptions*(conn: PGConn): cstring{.libpq, importc: "PQoptions".}
proc pqstatus*(conn: PGConn): ConnStatusType{.libpq, importc: "PQstatus".}
proc pqtransactionStatus*(conn: PGConn): PGTransactionStatusType{.libpq, importc: "PQtransactionStatus".}
proc pqparameterStatus*(conn: PGConn, paramName: cstring): cstring{.libpq, importc: "PQparameterStatus".}
proc pqserverVersion*(conn: PGConn): int32{.libpq, importc: "PQserverVersion".}
proc pqprotocolVersion*(conn: PGConn): int32{.libpq, importc: "PQprotocolVersion".}
proc pqerrorMessage*(conn: PGConn): cstring{.libpq, importc: "PQerrorMessage".}
proc pqsocket*(conn: PGConn): int32{.libpq, importc: "PQsocket".}
proc pqbackendPID*(conn: PGConn): int32{.libpq, importc: "PQbackendPID".}
proc pqconnectionNeedsPassword*(conn: PGConn): int32{.libpq, importc: "PQconnectionNeedsPassword".}
proc pqconnectionUsedPassword*(conn: PGConn): int32{.libpq, importc: "PQconnectionUsedPassword".}
proc pqclientEncoding*(conn: PGConn): int32{.libpq, importc: "PQclientEncoding".}
proc pqsetClientEncoding*(conn: PGConn, encoding: cstring): int32{.libpq, importc: "PQsetClientEncoding".}
proc pqsetErrorVerbosity*(conn: PGConn, verbosity: PGVerbosity): PGVerbosity{.libpq, importc: "PQsetErrorVerbosity".}
proc pqtrace*(conn: PGConn, debug_port: File){.libpq, importc: "PQtrace".}
proc pquntrace*(conn: PGConn){.libpq, importc: "PQuntrace".}
proc pqsetNoticeReceiver*(conn: PGConn, theProc: PQnoticeReceiver, arg: pointer): PQnoticeReceiver{.libpq, importc: "PQsetNoticeReceiver".}
proc pqsetNoticeProcessor*(conn: PGConn, theProc: PQnoticeProcessor, arg: pointer): PQnoticeProcessor{.libpq, importc: "PQsetNoticeProcessor".}
proc pqexec*(conn: PGConn, query: cstring): PGresult{.libpq, importc: "PQexec".}
proc pqexecParams*(conn: PGConn, command: cstring, nParams: int32, paramTypes: POid, paramValues: cstringArray, paramLengths, paramFormats: ptr int32, resultFormat: int32): PGresult{.libpq, importc: "PQexecParams".}
proc pqprepare*(conn: PGConn, stmtName, query: cstring, nParams: int32, paramTypes: POid): PGresult{.libpq, importc: "PQprepare".}
proc pqexecPrepared*(conn: PGConn, stmtName: cstring, nParams: int32, paramValues: cstringArray, paramLengths, paramFormats: ptr int32, resultFormat: int32): PGresult{.libpq, importc: "PQexecPrepared".}
proc pqsendQuery*(conn: PGConn, query: cstring): int32{.libpq, importc: "PQsendQuery".}

## See also https://www.postgresql.org/docs/current/libpq-async.html
proc pqsendQueryParams*(conn: PGConn, command: cstring, nParams: int32, paramTypes: POid, paramValues: cstringArray, paramLengths, paramFormats: ptr int32, resultFormat: int32): int32{.libpq, importc: "PQsendQueryParams".}
proc pqsendQueryPrepared*(conn: PGConn, stmtName: cstring, nParams: int32, paramValues: cstringArray, paramLengths, paramFormats: ptr int32, resultFormat: int32): int32{.libpq, importc: "PQsendQueryPrepared".}

## See also https://www.postgresql.org/docs/current/libpq-single-row-mode.html
proc pqSetSingleRowMode*(conn: PGConn): int32{.libpq, importc: "PQsetSingleRowMode".}

proc pqgetResult*(conn: PGConn): PGresult{.libpq, importc: "PQgetResult".}
proc pqisBusy*(conn: PGConn): int32{.libpq, importc: "PQisBusy".}
proc pqconsumeInput*(conn: PGConn): int32{.libpq, importc: "PQconsumeInput".}
proc pqnotifies*(conn: PGConn): PPGNotify{.libpq, importc: "PQnotifies".}
proc pqputCopyData*(conn: PGConn, buffer: cstring, nbytes: int32): int32{.libpq, importc: "PQputCopyData".}
proc pqputCopyEnd*(conn: PGConn, errormsg: cstring): int32{.libpq, importc: "PQputCopyEnd".}
proc pqgetCopyData*(conn: PGConn, buffer: cstringArray, async: int32): int32{.libpq, importc: "PQgetCopyData".}
proc pqgetline*(conn: PGConn, str: cstring, len: int32): int32{.libpq, importc: "PQgetline".}
proc pqputline*(conn: PGConn, str: cstring): int32{.libpq, importc: "PQputline".}
proc pqgetlineAsync*(conn: PGConn, buffer: cstring, bufsize: int32): int32{.libpq, importc: "PQgetlineAsync".}
proc pqputnbytes*(conn: PGConn, buffer: cstring, nbytes: int32): int32{.libpq, importc: "PQputnbytes".}
proc pqendcopy*(conn: PGConn): int32{.libpq, importc: "PQendcopy".}
proc pqsetnonblocking*(conn: PGConn, arg: int32): int32{.libpq, importc: "PQsetnonblocking".}
proc pqisnonblocking*(conn: PGConn): int32{.libpq, importc: "PQisnonblocking".}
proc pqflush*(conn: PGConn): int32{.libpq, importc: "PQflush".}
proc pqfn*(conn: PGConn, fnid: int32, result_buf, result_len: ptr int32, result_is_int: int32, args: PPQArgBlock, nargs: int32): PGresult{.libpq, importc: "PQfn".}
proc pqresultStatus*(res: PGresult): ExecStatusType{.libpq, importc: "PQresultStatus".}
proc pqresStatus*(status: ExecStatusType): cstring{.libpq, importc: "PQresStatus".}
proc pqresultErrorMessage*(res: PGresult): cstring{.libpq, importc: "PQresultErrorMessage".}
proc pqresultErrorField*(res: PGresult, fieldcode: int32): cstring{.libpq, importc: "PQresultErrorField".}
proc pqntuples*(res: PGresult): int32{.libpq, importc: "PQntuples".}
proc pqnfields*(res: PGresult): int32{.libpq, importc: "PQnfields".}
proc pqbinaryTuples*(res: PGresult): int32{.libpq, importc: "PQbinaryTuples".}
proc pqfname*(res: PGresult, field_num: int32): cstring{.libpq, importc: "PQfname".}
proc pqfnumber*(res: PGresult, field_name: cstring): int32{.libpq, importc: "PQfnumber".}
proc pqftable*(res: PGresult, field_num: int32): Oid{.libpq, importc: "PQftable".}
proc pqftablecol*(res: PGresult, field_num: int32): int32{.libpq, importc: "PQftablecol".}
proc pqfformat*(res: PGresult, field_num: int32): int32{.libpq, importc: "PQfformat".}
proc pqftype*(res: PGresult, field_num: int32): Oid{.libpq, importc: "PQftype".}
proc pqfsize*(res: PGresult, field_num: int32): int32{.libpq, importc: "PQfsize".}
proc pqfmod*(res: PGresult, field_num: int32): int32{.libpq, importc: "PQfmod".}
proc pqcmdStatus*(res: PGresult): cstring{.libpq, importc: "PQcmdStatus".}
proc pqoidStatus*(res: PGresult): cstring{.libpq, importc: "PQoidStatus".}
proc pqoidValue*(res: PGresult): Oid{.libpq, importc: "PQoidValue".}
proc pqcmdTuples*(res: PGresult): cstring{.libpq, importc: "PQcmdTuples".}
proc pqgetvalue*(res: PGresult, tup_num: int32, field_num: int32): cstring{.libpq, importc: "PQgetvalue".}
proc pqgetlength*(res: PGresult, tup_num: int32, field_num: int32): int32{.libpq, importc: "PQgetlength".}
proc pqgetisnull*(res: PGresult, tup_num: int32, field_num: int32): int32{.libpq, importc: "PQgetisnull".}
proc pqclear*(res: PGresult){.libpq, importc: "PQclear".}
proc pqfreemem*(p: pointer){.libpq, importc: "PQfreemem".}
proc pqmakeEmptyPGresult*(conn: PGConn, status: ExecStatusType): PGresult{.libpq, importc: "PQmakeEmptyPGresult".}
proc pqescapeString*(till, `from`: cstring, len: int): int{.libpq, importc: "PQescapeString".}
proc pqescapeBytea*(bintext: cstring, binlen: int, bytealen: var int): cstring{.libpq, importc: "PQescapeBytea".}
proc pqunescapeBytea*(strtext: cstring, retbuflen: var int): cstring{.libpq, importc: "PQunescapeBytea".}
proc pqprint*(fout: File, res: PGresult, ps: PPQprintOpt){.libpq, importc: "PQprint".}
proc pqdisplayTuples*(res: PGresult, fp: File, fillAlign: int32, fieldSep: cstring, printHeader: int32, quiet: int32){.libpq, importc: "PQdisplayTuples".}
proc pqprintTuples*(res: PGresult, fout: File, printAttName: int32, terseOutput: int32, width: int32){.libpq, importc: "PQprintTuples".}
proc lo_open*(conn: PGConn, lobjId: Oid, mode: int32): int32{.libpq, importc: "lo_open".}
proc lo_close*(conn: PGConn, fd: int32): int32{.libpq, importc: "lo_close".}
proc lo_read*(conn: PGConn, fd: int32, buf: cstring, length: int): int32{. libpq, importc: "lo_read".}
proc lo_write*(conn: PGConn, fd: int32, buf: cstring, length: int): int32{.libpq, importc: "lo_write".}
proc lo_lseek*(conn: PGConn, fd: int32, offset: int32, whence: int32): int32{.libpq, importc: "lo_lseek".}
proc lo_creat*(conn: PGConn, mode: int32): Oid{.libpq, importc: "lo_creat".}
proc lo_tell*(conn: PGConn, fd: int32): int32{.libpq, importc: "lo_tell".}
proc lo_unlink*(conn: PGConn, lobjId: Oid): int32{.libpq, importc: "lo_unlink".}
proc lo_import*(conn: PGConn, filename: cstring): Oid{.libpq, importc: "lo_import".}
proc lo_export*(conn: PGConn, lobjId: Oid, filename: cstring): int32{.libpq, importc: "lo_export".}
proc pqmblen*(s: cstring, encoding: int32): int32{.libpq, importc: "PQmblen".}
proc pqenv2encoding*(): int32{.libpq, importc: "PQenv2encoding".}

proc pqsetdb(M_PGHOST, M_PGPORT, M_PGOPT, M_PGTTY, M_DBNAME: cstring): PGConn =
  result = pqsetdbLogin(M_PGHOST, M_PGPORT, M_PGOPT, M_PGTTY, M_DBNAME, "", "")
