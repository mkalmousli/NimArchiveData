## Contains procedures to convert objects, arrays and special datatypes
## to proper database representations.
## 
## Used internally by amicus

## Convention:
## `!$` procedures convert a datatype *to* a database-compatible
## representation which is dependent on the dbEngine constant.
## 
## Procedures which convert *from* a database-compatible representation
## are simply named after the type they return.
## These, like the `!$` procedures, need to be aware of the database engine
## at hand, through the dbEngine constant.
## Naming examples:
##   toStrSeq returns a sequence consisting of strings
##   toKDF returns KDF objects
##   toDate returns DateTime objects

import std/[times, strformat, sysrand, strutils], ../shared
func basicEscape(s: string): string =
  ## Used by seq[string]'s !$() proc
  for ch in s:
    case ch:
    of '\\',',','"': result.add "\\" & ch
    else: result.add ch

func `!$`*(date: DateTime): string = 
  ## Converts a date into a database-compatible string
  when dbEngine == "postgres":
    return format(date, "yyyy-MM-dd HH:mm:ss")
  else: {.warning: "!$(DateTime) unimplemented".}

proc toDate*(row: string): DateTime =
  ## Creates a date out of a database row
  when dbEngine == "postgres":
    return parse(row, "yyyy-MM-dd HH:mm:ss", utc())
  else: {.warning: "toDate() unimplemented".}

func toLevel*(s: string): PostPrivacyLevel =
  when dbEngine == "postgres":
    case s:
    of "-1": return Deleted
    of "0": return Public
    of "1": return Unlisted
    of "2": return FollowersOnly
    of "3": return Limited
    of "4": return Private
    else: raise newException(CatchableError, "Unknown string passed to strextra.toLevel(): " & s)
  else: {.warning: "toLevel() unimplemented".}

func `!$`*(s: openArray[string]): string =
  ## Converts an ``openArray[string]`` into a simple string
  ## suitable for inserting into a database.
  when dbEngine == "postgres":
    for i in s:
      result.add('\"' & basicEscape(i) & "\",")

    # Bug: Exception occurs when trying
    # trim the last character of an empty string.
    # Fix: Add a length check :-)
    if len(result) != 0:
      result = result[0..^2]

    return '{' & result & '}' 
  else: {.warning: "!$(openArray[string]) unimplemented".}

func toStrSeq*(s: string): seq[string] =
  ## Converts a postgres string array into a real sequence.
  when dbEngine == "postgres":
    var
      tmp = ""
      backslash = false
      inString = false
    for ch in s:
      # We are dealing with: "a,",b
      if backslash:
        tmp.add(ch)
        backslash = false
        continue

      if inString:
        case ch:
        of '"': inString = false
        of '\\': backslash = true
        else: tmp.add(ch)
      else:
        case ch:
        of '"': inString = true
        of '\\': backslash = true
        of '{','}': continue
        of ',':
          result.add tmp
          tmp = ""
        else: tmp.add ch

    if tmp != "":
      result.add(tmp)
  else: {.warning: "toStrSeq() unimplemented".}

func `!$`*(s: openArray[int]): string =
  ## Converts an ``openArray[string]`` into a simple string
  ## suitable for inserting into a database.
  when dbEngine == "postgres":
    for i in s:
      result.add($i & ",")

    # Bug: Exception occurs when trying
    # trim the last character of an empty string.
    # Fix: Add a length check :-)
    if len(result) != 0:
      result = result[0..^2]

    return '{' & result & '}' 
  else: {.warning: "!$(openArray[int]) unimplemented".}

func toIntSeq*(s: string): seq[int] =
  ## Converts a postgres integer array into a real sequence.
  when dbEngine == "postgres":
    var tmp = ""
    for ch in s:
      # We are dealing with: 1,2,3
      case ch:
      of ',': result.add parseInt(tmp)
      of '{','}': continue
      else: tmp.add(ch)

    if tmp != "":
      result.add parseInt(tmp)
  else: {.warning: "toIntSeq() unimplemented".}

func `!$`*(k: KDF): string =
  ## Converts a `KDF` object into a string ready to be inserted into the database.
  when dbEngine == "postgres":
    $(k)
  else: {.warning: "!$(KDF) unimplemented".}

func toKDF*(str: string): KDF = 
  ## Returns back a proper `KDF` object out of a string representation from the database layer.
  # Feel free to change this if and when the KDF needs
  # to be updated :)
  when dbEngine == "postgres":
    PBKDF_HMAC_SHA512
  else: {.warning: "toKDF() unimplemented".}

func `!$`*(l: PostPrivacyLevel): string =
  ## Converts a `PostPrivacyLevel` object into a string ready to be inserted into the database.
  when dbEngine == "postgres":
    case l:
    of Public: return "0"
    of Unlisted: return "1"
    of FollowersOnly: return "2"
    of Limited: return "3"
    of Private: return "4"
    of Deleted: return "5"
  else: {.warning: "!$(PostPrivacyLevel) unimplemented".}

func htmlEscape*(pre_s: string): string =
  ## Very basic HTML escaping function.
  var s = pre_s
  if s.startsWith("javascript:"): s = s[11..^1]
  if s.startsWith("script:"): s = s[7..^1]
  if s.startsWith("java:"): s = s[5..^1]

  for ch in s:
    case ch:
    of '<': result.add("&lt;")
    of '>': result.add("&gt;")
    else: result.add(ch)

# Includes only 0 to 9, a to z and A to Z
# in ASCII.
const pattern = {48..57, 65..90, 97..122}
proc randstr*(length = 128): string =     
  ## Generates a string using the system CSPRNG
  while true:
    for i in urandom(length):
      if i in pattern:
        result.add(char(i))
    if len(result) >= length:
      return result[0..length - 1] 

proc uuidv4*(): string =
  ## Generates a UUID (version 4).
  ## This type of UUID is completely random.
  ## 
  ## This implementation is based on nim-uuid4 by Matt Cooper (@vtbassmatt on GitHub)
  var bytes = urandom(16)
  bytes[6] = (bytes[6] and 0x0F) or 0x40 # version 4
  bytes[8] = (bytes[8] and 0x3F) or 0x80 # variant 1
  proc toHex(bytes: seq[byte]): string =
    for b in bytes:
      result = result & fmt"{b:02x}"
  return toHex(bytes[0..3]) & '-' &
         toHex(bytes[4..5]) & '-' &
         toHex(bytes[6..7]) & '-' &
         toHex(bytes[8..9]) & '-' &
         toHex(bytes[10..^1])