## Thin sqlite3 wrapper, based off of db_connector/sqlite3
when defined(staticAmicus):
  {.compile("sqlite3.c", "-O3").}
  {.pragma: sql3, cdecl.}
else:
  when defined(windows):
    when defined(cpu64):
      const Lib = "sqlite3_64.dll"
    else:
      const Lib = "sqlite3_32.dll"
  elif defined(macosx):
    const Lib = "libsqlite3(|.0).dylib"
  else:
    const Lib = "libsqlite3.so(|.0)"
  {.pragma: sql3, cdecl, dynlib: Lib.}
type Sqlite3* {.pure.} = ptr object # Handle to db
type Stmt* {.pure.} = ptr object # Statement
type BindDestructor* = proc (arg1: pointer){.cdecl, tags: [], raises: [], gcsafe.}
const SQLITE_OK* = 0
const SQLITE_ROW* = 100
const SQLITE_DONE* = 101
const SQLITE_INTEGER* = 1.cint
const SQLITE_FLOAT* = 2.cint
const SQLITE_TEXT* = 3.cint
const SQLITE_BLOB* = 4.cint
const SQLITE_NULL* = 5.cint
const SQLITE_STATIC* = nil
const SQLITE_TRANSIENT* = cast[BindDestructor](-1)
proc errmsg*(arg1: Sqlite3): cstring{.sql3, importc: "sqlite3_errmsg".}
proc open*(filename: cstring, ppDb: var Sqlite3): int32{.sql3, importc: "sqlite3_open".}
proc prepare_v2*(db: Sqlite3, zSql: cstring, nByte: cint, ppStmt: var Stmt, pzTail: ptr cstring): cint {.importc: "sqlite3_prepare_v2", sql3.}
proc bind_blob*(arg1: Stmt, arg2: int32, arg3: pointer, n: int32, arg5: BindDestructor): int32{.sql3, importc: "sqlite3_bind_blob".}
proc bind_double*(arg1: Stmt, arg2: int32, arg3: float64): int32{.sql3, importc: "sqlite3_bind_double".}
proc bind_int64*(arg1: Stmt, arg2: int32, arg3: int64): int32{.sql3, importc: "sqlite3_bind_int64".}
proc bind_null*(arg1: Stmt, arg2: int32): int32{.sql3, importc: "sqlite3_bind_null".}
proc bind_text*(arg1: Stmt, arg2: int32, arg3: cstring, n: int32, arg5: BindDestructor): int32{.sql3, importc: "sqlite3_bind_text".}
proc bind_parameter_count*(arg1: Stmt): int32{.sql3, importc: "sqlite3_bind_parameter_count".}
proc column_count*(stmt: Stmt): cint {.sql3, importc: "sqlite3_column_count".}
proc column_type*(stmt: Stmt, c: cint): cint {.sql3, importc: "sqlite3_column_type".}
proc column_text*(stmt: Stmt, c: cint): cstring {.sql3, importc: "sqlite3_column_text".}
proc column_int64*(stmt: Stmt, c: cint): int64 {.sql3, importc: "sqlite3_column_int64".}
proc column_blob*(stmt: Stmt, c: cint): pointer {.sql3, importc: "sqlite3_column_blob".}
proc column_bytes*(stmt: Stmt, c: cint): cint {.sql3, importc: "sqlite3_column_bytes".}
proc column_double*(stmt: Stmt, c: cint): float64 {.sql3, importc: "sqlite3_column_double".}
proc step*(arg1: Stmt): int32{.sql3, importc: "sqlite3_step".}
proc finalize*(arg: Stmt): int32{.sql3, importc: "sqlite3_finalize".}
proc reset*(arg: Stmt): int32{.sql3, importc: "sqlite3_reset".}
proc close_v2*(arg: Sqlite3): int32{.sql3, importc: "sqlite3_close_v2".}