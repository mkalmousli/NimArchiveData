# Copyright © penguinite 2024-2025 <penguinite@tuta.io>
#
# This file is part of Onbox.
# 
# Onbox is free software: you can redistribute it and/or modify it under the terms of
# the GNU Affero General Public License as published by the Free Software Foundation,
# either version 3 of the License, or (at your option) any later version.
# 
# Onbox is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License
# for more details.
# 
# You should have received a copy of the GNU Affero General Public License
# along with Onbox. If not, see <https://www.gnu.org/licenses/>. 
import db_connector/db_postgres, shared

## Users can bookmark a post to return to it later, and this module implements that.
## This module handles creation, retrieval, checking, updating and deletion of bookmarks.

proc bookmarkExists*(db: DbConn, user, post: string): bool =
  ## Check if a bookmark exists. A user *shouldn't* be allowed to bookmark a post twice.
  runnableExamples "-r:off -c:off":
    # ignore these lines
    import amicus
    var
      db: DbConn
      user, post: string

    var output = ""
    if not db.bookmarkExists(user, post):
      db.bookmarkPost(user, post)
      output = "You've successfully bookmarked this post!"
    else:
      output = "You've already bookmarked this post!"
  when dbEngine == "postgres":
    db.getRow(
      sql"SELECT EXISTS(SELECT 0 FROM bookmarks WHERE uid = ? AND pid = ?);",
      user, post
    )[0] == "t"
  else: {.warning: "bookmarkExists() unimplemented".}

proc bookmarkPost*(db: DbConn, user, post: string) =
  ## Bookmark a post. Both fields are expected to be IDs.
  when dbEngine == "postgres":
    db.exec(sql"INSERT INTO bookmarks VALUES (?,?);", post, user)
  else: {.warning: "bookmarkPost() unimplemented".}

proc getBookmarks*(db: DbConn, user: string, limit = 20): seq[string] =
  ## Returns a sequence of post IDs that a user has bookmarked.
  ## 
  ## Note: This has a limit, which is by default 20.
  ## But you can change it with the ``limit```parameter
  when dbEngine == "postgres":
    for row in db.getAllRows(sql("SELECT pid FROM bookmarks WHERE uid = ? LIMIT " & $limit & ";"), user):
      result.add(row[0])
  else: {.warning: "getBookmarks() unimplemented".}

proc getAllBookmarks*(db: DbConn, user: string): seq[string] =
  ## Returns a sequence of post IDs that a user has bookmarked.
  ## 
  ## Note: This has NO limit, meaning that if a user has a thousand bookmarks
  ## then they will all be searched through.
  when dbEngine == "postgres":
    for row in db.getAllRows(sql"SELECT pid FROM bookmarks WHERE uid = ?;", user):
      result.add(row[0])
  else: {.warning: "getAllBookmarks() unimplemented".}

proc unbookmarkPost*(db: DbConn, user, post: string) =
  ## "unbookmarks" (removes a bookmark) a post by a user. Both fields are expected to be IDs.
  when dbEngine == "postgres":
    db.exec(sql"DELETE FROM bookmarks WHERE uid = ? AND pid = ?;", user, post)
  else: {.warning: "unbookmarkPost() unimplemented".}