# Copyright © penguinite 2024-2025 <penguinite@tuta.io>
# Copyright © Leo Gavilieau 2022-2023 <xmoo@privacyrequired.com>
#
# This file is part of Onbox.
# 
# Onbox is free software: you can redistribute it and/or modify it under the terms of
# the GNU Affero General Public License as published by the Free Software Foundation,
# either version 3 of the License, or (at your option) any later version.
# 
# Onbox is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License
# for more details.
# 
# You should have received a copy of the GNU Affero General Public License
# along with Onbox. If not, see <https://www.gnu.org/licenses/>. 
import shared, private/strconv, std/tables, db_connector/db_postgres

## This module contains all database logic for handling boosts.
## A "boost" is used to promote and share posts, putting them on a user's profile
## and thus visible to a user's followers.
##
## There are different kinds of boosts, hence why we store an extra "level" column
## Someone might want to show a post to only their followers and no one else.
## Quote-boosts are not considered true boosts. They're just posts with a link.

proc getBoosts*(db: DbConn, post: string, limit = 40): Table[PostPrivacyLevel, seq[string]] =
  ## Retrieves a Table of boosts for a post.
  ## Result consists of a table where the keys are the specific levels and
  ## the value is a sequence of boosters associated with this level.
  when dbEngine == "postgres":
    
    for row in db.getAllRows(sql("SELECT uid,level FROM boosts WHERE pid = ? LIMIT " & $limit & ";"), post):
      if not result.hasKey(toLevel(row[1])):
        result[toLevel(row[1])] = @[]
      result[toLevel(row[1])].add(row[0])
  else: {.warning: "getBoosts unimplemented.".}

proc getBoostsFast*(db: DbConn, post: string, limit = 40): seq[string] =
  ## Returns a list of boosters for a specific post.
  # TODO: Adding an extra for loop here seems dumb...
  # But getAllRows returns seq[Row] (which is like seq[seq[string]])
  when dbEngine == "postgres":
    for row in db.getAllRows(sql("SELECT uid FROM boosts WHERE pid = ? LIMIT " & $limit & ";"), post):
      result.add(row[0])
  else: {.warning: "getBoostsFast unimplemented.".}

proc isBoostable*(db: DbConn, post: string): bool =
  ## Checks if the post can be boosted.
  ##
  ## Currently, this only checks if the post you're trying to boost
  ## is either a public or unlisted post. Cause if it isn't either of those
  ## then you're not allowed to share it to potentially unknown people.
  when dbEngine == "postgres":
    # TODO: This might be wrong.
    toLevel(db.getRow(sql"SELECT privacy_level FROM posts WHERE id = ?;", post)[0]) in [Public, Unlisted]
  else: {.warning: "isBoostable unimplemented.".}

proc userBoosted*(db: DbConn, user, post: string): bool =
  ## Check if a user has boosted a post
  when dbEngine == "postgres":
    db.getRow(
      sql"SELECT EXISTS(SELECT 0 FROM boosts WHERE pid = ? AND uid = ?);",
      post, user
    )[0] == "t"
  else: {.warning: "userBoosted unimplemented.".}

proc removeBoost*(db: DbConn, user, post: string) =
  ## "Unboosts" (or removes a boost) from the database
  when dbEngine == "postgres":
    db.exec(sql"DELETE FROM boosts WHERE pid = ? AND uid = ?;",post,user)
  else: {.warning: "removeBoost unimplemented.".}

proc userBoostedLevel*(db: DbConn, user, post: string, level: PostPrivacyLevel): bool =
  ## Checks if a post has a boost by a specific user, with a specific level too.
  when dbEngine == "postgres":
    db.getRow(
      sql"SELECT EXISTS(SELECT 0 FROM boosts WHERE pid = ? AND uid = ? AND level = ?);",
      post, user, !$level
    )[0] == "t"
  else: {.warning: "userBoostedLevel unimplemented.".}

proc addBoost*(db: DbConn, user, post: string, level: PostPrivacyLevel) =
  ## Adds an individual boost
  ## 
  ## The level parameter can only be Public, Unlisted or FollowersOnly.
  # Check if a boost already exists before
  # &
  # Filter out invalid levels.
  # You can't have a boost limited to some unknown people
  # and a "private boost" (that is just a bookmark lol)
  # a "deleted boost"? wtf?
  #
  # TODO: Remove this check.
  if not db.userBoosted(user, post) and level in {Public, Unlisted, FollowersOnly}:
    when dbEngine == "postgres":
      db.exec(sql"INSERT INTO boosts (pid, uid, level) VALUES (?,?,?);",post,user, !$(level))
    else: {.warning: "addBoost unimplemented.".}

proc getNumBoosts*(db: DbConn, post: string): int =
  ## Returns the number of times a post has been boosted.
  ## 
  ## Doesn't return the boosters or anything more than that.
  when dbEngine == "postgres":
    return len(db.getAllRows(sql"SELECT 0 FROM boosts WHERE pid = ?;", post))
  else: {.warning: "getNumBoosts unimplemented.".}