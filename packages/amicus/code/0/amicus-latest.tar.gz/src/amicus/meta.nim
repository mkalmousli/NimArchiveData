# Copyright © penguinite 2024-2025 <penguinite@tuta.io>
#
# This file is part of Onbox.
# 
# Onbox is free software: you can redistribute it and/or modify it under the terms of
# the GNU Affero General Public License as published by the Free Software Foundation,
# either version 3 of the License, or (at your option) any later version.
# 
# Onbox is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License
# for more details.
# 
# You should have received a copy of the GNU Affero General Public License
# along with Onbox. If not, see <https://www.gnu.org/licenses/>. 
import db_connector/db_postgres, shared

## This module provides access to the ``meta`` table that Amicus creates.
## This ``meta`` table is used to provide statistics, config options and
## constants for the database itself.
## 
## One thing it stores is the ``db_version`` key, which is a simple text
## value containing the version of Amicus that created the database schema.
## This is used to smoothly migrate from one version to another.
## 
## In short, This module provides a standard, database-neutral interface
## which you can use to fetch, delete, set/update "metadata" about the database.

## Users can bookmark a post to return to it later, and this module implements that.
## This module handles creation, retrieval, checking, updating and deletion of bookmarks.

proc metaKeyExists*(db: DbConn, key: string): bool =
  ## Check if a key in the meta table exists.
  when dbEngine == "postgres":
    db.getRow(sql"SELECT EXISTS(SELECT 0 FROM meta WHERE k = ?);", key)[0] == "t"
  else: {.warning: "metaKeyExists() unimplemented".}

proc getMetaKey*(db: DbConn, key: string): string =
  ## Return the value of a meta key.
  when dbEngine == "postgres":
    db.getRow(sql"SELECT v FROM meta WHERE k = ?;", key)[0]
  else: {.warning: "getMetaKey() unimplemented".}

proc createMetaKey*(db: DbConn, key, value: string) =
  ## Create a meta key
  ## 
  ## Note: Be careful!
  when dbEngine == "postgres":
    db.exec(sql"INSERT INTO meta VALUES (?,?);", key, value)
  else: {.warning: "createMetaKey() unimplemented".}

proc setMetaKey*(db: DbConn, key, value: string) =
  ## Create a meta key
  ## 
  ## Note: Be careful!
  when dbEngine == "postgres":
    db.exec(sql"UPDATE meta SET v = ? WHERE k = ?;", value, key)
  else: {.warning: "setMetaKey() unimplemented".}

proc deleteMetaKey*(db: DbConn, key: string): seq[string] =
  ## Delete a meta key.
  ##
  ## Note: Be careful!
  when dbEngine == "postgres":
    db.exec(sql"DELETE FROM meta WHERE k = ?;", key)
  else: {.warning: "deleteMetaKey() unimplemented".}