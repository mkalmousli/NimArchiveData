# Copyright © penguinite 2024-2025 <penguinite@tuta.io>
#
# This file is part of Onbox. Specifically, the Quark repository.
# 
# Onbox is free software: you can redistribute it and/or modify it under the terms of
# the GNU Affero General Public License as published by the Free Software Foundation,
# either version 3 of the License, or (at your option) any later version.
# 
# Onbox is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License
# for more details.
# 
# You should have received a copy of the GNU Affero General Public License
# along with Onbox. If not, see <https://www.gnu.org/licenses/>. 
import shared, private/strconv, std/times, db_connector/db_postgres

## This module handles Email verification codes for users.
## This module does not handle sending email verification codes,

proc emailCodeExists*(db: DbConn, code: string): bool =
  ## Checks if an email code exists or not.
  when dbEngine == "postgres":
    db.getRow(sql"SELECT EXISTS(SELECT 0 FROM email_codes WHERE id = ?);",code)[0] == "t"
  else: {.warning: "emailCodeExists() unimplemented.".}

proc emailCodeExistsByUser*(db: DbConn, user: string): bool =
  ## Checks if a user already has an email code.
  when dbEngine == "postgres":
    db.getRow(sql"SELECT EXISTS(SELECT 0 FROM email_codes WHERE uid = ?);",user)[0] == "t"
  else: {.warning: "emailCodeExistsByUser() unimplemented.".}

proc getUserFromEmailCode*(db: DbConn, user: string): string =
  ## Gets the user ID belonging to an email code.
  when dbEngine == "postgres":
    db.getRow(sql"SELECT uid FROM email_codes WHERE id = ?;", user)[0]
  else: {.warning: "getUserFromEmailCode() unimplemented.".}

proc getEmailCodeDate*(db: DbConn, code: string): DateTime =
  ## Return the date of when an email code was created
  when dbEngine == "postgres":
    return toDate(db.getRow(sql"SELECT date FROM email_codes WHERE id = ?;", code)[0])
  else: {.warning: "getEmailCodeDate() unimplemented".}

proc getEmailCodeAge*(db: DbConn, code: string): Duration =
  ## Returns how old an email code is
  return now().utc - db.getEmailCodeDate(code)

proc emailCodeValid*(db: DbConn, code, user: string): bool =
  ## Use this over emailCodeExists or emailCodeExistsForUser
  return (
    db.emailCodeExists(code) and
    db.getUserFromEmailCode(code) == user and
    not (db.getEmailCodeAge(code) > initDuration(days = 1)) and
    user != nullUuid
  )

proc deleteEmailCode*(db: DbConn, code: string) =
  ## Deletes an email code
  when dbEngine == "postgres":
    db.exec(sql"DELETE FROM email_codes WHERE id = ?;", code)
  else: {.warning: "deleteEmailCode() unimplemented.".}

proc deleteEmailCodeByUser*(db: DbConn, user: string) =
  ## Delete an email code using the User ID instead of the code itself.
  when dbEngine == "postgres":
    db.exec(sql"DELETE FROM email_codes WHERE uid = ?;", user)
  else: {.warning: "deleteEmailCodeByUser() unimplemented.".}

proc createEmailCode*(db: DbConn, user: string, date = now().utc): string =
  ## Creates an email code and returns the ID belonging to it
  result = randstr(32)
  when dbEngine == "postgres":
    # TODO: Remove this check
    # Check if another code already exists for this user first.
    # And delete it.
    if db.emailCodeExistsByUser(user):
      db.deleteEmailCodeByUser(user)
    db.exec(sql"INSERT INTO email_codes VALUES (?,?,?);", result, user, !$(date))
  else: {.warning: "createEmailCode() unimplemented.".}

proc cleanEmailCodes*(db: DbConn) =
  ## Clean old invalid email codes.
  when dbEngine == "postgres":
    for row in db.getAllRows(sql"SELECT id,uid,date FROM email_codes;"):
      if (now().utc - toDate(row[2]) > initDuration(days = 1)) or row[1] == nullUuid:
        db.deleteEmailCode(row[0])
  else: {.warning: "cleanEmailCodes() unimplemented.".}