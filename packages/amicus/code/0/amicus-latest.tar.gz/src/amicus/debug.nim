## Common procedures for debugging
when not defined(amicusDebug):
  {.error: "do not use".}

import ../amicus, db_connector/db_postgres
export amicus

proc openDb*(): DbConn =
  result = open("127.0.0.1:5432", "onbox", "SOMETHING_SECRET", "onbox")

  # run setupEverything() if no tables can be found
  if result.getRow(sql"SELECT EXISTS (SELECT 0 FROM information_schema.tables WHERE table_schema = 'public' AND table_name = 'apps');") != @["t"]:
    result.setupEverything()

proc closeDb*(db: DbConn) =
  db.close()