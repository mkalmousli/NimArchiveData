# Copyright © penguinite 2024-2025 <penguinite@tuta.io>
#
# This file is part of Onbox.
# 
# Onbox is free software: you can redistribute it and/or modify it under the terms of
# the GNU Affero General Public License as published by the Free Software Foundation,
# either version 3 of the License, or (at your option) any later version.
# 
# Onbox is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License
# for more details.
# 
# You should have received a copy of the GNU Affero General Public License
# along with Onbox. If not, see <https://www.gnu.org/licenses/>. 
import apps, shared, users, std/times, db_connector/db_postgres, private/strconv

## This module handles authorization code creation, cleanup and processing.
## Authorization codes refer to the ones generated via the OAuth process.
## This is usually typically used to authorize apps (such as third party clients)
## to do various things to your account (or the instance depending on the scopes)
## 
## The general process is to first create an app and then authorize a user
## or something along those lines, creating an auth code. and then using that
## to obtain an oauth token which is what is actually used to authenticate
## (in HTTP headers and the like)

proc getAuthCode*(db: DbConn, user, client: string): string =
  ## Return an auth code by searching for the user it belongs to and the client that submitted it
  ##
  ## The ``user`` and ``client`` parameters are meant to be IDs, namely the user ID and the app's ``client_id``
  runnableExamples "-r:off -c:off":
    # ignore these lines
    import amicus
    var
      db: DbConn
      user, client, input: string

    if db.getAuthCode(user, client) == input:
      echo "Access definitely granted!"
  when dbEngine == "postgres":
    db.getRow(sql"SELECT id FROM auth_codes WHERE uid = ? AND cid = ?;", user, client)[0]
  else: {.warning: "getAuthCode() unimplemented".}

proc authCodeExists*(db: DbConn, user, client: string): bool =
  ## Check if an authorization code exists by searching for it using the user ID and the client ID.
  ## 
  ## The ``user`` and ``client`` parameters are meant to be IDs, namely the user ID and the app's ``client_id``
  runnableExamples "-r:off -c:off":
    # ignore these lines
    import amicus
    var
      db: DbConn
      user, client: string

    if not db.authCodeExists(user, client):
      echo "Access *not* granted."
  when dbEngine == "postgres":
    db.getRow(
      sql"SELECT EXISTS(SELECT 0 FROM auth_codes WHERE uid = ? AND cid = ?);",
      user, client
    )[0] == "t"
  else: {.warning: "authCodeExists() unimplemented".}

proc authCodeExists*(db: DbConn, id: string): bool =
  ## Check if an authorization code exists by searching for the code itself.
  runnableExamples "-r:off -c:off":
    # ignore these lines
    import amicus
    var
      db: DbConn
      input: string

    if input != "" and db.authCodeExists(input):
      echo "Hm... I'll need to check this with getAuthCode()"
  when dbEngine == "postgres":
    db.getRow(
      sql"SELECT EXISTS(SELECT 0 FROM auth_codes WHERE id = ?);", id
    )[0] == "t"
  else: {.warning: "authCodeExists() unimplemented".}

proc createAuthCode*(db: DbConn, user, client: string, scopes: openArray[string], date = now().utc): string =
  ## Creates an auth code for a user and returns it.
  ##
  ## The ``user`` and ``client`` parameters are meant to be IDs, namely the user ID and the app's ``client_id``
  runnableExamples "-r:off -c:off":
    # ignore these lines
    import amicus
    var
      db: DbConn
      user, client: string

    let code = db.createAuthCode(user, client, ["read", "write"])
    echo "Your auth code is: ", code
  when dbEngine == "postgres":
    result = randstr(32)
    db.exec(
      sql"INSERT INTO auth_codes VALUES (?,?,?,?,?);",
      result, user, client, !$(scopes), date
    )
  else: {.warning: "createAuthCode() unimplemented".}

proc getCodeScopes*(db: DbConn, id: string): seq[string] =
  ## Retrieves the scopes for an auth code
  when dbEngine == "postgres":
    toStrSeq(db.getRow(sql"SELECT scopes FROM auth_codes WHERE id = ?;", id)[0])
  else: {.warning: "getCodeScopes() unimplemented".}
  
proc codeHasScopes*(db: DbConn, id:string, scopes: seq[string]): bool =
  ## When given an auth code, it will check if the auth code has a bunch of scopes specified in the ``scopes`` array.  
  ## 
  ## This procedure's logic might be abruptly changed, do not use it.
  # TODO: What is this supposed to do again?
  let appScopes = db.getCodeScopes(id)
  for scope in scopes:
    for codeScope in appScopes:
      if codeScope == scope or codeScope == scope.getBroadScope():
        result = true
        break

proc deleteAuthCode*(db: DbConn, id: string) =
  when dbEngine == "postgres":
    db.exec(sql"DELETE FROM auth_codes WHERE id = ?;", id)
  else: {.warning: "getCodeScopes() unimplemented".}

proc getUserFromAuthCode*(db: DbConn, id: string): string =
  ## Returns user id associated with an auth code
  when dbEngine == "postgres":
    db.getRow(sql"SELECT uid FROM auth_codes WHERE id = ?;", id)[0]
  else: {.warning: "getUserFromAuthCode() unimplemented".}

proc getAppFromAuthCode*(db: DbConn, id: string): string =
  ## Returns app id associated with an auth code
  when dbEngine == "postgres":
    db.getRow(sql"SELECT cid FROM auth_codes WHERE id = ?;", id)[0]
  else: {.warning: "getAppFromAuthCode() unimplemented".}

proc getAuthCodeDate*(db: DbConn, id: string): DateTime =
  ## Returns the date that an auth code was assigned.
  ## 
  ## Auth codes are usually deleted after a day.
  when dbEngine == "postgres":
    toDate(db.getRow(sql"SELECT date FROM auth_codes WHERE id = ?;", id)[0])
  else: {.warning: "getAuthCodeDate() unimplemented".}

proc authCodeValid*(db: DbConn, id: string): bool =
  ## Checks if an auth code is actually valid and can be used.
  runnableExamples "-r:off -c:off":
    # ignore these lines
    import amicus
    var
      db: DbConn
      input: string

    if not db.authCodeValid(input):
      var output = "get outta here!"
  # Obviously check if the auth code exists first.
  if not db.authCodeExists(id):
    return false
  
  # Check if the associated app exists
  # If an auth code isn't assigned to any valid app then it's invalid
  if not db.clientExists(db.getAppFromAuthCode(id)):
    return false
  
  # Check if the associated user exists
  # If the auth token is associated to a non-existent user then it is invalid.
  if not db.userIdExists(db.getUserFromAuthCode(id)):
    return false

  # Check if the auth code is assigned to the "Null" user
  # No auth code should be assigned to null, but it might happen.
  if db.getUserFromAuthCode(id) == "00000000-0000-0000-0000-000000000000":
    return false

  # Check if the code is a day old or more.
  # if it is a day old (or more), then it's invalid. (And should be deleted at some point)
  if now().utc - db.getAuthCodeDate(id) > initDuration(days = 1):
    return false

  # Stop time traveler auth codes
  # This is not a real concern but... meh...
  if db.getAuthCodeDate(id) > now().utc:
    return false

  # If all our checks succeed then it has to be a valid auth code.
  return true

proc cleanAuthCodes*(db: DbConn) =
  ## Purge any invalid authentication codes
  when dbEngine == "postgres":
    for row in db.getAllRows(sql"SELECT id FROM auth_codes;"):
      if not db.authCodeValid(row[0]):
        db.deleteAuthCode(row[0])
  else: {.warning: "cleanAuthCodes() unimplemented".}