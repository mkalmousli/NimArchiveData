# Copyright © penguinite 2024-2025 <penguinite@tuta.io>
# Copyright © Leo Gavilieau 2022-2023 <xmoo@privacyrequired.com>
#
# This file is part of Onbox.
# 
# Onbox is free software: you can redistribute it and/or modify it under the terms of
# the GNU Affero General Public License as published by the Free Software Foundation,
# either version 3 of the License, or (at your option) any later version.
# 
# Onbox is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License
# for more details.
# 
# You should have received a copy of the GNU Affero General Public License
# along with Onbox. If not, see <https://www.gnu.org/licenses/>. 
#
# onbox/shared.nim:
## This module contains procedures, templates, constants and other data
## to be shared across Onbox, or that is used many times across many places.
## 
import std/[tables, times]

##[
dbEngine is a constant that determines which database backend to use in amicus.
For example, compiling your application with ``-d:dbEngine=postgres`` means that amicus will use
postgres-only SQL queries, schema, conventions and so on.

Currently only ``postgres`` is supported, and it is the default.]##
const
  dbEngine*{.strdefine.} = "postgres"
  nullUuid* = "00000000-0000-0000-0000-000000000000" 

type
  FollowStatus* = enum ## An enum representing the possible follow states between two users.
    NoFollowRequest, ## User isn't following or hasn't sent a follow request yet.
    PendingFollowRequest, ## User has sent a follow request but it hasn't been accepted yet.
    AcceptedFollowRequest ## User is following and/or has sent a follow request which has been accepted.

  PostPrivacyLevel* = enum ## An enum representing the possible visibilities for a post to have.
    Deleted = "-1", ## Not to be shown or viewed at all.
    Public = "0", ## ``Public`` essentially means that the post can be viewed by anyone with no restrictions
    Unlisted = "1", ## ```Unlisted` ensures that the post won't be visible in *public* feeds but it can still be found
    FollowersOnly = "2", ## ``FollowersOnly`` is stricter than ``Unlisted`` in that it can only be viewed by the those who follow the sender.
    Limited = "3", ## It's unclear what this means.
    Private = "4", ## ``Private`` is the strictest privacy level that a user can select. It means the post is only visible to the owner and recipients (mentions)

  PostContentType* = enum
    Text = "0"
    Media = "1"

  PostContent* = object of RootObj
    case kind*: PostContentType
    of Text:
      txt_published*: DateTime ## The timestamp of when then Post was last edited
      txt_format*: int ## The format that the text is written in.
      text*: string ## The text itself
    of Media:
      media_id*: string

  Post* = object
    id*: string # A unique id.
    sender*: string # Basically, the person sending the message (Or more specifically, their ID.)
    replyto*: string # Resource/Post person was replying to,  
    client*: string # A string containing the client id used for writing this post.
    written*: DateTime # A timestamp of when the Post was created
    level*: PostPrivacyLevel # The privacy level of the post
    local*:bool # A boolean indicating whether or not the post came from the local server or external servers
    recipients*: seq[string] # A sequence of recipient's handles.
    tags*: seq[string] # Set of hashtags used
    content*: seq[PostContent] # The actual content of the post
    reactions*: Table[string, seq[string]] # A sequence of reactions this post has.
    boosts*: Table[string, seq[string]] # A sequence of id's that have boosted this post. (Along with what level)

  KDF* = enum ## The building block for amicus's KDF/crypto layer.
    PBKDF_HMAC_SHA512 = "1" 

  UserType* = enum ## Indicates what "type" the user is.
    Person, ## A human being
    Application, ## An external application (such as a frontend, client or bot) acting as a user.
    Organization, ## An account for an organization
    Group, ## A group of individuals sharing a single account
    Service  ## A service using an account to implement a feature

  ProfileField* = object ## Profile fields allow a user to present information about themselves in a structured manner, in addition the fields can consist of domain names that are "verified" (ensuring that a User is really who they say they are.)
    key*, val*: string ## The keys and values for a field
    verified*: bool ## Indicates if the profile field's content has been verified to some extent, fx. if the profile field links to a website then the website will be fetched to see if it contains a link to the user's profile, and if it does, then it's verified. This acts a sort of basic identity verification mechanism.
    verified_at*: DateTime ## Indicates at which point in time the user's profile was marked as "verified"

  User* = object ## Represents users in amicus
    id*: string ## A UUID to represent the user
    kdf*: KDF ## Which KDF to use when validating the password
    roles*: seq[int] ## Roles associated with this user
    discoverable*: bool ## If the user is discoverable (should be visible in searches) or not
    email_verified*: bool ## If the user has a verified email or not
    handle*: string ## The user's "handle" ie. username.
    domain*: string ## If a user is federated, then this string will contain their domain. For local users this is empty.
    name*: string ## A string containing the user's display name
    email*: string ## A string containing the user's email
    bio*: string ## A string containing the user's biography
    password*: string ## A string to store a password hash
    salt*: string ## Salt with which to hash user's password