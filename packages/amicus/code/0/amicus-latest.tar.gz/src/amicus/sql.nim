## This module provides the SQL scripts needed to initialize the database schema.

import std/strutils, db_connector/db_postgres

const
  pgPurgeSql* = staticRead("../assets/pg_purge.sql")
  pgSetupSql* = staticRead("../assets/pg_setup.sql")
  
proc parseSqlFile(input: string): seq[string] =
  ## This implements the weird SQL script convention mentioned
  ## at the top of the `setup.sql` file.
  ## The main reason being that db.exec() only accepts one
  ## command at a time.
  var cmd = ""
  for line in input.splitLines:
    if line.startsWith("--"):
      continue
    if line.isEmptyOrWhitespace() and not cmd.isEmptyOrWhitespace():
      result.add(cmd)
      cmd = ""
      continue
    cmd.add(line & "\n")
  
  # One last check to make sure we're not missing data
  if cmd != "": 
    result.add(cmd)

proc purgeEverything*(db: DbConn) =
  for cmd in parseSqlFile(pgPurgeSql):
    db.exec(sql(cmd))
    
proc setupEverything*(db: DbConn) =
  for cmd in parseSqlFile(pgSetupSql):
    db.exec(sql(cmd))

