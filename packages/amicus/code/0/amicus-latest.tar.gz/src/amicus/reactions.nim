# Copyright © penguinite 2024-2025 <penguinite@tuta.io>
# Copyright © Leo Gavilieau 2022-2023 <xmoo@privacyrequired.com>
#
# This file is part of Onbox.
# 
# Onbox is free software: you can redistribute it and/or modify it under the terms of
# the GNU Affero General Public License as published by the Free Software Foundation,
# either version 3 of the License, or (at your option) any later version.
# 
# Onbox is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License
# for more details.
# 
# You should have received a copy of the GNU Affero General Public License
# along with Onbox. If not, see <https://www.gnu.org/licenses/>. 
import std/tables, shared, db_connector/db_postgres

## This module contains all database logic for handling reactions.
## Reactions include likes, favorites or whatever.
## They're flexible by design.

proc getReactions*(db: DbConn, post: string, limit = 40): Table[string, seq[string]] =
  ## Retrieves a Table of reactions for a post.
  ## Result consists of a table where the keys are the specific reaction and
  ## the value is a sequence of reactors.
  when dbEngine == "postgres":
    for row in db.getAllRows(sql("SELECT uid,reaction FROM reactions WHERE pid = ? " & $limit & ";"), post):
      result[row[1]].add(row[0])
  else: {.warning: "getReactions() unimplemented".}

proc getReactionsFast*(db: DbConn, post: string, limit = 40): seq[string] =
  ## Returns a list of reactions for a specific post.
  # TODO: Adding an extra for loop here seems dumb...
  # But getAllRows returns seq[Row] (which is like seq[seq[string]])
  when dbEngine == "postgres":
    for row in db.getAllRows(sql("SELECT uid FROM reactions WHERE pid = ? LIMIT " & $limit & ";"), post):
      result.add(row[0])
  else: {.warning: "getReactionsFast unimplemented.".}

proc getNumOfReactions*(db: DbConn, post: string): int =
  ## Return the number of reactions on a specific post.
  when dbEngine == "postgres":
    len(db.getAllRows(sql"SELECT 0 FROM reactions WHERE pid = ?;", post))
  else: {.warning: "getNumOfReactions() unimplemented".}

proc userReactedWith*(db: DbConn, user, post, reaction: string): bool =
  ## Return whether or not a user has reacted in a specific way to a post.
  when dbEngine == "postgres":
    db.getRow(
      sql"SELECT EXISTS(SELECT 0 FROM reactions WHERE pid = ? AND uid = ? AND reaction = ?);",
      post, user, reaction
    )[0] == "t"
  else: {.warning: "userReactedWith() unimplemented".}

proc userReacted*(db: DbConn, user, post: string): bool =
  ## Return whether or not a user has reacted to a post.
  ## The specific reaction used doesn't matter, if you'd
  ## like to check for that as well then use ``userReactedWith``
  when dbEngine == "postgres":
    db.getRow(
      sql"SELECT EXISTS(SELECT 0 FROM reactions WHERE pid = ? AND uid = ?);", post, user
    )[0] == "t"
  else: {.warning: "userReacted() unimplemented".}

proc addReaction*(db: DbConn, user, post, reaction: string) =
  ## Adds an individual reaction
  when dbEngine == "postgres":
    db.exec(sql"INSERT INTO reactions VALUES (?,?,?);",post,user,reaction)
  else: {.warning: "addReaction() unimplemented".}

proc removeReaction*(db: DbConn, user, post: string) =
  ## Removes a reactions from the database
  when dbEngine == "postgres":
    db.exec(sql"DELETE FROM reactions WHERE pid = ? AND uid = ?;",post,user)
  else: {.warning: "removeReaction() unimplemented".}
