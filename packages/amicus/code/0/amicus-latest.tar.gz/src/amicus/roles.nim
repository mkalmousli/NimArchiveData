## This module provides a nice abstraction over roles.
## It gives human readable identifiers.

type
  Roles* {.pure.} = enum
    Frozen = -1, ## Users with this role cannot post, login or do anything.
    Regular = 0, ## A normal user role, users without the approved but with this can't login but they do exist.
    Approved = 1, ## Users with this role can login, post and whatnot.
    Mod = 2, ## This role can freeze users and mark posts as deleted.
    Admin = 3, ## This role can do anything
    Bot = 4, ## This role has no special purpose but it has a mark signalling that its controlled by an automated program.
    Group = 5, ## This role also has no special roles, it is also distinguishe.
    Private = 6, ## Users with this role verify people before letting them follow them.

runnableExamples:
  import amicus
  assert int(Roles.Admin) == 3