# Copyright © penguinite 2024-2025 <penguinite@tuta.io>
#
# This file is part of Onbox.
# 
# Onbox is free software: you can redistribute it and/or modify it under the terms of
# the GNU Affero General Public License as published by the Free Software Foundation,
# either version 3 of the License, or (at your option) any later version.
# 
# Onbox is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License
# for more details.
# 
# You should have received a copy of the GNU Affero General Public License
# along with Onbox. If not, see <https://www.gnu.org/licenses/>. 
import private/strconv, db_connector/db_postgres, std/times, shared

## This module contains all database logic for handling hashtags!
## Including creation, retrieval, checking, updating and deletion

proc tagExists*(db: DbConn, tag: string): bool =
  ## Check if a tag exists or not
  when dbEngine == "postgres":
    db.getRow(
      sql"SELECT EXISTS(SELECT 0 FROM tag WHERE name = ?);", tag
    )[0] == "t"
  else: {.warning: "tagExists() unimplemented".}

proc getTagUrl*(db: DbConn, tag: string): string =
  ## Tags can have a url (such as a link to a blog post or article) associated
  ## with them. This procedure allows you to fetch that URL.
  when dbEngine == "postgres":
    db.getRow(sql"SELECT url FROM tag WHERE name = ?;", tag)[0]
  else: {.warning: "tagExists() unimplemented".}

proc getTagFollows*(db: DbConn, user: string, limit = 100): seq[string] =
  ## Return the set of tags that a user follows
  # TODO: Same problem as onbox/db/boosts.getBoostsQuick() where we have an extra for loop.
  when dbEngine == "postgres":
    for i in db.getAllRows(sql"SELECT following FROM tag_follows WHERE follower = ? LIMIT ?;", user, $(limit)):
      result.add(i[0])
  else: {.warning: "getTagFollows() unimplemented".}

proc followTag*(db: DbConn, user, tag: string) =
  ## Add a follow for a tag by a user
  ## 
  ## When a user follows a tag, posts that contain it will show up
  ## in their home timeline in chronological order with all other posts.
  when dbEngine == "postgres":
    db.exec(
      sql"INSERT INTO tag_follows VALUES (?,?);",
      user, tag
    )
  else: {.warning: "followTag() unimplemented".}

proc unfollowTag*(db: DbConn, user, tag: string) =
  ## Remove a follow for a tag by a user
  ## 
  ## In other words, this allows a user to stop having
  ## posts of a certain tag show up on their home timeline.
  when dbEngine == "postgres":
    db.exec(
      sql"DELETE FROM tag_follows WHERE follower = ? AND following = ?;",
      user, tag
    )
  else: {.warning: "unfollowTag() unimplemented".}

proc followsTag*(db: DbConn, user, tag: string): bool =
  ## Returns true if a user (supplied by ID) follows a hashtag
  when dbEngine == "postgres":
    db.getRow(
      sql"SELECT EXISTS(SELECT 0 FROM tag_follows WHERE follower = ? AND following = ?);",
      user, tag
    )[0] == "t"
  else: {.warning: "followsTag() unimplemented".}

proc createTag*(
    db: DbConn, name: string, url = "", desc = "",
    trendable = true, usable = true, requires_review = false, system = false
  ) =
  ## Creates a new tag object in the database
  ## 
  ## ``trendable`` allows you to control whether a tag is allowed to
  ## show up the in a trending set.
  ## 
  ## ``usable`` allows you to control whether users are allowed to create posts
  ## with this tag or not, administrators are exempt from this requirement
  ## 
  ## ``requires_review`` allows you to control whether or not this tag should be
  ## reviewed before being shown as usable.
  ## 
  ## ``system`` allows you to control whether or not this tag (or others) *must* be
  ## chosen for a post. This allows you to implement a sort-of forum system.
  ## Where each board is a ``system`` tag.
  # TODO: The features above aren't implemented. Implement them.
  when dbEngine == "postgres":
    db.exec(
      sql"INSERT INTO tag VALUES (?,?,?,?,?,?,?);",
      trendable, usable, requires_review, system,
      name, url, desc
    )
  else: {.warning: "createTag() unimplemented".}

proc hasTag*(db: DbConn, post, tag: string): bool =
  ## Check if a post has a tag.
  when dbEngine == "postgres":
    db.getRow(
      sql"SELECT EXISTS(SELECT 0 FROM posts WHERE id = ? AND tags @> ?);",
      post, !$([tag])
    )[0] == "t"
  else: {.warning: "hasTag() unimplemented".}

# For the next three procs
# Given that this API is called on startup by a staggering number of clients,
# The top priority was to increase performance as much as possible.
# And I believe I did the right thing here but in the future, we must re-evaluate.

proc getTagUsagePostNum*(db: DbConn, tag: string, days = 2): seq[int] =
  ## Returns the number of posts using a tag in the past couple X days.
  # Game plan:
  # Select all the posts that were last published in the past number of days
  # And that have the specific tag required.
  #
  # TODO: This is a bit ugly... Could we optimize it?
  # Still, way way better than the old code!
  when dbEngine == "postgres":
    for i in countup(0,days - 1):
      result.add len(db.getAllRows(
        sql"SELECT 0 FROM posts WHERE tags @> ? AND created = ?;",
        !$[tag], getDateStr(now().utc - i.days)
      ))
  else: {.warning: "getTagUsagePostNum() unimplemented".}

proc getTagUsageUserNum*(db: DbConn, tag: string, days = 2): seq[int] =
  ## Returns the number of accounts using a tag in the past couple X days
  # Game plan:
  # Select all the users who have been last writing posts
  # that included a certain tag in the past number of days.
  #
  # TODO: Whew, this is a bit uglier than getTagUsagePostNum()
  # Jesus...
  when dbEngine == "postgres":
    for i in countup(0,days - 1):
      result.add len(db.getAllRows(
        sql"SELECT DISTINCT ON (sender) 0 FROM posts WHERE tags @> ? AND use_date = ?;",
        !$[tag], getDateStr(now().utc - i.days)
      ))
  else: {.warning: "getTagUsageUserNum() unimplemented".}

proc getPostTags*(db: DbConn, post: string): seq[string] =
  ## Return the set of tags used on a post.
  when dbEngine == "postgres":
    toStrSeq(db.getRow(sql"SELECT tags FROM posts WHERE id = ?;", post)[0])
  else: {.warning: "getPostTags() unimplemented".}

proc getTagUsageDays*(days = 2): seq[int64]
  {.deprecated: "Do not use. May be removed.".} =  
  ## Used only for the Tag ApiEntity
  for i in countup(0,days - 1):
    result.add(toUnix(toTime(now().utc - i.days)))

# Test suite:
#[
# TODO: This code is quite old.

when isMainModule:
  import onbox/db/[users, posts], onbox/[conf, database]
  var config = setup(getConfigFilename())
  var deebee = setup(
    config.getDbName(),
    config.getDbUser(),
    config.getDbHost(),
    config.getDbPass()
  )

  var
    userA = newUser("a", true, "")
    userB = newUser("b", true, "")
    postA = newPost(userA.id, @[text("Badabing badaboom!"), hashtag("hi")])
    postB = newPost(userA.id, @[text("Badabing badaboom 2!"), hashtag("hi")])
    postC = newPost(userB.id, @[text("Badabing badaboom 3?"), hashtag("hi")])

  deebee.addUser(userA)
  deebee.addUser(userB)
  deebee.addPost(postA)
  deebee.addPost(postB)
  deebee.addPost(postC)
  

  if not deebee.tagExists("hi"):
    deebee.createTag("hi")
  echo deebee.getTagUsagePostNum("hi")
  echo deebee.getTagUsageUserNum("hi")
]#