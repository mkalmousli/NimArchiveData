# Copyright © penguinite 2024-2025 <penguinite@tuta.io>
#
# This file is part of Onbox.
# 
# Onbox is free software: you can redistribute it and/or modify it under the terms of
# the GNU Affero General Public License as published by the Free Software Foundation,
# either version 3 of the License, or (at your option) any later version.
# 
# Onbox is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
# FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License
# for more details.
# 
# You should have received a copy of the GNU Affero General Public License
# along with Onbox. If not, see <https://www.gnu.org/licenses/>. 
import private/[dbutils, strconv], std/[tables, times, strutils], db_connector/db_postgres, follows, shared

## This module contains all the logic for handling posts.
## 
## Including basic processing, database storage,
## database retrieval, modification, deletion and so on
## and so forth.

# Game plan when inserting a post:
# Insert the post
# Insert the post content
#
# Game plan when post is edited (text only):
# Create a new "text content" row in the db
# Update any other columns accordingly (Setting latest to false)
# Create a new "post content" row in the db and set it accordingly.
# Update any other attributes accordingly (For example, the client, the modified bool, the recipients, the level)

proc constructPost*(db: DbConn, row: Row): Post =
  ## Constructs a post out of a database row, minimally.
  ## This means no reactions, no boosts
  ## and no content.  
  when dbEngine == "postgres":
    var i: int = -1;
    for key,value in result.fieldPairs:
      # Skip the fields that are processed by *other* bits of code.
      when result.get(key) isnot Table[string, seq[string]] and result.get(key) isnot seq[PostContent]:
        inc(i)

      when result.get(key) is bool:
        result.get(key) = (row[i] == "t")
      when result.get(key) is string:
        result.get(key) = row[i]
      when result.get(key) is seq[string]:
        result.get(key) = toStrSeq(row[i])
      when result.get(key) is DateTime:
        result.get(key) = toDate(row[i])
      when result.get(key) is PostPrivacyLevel:
        result.get(key) = toLevel(row[i])
  else: {.warning: "constructPost() unimplemented.".}

proc newPost*(): Post =
  ## Create a new Post object and fill out some common fields.
  ## 
  ## Currently this procedure only fills out the ID field with a randomly
  ## generated UUID version 4.
  result.id = uuidv4()

proc addPost*(db: DbConn, post: Post) =
  ## A function to add a post into the database
  when dbEngine == "postgres":
    db.exec(
      sql"INSERT INTO posts VALUES (?,?,NULLIF(?,'')::UUID,NULLIF(?,'')::UUID,?,?,?,?,?);",
      post.id,
      post.sender,
      post.replyto,
      post.client,
      !$(post.written),
      $(post.level),
      post.local,
      !$(post.recipients),
      !$(post.tags)
    )

    # Handle post "contents"
    for content in post.content:
      case content.kind:
      of Text:
        # Insert post text
        db.exec(
          sql"INSERT INTO post_texts VALUES (?,?,?,?);",
          post.id,
          !$(content.txt_published),
          $(content.txt_format),
          content.text,
        )
      else:
        # If you encounter this error then flag it immediately to the devs.
        raise newException(DbError, "Unknown post content type: " & $(content.kind))
  else: {.warning: "addPost() unimplemented".}

proc postIdExists*(db: DbConn, id: string): bool =
  ## A function to see if a post id exists in the database
  when dbEngine == "postgres":
    db.getRow(
      sql"SELECT EXISTS(SELECT 0 FROM posts WHERE id = ?);", id
    )[0] == "t"
  else: {.warning: "postIdExists() unimplemented".}

proc updatePost*(db: DbConn, id, column, value: string) =
  ## A procedure to update a post using it's ID.
  ## Like with the updateUserByHandle and updateUserById procedures,
  ## the value parameter should be heavily sanitized and escaped to prevent a class of awful security holes.
  ## The id can be passed plain, it will be escaped.
  when dbEngine == "postgres":
    db.exec(sql("UPDATE posts SET " & column & " = ? WHERE id = ?;"), value, id)
  else: {.warning: "updatePost() unimplemented".}

proc getPost*(db: DbConn, id: string): Row =
  ## Retrieve a post using an ID.
  ## 
  ## You will need to pass this on further to constructPost()
  ## or its semi and full variants. As this just returns a database row.
  when dbEngine == "postgres":
    db.getRow(sql"SELECT * FROM posts WHERE id = ?;", id)
  else: {.warning: "getPost() unimplemented".}

proc getPostsByUser*(db: DbConn, id: string, limit: int = 15): seq[string] = 
  ## A procedure that only fetches the IDs of posts made by a specific user.
  ## This is used to quickly get a list over every post made by a user, for, say,
  ## onboxctl or an Onbox admin frontend.
  when dbEngine == "postgres":
    var sqlStatement = "SELECT id FROM posts WHERE sender = ?"

    if limit != 0: sqlStatement.add(" LIMIT " & $limit & ";")
    else: sqlStatement.add(";")

    for post in db.getAllRows(sql(sqlStatement), id):
      result.add(post[0])
  else: {.warning: "getPostsByUser() unimplemented".}

proc getNumPostsByUser*(db: DbConn, id: string): int =
  ## Returns the number of posts made by a specific user.
  when dbEngine == "postgres":
    len(db.getAllRows(sql"SELECT 0 FROM posts WHERE sender = ?;", id))
  else: {.warning: "getNumPostsByUser() unimplemented".}

proc getPostText*(db: DbConn, id: string): PostContent =
  ## Returns the latest draft/text of a post.
  when dbEngine == "postgres":
    let row = db.getRow(sql"SELECT published,format,content FROM post_texts WHERE pid = ? ORDER BY published DESC;", id)
    return PostContent(
      kind: Text,
      txt_published: toDate(row[0]),
      txt_format: parseInt(row[1]),
      text: row[2]
    )
  else: {.warning: "getPostText() unimplemented".}

proc getNumTotalPosts*(db: DbConn, local = true): int =
  ## A procedure to get the total number of posts. You can choose where or not they should be local-only with the local parameter.
  when dbEngine == "postgres":
    case local:
    of true: return len(db.getAllRows(sql("SELECT 0 FROM posts WHERE is_local = true;")))
    of false: return len(db.getAllRows(sql("SELECT 0 FROM posts;")))
  else: {.warning: "getNumTotalPosts() unimplemented".}

proc deletePost*(db: DbConn, id: string) = 
  ## Deletes a post from the database
  when dbEngine == "postgres":
    db.exec(sql"DELETE FROM bookmarks WHERE pid = ?;", id)
    db.exec(sql"DELETE FROM reactions WHERE pid = ?;", id)
    db.exec(sql"DELETE FROM boosts WHERE pid = ?;", id)
    db.exec(sql"DELETE FROM post_embeds WHERE pid = ?;", id)
    db.exec(sql"DELETE FROM post_texts WHERE pid = ?;", id)
    db.exec(sql"DELETE FROM posts WHERE id = ?;", id)
  else: {.warning: "deletePost() unimplemented".}

proc getNumOfReplies*(db: DbConn, post_id: string): int =
  ## Get the number of replies a post has
  when dbEngine == "postgres":
    len(db.getAllRows(sql"SELECT 0 FROM posts WHERE replyto = ?;", post_id))
  else: {.warning: "getNumOfReplies() unimplemented".}

proc getPostSender*(db: DbConn, post_id: string): string =
  ## Get the user ID of the person who sent the post
  when dbEngine == "postgres":
    db.getRow(sql"SELECT sender FROM posts WHERE id = ?;", post_id)[0]
  else: {.warning: "getPostSender() unimplemented".}

proc updatePostSender*(db: DbConn, post_id, sender: string) =
  ## Updates the `sender` for any post
  ## 
  ## Used when deleting users, since we can save on processing costs
  ## by marking posts as "deleted" or "unavailable"
  ## (And this, we do by setting the sender to null)
  when dbEngine == "postgres":
    db.exec(sql"UPDATE posts SET sender = ? WHERE id = ?;", sender, post_id)
  else: {.warning: "updatePostSender() unimplemented".}

proc getLocalPosts*(db: DbConn, limit: int = 15): seq[string] =
  ## A procedure to get posts from local users only.
  ## Set limit to 0 to disable the limit and get all posts from local users.
  ## 
  ## This returns seq[Row], so you might want to pass it on to a constructPost() like proc.
  when dbEngine == "postgres":
    var sqlStatement = "SELECT id FROM posts WHERE is_local = TRUE"
    if limit != 0:
      sqlStatement.add(" LIMIT " & $limit)

    for post in db.getAllRows(sql(sqlStatement & ";")):
      result.add(post[0])
  else: {.warning: "getLocalPosts() unimplemented".}

import packages/docutils/[rst, rstgen], std/strtabs

proc contentToHtml*(content: PostContent): string =
  ## Converts a PostContent object into safe, sanitized HTML. Ready for displaying!
  when dbEngine == "postgres":
    case content.kind:
    of Text:
      ## TODO: Add support for HTML, ie. do HTML sanitization the way that Mastodon does it.
      case content.txt_format:
      of 0: # Text, plain
        result.add("<p>" & htmlEscape(content.text) & "</p>")
      of 1: # Markdown
        result.add(rstToHtml(
            htmlEscape(content.text), {roPreferMarkdown}, newStringTable()
          )
        )
      of 2: # ReStructuredText
        result.add(
          rstToHtml(htmlEscape(content.text), {}, newStringTable())
        )
      else: raise newException(ValueError, "Unexpected text format: " & $(content.txt_format))
    else: raise newException(ValueError, "Unexpected content type: " & $(content.kind))
  else: {.warning: "contentToHtml() unimplemented".}

proc getPostPrivacyLevel*(db: DbConn, id: string): PostPrivacyLevel =
  ## Return the privacy level of a post
  when dbEngine == "postgres":
    toLevel(db.getRow(sql"SELECT privacy_level FROM posts WHERE id = ?;", id)[0])
  else: {.warning: "getPostPrivacyLevel() unimplemented".}

proc getRecipients*(db: DbConn, pid: string): seq[string] =
  ## Returns the recipients of a post in a string sequence containing user IDs
  when dbEngine == "postgres":
    toStrSeq(db.getRow(sql"GET recipients FROM posts WHERE id = ?;", pid)[0])
  else: {.warning: "getRecipients() unimplemented".}

proc canSeePost*(db: DbCOnn, uid, pid: string, level: PostPrivacyLevel): bool =
  ## A procedure that calculates whether or not a user is allowed to see a post or not.
  ## 
  ## This procedure is meant to be used in a normal timeline, not in a post overview type of menu.
  case level:
  of Public, Unlisted:
    # Of course the user is allowed to see these...
    return true
  of FollowersOnly:
    # Check if user is following sender
    # If so, then yes, they can see the post.
    return db.getFollowStatus(uid, db.getPostSender(pid)) == AcceptedFollowRequest
  of Limited, Private:
    # TODO: Limited is different from Private but the MastoAPI docs don't clarify hpw.
    # Please figure out the difference and fix this bug.
    # For now, we will check if the user has been directly mentioned in the post they
    # want to see.
    return uid in db.getRecipients(pid)
  of Deleted:
    return false

proc idempotencyCheck*(db: DbConn, user, content: string): bool =
  ## Returns true if a user has written a post with this content
  ## an hour ago.
  ## TODO: THIS IS NOT TRUE IDEMPOTENCY!!!
  return false #TODO :Implemented

# Imagine a post structure like so:
#   1. Pigeon: Someone just dropped bread at the local pond.
#   ├── 2. Penguin: What about fish guts? It's way better than bread.
#   │   ├── 3. Duck: You make me sick!
#   |   ├──── 4. Goose: Honk
#   │   └── 5. Seagull: All food is good food
#   └── 6. Goose: Honk
#       ├── 7. Pigeon: Yes, I completely understand
#       │   └── 8. Duck: Someone should tell him to turn off voice recognition
#       └── 9. Penguin: Insightful commentary.
#
# Amicus provides two procedures to trying to parse this type of post tree.
#   - getPostChildren()
#   - getPostParents()
# 
# getPostChildren() returns direct descendants only, in other words.
# All posts that have a `replyto` field which matches the post ID given to us.
# (In other, other words, the top-level replies to a post)
# getPostParents() returns any and all parents to a post (at great depths too)
# 
# So, using getPostChilren() on post 1 here would give us back post 2 and 6.
# Whilst using it on post 7 would yield only post 8, and using it on post 4
# would yield nothing at all.
#
# using getPostParents() on:
#   - post 1 would return nothing (post 1 isn't a reply)
#   - post 4 would yield 3,2,1 (in that order)
#   - post 7 would yield 6,1
#   - post 8 would yield 7,6,1
#
# With these two procedures, you can navigate a post structure pretty seamlessly.

proc getPostChildren*(db: DbConn, id: string, limit = 60): seq[string] =
  for row in db.getAllRows(sql("SELECT id FROM posts WHERE privacy_level != -1 AND replyto = ? LIMIT " & $limit & ";"), id):
    result.add(row[0])

proc getPostParents*(db: DbConn, id: string, limit = 20): seq[string] =
  var curId = id
  for cur in 0..limit:
    let row = db.getRow(sql"SELECT replyto FROM posts WHERE id = ?;", curId)[0]
    if row == "" or row == nullUuid:
      break
    if cur == limit:
      break
    result.add(row)
    curId = row