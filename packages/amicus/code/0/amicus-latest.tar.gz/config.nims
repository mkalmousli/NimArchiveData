switch("path","./src")
switch("d", "useMalloc") # Required for fixing memory leak.