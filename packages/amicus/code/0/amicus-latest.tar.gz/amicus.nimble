# Package

version       = "0.0.2"
author        = "penguinite"
description   = "Social networking library powering Onbox."
license       = "AGPL-3.0-or-later"
srcDir        = "src"

# Dependencies
requires "nim >= 2.0.0"
requires "nimcrypto >= 0.6.3"
requires "db_connector >= 0.1.0"