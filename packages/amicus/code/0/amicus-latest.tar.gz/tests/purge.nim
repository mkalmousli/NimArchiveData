{.define: amicusDebug.}
import amicus/debug

var db = openDb()

purgeEverything(db)