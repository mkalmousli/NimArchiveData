{.define: amicusDebug.}
import amicus/debug, std/times

var db = openDb()

let id = db.createClient(
  "tootcli", "https://tootcli.internal/",
  @["read", "write"],
  @["urn:ietf:wg:oauth:2.0:oob"]
)[0]

assert db.clientExists(id)

let user = createUser(
  handle = "john",
  local = true,
  password = "SOMETHING_SECET",
  domain = ""
)

db.insertUser(user)
assert db.userIdExists(user.id)

let
  date = now().utc
  code = db.createAuthCode(
    user.id,
    id,
    @["read", "write"],
    date = date
  )

# Now for the actual test

# Comparing dates is a bit... iffy...
# Nim's DateTime type is quite precise
# and the type we get from the database
# usually doesn't include nanoseconds.

# So we have to make our own comparator
# because std/times doesn't ship a "weaker" comparator.
# Thanks Nim!

proc `===`*(a,b: DateTime): bool =
  ## A comparator for DateTime objects that skips the nanosecond range,
  ## the timestamp returned by the database is often not so precise compared
  ## to the native Nim timestamp.
  # Comparing two DateTime objects is:
  #  a.toTime == b.toTime
  # And comparing two Time objects is.
  #  a.seconds == b.seconds
  #  a.nanoseconds == b.nanoseconds
  # We have no need for nanoseconds
  return toUnix(toTime(a)) == toUnix(toTime(a))

assert db.getAuthCodeDate(code) === date

# Cleanup

db.deleteAuthCode(code)
assert not db.authCodeExists(code)

db.deleteClient(id)
assert not db.clientExists(id)

db.deleteUser(user.id)
assert not db.userIdExists(user.id)

db.closeDb()