{.define: amicusDebug.}
import amicus/debug, std/times

var db = openDb()

let id = db.createClient(
  "tootcli", "https://tootcli.internal/",
  @["read", "write"],
  @["urn:ietf:wg:oauth:2.0:oob"]
)[0]

assert db.clientExists(id)

let user = createUser(
  handle = "john",
  local = true,
  password = "SOMETHING_SECET",
  domain = ""
)

db.insertUser(user)
assert db.userIdExists(user.id)

let
  date = now().utc
  code = db.createAuthCode(
    user.id,
    id,
    @["read", "write"],
    date = date
  )

# Now for the actual test

db.deleteAuthCode(code)
assert not db.authCodeExists(code)
assert not db.authCodeExists(user.id, id)
assert not db.authCodeValid(code)

# Cleanup

db.deleteClient(id)
assert not db.clientExists(id)

db.deleteUser(user.id)
assert not db.userIdExists(user.id)

db.closeDb()