{.define: amicusDebug.}
import amicus/debug, std/times

var db = openDb()

let id = db.createClient(
  "tootcli", "https://tootcli.internal/",
  @["read", "write"],
  @["urn:ietf:wg:oauth:2.0:oob"]
)[0]

assert db.clientExists(id)

let user = createUser(
  handle = "john",
  local = true,
  password = "SOMETHING_SECET",
  domain = ""
)

db.insertUser(user)
assert db.userIdExists(user.id)

# Note: Here we want to create intentionally
# invalid auth codes, but thanks to foreign keys,
# it's hard to create auth codes that don't have
# a valid user or a valid client.
#
# deleteUser() and deleteClient() can't just leave out
# data that references the old user or client because
# that'll make our database weep and sob.
# So, the checks for invalid users and clients
# literally cannot be satisfied.
#
# TODO: Either add a way to test for them here or
# remove those checks in authCodeValid()
# (Since they're not gonna happen either way)

let
  reallyInvalidCode = db.createAuthCode(
    user.id,
    id,
    @["read", "write"],
    date = now().utc - initDuration(days = 7) 
  )

  invalidCode = db.createAuthCode(
    user.id,
    id,
    @["read", "write"],
    date = now().utc - initDuration(days = 1) 
  )

  validCode = db.createAuthCode(
    user.id,
    id,
    @["read", "write"],
  )

  timeTravelerCode = db.createAuthCode(
    user.id,
    id,
    @["read", "write"],
    date = now().utc + initDuration(days = 7) 
  )

assert db.authCodeExists(reallyInvalidCode)
assert db.authCodeExists(invalidCode)
assert db.authCodeExists(validCode)
assert db.authCodeExists(timeTravelerCode)

assert not db.authCodeValid(reallyInvalidCode)
assert not db.authCodeValid(invalidCode)
assert db.authCodeValid(validCode)
assert not db.authCodeValid(timeTravelerCode)

# Cleanup

for code in @[
  reallyInvalidCode, invalidCode, validCode, timeTravelerCode
]:
  db.deleteAuthCode(code)
  assert not db.authCodeExists(code)

db.deleteClient(id)
assert not db.clientExists(id)

db.deleteUser(user.id)
assert not db.userIdExists(user.id)

db.closeDb()