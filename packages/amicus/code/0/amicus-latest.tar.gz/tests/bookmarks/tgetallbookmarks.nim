{.define: amicusDebug.}
import amicus/debug, std/[times, tables]

var db = openDb()

let user = createUser(
  handle = "john",
  local = true,
  password = "SOMETHING_SECRET",
  domain = ""
)

db.insertUser(user)

assert db.userIdExists(user.id)

var post = newPost()
post.sender = user.id
post.replyto = ""
post.client = ""
post.written = now().utc
post.level = Public
post.local = true
post.recipients = @[]
post.tags = @["cats", "dogs", "creatures"]
post.content = @[PostContent(
  kind: Text,
  txt_published: now().utc,
  txt_format: 0,
  text: "Hello World!"
)]

post.reactions = initTable[string, seq[string]]()
post.boosts = initTable[string, seq[string]]()
db.addPost(post)

# Now for the test

db.bookmarkPost(user.id, post.id)
assert db.bookmarkExists(user.id, post.id)

assert db.getAllBookmarks(user.id) == @[post.id]

# Cleanup

db.unbookmarkPost(user.id, post.id)
assert not db.bookmarkExists(user.id, post.id)

db.deletePost(post.id)
assert not db.postIdExists(post.id)

db.deleteUser(user.id)
assert not db.userIdExists(user.id)


db.closeDb()