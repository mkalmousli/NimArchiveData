{.define: amicusDebug.}
import amicus/debug, std/[times, tables]

var db = openDb()

var user = createUser(
  handle = "cosmo",
  local = true,
  password = "",
  domain = ""
)

user.bio = "boku wa umare soshite kidzuku\nshosen hito no manegato da to\nshite nao mo utai tsudzuku\ntowa no inochi\nVOCALOID"

db.insertUser(user)
assert db.userIdExists(user.id)

db.insertField(user.id, "most known for", "THE END OF HATSUNE MIKU")
db.insertField(user.id, "professions", "music composer, artist")
db.insertField(user.id, "website", "https://chemsys.cc/")

let date = now().utc

db.verifyField(user.id, "website", "https://chemsys.cc/", date)
# Comparing dates is a bit... iffy...
# Nim's DateTime type is quite precise
# and the type we get from the database
# usually doesn't include nanoseconds.

# So we have to make our own comparator
# because std/times doesn't ship a "weaker" comparator.
# Thanks Nim!

proc `===`*(a,b: DateTime): bool =
  ## A comparator for DateTime objects that skips the nanosecond range,
  ## the timestamp returned by the database is often not so precise compared
  ## to the native Nim timestamp.
  # Comparing two DateTime objects is:
  #  a.toTime == b.toTime
  # And comparing two Time objects is.
  #  a.seconds == b.seconds
  #  a.nanoseconds == b.nanoseconds
  # We have no need for nanoseconds
  return toUnix(toTime(a)) == toUnix(toTime(a))

let fields = db.getFields(user.id)
assert len(fields) >= 3
assert fields[0].key == "most known for"
assert fields[0].val = "THE END OF HATSUNE MIKU"
assert fields[0].verified == false

assert fields[1].key == "professions"
assert fields[1].val = "music composer, artist"
assert fields[1].verified == false

assert fields[2].key == "website"
assert fields[2].val = "https://chemsys.cc/"
assert fields[2].verified == true
assert fields[2].verified_at === date

# Cleanup

db.removeField(user.id, "most known for", "THE END OF HATSUNE MIKU")
db.removeField(user.id, "professions", "music composer, artist")
db.removeField(user.id, "website", "https://chemsys.cc/")
assert not db.fieldExists(user.id, "most known for", "THE END OF HATSUNE MIKU")
assert not db.fieldExists(user.id, "professions", "music composer, artist")
assert not db.fieldExists(user.id, "website", "https://chemsys.cc/")

db.deleteUser(user.id)
assert not db.userIdExists(user.id)

db.closeDb()