{.define: amicusDebug.}
import amicus/debug, std/[times, tables]

var db = openDb()

var user = createUser(
  handle = "cosmo",
  local = true,
  password = "",
  domain = ""
)

user.bio = "boku wa umare soshite kidzuku\nshosen hito no manegato da to\nshite nao mo utai tsudzuku\ntowa no inochi\nVOCALOID"

db.insertUser(user)
assert db.userIdExists(user.id)

db.insertField(user.id, "most known for", "THE END OF HATSUNE MIKU")
db.insertField(user.id, "professions", "music composer, artist")
db.insertField(user.id, "website", "https://chemsys.cc/")

assert db.fieldExists(user.id, "most known for", "THE END OF HATSUNE MIKU")
assert db.fieldExists(user.id, "professions", "music composer, artist")
assert db.fieldExists(user.id, "website", "https://chemsys.cc/")

# Cleanup

db.removeField(user.id, "most known for", "THE END OF HATSUNE MIKU")
db.removeField(user.id, "professions", "music composer, artist")
db.removeField(user.id, "website", "https://chemsys.cc/")
assert not db.fieldExists(user.id, "most known for", "THE END OF HATSUNE MIKU")
assert not db.fieldExists(user.id, "professions", "music composer, artist")
assert not db.fieldExists(user.id, "website", "https://chemsys.cc/")

db.deleteUser(user.id)
assert not db.userIdExists(user.id)

db.closeDb()