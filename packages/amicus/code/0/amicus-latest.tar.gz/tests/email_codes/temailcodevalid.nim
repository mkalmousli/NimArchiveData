{.define: amicusDebug.}
import amicus/debug, std/[times]

var db = openDb()

let userA = createUser(
  handle = "miku",
  local = true,
  password = "OO_EE_OO",
  domain = ""
)

let userB = createUser(
  handle = "miku",
  local = true,
  password = "OO_EE_OO",
  domain = ""
)

db.insertUser(userA)
assert db.userIdExists(userA.id)
db.insertUser(userB)
assert db.userIdExists(userB.id)

# Now for the test

var code = ""

# Valid
code = db.createEmailCode(userA.id)
assert db.emailCodeValid(code, userA.id)
db.deleteEmailCode(code)
assert not db.emailCodeValid(code, userA.id)

# Invalid (too old)
code = db.createEmailCode(userA.id, now().utc + initDuration(days = 7))
assert not db.emailCodeValid(code, userA.id)
db.deleteEmailCode(code)
assert not db.emailCodeValid(code, userA.id)

# Invalid (user mismatch)
code = db.createEmailCode(userA.id)
assert not db.emailCodeValid(code, userB.id)
db.deleteEmailCode(code)
assert not db.emailCodeValid(code, userB.id)

# Invalid (code not found)
code = db.createEmailCode(userA.id)
db.deleteEmailCode(code)
assert not db.emailCodeValid(code, userA.id)

# Cleanup

db.deleteUser(userA.id)
assert not db.userIdExists(userA.id)
db.deleteUser(userB.id)
assert not db.userIdExists(userB.id)

db.closeDb()