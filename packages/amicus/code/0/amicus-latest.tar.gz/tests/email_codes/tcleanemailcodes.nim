{.define: amicusDebug.}
import amicus/debug, std/times

var db = openDb()

let user = createUser(
  handle = "miku",
  local = true,
  password = "OO_EE_OO",
  domain = ""
)

db.insertUser(user)
assert db.userIdExists(user.id)

# Now for the test

var
  codeA = db.createEmailCode(user.id, now().utc + initDuration(days = 7))
  codeB = db.createEmailCode(nullUuid)

assert db.emailCodeExists(codeA)
assert db.emailCodeExists(codeB)

db.cleanEmailCodes()

assert not db.emailCodeExists(codeA)
assert not db.emailCodeExists(codeB)

# Cleanup

db.deleteUser(user.id)
assert not db.userIdExists(user.id)

db.closeDb()