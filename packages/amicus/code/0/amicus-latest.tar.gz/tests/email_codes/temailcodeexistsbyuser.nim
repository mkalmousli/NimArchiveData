{.define: amicusDebug.}
import amicus/debug

var db = openDb()

let user = createUser(
  handle = "miku",
  local = true,
  password = "OO_EE_OO",
  domain = ""
)

db.insertUser(user)
assert db.userIdExists(user.id)

# Now for the test

let code = db.createEmailCode(user.id)
assert db.emailCodeExists(code)
assert db.emailCodeExistsByUser(user.id)
db.deleteEmailCode(code)
assert not db.emailCodeExists(code)
assert not db.emailCodeExistsByUser(user.id)

# Cleanup

db.deleteUser(user.id)
assert not db.userIdExists(user.id)

db.closeDb()