{.define: amicusDebug.}
import amicus/debug, std/times

var db = openDb()

let user = createUser(
  handle = "miku",
  local = true,
  password = "OO_EE_OO",
  domain = ""
)

db.insertUser(user)
assert db.userIdExists(user.id)

# Now for the test

var
  date = now().utc
  code = db.createEmailCode(user.id, date)

assert db.emailCodeValid(code, user.id)
assert db.emailCodeExists(code)
assert db.emailCodeExistsByUser(user.id)

proc `===`*(a,b: DateTime): bool =
  ## A comparator for DateTime objects that skips the nanosecond range,
  ## the timestamp returned by the database is often not so precise compared
  ## to the native Nim timestamp.
  # Comparing two DateTime objects is:
  #  a.toTime == b.toTime
  # And comparing two Time objects is.
  #  a.seconds == b.seconds
  #  a.nanoseconds == b.nanoseconds
  # We have no need for nanoseconds
  return toUnix(toTime(a)) == toUnix(toTime(a))

assert db.getUserFromEmailCode(code) == user.id
assert db.getEmailCodeAge(code) < initDuration(hours = 1)
assert db.getEmailCodeDate(code) === date

db.deleteEmailCode(code)
assert not db.emailCodeExists(code)

# Cleanup

db.deleteUser(user.id)
assert not db.userIdExists(user.id)

db.closeDb()