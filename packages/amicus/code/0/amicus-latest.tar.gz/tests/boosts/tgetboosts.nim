{.define: amicusDebug.}
import amicus/debug, std/[times, tables]

var db = openDb()

let user = createUser(
  handle = "john",
  local = true,
  password = "SOMETHING_SECRET",
  domain = ""
)

db.insertUser(user)
assert db.userIdExists(user.id)

var post = newPost()
post.sender = user.id
post.replyto = ""
post.client = ""
post.written = now().utc
post.level = Public
post.local = true
post.recipients = @[]
post.tags = @["cats", "dogs", "creatures", "nature"]
post.content = @[PostContent(
  kind: Text,
  txt_published: now().utc,
  txt_format: 0,
  text: "I EMBRACE ALL THE CREATURES BELONGING TO EARTH, THEY'RE ALL MINE!"
)]
post.reactions = initTable[string, seq[string]]()
post.boosts = initTable[string, seq[string]]()

db.addPost(post)
assert db.postIdExists(post.id)

db.addBoost(user.id, post.id, Public)
assert db.userBoostedLevel(user.id, post.id, Public)

# Now for the test


assert db.getBoosts(post.id).hasKey(Public)
assert not db.getBoosts(post.id).hasKey(Unlisted)
assert not db.getBoosts(post.id).hasKey(FollowersOnly)
assert db.getBoosts(post.id)[Public].len() == 1
assert db.getBoosts(post.id)[Public][0] == user.id
assert db.getBoosts(post.id)[Public] == @[user.id]

# Cleanup

db.removeBoost(user.id, post.id)
assert not db.userBoostedLevel(user.id, post.id, Public)
assert not db.userBoosted(user.id, post.id)

db.deletePost(post.id)
assert not db.postIdExists(post.id)

db.deleteUser(user.id)
assert not db.userIdExists(user.id)

db.closeDb()