{.define: amicusDebug.}
import amicus/debug, std/[times, tables]

var db = openDb()

proc mkUser(handle: string): User =
  result = createUser(
    handle = handle,
    local = true,
    password = "SOMETHING_SECRET",
    domain = ""
  )

  db.insertUser(result)
  assert db.userIdExists(result.id)

var
  userA = mkUser("john")
  userB = mkUser("jerry")
  userC = mkUser("miku")

var post = newPost()
post.sender = userA.id
post.replyto = ""
post.client = ""
post.written = now().utc
post.level = Public
post.local = true
post.recipients = @[userB.id, userC.id]
post.tags = @["cats", "dogs", "creatures", "nature"]
post.content = @[PostContent(
  kind: Text,
  txt_published: now().utc,
  txt_format: 0,
  text: "I EMBRACE ALL THE CREATURES BELONGING TO EARTH, THEY'RE ALL MINE!"
)]
post.reactions = initTable[string, seq[string]]()
post.boosts = initTable[string, seq[string]]()

db.addPost(post)
assert db.postIdExists(post.id)

# Now for the test

# Here we test what kinds of levels we can use in a boost.
# We expect to be able to use Public, Unlisted and FollowersOnly
# as per the documentation for `addBoost`

db.addBoost(userA.id, post.id, Public)
assert db.userBoosted(userA.id, post.id)
assert db.getNumBoosts(post.id) == 1

db.addBoost(userB.id, post.id, Public)
assert db.userBoosted(userB.id, post.id)
assert db.getNumBoosts(post.id) == 2

db.addBoost(userC.id, post.id, Public)
assert db.userBoosted(userC.id, post.id)
assert db.getNumBoosts(post.id) == 3

# Cleanup

db.removeBoost(userA.id, post.id)
assert not db.userBoostedLevel(userA.id, post.id, Public)
assert not db.userBoosted(userA.id, post.id)

db.removeBoost(userB.id, post.id)
assert not db.userBoostedLevel(userB.id, post.id, Public)
assert not db.userBoosted(userB.id, post.id)

db.removeBoost(userC.id, post.id)
assert not db.userBoostedLevel(userC.id, post.id, Public)
assert not db.userBoosted(userC.id, post.id)

db.deletePost(post.id)
assert not db.postIdExists(post.id)

db.deleteUser(userA.id)
assert not db.userIdExists(userA.id)

db.deleteUser(userB.id)
assert not db.userIdExists(userB.id)

db.deleteUser(userC.id)
assert not db.userIdExists(userC.id)

db.closeDb()