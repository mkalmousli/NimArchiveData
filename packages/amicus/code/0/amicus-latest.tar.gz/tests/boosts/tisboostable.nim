{.define: amicusDebug.}
import amicus/debug, std/[times, tables]

var db = openDb()

let user = createUser(
  handle = "john",
  local = true,
  password = "SOMETHING_SECRET",
  domain = ""
)

db.insertUser(user)
assert db.userIdExists(user.id)

proc postWithLevel(l: PostPrivacyLevel): Post =
  result = newPost()
  result.sender = user.id
  result.replyto = ""
  result.client = ""
  result.written = now().utc
  result.level = l
  result.local = true
  result.recipients = @[]
  result.tags = @["cats", "dogs", "creatures", "nature"]
  result.content = @[PostContent(
    kind: Text,
    txt_published: now().utc,
    txt_format: 0,
    text: "I EMBRACE ALL THE CREATURES BELONGING TO EARTH, THEY'RE ALL MINE!"
  )]
  result.reactions = initTable[string, seq[string]]()
  result.boosts = initTable[string, seq[string]]()
  return result

var
  publicPost = postWithLevel(Public)
  unlistedPost = postWithLevel(Unlisted)
  followersOnlyPost = postWithLevel(FollowersOnly)
  limitedPost = postWithLevel(Limited)
  privatePost = postWithLevel(Private)
  deletedPost = postWithLevel(Deleted)

for post in @[publicPost, unlistedPost, followersOnlyPost, limitedPost, privatePost, deletedPost]:
  db.addPost(post)
  assert db.postIdExists(post.id)

# Now for the test

assert db.isBoostable(publicPost.id)
assert db.isBoostable(unlistedPost.id)

assert not db.isBoostable(followersOnlyPost.id)
assert not db.isBoostable(limitedPost.id)
assert not db.isBoostable(privatePost.id)
assert not db.isBoostable(deletedPost.id)

# Cleanup

for post in @[publicPost, unlistedPost, followersOnlyPost, limitedPost, privatePost, deletedPost]:
  db.deletePost(post.id)
  assert not db.postIdExists(post.id)

db.deleteUser(user.id)
assert not db.userIdExists(user.id)

db.closeDb()