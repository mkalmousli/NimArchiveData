{.define: amicusDebug.}
import amicus/debug

assert getBroadScope("read:status") == "read"
assert getBroadScope("admin:read:domain_blocks") == "admin:read"
assert getBroadScope("write:follows") == "write"
assert getBroadScope("admin:write:rules") == "admin:write"
assert getBroadScope("push") == "push"
assert getBroadScope("crypto") == "crypto"

