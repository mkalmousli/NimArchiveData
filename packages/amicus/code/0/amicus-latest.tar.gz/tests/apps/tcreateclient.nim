{.define: amicusDebug.}
import amicus/debug

var db = openDb()

let (id, secret) = db.createClient(
  "tootcli", "https://tootcli.internal/",
  @["read", "write"],
  @["urn:ietf:wg:oauth:2.0:oob"]
)

assert db.getClientLink(id) == "https://tootcli.internal/"
assert db.getClientName(id) == "tootcli"
assert db.getClientSecret(id) == secret
assert db.getClientScopes(id) == @["read", "write"]
assert db.getClientUris(id) == @["urn:ietf:wg:oauth:2.0:oob"]
assert db.clientExists(id)
assert db.hasScope(id, "read")
assert db.hasScope(id, "write")
assert db.hasScopes(id, @["read", "write"])

db.deleteClient(id)
assert not db.clientExists(id)

db.closeDb()