{.define: amicusDebug.}
import amicus/debug

assert scopeValid("read") == true
assert scopeValid("read:statuses") == true
assert scopeValid("end:the:world") == false