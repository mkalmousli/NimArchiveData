{.define: amicusDebug.}
import amicus/debug

var db = openDb()

let id = db.createClient(
  "tootcli", "https://tootcli.internal/",
  @["read", "write"],
  @["urn:ietf:wg:oauth:2.0:oob"]
)[0]

assert db.getClientLink(id) == "https://tootcli.internal/"
db.deleteClient(id)

db.closeDb()