{.define: amicusDebug.}
import amicus/debug

var db = openDb()

let (id, secret) = db.createClient(
  "tootcli", "https://tootcli.internal/",
  @["read", "write"],
  @["urn:ietf:wg:oauth:2.0:oob"]
)

assert db.getClientSecret(id) == secret

db.deleteClient(id)

db.closeDb()