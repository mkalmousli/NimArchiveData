{.define: amicusDebug.}
import amicus/debug

var db = openDb()

let id = db.createClient(
  "tootcli", "https://tootcli.internal/",
  @["read", "write", "admin:read", "admin:write", "push", "profile"],
  @["urn:ietf:wg:oauth:2.0:oob"]
)[0]

assert db.hasScope(id, "read")
assert db.hasScope(id, "write")
assert db.hasScope(id, "read:statuses")
assert db.hasScope(id, "write:statuses")
assert db.hasScope(id, "read:follows")
assert db.hasScope(id, "write:follows")
assert db.hasScope(id, "read:search")
assert db.hasScope(id, "write:search")
assert db.hasScope(id, "admin:read")
assert db.hasScope(id, "admin:write")
assert db.hasScope(id, "admin:read:accounts")
assert db.hasScope(id, "admin:write:reports")
assert db.hasScope(id, "admin:read:domain_blocks")
assert db.hasScope(id, "admin:write:email_domain_blocks")

assert not db.hasScope(id, "delete:onbox:org")
assert not db.hasScope(id, "end:the:world")
assert not db.hasScope(id, "grant:wishes")
assert not db.hasScope(id, "rm:rf")

db.deleteClient(id)

db.closeDb()