{.define: amicusDebug.}
import amicus/debug

var db = openDb()

let id = db.createClient(
  "tootcli", "https://tootcli.internal/",
  @["read", "write"],
  @[
    "urn:ietf:wg:oauth:2.0:oob",
    "https://example.com/onbox/"
  ]
)[0]

assert "urn:ietf:wg:oauth:2.0:oob" in db.getClientUris(id)
assert "https://example.com/onbox/" in db.getClientUris(id)
assert db.getClientUris(id).len() == 2

db.deleteClient(id)

db.closeDb()