{.define: amicusDebug.}
import amicus/debug

assert humanizeScope("read") == "Full read access to everything except admin actions."
assert humanizeScope("admin:read") == "Full read access to everything admin-related."
assert humanizeScope("push") == "Access to push notifications."
assert humanizeScope("end:the:world") == "Unknown scope."