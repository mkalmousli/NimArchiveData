# Alternative German API
import std/[strformat]
import holidapi/api/feiertageapi

let response: OrderedTable[GermanState, seq[Holiday]] = getAllHolidays(2024)

for state, holidays in response:
    echo &"Holidays for state {state}:"
    for i, holiday in holidays:
        echo &"{i}: {holiday.name}"
