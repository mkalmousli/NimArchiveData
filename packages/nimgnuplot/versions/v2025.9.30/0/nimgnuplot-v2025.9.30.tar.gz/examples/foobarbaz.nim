import std/sugar
import std/tables
import std/strformat

import datamancer
import nimgnuplot

const
    COL_COLORS = {
        "foo": "red",
        "bar": "web-green",
        "baz": "blue",
    }.toTable

    COL_NAMES = {
        "foo": "Fooregard",
        "bar": "Barrington",
        "baz": "Bazarang",
    }.toTable

    COL_POINT_TYPES = {
        "foo": 7,
        "bar": 9,
        "baz": 5,
    }.toTable

var g = initGnuplotScript()

g.cmd """
    set terminal svg size 850,500 dynamic background rgb 'white'
    set style fill solid 1.0
    set title 'Foo, Bar, \& Baz by Day' font ',20'
    set xlabel 'Day' center
    set ylabel 'Amount' center rotate by 90
    set key at graph 0.5,1.04 horizontal center width -2
    set border lw 2
    set yrange [0:80]
    set xtics nomirror
    set ytics nomirror
"""

let colHeaders = g.addData("foobarbaz", readCsv("foobarbaz.csv"))
let plotElements = collect:
    for col in colHeaders[1 .. ^1]:
        &"u 'day':'{col}' w linespoints pt {COL_POINT_TYPES[col]} ps 0.5 lc rgb '{COL_COLORS[col]}' title '{COL_NAMES[col]}'"

g.plotData("foobarbaz", plotElements)

let svgBytes = g.execute()
writeFile("foobarbaz.svg", svgBytes)
