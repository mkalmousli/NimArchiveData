import unittest

import compose

proc add20(x: int): int = x + 20
proc mul3(x: int): int = x * 3

# Doesn't support overloading yet
#proc add20(x: float): float = x + 20.0
#proc mul3(x: float): float = x * 3.0
proc add20ff(x: float): float = x + 20.0
proc mul3ff(x: float): float = x * 3.0

proc multiAdd30(x,y,z: float): float = x + y + z + 30.0
proc div2(x: float): float = x / 2.0

proc addWithDefaults(x: float = 1.0, y: float = 2.0, z: float = 3.0): float =
  x + y + z


suite "operators":
  let arg0 = 10

  test "1 argument procs":
    check:
      mul3(add20(10)) == (mul3 << add20)(10)
      mul3(add20(10)) == (add20 >> mul3)(10)
      add20(mul3(10)) == (add20 << mul3)(10)
      add20(mul3(10)) == (mul3 >> add20)(10)

      mul3ff(add20ff(10.0)) == (mul3ff << add20ff)(10.0)
      mul3ff(add20ff(10.0)) == (add20ff >> mul3ff)(10.0)
      add20ff(mul3ff(10.0)) == (add20ff << mul3ff)(10.0)
      add20ff(mul3ff(10.0)) == (mul3ff >> add20ff)(10.0)

      add20ff(mul3ff(mul3ff(10.0))) == (add20ff << mul3ff << mul3ff)(10.0)

  test "multiple argument procs":
    check:
      div2(multiAdd30(3,4,5)) == (div2 << multiAdd30)(3,4,5)
      div2(multiAdd30(3,4,5)) == (multiAdd30 >> div2)(3,4,5)

  test "default parameter values":
    check:
      div2(addWithDefaults(3,4,5)) == (div2 << addWithDefaults)(3,4,5)
      div2(addWithDefaults(3,4)) == (div2 << addWithDefaults)(3,4)
      div2(addWithDefaults(z = 5.0)) == (div2 << addWithDefaults)(z = 5.0)
      div2(addWithDefaults()) == (div2 << addWithDefaults)()


suite "compose":
  let arg0 = 10

  test "1 argument procs":
    check:
      mul3(add20(10)) == compose(mul3, add20)(10)
      add20(mul3(10)) == compose(add20, mul3)(10)

      mul3ff(add20ff(10.0)) == compose(mul3ff, add20ff)(10.0)
      add20ff(mul3ff(10.0)) == compose(add20ff, mul3ff)(10.0)

      add20ff(mul3ff(add20ff(10.0))) == compose(add20ff, mul3ff, add20ff)(10.0)

  test "multiple argument procs":
    check:
      div2(multiAdd30(3,4,5)) == compose(div2, multiAdd30)(3,4,5)

  test "default parameter values":
    check:
      div2(addWithDefaults(3,4,5)) == compose(div2, addWithDefaults)(3,4,5)
      div2(addWithDefaults(3,4)) == compose(div2, addWithDefaults)(3,4)
      div2(addWithDefaults(z = 5.0)) == compose(div2, addWithDefaults)(z = 5.0)
      div2(addWithDefaults()) == compose(div2, addWithDefaults)()


