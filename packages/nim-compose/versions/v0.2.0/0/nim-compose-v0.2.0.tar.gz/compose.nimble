# Package

version       = "0.2.0"
author        = "emanresu3"
description   = "Function composition operators"
license       = "MIT"
srcDir        = "src"


# Dependencies

requires "nim >= 1.6.6"
