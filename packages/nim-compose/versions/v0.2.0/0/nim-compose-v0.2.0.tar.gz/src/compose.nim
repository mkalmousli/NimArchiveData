import
  macros

proc getSignature(fn: NimNode): NimNode =
  ## Gets the signature of a proc NimNode as a NimNode
  ## ready to be passed to a nnkLambda or nnkProcDef node

  # Get the signature from getImpl and replace Syms for Idents
  let sigImpl = fn.getImpl[3]
  var subSigImpl: NimNode
  for i in 0 ..< sigImpl.len:
    subSigImpl = sigImpl[i]
    # the return type 'Sym "type"' can stay as a sym
    for j in 0 ..< subSigImpl.len:
      if subSigImpl[j].kind == nnkSym:
        subSigImpl[j] = ident(subSigImpl[j].strVal)
  result = sigImpl


proc retCallable(signature, body: NimNode): NimNode =
  newNimNode(nnkLambda)
    .add(newEmptyNode())
    .add(newEmptyNode())
    .add(newEmptyNode())
    .add(signature)
    .add(newEmptyNode())
    .add(newEmptyNode())
    .add(body)


macro `<<`*(fn1, fn0: typed): untyped =

  let
    typeImpl = fn0.getTypeImpl
    # Same signature as inner callable
    signature = getSignature(fn0)

  var
    body = newNimNode(nnkStmtList)
    innerCall = newNimNode(nnkCall).add(fn0)

  # Add parameters as arguments to the inner callable
  for i in 1 ..< typeImpl[0].len:
    innerCall.add( ident(typeImpl[0][i][0].repr) )

  # TODO:
  # If return type of fn0 doesn't match parameter type of fn1
  # throw an exception with said message
  body.add(
    newNimNode(nnkCall)
      .add(fn1)
      .add(innerCall)
  )

  result = retCallable(signature, body)


template `>>`*(fn0, fn1: typed): untyped = fn1 << fn0


macro `compose`*(fns: varargs[typed]): untyped =

  let
    typeImpl = fns[^1].getTypeImpl
    signature = getSignature(fns[^1])

  var
    body = newNimNode(nnkStmtList)
    nestedCalls = newNimNode(nnkCall).add(fns[^1])

  # Add parameters as arguments to the inner callable
  for i in 1 ..< typeImpl[0].len:
    nestedCalls.add( ident(typeImpl[0][i][0].repr) )

  for i in 2 .. fns.len:
    nestedCalls = newNimNode(nnkCall)
      .add(fns[^i])
      .add(nestedCalls)

  body.add(nestedCalls)

  result = retCallable(signature, body)
