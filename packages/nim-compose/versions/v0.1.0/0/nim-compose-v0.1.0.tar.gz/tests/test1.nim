import unittest

import compose

proc add20(x: int): int = x + 20
proc mul3(x: int): int = x * 3

# Doesn't support overloading yet
#proc add20(x: float): float = x + 20.0
#proc mul3(x: float): float = x * 3.0
proc add20ff(x: float): float = x + 20.0
proc mul3ff(x: float): float = x * 3.0

suite "operators":
  let arg0 = 10

  test "1 argument procs":
    check:
      mul3(add20(10)) == (mul3 << add20)(10)
      mul3(add20(10)) == (add20 >> mul3)(10)
      add20(mul3(10)) == (add20 << mul3)(10)
      add20(mul3(10)) == (mul3 >> add20)(10)

      mul3ff(add20ff(10.0)) == (mul3ff << add20ff)(10.0)
      mul3ff(add20ff(10.0)) == (add20ff >> mul3ff)(10.0)
      add20ff(mul3ff(10.0)) == (add20ff << mul3ff)(10.0)
      add20ff(mul3ff(10.0)) == (mul3ff >> add20ff)(10.0)


suite "compose":
  let arg0 = 10

  test "1 argument procs":
    check:
      mul3(add20(10)) == compose(mul3, add20)(10)
      add20(mul3(10)) == compose(add20, mul3)(10)

      mul3ff(add20ff(10.0)) == compose(mul3ff, add20ff)(10.0)
      add20ff(mul3ff(10.0)) == compose(add20ff, mul3ff)(10.0)

      add20ff(mul3ff(add20ff(10.0))) == compose(add20ff, mul3ff, add20ff)(10.0)
