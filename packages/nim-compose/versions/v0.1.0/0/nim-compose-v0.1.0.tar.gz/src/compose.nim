import
  macros

proc setSignature(types: NimNode): NimNode =

  var params: NimNode = newNimNode(nnkIdentDefs)
  for i in 1 ..< types.len:
    params
      # Same parameter name of the left proc
      .add( ident(types[0][i][0].repr) )
      # Same parameter type of the left proc
      .add(types[0][i][1])
      .add(newEmptyNode())

  let
    retType = types[0][0]
    # Maybe retType "auto" as default?

  result = newNimNode(nnkFormalParams)
    .add(retType)
    .add(params)


proc retCallable(signature, body: NimNode): NimNode =
  newNimNode(nnkLambda)
    .add(newEmptyNode())
    .add(newEmptyNode())
    .add(newEmptyNode())
    .add(signature)
    .add(newEmptyNode())
    .add(newEmptyNode())
    .add(body)


macro `<<`*(fn1, fn0: typed): untyped =

  let
    types = fn1.getTypeImpl
    signature = setSignature(types)

  var body = newNimNode(nnkStmtList)
  # TODO:
  # If return type of fn0 doesn't match parameter type of fn1
  # throw an exception with said message
  body.add(
    newNimNode(nnkCall)
      .add(fn1)
      .add(
        newNimNode(nnkCall)
          .add(fn0)
          # ↓ Only call first parameter
          .add( ident(types[0][1][0].repr) )
      )
  )

  result = retCallable(signature, body)


template `>>`*(fn0, fn1: typed): untyped = fn1 << fn0


macro `compose`*(fns: varargs[typed]): untyped =

  let
    types = fns[0].getTypeImpl
    signature = setSignature(types)

  var body = newNimNode(nnkStmtList)

  var nestedCalls = newNimNode(nnkCall)
    .add(fns[^1])
    # ↓ Only call first parameter
    .add( ident(types[0][1][0].repr) )

  for i in 2..fns.len:
    nestedCalls = newNimNode(nnkCall)
      .add(fns[^i])
      .add(nestedCalls)

  body.add(nestedCalls)

  result = retCallable(signature, body)
