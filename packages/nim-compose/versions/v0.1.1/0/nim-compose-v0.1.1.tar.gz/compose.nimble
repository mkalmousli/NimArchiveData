# Package

version       = "0.1.1"
author        = "emanresu3"
description   = "Function composition operators"
license       = "MIT"
srcDir        = "src"


# Dependencies

requires "nim >= 1.6.6"
