import
  macros

proc setSignature(types: NimNode): NimNode =
  let retType = types[0][0]
  # Maybe retType "auto" as default?

  result = newNimNode(nnkFormalParams)
    .add(retType)

  for i in 1 ..< types[0].len:
    result.add(
      newNimNode(nnkIdentDefs)
      # Same parameter name of the proc
      .add( ident(types[0][i][0].repr) )
      # Same parameter type of the proc
      .add( ident(types[0][i][1].repr) )
      .add(newEmptyNode())
    )


proc retCallable(signature, body: NimNode): NimNode =
  newNimNode(nnkLambda)
    .add(newEmptyNode())
    .add(newEmptyNode())
    .add(newEmptyNode())
    .add(signature)
    .add(newEmptyNode())
    .add(newEmptyNode())
    .add(body)


macro `<<`*(fn1, fn0: typed): untyped =

  let
    types = fn0.getTypeImpl
    # Same signature as inner callable
    signature = setSignature(types)

  var
    body = newNimNode(nnkStmtList)
    innerCall = newNimNode(nnkCall).add(fn0)

  # Add parameters as arguments to the inner callable
  for i in 1 ..< types[0].len:
    innerCall.add( ident(types[0][i][0].repr) )

  # TODO:
  # If return type of fn0 doesn't match parameter type of fn1
  # throw an exception with said message
  body.add(
    newNimNode(nnkCall)
      .add(fn1)
      .add(innerCall)
  )

  result = retCallable(signature, body)


template `>>`*(fn0, fn1: typed): untyped = fn1 << fn0


macro `compose`*(fns: varargs[typed]): untyped =

  let
    types = fns[^1].getTypeImpl
    signature = setSignature(types)

  var
    body = newNimNode(nnkStmtList)
    nestedCalls = newNimNode(nnkCall).add(fns[^1])

  # Add parameters as arguments to the inner callable
  for i in 1 ..< types[0].len:
    nestedCalls.add( ident(types[0][i][0].repr) )

  for i in 2 .. fns.len:
    nestedCalls = newNimNode(nnkCall)
      .add(fns[^i])
      .add(nestedCalls)

  body.add(nestedCalls)

  result = retCallable(signature, body)
