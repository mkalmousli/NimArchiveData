switch("path", "../../src")

switch("gc", "arc")
# switch("profiler", "on")
# switch("stacktrace", "on")
switch("define", "debug")
switch("threads", "on")

switch("define", "McuUtilsLoggingLevel:lvlInfo")
