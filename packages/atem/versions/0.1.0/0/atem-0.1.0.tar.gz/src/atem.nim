import std/[httpclient, uri, json, os, strutils, strformat, net,
             asynchttpserver, asyncdispatch, browsers, times, parseutils,
             sequtils]
import cligen
import dotenv

const
  Version = staticRead("../atem.nimble").splitLines().filterIt(it.startsWith("version")).
      mapIt(it.split("=")[1].strip().strip(chars = {'"'}))[0]
  graphBase = "https://graph.facebook.com/v22.0"
  oauthBase = "https://www.facebook.com/v22.0/dialog/oauth"
  tokenUrl = "https://graph.facebook.com/v22.0/oauth/access_token"
  redirectUri = "http://localhost:8910/callback"
  scopes = "pages_manage_posts,pages_read_engagement,pages_manage_metadata,pages_read_user_content,pages_show_list"
  tokenFile = ".atem_token"

# --- Config ---

type Config = object
  appId: string
  appSecret: string
  token: string

proc tokenPath(): string =
  let cwdPath = getCurrentDir() / tokenFile
  if fileExists(cwdPath): return cwdPath
  let appPath = getAppDir() / tokenFile
  if fileExists(appPath): return appPath
  return cwdPath  # default to cwd for saving

proc loadConfig(): Config =
  let envPath = getAppDir() / ".env"
  let cwdEnv = getCurrentDir() / ".env"
  if fileExists(cwdEnv):
    load(cwdEnv)
  elif fileExists(envPath):
    load(envPath)
  result.appId = getEnv("ATEM_APP_ID")
  result.appSecret = getEnv("ATEM_APP_SECRET")
  if result.appId == "" or result.appSecret == "":
    quit("Missing ATEM_APP_ID or ATEM_APP_SECRET in .env")
  # Load saved token
  let tf = tokenPath()
  if fileExists(tf):
    result.token = readFile(tf).strip()

proc saveToken(token: string) =
  writeFile(tokenPath(), token & "\n")

proc requireToken(cfg: Config): string =
  if cfg.token == "":
    quit("Not authenticated. Run: atem login")
  cfg.token

proc checkFbError(resp: Response) =
  if resp.code.is4xx or resp.code.is5xx:
    let body = parseJson(resp.body)
    if body.hasKey("error"):
      let err = body["error"]
      let msg = err.getOrDefault("message").getStr("Unknown error")
      let code = err.getOrDefault("code").getInt()
      quit(fmt"Facebook API error {code}: {msg}")
    quit("HTTP " & $resp.code & ": " & resp.body)

proc graph(path: string, token: string, params: seq[(string, string)] = @[]): JsonNode =
  let client = newHttpClient()
  defer: client.close()
  var p = @[("access_token", token)] & params
  let url = graphBase & path & "?" & encodeQuery(p)
  let resp = client.get(url)
  checkFbError(resp)
  result = parseJson(resp.body)

proc graphPost(path: string, token: string, params: seq[(string, string)] = @[]): JsonNode =
  let client = newHttpClient()
  defer: client.close()
  var p = @[("access_token", token)] & params
  let url = graphBase & path
  let body = encodeQuery(p)
  client.headers = newHttpHeaders({"Content-Type": "application/x-www-form-urlencoded"})
  let resp = client.post(url, body)
  checkFbError(resp)
  result = parseJson(resp.body)

proc graphPostMultipart(path: string, token: string, data: MultipartData): JsonNode =
  let client = newHttpClient()
  defer: client.close()
  let url = graphBase & path & "?" & encodeQuery(@[("access_token", token)])
  let resp = client.post(url, multipart = data)
  checkFbError(resp)
  result = parseJson(resp.body)

# --- Get page access token ---

proc getPageToken(userToken: string, pageId: string): string =
  let resp = graph("/" & pageId, userToken, @[("fields", "access_token")])
  if resp.hasKey("access_token"):
    result = resp["access_token"].getStr()
  else:
    quit("Could not get page access token. Make sure you manage this page.\n" & $resp)

# --- Commands ---

proc login() =
  ## Authenticate with Facebook via OAuth. Opens a browser.
  let cfg = loadConfig()
  let authUrl = oauthBase & "?" & encodeQuery(@[
    ("client_id", cfg.appId),
    ("redirect_uri", redirectUri),
    ("scope", scopes),
    ("response_type", "code"),
  ])

  var code = ""
  var responded = false

  # Start local server to catch the redirect
  proc handler(req: Request) {.async.} =
    let params = req.url.query
    for pair in params.split('&'):
      let kv = pair.split('=', 1)
      if kv.len == 2 and kv[0] == "code":
        code = decodeUrl(kv[1])
    let html = "<html><body><h2>Authenticated! You can close this tab.</h2></body></html>"
    await req.respond(Http200, html, newHttpHeaders())
    responded = true

  echo "Opening browser for Facebook login..."
  echo "If it doesn't open, visit:\n", authUrl
  openDefaultBrowser(authUrl)

  # Serve one request
  let server = newAsyncHttpServer()
  let fut = server.serve(Port(8910), handler)

  # Wait for the code and response to complete
  while code == "" or not responded:
    poll(100)
  server.close()

  if code == "":
    quit("No authorization code received.")

  echo "Got authorization code. Exchanging for token..."

  # Exchange code for short-lived token
  let client = newHttpClient()
  defer: client.close()
  let exchangeUrl = tokenUrl & "?" & encodeQuery(@[
    ("client_id", cfg.appId),
    ("redirect_uri", redirectUri),
    ("client_secret", cfg.appSecret),
    ("code", code),
  ])
  let shortResp = parseJson(client.getContent(exchangeUrl))
  let shortToken = shortResp["access_token"].getStr()

  # Exchange for long-lived token
  let longUrl = tokenUrl & "?" & encodeQuery(@[
    ("grant_type", "fb_exchange_token"),
    ("client_id", cfg.appId),
    ("client_secret", cfg.appSecret),
    ("fb_exchange_token", shortToken),
  ])
  let longResp = parseJson(client.getContent(longUrl))
  let longToken = longResp["access_token"].getStr()

  saveToken(longToken)
  echo "Authenticated and token saved to ", tokenFile

proc pages() =
  ## List Facebook pages you manage.
  let cfg = loadConfig()
  let token = requireToken(cfg)
  let resp = graph("/me/accounts", token, @[("fields", "id,name,category,fan_count")])
  if not resp.hasKey("data"):
    quit("Unexpected response:\n" & $resp)
  let data = resp["data"]
  if data.len == 0:
    echo "No pages found."
    return
  for page in data:
    let fans = if page.hasKey("fan_count"): $page["fan_count"].getInt() else: "?"
    let name = page["name"].getStr()
    let id = page["id"].getStr()
    let cat = page["category"].getStr()
    echo fmt"{name:<40} id={id}  fans={fans}  cat={cat}"

proc publish(pageId: string, message: string) =
  ## Publish a text post to a page.
  let cfg = loadConfig()
  let userToken = requireToken(cfg)
  let pageToken = getPageToken(userToken, pageId)
  let resp = graphPost("/" & pageId & "/feed", pageToken, @[("message", message)])
  echo "Posted: ", resp["id"].getStr()

proc photo(pageId: string, file: string, caption: string = "") =
  ## Publish a photo to a page.
  let cfg = loadConfig()
  let userToken = requireToken(cfg)
  let pageToken = getPageToken(userToken, pageId)
  if not fileExists(file):
    quit("File not found: " & file)
  var mp = newMultipartData()
  mp.addFiles({"source": file})
  if caption != "":
    mp.add("caption", caption)
  let resp = graphPostMultipart("/" & pageId & "/photos", pageToken, mp)
  echo "Photo posted: ", resp["id"].getStr()

proc link(pageId: string, url: string, message: string = "") =
  ## Share a link on a page.
  let cfg = loadConfig()
  let userToken = requireToken(cfg)
  let pageToken = getPageToken(userToken, pageId)
  var params = @[("link", url)]
  if message != "":
    params.add(("message", message))
  let resp = graphPost("/" & pageId & "/feed", pageToken, params)
  echo "Link shared: ", resp["id"].getStr()

proc schedule(pageId: string, message: string, time: string) =
  ## Schedule a post. Time format: YYYY-MM-DDThh:mm (local time) or unix timestamp.
  let cfg = loadConfig()
  let userToken = requireToken(cfg)
  let pageToken = getPageToken(userToken, pageId)
  var ts: int64
  if time.contains("T") or time.contains("-"):
    let dt = parse(time, "yyyy-MM-dd'T'HH:mm")
    ts = dt.toTime().toUnix()
  else:
    ts = parseBiggestInt(time)
  let now = getTime().toUnix()
  if ts < now + 600:
    quit("Scheduled time must be at least 10 minutes in the future.")
  if ts > now + 75 * 86400:
    quit("Scheduled time must be within 75 days.")
  let resp = graphPost("/" & pageId & "/feed", pageToken, @[
    ("message", message),
    ("published", "false"),
    ("scheduled_publish_time", $ts),
  ])
  echo "Scheduled: ", resp["id"].getStr()

proc posts(pageId: string, limit: int = 10) =
  ## List recent posts on a page.
  let cfg = loadConfig()
  let userToken = requireToken(cfg)
  let pageToken = getPageToken(userToken, pageId)
  let resp = graph("/" & pageId & "/feed", pageToken, @[
    ("fields", "id,message,created_time,shares"),
    ("limit", $limit),
  ])
  if not resp.hasKey("data"):
    quit("Unexpected response:\n" & $resp)
  for p in resp["data"]:
    let msg = if p.hasKey("message"): p["message"].getStr().substr(0, 80) else: "(no text)"
    let time = p["created_time"].getStr()
    let id = p["id"].getStr()
    echo fmt"{time}  {id}  {msg}"

proc deletePost(postId: string) =
  ## Delete a post by its ID (format: pageId_postId).
  let cfg = loadConfig()
  let userToken = requireToken(cfg)
  let parts = postId.split('_', 1)
  if parts.len != 2:
    quit("Post ID should be in pageId_postId format (e.g. 123456_789012)")
  let pageToken = getPageToken(userToken, parts[0])
  let client = newHttpClient()
  defer: client.close()
  let url = graphBase & "/" & postId & "?" & encodeQuery(@[("access_token", pageToken)])
  let resp = client.request(url, httpMethod = HttpDelete)
  if resp.code.is4xx or resp.code.is5xx:
    checkFbError(resp)
  let body = parseJson(resp.body)
  if body.hasKey("success") and body["success"].getBool():
    echo "Deleted: ", postId
  else:
    echo "Delete failed: ", $body

proc version() =
  ## Show version
  echo "atem " & Version

proc info(pageId: string) =
  ## Show detailed info about a page.
  let cfg = loadConfig()
  let userToken = requireToken(cfg)
  let pageToken = getPageToken(userToken, pageId)
  let resp = graph("/" & pageId, pageToken, @[
    ("fields", "id,name,category,fan_count,description,website,link,single_line_address,phone,emails"),
  ])
  echo pretty(resp)

when isMainModule:
  dispatchMulti(
    [login],
    [pages],
    [publish, help = {"pageId": "Page ID", "message": "Post text"}],
    [photo, help = {"pageId": "Page ID", "file": "Image path", "caption": "Photo caption"}],
    [link, help = {"pageId": "Page ID", "url": "URL to share", "message": "Optional message"}],
    [schedule, help = {"pageId": "Page ID", "message": "Post text", "time": "YYYY-MM-DDThh:mm or unix ts"}],
    [posts, help = {"pageId": "Page ID", "limit": "Number of posts"}],
    [deletePost, cmdName = "delete", help = {"postId": "Post ID to delete"}],
    [info, help = {"pageId": "Page ID"}],
    [version],
  )
