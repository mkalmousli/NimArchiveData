# Package
version       = "0.1.0"
author        = "Carlo Capocasa"
description   = "Facebook Page management CLI"
license       = "MIT"
srcDir        = "src"
bin           = @["atem"]

# Dependencies
requires "nim >= 2.0.0"
requires "cligen"
requires "dotenv"
