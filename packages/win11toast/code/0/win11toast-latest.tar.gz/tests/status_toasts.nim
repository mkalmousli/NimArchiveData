discard """

Status Toast Examples
Demonstrates success, warning, and info toast notifications

nim c -r tests/status_toasts.nim

"""

import ../src/win11toast

when isMainModule:
  when defined(windows):
    proc main =
      initWinRT()
      defer: uninitWinRT()

      # Success Toast
      echo "Sending success toast..."
      block:
        let xml = newToastBuilder()
          .setTitle("✅ Success")
          .setBody("Operation completed successfully!")
          .buildXml()

        let handle = showToast(xml)
        releaseToast(handle)

      # Warning Toast (buttons dismiss the toast without opening anything)
      echo "Sending warning toast..."
      block:
        let xml = newToastBuilder()
          .setTitle("⚠️ Warning")
          .setBody("Please review before proceeding.")
          .setDuration(tdLong)
          .addButton("Review", "action=review", "foreground")
          .addButton("Ignore", "action=ignore", "foreground")
          .buildXml()

        let handle = showToast(xml)
        releaseToast(handle)

      # Info Toast (Learn More opens URL, Dismiss just closes)
      echo "Sending info toast..."
      block:
        let xml = newToastBuilder()
          .setTitle("ℹ️ Info")
          .setBody("New updates are available.")
          .setAttribution("System Notification")
          .addButton("Learn More", "https://example.com", "protocol")
          .addButton("Dismiss", "action=dismiss", "foreground")
          .buildXml()

        let handle = showToast(xml)
        releaseToast(handle)

      echo "All status toasts sent!"

    main()
  else:
    echo "This example only works on Windows."