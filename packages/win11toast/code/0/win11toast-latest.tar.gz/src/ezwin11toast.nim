## win11toast/ez - Ergonomic Toast Notifications
## 
## A simplified, batteries-included interface for Windows toast notifications.
## Import this instead of win11toast for a much cleaner API.
##
## Usage:
##   import win11toast/ez
##   
##   # One-liners
##   success "Build complete!"
##   error "Connection failed", "Check your network settings"
##   warn "Low disk space"
##   info "Update available", launch = "https://example.com"
##   
##   # Quick toast with chaining
##   "Hello World".toast
##   "Click me".toast(launch = "https://nim-lang.org")
##   
##   # Builder pattern (when you need more control)
##   toast:
##     title "Download Complete"
##     body "Your file is ready"
##     button "Open", "file:///path/to/file"
##     button "Dismiss"
##     sound Notification

import std/[options, strutils, strformat]
import win11toast

export win11toast.ToastScenario, win11toast.ToastDuration
export win11toast.initWinRT, win11toast.uninitWinRT

# ============================================================================
# Lazy Initialization
# ============================================================================

var ezInitialized = false

proc ensureInit() =
  ## Lazily initialize WinRT on first use
  if not ezInitialized:
    when defined(windows):
      initWinRT()
    ezInitialized = true

# ============================================================================
# Sound Presets
# ============================================================================

type
  ToastSound* = enum
    Default     = "ms-winsoundevent:Notification.Default"
    Mail        = "ms-winsoundevent:Notification.Mail"
    Reminder    = "ms-winsoundevent:Notification.Reminder"
    SMS         = "ms-winsoundevent:Notification.SMS"
    Alarm       = "ms-winsoundevent:Notification.Looping.Alarm"
    Alarm2      = "ms-winsoundevent:Notification.Looping.Alarm2"
    Alarm3      = "ms-winsoundevent:Notification.Looping.Alarm3"
    Call        = "ms-winsoundevent:Notification.Looping.Call"
    Call2       = "ms-winsoundevent:Notification.Looping.Call2"
    Silent      = ""

# ============================================================================
# Quick Status Toasts
# ============================================================================

proc success*(title: string, body = "", launch = "") =
  ## Show a success toast with ✅ icon
  ensureInit()
  notify(
    title  = "✅ " & title
    ,body   = body
    ,launch = launch
    ,silent = true
  )

proc error*(title: string, body = "", launch = "") =
  ## Show an error toast with ❌ icon
  ensureInit()
  notify(
    title    = "❌ " & title
    ,body     = body
    ,launch   = launch
    ,duration = some(tdLong)
    ,audio    = $Reminder
  )

proc warn*(title: string, body = "", launch = "") =
  ## Show a warning toast with ⚠️ icon
  ensureInit()
  notify(
    title    = "⚠️ " & title
    ,body     = body
    ,launch   = launch
    ,duration = some(tdLong)
    ,audio    = $Reminder
  )

proc info*(title: string, body = "", launch = "") =
  ## Show an info toast with ℹ️ icon
  ensureInit()
  notify(
    title  = "ℹ️ " & title
    ,body   = body
    ,launch = launch
    ,silent = true
  )

proc progress*(title: string, body = "", pct: int = -1) =
  ## Show a progress toast (note: static, doesn't update)
  ## pct: 0-100 for determinate, -1 for indeterminate
  ensureInit()
  var builder = newToastBuilder()
    .setTitle(title)
    .setBody(body)
  
  if pct < 0:
    builder.setProgress(title, "Working...", "indeterminate")
  else:
    let val = clamp(pct, 0, 100).float / 100.0
    builder.setProgress(title, $pct & "%", $val, $pct & "%")
  
  let handle = showToast(builder.buildXml())
  releaseToast(handle)

proc alarm*(title: string, body = "", snoozeBtn = true) =
  ## Show an alarm toast that stays until dismissed
  ensureInit()
  var builder = newToastBuilder()
    .setTitle("⏰ " & title)
    .setBody(body)
    .setScenario(tsAlarm)
    .setDuration(tdLong)
    .setAudio($Alarm, loop = true)
  
  if snoozeBtn:
    builder.addButton("Snooze", "action:snooze", "foreground")
  builder.addButton("Dismiss", "action:dismiss", "foreground")
  
  let handle = showToast(builder.buildXml())
  releaseToast(handle)

proc reminder*(title: string, body = "", launch = "") =
  ## Show a reminder toast
  ensureInit()
  notify(
    title    = "🔔 " & title
    ,body     = body
    ,launch   = launch
    ,scenario = tsReminder
    ,duration = some(tdLong)
    ,audio    = $Reminder
  )

# ============================================================================
# String Extension - Ultra Simple API
# ============================================================================

proc toast*(message: string, body = "", launch = "", sound: ToastSound = Silent) =
  ## Show a simple toast from a string
  ## 
  ## Example:
  ##   "Hello World".toast
  ##   "Click me".toast(launch = "https://nim-lang.org")
  ##   "Ding!".toast(sound = Mail)
  ensureInit()
  if sound == Silent:
    notify(title = message, body = body, launch = launch, silent = true)
  else:
    notify(title = message, body = body, launch = launch, audio = $sound)

# ============================================================================
# Fluent Builder - For Complex Toasts
# ============================================================================

type
  EzToast* = ref object
    builder: ToastBuilder
    appId: string

proc newEzToast*(): EzToast =
  result = EzToast(
    builder: newToastBuilder()
    ,appId: DEFAULT_APP_ID
  )

# Chainable setters
proc title*(t: EzToast, s: string): EzToast {.discardable.} =
  t.builder.setTitle(s)
  t

proc body*(t: EzToast, s: string): EzToast {.discardable.} =
  t.builder.setBody(s)
  t

proc attribution*(t: EzToast, s: string): EzToast {.discardable.} =
  t.builder.setAttribution(s)
  t

proc launch*(t: EzToast, url: string): EzToast {.discardable.} =
  t.builder.setLaunch(url)
  t

proc icon*(t: EzToast, src: string): EzToast {.discardable.} =
  t.builder.setIcon(src)
  t

proc image*(t: EzToast, src: string): EzToast {.discardable.} =
  t.builder.setImage(src)
  t

proc button*(t: EzToast, label: string, action = "", protocol = true): EzToast {.discardable.} =
  let actType = if protocol: "protocol" else: "foreground"
  let args = if action == "": "action:" & label.toLowerAscii else: action
  t.builder.addButton(label, args, actType)
  t

proc input*(t: EzToast, id: string, placeholder = ""): EzToast {.discardable.} =
  t.builder.addInput(id, placeHolderContent = placeholder)
  t

proc dropdown*(t: EzToast, id: string, options: openArray[(string, string)]): EzToast {.discardable.} =
  var items: seq[tuple[id: string, content: string]]
  for (k, v) in options:
    items.add((k, v))
  t.builder.addSelection(id, items)
  t

proc sound*(t: EzToast, s: ToastSound, loop = false): EzToast {.discardable.} =
  if s == Silent:
    t.builder.setSilent()
  else:
    t.builder.setAudio($s, loop)
  t

proc silent*(t: EzToast): EzToast {.discardable.} =
  t.builder.setSilent()
  t

proc long*(t: EzToast): EzToast {.discardable.} =
  t.builder.setDuration(tdLong)
  t

proc short*(t: EzToast): EzToast {.discardable.} =
  t.builder.setDuration(tdShort)
  t

proc asAlarm*(t: EzToast): EzToast {.discardable.} =
  t.builder.setScenario(tsAlarm)
  t

proc asReminder*(t: EzToast): EzToast {.discardable.} =
  t.builder.setScenario(tsReminder)
  t

proc asUrgent*(t: EzToast): EzToast {.discardable.} =
  t.builder.setScenario(tsUrgent)
  t

proc app*(t: EzToast, appId: string): EzToast {.discardable.} =
  t.appId = appId
  t

proc tag*(t: EzToast, s: string): EzToast {.discardable.} =
  t.builder.setTag(s)
  t

proc group*(t: EzToast, s: string): EzToast {.discardable.} =
  t.builder.setGroup(s)
  t

proc show*(t: EzToast) =
  ## Show the toast (fire and forget)
  ensureInit()
  let handle = showToast(t.builder.buildXml(), t.appId)
  releaseToast(handle)

proc showAndHold*(t: EzToast): ToastNotificationHandle =
  ## Show the toast and return handle for later release
  ensureInit()
  showToast(t.builder.buildXml(), t.appId)

# ============================================================================
# DSL-style Builder via Template
# ============================================================================

import std/macros

macro wintoast*(actions: untyped): untyped =
  ## DSL for building toasts
  ## 
  ## Example:
  ##   toast:
  ##     title "Hello"
  ##     body "World"
  ##     button "OK"
  ##     silent
  
  result = newStmtList()
  
  # Create the toast variable
  let tSym = genSym(nskVar, "t")
  result.add quote do:
    var `tSym` = newEzToast()
  
  # Process each statement in the block
  for stmt in actions:
    case stmt.kind
    of nnkCall, nnkCommand:
      let cmdName = stmt[0].strVal
      case cmdName
      of "title":
        let arg = stmt[1]
        result.add quote do:
          `tSym` = `tSym`.title(`arg`)
      of "body":
        let arg = stmt[1]
        result.add quote do:
          `tSym` = `tSym`.body(`arg`)
      of "attribution":
        let arg = stmt[1]
        result.add quote do:
          `tSym` = `tSym`.attribution(`arg`)
      of "launch":
        let arg = stmt[1]
        result.add quote do:
          `tSym` = `tSym`.launch(`arg`)
      of "icon":
        let arg = stmt[1]
        result.add quote do:
          `tSym` = `tSym`.icon(`arg`)
      of "image":
        let arg = stmt[1]
        result.add quote do:
          `tSym` = `tSym`.image(`arg`)
      of "button":
        if stmt.len == 2:
          let label = stmt[1]
          result.add quote do:
            `tSym` = `tSym`.button(`label`)
        else:
          let label = stmt[1]
          let action = stmt[2]
          result.add quote do:
            `tSym` = `tSym`.button(`label`, `action`)
      of "input":
        if stmt.len == 2:
          let id = stmt[1]
          result.add quote do:
            `tSym` = `tSym`.input(`id`)
        else:
          let id = stmt[1]
          let placeholder = stmt[2]
          result.add quote do:
            `tSym` = `tSym`.input(`id`, `placeholder`)
      of "sound":
        let arg = stmt[1]
        result.add quote do:
          `tSym` = `tSym`.sound(`arg`)
      of "silent":
        result.add quote do:
          `tSym` = `tSym`.silent()
      of "long":
        result.add quote do:
          `tSym` = `tSym`.long()
      of "short":
        result.add quote do:
          `tSym` = `tSym`.short()
      of "asAlarm":
        result.add quote do:
          `tSym` = `tSym`.asAlarm()
      of "asReminder":
        result.add quote do:
          `tSym` = `tSym`.asReminder()
      of "asUrgent":
        result.add quote do:
          `tSym` = `tSym`.asUrgent()
      of "app":
        let arg = stmt[1]
        result.add quote do:
          `tSym` = `tSym`.app(`arg`)
      else:
        error("Unknown toast command: " & cmdName, stmt)
    of nnkIdent:
      # Handle bare identifiers like `silent`, `long`
      let cmdName = stmt.strVal
      case cmdName
      of "silent":
        result.add quote do:
          `tSym` = `tSym`.silent()
      of "long":
        result.add quote do:
          `tSym` = `tSym`.long()
      of "short":
        result.add quote do:
          `tSym` = `tSym`.short()
      of "asAlarm":
        result.add quote do:
          `tSym` = `tSym`.asAlarm()
      of "asReminder":
        result.add quote do:
          `tSym` = `tSym`.asReminder()
      of "asUrgent":
        result.add quote do:
          `tSym` = `tSym`.asUrgent()
      else:
        error("Unknown toast command: " & cmdName, stmt)
    else:
      error("Invalid toast DSL syntax", stmt)
  
  # Show the toast
  result.add quote do:
    `tSym`.show()

# ============================================================================
# Examples in comments
# ============================================================================

when isMainModule:
  # --- Quick one-liners ---
  
  when defined(example.success):
    success "Build passed!"

  when defined(example.error):
    error "Build failed", "Check the logs for details"

  when defined(example.warn):
    warn "Disk space low", "Only 5GB remaining"

  when defined(example.info):
    info "New version available"

  # --- String extension ---
  
  when defined(example.string):
    "Simple message".toast
    "Click to learn more".toast(launch = "https://nim-lang.org")
    "Ding!".toast(sound = Mail)

  # --- Fluent builder ---
  
  when defined(example.builder):
    newEzToast()
      .title("Download Complete")
      .body("myfile.zip is ready")
      .button("Open Folder", "file:///C:/Downloads")
      .button("Dismiss")
      .silent()
      .show()

  # --- DSL style ---
  
  when defined(example.dsl):
    wintoast:
      title "Meeting Reminder"
      body "Team standup in 5 minutes"
      button "Join", "https://meet.example.com"
      button "Snooze"
      sound Reminder
      long