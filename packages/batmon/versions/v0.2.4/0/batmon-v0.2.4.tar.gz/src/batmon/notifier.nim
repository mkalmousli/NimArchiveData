import osproc, strformat

type
  Notification* = object
    summary*: string
    body*: string
    timeout*: int
    wait*: bool
    urgency*: Urgency
  Urgency* = enum
    Low,
    Normal,
    Critical

proc newNotification*(summary: string, body: string = "", urgency: Urgency = Normal , timeout: int = 0): Notification =
  var n = Notification()
  n.summary = summary
  n.body = body
  n.urgency = urgency
  n.timeout = timeout
  return n

proc send*(n: Notification): bool =
  var params = fmt"-a BatMon -u {n.urgency}"
  if n.timeout > 0:
    params &= fmt" -t {n.timeout}"
  if n.wait:
    params &= fmt" --wait"
  let content = fmt"'{n.summary}' '{n.body}'"
  let cmd = fmt"notify-send {params} {content}"
  return osproc.execCmd(cmd) == 0


