import strutils

type 
  Battery* = object
    status*: Status
    charge*: float
  Status* = enum
    Unknown,
    High,
    Low,
    Critical,
    Charging,
    Discharging,
    Full

proc charging*(b: Battery): bool = 
  return b.status == Charging

proc toStatus*(i: int): Status =
  case i
  of 0: return High
  of 1: return Low
  of 2: return Critical
  of 3: return Charging
  else: return Unknown

proc toStatus*(str: string): Status =
  case str
  of "Full": return Full
  of "Charging": return Charging
  of "Discharging": return Discharging
  else: return toStatus(str.parseInt)
