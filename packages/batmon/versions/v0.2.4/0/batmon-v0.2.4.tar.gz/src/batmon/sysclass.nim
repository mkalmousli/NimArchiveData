import battery
import strutils, os

proc parseStatus(status: string, charge: float): Status =
  if status == "Charging":
    return Charging
  elif charge < 10:
    return Critical
  elif charge < 40:
    return Low
  else:
    return High

proc get_sysclass*(): Battery =
  let sysclass_bat_list = "/sys/class/power_supply/"
  var sysclass_bat = sysclass_bat_list & "BAT0"
  for bat in sysclass_bat_list.walkDir():
    if bat.path[^4..^2] == "BAT":
      sysclass_bat = bat.path

  # Should probably do more battery checks here, but OK for now
  var bat = Battery()
  if dirExists(sysclass_bat):
    let exists = strip(readFile(sysclass_bat & "/present"))
    if exists == "1":
      let charge = strip(readFile(sysclass_bat & "/capacity")).parseFloat
      let status = strip(readFile(sysclass_bat & "/status"))
      bat.status = parseStatus(status, charge)
      bat.charge = charge
  return bat
