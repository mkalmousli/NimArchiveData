import osproc, strutils
import battery

proc getAPM*(): Battery =
  var bat = Battery()
  let state = execCmdEx("apm -b")
  bat.status = state.output.strip().toStatus
  let charge = execCmdEx("apm -l")
  bat.charge = charge.output.strip().parseFloat
  return bat
