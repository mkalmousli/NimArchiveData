# Package

version       = "0.2.4"
author        = "Paul Wilde"
description   = "BatMon - Monitor your Battery"
license       = "BSD-3-Clause"
srcDir        = "src"
binDir        = "bin"
installExt    = @["nim"]
bin           = @["batmon"]


# Dependencies

requires "nim >= 2.0.0"
