import batmon/apm, batmon/sysclass
import batmon/battery, batmon/notifier
import os, json, strformat

export battery
export notifier

type
  Run = enum
    None,
    Daemon,
    Once

var run_as: Run = None
var last_status: Status = Unknown
var wait_seconds: int = 60
var help_shown: bool = false
const VERSION: string = "0.1.6"


proc get_status(): Battery =
  var bat: Battery
  case hostOS
  of "freebsd":
    bat = getAPM()
  of "linux":
    wait_seconds = 5
    bat = get_sysclass()
  else:
    echo "Batmon is not supported on this system: " & hostOS
  return bat

proc get_battery_status*(): Battery =
  return get_status()

proc output(bat: Battery) =
  echo %*bat

proc start_notifier() =
  while run_as == Daemon:
    let bat = get_status()
    output(bat)
    if last_status != bat.status:
      var n: Notification = newNotification(summary = "BatMon",
                                            body = "",
                                            timeout = 5000)
      n.body &= fmt"Status: {bat.status}\n"
      n.body &= fmt"Charge: {bat.charge}"
      case bat.status
      of Critical:
        n.urgency = Critical
        n.timeout = 60 * 1000 * 2 # 2 Minutes
      of Low:
        n.urgency = Critical
        n.timeout = 30 * 1000 # 30 seconds
      of Discharging, High:
        n.urgency = Normal
      of Charging, Unknown:
        n.urgency = Low
      else:
        n.urgency = Low
      discard n.send()
      last_status = bat.status
    sleep 1000 * wait_seconds

proc welcome_message() =
  echo """
  =================
  na na na na na na
        na na      
  na na na na na na
        na na      
      !BAT MON!    
  =================
  """

proc show_help() =
  welcome_message()
  echo """
  A simple battery status notifier.

  Command line parameters:
      -d, --daemon   Runs the daemon, which will send a notification on 
                     status change i.e. Charging, High, Low, Critical
      -o, --once     Check the battery status once and exit
      -v, --version  Shows the version
      -h, --help     Shows this help screen
  """
  echo """
  Version : """ & VERSION
  help_shown = true

proc parseArgs() =
  let args = commandLineParams()
  for arg in args:
    case arg:
      of "-o", "--once":
        run_as = Once
      of "-d", "--daemon":
        run_as = Daemon
      of "-h", "--help", "-v", "--version":
        show_help()

when isMainModule:
  parseArgs()
  case run_as
  of Once:
    output(get_status())
  of Daemon:
    start_notifier()
  else:
    if not help_shown:
      show_help()

