import nimvss
import winim/lean
import std/[tables, sequtils]

proc testPrivileges() =
  doAssert privs.havePrivilege("SeBackupPrivilege") == false, "Backup privilege disabled"
  doAssert privs.enablePrivilege("SeBackupPrivilege"), "Backup privilege enabling"
  doAssert privs.havePrivilege("SeBackupPrivilege"), "Backup privilege enabled"
  doAssert privs.enablePrivilege("SeBackupPrivilege", enable=false), "Backup privilege disabling"
  doAssert not privs.havePrivilege("SeBackupPrivilege"), "Backup privilege disabled"

proc testListSnapshots() =
  echo "== Testing snapshot enumeration =="
  var session = newVssSession(VSS_CTX_ALL)
  let snaps = session.listSnapshots()
  session.close()
  for s in snaps.values:
    echo $s.info
  if snaps.len == 0:
    echo "No snapshots found."

proc testDeleteSnapshot() =
  echo "== Deleting last snapshot =="
  var session = newVssSession(VSS_CTX_ALL)
  let 
    curSnaps = session.listSnapshots()
    lastOne = toSeq(curSnaps.values)[0]
  doAssert session.deleteSnapshot(lastOne.info.id), "Delete 1 snapshot"
  doAssert session.listSnapshots().len + 1 == curSnaps.len, "One less."
  session.close

proc testCreateSnapshot() =
  echo "== Testing create snapshots =="
  var
    session = newVssSession(persistent=false)
    snapshot = session.createSnapshot("C:", openHandle=true)
  session.close
  echo $snapshot.info
  doAssert snapshot.state.handle != INVALID_HANDLE_VALUE, "Got handle"
  doAssert snapshot.info.devicePath.len > 0, "Got valid path"

proc testSnapshots() =
  echo "== Testing snapshots =="
  testListSnapshots()
  testCreateSnapshot()
  testListSnapshots()
  testDeleteSnapshot()
  testListSnapshots()


when isMainModule:
  # testPrivileges()
  testSnapshots()

