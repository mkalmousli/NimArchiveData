# Package

version       = "0.1.0"
author        = "srozb"
description   = "Minimal Nim library that provides simple access to Windows Volume Shadow Copy Service (VSS)"
license       = "MIT"
srcDir        = "src"


# Dependencies

requires "nim >= 2.0.0, winim >= 3.9.0"
