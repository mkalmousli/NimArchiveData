## nimvss
##
## Public umbrella module for the nimvss library. Re-exports the
## high-level snapshot API, low-level VSS FFI bindings, and privilege
## helpers so adopters can `import nimvss` and access everything.
from nimvss/snapshot import nil
from nimvss/winvss import nil
from nimvss/privs import nil
export snapshot, winvss, privs
