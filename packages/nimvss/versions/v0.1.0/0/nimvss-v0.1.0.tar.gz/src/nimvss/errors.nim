import winim/lean
import std/strutils

type
  VssError* = object of CatchableError ## Error raised for VSS/COM failures.
    hr*: HRESULT ## Underlying HRESULT when available.

  WinError* = object of CatchableError ## Error raised for Win32 API failures.
    code*: DWORD ## GetLastError() value.

proc hresultHex*(hr: HRESULT): string =
  ## Hex string for HRESULT (e.g., 0x80042306)
  "0x" & toHex(cast[uint32](hr), 8)

proc formatHresult*(hr: HRESULT): string =
  ## Return a system message for the HRESULT when possible.
  var buf: LPWSTR
  let flags =
    FORMAT_MESSAGE_ALLOCATE_BUFFER or FORMAT_MESSAGE_FROM_SYSTEM or
    FORMAT_MESSAGE_IGNORE_INSERTS
  let got = FormatMessageW(flags.DWORD, nil, hr.DWORD, 0.DWORD, buf, 0.DWORD, nil)
  if got == 0:
    return "HRESULT " & hresultHex(hr)
  return $buf

proc formatWinError*(code: DWORD): string =
  ## Return a system message for a Win32 GetLastError code when possible.
  var buf: LPWSTR
  let flags =
    FORMAT_MESSAGE_ALLOCATE_BUFFER or FORMAT_MESSAGE_FROM_SYSTEM or
    FORMAT_MESSAGE_IGNORE_INSERTS
  let got = FormatMessageW(flags.DWORD, nil, code, 0.DWORD, buf, 0.DWORD, nil)
  if got == 0:
    return "WinError " & $code
  return $buf

proc raiseVss*(hr: HRESULT, where: string) {.noinline, raises: [VssError].} =
  ## Raise a VssError with HRESULT context and readable message.
  let msg = where & " failed: " & formatHresult(hr) & " (" & hresultHex(hr) & ")"
  var e = newException(VssError, msg)
  e.hr = hr
  raise e

proc ensureHrOk*(hr: HRESULT, where: string) {.raises: [VssError].} =
  ## Raise if HRESULT signals failure.
  if hr < 0:
    raiseVss(hr, where)

template checkHr*(call: untyped, where: string): untyped =
  ## Evaluate a COM/VSS call returning HRESULT and raise on failure.
  block:
    let hr = call
    ensureHrOk(hr, where)
    hr

proc raiseWin*(
    where: string, code: DWORD = GetLastError()
) {.noinline, raises: [WinError].} =
  ## Raise a WinError with GetLastError-derived context.
  let msg = where & " failed: " & formatWinError(code) & " (code " & $code & ")"
  var e = newException(WinError, msg)
  e.code = code
  raise e

proc ensureTrue*(ok: BOOL, where: string) {.raises: [WinError].} =
  ## Ensure a Win32 BOOL call succeeded.
  if ok == 0:
    raiseWin(where)
