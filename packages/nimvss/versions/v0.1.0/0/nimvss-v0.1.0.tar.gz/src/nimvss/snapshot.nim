## High-level helpers around Windows Volume Shadow Copy Service (VSS).
##
## This module provides a small, pragmatic API to enumerate, create and
## delete VSS snapshots, plus a few utilities for dealing with Windows
## time and GUID types. Prefer this module over `winvss` unless you need
## direct FFI access.
import std/[times, strutils, tables]
import winim/[lean, com]
import winvss
import errors

# import nimvss/[privs]

const
  EPOCH_DIFF_100NS = 116444736000000000'u64 # 1601→1970 in 100ns ticks
  TICKS_PER_SEC = 10_000_000'u64

type
  SnapshotInfo* = object ## Immutable facts about a snapshot as returned by VSS.
    id*: GUID
    setId*: GUID
    devicePath*: string # \\?\GLOBALROOT\Device\HarddiskVolumeShadowCopyXX
    originalVolume*: string # \\?\Volume{...}\
    originatingMachine*: string
    serviceMachine*: string
    created*: DateTime # UTC
    persistent*: bool

  SnapshotState* = object ## Mutable runtime state for an existing snapshot.
    exposed*: bool = false # was ExposeSnapshot called?
    exposedPath*: string # "X:" or mount path (if exposed)
    exposedName*: string
    handle*: Handle = INVALID_HANDLE_VALUE # raw device handle

  Snapshot* = ref object ## A snapshot handle joining static info and mutable state.
    info*: SnapshotInfo
    state*: SnapshotState

  VssSession* = ref object ## A VSS session used to query/manage snapshots.
    comp: ptr IVssBackupComponents # ptr IVssBackupComponents (opaque here)
    ctx*: VSS_SNAPSHOT_CONTEXT # VSS context flags (e.g., VSS_CTX_BACKUP / APP_ROLLBACK)
    snapshots*: Table[GUID, Snapshot] # id -> Snapshot (current system view)

  # CreateOpts* = object
  #   withWriters*: bool             # default false
  #   persistent*: bool              # default false (auto-release)

  # ExposeResult* = object
  #   snapshotId*: GUID
  #   exposedName*: string           # actual le

proc hrOk(hr: HRESULT): bool =
  hr >= 0

func pickCtx*(persistent, withWriters: bool): VSS_SNAPSHOT_CONTEXT =
  ## Choose an appropriate VSS context based on persistence and writer usage.
  if not persistent and not withWriters:
    VSS_CTX_FILE_SHARE_BACKUP
  elif not persistent and withWriters:
    VSS_CTX_BACKUP
  elif persistent and not withWriters:
    VSS_CTX_NAS_ROLLBACK
  else:
    VSS_CTX_APP_ROLLBACK

proc newVssSession*(ctx: VSS_SNAPSHOT_CONTEXT): VssSession =
  ## Create a new VSS session with an explicit context.
  result = VssSession(ctx: ctx)
  discard CoInitializeEx(nil, COINIT_MULTITHREADED)
  ensureHrOk(
    CreateVssBackupComponentsInternal(addr result.comp),
    "CreateVssBackupComponentsInternal",
  )
  if result.comp.isNil:
    raise
      newException(VssError, "CreateVssBackupComponentsInternal returned nil component")
  try:
    ensureHrOk(
      result.comp.lpVtbl.InitializeForBackup(result.comp, cast[BSTR](nil)),
      "IVssBackupComponents.InitializeForBackup",
    )
    ensureHrOk(
      result.comp.lpVtbl.SetContext(result.comp, result.ctx),
      "IVssBackupComponents.SetContext",
    )
  except VssError:
    discard result.comp.lpVtbl.Release(result.comp)
    result.comp = nil
    raise

proc newVssSession*(persistent = false, withWriters = false): VssSession =
  ## Create a new VSS session using convenience flags.
  newVssSession(pickCtx(persistent, withWriters))

proc close*(s: VssSession) =
  ## Release COM resources held by the session.
  if s.comp != nil:
    discard s.comp.lpVtbl.Release(s.comp)
    s.comp = nil
  CoUninitialize()

proc filetimeToDateTime*(ts: LARGE_INTEGER): DateTime =
  ## Convert Windows FILETIME (100ns ticks since 1601) to UTC DateTime.
  let ft100ns = cast[uint64](ts.QuadPart)
  if ft100ns <= EPOCH_DIFF_100NS:
    return fromUnix(0).utc
  let unixSecs = (ft100ns - EPOCH_DIFF_100NS) div TICKS_PER_SEC
  result = fromUnix(unixSecs.int64).utc # Time -> DateTime (UTC)

proc `$`(dt: DateTime): string =
  dt.format("yyyy-MM-dd HH:mm:ss")

proc `$`(g: GUID): string =
  var guidString: LPOLESTR
  StringFromCLSID(cast[REFCLSID](addr g), &guidString)
  result = $guidString

proc fromStr(g: var GUID, s: string) =
  let w = newWideCString(s)
  if not hrOk(CLSIDFromString(w, addr g)):
    raise newException(ValueError, "Invalid GUID format")

proc fromProp(info: var SnapshotInfo, prop: VSS_SNAPSHOT_PROP) =
  info.id = prop.m_SnapshotId
  info.setId = prop.m_SnapshotSetId
  info.devicePath = $prop.m_pwszSnapshotDeviceObject
  info.originalVolume = $prop.m_pwszOriginalVolumeName
  info.originatingMachine = $prop.m_pwszOriginatingMachine
  info.serviceMachine = $prop.m_pwszServiceMachine
  info.created = prop.m_tsCreationTimestamp.filetimeToDateTime
  info.persistent = (prop.m_lSnapshotAttributes and VSS_VOLSNAP_ATTR_PERSISTENT) != 0

# proc fromProp(state: var SnapshotState, prop: VSS_SNAPSHOT_PROP) =
#   state.exposed = true
#   state.exposedPath = $prop.m_pwszExposedPath
#   state.exposedName = $prop.m_pwszExposedName

proc `$`*(s: SnapshotInfo): string =
  ## Human-readable multi-line representation of SnapshotInfo.
  result = "snapshotID: " & $s.id & "\n"
  result.add "SetID: " & $s.setId & "\n"
  result.add "DevicePath: " & s.devicePath & "\n"
  result.add "OriginalVolume: " & s.originalVolume & "\n"
  result.add "OriginatingMachine: " & s.originatingMachine & "\n"
  result.add "ServiceMachine: " & s.serviceMachine & "\n"
  result.add "Created: " & $s.created & "\n"
  result.add "Persistent: " & $s.persistent

proc refreshSnapshots*(session: var VssSession) =
  ## Enumerate existing VSS snapshots and return basic info.
  var
    penumObj: ptr IVssEnumObject
    queried = GUID()
    eQueriedObjectType = VSS_OBJECT_NONE
    returned_type = VSS_OBJECT_SNAPSHOT
    snapshots = initTable[GUID, Snapshot]()

  # Query all snapshots (queried = GUID_NULL)
  ensureHrOk(
    session.comp.lpVtbl.Query(
      session.comp, queried, eQueriedObjectType, returned_type, addr penumObj
    ),
    "IVssBackupComponents.Query",
  )
  if penumObj.isNil:
    session.snapshots = snapshots
    return

  var
    fetched: ULONG = 0
    prop: VSS_OBJECT_PROP
  while hrOk(penumObj.lpVtbl.Next(penumObj, 1.ULONG, addr prop, addr fetched)) and
      fetched == 1:
    if prop.Type == VSS_OBJECT_SNAPSHOT:
      var snapshot = Snapshot()
      snapshot.info.fromProp(prop.Obj.Snap)
      VssFreeSnapshotProperties(addr prop.Obj.Snap)
      snapshots[snapshot.info.id] = snapshot
  if not penumObj.isNil:
    discard penumObj.lpVtbl.Release(penumObj)
  session.snapshots = snapshots

proc listSnapshots*(session: var VssSession): Table[GUID, Snapshot] =
  ## Refresh and return the current snapshot table (id -> Snapshot).
  session.refreshSnapshots()
  return session.snapshots

proc createSnapshot*(s: var VssSession, volume: string, openHandle = false): Snapshot =
  ## Create a snapshot for the given volume and optionally open a device handle.
  if s.ctx == VSS_CTX_ALL:
    raise newException(
      ValueError,
      "VSS_CTX_ALL is for queries only; pick a concrete context for creation.",
    )
  var vol = volume
  if vol.len == 2 and vol[1] == ':':
    vol.add r"\"
  elif vol.len > 0 and not (vol.endsWith(r"\") or vol.endsWith("/")):
    vol.add r"\"
  var
    wvol = newWideCString(vol)
    async: ptr IVssAsync
    prop: VSS_SNAPSHOT_PROP
    snapId, setId, providerId: GUID
  try:
    ensureHrOk(
      s.comp.lpVtbl.StartSnapshotSet(s.comp, addr setId),
      "IVssBackupComponents.StartSnapshotSet",
    )
    ensureHrOk(
      s.comp.lpVtbl.AddToSnapshotSet(s.comp, wvol, providerId, addr snapId),
      "IVssBackupComponents.AddToSnapshotSet",
    )
    ensureHrOk(
      s.comp.lpVtbl.DoSnapshotSet(s.comp, addr async),
      "IVssBackupComponents.DoSnapshotSet",
    )
    ensureHrOk(
      s.comp.lpVtbl.GetSnapshotProperties(s.comp, snapId, addr prop),
      "IVssBackupComponents.GetSnapshotProperties",
    )
  except VssError:
    discard s.comp.lpVtbl.AbortBackup(s.comp)
    raise
  defer:
    VssFreeSnapshotProperties(addr prop)

  s.refreshSnapshots()
  result = s.snapshots[snapId]
  if not openHandle:
    return

  result.state.handle = CreateFileW(
    prop.m_pwszSnapshotDeviceObject,
    GENERIC_READ,
    FILE_SHARE_READ or FILE_SHARE_WRITE or FILE_SHARE_DELETE,
    nil,
    OPEN_EXISTING,
    FILE_ATTRIBUTE_NORMAL,
    0,
  )

proc deleteSnapshot*(s: var VssSession, snapshotId: GUID, force = true): bool =
  ## Delete a single snapshot by GUID. Returns true if one or more snapshots were deleted.
  var
    deleted: LONG = 0
    deletedId: GUID
  let f: BOOL = if force: TRUE else: FALSE
  ensureHrOk(
    s.comp.lpVtbl.DeleteSnapshots(
      s.comp, snapshotId, VSS_OBJECT_SNAPSHOT, f, addr deleted, addr deletedId
    ),
    "IVssBackupComponents.DeleteSnapshots",
  )
  result = deleted > 0

proc deleteSnapshot*(s: var VssSession, snapshotIdStr: string, force = true): bool =
  ## Delete a snapshot by its string GUID representation.
  var gid: GUID
  gid.fromStr(snapshotIdStr)
  result = deleteSnapshot(s, gid, force)

# proc exposeSnapshot*(s: VssSession; volume: string; mountPoint: string): ExposedSnapshot =
#   ## Expose snapshot at mount point (drive letter or path).
#   discard

# proc unexposeSnapshot*(snap: SnapshotHandle) =
#   ## Unexpose snapshot from mount point.
#   discard

# # --- Block device access ------------------------------------------------------

# proc openSnapshotDevice*(snap: SnapshotHandle; unbuffered = true): Handle =
#   ## Open snapshot device as raw block device (returns WinAPI HANDLE).
#   discard

# proc openExistingSnapshotDevice*(devicePath: string; unbuffered = true): Handle =
#   ## Open snapshot device by path (existing snapshot).
#   discard

# proc querySectorSize*(h: Handle): int =
#   ## Query sector size of block device handle.
#   discard

# proc queryLength*(h: Handle): uint64 =
#   ## Query total length of block device handle.
#   discard
