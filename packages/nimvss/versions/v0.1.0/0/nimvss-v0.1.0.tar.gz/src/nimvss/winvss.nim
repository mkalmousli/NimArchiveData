## Low-level FFI bindings to Windows VSS (vssapi.dll).
##
## This module exposes the minimal set of types, constants, interfaces,
## and functions required by the high-level `nimvss/snapshot` helpers.
## Prefer using `nimvss/snapshot` unless you need direct interop.
import winim/[lean, com]

const
  VSS_VOLSNAP_ATTR_PERSISTENT* = 0x00000001'i32
  VSS_CTX_FILE_SHARE_BACKUP* = 0x00000010'i32
  VSS_CTX_NAS_ROLLBACK* = 0x00000019'i32
  VSS_CTX_APP_ROLLBACK* = 0x00000009'i32
  VSS_CTX_BACKUP* = 0x00000000'i32
  VSS_CTX_ALL* = 0xffffffff'i32

type
  VSS_ID* = GUID

  VSS_SNAPSHOT_CONTEXT* = int32

  VSS_OBJECT_TYPE* = enum
    VSS_OBJECT_UNKNOWN = 0
    VSS_OBJECT_NONE = 1
    VSS_OBJECT_SNAPSHOT_SET = 2
    VSS_OBJECT_SNAPSHOT = 3
    VSS_OBJECT_PROVIDER = 4
    VSS_OBJECT_TYPE_COUNT = 5

  VSS_SNAPSHOT_PROP* = object
    m_SnapshotId*: VSS_ID
    m_SnapshotSetId*: VSS_ID
    m_lSnapshotsCount*: int32
    m_pwszSnapshotDeviceObject*: LPWSTR
    m_pwszOriginalVolumeName*: LPWSTR
    m_pwszOriginatingMachine*: LPWSTR
    m_pwszServiceMachine*: LPWSTR
    m_pwszExposedName*: LPWSTR
    m_pwszExposedPath*: LPWSTR
    m_ProviderId*: VSS_ID
    m_lSnapshotAttributes*: int32
    m_tsCreationTimestamp*: LARGE_INTEGER
    m_eStatus*: int32

  VSS_OBJECT_PROP_UNION* {.bycopy, union.} = object
    Snap*: VSS_SNAPSHOT_PROP

  VSS_OBJECT_PROP* = object
    Type*: VSS_OBJECT_TYPE
    Obj*: VSS_OBJECT_PROP_UNION

  IVssEnumObjectVtbl* = object
    QueryInterface*: proc(
      self: ptr IVssEnumObject, riid: ptr GUID, ppv: ptr pointer
    ): HRESULT {.stdcall.}
    AddRef*: proc(self: ptr IVssEnumObject): ULONG {.stdcall.}
    Release*: proc(self: ptr IVssEnumObject): ULONG {.stdcall.}
    Next*: proc(
      self: ptr IVssEnumObject,
      celt: ULONG,
      rgelt: ptr VSS_OBJECT_PROP,
      pceltFetched: ptr ULONG,
    ): HRESULT {.stdcall.}
    Skip*: proc(self: ptr IVssEnumObject, celt: ULONG): HRESULT {.stdcall.}
    Reset*: proc(self: ptr IVssEnumObject): HRESULT {.stdcall.}
    Clone*: proc(self: ptr IVssEnumObject, ppenum: ptr pointer): HRESULT {.stdcall.}

  IVssEnumObject* = object
    lpVtbl*: ptr IVssEnumObjectVtbl

  # Opaque forward declarations to keep signatures without pulling full SDK
  IVssWriterComponentsExt* = object
  IVssAsync* = object
  IVssExamineWriterMetadata* = object
  VSS_COMPONENT_TYPE* = int32
  VSS_BACKUP_TYPE* = int32
  VSS_RESTORE_TYPE* = int32
  VSS_WRITER_STATE* = int32
  VSS_FILE_RESTORE_STATUS* = int32

  IVssBackupComponentsVtbl* = object
    QueryInterface*: proc(
      self: ptr IVssBackupComponents, riid: ptr GUID, ppv: ptr pointer
    ): HRESULT {.stdcall.}
    AddRef*: proc(self: ptr IVssBackupComponents): ULONG {.stdcall.}
    Release*: proc(self: ptr IVssBackupComponents): ULONG {.stdcall.}
    GetWriterComponentsCount*:
      proc(self: ptr IVssBackupComponents, components: ptr UINT): HRESULT {.stdcall.}
    GetWriterComponents*: proc(
      self: ptr IVssBackupComponents,
      index: UINT,
      writer: ptr ptr IVssWriterComponentsExt,
    ): HRESULT {.stdcall.}
    InitializeForBackup*:
      proc(self: ptr IVssBackupComponents, bstrXML: BSTR): HRESULT {.stdcall.}
    SetBackupState*: proc(
      self: ptr IVssBackupComponents,
      select_components: BOOL,
      state: BOOL,
      typ: VSS_BACKUP_TYPE,
      partial_support: BOOL,
    ): HRESULT {.stdcall.}
    InitializeForRestore*:
      proc(self: ptr IVssBackupComponents, xml: BSTR): HRESULT {.stdcall.}
    SetRestoreState*: proc(
      self: ptr IVssBackupComponents, restore: VSS_RESTORE_TYPE
    ): HRESULT {.stdcall.}
    GatherWriterMetadata*: proc(
      self: ptr IVssBackupComponents, async: ptr ptr IVssAsync
    ): HRESULT {.stdcall.}
    GetWriterMetadataCount*:
      proc(self: ptr IVssBackupComponents, count: ptr UINT): HRESULT {.stdcall.}
    GetWriterMetadata*: proc(
      self: ptr IVssBackupComponents,
      index: UINT,
      instance: ptr VSS_ID,
      metadata: ptr ptr IVssExamineWriterMetadata,
    ): HRESULT {.stdcall.}
    FreeWriterMetadata*: proc(self: ptr IVssBackupComponents): HRESULT {.stdcall.}
    AddComponent*: proc(
      self: ptr IVssBackupComponents,
      instance: VSS_ID,
      id: VSS_ID,
      ct: VSS_COMPONENT_TYPE,
      wszLogicalPath: LPCWSTR,
      name: LPCWSTR,
    ): HRESULT {.stdcall.}
    PrepareForBackup*: proc(
      self: ptr IVssBackupComponents, async: ptr ptr IVssAsync
    ): HRESULT {.stdcall.}
    AbortBackup*: proc(self: ptr IVssBackupComponents): HRESULT {.stdcall.}
    GatherWriterStatus*: proc(
      self: ptr IVssBackupComponents, async: ptr ptr IVssAsync
    ): HRESULT {.stdcall.}
    GetWriterStatusCount*:
      proc(self: ptr IVssBackupComponents, count: ptr UINT): HRESULT {.stdcall.}
    FreeWriterStatus*: proc(self: ptr IVssBackupComponents): HRESULT {.stdcall.}
    GetWriterStatus*: proc(
      self: ptr IVssBackupComponents,
      index: UINT,
      instance: ptr VSS_ID,
      id: ptr VSS_ID,
      writer: ptr BSTR,
      status: ptr VSS_WRITER_STATE,
      failure: ptr HRESULT,
    ): HRESULT {.stdcall.}
    SetBackupSucceeded*: proc(
      self: ptr IVssBackupComponents,
      instance: VSS_ID,
      id: VSS_ID,
      ct: VSS_COMPONENT_TYPE,
      path: LPCWSTR,
      name: LPCWSTR,
      succeeded: BOOL,
    ): HRESULT {.stdcall.}
    SetBackupOptions*: proc(
      self: ptr IVssBackupComponents,
      id: VSS_ID,
      ct: VSS_COMPONENT_TYPE,
      path: LPCWSTR,
      name: LPCWSTR,
      options: LPCWSTR,
    ): HRESULT {.stdcall.}
    SetSelectedForRestore*: proc(
      self: ptr IVssBackupComponents,
      id: VSS_ID,
      ct: VSS_COMPONENT_TYPE,
      path: LPCWSTR,
      name: LPCWSTR,
      selected_restore: BOOL,
    ): HRESULT {.stdcall.}
    SetRestoreOptions*: proc(
      self: ptr IVssBackupComponents,
      id: VSS_ID,
      ct: VSS_COMPONENT_TYPE,
      path: LPCWSTR,
      name: LPCWSTR,
      options: LPCWSTR,
    ): HRESULT {.stdcall.}
    SetAdditionalRestores*: proc(
      self: ptr IVssBackupComponents,
      id: VSS_ID,
      ct: VSS_COMPONENT_TYPE,
      path: LPCWSTR,
      name: LPCWSTR,
      additional: BOOL,
    ): HRESULT {.stdcall.}
    SetPreviousBackupStamp*: proc(
      self: ptr IVssBackupComponents,
      id: VSS_ID,
      ct: VSS_COMPONENT_TYPE,
      path: LPCWSTR,
      name: LPCWSTR,
      stamp: LPCWSTR,
    ): HRESULT {.stdcall.}
    SaveAsXML*: proc(self: ptr IVssBackupComponents, xml: ptr BSTR): HRESULT {.stdcall.}
    BackupComplete*: proc(
      self: ptr IVssBackupComponents, async: ptr ptr IVssAsync
    ): HRESULT {.stdcall.}
    AddAlternativeLocationMapping*: proc(
      self: ptr IVssBackupComponents,
      id: VSS_ID,
      ctype: VSS_COMPONENT_TYPE,
      logical: LPCWSTR,
      name: LPCWSTR,
      path: LPCWSTR,
      filespec: LPCWSTR,
      recursive: BOOL,
      destination: LPCWSTR,
    ): HRESULT {.stdcall.}
    AddRestoreSubcomponent*: proc(
      self: ptr IVssBackupComponents,
      id: VSS_ID,
      ctype: VSS_COMPONENT_TYPE,
      logical: LPCWSTR,
      name: LPCWSTR,
      path: LPCWSTR,
      sub_name: LPCWSTR,
      repair: BOOL,
    ): HRESULT {.stdcall.}
    SetFileRestoreStatus*: proc(
      self: ptr IVssBackupComponents,
      id: VSS_ID,
      ct: VSS_COMPONENT_TYPE,
      path: LPCWSTR,
      name: LPCWSTR,
      status: VSS_FILE_RESTORE_STATUS,
    ): HRESULT {.stdcall.}
    AddNewTarget*: proc(
      self: ptr IVssBackupComponents,
      id: VSS_ID,
      ct: VSS_COMPONENT_TYPE,
      logical: LPCWSTR,
      component: LPCWSTR,
      path: LPCWSTR,
      filename: LPCWSTR,
      recursive: BOOL,
      alternate: LPCWSTR,
    ): HRESULT {.stdcall.}
    SetRangesFilePath*: proc(
      self: ptr IVssBackupComponents,
      id: VSS_ID,
      ct: VSS_COMPONENT_TYPE,
      logical: LPCWSTR,
      component: LPCWSTR,
      partial: UINT,
      ranges: LPCWSTR,
    ): HRESULT {.stdcall.}
    PreRestore*: proc(self: ptr IVssBackupComponents, async: ptr ptr IVssAsync): HRESULT {.
      stdcall
    .}
    PostRestore*: proc(
      self: ptr IVssBackupComponents, async: ptr ptr IVssAsync
    ): HRESULT {.stdcall.}
    SetContext*:
      proc(self: ptr IVssBackupComponents, context: LONG): HRESULT {.stdcall.}
    StartSnapshotSet*:
      proc(self: ptr IVssBackupComponents, id: ptr VSS_ID): HRESULT {.stdcall.}
    AddToSnapshotSet*: proc(
      self: ptr IVssBackupComponents, volume: LPCWSTR, id: VSS_ID, snapshot: ptr VSS_ID
    ): HRESULT {.stdcall.}
    DoSnapshotSet*: proc(
      self: ptr IVssBackupComponents, async: ptr ptr IVssAsync
    ): HRESULT {.stdcall.}
    DeleteSnapshots*: proc(
      self: ptr IVssBackupComponents,
      objectId: VSS_ID,
      objType: VSS_OBJECT_TYPE,
      force: BOOL,
      snapshots: ptr LONG,
      id: ptr VSS_ID,
    ): HRESULT {.stdcall.}
    ImportSnapshots*: proc(
      self: ptr IVssBackupComponents, async: ptr ptr IVssAsync
    ): HRESULT {.stdcall.}
    BreakSnapshotSet*:
      proc(self: ptr IVssBackupComponents, snapshot: VSS_ID): HRESULT {.stdcall.}
    GetSnapshotProperties*: proc(
      self: ptr IVssBackupComponents, snapshot: VSS_ID, prop: ptr VSS_SNAPSHOT_PROP
    ): HRESULT {.stdcall.}
    Query*: proc(
      self: ptr IVssBackupComponents,
      queried: VSS_ID,
      queried_type: VSS_OBJECT_TYPE,
      returned_type: VSS_OBJECT_TYPE,
      enums: ptr ptr IVssEnumObject,
    ): HRESULT {.stdcall.}
    IsVolumeSupported*: proc(
      self: ptr IVssBackupComponents,
      provider: VSS_ID,
      volume: LPCWSTR,
      supported: ptr BOOL,
    ): HRESULT {.stdcall.}
    DisableWriterClasses*: proc(
      self: ptr IVssBackupComponents, writer_id: ptr VSS_ID, class_id: UINT
    ): HRESULT {.stdcall.}
    EnableWriterClasses*: proc(
      self: ptr IVssBackupComponents, classid: ptr VSS_ID, id: UINT
    ): HRESULT {.stdcall.}
    DisableWriterInstances*: proc(
      self: ptr IVssBackupComponents, instance: ptr VSS_ID, id: UINT
    ): HRESULT {.stdcall.}
    ExposeSnapshot*: proc(
      self: ptr IVssBackupComponents,
      snapshot: VSS_ID,
      path: LPCWSTR,
      attributes: LONG,
      expose: LPCWSTR,
      exposed: ptr LPCWSTR,
    ): HRESULT {.stdcall.}
    RevertToSnapshot*: proc(
      self: ptr IVssBackupComponents, snapshot: VSS_ID, force: BOOL
    ): HRESULT {.stdcall.}
    QueryRevertStatus*: proc(
      self: ptr IVssBackupComponents, volume: LPCWSTR, async: ptr ptr IVssAsync
    ): HRESULT {.stdcall.}

  IVssBackupComponents* = object
    lpVtbl*: ptr IVssBackupComponentsVtbl

### vssapi declarations
proc CreateVssBackupComponentsInternal*(
  ppBackup: ptr ptr IVssBackupComponents
): HRESULT {.stdcall, dynlib: "vssapi.dll", importc.}

proc VssFreeSnapshotProperties*(
  pProp: ptr VSS_SNAPSHOT_PROP
) {.stdcall, dynlib: "vssapi.dll", importc.}

###
