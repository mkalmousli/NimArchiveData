## Windows privilege helpers.
##
## Utilities to enable/check process token privileges required for some
## VSS operations (e.g., `SeBackupPrivilege`).
import winim/lean
import errors

proc enablePrivilege*(privilege: string, enable = true): bool =
  ## Enable or disable a process token privilege by name.
  ## Returns true if privilege is enabled/disabled as requested.
  ## Raises WinError on underlying WinAPI call failures.
  var
    tp: TOKEN_PRIVILEGES
    luid: LUID

  ensureTrue(
    LookupPrivilegeValue(NULL, privilege.LPCWSTR, luid), "LookupPrivilegeValue"
  )

  tp.Privileges[0].Attributes = (if enable: SE_PRIVILEGE_ENABLED else: 0)
  tp.PrivilegeCount = 1
  tp.Privileges[0].Luid = luid

  var hToken: HANDLE
  defer:
    hToken.CloseHandle()
  ensureTrue(
    OpenProcessToken(
      GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES or TOKEN_QUERY, addr hToken
    ),
    "OpenProcessToken",
  )

  # Adjusting token can succeed but not assign privilege; detect via GetLastError
  SetLastError(0) # clear prior error
  ensureTrue(
    AdjustTokenPrivileges(
      hToken,
      FALSE,
      addr tp,
      (sizeof(tp)).DWORD,
      cast[PTOKEN_PRIVILEGES](NULL),
      cast[PDWORD](NULL),
    ),
    "AdjustTokenPrivileges",
  )

  let gl = GetLastError()
  if gl == ERROR_NOT_ALL_ASSIGNED:
    return false
  return true

proc havePrivilege*(privilege: string): bool =
  ## Check if current process has given privilege.
  ## Returns true only if the privilege exists and is enabled.
  ## Raises WinError on underlying WinAPI call failures.
  var luid: LUID
  ensureTrue(
    LookupPrivilegeValue(NULL, privilege.LPCWSTR, luid), "LookupPrivilegeValue"
  )

  var hToken: HANDLE
  defer:
    hToken.CloseHandle()
  ensureTrue(
    OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, addr hToken), "OpenProcessToken"
  )

  var reqLen: DWORD = 0
  # First call is expected to return 0 with ERROR_INSUFFICIENT_BUFFER; just capture reqLen.
  discard GetTokenInformation(
    hToken,
    tokenPrivileges.TOKEN_INFORMATION_CLASS,
    cast[LPVOID](nil),
    0.DWORD,
    addr reqLen,
  )

  var buf = newSeq[byte](reqLen.int)
  ensureTrue(
    GetTokenInformation(
      hToken, tokenPrivileges.TOKEN_INFORMATION_CLASS, addr buf[0], reqLen, addr reqLen
    ),
    "GetTokenInformation",
  )

  let ptp = cast[PTOKEN_PRIVILEGES](addr buf[0])
  for i in 0 ..< ptp[].PrivilegeCount.int:
    let
      privs = cast[ptr UncheckedArray[LUID_AND_ATTRIBUTES]](addr ptp[].Privileges[0])
      la = privs[i]
    if la.Luid.LowPart == luid.LowPart and la.Luid.HighPart == luid.HighPart:
      return (la.Attributes and SE_PRIVILEGE_ENABLED) != 0
  return false
