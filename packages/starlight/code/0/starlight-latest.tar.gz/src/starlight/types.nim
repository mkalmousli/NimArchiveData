## Core types for the SSR framework.

import std/[tables, sets]
import chronos
import chronos/apps/http/httpserver

export tables, chronos, httpserver

type
  ParamKind* = enum
    pkString, pkInt, pkFloat, pkBool

  SegmentKind* = enum
    skStatic, skParam, skWildcard

  PatternSegment* = object
    name*: string
    kind*: SegmentKind
    paramKind*: ParamKind

  SameSite* = enum
    Default, None, Lax, Strict

  Cookies* = ref object
    request*: RequestData ## Ref to request for lazy Cookie header parsing in `get`.
    parsed*: Table[string, string]
    isParsed*: bool
    pending*: seq[string]

  RequestData* = ref object
    headers*: HttpTable
    body*: string
    query*: Table[string, string]
    ip*: string

  SessionValueKind* = enum
    svkString, svkInt, svkFloat, svkBool

  SessionValue* = object
    case kind*: SessionValueKind
    of svkString: strVal*: string
    of svkInt: intVal*: int
    of svkFloat: floatVal*: float
    of svkBool: boolVal*: bool

  Session* = ref object
    id*: string
    data*: Table[string, SessionValue]
    isModified*: bool
    isNew*: bool

  SessionStore* = ref object of RootObj

  Context* = ref object
    path*: string
    httpMethod*: HttpMethod
    pathParams*: Table[string, string]
    request*: RequestData
    router*: Router
    cookies*: Cookies
    session*: Session

  Response* = object
    code*: HttpCode = Http200
    body*: string
    headers*: HttpTable

  HandlerProc* = proc(ctx: Context): Future[Response] {.
    async: (raises: [CatchableError]), gcsafe.}

  MiddlewareProc* = proc(ctx: Context, next: HandlerProc): Future[Response] {.
    async: (raises: [CatchableError]), gcsafe.}

  HandlerEntry* = object
    handler*: HandlerProc
    middlewares*: seq[MiddlewareProc]

  PrefixTreeNode* = ref object
    segment*: string
    kind*: SegmentKind
    paramKind*: ParamKind
    children*: seq[PrefixTreeNode]
    handlers*: Table[HttpMethod, HandlerEntry]

  Router* = ref object
    root*: PrefixTreeNode
    globalMiddlewares*: seq[MiddlewareProc]
    errorHandlers*: Table[HttpCode, HandlerProc]
    cdnDirs*: seq[CDNEntry]

  MatchResult* = object
    handler*: HandlerProc
    params*: Table[string, string]
    middlewares*: seq[MiddlewareProc]

  RouteEntry* = object
    httpMethod*: HttpMethod
    pattern*: string
    handler*: HandlerProc
    middlewares*: seq[MiddlewareProc]

  RouteGroup* = object
    entries*: seq[RouteEntry]

  CDNEntry* = object
    path*: string
    proxy*: string
    extensions*: HashSet[string]
    ignoreExtensions*: HashSet[string]

  RefKind* = enum
    AbsRef    ## Absolute URL: "/users/alice"
    RelRef    ## Relative URL: "./users/alice"

  RouteRef*[P: static string] = object
    entry*: RouteEntry
