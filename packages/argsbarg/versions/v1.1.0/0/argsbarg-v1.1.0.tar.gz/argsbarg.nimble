version = "1.1.0"
author = "Brian Dombroski"
description = "argsbarg: schema based cli framework with zsh completions"
license = "MIT"
srcDir = "src"

requires "nim >= 2.0.0"
