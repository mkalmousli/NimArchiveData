const foo* = 123
