
const
  ClientIsMain* = isMainModule
