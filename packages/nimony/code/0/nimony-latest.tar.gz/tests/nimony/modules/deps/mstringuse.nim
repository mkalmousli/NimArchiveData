proc usesString*() =
  discard "abc"
