import deps/mstringuse

usesString()
