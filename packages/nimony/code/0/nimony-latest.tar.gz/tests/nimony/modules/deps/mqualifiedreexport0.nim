proc openBar*() = discard
