type Foo* = int
