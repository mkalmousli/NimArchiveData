type Foo* = float
