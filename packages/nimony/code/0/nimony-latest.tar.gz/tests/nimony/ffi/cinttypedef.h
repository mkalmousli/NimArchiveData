typedef int CIntTypeDef;
