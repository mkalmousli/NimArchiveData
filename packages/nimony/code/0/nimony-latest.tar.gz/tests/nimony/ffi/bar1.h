typedef struct {} Bar1;
