
template eraseToplevelBlocks* =
  {.plugin: "mmoduleplugin".}
