typedef struct {} Bar;
