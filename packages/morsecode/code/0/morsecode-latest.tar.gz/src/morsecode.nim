import strutils, tables

const
  letterSep = " "
  wordSep = "   "

let morseMap = {
  'A': ".-",    'B': "-...",  'C': "-.-.",  'D': "-..",
  'E': ".",     'F': "..-.",  'G': "--.",   'H': "....",
  'I': "..",    'J': ".---",  'K': "-.-",   'L': ".-..",
  'M': "--",    'N': "-.",    'O': "---",   'P': ".--.",
  'Q': "--.-",  'R': ".-.",   'S': "...",   'T': "-",
  'U': "..-",   'V': "...-",  'W': ".--",   'X': "-..-",
  'Y': "-.--",  'Z': "--..",

  '0': "-----", '1': ".----", '2': "..---", '3': "...--",
  '4': "....-", '5': ".....", '6': "-....", '7': "--...",
  '8': "---..", '9': "----."
}.toTable()

let revMap = block:
  var t = initTable[string, string]()
  for k, v in morseMap.pairs:
    t[v] = $k
  t

proc encode*(text: string): string =
  var result: seq[string]
  for word in text.splitWhitespace():
    var wordMorse: seq[string]
    for ch in word.toUpperAscii():
      if ch in morseMap: wordMorse.add(morseMap[ch])
    result.add(wordMorse.join(letterSep))
  result.join(wordSep)

proc decode*(text: string): string =
  var result: seq[string]
  for word in text.strip().split(wordSep):
    var wordText: seq[string]
    for symbol in word.strip().split(letterSep):
      if symbol in revMap: wordText.add(revMap[symbol])
      else: wordText.add("?")
    result.add(wordText.join())
  result.join(" ")
