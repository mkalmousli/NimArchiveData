import unittest
import morsecode

test "encode basic words":
  check encode("HELLO") == ".... . .-.. .-.. ---"
  check encode("HELLO WORLD") == ".... . .-.. .-.. ---   .-- --- .-. .-.. -.."
  check encode("123") == ".---- ..--- ...--"

test "encode is case insensitive":
  check encode("sos") == "... --- ..."
  check encode("HeLLo") == ".... . .-.. .-.. ---"

test "encode skips unsupported characters":
  check encode("HELLO!") == ".... . .-.. .-.. ---"

test "decode basic morse code":
  check decode(".... . .-.. .-.. ---") == "HELLO"
  check decode(".... . .-.. .-.. ---   .-- --- .-. .-.. -..") == "HELLO WORLD"
  check decode(".---- ..--- ...--") == "123"

test "decode handles unknown symbols":
  check decode("..--") == "?"
  check decode(".... . .-. .-.. ---") == "HERLO"

test "decode trims and normalizes input":
  check decode("   ... --- ...   ") == "SOS"
  check decode(".... .\t .-.. .-.. ---") == "H?LLO"
