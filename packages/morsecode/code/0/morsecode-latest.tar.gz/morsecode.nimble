# Package

version       = "0.1.0"
author        = "Nemuel Wainaina"
description   = "Encode and decode text using standard international Morse code"
license       = "GPL-3.0-or-later"
srcDir        = "src"

# Dependencies

requires "nim >= 1.6.12"
