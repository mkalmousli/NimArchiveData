import parsecfg
import streams
import strutils
import sequtils

proc getVersion*(): string = 
  let nimble = staticRead("../../norg.nimble")
  var p: Config = loadConfig(newStringStream(nimble))
  let vers = p.getSectionValue("","version")
  echo "Compiling version: v", vers
  return "v" & vers

proc newerThan*(a,b: string): bool =
  echo "Current Version: " & b
  echo "Latest  Version: " & a
  if a == b: return false
  let new = a[1..^1].split(".").map(proc(s: string): int = s.parseInt())
  let cur = b[1..^1].split(".").map(proc(s: string): int = s.parseInt())
  for i in countup(0, len(cur) - 1):
    if new[i] < cur[i]: return false
  return true
