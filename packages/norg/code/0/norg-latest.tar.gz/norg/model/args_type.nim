import command_type
export command_type

type 
  NorgArgs* = object
    show_version*: bool
    update*: bool
    config_file*: string
    extract_destination*: string
    command*: Command
    repository*: string
    archive*: string
    stats*: bool
    further_args*: seq[string]
    prerelease*: bool


proc newNorgArgs*(): NorgArgs =
  var args = NorgArgs()
  return args

