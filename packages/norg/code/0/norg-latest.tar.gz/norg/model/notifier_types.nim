import notifier_type
import ../notifier/uptimekuma_notifier
import ../notifier/gatus_notifier

export notifier_type
export uptimekuma_notifier
export gatus_notifier

type
  Notifiers* = object
    uptimekuma*: UptimeKuma
    gatus*: Gatus

