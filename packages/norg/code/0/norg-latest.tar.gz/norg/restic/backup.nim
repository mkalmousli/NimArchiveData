import ../model/config_type
import ../model/state_type
import ../notifier/notifier
import execute
import prune
import exitcodes

import nativesockets
import times
import os

proc createArchive(nc: NorgConfig, repo: Repository, retry: int = 0): ExitCode = 
  let further_args = nc.args.further_args
  let res = run genBackupCommand(repo = repo.path, sources = nc.source_directories, exc= nc.exclusions, further_args = further_args)
  let ec = res.toExitCode
  case ec
  of ResticFailed:
    debug "Backup failed to run, trying again in 15 seconds..."
    sleep 15 * 1000 # 15 seconds
    if retry == nc.retries:
      debug "Backup failed to run " & $nc.retries & " times. Stopping."
      return ec
    else:
      return createArchive(nc, repo, retry + 1)
  else:
    return ec

proc createBackup*(nc: NorgConfig, repo: Repository): ExitCode =
  let start_time = now()
  notify(nc.notifiers, state=Running)
  let ec = createArchive(nc, repo)
  let end_time = now()
  let total = (end_time - start_time).inMilliSeconds()
  case ec
  of ResticSuccess:
    if not repo.append_only:
      discard pruneRepo(nc, repo)
    debug "Backup Success Exit Code : ", $ec
    notify(nc.notifiers, state=Success, runtime=total)
  of ResticFailed:
    debug "Backup Failed Exit Code : ", $ec
    notify(nc.notifiers, state=Failure, runtime=total)
  else:
    notice "Backup Returned Exit Code : ", $ec
    notify(nc.notifiers, state=Failure, runtime=total, msg = $ec)
  return ec
