# Package

version       = "0.2.3"
author        = "Paul Wilde"
description   = "A Borg Backup Orchestration Tool"
license       = "AGPL-3.0-or-later"
srcDir        = "norg"
binDir        = "bin"
bin           = @["norg"]


# Dependencies

requires "nim >= 2.0.0"
requires "parsetoml >= 0.7.1"
requires "argparse >= 4.0.1"
