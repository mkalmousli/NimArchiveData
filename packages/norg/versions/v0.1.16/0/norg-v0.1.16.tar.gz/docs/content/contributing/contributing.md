+++
title = "Contributing"
weight = 80
+++
We are very happy to take on an ideas or issues you may have with Norg, and 
welcome pull requests that can implement these features within reason.  
The source code is published here: [codeberg.org/pswilde/norgbackup](https://codeberg.org/pswilde/norgbackup), which is where you can raise issue and make pull requests.

When creating new features, or adjusting anything within the current state of Norg, 
please also update the documentation to reflect these changes. 
The documentation uses the [Zola](https://getzola.org) static site generator, 
which uses markdown content files in the `docs/content/` directory.
