+++
title = "Initialize Repositories"
weight = 40
+++
Your backup repositories need to be initialized before they can be used. Norg 
has a command to do this for you once you.  
To initialize your repositories one by one, you can run the following command:
```sh
norg -c myconfig.toml init -e repokey-blake2
```
This will initialize a Borg repository using the `repokey-blake2` encryption algorithm, making it ready for use.  

Restic does not use the same encryption algorithm option, so the above command may fail. However, running the below command again, without the `-e repokey-blake2` option 
will initialize a Restic repository correctly, leaving the borg repository untouched.  

**TODO**: We plan to resolve the requirement of running this command twice in the future.

