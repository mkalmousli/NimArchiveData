+++
title = "Configuring Norg"
weight = 20
+++
Norg is configured using a [TOML](https://toml.io) format configuration file.  
There is an [Example Configuration File](/reference/example-configuration) on the norgbackup website that you can use as a base to create your own backups.  

## Many backups from one system
You can run multiple different backups on the same system by specifying different 
configuration files using the `-c` [command line parameter](/reference/command-line).

## Scheduling
Norg can be scheduled to run using your system's task scheduler. For the sake of
this example, we are using `cron` to run a backups every day at 8pm and 10pm.
```ini
0 20 * * * norg -c /home/me/myconfig.toml
0 22 * * * norg -c /home/me/myotherbackup.toml
```
This concept should be transferrable to any other scheduling tool.
