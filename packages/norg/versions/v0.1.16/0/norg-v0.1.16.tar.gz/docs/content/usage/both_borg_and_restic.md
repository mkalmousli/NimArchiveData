+++
title = "Using both Borg and Restic"
weight = 999
+++
Allowances have been made to be able to use both Borg and Restic repositories 
for the same backup in one configuration file, and this will largely work 
correctly. However, caution must be taken when using any direct Borg/Restic 
command line parameters as they could cause either backup tool to fail as it 
does not understand the parameter given.  

A good example of this is the `--stats` parameter. Borg understands this and 
outputs backup stats when its backup has completed. However, Restic does not 
have a `--stats` parameter and fails to run when it is provided.  

Since `Norg version 0.1.6`, we have taken steps to ignore the `--stats` parameter
when provided for restic repositories, so it will work correctly. However, 
other parameters could cause a similar effect. We shall try to cater for these 
as they are learned about. Please file an issue on our [Codeberg Repo](https://codeberg.org/pswilde/norgbackup/issues) if you discover a parameter which causes either backup tool to fail to run.


## Aliased Commands
Terminology in both Borg and Restic differs, but the result is effectively the same.
Some different yet similar commands are aliased so they can be used interchangeably.
The table below shows some of these:  
| Borg Command | Restic Command             | Result                                     |
| ---          | ---                        | ---                                        |
| create       | backup                     | creates a backup                           |
| list         | snapshots                  | lists archives/snapshots                   |
| extract      | restore                    | restores/extracts a backup                 |
| delete       | forget                     | removes a archive/snapshot                 |
| prune        | forget (with --prune flag) | removes snapshots as per `--keep-*` config |

You may specify either command and it will work with both except the `forget` command. This will only forget a single snapshot in restic, and delete a single archive with borg.  
