+++
title = "System Compatibility"
weight = 90
+++
Norg should run on any platform able to compile `nim` code using `nimble`.  
It has been tested on the following operating systems:
- FreeBSD
- Arch Linux
- AlmaLinux
- Rocky Linux
- Debian
- [Windows](#windows-support) (Restic only)

Ultimately, any system that can compile the code and has the `borg` or `restic` 
binary files in the running user's `$PATH` environment variable should be able 
to run `norg` without issue.

## Windows Support
Norg does work on windows but requires `libcrypto` and `libssl`. You can just put 
these libraries in the same directory as the `norg.exe` binary.  
You can also install Nim (which includes these libraries) on Windows and put 
the `./nim/bin` folder in your `$PATH` environment variable for these libraries 
to be found and referenced.
