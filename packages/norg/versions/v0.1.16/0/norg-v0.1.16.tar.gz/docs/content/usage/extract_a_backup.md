+++
title = "Extract/Restore a Backup"
weight = 70
+++
> _"People don't want backups. People want Restores."_

What's the point in backing up if you can't restore from it?  
Of course, Norg has a restore functionality, and can restore an entire backup to 
a directory of your choice.  
To protect current data, Norg will only restore to an empty directory, so it is
important to specify a directory that is empty. Norg will create directories that 
do not exist.

## Steps
First, find the backup you wish to restore. This can easily be done by using 
the [`list`](http://127.0.0.1:1111/usage/inspect-your-backups#list-existing-backups) command.
```sh
norg -c myconfig.toml list
```

Which will give you an output similar to this:
```sh
# For Borg
hostname-2024-08-23T15:46:19.037234 Fri, 2024-08-23 15:46:19 
hostname-2024-08-24T15:21:17.738163 Sat, 2024-08-24 15:21:18

# or for Restic
ID        Time                 Host        Paths     Size
---------------------------------------------------------------
5f2bc4f1  2024-08-23 10:30:25  hostname    /home/me  96.361 MiB
e0de9b6c  2024-08-24 11:50:52  hostname    /home/me  94.123 MiB
```

When you know which archive or snapshot you want to extract, you can run the 
`extract` command with `repository`, `archive` and `destination` parameters.

```sh
# Borg example 
norg -c myconfig.toml extract -r MyBorgRepo -a hostname-2024-08-23T15:46:19.037234 --destination /my/restore/location

# Restic example
norg -c myconfig.toml extract -r MyResticRepo -a 5f2bc4f1 --destination /my/restore/location
```

## Further Command Line Reference
Like with all other commands, you can specify Borg/Restic command line parameters after all other parameters to adjust how the extract will run. Please see [Using both Borg and Restic](/usage/both-borg-and-restic/) for more information.
