+++
title = "Command Line Reference"
weight = 20
+++
Here are the available norg command line parameters for the most recent version. 
If you are using an older version of norg some of these parameters may not work.
Please use `norg --help` to view all available parameters in your version.
```help
{{ get_source(path="other/command_line.txt",pure=true) }}
```

The `-c`, or `--config`, parameter is required. Failing to provide this will only show the above help information.  

When specifying the `-r` or `--repository` parameter, you can specify either 
the `label` or `path` for the repository defined in the configuration file.

A sample configuration file can be generated using the `generate_config` argument. By default, the configuration file will be placed in the current directory and named `norg_backup.toml` but you can use the `-c`, `--config` parameter to define an alternative location for it.
