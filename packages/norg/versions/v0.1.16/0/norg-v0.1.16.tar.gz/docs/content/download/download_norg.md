+++
title = "Download Norg"
weight = 0
+++

## Installing from nimble.directory
The latest version of Norg is most simply downloaded and installed using Nim's `nimble` command line tool. 
```sh
nimble install norg
```

## Installing direct from the Norg code repository
You can also install, via nimble, direct from the code repository.
```sh
nimble install https://codeberg.org/pswilde/norgbackup
```

## Building from Source
Norg source code can be downloaded from our [releases page at Codeberg](https://codeberg.org/pswilde/norgbackup/releases) and can be built using the following commands:
```sh
unzip norgbackup-{version}.zip
# or
tar xf norgbackup-{version}.tar.gz

cd norgbackup
nimble install
```

## Pre-compiled Binaries
Pre-compiled binaries are available on our [releases page at Codeberg](https://codeberg.org/pswilde/norgbackup/releases).  

### Updating  
If installed from our Codeberg repository, or if your hostOS and architecture matches a pre-compiled version hosted on our Codeberg respository, then you can update norg by simply running `norg --update`.

