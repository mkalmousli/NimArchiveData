+++
title = "Setting up Norg"
weight = 10
+++
## Prerequisites
Install [Borg](https://borgbackup.readthedocs.io/en/stable/installation.html) or [Restic](https://restic.net/#installation) as these do not get installed automatically.  

You will also need to install [Nim v2](https://nim-lang.org) and `nimble`
- [FreeBSD](https://www.freebsd.org) - `pkg install nimble`
- [Arch Linux](https://archlinux.org) - `pacman -S nimble`
- For other distros you may need to use the official [`choosenim` Installer](https://nim-lang.org/install_unix.html) to get the latest version of nim installed.

## Installation
Norg is listed on [Nimble Directory](https://nimble.directory) so you can install 
norg using nimble
```sh
nimble install norg
```
or, if you'd rather not use the directory, you can install direct from our 
[Codeberg Repo](https://codeberg.org/pswilde/norgbackup):
```sh
nimble install https://codeberg.org/pswilde/norgbackup
```

#### PATH variable
Once installed, `norg` will be installed in your `$HOME/.nimble/bin/` directory.
You should add this location to your `$PATH` variable so it can be found remains 
up-to-date when running `nimble install norg` again.  

## Portability
Norg is a single binary executable, so it can be copied wherever you need providing 
it has been compiled in the required system and architecture beforehand.  
For example, I have multiple FreeBSD servers where I use Norg. I install the latest version on one of these servers, then just copy that binary to all others servers that
need to make use of it.

## Upgrading Norg
Norg can be upgraded easily via nimble:
```sh
# Update nimble directory cache
nimble update
# Upgrade Norg
nimble install norg
```

The latest version of Norg should then be installed in your `$HOME/.nimble/bin/` directory.
