+++
title = "Create a Backup"
weight = 50
+++
Now norg is configured and your repositories are created and initialized, it's 
sensible to test everything is working. Run norg with the `create` command to start a backup like this:
```sh
norg -c myconfig.toml create --stats
```
As the command runs, you should check the output of borg or restic to see if files 
you expect to be backed up are being backed up.  
The `--stats` flag provides statistics of a borg backup once completed. It is 
ignored for Restic backups.  
The `-c` or `--config` option is required, and must reference a norg configuration file.

## Default Options
If you do not specify `create`, or any other option, norg will default to the `create` option anyway, so the above command can be simplified as so:
```sh
norg -c myconfig.toml
```
With Restic, the terminology for creating a snapshot is `backup`. Norg has both `create` and `backup` as aliases to each other, so either will work as desired.
