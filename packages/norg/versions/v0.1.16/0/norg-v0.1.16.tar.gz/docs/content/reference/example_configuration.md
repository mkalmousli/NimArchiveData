+++
title = "Example Configuration"
weight = 10
+++
Below is an example configuration in [`toml`](https://toml.io) format which can be used as a base for setting up a new norg backup.  
This configuration file can be [downloaded here](/downloads/norg.toml.sample).
```toml
{{ get_source(path="downloads/norg.toml.sample",pure=true) }}
```
