+++
title = "Backup Redundancy"
weight = 30
+++
Norg has the ability to back up to multiple repositories using both the [BorgBackup](https://borgbackup.com) or [Restic](https://restic.net) backup utilities.  
To enable this, simply configure multiple different repositories in your configuration file and norg will take care of the rest.  

For example, the `repositories` section of your configuration file may look like this:
```toml
...
[[repositories]]
label = "MyFirstLocation"
path = "/location1"

[[repositories]]
label = "MySecondLocation"
path = "ssh://1234abcd@1234abcd.repo.borgbase.com/./repo"

[[repositories]]
label = "MyThirdLocationUsingRestic"
path = "/location3"
tool = "restic"

[[repositories]]
label = "MyFourthLocationUsingRestic"
path = "rest:https://5678zyxw:9090abab@5678zyxw.repo.borgbase.com"
tool = "restic"
...
```
When running norg with this configuration, it invokes Borg or Restic once per 
repository in sequence (i.e. not at the same time) which means in each 
repository a new archive or snapshot is made containing all source directories.  
This provides redundancy across multiple backup repositories and across backup 
tools. You could even configure multiple storage providers to gain redundancy 
there as well.

