+++
title = "Inspect your Backups"
weight = 60
+++
The output of a backup will be shown in your terminal if running manually. 
You could output this into a log file if you wish, like so:
```sh
norg -c myconfig.toml --stats >> mybackup.log
```
This is great for letting you know some basic information about your backup. 

## List Existing Backups
Norg provides command line parameters to allow you to list your backups for all 
or specific repositories.
```sh
# List all archives/snapshots on all repositories
norg -c myconfig.toml list 

# List all archives/snapshots on a specific repository
norg -c myconfig.toml list -r MyRepository
```
When specifying the `-r` or `--repository` parameter, you can specify either 
the `label` or `path` for the repository defined in the configuration file.

You can also specify further [Borg or Restic command line options](/usage/both-borg-and-restic#further-args)
(like `--last 3` to show the last 3 archives in a Borg repository). It is advised to 
*always* use the `-r` parameter in these cases as specifc flags for Borg do not
work with Restic and vice-versa.

## Mount a Backup
Both Borg and Restic provide the ability to mount an archive (Borg) or repository (Restic) so you can inspect and recover individual files this way. Norg provides the ability to do this via the below command:
```sh
# For Borg repositories, where we mount an Archive
norg -c myconfig.toml mount -r MyBorgRepository -a hostname-date-of-backup /path/to/mount/point

# For Restic repositories, where we mount the entire repository
norg -c myconfig.toml mount -r MyResticRepository /path/to/mount/point
```
It is sensible to always provide the `-r` parameter as you will not be able to mount multiple archive/repositories to the same location.  

### Unmount a Backup
Unmounting a backup is different for both Borg and Restic.  
Borg has a `umount` command which can be run via norg as follows:
```sh
norg -c myconfig.toml umount /path/to/mount/point
```

Restic however, remains running after a `mount` command has been issues, and awaits 
`Ctrl+C` keyboard entry to unmount. In short, there is no `umount` command for Restic.

