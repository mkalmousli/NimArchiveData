+++
title = "Before and After Actions"
weight = 90
+++
Norg has the ability to run other commands before and after various points 
during its running session.  
These times are as follows:
* `before_everything` - Runs before anything else happens, just after starting.
* `after_everything` - Runs after everything has happened, just before closing.
* `before_actions` - Runs before any action for each repository.
* `after_actions` - Runs after any action for each repository.
* `before_backup` - Runs before each backup for each repository.
* `after_backup` - Runs after each backup for each repository.
* `before_extract` - Runs before an extract.
* `after_extract` - Runs after an extract.
* `before_prune` - Runs before a prune job (when run manually).
* `after_prune` - Runs after a prune job (when run manually).
* `before_compact` - Runs before a compact action, for each repository.
* `after_compact` - Runs after a compact aciton, for each repository.
* `before_check` - Runs before a check action, for each repository.
* `after_check` - Runs after a check action, for each repository.

The general use here is to run a database backup/dump to store a database 
backup file in a location that is then backed up, but could be used for other things.
