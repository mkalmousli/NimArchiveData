
import std/enumutils

type
  ExitCode* = enum
    BorgSuccess = 0
    BorgGenericWarning = 1
    BorgGenericError = 2
    # For Use with BORG_EXIT_CODES = modern which is not currently used in norg
    BorgSpecificErrorStart = 3
    BorgSpecificErrorEnd = 99
    BorgSpecificWarningStart = 100
    BorgSpecificWarningEnd = 127
    BorgKilledBySignal = 128

proc toExitCode*(i: int): ExitCode =
  case i
  of 0: return BorgSuccess
  of 1: return BorgGenericWarning
  of 2: return BorgGenericError
  # For Use with BORG_EXIT_CODES = modern which is not currently used in norg
  of ord(BorgSpecificErrorStart)..ord(BorgSpecificErrorEnd):
    return BorgSpecificErrorStart
  of ord(BorgSpecificWarningStart)..ord(BorgSpecificWarningEnd):
    return BorgSpecificWarningStart
  else:
    return BorgKilledBySignal

proc `$`*(ec: ExitCode): string = 
  return $ord(ec) & ":" & symbolName(ec)
