import ../model/config_type
import ../model/log_type

import execute
import strformat
import os

proc isEmpty(dir: string): bool =
  var count = 0
  for idx, f in walkDir(dir): return false
  #count += 1
  return count == 0

proc extractArchive*(nc: NorgConfig, repo: Repository): int =
  let archive = fmt"{repo.path}::{nc.args.archive}"
  var further_args = nc.args.further_args
  if nc.args.extract_destination != "":
    discard existsOrCreateDir(nc.args.extract_destination)
    setCurrentDir(nc.args.extract_destination)
  let dir = getCurrentDir()
  if dir.isEmpty():
    info "Restoring..."
    let ok = run genCommand(cmd = "extract", repo = archive, further_args = further_args)
    return ok
  else:
    error "Not restoring to non-empty destination\r\nPlease use the --destination flag or cd to an empty directory."
