import ../model/config_type
import ../model/log_type

import execute
import strformat

proc mountArchive*(nc: NorgConfig, repo: Repository): int =
  let archive = fmt"{repo.path}::{nc.args.archive}"
  let further_args = nc.args.further_args
  let ok = runDiscard genCommand(cmd = "mount", repo = archive, further_args = further_args)
  if ok == 0:
    info fmt"Mounted {archive} at {further_args[0]}"
  else:
    error "Failed to mount ", archive

proc unmountArchive*(nc: NorgConfig): int =
  let ok = runDiscard genCommand(cmd = "umount", repo = "", further_args = nc.args.further_args)
  if ok == 0:
    info "Unmounted ", nc.args.further_args[0]
  else:
    error "Failed to unmount ", nc.args.further_args[0]
