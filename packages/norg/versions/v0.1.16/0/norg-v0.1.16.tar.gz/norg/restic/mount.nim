import ../model/config_type
import ../model/log_type
import execute
import strformat


proc mountSnapshot*(nc: NorgConfig, repo: Repository): int =
  #let further_args = nc.args.further_args[1..^1]
  let further_args = nc.args.further_args
  let ok = runDiscard genCommand(cmd = "mount", repo = repo.path, further_args = further_args)
  if ok == 0:
    info fmt"Mounted {repo.path} at {further_args[0]}"
  else:
    error "Failed to mount ", repo.path
