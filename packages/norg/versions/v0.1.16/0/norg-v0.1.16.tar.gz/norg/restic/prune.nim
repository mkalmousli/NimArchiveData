import ../model/config_type

import execute

  
proc pruneRepo*(nc: NorgConfig, repo: Repository): int = 
  var cmd = genPruneCommand(repo = repo.path, further_args = nc.args.further_args, nc.maintenance)
  return run cmd

proc forgetSnapshot*(nc: NorgConfig, repo: Repository): int = 
  var cmd = genForgetCommand(repo = repo.path, archive = nc.args.archive, further_args = nc.args.further_args)
  return run cmd
