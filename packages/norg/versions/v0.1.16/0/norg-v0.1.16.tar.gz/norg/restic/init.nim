import ../model/config_type
import execute

proc initRepo*(nc: NorgConfig, repo: Repository): int =
  return runDiscard genCommand(cmd = "init", repo = repo.path, further_args = nc.args.further_args)

