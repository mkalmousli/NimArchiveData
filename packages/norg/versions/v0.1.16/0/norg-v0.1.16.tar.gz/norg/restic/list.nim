import ../model/config_type
import execute

proc listSnapshots*(nc: NorgConfig, repo: Repository): int =
  return run genCommand(cmd = "snapshots", repo = repo.path, further_args = nc.args.further_args)


