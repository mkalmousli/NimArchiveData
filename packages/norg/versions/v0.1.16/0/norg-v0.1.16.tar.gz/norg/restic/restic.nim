import ../model/config_type
import ../utils/actions
import ../model/log_type

import init
import backup
import list
import mount
import restore
import prune


proc execute*(nc: NorgConfig, repo: Repository) =
  case nc.args.command
  of INIT:
    info "Initializing repo: ", repo.label
    discard initRepo(nc, repo)
  of CREATE:
    run_actions(norg_config.actions.before_backup)
    info "Backing up to ", repo.label
    discard createBackup(nc, repo)
    run_actions(norg_config.actions.after_backup)
  of LIST:
    info "Listing Snapshots at ", repo.label
    discard listSnapshots(nc, repo)
  of MOUNT:
    info "Mounting Snapshot from ", repo.label
    discard mountSnapshot(nc, repo)
  of EXTRACT:
    run_actions(norg_config.actions.before_extract)
    info "Restoring snapshot from ", repo.label
    discard restoreSnapshot(nc, repo)
    run_actions(norg_config.actions.after_extract)
  of PRUNE:
    run_actions(norg_config.actions.before_prune)
    info "Pruning repo: ", repo.label
    discard pruneRepo(nc, repo)
    run_actions(norg_config.actions.after_prune)
  of DELETE:
    info "Forgetting snapshot: ", nc.args.archive
    discard forgetSnapshot(nc, repo)
  else:
    discard
