import strutils
import strformat

import ../model/command_type
import ../model/maintenance_type
import ../model/exclusions_type
import ../utils/run
export run

proc genCommand*(cmd: string, repo: string, further_args: seq[string]): string =
  let args = further_args.join(" ")
  let cmd = fmt"{RESTIC_BIN} {cmd} -r {repo} {args}"
  return cmd

proc genBackupCommand*(repo: string, sources: seq[string], exc: Exclusions, further_args: seq[string]): string =
  var source_dirs = ""
  for source in sources:
    source_dirs &= fmt""""{source}" """
  let args = further_args.join(" ")
  var cmd = fmt"{RESTIC_BIN} backup -r {repo} {source_dirs}"
  if exc.exclude_file != "":
    cmd = fmt"{cmd} --exclude-file={exc.exclude_file}"
  for exclude in exc.excludes:
    cmd = fmt"{cmd} --exclude={exclude}"
  cmd = fmt"{cmd} {args}"
  return cmd

proc genRestoreCommand*(repo_snapshot: string, destination: string, further_args: seq[string]): string =
  let args = further_args.join(" ")
  let cmd = fmt"{RESTIC_BIN} restore -r {repo_snapshot} --target {destination} {args}"
  return cmd

proc genForgetCommand*(repo: string, archive: string, further_args: seq[string]): string =
  let args = further_args.join(" ")
  let cmd = fmt"{RESTIC_BIN} forget -r {repo} {archive} {args}"
  return cmd

proc genPruneCommand*(repo: string, further_args: seq[string], maintenance: Maintenance): string = 
  let args = further_args.join(" ")
  let cmd = fmt"""{RESTIC_BIN} forget --prune --keep-hourly {maintenance.keep_hourly} --keep-daily {maintenance.keep_daily} --keep-weekly {maintenance.keep_weekly} --keep-monthly {maintenance.keep_monthly} --keep-yearly {maintenance.keep_yearly} -r {repo} {args}"""
  return cmd
