import std/enumutils

# Information about Restic Exit Codes can be found here: https://restic.readthedocs.io/en/stable/075_scripting.html
type 
  ExitCode* = enum
    ResticSuccess = 0
    ResticFailed = 1
    ResticGoRuntimeError = 2
    ResticCantReadSourceData = 3
    ResticRepoNotExist = 10
    ResticFailedToLockRepo = 11
    ResticWrongPassword = 12
    ResticInterrupted = 130


proc `$`*(ec: ExitCode): string = 
  return $ord(ec) & ":" & symbolName(ec)


proc toExitCode*(i: int): ExitCode =
  for e in ExitCode.items:
    if ord(e) == i: return e

