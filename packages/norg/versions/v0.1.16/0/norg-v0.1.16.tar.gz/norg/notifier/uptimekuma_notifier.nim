import ../model/state_type
import ../model/notifier_type
import ../model/log_type
import strformat

import ../utils/httprequest

type 
  UptimeKuma* = object of Notifier
    major_version*: int

proc send_notify*(uk: UptimeKuma, state: State, runtime: int = 0, msg: string = ""): int {.discardable.} =
  var status: string = "down"
  case state
  of Running:
    # Version 2 of UK has a different way of handling 
    # push notifiers which is helpful - we can sending a pending status when starting, 
    # which will only cause a filaure after a period of time has elapsed with 
    # no Success
    if uk.major_version < 2:
      status = "up"
    else:
      status = "pending"
  of Success:
    status = "up"
  else:
    status = "down"
  var message = $state
  if msg != "":
    message &= fmt":{msg}"
  let url = fmt"{uk.base_url}?status={status}&msg={message}&ping={runtime}"

  debug "Sending notification to " & url
  try:
    let res = sendHttpRequest(HttpGet, url)
    if res.status == $Http200:
      return 0
    else:
      return 1
  except:
    error(getCurrentExceptionMsg())

