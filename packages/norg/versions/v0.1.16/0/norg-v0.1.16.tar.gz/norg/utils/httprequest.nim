import httpclient

export httpclient

proc sendHttpRequest*(meth: HttpMethod, url: string, body: string = "", headers: HttpHeaders = newHttpHeaders(), timeout: int = 10): Response =
  let client = newHttpClient(headers = headers, timeout = timeout * 1000)
  var res: Response
  try:
    case meth
    of HttpGET:
      res = client.get(url)
    of HttpPost:
      res = client.post(url, body)
    else:
      discard
  finally:
    client.close()
  return res


