import osproc

proc run_actions*(actions: seq[string]): int {.discardable.} = 
  for action in actions:
    discard execCmd(action)

