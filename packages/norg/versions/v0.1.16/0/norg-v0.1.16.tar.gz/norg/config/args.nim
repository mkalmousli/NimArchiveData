import argparse
import ../model/config_type

var norg_args*: NorgArgs = newNorgArgs()

proc parseArgs*() =
  var p = newParser:
    help("Norg -- " & VERSION & "\r\nA portable borg backup and restic orchestration tool.")
    option("-c", "--config", help="Config file to use.")
    option("-d", "--destination", help="Destination when extracting backup,", required = false)
    option("-r", "--repository", help="Define an explicit repository to work on by either label or path.", required = false)
    option("-a", "--archive", help="The archive or snapshot to operate on.", required = false)
    flag("-s","--stats",help="Provides statistics at the end of a backup (Borg only).")
    arg("command", help="The command to run, defaults to 'create' which will perform a backup.", default=some("create"))
    arg("further_args", nargs = -1, help="Any further arguments to send onto borg or restic.")
    flag("-v","--version",help="Shows the current norg version.")
    flag("-u","--update", help="Checks for a Norg update and attempts to install it.")
  try:
    var opts = p.parse(commandLineParams())
    norg_args.config_file = opts.config
    norg_args.extract_destination = opts.destination
    norg_args.command = opts.command.toCommand()
    norg_args.repository = opts.repository
    norg_args.archive = opts.archive
    norg_args.stats = opts.stats
    norg_args.further_args = opts.further_args
    norg_args.show_version = opts.version
    norg_args.update = opts.update
  except ShortCircuit as err:
    if err.flag == "argparse_help":
      echo err.help
      quit(1)
  except UsageError:
    echo p.help
    stderr.writeLine getCurrentExceptionMsg()
    quit(1)
