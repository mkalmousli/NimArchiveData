import ../model/actions_type
import parsetoml

proc parseActions*(conf: TomlValueRef): Actions =
  var actions: Actions = Actions()
  # Oh I hate this bit..
  
  # Everything
  for action in conf{"before_everything"}.getElems():
    actions.before_everything.add(action.getStr())
  for action in conf{"after_everything"}.getElems():
    actions.after_everything.add(action.getStr())
  # Actions
  for action in conf{"before_actions"}.getElems():
    actions.before_actions.add(action.getStr())
  for action in conf{"after_actions"}.getElems():
    actions.after_actions.add(action.getStr())
  # Backup
  for action in conf{"before_backup"}.getElems():
    actions.before_backup.add(action.getStr())
  for action in conf{"after_backup"}.getElems():
    actions.after_backup.add(action.getStr())
  # Extract
  for action in conf{"before_extract"}.getElems():
    actions.before_extract.add(action.getStr())
  for action in conf{"after_extract"}.getElems():
    actions.after_extract.add(action.getStr())
  # Prune
  for action in conf{"before_prune"}.getElems():
    actions.before_prune.add(action.getStr())
  for action in conf{"after_prune"}.getElems():
    actions.after_prune.add(action.getStr())
  # Compact
  for action in conf{"before_compact"}.getElems():
    actions.before_compact.add(action.getStr())
  for action in conf{"after_compact"}.getElems():
    actions.after_compact.add(action.getStr())
  # Check
  for action in conf{"before_check"}.getElems():
    actions.before_check.add(action.getStr())
  for action in conf{"after_check"}.getElems():
    actions.after_check.add(action.getStr())

  return actions
