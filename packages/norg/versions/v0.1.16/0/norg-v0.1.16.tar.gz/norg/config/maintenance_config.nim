import ../model/maintenance_type
import parsetoml

proc parseMaintenance*(conf: TomlValueRef): Maintenance =
  var maintenance = newMaintenance()
  maintenance.keep_hourly = conf{"keep_hourly"}.getInt(maintenance.keep_hourly)
  maintenance.keep_daily = conf{"keep_daily"}.getInt(maintenance.keep_daily)
  maintenance.keep_weekly = conf{"keep_weekly"}.getInt(maintenance.keep_weekly)
  maintenance.keep_monthly = conf{"keep_monthly"}.getInt(maintenance.keep_monthly)
  maintenance.keep_yearly = conf{"keep_yearly"}.getInt(maintenance.keep_yearly)
  return maintenance
