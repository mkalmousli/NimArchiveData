import sugar
import tool_type

export tool_type

type
  Repository* = object
    path*: string
    label*: string
    tool*: BackupTool
    append_only*: bool

proc findRepository*(repos: seq[Repository], r: string): seq[Repository] =
  let repo = collect:
    for item in repos:
      if item.label == r or item.path == r:
        item
  return repo
