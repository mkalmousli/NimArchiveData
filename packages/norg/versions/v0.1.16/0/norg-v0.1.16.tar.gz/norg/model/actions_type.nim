
type
  Actions* = object
    # Before and after everything for all repositories
    before_everything*: seq[string]
    after_everything*: seq[string]
    # before and after each reposistory
    before_actions*: seq[string]
    after_actions*: seq[string]
    # before and after a backup per respository
    before_backup*: seq[string]
    after_backup*: seq[string]
    # before and after a prune per repository
    before_prune*: seq[string]
    after_prune*: seq[string]
    # before and after an extract per repository
    before_extract*: seq[string]
    after_extract*: seq[string]
    # before and after an compact per repository
    before_compact*: seq[string]
    after_compact*: seq[string]
    # before and after an check per repository
    before_check*: seq[string]
    after_check*: seq[string]
