
type
  Exclusions* = object
    exclude_file*: string
    excludes*: seq[string]
    patterns_file*: string
    patterns*: seq[string]
