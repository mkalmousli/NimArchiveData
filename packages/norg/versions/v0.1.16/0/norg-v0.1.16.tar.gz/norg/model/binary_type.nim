
type
  Binaries* = object
    borg*: seq[string]
    restic*: seq[string]

proc newBinaries*(): Binaries = 
  var 
    borgs: seq[string] = @["borg","/usr/local/bin/borg","/usr/bin/borg","borg.exe"]
    restics: seq[string] = @["restic","/usr/local/bin/restic","/usr/bin/restic","restic.exe"]
  return Binaries(borg: borgs, restic: restics)
