import os

proc setEncryptionPassphrase*(pw: string) = 
  if pw != "":
    putEnv("BORG_PASSPHRASE", pw)
    putEnv("RESTIC_PASSWORD", pw)

proc setEncryptionPassphraseFD*(pw: string) = 
  if pw != "":
    putEnv("BORG_PASSPHRASE_FD", pw)

proc setEncryptionPassphraseFile*(pw: string) = 
  if pw != "":
    putEnv("RESTIC_PASSWORD_FILE", pw)

proc setEncryptionPassCommand*(pw: string) = 
  if pw != "":
    putEnv("BORG_PASSCOMMAND", pw)
    putEnv("RESTIC_PASSWORD_COMMAND", pw)

proc delEncryptionPassphraseInfo*() = 
  delEnv("BORG_PASSPHRASE")
  delEnv("BORG_PASSPHRASE_FD")
  delEnv("BORG_PASSCOMMAND")
  delEnv("RESTIC_PASSWORD")
  delEnv("RESTIC_PASSWORD_FILE")
  delEnv("RESTIC_PASSWORD_COMMAND")
