
type
  Maintenance* = object
    keep_hourly*: int
    keep_daily*: int
    keep_weekly*: int
    keep_monthly*: int
    keep_yearly*: int

proc newMaintenance*(): Maintenance = 
  var m = Maintenance()
  m.keep_hourly = 24
  m.keep_daily = 7
  m.keep_weekly = 4
  m.keep_monthly = 6
  m.keep_yearly = 1
  return m
