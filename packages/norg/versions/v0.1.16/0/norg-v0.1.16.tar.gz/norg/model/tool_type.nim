
type
  BackupTool* = enum
    BORG = "borg",
    RESTIC = "restic"
    
proc toBackupTool*(str: string): BackupTool = 
  for tool in BackupTool.items:
    if str == $tool: return tool
  return BORG
