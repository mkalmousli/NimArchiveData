
type
  State* = enum
    Unknown = "Unknown"
    Running = "Running"
    Success = "Success"
    Failure = "Failure"

proc toState*(str: string): State = 
  case str
  of "Running": return Running
  of "Success": return Success
  of "Failure": return Failure
  else: return Unknown
