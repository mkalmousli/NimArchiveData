import repository_type
import notifier_types
import actions_type
import maintenance_type
import binary_type
import args_type
import log_type
import exclusions_type

export repository_type
export notifier_types
export actions_type
export maintenance_type
export binary_type
export args_type
export log_type
export exclusions_type

import ../utils/version

const VERSION*: string = getVersion()

type 
  NorgConfig* = ref object
    retries*: int
    source_directories*: seq[string]
    repositories*: seq[Repository]
    maintenance*: Maintenance
    #checks*: Check - see borgmatic
    notifiers*: Notifiers
    actions*: Actions
    args*: NorgArgs
    exclusions*: Exclusions
    bins*: Binaries
    log_info*: LogInfo

proc newNorgConfig*(): NorgConfig = 
  var nc = NorgConfig()
  nc.maintenance = newMaintenance()
  nc.bins = newBinaries()
  nc.log_info = newLogInfo()
  return nc

var norg_config*: NorgConfig = newNorgConfig()

#proc `$`*(c: NorgConfig): string = 
#  var msg: string = "Source Dirs: " & $c.source_directories & "\r\n"
#  msg &= "Repositories: " & $c.repositories & "\r\n"
#  msg &= "Notifiers: " & $c.notifiers & "\r\n"
#  return msg




