import state_type

type 
  Notifier* = object of RootObj
    base_url*: string
    states*: seq[State]

proc defaultStates*(): seq[State] = 
  return @[Success, Failure, Running]

proc newNotifier*(): Notifier =
  return Notifier(states: defaultStates())

