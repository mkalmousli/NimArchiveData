import notifier_type
import ../notifier/uptimekuma_notifier

export notifier_type
export uptimekuma_notifier

type
  Notifiers* = object
    uptimekuma*: UptimeKuma

