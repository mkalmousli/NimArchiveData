#!/usr/bin/env sh

version=$(grep -i version norg.nimble | awk '{print $3}' | sed "s/\"//g" | sed "s/\./_/g")
dir=$(pwd)
echo Building for Linux
for cpu in amd64; do
  nimble build -d:linux --cpu:$cpu
  if [ $? != 1 ]; then
      echo "Compressing..."
      cd bin || exit
      tar cvzf "norg_linux_$cpu-$version.tar.gz" norg
      rm norg
      cd "$dir" || exit
      echo Done.
  fi
  
  echo Building for FreeBSD
  nimble build -d:freebsd --cpu:$cpu
  if [ $? != 1 ]; then
      echo "Compressing..."
      cd bin || exit
      tar cvzf "norg_freebsd_$cpu-$version.tar.gz" norg
      rm norg
      cd "$dir" || exit
      echo Done.
  fi
  
  echo Building for Windows
  nimble build -d:mingw --cpu:$cpu
  if [ $? != 1 ]; then
      echo "Zipping..."
      cd bin || exit
      cp ../resources/windows/lib* ./
      zip "norg_windows_$cpu-$version.zip" norg.exe lib*
      rm ./lib*
      cd "$dir" || exit
      rm bin/norg.exe
      echo Done.
  fi
done
