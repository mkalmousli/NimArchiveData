import ../model/state_type
import ../model/notifier_type
import ../model/log_type
import strformat

import ../utils/httprequest

type 
  UptimeKuma* = object of Notifier

proc send_notify*(uk: UptimeKuma, state: State, runtime: int = 0, msg: string = ""): int {.discardable.} =
  var status: string = "down"
  case state
  of Success, Running:
    status = "up"
  else:
    status = "down"
  var message = $state
  if msg != "":
    message &= fmt":{msg}"
  let url = fmt"{uk.base_url}?status={status}&msg={message}&ping={runtime}"

  debug "Sending notification to " & url
  let res = sendHttpRequest(HttpGet, url)
  if res.status == $Http200:
    return 0
  else:
    return 1

