import parsetoml

import ../model/config_type
import ../model/command_type
import ../model/encryption_type
import ../model/args_type
import notifier_config
import actions_config
import maintenance_config
export args_type

export config_type


proc parseSourceDirectories*(in_conf: TomlValueRef): seq[string] =
  var src_dirs: seq[string] = @[]
  for dir in in_conf{"source_directories"}.getElems():
    src_dirs.add(dir.getStr())
  # this is here for backwards compatibiliy
  for dir in in_conf{"source_dirs"}.getElems():
    norg_config.source_directories.add(dir.getStr())
  return src_dirs

proc parseRepositories*(rep_conf: TomlValueRef): seq[Repository] =
  var repos: seq[Repository] = @[]
  for r in rep_conf.getElems():
    let rtable = r.getTable()
    var repo = Repository()
    repo.path = rtable["path"].getStr()
    repo.label = rtable["label"].getStr()
    if rtable.hasKey("append_only"):
      repo.append_only = rtable["append_only"].getBool()
    if rtable.hasKey("tool"):
      repo.tool = rtable["tool"].getStr("borg").toBackupTool()
    repos.add(repo)
  return repos

proc parseEncryption*(enc_conf: TomlValueRef) =
  setEncryptionPassphrase(enc_conf{"encryption_passphrase"}.getStr(""))
  setEncryptionPassphraseFD(enc_conf{"encryption_passphrase_fd"}.getStr(""))
  setEncryptionPassphraseFile(enc_conf{"encryption_passphrase_file"}.getStr(""))
  setEncryptionPassCommand(enc_conf{"encryption_passcommand"}.getStr(""))

proc parseLogging(nc: var NorgConfig, log_conf: TomlValueRef) =
  let ll = log_conf{"log_level"}.getStr()
  if ll != "":
    nc.log_info.level = ll.toLogLevel()
  nc.log_info.file = log_conf{"log_file"}.getStr()
  discard

proc addConfigBinaries*(current: var Binaries, bin_conf: TomlValueRef) = 
  let 
    borg = bin_conf{"borg_bin"}.getStr()
    restic = bin_conf{"restic_bin"}.getStr()
  if borg != "":
    current.borg.insert(borg,0)
  if restic != "":
    current.restic.insert(restic,0)

proc parseConfigFile*(file: string): NorgConfig =
  let in_conf = parsetoml.parseFile(file)
  norg_config.source_directories = parseSourceDirectories(in_conf)
  norg_config.repositories = parseRepositories(in_conf{"repositories"})
  if norg_config.args.repository != "":
    echo "Filtering repo list to selected: ", norg_config.args.repository
    norg_config.repositories = norg_config.repositories.findRepository(norg_config.args.repository)
  parseEncryption(in_conf{"encryption"})
  norg_config.notifiers = parseNotifiers(in_conf)
  norg_config.actions = parseActions(in_conf{"actions"})
  norg_config.maintenance = parseMaintenance(in_conf{"maintenance"})
  norg_config.bins.addConfigBinaries(in_conf{"binaries"})
  norg_config.bins.setBinaryLocations()
  norg_config.parseLogging(in_conf{"logging"})
  return norg_config


