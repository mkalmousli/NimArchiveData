import strutils
import strformat

import ../model/command_type
import ../utils/run
export run


proc genCommand*(cmd: string, repo: string, further_args: seq[string]): string =
  let args = further_args.join(" ")
  let cmd = fmt"{BORG_BIN} {cmd} {repo} {args}"
  return cmd

proc genCreateCommand*(repo: string, sources: seq[string], stats: bool, further_args: seq[string]): string =
  let args = further_args.join(" ")
  var stats_flag = "--stats"
  if not stats: stats_flag = ""
  var source_dirs = ""
  for source in sources:
    source_dirs &= fmt""""{source}" """
  let cmd = fmt"{BORG_BIN} create {stats_flag} {repo} {source_dirs} {args}"
  return cmd

proc genDeleteCommand*(repo: string, archive: string, further_args: seq[string]): string =
  let args = further_args.join(" ")
  let cmd = fmt"{BORG_BIN} delete {repo} {archive} {args}"
  return cmd

