import ../model/binary_type
import os

type
  Command* = enum
    LIST = "list"
    INIT = "init",
    CREATE = "create",
    EXTRACT = "extract",
    MOUNT = "mount",
    UMOUNT = "umount",
    PRUNE = "prune",
    DELETE = "delete"
    CHECK = "check",
    COMPACT = "compact"

var BORG_BIN* = "borg"
var RESTIC_BIN* = "restic"

proc setBinaryLocations*(b: Binaries) =
  for borg in b.borg:
    #echo "Checking if '", borg, "' exists"
    if fileExists(borg): 
      #echo "Setting Borg binary to : ", borg
      BORG_BIN = borg
      break
  for restic in b.restic:
    #echo "Checking if '", restic, "' exists"
    if fileExists(restic): 
      #echo "Setting Restic binary to : ", restic
      RESTIC_BIN = restic
      break

proc toCommand*(str: string): Command = 
  for cmd in Command.items:
    if str == $cmd: return cmd
  case str
  of "backup": return CREATE
  of "snapshots","archives": return LIST
  of "restore": return EXTRACT
  of "forget": return DELETE


