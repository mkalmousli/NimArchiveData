import logging
#import threadlogging
import strutils

type
  LogInfo* = object
    level*: Level
    file*: string

var logger*: ConsoleLogger
proc initLogger*(level: Level = lvlInfo, strfmt: string = "[$levelname] ") =
  logger = newConsoleLogger(level, strfmt)
  logger.log(lvlNotice, "Log Level: ", $level)

#proc initLoggerThread*(level: Level = lvlInfo, strfmt: string = "[$levelname] ") =
#  initLogThread(strfmt, level)
#  threadlogging.notice("Log Level: ", $level)

proc newLogInfo*(): LogInfo =
  var log = LogInfo()
  log.level = lvlInfo
  log.file = ""
  return log

proc toLogLevel*(s: string): Level =
  for l in Level.items:
    if s == $l: return l
  case s
  of "debug": return lvlDebug
  of "info": return lvlInfo
  of "warn": return lvlWarn
  of "error": return lvlError
  of "fatal": return lvlFatal
  of "notice": return lvlNotice
  return lvlInfo

proc debug*(args: varargs[string,`$`]) = 
  logger.log(lvlDebug, args.join(" "))
proc fatal*(args: varargs[string,`$`]) = 
  logger.log(lvlfatal, args.join(" "))
proc warn*(args: varargs[string,`$`]) = 
  logger.log(lvlwarn, args.join(" "))
proc notice*(args: varargs[string,`$`]) = 
  logger.log(lvlnotice, args.join(" "))
proc info*(args: varargs[string,`$`]) = 
  logger.log(lvlinfo, args.join(" "))
proc error*(args: varargs[string,`$`]) = 
  logger.log(lvlerror, args.join(" "))
