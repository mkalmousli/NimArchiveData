import config/init
import config/args
import borg/borg
import restic/restic
import model/encryption_type
import utils/actions
import model/log_type
import os

proc showVersion() = 
  echo "Norg Version: ", VERSION
  quit(0)

proc startLogger(log_info: LogInfo) = 
  initLogger(log_info.level, "[$levelname] ")

proc start() =
  parseArgs()
  norg_config.args = norg_args
  if norg_args.show_version: 
    showVersion()
  elif norg_args.config_file != "":
    norg_config = parseConfigFile(norg_args.config_file)
    echo norg_config.log_info.level
    startLogger(norg_config.log_info)
    if norg_config.source_directories.len > 0 and norg_config.repositories.len > 0:
      run_actions(norg_config.actions.before_everything)
      for repo in norg_config.repositories:
        run_actions(norg_config.actions.before_actions)
        case repo.tool
        of BORG:
          borg.execute(norg_config, repo)
        of RESTIC:
          restic.execute(norg_config, repo)
        run_actions(norg_config.actions.after_actions)
      run_actions(norg_config.actions.after_everything)
      delEncryptionPassphraseInfo()
  else:
    echo "No Config File Provided"

when isMainModule:
  start()
  # sleep for a bit to let logs finish
  sleep 5
