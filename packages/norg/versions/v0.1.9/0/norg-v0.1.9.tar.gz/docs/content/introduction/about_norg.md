+++
title = "About Norg"
date = 2024-08-24T13:00:00
weight = 0
+++
`Norg` is a simple, portable, wrapper utility for the [BorgBackup](https://borgbackup.com) and [Restic](https://restic.net) backup utilities.  
This website serves as a point of reference for both documentation and 
assistance when using the `norg` backup utilitiy.  
Please use the menu or search function to find the information you require.

## Naming. Why "Norg"?
Norg is short for "Nice Borg" - a way to nicely handle borg based backups.  

Also, I'm a Star Trek fan so obviously I wanted to keep something in line with the 
[Borg pseudo-species](https://memory-alpha.fandom.com/wiki/Borg) as the borg backup utility does. Sometimes I feel my code has elements of inexperience but loads of potential... which reminded me of [Nog](https://memory-alpha.fandom.com/wiki/Nog).  
So, simply put, Norg could also be a portmanteau of "Borg" and "Nog".
