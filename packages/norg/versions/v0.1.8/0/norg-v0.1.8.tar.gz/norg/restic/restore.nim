import ../model/config_type
import execute
import strformat
import os

proc isEmpty(dir: string): bool =
  var count = 0
  for idx, f in walkDir(dir): return false
  #count += 1
  return count == 0

proc restoreSnapshot*(nc: NorgConfig, repo: Repository): int =
  let repo_snapshot = fmt"{repo.path} {nc.args.archive}"
  var further_args = nc.args.further_args
  if nc.args.extract_destination != "":
    discard existsOrCreateDir(nc.args.extract_destination)
    setCurrentDir(nc.args.extract_destination)
  let dir = getCurrentDir()
  if dir.isEmpty():
    echo "Restoring..."
    let ok = run genRestoreCommand(repo_snapshot = repo_snapshot, destination = nc.args.extract_destination, further_args = further_args)
    return ok
  else:
    echo "Not restoring to non-empty destination\r\nPlease use the --destination flag or cd to an empty directory."
