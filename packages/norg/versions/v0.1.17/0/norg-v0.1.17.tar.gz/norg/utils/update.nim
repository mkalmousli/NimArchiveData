##curl -X 'GET' 'https://codeberg.org/api/v1/repos/pswilde/norgbackup/releases/latest -H 'accept: application/json'
##
import httpclient
import json
import strformat
import strutils
import terminal
import osproc
import os

import ../model/log_type
import version

const SH = """
#!/usr/bin/env sh
mv {new} {old}
{old} --version
rm -r tmp
"""
const BAT = """
move {new} {old}
{old} --version
rmdir /s tmp
"""

proc extractUpdate(name, file: string) =
  var client = newHttpClient()
  try:
    createDir("tmp")
    client.downloadFile(file,fmt"tmp/{name}")
    let cwd = getAppDir()
    let cwf = getAppFilename()
    let ok = osproc.execCmd(fmt"tar xf tmp/{name} -C tmp/")
    copyFile(cwf,fmt"{cwd}/norg_backup")
    if ok == 0:
      case hostOS
      of "linux","freebsd":
        let content = SH.replace("{new}", "tmp/norg").replace("{old}", cwf)
        writeFile("tmp/norg_update", content)
        discard osproc.execCmd("sh tmp/norg_update")
        quit(0)
      of "windows":
        let content = BAT.replace("{new}", "tmp/norg").replace("{old}", cwf)
        writeFile("tmp/norg_update", content)
        discard osproc.execCmd("tmp/norg_update")
        quit(0)
  except:
    error getCurrentExceptionMsg()
  finally:
    removeDir("tmp")

proc updateNorg(version: string, j: JsonNode) = 
  let newvers = version[1..^1].replace(".","_")
  let ext = if hostOS == "windows": ".zip" else: ".tar.gz"
  let check_file = fmt"norg_{hostOS}_{hostCPU}-{newvers}{ext}"
  info fmt"Looking for file: {check_file}"
  var update_found = false
  for asset in j["assets"].getElems():
    let name = asset["name"].getStr()
    if checkfile == name:
      let file = asset["browser_download_url"].getStr()
      update_found = true
      extractUpdate(name,file)
  if not update_found:
    info "Unable to find update file for your OS and architecture."
    info "Please check https://codeberg.org/pswilde/norgbackup/releases/latest for more information"


proc checkUpdates*(cur_vers: string)=
  initLogger(strfmt = "[$levelname] ")
  let latest_url = "https://codeberg.org/api/v1/repos/pswilde/norgbackup/releases/latest"
  var client = newHttpClient()
  try:
    let res = client.get(latest_url)
    if res.code == Http200:
      let j = res.body.parseJson()
      let new_vers = j["tag_name"].getStr()
      if new_vers.newerThan(cur_vers):
        info "An update is available, would you like to update? (y/N)"
        let resp = getch()
        case resp
        of 'y', 'Y':
          new_vers.updateNorg(j)
        else:
          info "Not updating"
      else:
        info "No new Update available."
    else:
      debug res.code
      debug res.body
      error "Cannot access update URL."
  except:
    error getCurrentExceptionMsg()

