import ../model/state_type
import ../model/notifier_type
import ../model/log_type
import strformat

import ../utils/httprequest

type 
  Gatus* = object of Notifier
    token*: string

proc send_notify*(gatus: Gatus, state: State, runtime: int = 0, msg: string = ""): int {.discardable.} =
  var success: string = "false"
  case state
  of Success:
    success = "true"
  else:
    success = "false"
  var message = $state
  if msg != "":
    message &= fmt"{msg}"
  let url = fmt"{gatus.base_url}?success={success}&error={message}%20{runtime}"

  debug "Sending notification to " & url
  try:
    let headers = newHttpHeaders({"Authorization":"Bearer " & gatus.token})
    let res = sendHttpRequest(HttpPost, url, headers=headers)
    if res.status == $Http200:
      return 0
    else:
      return 1
  except:
    error(getCurrentExceptionMsg())

