import ../model/state_type
import ../model/notifier_types

proc notify*(notifiers: Notifiers, state: State, runtime: int = 0, msg: string = ""): int = 
  if notifiers.uptimekuma.base_url != "" and
     state in notifiers.uptimekuma.states:
       return notifiers.uptimekuma.send_notify(state, runtime, msg)
  if notifiers.gatus.base_url != "" and
     state in notifiers.gatus.states:
       return notifiers.gatus.send_notify(state, runtime, msg)
