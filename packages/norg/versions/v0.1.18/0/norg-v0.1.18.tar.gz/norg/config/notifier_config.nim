import parsetoml

import ../model/notifier_types
import ../model/state_type

proc parseUptimeKumaConf(conf: TomlValueRef): UptimeKuma =
  var uk = UptimeKuma()
  uk.base_url = conf{"base_url"}.getStr()
  uk.states = @[]
  for state in conf{"states"}.getElems():
    uk.states.add(state.getStr().toState())
  if uk.states.len == 0:
    uk.states = defaultStates()
  uk.major_version = conf{"major_version"}.getInt(2)
  return uk

proc parseGatusConf(conf: TomlValueRef): Gatus =
  var g = Gatus()
  g.base_url = conf{"base_url"}.getStr()
  g.states = @[]
  for state in conf{"states"}.getElems():
    g.states.add(state.getStr().toState())
  if g.states.len == 0:
    g.states = defaultStates()
  return g

proc parseNotifiers*(in_conf: TomlValueRef): Notifiers =
  var notifiers = Notifiers()
  if in_conf.hasKey("uptimekuma"):  
    let u = parseUptimeKumaConf(in_conf["uptimekuma"])
    notifiers.uptimekuma = u
  if in_conf.hasKey("gatus"):  
    let g = parseGatusConf(in_conf["gatus"])
    notifiers.gatus = g
  return notifiers
