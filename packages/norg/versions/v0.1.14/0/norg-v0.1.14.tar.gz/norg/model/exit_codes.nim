import tool_type

import std/enumutils

type
  EXIT_CODE* = enum
    BORG_SUCCESS = 0
    BORG_WARNING = 1
    BORG_ERROR = 2
    OTHER = 99

proc toExitCode*(i: int, tool: BackupTool): EXIT_CODE =
  for code in EXIT_CODE:
    if i == ord(code): return code 
  return OTHER
