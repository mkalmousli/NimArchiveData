#!/usr/bin/env sh

version=$(grep -i version norg.nimble | awk '{print $3}' | sed "s/\"//g" | sed "s/\./_/g")
dir=$(pwd)
echo Building for Linux
nimble build -d:linux
if [ $? != 1 ]; then
    echo "Compressing..."
    cd bin || exit
    tar cvzf "norg_linux_$version.tar.gz" norg
    rm norg
    cd "$dir" || exit
    echo Done.
fi

echo Building for FreeBSD
nimble build -d:freebsd
if [ $? != 1 ]; then
    echo "Compressing..."
    cd bin || exit
    tar cvzf "norg_freebsd_$version.tar.gz" norg
    rm norg
    cd "$dir" || exit
    echo Done.
fi

echo Building for Windows
nimble build -d:mingw
if [ $? != 1 ]; then
    echo "Zipping..."
    cd bin || exit
    cp ../resources/windows/lib* ./
    zip "norg_windows_$version.zip" norg.exe lib*
    rm ./lib*
    cd "$dir" || exit
    rm bin/norg.exe
    echo Done.
fi
