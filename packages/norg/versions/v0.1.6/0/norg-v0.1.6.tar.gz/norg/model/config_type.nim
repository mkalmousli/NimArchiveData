import repository_type
import notifier_types
import actions_type
import maintenance_type
import ../config/args

export repository_type
export notifier_types
export actions_type
export maintenance_type


type 
  NorgConfig* = ref object
    retries*: int
    source_directories*: seq[string]
    repositories*: seq[Repository]
    maintenance*: Maintenance
    #checks*: Check - see borgmatic
    notifiers*: Notifiers
    actions*: Actions
    args*: NorgArgs


proc newNorgConfig*(): NorgConfig = 
  var nc = NorgConfig()
  nc.maintenance = newMaintenance()
  return nc

var norg_config*: NorgConfig = newNorgConfig()

#proc `$`*(c: NorgConfig): string = 
#  var msg: string = "Source Dirs: " & $c.source_directories & "\r\n"
#  msg &= "Repositories: " & $c.repositories & "\r\n"
#  msg &= "Notifiers: " & $c.notifiers & "\r\n"
#  return msg




