const BORG_BIN* = "borg"
const RESTIC_BIN* = "restic"

type
  Command* = enum
    LIST = "list"
    INIT = "init",
    CREATE = "create",
    EXTRACT = "extract",
    MOUNT = "mount",
    UMOUNT = "umount",
    PRUNE = "prune",
    DELETE = "delete"
    CHECK = "check",
    COMPACT = "compact"

proc toCommand*(str: string): Command = 
  for cmd in Command.items:
    if str == $cmd: return cmd
  case str
  of "backup": return CREATE
  of "snapshots","archives": return LIST
  of "restore": return EXTRACT
  of "forget": return DELETE


