import parsetoml

import ../model/config_type
import ../model/encryption_type
import notifier_config
import actions_config
import maintenance_config
export config_type

proc parseSourceDirectories*(in_conf: TomlValueRef): seq[string] =
  var src_dirs: seq[string] = @[]
  for dir in in_conf{"source_directories"}.getElems():
    src_dirs.add(dir.getStr())
  # this is here for backwards compatibiliy
  for dir in in_conf{"source_dirs"}.getElems():
    norg_config.source_directories.add(dir.getStr())
  return src_dirs

proc parseRepositories*(rep_conf: TomlValueRef): seq[Repository] =
  var repos: seq[Repository] = @[]
  for r in rep_conf.getElems():
    let rtable = r.getTable()
    var repo = Repository()
    repo.path = rtable["path"].getStr()
    repo.label = rtable["label"].getStr()
    if rtable.hasKey("tool"):
      repo.tool = rtable["tool"].getStr("borg").toBackupTool()
    repos.add(repo)
  return repos

proc parseEncryption*(enc_conf: TomlValueRef) =
  setEncryptionPassphrase(enc_conf{"encryption_passphrase"}.getStr(""))
  setEncryptionPassphraseFD(enc_conf{"encryption_passphrase_fd"}.getStr(""))
  setEncryptionPassphraseFile(enc_conf{"encryption_passphrase_file"}.getStr(""))
  setEncryptionPassCommand(enc_conf{"encryption_passcommand"}.getStr(""))

proc parseConfigFile*(file: string): NorgConfig =
  let in_conf = parsetoml.parseFile(file)
  norg_config.source_directories = parseSourceDirectories(in_conf)
  norg_config.repositories = parseRepositories(in_conf{"repositories"})
  if norg_config.args.repository != "":
    echo "Filtering repo list to selected: ", norg_config.args.repository
    norg_config.repositories = norg_config.repositories.findRepository(norg_config.args.repository)
  parseEncryption(in_conf{"encryption"})
  norg_config.notifiers = parseNotifiers(in_conf)
  norg_config.actions = parseActions(in_conf{"actions"})
  norg_config.maintenance = parseMaintenance(in_conf{"maintenance"})
  return norg_config


