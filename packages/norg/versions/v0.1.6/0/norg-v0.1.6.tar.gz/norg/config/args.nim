import argparse
import ../model/command_type

type 
  NorgArgs* = object
    config_file*: string
    extract_destination*: string
    command*: Command
    repository*: string
    archive*: string
    further_args*: seq[string]

var norg_args*: NorgArgs = NorgArgs()

proc parseArgs*() =
  var p = newParser:
    help("Norg\r\nA portable borg backup wrapper utility")
    option("-c", "--config", help="Config file to use.", required = true)
    option("-d", "--destination", help="Destination when extracting backup", required = false)
    option("-r", "--repository", help="Define an explicit repository to work on by either label or path.", required = false)
    option("-a", "--archive", help="The archive or snapshot to operate on", required = false)
    arg("command", help="The command to run, defaults to 'create' which will perform a backup.", default=some("create"))
    arg("further_args", nargs = -1, help="Any further arguments to send onto borg or restic.")
  try:
    var opts = p.parse(commandLineParams())
    norg_args.config_file = opts.config
    norg_args.extract_destination = opts.destination
    norg_args.command = opts.command.toCommand()
    norg_args.repository = opts.repository
    norg_args.archive = opts.archive
    norg_args.further_args = opts.further_args
  except ShortCircuit as err:
    if err.flag == "argparse_help":
      echo err.help
      quit(1)
  except UsageError:
    echo p.help
    stderr.writeLine getCurrentExceptionMsg()
    quit(1)
