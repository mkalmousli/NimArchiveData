# A list of things I'd like to include in Norg
- [ ] Backup maintenance i.e. Keep Daily/Weekly/Monthy
- [x] Add Restic implementation
- [x] Pre and post run scripts i.e. to backup a database
- [x] change encryption_password to encryption_passphrase in config to be more in line with borgbackup
- [ ] More notifiers (ntfy, healthchecks, etc.)
- [ ] Generate config command parameter
- [x] Allow to specify direct repository so mount/extract doesn't fail if multiple are available
- [ ] Better workflow of using borg flags and options as it seems a little sketchy just passing them through to the command string
- [ ] ... and loads more
