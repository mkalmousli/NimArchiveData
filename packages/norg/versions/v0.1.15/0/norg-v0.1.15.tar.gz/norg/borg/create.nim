import ../model/config_type
import ../model/state_type
import ../notifier/notifier
import ../model/log_type

import exit_codes
import execute
import prune

import os
import times
import strformat
import nativesockets

proc genArchiveName(): string = 
  let hostname = getHostname()
  let ts = getTime().format("yyyy-MM-dd'T'HH:mm:ss'.'ffffff")
  return fmt"{hostname}-{ts}"

proc createArchive(nc: NorgConfig, repo: Repository, archivename: string, retry: int = 0): (EXIT_CODE,string) = 
  let further_args = nc.args.further_args
  let res = run genCreateCommand(repo = archivename, sources = nc.source_directories, stats=nc.args.stats, exc=nc.exclusions, further_args = further_args)
  if res != 0:
    info "Failed to run Borg. Waiting 15 seconds and trying again"
    sleep 15 * 1000 # 15 seconds
    if retry == nc.retries:
      return (BORG_ERROR, "Max Retries Reached")
    else:
      return createArchive(nc, repo, archivename, retry + 1)
  return (res.toExitCode(),"Success")

proc createBackup*(nc: NorgConfig, repo: Repository): EXIT_CODE =
  let start_time = now()
  discard notify(nc.notifiers, state=Running)
  let archivename = repo.path & "::" & genArchiveName()
  debug "Creating Archive: ", archivename
  let (res,msg) = createArchive(nc, repo, archivename)
  let end_time = now()
  let total = (end_time - start_time).inMilliSeconds()
  case res
  of BORG_SUCCESS:
    if not repo.append_only:
      discard pruneRepo(nc, repo)
    discard notify(nc.notifiers, state=Success, runtime=total, msg=msg)
  of BORG_WARNING:
    discard notify(nc.notifiers, state=Success, runtime=total, msg="Warning")
  of BORG_ERROR:
    discard notify(nc.notifiers, state=Failure, runtime=total, msg=msg)
  else:
    discard notify(nc.notifiers, state=Failure, runtime=total, msg = $res)
  return res
