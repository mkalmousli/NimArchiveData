+++
title = "Download Norg"
weight = 0
+++

## Installing from nimble.directory
The latest version of Norg is most simply downloaded and installed using Nim's `nimble` command line tool. 
```sh
nimble install norg
```

## Installing direct from the Norg code repository
You can also install, via nimble, direct from the code repository.
```sh
nimble install https://codeberg.org/pswilde/norgbackup
```

## Building from Source
Norg source code can be downloaded from our [releases page at Codeberg](https://codeberg.org/pswilde/norgbackup/releases) and can be built using the following commands:
```sh
unzip norgbackup-{version}.zip
# or
tar xf norgbackup-{version}.tar.gz

cd norgbackup
nimble install
```

## Pre-compiled Binaries
We are working on providing pre-compiled binaries on our [releases page at Codeberg](https://codeberg.org/pswilde/norgbackup/releases). Currently these are not available, so using the options above are the best option.
