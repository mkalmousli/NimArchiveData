import parsecfg
import streams

proc getVersion*(): string = 
  let nimble = staticRead("../../norg.nimble")
  var p: Config = loadConfig(newStringStream(nimble))
  let vers = p.getSectionValue("","version")
  echo "Compiling version: v", vers
  return "v" & vers

