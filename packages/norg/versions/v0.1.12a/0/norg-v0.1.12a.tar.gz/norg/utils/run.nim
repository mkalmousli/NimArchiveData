import strformat
import osproc
import ../model/log_type

proc run*(cmd: string): int =
  debug fmt"Trying to run : {cmd}"
  try:
    let (output,exitcode) = execCmdEx(cmd)
    debug("Run Command Exist Code: " & $exitcode)
    info(output)
    return exitcode
  except:
    error getCurrentExceptionMsg()
  return 1

proc runDiscard*(cmd: string): int = 
  debug fmt"Trying to run : {cmd}"
  try:
    let (output,exitcode) = execCmdEx(cmd)
    debug("Run Command Exist Code: " & $exitcode)
    info(output)
    return exitcode
  except:
    error getCurrentExceptionMsg()
  return 1

