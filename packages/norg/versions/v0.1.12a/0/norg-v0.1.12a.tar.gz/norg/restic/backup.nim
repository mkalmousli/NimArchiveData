import ../model/config_type
import ../model/state_type
import ../notifier/notifier
import execute
import prune

import nativesockets
import times
import os

proc createArchive(nc: NorgConfig, repo: Repository, retry: int = 0): int = 
  let further_args = nc.args.further_args
  let res = run genBackupCommand(repo = repo.path, sources = nc.source_directories, exc= nc.exclusions, further_args = further_args)
  if res != 0:
    sleep 15 * 1000 # 15 seconds
    if retry == nc.retries:
      return 1
    else:
      return createArchive(nc, repo, retry + 1)
  return res

proc createBackup*(nc: NorgConfig, repo: Repository): int =
  let start_time = now()
  discard notify(nc.notifiers, state=Running)
  let res = createArchive(nc, repo)
  let end_time = now()
  let total = (end_time - start_time).inMilliSeconds()
  case res
  of 0:
    if not repo.append_only:
      discard pruneRepo(nc, repo)
    discard notify(nc.notifiers, state=Success, runtime=total)
  of 1:
    discard notify(nc.notifiers, state=Failure, runtime=total)
  else:
    discard notify(nc.notifiers, state=Failure, runtime=total, msg = $res)
  return res
