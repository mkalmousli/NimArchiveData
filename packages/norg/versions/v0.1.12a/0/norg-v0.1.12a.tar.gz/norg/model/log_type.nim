import logging
#import threadlogging
import strutils

type
  LogInfo* = object
    level*: Level
    file*: string

var logger*: ConsoleLogger
var filelogger*: FileLogger

proc initLogger*(level: Level = lvlInfo, strfmt: string = "[$levelname] ", log_file: string = "") =
  logger = newConsoleLogger(level, strfmt)
  logger.log(lvlNotice, "Log Level: ", $level)
  if log_file != "":
    let str = "$time " & strfmt
    filelogger = newFileLogger(log_file, levelThreshold=level, fmtStr=str)
    filelogger.log(lvlNotice, "Log Level: ", $level)


proc newLogInfo*(): LogInfo =
  var log = LogInfo()
  log.level = lvlInfo
  log.file = ""
  return log

proc toLogLevel*(s: string): Level =
  for l in Level.items:
    if s == $l: return l
  case s
  of "debug": return lvlDebug
  of "info": return lvlInfo
  of "warn": return lvlWarn
  of "error": return lvlError
  of "fatal": return lvlFatal
  of "notice": return lvlNotice
  return lvlInfo

proc debug*(args: varargs[string,`$`]) = 
  logger.log(lvlDebug, args.join(" "))
  if filelogger != nil:
    filelogger.log(lvlDebug, args.join(" "))

proc fatal*(args: varargs[string,`$`]) = 
  logger.log(lvlFatal, args.join(" "))
  if filelogger != nil:
    filelogger.log(lvlFatal, args.join(" "))

proc warn*(args: varargs[string,`$`]) = 
  logger.log(lvlwarn, args.join(" "))
  if filelogger != nil:
    filelogger.log(lvlWarn, args.join(" "))

proc notice*(args: varargs[string,`$`]) = 
  logger.log(lvlnotice, args.join(" "))
  if filelogger != nil:
    filelogger.log(lvlNotice, args.join(" "))

proc info*(args: varargs[string,`$`]) = 
  logger.log(lvlinfo, args.join(" "))
  if filelogger != nil:
    filelogger.log(lvlInfo, args.join(" "))

proc error*(args: varargs[string,`$`]) = 
  logger.log(lvlerror, args.join(" "))
  if filelogger != nil:
    filelogger.log(lvlError, args.join(" "))
