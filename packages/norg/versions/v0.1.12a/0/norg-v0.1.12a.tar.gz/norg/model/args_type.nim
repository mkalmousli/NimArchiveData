import command_type
export command_type

type 
  NorgArgs* = object
    show_version*: bool
    config_file*: string
    extract_destination*: string
    command*: Command
    repository*: string
    archive*: string
    stats*: bool
    further_args*: seq[string]


proc newNorgArgs*(): NorgArgs =
  var args = NorgArgs()
  return args

