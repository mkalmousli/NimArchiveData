import strutils
import strformat

import ../model/command_type
import ../model/exclusions_type
import ../model/log_type
import ../utils/run
export run


proc genCommand*(cmd: string, repo: string, further_args: seq[string]): string =
  let args = further_args.join(" ")
  let cmd = fmt"{BORG_BIN} {cmd} {repo} {args}"
  debug("Borg Command: " & cmd)
  return cmd

proc genCreateCommand*(repo: string, sources: seq[string], stats: bool, exc: Exclusions, further_args: seq[string]): string =
  let args = further_args.join(" ")
  var stats_flag = "--stats"
  if not stats: stats_flag = ""
  var source_dirs = ""
  for source in sources:
    source_dirs &= fmt""""{source}" """
  var cmd = fmt"{BORG_BIN} create {stats_flag} {repo} {source_dirs}"
  if exc.exclude_file != "":
    cmd = fmt"{cmd} --exclude-from {exc.exclude_file}"
  if exc.patterns_file != "":
    cmd = fmt"{cmd} --pattern-from {exc.patterns_file}"
  for exclude in exc.excludes:
    cmd = fmt"{cmd} --exclude {exclude}"
  for pattern in exc.patterns:
    cmd = fmt"{cmd} --pattern {pattern}"
  cmd = fmt"{cmd} {args}"
  debug("Borg Command: " & cmd)
  return cmd

proc genDeleteCommand*(repo: string, archive: string, further_args: seq[string]): string =
  let args = further_args.join(" ")
  let cmd = fmt"{BORG_BIN} delete {repo} {archive} {args}"
  debug("Borg Command: " & cmd)
  return cmd

