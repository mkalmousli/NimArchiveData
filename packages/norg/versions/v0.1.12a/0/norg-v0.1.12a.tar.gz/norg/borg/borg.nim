import ../model/config_type
import ../model/command_type
import ../utils/actions
import ../model/log_type

import execute
import prune
import create
import mount
import extract



proc initRepo(nc: NorgConfig, repo: Repository): int = 
  return runDiscard genCommand(cmd = "init", repo = repo.path, further_args = nc.args.further_args)

proc listArchives(nc: NorgConfig, repo: Repository): int =
  return run genCommand(cmd = "list", repo = repo.path, further_args = nc.args.further_args)

proc compactRepo(nc: NorgConfig, repo: Repository): int = 
  error "Not Yet Implemented."
  discard

proc checkRepo(nc: NorgConfig, repo: Repository): int = 
  error "Not Yet Implemented."
  discard

proc execute*(nc: NorgConfig, repo: Repository): int {.discardable.} =
  case nc.args.command
  of INIT:
    info "Initializing repo: ", repo.label
    discard initRepo(nc, repo)
  of CREATE:
    run_actions(norg_config.actions.before_backup)
    info "Creating archive on ", repo.label
    discard createBackup(nc, repo)
    run_actions(norg_config.actions.after_backup)
  of LIST:
    info "Listing Archives on ", repo.label
    discard listArchives(nc, repo)
  of MOUNT:
    info "Mounting Archive from ", repo.label
    discard mountArchive(nc, repo)
  of UMOUNT:
    discard unmountArchive(nc)
  of EXTRACT:
    run_actions(norg_config.actions.before_extract)
    info "Extracting archive from ", repo.label
    discard extractArchive(nc, repo)
    run_actions(norg_config.actions.after_extract)
  of PRUNE:
    run_actions(norg_config.actions.before_prune)
    info "Pruning repo: ", repo.label
    discard pruneRepo(nc, repo)
    run_actions(norg_config.actions.after_prune)
  of DELETE:
    info "Deleting Archive ", nc.args.archive
    discard deleteArchive(nc, repo)
  of COMPACT:
    run_actions(norg_config.actions.before_compact)
    discard compactRepo(nc, repo)
    run_actions(norg_config.actions.after_compact)
  of CHECK:
    run_actions(norg_config.actions.before_check)
    discard checkRepo(nc, repo)
    run_actions(norg_config.actions.after_check)
  else:
    discard
