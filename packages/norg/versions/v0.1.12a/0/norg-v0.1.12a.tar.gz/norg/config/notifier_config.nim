import parsetoml

import ../model/notifier_types
import ../model/state_type

proc parseUptimeKumaConf(conf: TomlValueRef): UptimeKuma =
  var uk = UptimeKuma()
  uk.base_url = conf{"base_url"}.getStr()
  uk.states = @[]
  for state in conf{"states"}.getElems():
    uk.states.add(state.getStr().toState())
  if uk.states.len == 0:
    uk.states = defaultStates()
  return uk

proc parseNotifiers*(in_conf: TomlValueRef): Notifiers =
  var notifiers = Notifiers()
  if in_conf.hasKey("uptimekuma"):  
    let u = parseUptimeKumaConf(in_conf["uptimekuma"])
    notifiers.uptimekuma = u
  return notifiers
