+++
title = "Example Configuration"
weight = 10
+++
Below is an example configuration in [`toml`](https://toml.io) format which can be used as a base for setting up a new norg backup.  
```toml
# Defines what folders you would like to back up
source_directories = [
  "/home/me",
  "/opt/other_things"
]

# Defines your backup repository/repositories
[[repositories]]
label = "LocalBorgBackup"
path = "/path/to/backup"
# You can define to backup tool here, default is "borg"
tool = "borg"

# You can add more repositories of varying types.
# When defining multiple repositories, a new backup will run for each repository 
# defined.
[[repositories]]
label = "RemoteBorgBase"
path = "ssh://1234abcd@1234abcd.repo.borgbase.com/./repo"
tool = "borg"

[[repositories]]
label = "LocalResticBackup
path = "/path/to/another/backup"
# You can define restic as a backup tool
tool = "restic"

# Defines encryption information i.e. backup encryption passphrase
# If a passphrase is not set or is incorrect, borg/restic will prompt you for one 
# which is likely to cause your backups to not run.
[encryption]
# Set a string variable for the passphrase
encryption_passphrase = "MyVeryS3curePassphrase!"

# Get the passphrase from the result of a command
# encryption_passcommand = "cat my_passphrase.txt"

# These actions can be configured to run scripts (i.e. back up a database) 
# at various times throughout the running process
[actions]
# "everything" means before or after every possible option for all repositories
before_everything = ["echo before everything"]
after_everything = ["echo after everything"]
# "actions" means before any action, per repository
before_actions = ["echo before actions"]
after_actions = ["echo after actions"]
# before or after the backup process per repository
before_backup = ["echo before backup"]
after_backup = ["echo after backup"]
# before or after the extract process per repository
before_extract = ["echo before extract"]
after_extract = ["echo after extract"]
# before or after the prune process per repository
before_prune = ["echo before prune"]
after_prune = ["echo after prune"]
# before or after the compact process per respository
before_compact = ["echo before compact"]
after_compact = ["echo after compact"]
# before or after the check processs per repository
before_check = ["echo before check"]
after_check = ["echo after check"]

# Send a status update to Uptime Kuma
# more status monitor tools are planned to be supported in the future
[uptimekuma]
# The base/push url of your Uptime Kuma monitor - without the query string.
# The query string will be generated at run time and will change dependant on the state of your backup.
base_url = "https://uptime.kuma.url/api/push/1234abcd"

# what backup states you wish to send an alert for, defaults to Success, Failure and Running
states = ["Success","Failure", "Running"]

# Set locations of the borg or restic binaries if you need to.
# Norg will check some common locations and use the first one it finds, but 
# if you have them installed in a non-standard location, set that location here
[binaries]
borg_bin = "/usr/local/bin/borg"
restic_bin = "/usr/local/bin/restic"
```
