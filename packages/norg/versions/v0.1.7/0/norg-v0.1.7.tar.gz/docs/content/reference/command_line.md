+++
title = "Command Line Reference"
weight = 20
+++
Here are the available norg command line parameters for the most recent version. 
If you are using an older version of norg some of these parameters may not work.
Please use `norg --help` to view all available parameters in your version.
```help
Norg
A portable borg backup wrapper utility

Usage:
   [options] [command] [further_args ...]

Arguments:
  [command]        The command to run, defaults to 'create' which will perform a backup. (default: create)
  [further_args ...]
                   Any further arguments to send onto borg or restic.

Options:
  -h, --help
  -c, --config=CONFIG        Config file to use.
  -d, --destination=DESTINATION
                             Destination when extracting backup
  -r, --repository=REPOSITORY
                             Define an explicit repository to work on by either label or path.
  -a, --archive=ARCHIVE      The archive or snapshot to operate on
  -s, --stats                Provides statistics at the end of a backup (Borg only)
```

The `-c`, or `--config`, parameter is required. Failing to provide this will only show the above help information.  

When specifying the `-r` or `--repository` parameter, you can specify either 
the `label` or `path` for the repository defined in the configuration file.

