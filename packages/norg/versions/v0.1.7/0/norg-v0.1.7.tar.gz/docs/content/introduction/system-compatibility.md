+++
title = "System Compatibility"
weight = 90
+++
Norg should run on any platform able to compile `nim` code using `nimble`.  
It has been tested on the following operating systems:
- FreeBSD
- Arch Linux
- AlmaLinux
- Rocky Linux
- Debian

Ultimately, any system that can compile the code and has the `borg` or `restic` 
binary files in the running user's `$PATH` environment variable should be able 
to run `norg` without issue.

## Windows Support
Running `norg` on Windows is feasibly possible (for Restic repositories, 
Borg is not supported on Windows), and is planned for a future release. 
`Norg` uses fairly pure nim code, which should be transferrable between 
Operating Systems. The only thing lacking for Windows is a reference to the 
correct path for running Restic. This should be an easy fix, and will work in a
future release.

