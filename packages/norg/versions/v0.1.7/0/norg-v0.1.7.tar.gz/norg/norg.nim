import config/init
import config/args
import borg/borg
import restic/restic
import model/encryption_type
import utils/actions

proc start() =
  parseArgs()
  norg_config.args = norg_args
  norg_config = parseConfigFile(norg_args.config_file)
  if norg_config.source_directories.len > 0 and norg_config.repositories.len > 0:
    run_actions(norg_config.actions.before_everything)
    for repo in norg_config.repositories:
      run_actions(norg_config.actions.before_actions)
      case repo.tool
      of BORG:
        borg.execute(norg_config, repo)
      of RESTIC:
        restic.execute(norg_config, repo)
      run_actions(norg_config.actions.after_actions)
    run_actions(norg_config.actions.after_everything)
  delEncryptionPassphraseInfo()

when isMainModule:
  start()
