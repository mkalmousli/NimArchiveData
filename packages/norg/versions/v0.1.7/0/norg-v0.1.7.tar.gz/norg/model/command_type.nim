import ../model/binary_type
import os

type
  Command* = enum
    LIST = "list"
    INIT = "init",
    CREATE = "create",
    EXTRACT = "extract",
    MOUNT = "mount",
    UMOUNT = "umount",
    PRUNE = "prune",
    DELETE = "delete"
    CHECK = "check",
    COMPACT = "compact"

var BORG_BIN* = "borg"
var RESTIC_BIN* = "restic"

proc setBinaryLocations*(b: Binaries) =
  for borg in b.borg:
    if fileExists(borg): BORG_BIN = borg
  for restic in b.restic:
    if fileExists(restic): RESTIC_BIN = restic
proc toCommand*(str: string): Command = 
  for cmd in Command.items:
    if str == $cmd: return cmd
  case str
  of "backup": return CREATE
  of "snapshots","archives": return LIST
  of "restore": return EXTRACT
  of "forget": return DELETE


