import ../model/config_type
import ../utils/actions

import init
import backup
import list
import mount
import restore
import prune

proc execute*(nc: NorgConfig, repo: Repository) =
  case nc.args.command
  of INIT:
    echo "Initializing repo: ", repo.label
    discard initRepo(nc, repo)
  of CREATE:
    run_actions(norg_config.actions.before_backup)
    echo "Backing up to ", repo.label
    discard createBackup(nc, repo)
    run_actions(norg_config.actions.after_backup)
  of LIST:
    echo "Listing Snapshots at ", repo.label
    discard listSnapshots(nc, repo)
  of MOUNT:
    echo "Mounting Snapshot from ", repo.label
    discard mountSnapshot(nc, repo)
  of EXTRACT:
    run_actions(norg_config.actions.before_extract)
    echo "Restoring snapshot from ", repo.label
    discard restoreSnapshot(nc, repo)
    run_actions(norg_config.actions.after_extract)
  of PRUNE:
    run_actions(norg_config.actions.before_prune)
    echo "Pruning repo: ", repo.label
    discard pruneRepo(nc, repo)
    run_actions(norg_config.actions.after_prune)
  of DELETE:
    echo "Forgetting snapshot: ", nc.args.archive
    discard forgetSnapshot(nc, repo)
  else:
    discard
