import strutils
import strformat

import ../model/command_type
import ../utils/run
export run

proc genCommand*(cmd: string, repo: string, further_args: seq[string]): string =
  let args = further_args.join(" ")
  let cmd = fmt"{RESTIC_BIN} {cmd} -r {repo} {args}"
  return cmd

proc genRestoreCommand*(cmd: string, repo_snapshot: string, destination: string, further_args: seq[string]): string =
  let args = further_args.join(" ")
  let cmd = fmt"{RESTIC_BIN} {cmd} -r {repo_snapshot} --target {destination} {args}"
  return cmd

proc genForgetCommand*(cmd: string, repo: string, archive: string, further_args: seq[string]): string =
  let args = further_args.join(" ")
  let cmd = fmt"{RESTIC_BIN} {cmd} -r {repo} {archive} {args}"
  return cmd
