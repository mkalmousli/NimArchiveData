import ../model/config_type

import strformat

import execute

proc addPruneOptions(cmd: var string, maintenance: Maintenance) = 
  cmd = fmt"""{cmd} \
              --keep-hourly {maintenance.keep_hourly} \
              --keep-daily {maintenance.keep_daily} \
              --keep-weekly {maintenance.keep_weekly} \
              --keep-monthly {maintenance.keep_monthly} \
              --keep-yearly {maintenance.keep_yearly} \
              """
  
proc pruneRepo*(nc: NorgConfig, repo: Repository): int = 
  var cmd = genCommand(cmd = "forget --prune", repo = repo.path, further_args = nc.args.further_args)
  cmd.addPruneOptions(nc.maintenance)
  return run cmd

proc forgetSnapshot*(nc: NorgConfig, repo: Repository): int = 
  var cmd = genForgetCommand(cmd = "forget", repo = repo.path, archive = nc.args.archive, further_args = nc.args.further_args)
  return run cmd
