import ../model/config_type

import execute
  
proc pruneRepo*(nc: NorgConfig, repo: Repository): int = 
  var cmd = genCommand(cmd = "prune", repo = repo.path, further_args = nc.args.further_args)
  cmd.addPruneOptions(nc.maintenance)
  return run cmd

proc deleteArchive*(nc: NorgConfig, repo: Repository): int = 
  var cmd = genDeleteCommand(cmd = "delete", repo = repo.path, archive = nc.args.archive, further_args = nc.args.further_args)
  return run cmd
