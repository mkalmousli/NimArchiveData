import strutils
import strformat

import ../model/command_type
import ../utils/run
export run


proc genCommand*(cmd: string, repo: string, further_args: seq[string]): string =
  let args = further_args.join(" ")
  let cmd = fmt"{BORG_BIN} {cmd} {repo} {args}"
  return cmd

proc genCreateCommand*(cmd: string, repo: string, stats: bool, further_args: seq[string]): string =
  let args = further_args.join(" ")
  var stats_flag = "--stats"
  if not stats: stats_flag = ""
  let cmd = fmt"{BORG_BIN} {cmd} {stats_flag} {repo} {args}"
  return cmd

proc genDeleteCommand*(cmd: string, repo: string, archive: string, further_args: seq[string]): string =
  let args = further_args.join(" ")
  let cmd = fmt"{BORG_BIN} {cmd} {repo} {archive} {args}"
  return cmd

