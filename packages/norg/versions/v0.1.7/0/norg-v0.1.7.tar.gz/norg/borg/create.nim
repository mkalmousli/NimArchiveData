import ../model/config_type
import ../model/state_type
import ../notifier/notifier

import execute
import prune

import os
import times
import sequtils
import strformat
import nativesockets

proc genArchiveName(): string = 
  let hostname = getHostname()
  let ts = getTime().format("yyyy-MM-dd'T'HH:mm:ss'.'ffffff")
  return fmt"{hostname}-{ts}"

proc createArchive(nc: NorgConfig, repo: Repository, archivename: string, retry: int = 0): int = 
  let further_args = concat(nc.source_directories, nc.args.further_args)
  let res = run genCreateCommand(cmd = "create", repo = archivename, stats=nc.args.stats, further_args = further_args)
  if res != 0:
    sleep 15 * 1000 # 15 seconds
    if retry == nc.retries:
      return 1
    else:
      return createArchive(nc, repo, archivename, retry + 1)
  return res

proc createBackup*(nc: NorgConfig, repo: Repository): int =
  let start_time = now()
  notify(nc.notifiers, state=Running)
  let archivename = repo.path & "::" & genArchiveName()
  let res = createArchive(nc, repo, archivename)
  let end_time = now()
  let total = (end_time - start_time).inMilliSeconds()
  case res
  of 0:
    discard pruneRepo(nc, repo)
    notify(nc.notifiers, state=Success, runtime=total)
  of 1:
    notify(nc.notifiers, state=Failure, runtime=total)
  else:
    notify(nc.notifiers, state=Failure, runtime=total, msg = $res)
  return res
