import strformat
import osproc

import ../model/maintenance_type

proc run*(cmd: string): int =
  echo fmt"Trying to run : {cmd}"
  try:
    let res = execCmd(cmd)
    return res
  except:
    echo getCurrentExceptionMsg()
  return 1

proc runDiscard*(cmd: string): int = 
  echo fmt"Trying to run : {cmd}"
  try:
    let res = execCmd(cmd)
    return res
  except:
    echo getCurrentExceptionMsg()
  return 1

proc addPruneOptions*(cmd: var string, maintenance: Maintenance) = 
  cmd = fmt"""{cmd} \
              --keep-hourly {maintenance.keep_hourly} \
              --keep-daily {maintenance.keep_daily} \
              --keep-weekly {maintenance.keep_weekly} \
              --keep-monthly {maintenance.keep_monthly} \
              --keep-yearly {maintenance.keep_yearly} \
              """
