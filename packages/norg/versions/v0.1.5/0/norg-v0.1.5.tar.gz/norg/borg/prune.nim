import ../model/config_type

import strformat

import execute

proc addPruneOptions(cmd: var string, maintenance: Maintenance) = 
  cmd = fmt"""{cmd} \
              --keep-hourly {maintenance.keep_hourly} \
              --keep-daily {maintenance.keep_daily} \
              --keep-weekly {maintenance.keep_weekly} \
              --keep-monthly {maintenance.keep_monthly} \
              --keep-yearly {maintenance.keep_yearly} \
              """
  
proc pruneRepo*(nc: NorgConfig, repo: Repository): int = 
  var cmd = genCommand(cmd = "prune", repo = repo.path, others = nc.args.others)
  cmd.addPruneOptions(nc.maintenance)
  return run cmd
