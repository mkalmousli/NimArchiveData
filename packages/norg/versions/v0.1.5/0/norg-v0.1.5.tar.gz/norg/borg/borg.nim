import ../model/config_type
import ../model/encryption_type
import ../model/borg_type
import ../utils/actions

import execute
import prune
import create
import mount
import extract


proc initRepo(nc: NorgConfig, repo: Repository): int = 
  return runDiscard genCommand(cmd = "init", repo = repo.path, others = nc.args.others)

proc listArchives(nc: NorgConfig, repo: Repository): int =
  return run genCommand(cmd = "list", repo = repo.path, others = nc.args.others)

proc compactRepo(nc: NorgConfig, repo: Repository): int = 
  echo "Not Yet Implemented."
  discard

proc checkRepo(nc: NorgConfig, repo: Repository): int = 
  echo "Not Yet Implemented."
  discard

proc execute*(nc: NorgConfig) =
  run_actions(norg_config.actions.before_everything)
  for repo in nc.repositories:
    run_actions(norg_config.actions.before_actions)
    case nc.args.borg_cmd
    of INIT:
      discard initRepo(nc, repo)
    of CREATE:
      run_actions(norg_config.actions.before_backup)
      discard createBackup(nc, repo)
      run_actions(norg_config.actions.after_backup)
    of LIST:
      discard listArchives(nc, repo)
    of MOUNT:
      discard mountArchive(nc, repo)
    of UMOUNT:
      discard unmountArchive(nc)
    of EXTRACT:
      run_actions(norg_config.actions.before_extract)
      discard extractArchive(nc, repo)
      run_actions(norg_config.actions.after_extract)
    of PRUNE:
      run_actions(norg_config.actions.before_prune)
      discard pruneRepo(nc, repo)
      run_actions(norg_config.actions.after_prune)
    of COMPACT:
      run_actions(norg_config.actions.before_compact)
      discard compactRepo(nc, repo)
      run_actions(norg_config.actions.after_compact)
    of CHECK:
      run_actions(norg_config.actions.before_check)
      discard checkRepo(nc, repo)
      run_actions(norg_config.actions.after_check)
    run_actions(norg_config.actions.after_actions)
  delEncryptionPassphraseInfo()
  run_actions(norg_config.actions.after_everything)
