import ../model/config_type
import execute
import strformat
import os

proc isEmpty(dir: string): bool =
  var count = 0
  for idx, f in walkDir(dir): return false
  #count += 1
  return count == 0

proc extractArchive*(nc: NorgConfig, repo: Repository): int =
  let archive = fmt"{repo.path}::{nc.args.others[0]}"
  var others = nc.args.others[1..^1]
  if nc.args.extract_destination != "":
    discard existsOrCreateDir(nc.args.extract_destination)
    setCurrentDir(nc.args.extract_destination)
  let dir = getCurrentDir()
  if dir.isEmpty():
    echo "Restoring..."
    let ok = run genCommand(cmd = "extract", repo = archive, others = others)
    return ok
  else:
    echo "Not restoring to non-empty destination\r\nPlease use the --destination flag"
