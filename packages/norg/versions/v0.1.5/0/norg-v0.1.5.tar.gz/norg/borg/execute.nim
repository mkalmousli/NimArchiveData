import strutils
import strformat
import osproc

import ../model/borg_type

proc genCommand*(cmd: string, repo: string, others: seq[string]): string =
  let args = others.join(" ")
  let cmd = fmt"{BORG_BIN} {cmd} {repo} {args}"
  return cmd

proc run*(cmd: string): int =
  echo fmt"Trying to run : {cmd}"
  try:
    let res = execCmd(cmd)
    return res
  except:
    echo getCurrentExceptionMsg()
  return 1

proc runDiscard*(cmd: string): int = 
  echo fmt"Trying to run : {cmd}"
  try:
    let res = execCmd(cmd)
    return res
  except:
    echo getCurrentExceptionMsg()
  return 1
