import ../model/config_type
import execute
import strformat

proc mountArchive*(nc: NorgConfig, repo: Repository): int =
  let archive = repo.path & "::" & nc.args.others[0]
  let others = nc.args.others[1..^1]
  let ok = runDiscard genCommand(cmd = "mount", repo = archive, others = others)
  if ok == 0:
    echo fmt"Mounted {archive} at {others[0]}"
  else:
    echo "Failed to mount ", archive

proc unmountArchive*(nc: NorgConfig): int =
  let ok = runDiscard genCommand(cmd = "umount", repo = "", others = nc.args.others)
  if ok == 0:
    echo "Unmounted ", nc.args.others[0]
  else:
    echo "Failed to unmount ", nc.args.others[0]
