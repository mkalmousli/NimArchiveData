import argparse
import ../model/borg_type

type 
  NorgArgs* = object
    config_file*: string
    extract_destination*: string
    borg_cmd*: BorgCommand
    others*: seq[string]

var norg_args*: NorgArgs = NorgArgs()

proc parseArgs*() =
  var p = newParser:
    help("Norg\r\nA portable borg backup wrapper utility")
    option("-c", "--config", help="Config file to use", required = true)
    option("-d", "--destination", help="Destination when extracting backup", required = false)
    arg("borg_cmd", default=some("list"))
    arg("others", nargs = -1)
  try:
    var opts = p.parse(commandLineParams())
    norg_args.config_file = opts.config
    norg_args.extract_destination = opts.destination
    norg_args.borg_cmd = opts.borg_cmd.toBorgCommand()
    norg_args.others = opts.others

  except ShortCircuit as err:
    if err.flag == "argparse_help":
      echo err.help
      quit(1)
  except UsageError:
    echo p.help
    stderr.writeLine getCurrentExceptionMsg()
    quit(1)
