import parsetoml

import ../model/config_type
import ../model/encryption_type
import notifier_config
import actions_config
import maintenance_config
export config_type

proc parseSourceDirectories*(in_conf: TomlValueRef): seq[string] =
  var src_dirs: seq[string] = @[]
  for dir in in_conf{"source_directories"}.getElems():
    src_dirs.add(dir.getStr())
  # this is here for backwards compatibiliy
  for dir in in_conf{"source_dirs"}.getElems():
    norg_config.source_directories.add(dir.getStr())
  return src_dirs

proc parseEncryption*(enc_conf: TomlValueRef) =
  setEncryptionPassphrase(enc_conf{"encryption_passphrase"}.getStr(""))
  setEncryptionPassphraseFD(enc_conf{"encryption_passphrase_fd"}.getStr(""))
  setEncryptionPassCommand(enc_conf{"encryption_passcommand"}.getStr(""))

proc parseRepositories*(rep_conf: TomlValueRef): seq[Repository] =
  var repos: seq[Repository] = @[]
  for r in rep_conf.getElems():
    let rtable = r.getTable()
    var repo = Repository()
    repo.path = rtable["path"].getStr()
    repo.label = rtable["label"].getStr()
    repos.add(repo)
  return repos

proc parseConfigFile*(file: string): NorgConfig =
  norg_config = newNorgConfig()
  let in_conf = parsetoml.parseFile(file)
  norg_config.source_directories = parseSourceDirectories(in_conf)
  parseEncryption(in_conf{"encryption"})
  norg_config.repositories = parseRepositories(in_conf{"repositories"})
  norg_config.notifiers = parseNotifiers(in_conf)
  norg_config.actions = parseActions(in_conf{"actions"})
  norg_config.maintenance = parseMaintenance(in_conf{"maintenance"})
  return norg_config


