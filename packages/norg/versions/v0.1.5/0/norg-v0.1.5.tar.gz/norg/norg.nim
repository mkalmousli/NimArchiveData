import config/init
import config/args
import borg/borg

proc start() =
  parseArgs()
  norg_config = parseConfigFile(norg_args.config_file)
  norg_config.args = norg_args
  if norg_config.source_directories.len > 0 and norg_config.repositories.len > 0:
    borg.execute(norg_config)

when isMainModule:
  start()
