import os

proc setEncryptionPassphrase*(pw: string) = 
  if pw != "":
    putEnv("BORG_PASSPHRASE", pw)

proc setEncryptionPassphraseFD*(pw: string) = 
  if pw != "":
    putEnv("BORG_PASSPHRASE_FD", pw)

proc setEncryptionPassCommand*(pw: string) = 
  if pw != "":
    putEnv("BORG_PASSCOMMAND", pw)

proc delEncryptionPassphraseInfo*() = 
  delEnv("BORG_PASSPHRASE")
  delEnv("BORG_PASSPHRASE_FD")
  delEnv("BORG_PASSCOMMAND")
