const BORG_BIN* = "borg"

type
  BorgCommand* = enum
    LIST = "list"
    INIT = "init",
    CREATE = "create",
    EXTRACT = "extract",
    MOUNT = "mount",
    UMOUNT = "umount",
    PRUNE = "prune",
    CHECK = "check",
    COMPACT = "compact"

proc toBorgCommand*(str: string): BorgCommand = 
  for cmd in BorgCommand.items:
    if str == $cmd: return cmd


