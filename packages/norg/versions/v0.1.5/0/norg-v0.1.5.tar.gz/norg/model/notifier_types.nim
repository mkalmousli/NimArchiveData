import notifier_type
import uptimekuma_type

export notifier_type
export uptimekuma_type

type
  Notifiers* = object
    uptimekuma*: UptimeKuma

