
type
  Repository* = object
    path*: string
    label*: string

