import state_type
import notifier_type
import strformat

import ../utils/httprequest

type 
  UptimeKuma* = object of Notifier

proc send_notify*(uk: UptimeKuma, state: State, runtime: int = 0, msg: string = ""): int {.discardable.} =
  var status: string
  case state
  of Success, Running:
    status = "up"
  else:
    status = "down"
  let message = fmt"{status}\r\n{msg}"
  let url = fmt"{uk.base_url}?status={status}&msg={message}&ping={runtime}"

  echo "Sending notification to " & url
  let res = sendHttpRequest(HttpGet, url)
  if res.status == $Http200:
    return 0
  else:
    return 1

