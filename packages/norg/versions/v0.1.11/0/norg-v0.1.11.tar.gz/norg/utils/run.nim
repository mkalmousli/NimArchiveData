import strformat
import osproc
import ../model/log_type

proc run*(cmd: string): int =
  debug fmt"Trying to run : {cmd}"
  try:
    let res = execCmd(cmd)
    debug("Run Command Exist Code: " & $res)
    return res
  except:
    error getCurrentExceptionMsg()
  return 1

proc runDiscard*(cmd: string): int = 
  debug fmt"Trying to run : {cmd}"
  try:
    let res = execCmd(cmd)
    debug("Run Command Exist Code: " & $res)
    return res
  except:
    error getCurrentExceptionMsg()
  return 1

