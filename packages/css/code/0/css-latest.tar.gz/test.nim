# import checksums/md5

# echo getMD5("")


import macros

dumpTree:
  let t = @[1, 2, 3]
  ObjectConstr(id: "test", another: "another")