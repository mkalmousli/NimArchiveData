import css/types
export types
import css/util
export util
import css/styles_base
export styles_base
import css/core
export core
import css/written/written
export written
import css/computed_styles
export computed_styles

import pkg/jsony_plus/serialized_node
export serialized_node


when isMainModule:
  var styles = newStyles()
  styles.display = "flex"
  echo styles.display