import strutils

import types
import written/types
import imports/imports
import jsony_plus/serialized_node

proc ValidatorResult*(valid: bool, errors: seq[string] = @[]): ValidatorResult =
  result.valid = valid
  var realErrors: seq[Error] = @[]
  if not valid:
    for error in errors:
      var err: Error
      err.message = error
      err.line = 0
      err.column = 0
      realErrors.add(err)
  result.errors = realErrors

proc kebabToCamelCase*(s: string): string =
  ## Converts a kebab-case string to camelCase
  ## Example: "-webkit-line-clamp" -> "webkitLineClamp"
  
  result = ""
  var capitalizeNext = false
  
  for i, c in s:
    if c == '-':
      capitalizeNext = true
    elif capitalizeNext:
      result.add(toUpperAscii(c))
      capitalizeNext = false
    else:
      result.add(c)
  
  # Handle case when string begins with a hyphen (like "-webkit-line-clamp")
  if s.len > 0 and s[0] == '-':
    # We should lowercase the first character of the result
    if result.len > 0:
      result[0] = result[0].toLowerAscii
      
proc camelToKebabCase*(s: string): string =
  ## Converts a camelCase string to kebab-case
  ## Example: "webkitLineClamp" -> "-webkit-line-clamp"
  ## Example: "backgroundColor" -> "background-color"
  
  result = ""
  
  # Check if the string starts with "webkit" (case insensitive)
  let startsWithWebkit = s.len >= 6 and s[0..5].toLowerAscii() == "webkit"
  
  # Add hyphen at the beginning only if it starts with "webkit"
  if startsWithWebkit:
    result.add('-')
  
  for i, c in s:
    if c.isUpperAscii():
      # Add a hyphen before each uppercase letter
      result.add('-')
      # Convert the uppercase to lowercase
      result.add(c.toLowerAscii())
    else:
      result.add(c)
  
  # If the string was empty, we shouldn't have added a hyphen
  if s.len == 0:
    result = ""

proc toKebabCase*(s: string): string =
  if s.len == 0:
    return ""
  
  result = newStringOfCap(s.len + 5) # Extra capacity for potential hyphens
  result.add(s[0].toLowerAscii)
  
  for i in 1 ..< s.len:
    if s[i].isUpperAscii:
      result.add('-')
      result.add(s[i].toLowerAscii)
    else:
      result.add(s[i])

proc replaceUnits*(input: string): string =
  var unitsSeq = @["%"]
  for unitName in units:
    unitsSeq.add(unitName)

  result = input
  for unit in unitsSeq:
    result = result.replace("." & unit, unit)




import macros
proc toNode*(node: WrittenPropertyBody): NimNode =
  if node.kind == pkPURE:
    return newStrLitNode(node.value)
  else:
    return node.node.toNimNode()