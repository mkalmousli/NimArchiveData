import macros
import ./written/written
import ./styles_base
import ./util

import strutils
import tables

import jsony_plus/serialized_node
# import checksums/md5
# import hashes
import essentials/fastHash

import lifter

import ./imports/imports


genPrivateLift WrittenDocumentNode


const GLOBAL_PSEUDO_SELECTORS* = [
  ":root",
  ":fullscreen", 
  ":scope",
  ":host",
  ":host-context",
  ":where",
  ":is", 
  ":not",
  ":has",
  "::placeholder"
]
proc isComputedPseudoSelector(selector: string): bool =
  return selector.startsWith(":") and not GLOBAL_PSEUDO_SELECTORS.contains(selector.split("[")[0].strip())

proc toNimNode(prop: WrittenProperty, key: NimNode, makeImportant: bool = false): NimNode
proc toNimNode(rule: WrittenRule, key: NimNode): NimNode
proc toNimNode(atRule: WrittenAtRule, key: NimNode): NimNode
proc toNimNode(node: WrittenDocumentNode, key: NimNode, makeImportant: bool = false): NimNode =
  case node.kind:
  of cssikPROPERTY:
    if node.property == nil:
      raise newException(ValueError, "toNimNode: property is nil")
    result = toNimNode(node.property, key, makeImportant)
  of cssikRULE:
    if node.rule == nil:
      raise newException(ValueError, "toNimNode: rule is nil")
    result = toNimNode(node.rule, key)
  of cssikATRULE:
    if node.atRule == nil:
      raise newException(ValueError, "toNimNode: atRule is nil")
    result = toNimNode(node.atRule, key)
  of cssikINLINE:
    let endsWithColon = node.content.strip().endsWith(";")
    if endsWithColon:
      result = newStrLitNode(node.content)
    else:
      result = newStrLitNode(node.content.strip() & "; ")
  # else: discard

proc toNimNode(prop: WrittenProperty, key: NimNode, makeImportant: bool = false): NimNode =
  if prop == nil:
    raise newException(ValueError, "propertyToNimNode: property is nil")
  
  case prop.body.kind:
  of pkPURE:
    if makeImportant:
      result = newStrLitNode(prop.name & ": " & prop.body.value & " !important")
    else:
      result = newStrLitNode(prop.name & ": " & prop.body.value)
  of pkMIXED:
    # if prop.body.node == nil:
      # raise newException(ValueError, "propertyToNimNode: mixed property node is nil")
    if makeImportant:
      result = nnkInfix.newTree(
        ident("&"),
        newStrLitNode(prop.name & ": "),
        nnkInfix.newTree(
          ident("&"),
          nnkCall.newTree(
            ident("runtimeValidatePropertyValue"),
            newStrLitNode(prop.name),
            prop.body.node.toNimNode()
          ),
          newStrLitNode(" important!")
        )
      )
    else:
      result = nnkInfix.newTree(
        ident("&"),
        newStrLitNode(prop.name & ": "),
        nnkCall.newTree(
          ident("runtimeValidatePropertyValue"),
          newStrLitNode(prop.name),
          prop.body.node.toNimNode()
        )
      )

proc toNimNode(rule: WrittenRule, key: NimNode): NimNode =
  let isPseudoSelector = rule.selector.isComputedPseudoSelector()
  if isPseudoSelector:
    result = nnkInfix.newTree(
      ident("&"),
      nnkInfix.newTree(
        ident("&"),
        nnkInfix.newTree(
          ident("&"),
          newStrLitNode("."),
          key
        ),
        newStrLitNode(rule.selector)
      ),
      newStrLitNode(" { ")
    )
  else:
    result = newStrLitNode(rule.selector & " { ")
  for node in rule.body:
    result = nnkInfix.newTree(
      ident("&"),
      result,
      node.toNimNode(key, isPseudoSelector)
    )
    if node.kind == cssikPROPERTY:
      # add a semicolon after properties
      result = nnkInfix.newTree(
        ident("&"),
        result.copyNimTree(),
        newStrLitNode("; ")
      )
  result = nnkInfix.newTree(
    ident("&"),
    result,
    newStrLitNode("} ")
  )

proc toNimNode(atRule: WrittenAtRule, key: NimNode): NimNode =
  result = newStrLitNode("@" & atRule.name & " " & atRule.selector & " { ")
  for node in atRule.body:
    result = nnkInfix.newTree(
      ident("&"),
      result,
      node.toNimNode(key, true)
    )
    if node.kind == cssikPROPERTY:
      # add a semicolon after properties
      result = nnkInfix.newTree(
        ident("&"),
        result.copyNimTree(),
        newStrLitNode("; ")
      )
  result = nnkInfix.newTree(
    ident("&"),
    result,
    newStrLitNode("} ")
  )

# Do the same as above, but with runtime values
proc toString(prop: WrittenProperty, key: string, makeImportant: bool = false): string
proc toString(rule: WrittenRule, key: string): string
proc toString(atRule: WrittenAtRule, key: string): string
proc toString(node: WrittenDocumentNode, key: string, makeImportant: bool = false): string =
  case node.kind:
  of cssikPROPERTY:
    if node.property == nil:
      raise newException(ValueError, "toString: property is nil")
    result = node.property.toString(key, makeImportant)
  of cssikRULE:
    if node.rule == nil:
      raise newException(ValueError, "toString: rule is nil")
    result = node.rule.toString(key)
  of cssikATRULE:
    if node.atRule == nil:
      raise newException(ValueError, "toString: atRule is nil")
    result = node.atRule.toString(key)
  of cssikINLINE:
    if node.content.strip().endsWith(";"):
      result = node.content
    else:
      result = node.content.strip() & "; "

proc toString(prop: WrittenProperty, key: string, makeImportant: bool = false): string =
  if prop == nil:
    raise newException(ValueError, "propertyToString: property is nil")
  case prop.body.kind:
  of pkPURE:
    if makeImportant and not prop.body.value.endsWith("!important"):
      result = prop.name & ": " & prop.body.value & " !important; "
    else:
      result = prop.name & ": " & prop.body.value & "; "
  of pkMIXED:
    raise newException(ValueError, "toString: mixed properties are not supported in this context, this should never happen.")
proc toString(rule: WrittenRule, key: string): string =
  let isPseudoSelector = rule.selector.isComputedPseudoSelector()
  if isPseudoSelector:
    result = "." & key & rule.selector & " { "
  else:
    result = rule.selector & " { "
  for node in rule.body:
    result.add(node.toString(key, isPseudoSelector))
  result.add("} ")
proc toString(atRule: WrittenAtRule, key: string): string =
  result = "@" & atRule.name & " " & atRule.selector & " { "
  for node in atRule.body:
    result.add(node.toString(key, true))
  result.add("} ")





# Convert properties to inline style representation
proc toStylesAttribute*(properties: seq[WrittenDocumentNode]): NimNode =
  result = newEmptyNode()
  for node in properties:
    if node.kind != cssikPROPERTY:
      raise newException(ValueError, "toStylesAttribute: expected cssikPROPERTY, got " & $node.kind)
    if node.property == nil:
      raise newException(ValueError, "toStylesAttribute: property is nil")
    
    let propNode = toNimNode(node.property, newEmptyNode())
    if result.kind == nnkEmpty:
      result = propNode
    else:
      # result = nnkInfix.newTree(
      #   ident("&"),
      #   # nnkInfix.newTree(
      #   #   ident("&"),
      #   #   result.copyNimTree(),
      #   # ),
      #   result,
      #   propNode
      # )
      result = nnkInfix.newTree(
        ident("&"),
        nnkInfix.newTree(
          ident("&"),
          result,
          newStrLitNode("; ")
        ),
        propNode
      )

proc toStylesAttribute*(styles: Styles): string =
  $styles

# Convert rules to class attribute representation given the key
proc toClassAttribute*(rules: seq[WrittenDocumentNode], key: NimNode): NimNode =
  var classNames: seq[string] = @[]
  result = newEmptyNode()
  for node in rules:
    if node.kind == cssikPROPERTY:
      raise newException(ValueError, "toClassAttribute: expected cssikRULE or cssikATRULE, got cssikPROPERTY")
    
    # only rules get computed names 
    if node.kind == cssikRULE:
      let rule = node.rule
      # only compute class attributes for pseudo-selectors
      if rule.selector.startsWith(":"):
        let classNode = key
        if not classNames.contains(classNode.repr):
          classNames.add(classNode.repr)
          if result.kind == nnkEmpty:
            result = classNode
          else:
            result = nnkInfix.newTree(
              ident("&"),
              nnkInfix.newTree(
                ident("&"),
                result,
                newStrLitNode(" "),
              ),
              classNode
            )

proc toClassAttribute*(styles: Styles, key: string): string =
  var classNames: seq[string] = @[]
  for node in styles.rules:
    if node.kind == cssikRULE:
      let rule = node.rule
      # only compute class attributes for pseudo-selectors
      if rule.selector.startsWith(":"):
        let className = key
        if not classNames.contains(className):
          # result.add(key & rule.selector)
          classNames.add(className)
  return classNames.join(" ")
    

# Convert rules to styles element representation given the key
proc toStylesElement*(rules: seq[WrittenDocumentNode], key: NimNode): NimNode =
  result = newEmptyNode()
  for node in rules:
    if node.kind == cssikPROPERTY:
      raise newException(ValueError, "toStylesElement: expected cssikRULE or cssikATRULE, got cssikPROPERTY. This should never happen.")
    
    let node = toNimNode(node, key)
    if result.kind == nnkEmpty:
      result = node
    else:
      result = nnkInfix.newTree(
        ident("&"),
        nnkInfix.newTree(
          ident("&"),
          result,
          newStrLitNode(" "),
        ),
        node
      )

proc toStylesElement*(styles: Styles, key: string): string =
  result = ""
  for node in styles.rules:
    if result == "":
      result = toString(node, key)
    else:
      result.add(" ")
      result.add(toString(node, key))
  for node in styles.atRules:
    if result == "":
      result = toString(node, key)
    else:
      result.add(" ")
      result.add(toString(node, key))
  for node in styles.inline:
    var content = node.content.strip()
    if not content.endsWith(";"):
      content.add("; ")
    if result == "":
      result = content
    else:
      result.add(" ")
      result.add(content)