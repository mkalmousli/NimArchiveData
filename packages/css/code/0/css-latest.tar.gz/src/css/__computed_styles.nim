import macros
import ./written/written
import ./styles_base
import ./util

import strutils
import tables

import jsony_plus/serialized_node
import essentials/fastHash

import lifter

import ./imports/imports

genPrivateLift WrittenDocumentNode

# These can never have any selector prefixes
const GLOBAL_PSEUDO_SELECTORS* = [
  ":root", ":fullscreen", ":scope", ":host", ":host-context",
  ":where", ":is", ":not", ":has", "::placeholder"
]

proc isGlobalPseudoSelector(selector: string): bool =
  for globalSelector in GLOBAL_PSEUDO_SELECTORS:
    if selector == globalSelector or selector.startsWith(globalSelector & "(") or selector.startsWith(globalSelector & "["):
      return true
  return false

# New type to track style batches
type
  StyleBatch* = object
    properties*: seq[tuple[name: string, value: string]]
    selector*: string
    isPseudo*: bool
    baseClass*: string  # For pseudo-selectors, the base class to apply

proc findNode(stmtList: NimNode, propertyName: string): NimNode =
  ## Find a specific property assignment node within a statement list by property name
  if stmtList.kind != nnkStmtList:
    echo "Expected a statement list, but got: ", stmtList.kind
    return nil
  
  for child in stmtList:
    # Look for property assignment (name: value)
    if child.kind == nnkCall and child.len == 2:
      let name = child[0].strVal
      let kebabName = camelToKebabCase(name)
      if kebabName == propertyName:
        return child
    elif child.kind == nnkExprColonExpr and child[0].kind in {nnkIdent, nnkAccQuoted}:
      let name = if child[0].kind == nnkIdent: child[0].strVal else: child[0].repr
      let kebabName = camelToKebabCase(name)
      
      if kebabName == propertyName:
        return child
    # Look for nested statements
    elif child.kind == nnkStmtList:
      let found = findNode(child, propertyName)
      if found != nil:
        return found
        
  return nil

proc collectNonStrLitNodes(node: NimNode): seq[string] =
  ## Collects representations of non-string literal nodes for mixed properties
  var result = newSeq[string]()
  
  proc traverse(n: NimNode) =
    if n.isNil:
      return
      
    # Check if current node is not a string literal and is a value node
    if n.kind notin {nnkStrLit..nnkTripleStrLit} and n.kind in {
      nnkIntLit..nnkFloat128Lit, nnkIdent, nnkSym, nnkCall, nnkCommand, 
      nnkInfix, nnkPrefix, nnkDotExpr, nnkBracketExpr, nnkPar, nnkAccQuoted
    }:
      result.add(n.repr)
    
    # Recursively traverse all children
    for i in 0..<n.len:
      traverse(n[i])
  
  # Start the traversal
  traverse(node)
  return result


  
proc separateStyleContent*(styleDoc: seq[WrittenDocumentNode]): (seq[WrittenDocumentNode], seq[WrittenDocumentNode]) =
  ## Separates root-level CSS properties from CSS selectors/rules
  ## Returns (rootLevelProperties, cssSelectorsAndRules)
  
  var rootLevelProperties: seq[WrittenDocumentNode] = @[]
  var cssSelectorsAndRules: seq[WrittenDocumentNode] = @[]
  
  for node in styleDoc:
    case node.kind:
    of cssikPROPERTY:
      # Check if this property has a selector (came from a rule)
      if node.selector != "" and node.selector != nil:
        # This property came from a selector/rule, treat as CSS content
        cssSelectorsAndRules.add(node)
      else:
        # This is a true root-level property (no selector)
        rootLevelProperties.add(node)
    
    of cssikRULE, cssikATRULE, cssikINLINE:
      # These are CSS selectors, at-rules, imports, keyframes, media queries, etc.
      # They should go in the <style> block
      cssSelectorsAndRules.add(node)
    
    else:
      # Handle other node types as needed
      # Default to treating as CSS selector/rule for safety
      cssSelectorsAndRules.add(node)
  
  return (rootLevelProperties, cssSelectorsAndRules)


proc computeStyles*(uuid: string, body: NimNode): seq[WrittenDocumentNode] =
  # Parse the written document from the body
  let writtenDoc = parseWrittenDocument(body)
  # echo "WRITTEN DOC:"
  # echo writtenDoc.treeRepr

  var styles: seq[WrittenDocumentNode] = @[]
  
  # Variables to track parent rule context
  var currentRuleStack = ""
  var inRule = false

  # Process each node in the writtenDoc
  for docNode in writtenDoc:
    case docNode.kind:
    of cssikPROPERTY:
      let propName = docNode.property.name
      var propStack: seq[string] = @[]
      
      # If we're inside a rule, use the rule's stack as a base
      if inRule:
        propStack.add(currentRuleStack)
      
      # For mixed properties, add non-string literals to stack
      case docNode.property.body.kind:
      of pkPURE:
        # Pure string value - no additional stack items
        discard
      of pkMIXED:
        # Find the property in the AST
        let propertyNode = body.findNode(propName)
        if propertyNode != nil:
          # Extract variables and add to stack
          let nonStrLits = collectNonStrLitNodes(propertyNode)
          for expr in nonStrLits:
            propStack.add expr
        else:
          echo "Warning: Could not find property node for: ", propName
      
      # Calculate the stack hash for this property
      let stackHash = $fastHash(propStack.join(", "))
      
      # Store the node with updated stack in styles
      var propNode = WrittenDocumentNode(
        kind: cssikPROPERTY,
        property: docNode.property,
        stack: stackHash
      )
      styles.add propNode
      
    of cssikRULE:
      # Set rule context for nested properties
      inRule = true
      currentRuleStack = docNode.rule.selector
      
      # Add the rule itself to styles
      # styles.add docNode
      
      # For each property in the rule body

      var properties: seq[WrittenDocumentNode] = @[]
      for child in docNode.rule.body:
        if child.kind == cssikPROPERTY:
          var childStack: seq[string] = @[currentRuleStack]
          
          # Add variables for mixed properties
          case child.property.body.kind:
          of pkPURE:
            # Pure string value
            discard
          of pkMIXED:
            # Get variables for this property
            let propertyNode = body.findNode(child.property.name)
            if propertyNode != nil:
              let nonStrLits = collectNonStrLitNodes(propertyNode)
              for exprr in nonStrLits:
                childStack.add exprr
            
          let childStackHash = $fastHash(childStack.join(", "))
          # var childStackHash = docNode.rule.selector
          var selector = docNode.rule.selector

          echo "SELECTOR"
          echo selector
          echo "IS"
          echo isGlobalPseudoSelector(selector)

          # echo "Child stack: ", childStackHash
          if selector.startsWith(":") and not isGlobalPseudoSelector(selector):
            selector = uuid & "_" & childStackHash & selector
          # echo "Child stack hash: ", childStackHash

          # Create a node with updated stack
          var childNode = WrittenDocumentNode(
            kind: cssikPROPERTY,
            property: child.property,
            stack: childStackHash,
            selector: selector
          )
          styles.add childNode
      
      # Reset rule context
      inRule = false
      currentRuleStack = ""
      
    of cssikATRULE:
      # Process at-rule similar to rule but with additional name
      styles.add docNode
      
      # # For each property in the at-rule body
      # for child in docNode.atRule.body:
      #   if child.kind == cssikPROPERTY:
      #     var childStack: seq[string] = @[docNode.atRule.name & " " & docNode.atRule.selector]
          
      #     # Add variables for mixed properties
      #     case child.property.body.kind:
      #     of pkPURE:
      #       discard
      #     of pkMIXED:
      #       let propertyNode = body.findNode(child.property.name)
      #       if propertyNode != nil:
      #         let nonStrLits = collectNonStrLitNodes(propertyNode)
      #         for expr in nonStrLits:
      #           childStack.add expr
          
      #     let childStackHash = getMD5(childStack.join(", "))
          
      #     # Create a node with updated stack
      #     var childNode = WrittenDocumentNode(
      #       kind: cssikPROPERTY,
      #       property: child.property,
      #       stack: childStackHash
      #     )
      #     styles.add childNode
      
    of cssikINLINE:
      # Handle inline rules - typically just carry them through
      styles.add docNode
  
  # Return the computed styles
  return styles


proc computePropertyBatch(properties: seq[tuple[name, value: string]]): string =
  ## Compute a hash for a batch of properties
  var parts: seq[string] = @[]
  for (name, value) in properties:
    parts.add(name & ":" & value)
  return $fastHash(parts.join(";"))

proc batchStyles*(styles: seq[WrittenDocumentNode]): seq[StyleBatch] =
  ## Group styles into batches for more efficient class generation
  var batches: seq[StyleBatch] = @[]
  var currentBatch: StyleBatch
  var batchTable = initTable[string, StyleBatch]()
  
  for node in styles:
    case node.kind:
    of cssikPROPERTY:
      let key = node.stack & "|" & node.selector
      
      if not batchTable.hasKey(key):
        batchTable[key] = StyleBatch(
          properties: @[],
          selector: node.selector,
          isPseudo: false,
          baseClass: ""
        )
      
      batchTable[key].properties.add((node.property.name, 
        case node.property.body.kind:
        of pkPURE: node.property.body.value
        of pkMIXED: "/* mixed: " & node.property.name & " */"
      ))
      
      # Check if this is a pseudo-selector
      if node.selector.len > 0 and (":" in node.selector or "[" in node.selector):
        batchTable[key].isPseudo = true
        # Extract base class
        let colonPos = node.selector.find(':')
        let bracketPos = node.selector.find('[')
        var cutPos = node.selector.len
        if colonPos >= 0: cutPos = colonPos
        if bracketPos >= 0 and bracketPos < cutPos: cutPos = bracketPos
        if cutPos < node.selector.len:
          batchTable[key].baseClass = node.selector[0..<cutPos]
    
    of cssikRULE, cssikATRULE, cssikINLINE:
      # These remain as individual entries
      batches.add(StyleBatch(
        properties: @[],
        selector: if node.kind == cssikRULE: node.rule.selector else: "",
        isPseudo: false,
        baseClass: ""
      ))
  
  # Convert table to sequence
  for key, batch in batchTable:
    batches.add(batch)
  
  return batches

proc computeClassesStr*(uuid: string, styles: seq[WrittenDocumentNode]): string =
  ## Generate CSS string from styles using batching
  let batches = batchStyles(styles)
  var cssRules: seq[string] = @[]
  
  for batch in batches:
    if batch.properties.len > 0:
      # Generate class name from batch hash
      let batchHash = computePropertyBatch(batch.properties)
      var selector: string
      
      if batch.selector.len > 0:
        selector = batch.selector
      else:
        selector = "." & uuid & "_" & batchHash
      
      # Build CSS rule
      var rule = selector & " {\n"
      for (name, value) in batch.properties:
        rule.add("  " & name & ": " & value & ";\n")
      rule.add("}")
      cssRules.add(rule)
    else:
      # Handle non-property nodes (rules, at-rules, etc.)
      # These are stored as individual nodes in the original styles
      for node in styles:
        case node.kind:
        of cssikRULE:
          # Direct CSS rule
          var ruleText = node.rule.selector & " {\n"
          for bodyNode in node.rule.body:
            if bodyNode.kind == cssikPROPERTY:
              let propName = bodyNode.property.name
              var propValue: string
              case bodyNode.property.body.kind:
              of pkPURE:
                propValue = bodyNode.property.body.value
              of pkMIXED:
                propValue = "/* mixed property: " & propName & " */"
              ruleText.add("  " & propName & ": " & propValue & ";\n")
          ruleText.add("}")
          cssRules.add(ruleText)
        
        of cssikATRULE:
          # At-rule (@media, @keyframes, etc.)
          var atRuleText: string
          
          # Add @ symbol if not present
          if node.atRule.name.startsWith("@"):
            atRuleText = node.atRule.name
          else:
            atRuleText = "@" & node.atRule.name
          
          # Add selector if present
          if node.atRule.selector.len > 0:
            atRuleText.add(" " & node.atRule.selector)
          
          atRuleText.add(" {\n")
          
          # Process body content
          for bodyNode in node.atRule.body:
            case bodyNode.kind:
            of cssikPROPERTY:
              let propName = bodyNode.property.name
              var propValue: string
              case bodyNode.property.body.kind:
              of pkPURE:
                propValue = bodyNode.property.body.value
              of pkMIXED:
                propValue = "/* mixed property: " & propName & " */"
              atRuleText.add("  " & propName & ": " & propValue & ";\n")
            
            of cssikRULE:
              # Nested rules within at-rules (like keyframe percentages)
              atRuleText.add("  " & bodyNode.rule.selector & " {\n")
              for nestedProp in bodyNode.rule.body:
                if nestedProp.kind == cssikPROPERTY:
                  let propName = nestedProp.property.name
                  var propValue: string
                  case nestedProp.property.body.kind:
                  of pkPURE:
                    propValue = nestedProp.property.body.value
                  of pkMIXED:
                    propValue = "/* mixed property: " & propName & " */"
                  atRuleText.add("    " & propName & ": " & propValue & ";\n")
              atRuleText.add("  }\n")
            
            else:
              discard
          
          atRuleText.add("}")
          cssRules.add(atRuleText)
        
        of cssikINLINE:
          # Inline CSS - add as-is
          cssRules.add(node.content)
        
        of cssikPROPERTY:
          # Already handled in batches
          discard
  
  return cssRules.join("\n\n")

proc computeClasses*(uuid: string, styles: seq[WrittenDocumentNode]): string =
  ## Compute class names including base classes for pseudo-selectors
  let batches = batchStyles(styles)
  var classNames: seq[string] = @[]
  var addedClasses = initTable[string, bool]()
  
  for batch in batches:
    if batch.properties.len > 0:
      let batchHash = computePropertyBatch(batch.properties)
      let className = uuid & "_" & batchHash
      
      # Add the batch class
      if not addedClasses.hasKey(className):
        classNames.add(className)
        addedClasses[className] = true
      
      # If this is a pseudo-selector, also add its base class
      if batch.isPseudo and batch.baseClass.len > 0:
        # Remove any prefix to get clean class name
        var baseClassName = batch.baseClass
        if baseClassName.startsWith("obj-"):
          baseClassName = baseClassName[4..^1]
        elif baseClassName.startsWith("."):
          baseClassName = baseClassName[1..^1]
        
        if not addedClasses.hasKey(baseClassName):
          classNames.add(baseClassName)
          addedClasses[baseClassName] = true
  
  return classNames.join(" ")

# Simplified style property handling
template addStyleProperty*(styles: var Styles, propName: string, propValue: string, context: seq[string] = @[]) =
  ## Simplified template for adding style properties
  let contextStr = if context.len > 0: context.join(",") & "," else: ""
  let stackHash = $fastHash(contextStr & "styles," & propName & ":" & propValue)
  
  styles.addStack(stackHash, WrittenDocumentNode(
    kind: cssikPROPERTY,
    stack: stackHash,
    selector: "",
    property: WrittenProperty(
      name: propName,
      body: WrittenPropertyBody(kind: pkPURE, value: propValue)
    )
  ))

proc computeStylesCode*(uuid: string, body: NimNode): tuple[styles: seq[WrittenDocumentNode], transformedBody: NimNode] =
  ## Simplified version that generates cleaner code
  var styles: seq[WrittenDocumentNode] = @[]
  var transformedBody = newStmtList()
  
  proc processNode(node: NimNode, context: seq[string] = @[]): NimNode =
    case node.kind:
    of nnkStmtList:
      result = newStmtList()
      for child in node:
        result.add processNode(child, context)
    
    of nnkAsgn:
      # Handle style property assignments
      echo node.treeRepr
      if node.kind == nnkAsgn and node[0].kind == nnkDotExpr:
        let repr = node.repr
        let leftSide = repr.split(" = ")[0]
        let propName = camelToKebabCase(repr.split(" = ")[0].split(".")[^1].strip())

        if propName in properties and not leftSide.contains("(") and not leftSide.contains(".direct."):

          let propValue = node[1]
          let styleObj = node[0][0]
          
          # Generate cleaner code using the template
          result = newStmtList(
            node,  # Keep original assignment
            nnkCall.newTree(
              ident("addStyleProperty"),
              styleObj,
              newStrLitNode(propName),
              propValue
            )
          )
          
          # Track the style for compile-time
          var body: WrittenPropertyBody
          if propValue.kind in {nnkStrLit..nnkTripleStrLit}:
            body = WrittenPropertyBody(kind: pkPURE, value: propValue.strVal)
          else:
            body = WrittenPropertyBody(kind: pkMIXED, node: propValue.toSerializedNode())

          styles.add WrittenDocumentNode(
            kind: cssikPROPERTY,
            property: WrittenProperty(
              name: propName,
              body: body
            ),
            stack: "RUNTIME"  # Placeholder for runtime computation
          )
        else:
          result = node
      else:
        result = node
    
    of nnkCall:
      # Handle styles.add: blocks
      if node[0].kind == nnkDotExpr and node[0][1].strVal == "add" and 
         node[1].kind == nnkStmtList:
        
        let stylesObj = node[0][0]
        let addBody = node[1]
        
        # Parse the add body
        let computedStyles = computeStyles(uuid, addBody)
        
        # Generate batched addStack calls
        let batches = batchStyles(computedStyles)
        result = newStmtList()
        
        for batch in batches:
          if batch.properties.len > 0:
            let batchHash = computePropertyBatch(batch.properties)
            
            # Create a single node for the entire batch
            var batchNode = WrittenDocumentNode(
              kind: cssikRULE,
              rule: WrittenRule(
                selector: if batch.selector.len > 0: batch.selector else: "." & uuid & "_" & batchHash,
                body: @[]
              )
            )
            
            for (name, value) in batch.properties:
              batchNode.rule.body.add WrittenDocumentNode(
                kind: cssikPROPERTY,
                property: WrittenProperty(
                  name: name,
                  body: WrittenPropertyBody(kind: pkPURE, value: value)
                )
              )
            
            result.add nnkCall.newTree(
              nnkDotExpr.newTree(stylesObj, ident("addStack")),
              newStrLitNode(batchHash),
              lift[WrittenDocumentNode](batchNode)
            )
            
            # Track for compile-time
            styles.add batchNode
      else:
        result = node
    
    else:
      result = node
  
  transformedBody = processNode(body)
  return (styles: styles, transformedBody: transformedBody)

# Runtime helpers that handle input style context
proc mergeStyleContexts*(inputStyles: Styles, localContext: string): string =
  ## Merge input style contexts with local context for proper cascading
  var contexts: seq[string] = @[]
  for stackHash, _ in inputStyles.stack:
    contexts.add stackHash
  contexts.add localContext
  return $fastHash(contexts.join(","))

# Update the Styles type to better handle batching
proc addBatch*(styles: var Styles, properties: seq[tuple[name, value: string]]) =
  ## Add a batch of properties at once
  let batchHash = computePropertyBatch(properties)
  
  var batchNode = WrittenDocumentNode(
    kind: cssikRULE,
    rule: WrittenRule(
      selector: ".obj-" & $fastHash(repr(styles)) & "_" & batchHash,
      body: @[]
    )
  )
  
  for (name, value) in properties:
    batchNode.rule.body.add WrittenDocumentNode(
      kind: cssikPROPERTY,
      property: WrittenProperty(
        name: name,
        body: WrittenPropertyBody(kind: pkPURE, value: value)
      )
    )
  
  styles.stack[batchHash] = @[batchNode]