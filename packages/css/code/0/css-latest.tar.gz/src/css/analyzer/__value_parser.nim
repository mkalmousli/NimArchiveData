import options, strutils, sequtils, tables, hashes, macros, times
{.push checks: off, optimization: speed, inline.}

# Skip almost all validity checks for parsing
const UNSAFE_MODE = true

# Increase thread marker stack
{.passC: "-DGC_MARKERS_STACK=8192".}
{.passL: "-DGC_MARKERS_STACK=8192".}

# Arena memory allocator instead of per-token allocation
type TokenArena = object
  data: ptr UncheckedArray[byte]
  capacity: int
  used: int

proc newArena(capacity: int): TokenArena =
  result.data = cast[ptr UncheckedArray[byte]](alloc(capacity))
  result.capacity = capacity
  result.used = 0

proc allocInArena(arena: var TokenArena, size: int): pointer =
  # Add alignment padding
  let alignedSize = (size + 7) and not 7  # Align to 8-byte boundary
  
  if arena.used + alignedSize > arena.capacity:
    # Double the arena size if needed
    let newCap = max(arena.capacity * 2, arena.used + alignedSize)
    let newData = cast[ptr UncheckedArray[byte]](realloc(arena.data, newCap))
    arena.data = newData
    arena.capacity = newCap
  
  result = cast[pointer](cast[ByteAddress](arena.data) + arena.used)
  arena.used += alignedSize  # Use aligned size

# String view to avoid allocation and copying
type StringView = object
  data: ptr UncheckedArray[char]
  len: int

proc `==`(a, b: StringView): bool {.inline.} =
  if a.len != b.len: return false
  if a.len == 0: return true
  return equalMem(a.data, b.data, a.len)

proc hash(view: StringView): Hash {.inline.} =
  var h: Hash = 0
  for i in 0..<view.len:
    h = h !& hash(view.data[i])
  result = !$h

proc `$`(view: StringView): string {.inline.} =
  result = newString(view.len)
  if view.len > 0:
    copyMem(addr result[0], view.data, view.len)

proc view(s: string, start, len: int): StringView {.inline.} =
  if len <= 0:
    return StringView(data: nil, len: 0)
  return StringView(data: cast[ptr UncheckedArray[char]](unsafeAddr s[start]), len: len)

proc view(s: string): StringView {.inline.} =
  if s.len == 0:
    return StringView(data: nil, len: 0)
  return StringView(data: cast[ptr UncheckedArray[char]](unsafeAddr s[0]), len: s.len)

proc strip(view: StringView): StringView {.inline.} =
  if view.len == 0: return view
  
  var start = 0
  while start < view.len and view.data[start] in {' ', '\t'}:
    inc start
  
  var endPos = view.len - 1
  while endPos >= start and view.data[endPos] in {' ', '\t'}:
    dec endPos
  
  if start > 0 or endPos < view.len - 1:
    result.data = cast[ptr UncheckedArray[char]](cast[ByteAddress](view.data) + start)
    result.len = endPos - start + 1
  else:
    result = view

# Fast character lookup tables implemented as static arrays
var IdentCharLookup: array[256, bool]
var HexCharLookup: array[256, bool]
var DigitLookup: array[256, bool]
var WhitespaceLookup: array[256, bool]

proc initLookupTables() =
  for i in 0..255:
    let c = char(i)
    IdentCharLookup[i] = c.isAlphaAscii or c.isDigit or c in {'-', '_'}
    HexCharLookup[i] = c in {'0'..'9', 'a'..'f', 'A'..'F'}
    DigitLookup[i] = c in {'0'..'9'}
    WhitespaceLookup[i] = c in {' ', '\t', '\n', '\r'}

# Initialize lookup tables
initLookupTables()

# Fast character classification
template isIdentChar(c: char): bool = IdentCharLookup[ord(c)]
template isHexChar(c: char): bool = HexCharLookup[ord(c)]
template isDigit(c: char): bool = DigitLookup[ord(c)]
template isWhitespace(c: char): bool = WhitespaceLookup[ord(c)]

type
  ValueTokenKind* = enum
    vtkNumber,      
    vtkDimension,   
    vtkPercentage,  
    vtkColor,       
    vtkString,      
    vtkIdent,       
    vtkFunc,        
    vtkComma,       
    vtkSlash,       
    vtkLParen,      
    vtkRParen,      
    vtkImportant,   
    vtkSequence,
    vtkAtRule,
    vtkProperty,
    vtkRule

  ValueTokenObj = object
    case kind: ValueTokenKind
    of vtkAtRule, vtkRule:
      body: ptr UncheckedArray[ValueToken]
      bodyLen: int
    else:
      discard
    value: StringView
    children: ptr UncheckedArray[ValueToken]
    childrenLen: int
    line: int16      
    column: int16    
    case hasNumValue: bool
    of true:
      numValue: float
      unit: StringView
    of false: discard

  ValueToken* = ptr ValueTokenObj

# Fast unsafe pointer access for token allocations  
proc newToken(arena: var TokenArena, kind: ValueTokenKind): ValueToken {.inline.} =
  result = cast[ValueToken](allocInArena(arena, sizeof(ValueTokenObj)))
  result.kind = kind
  result.value = StringView(data: nil, len: 0)
  result.children = nil
  result.childrenLen = 0
  result.line = 0
  result.column = 0
  result.hasNumValue = false
  
  if kind in {vtkAtRule, vtkRule}:
    result.body = nil
    result.bodyLen = 0

proc setChildren(token: ValueToken, children: openArray[ValueToken], arena: var TokenArena) {.inline.} =
  let len = children.len
  if len == 0:
    token.children = nil
    token.childrenLen = 0
    return
  
  let childrenArray = cast[ptr UncheckedArray[ValueToken]](allocInArena(arena, len * sizeof(ValueToken)))
  for i in 0..<len:
    childrenArray[i] = children[i]
  
  token.children = childrenArray
  token.childrenLen = len

proc setBody(token: ValueToken, body: openArray[ValueToken], arena: var TokenArena) {.inline.} =
  if token.kind notin {vtkAtRule, vtkRule}:
    return
  
  let len = body.len
  if len == 0:
    token.body = nil
    token.bodyLen = 0
    return
  
  let bodyArray = cast[ptr UncheckedArray[ValueToken]](allocInArena(arena, len * sizeof(ValueToken)))
  for i in 0..<len:
    bodyArray[i] = body[i]
  
  token.body = bodyArray
  token.bodyLen = len

# Extremely optimized position tracking
type TokenPosition = object
  data: ptr UncheckedArray[char]
  len: int
  pos: int
  line: int16
  column: int16

proc init(pos: var TokenPosition, s: string) {.inline.} =
  if s.len == 0:
    pos.data = nil
    pos.len = 0
    pos.pos = 0
  else:
    pos.data = cast[ptr UncheckedArray[char]](unsafeAddr s[0])
    pos.len = s.len
    pos.pos = 0
  pos.line = 1
  pos.column = 1

proc atEnd(pos: TokenPosition): bool {.inline.} =
  pos.pos >= pos.len

proc currChar(pos: TokenPosition): char {.inline.} =
  if pos.pos < pos.len:
    result = pos.data[pos.pos]
  else:
    result = '\0'

proc nextChar(pos: var TokenPosition) {.inline.} =
  if pos.pos < pos.len:
    if pos.data[pos.pos] == '\n':
      inc pos.line
      pos.column = 1
    else:
      inc pos.column
    inc pos.pos

proc skipWhitespace(pos: var TokenPosition) {.inline.} =
  while pos.pos < pos.len:
    let c = pos.data[pos.pos]
    if c == ' ' or c == '\t':
      inc pos.column
      inc pos.pos
    elif c == '\n':
      inc pos.line
      pos.column = 1
      inc pos.pos
    elif c == '\r':
      inc pos.column
      inc pos.pos
    else:
      break

proc skipComment(pos: var TokenPosition) {.inline.} =
  if pos.pos + 1 < pos.len and pos.data[pos.pos] == '/' and pos.data[pos.pos+1] == '*':
    inc(pos.pos, 2)
    inc(pos.column, 2)
    
    while pos.pos + 1 < pos.len:
      if pos.data[pos.pos] == '*' and pos.data[pos.pos+1] == '/':
        inc(pos.pos, 2)
        inc(pos.column, 2)
        return
      
      if pos.data[pos.pos] == '\n':
        inc pos.line
        pos.column = 1
      else:
        inc pos.column
      inc pos.pos

proc peekView(pos: TokenPosition, startPos: int): StringView {.inline.} =
  if pos.pos <= startPos:
    return StringView(data: nil, len: 0)
  
  result.data = cast[ptr UncheckedArray[char]](cast[ByteAddress](pos.data) + startPos)
  result.len = pos.pos - startPos

# Forward declarations for core parsing functions
proc parseValueFast*(arena: var TokenArena, input: string, startLine: int16 = 1, 
                  startColumn: int16 = 1, isPropertyValue: bool = false): seq[ValueToken]
proc parseProperty(arena: var TokenArena, pos: var TokenPosition): ValueToken
proc parseRule(arena: var TokenArena, pos: var TokenPosition): ValueToken
proc parseAtRule(arena: var TokenArena, pos: var TokenPosition): ValueToken

# Ultra-optimized token creation functions
proc createIdentToken(arena: var TokenArena, value: StringView, line, column: int16): ValueToken {.inline.} =
  result = newToken(arena, vtkIdent)
  result.value = value
  result.line = line
  result.column = column

proc createCommonToken(arena: var TokenArena, c: char, line, column: int16): ValueToken {.inline.} =
  let kind = 
    case c
    of ',': vtkComma
    of '(': vtkLParen
    of ')': vtkRParen
    of '/': vtkSlash
    else: vtkIdent
  
  result = newToken(arena, kind)
  
  # Create a one-character string view directly
  var charData = cast[ptr UncheckedArray[char]](allocInArena(arena, 1))
  charData[0] = c
  result.value = StringView(data: charData, len: 1)
  
  result.line = line
  result.column = column

proc createNumericToken(arena: var TokenArena, kind: ValueTokenKind, 
                       value: StringView, numValue: float, 
                       unit: StringView, line, column: int16): ValueToken {.inline.} =
  result = newToken(arena, kind)
  result.value = value
  result.hasNumValue = true
  result.numValue = numValue
  result.unit = unit
  result.line = line
  result.column = column

proc createToken(arena: var TokenArena, kind: ValueTokenKind, 
                value: StringView, line, column: int16): ValueToken {.inline.} =
  result = newToken(arena, kind)
  result.value = value
  result.line = line
  result.column = column

# Core parsing functions
proc parseColor(arena: var TokenArena, pos: var TokenPosition): ValueToken {.inline.} =
  let startLine = pos.line
  let startColumn = pos.column
  let startPos = pos.pos
  
  # Skip # character
  nextChar(pos)
  
  # Parse hex digits - fast inline loop
  while pos.pos < pos.len:
    let c = pos.data[pos.pos]
    if not ((c >= '0' and c <= '9') or (c >= 'a' and c <= 'f') or (c >= 'A' and c <= 'F')):
      break
    nextChar(pos)
  
  let color = peekView(pos, startPos)
  return createToken(arena, vtkColor, color, startLine, startColumn)

proc parseString(arena: var TokenArena, pos: var TokenPosition): ValueToken {.inline.} =
  let startLine = pos.line
  let startColumn = pos.column
  let quoteChar = pos.data[pos.pos]
  nextChar(pos)  # Skip opening quote
  
  let startPos = pos.pos
  while pos.pos < pos.len and pos.data[pos.pos] != quoteChar:
    nextChar(pos)
  
  let str = peekView(pos, startPos)
  
  if pos.pos < pos.len:
    nextChar(pos)  # Skip closing quote
  
  return createToken(arena, vtkString, str, startLine, startColumn)

proc parseNumber(arena: var TokenArena, pos: var TokenPosition): ValueToken {.inline.} =
  let startLine = pos.line
  let startColumn = pos.column
  let startPos = pos.pos
  
  # Handle negative sign
  if pos.pos < pos.len and pos.data[pos.pos] == '-':
    nextChar(pos)
  
  # Parse digits before decimal
  while pos.pos < pos.len and (pos.data[pos.pos] >= '0' and pos.data[pos.pos] <= '9'):
    nextChar(pos)
  
  # Parse decimal point and digits after
  if pos.pos < pos.len and pos.data[pos.pos] == '.':
    nextChar(pos)
    while pos.pos < pos.len and (pos.data[pos.pos] >= '0' and pos.data[pos.pos] <= '9'):
      nextChar(pos)
  
  let numStrPos = startPos
  let numStrLen = pos.pos - startPos
  
  # Check for unit
  let unitStartPos = pos.pos
  if pos.pos < pos.len and (pos.data[pos.pos].isAlphaAscii or pos.data[pos.pos] == '%'):
    while pos.pos < pos.len and (pos.data[pos.pos].isAlphaAscii or pos.data[pos.pos] == '-' or pos.data[pos.pos] == '%'):
      nextChar(pos)
  
  let fullValue = peekView(pos, startPos)
  let unitView = if pos.pos > unitStartPos: peekView(pos, unitStartPos) else: StringView(data: nil, len: 0)
  
  # Fast number parsing
  var numValue = 0.0
  if numStrLen > 0:
    var numStr = newString(numStrLen)
    copyMem(addr numStr[0], cast[pointer](cast[ByteAddress](pos.data) + numStrPos), numStrLen)
    try:
      numValue = parseFloat(numStr)
    except:
      discard
  
  # Return appropriate token based on unit
  if unitView.len == 1 and unitView.data[0] == '%':
    return createNumericToken(arena, vtkPercentage, fullValue, numValue, unitView, startLine, startColumn)
  elif unitView.len > 0:
    return createNumericToken(arena, vtkDimension, fullValue, numValue, unitView, startLine, startColumn)
  else:
    return createNumericToken(arena, vtkNumber, fullValue, numValue, unitView, startLine, startColumn)

proc parseImportant(arena: var TokenArena, pos: var TokenPosition): ValueToken {.inline.} =
  let startLine = pos.line
  let startColumn = pos.column
  let startPos = pos.pos
  
  # Skip '!'
  nextChar(pos)
  
  # Check for "important" string (manual inlined check)
  if pos.pos + 8 < pos.len:
    let p = cast[ByteAddress](pos.data) + pos.pos
    if cast[ptr char](p)[] == 'i' and
       cast[ptr char](p+1)[] == 'm' and
       cast[ptr char](p+2)[] == 'p' and
       cast[ptr char](p+3)[] == 'o' and
       cast[ptr char](p+4)[] == 'r' and
       cast[ptr char](p+5)[] == 't' and
       cast[ptr char](p+6)[] == 'a' and
       cast[ptr char](p+7)[] == 'n' and
       cast[ptr char](p+8)[] == 't':
      
      inc(pos.pos, 9)
      inc(pos.column, 9)
      
      # Create !important token
      var importantStr = "!important"
      return createToken(arena, vtkImportant, view(importantStr), startLine, startColumn)
  
  # Return just the '!' if not !important
  pos.pos = startPos + 1
  pos.column = startColumn + 1
  
  var str = "!"
  return createIdentToken(arena, view(str), startLine, startColumn)

proc parseFunctionArgs(arena: var TokenArena, pos: var TokenPosition): seq[ValueToken] {.inline.} =
  result = @[]
  var argStart = pos.pos
  var argStartLine = pos.line
  var argStartColumn = pos.column
  var parenLevel = 0
  
  while pos.pos < pos.len:
    let c = pos.data[pos.pos]
    
    if c == '(':
      parenLevel.inc
      nextChar(pos)
    elif c == ')' and parenLevel > 0:
      parenLevel.dec
      nextChar(pos)
    elif c == ')' and parenLevel == 0:
      # Process last argument
      let argLen = pos.pos - argStart
      if argLen > 0:
        var argStr = newString(argLen)
        copyMem(addr argStr[0], cast[pointer](cast[ByteAddress](pos.data) + argStart), argLen)
        let argTokens = parseValueFast(arena, argStr.strip(), argStartLine, argStartColumn, true)
        if argTokens.len > 0:
          result.add(argTokens)
      
      break
    elif c == ',' and parenLevel == 0:
      # Process current argument
      let argLen = pos.pos - argStart
      if argLen > 0:
        var argStr = newString(argLen)
        copyMem(addr argStr[0], cast[pointer](cast[ByteAddress](pos.data) + argStart), argLen)
        let argTokens = parseValueFast(arena, argStr.strip(), argStartLine, argStartColumn, true)
        if argTokens.len > 0:
          result.add(argTokens)
      
      nextChar(pos)
      argStart = pos.pos
      argStartLine = pos.line
      argStartColumn = pos.column
    else:
      nextChar(pos)

proc parseIdent(arena: var TokenArena, pos: var TokenPosition): ValueToken {.inline.} =
  let startLine = pos.line
  let startColumn = pos.column
  let startPos = pos.pos
  
  # Parse identifier characters
  while pos.pos < pos.len and (pos.data[pos.pos].isAlphaAscii or 
                              pos.data[pos.pos].isDigit or 
                              pos.data[pos.pos] in {'-', '_'}):
    nextChar(pos)
  
  let ident = peekView(pos, startPos)
  
  # Look ahead for function call
  skipWhitespace(pos)
  if pos.pos < pos.len and pos.data[pos.pos] == '(':
    nextChar(pos)  # Skip '('
    let args = parseFunctionArgs(arena, pos)
    
    if pos.pos < pos.len and pos.data[pos.pos] == ')':
      nextChar(pos)  # Skip ')'
    
    let funcToken = createToken(arena, vtkFunc, ident, startLine, startColumn)
    var argsArray: seq[ValueToken] = @[]
    for arg in args:
      argsArray.add(arg)
    
    funcToken.setChildren(argsArray, arena)
    return funcToken
  
  return createIdentToken(arena, ident, startLine, startColumn)

proc parsePotentialProperty(pos: TokenPosition): bool {.inline.} =
  # Check efficiently if this could be a property
  var i = pos.pos
  let len = pos.len
  
  # Skip the identifier
  while i < len and (pos.data[i].isAlphaAscii or pos.data[i].isDigit or pos.data[i] in {'-', '_'}):
    inc i
  
  # Skip whitespace
  while i < len and pos.data[i] in {' ', '\t'}:
    inc i
  
  # Check for colon
  return i < len and pos.data[i] == ':'

proc parseProperty(arena: var TokenArena, pos: var TokenPosition): ValueToken {.inline.} =
  let startLine = pos.line
  let startColumn = pos.column
  let propStartPos = pos.pos
  
  # Find colon
  while pos.pos < pos.len and pos.data[pos.pos] != ':':
    nextChar(pos)
  
  if pos.pos >= pos.len or pos.data[pos.pos] != ':':
    # Not a property (no colon found)
    pos.pos = propStartPos
    pos.line = startLine
    pos.column = startColumn
    return nil
  
  # Extract property name and strip whitespace
  let rawPropName = peekView(pos, propStartPos)
  let propName = strip(rawPropName)
  
  # Skip colon
  nextChar(pos)
  skipWhitespace(pos)
  
  # Remember value position
  let valueStartLine = pos.line
  let valueStartColumn = pos.column
  let valueStartPos = pos.pos
  
  # Find end of property value
  var braceLevel = 0
  var parenLevel = 0
  
  while pos.pos < pos.len:
    let c = pos.data[pos.pos]
    if c == '{':
      braceLevel.inc
      nextChar(pos)
    elif c == '}':
      if braceLevel > 0:
        braceLevel.dec
        nextChar(pos)
      else:
        break
    elif c == '(':
      parenLevel.inc
      nextChar(pos)
    elif c == ')':
      if parenLevel > 0:
        parenLevel.dec
        nextChar(pos)
      else:
        break
    elif c == ';' and braceLevel == 0:
      break
    else:
      nextChar(pos)
  
  # Extract value and strip whitespace
  let rawPropValue = peekView(pos, valueStartPos)
  let propValue = strip(rawPropValue)
  
  # Skip semicolon if present
  if pos.pos < pos.len and pos.data[pos.pos] == ';':
    nextChar(pos)
  
  # Create property token
  result = createToken(arena, vtkProperty, propName, startLine, startColumn)
  
  # Parse value (if non-empty)
  if propValue.len > 0:
    var valueStr = $propValue
    let valueTokens = parseValueFast(arena, valueStr, valueStartLine, valueStartColumn, true)
    result.setChildren(valueTokens, arena)

proc parseRule(arena: var TokenArena, pos: var TokenPosition): ValueToken {.inline.} =
  let startLine = pos.line
  let startColumn = pos.column
  var selectors: seq[ValueToken] = @[]
  
  # Remember start position for backtracking
  let startPos = pos.pos
  let startPosLine = pos.line
  let startPosColumn = pos.column
  
  # Parse selectors
  while true:
    skipWhitespace(pos)
    
    if pos.atEnd():
      break
    
    # Parse selector
    let c = pos.data[pos.pos]
    if c.isAlphaAscii or c in {'-', '_', '%', '.', '#', '*', '[', ':'}:
      let selectorStartLine = pos.line
      let selectorStartColumn = pos.column
      let selectorStartPos = pos.pos
      
      # Parse the selector text - direct memory access
      while pos.pos < pos.len and pos.data[pos.pos] notin {',', '{', '}', ';'}:
        nextChar(pos)
      
      let rawSelector = peekView(pos, selectorStartPos)
      let selector = strip(rawSelector)
      
      if selector.len > 0:
        selectors.add(createIdentToken(arena, selector, selectorStartLine, selectorStartColumn))
    
    skipWhitespace(pos)
    
    # Check for comma or brace
    if pos.pos < pos.len:
      if pos.data[pos.pos] == ',':
        nextChar(pos)
        continue
      elif pos.data[pos.pos] == '{':
        break
      else:
        # Not a valid rule, reset and return nil
        pos.pos = startPos
        pos.line = startPosLine
        pos.column = startPosColumn
        return nil
    else:
      break
  
  # Skip opening brace
  if pos.pos < pos.len and pos.data[pos.pos] == '{':
    nextChar(pos)
  else:
    # Not a valid rule
    pos.pos = startPos
    pos.line = startPosLine
    pos.column = startPosColumn
    return nil
  
  # Create rule token
  result = createToken(arena, vtkRule, StringView(data: nil, len: 0), startLine, startColumn)
  result.setChildren(selectors, arena)
  
  # Parse rule body
  let bodyStartLine = pos.line
  let bodyStartColumn = pos.column
  let bodyStartPos = pos.pos
  
  # Find closing brace
  var braceLevel = 1
  while pos.pos < pos.len and braceLevel > 0:
    if pos.data[pos.pos] == '{':
      braceLevel.inc
      nextChar(pos)
    elif pos.data[pos.pos] == '}':
      braceLevel.dec
      if braceLevel == 0:
        break
      nextChar(pos)
    else:
      nextChar(pos)
  
  # Extract and parse body content
  if pos.pos > bodyStartPos:
    let bodyLen = pos.pos - bodyStartPos
    var bodyContent = newString(bodyLen)
    copyMem(addr bodyContent[0], cast[pointer](cast[ByteAddress](pos.data) + bodyStartPos), bodyLen)
    
    # Parse body with specialized parser
    var bodyTokens = parseValueFast(arena, bodyContent, bodyStartLine, bodyStartColumn, false)
    result.setBody(bodyTokens, arena)
  
  # Skip closing brace
  if pos.pos < pos.len and pos.data[pos.pos] == '}':
    nextChar(pos)

proc parseAtRule(arena: var TokenArena, pos: var TokenPosition): ValueToken {.inline.} =
  # Get the starting position
  let startLine = pos.line
  let startColumn = pos.column
  
  # Skip '@'
  nextChar(pos)
  
  # Parse rule name
  let nameStartPos = pos.pos
  while pos.pos < pos.len and (pos.data[pos.pos].isAlphaAscii or 
                              pos.data[pos.pos].isDigit or 
                              pos.data[pos.pos] in {'-', '_'}):
    nextChar(pos)
  
  # Extract rule name
  let ruleName = peekView(pos, nameStartPos)
  
  # Create at-rule token
  result = createToken(arena, vtkAtRule, ruleName, startLine, startColumn)
  
  # Skip whitespace
  skipWhitespace(pos)
  
  # Capture parameters
  let paramStartPos = pos.pos
  let paramStartLine = pos.line
  let paramStartColumn = pos.column
  
  # Collect everything until '{' or ';'
  while pos.pos < pos.len and pos.data[pos.pos] notin {'{', ';'}:
    nextChar(pos)
  
  # Process parameters
  let paramLen = pos.pos - paramStartPos
  if paramLen > 0:
    var paramStr = newString(paramLen)
    copyMem(addr paramStr[0], cast[pointer](cast[ByteAddress](pos.data) + paramStartPos), paramLen)
    let paramTokens = parseValueFast(arena, paramStr.strip(), paramStartLine, paramStartColumn, false)
    result.setChildren(paramTokens, arena)
  
  # Parse body if we have a '{'
  if pos.pos < pos.len and pos.data[pos.pos] == '{':
    # Skip '{'
    nextChar(pos)
    
    let bodyStartPos = pos.pos
    let bodyStartLine = pos.line
    let bodyStartColumn = pos.column
    
    # Find matching '}'
    var braceLevel = 1
    while pos.pos < pos.len and braceLevel > 0:
      if pos.data[pos.pos] == '{':
        braceLevel.inc
      elif pos.data[pos.pos] == '}':
        braceLevel.dec
      
      if braceLevel > 0 or pos.data[pos.pos] != '}':
        nextChar(pos)
      else: 
        break
    
    # Process the body
    let bodyLen = pos.pos - bodyStartPos
    if bodyLen > 0:
      var bodyContent = newString(bodyLen)
      copyMem(addr bodyContent[0], cast[pointer](cast[ByteAddress](pos.data) + bodyStartPos), bodyLen)
      let bodyTokens = parseValueFast(arena, bodyContent, bodyStartLine, bodyStartColumn, false)
      result.setBody(bodyTokens, arena)
    
    # Skip closing '}'
    if pos.pos < pos.len and pos.data[pos.pos] == '}':
      nextChar(pos)
  elif pos.pos < pos.len and pos.data[pos.pos] == ';':
    # Skip ';'
    nextChar(pos)

proc parseBody(arena: var TokenArena, pos: var TokenPosition): seq[ValueToken] {.inline.} =
  result = @[]
  
  while not pos.atEnd():
    skipWhitespace(pos)
    if pos.atEnd():
      break
    
    let c = pos.data[pos.pos]
    if c == '@':
      let atRule = parseAtRule(arena, pos)
      if atRule != nil:
        result.add(atRule)
    elif c.isAlphaAscii or c in {'-', '_', '.', '#', '[', ':', '*', '%'}:
      # Fast check for property vs rule
      if parsePotentialProperty(pos):
        let prop = parseProperty(arena, pos)
        if prop != nil:
          result.add(prop)
      else:
        # Try as rule
        let rule = parseRule(arena, pos)
        if rule != nil:
          result.add(rule)
        else:
          # Skip unknown content
          while pos.pos < pos.len and pos.data[pos.pos] notin {';', '}'}:
            nextChar(pos)
          if pos.pos < pos.len:
            nextChar(pos)
    else:
      # Skip unknown character
      nextChar(pos)

proc parseCSSDocument(arena: var TokenArena, input: string): seq[ValueToken] {.gcsafe.} =
  if input.len == 0:
    return @[]
  
  var pos: TokenPosition
  pos.init(input)
  result = @[]
  
  while not pos.atEnd():
    skipWhitespace(pos)
    skipComment(pos)
    
    if pos.atEnd():
      break
      
    let c = pos.data[pos.pos]
    if c == '@':
      let atRule = parseAtRule(arena, pos)
      if atRule != nil:
        result.add(atRule)
    elif c.isAlphaAscii or c in {'-', '_', '.', '#', '[', ':', '*', '%'}:
      # Try rule
      let savedPos = pos.pos
      let savedLine = pos.line
      let savedColumn = pos.column
      
      let rule = parseRule(arena, pos)
      if rule != nil:
        result.add(rule)
        continue
      
      # Reset position and try property
      pos.pos = savedPos
      pos.line = savedLine
      pos.column = savedColumn
      
      if parsePotentialProperty(pos):
        let prop = parseProperty(arena, pos)
        if prop != nil:
          result.add(prop)
          continue
      
      # Try identifier
      pos.pos = savedPos
      pos.line = savedLine
      pos.column = savedColumn
      let ident = parseIdent(arena, pos)
      if ident != nil:
        result.add(ident)
      
      # Skip to next structure if nothing worked
      while pos.pos < pos.len and pos.data[pos.pos] notin {';', '{', '}'}:
        nextChar(pos)
      if pos.pos < pos.len:
        nextChar(pos)
    else:
      # Skip unknown character
      nextChar(pos)

proc parseValueFast*(arena: var TokenArena, input: string, startLine: int16 = 1, 
                  startColumn: int16 = 1, isPropertyValue: bool = false): seq[ValueToken] =
  if input.len == 0:
    return @[]
  
  var pos: TokenPosition
  pos.init(input)
  pos.line = startLine
  pos.column = startColumn
  
  result = @[]
  
  # Fast track for CSS documents
  if not isPropertyValue and '{' in input:
    return parseCSSDocument(arena, input)
  
  # Main parsing loop
  while not pos.atEnd():
    skipWhitespace(pos)
    skipComment(pos)

    if pos.atEnd():
      break
    
    let c = pos.data[pos.pos]
    case c
    of '@':
      if isPropertyValue:
        result.add(parseIdent(arena, pos))
      else:
        let atRule = parseAtRule(arena, pos)
        if atRule != nil:
          result.add(atRule)
    of '-':
      if pos.pos + 1 < pos.len and (pos.data[pos.pos + 1] >= '0' and pos.data[pos.pos + 1] <= '9' or pos.data[pos.pos + 1] == '.'):
        result.add(parseNumber(arena, pos))
      elif not isPropertyValue and parsePotentialProperty(pos):
        let prop = parseProperty(arena, pos)
        if prop != nil:
          result.add(prop)
      else:
        result.add(parseIdent(arena, pos))
    of '0'..'9', '.':
      result.add(parseNumber(arena, pos))
    of '"', '\'':
      result.add(parseString(arena, pos))
    of '!':
      result.add(parseImportant(arena, pos))
    of 'a'..'z', 'A'..'Z', '_':
      if not isPropertyValue and parsePotentialProperty(pos):
        let prop = parseProperty(arena, pos)
        if prop != nil:
          result.add(prop)
      else:
        result.add(parseIdent(arena, pos))
    of '#':
      result.add(parseColor(arena, pos))
    of ',':
      result.add(createCommonToken(arena, ',', pos.line, pos.column))
      nextChar(pos)
    of '/':
      result.add(createCommonToken(arena, '/', pos.line, pos.column))
      nextChar(pos)
    of '(':
      result.add(createCommonToken(arena, '(', pos.line, pos.column))
      nextChar(pos)
    of ')':
      result.add(createCommonToken(arena, ')', pos.line, pos.column))
      nextChar(pos)
    of ':':
      var str = ":"
      result.add(createIdentToken(arena, view(str), pos.line, pos.column))
      nextChar(pos)
    of '~', '=', '|', '^', '$', '*', '+', '>', '<', '[', ']':
      result.add(createCommonToken(arena, c, pos.line, pos.column))
      nextChar(pos)
    else:
      # Skip unknown character
      nextChar(pos)
  
  return result

proc parseCSSFast*(input: string): seq[ValueToken] {.gcsafe.} =
  # Create one large arena for all allocations
  var arena = newArena(max(1024*1024, input.len * 2))
  result = parseValueFast(arena, input)

# Forward declarations
proc safeStr(view: StringView): string {.gcsafe, inline.}
proc `$`*(token: ValueToken): string {.gcsafe.}
proc safeTokenStr(tokens: ptr UncheckedArray[ValueToken], count: int): string {.gcsafe.}

# Safe string conversion for StringView
proc safeStr(view: StringView): string {.gcsafe, inline.} =
  if view.data == nil or view.len <= 0 or view.len > 10000:  # Sanity check for length
    return "<invalid>"
  
  try:
    result = newString(view.len)
    copyMem(addr result[0], view.data, view.len)
  except:
    return "<error>"

# Safe token array stringification
proc safeTokenStr(tokens: ptr UncheckedArray[ValueToken], count: int): string {.gcsafe.} =
  if tokens == nil or count <= 0 or count > 10000:  # Sanity check
    return ""
  
  result = ""
  try:
    for i in 0..<min(count, 100):  # Limit to reasonable number for display
      if i > 0:
        result.add(", ")
      result.add($tokens[i])
    
    if count > 100:
      result.add(", ...")
  except:
    result.add("<error>")
  
  return result

# Main string representation function with safety checks
proc `$`*(token: ValueToken): string {.gcsafe.} =
  try:
    if isNil(token):
      return "nil"
    
    case token.kind
    of vtkProperty:
      let propName = safeStr(token.value)
      let childrenStr = if token.childrenLen > 0 and token.children != nil: 
                          ": " & safeTokenStr(token.children, token.childrenLen) 
                        else: 
                          ""
      return "[" & propName & childrenStr & "]"
    
    of vtkAtRule:
      let ruleName = safeStr(token.value)
      var result = "@" & ruleName
      
      # Add parameters if present
      if token.childrenLen > 0 and token.children != nil:
        result.add(" " & safeTokenStr(token.children, token.childrenLen))
      
      # Add body if present
      if token.bodyLen > 0 and token.body != nil:
        result.add(" {" & safeTokenStr(token.body, token.bodyLen) & "}")
      else:
        result.add(";")
        
      return result
    
    of vtkRule:
      var result = "[Rule"
      
      # Add selectors
      if token.childrenLen > 0 and token.children != nil:
        result.add("(")
        for i in 0..<min(token.childrenLen, 10):  # Limit display count
          if i > 0:
            result.add(", ")
          if token.children[i].kind == vtkIdent:
            result.add(safeStr(token.children[i].value))
          else:
            result.add("<non-ident>")
        if token.childrenLen > 10:
          result.add(", ...")
        result.add(")")
      
      # Add body content
      if token.bodyLen > 0 and token.body != nil:
        result.add(" {" & safeTokenStr(token.body, token.bodyLen) & "}")
      else:
        result.add(" {}")
        
      result.add("]")
      return result
    
    of vtkNumber, vtkDimension, vtkPercentage:
      if token.hasNumValue:
        var numStr = if token.numValue >= -1e10 and token.numValue <= 1e10:
                      $token.numValue 
                     else: 
                      "<invalid-num>"
        if token.unit.len > 0 and token.unit.data != nil:
          numStr.add(safeStr(token.unit))
        return "[" & numStr & "]"
      else:
        return "[" & safeStr(token.value) & "]"
        
    of vtkColor, vtkString, vtkIdent: 
      return "[" & safeStr(token.value) & "]"
      
    of vtkFunc:
      var args = if token.childrenLen > 0 and token.children != nil: 
                  safeTokenStr(token.children, token.childrenLen)
                else: 
                  ""
      return "[" & safeStr(token.value) & "(" & args & ")]"
      
    of vtkSequence:
      return "(Sequence " & safeTokenStr(token.children, token.childrenLen) & ")"
      
    of vtkComma: return "[,]"
    of vtkSlash: return "[/]"
    of vtkLParen: return "[(]"
    of vtkRParen: return "[)]"
    of vtkImportant: return "[!important]"
  except:
    return "<exception>"

# Convenience function for seq of tokens
proc `$`*(tokens: seq[ValueToken]): string {.gcsafe.} =
  try:
    result = "["
    for i, token in tokens:
      if i > 0:
        result.add(", ")
      result.add($token)
    result.add("]")
  except:
    result = "[<error>]"
  return result

# Ultra-defensive string representation to handle severe corruption
proc safeDump*(token: ValueToken, maxDepth: int = 2): string =
  # Safety check for nil
  if isNil(token):
    return "<nil>"
  
  # Stop recursion if too deep
  if maxDepth <= 0:
    return "<max-depth>"
  
  try:
    # Basic token type identification
    var kind = "<unknown>"
    try:
      kind = $token.kind
    except:
      discard
    
    result = "[" & kind
    
    # Safely check if value exists and is valid
    if token.value.data != nil and token.value.len > 0 and token.value.len < 1000:
      try:
        var safeValue = newString(token.value.len)
        copyMem(addr safeValue[0], token.value.data, token.value.len)
        
        # Filter non-printable chars
        for i in 0..<safeValue.len:
          if safeValue[i] < ' ' or safeValue[i] > '~':
            safeValue[i] = '?'
        
        result.add(": \"" & safeValue & "\"")
      except:
        result.add(": <corrupt-value>")
    
    # Safely check children
    if token.childrenLen > 0 and token.childrenLen < 100 and token.children != nil:
      try:
        result.add(" children[" & $token.childrenLen & "]=")
        if maxDepth > 1:
          result.add("[")
          for i in 0..<min(token.childrenLen, 3):  # Show max 3 children
            if i > 0: result.add(",")
            try:
              result.add(safeDump(token.children[i], maxDepth-1))
            except:
              result.add("<corrupt-child>")
          if token.childrenLen > 3:
            result.add(",...")
          result.add("]")
        else:
          result.add("<truncated>")
      except:
        result.add(" <corrupt-children>")
    
    # Safely check body for rules and at-rules
    if token.kind in {vtkRule, vtkAtRule} and token.bodyLen > 0 and token.bodyLen < 100 and token.body != nil:
      try:
        result.add(" body[" & $token.bodyLen & "]=")
        if maxDepth > 1:
          result.add("[")
          for i in 0..<min(token.bodyLen, 3):  # Show max 3 body items
            if i > 0: result.add(",")
            try:
              result.add(safeDump(token.body[i], maxDepth-1))
            except:
              result.add("<corrupt-body-item>")
          if token.bodyLen > 3:
            result.add(",...")
          result.add("]")
        else:
          result.add("<truncated>")
      except:
        result.add(" <corrupt-body>")
    
    # Add numeric value if present
    if token.hasNumValue:
      try:
        if token.numValue >= -1e10 and token.numValue <= 1e10:
          result.add(" num=" & $token.numValue)
        else:
          result.add(" num=<invalid>")
      except:
        result.add(" <corrupt-num>")
    
    result.add("]")
  except:
    return "<completely-corrupt>"

# Wrapper for seq of tokens
proc safeDump*(tokens: seq[ValueToken], maxDepth: int = 2): string =
  try:
    result = "["
    for i, token in tokens:
      if i > 0: result.add(", ")
      if i >= 10:  # Limit to 10 tokens
        result.add("...")
        break
      result.add(safeDump(token, maxDepth))
    result.add("]")
  except:
    return "[<corrupt-seq>]"

# Main entry point
when isMainModule:
  # Add TLS size directive
  {.passC: "-DGC_MARKERS_STACK=8192".}
  {.passL: "-DGC_MARKERS_STACK=8192".}
  
  echo "CSS Parser Benchmark"
  echo "-------------------"
  
  let startTime = getTime()
  let content = readFile("src/css/analyzer/bootstrap.css")
  echo "File size: ", content.len, " bytes"
  let tokens = parseCSSFast(content)
  let endTime = getTime()
  echo "Tokenized in: " & $(endTime - startTime)

  echo safeDump(tokens, 3)

{.pop.}  # End of optimization pragmas