import macros
import ./written/written
import ./styles_base
import ./util

import strutils
import tables

import jsony_plus/serialized_node
# import checksums/md5
# import hashes
import essentials/fastHash

import lifter

import ./imports/imports


genPrivateLift WrittenDocumentNode


# These can never have any selector prefixes, this is important to the "computing" of styles to bundle
const GLOBAL_PSEUDO_SELECTORS* = [
  ":root",
  ":fullscreen", 
  ":scope",
  ":host",
  ":host-context",
  ":where",
  ":is", 
  ":not",
  ":has",
  "::placeholder"
]

proc isGlobalPseudoSelector(selector: string): bool =
  ## Check if a selector is a global pseudo-selector that should not be prefixed
  for globalSelector in GLOBAL_PSEUDO_SELECTORS:
    if selector == globalSelector or selector.startsWith(globalSelector & "(") or selector.startsWith(globalSelector & "["):
      return true
  return false

# type
#   ComputedStyles* = object
#     properties*: Table[string, WrittenDocumentNode]
#     rules*: Table[string, WrittenDocumentNode]

proc stmtLessRepr(node: NimNode): string =
  ## Provides a representation of a NimNode with all nested statement lists removed.
  ## Uses the built-in .repr but filters out statement lists from the AST first.
  
  proc filterStmtLists(n: NimNode): NimNode =
    # Base case: nil node
    if n.isNil:
      return nil
    # Skip processing the root node if it's a statement list
    if n.kind == nnkStmtList and n.len == 0:
      return n.copyNimTree()
    
    # Create a copy of the current node
    result = newNimNode(n.kind)
    
    # Copy over any symbol, ident or literal information
    case n.kind:
      of nnkSym:
        result = n.copyNimTree()  # Copy symbol nodes directly
      of nnkIdent:
        result = newIdentNode(n.strVal)
      of nnkCharLit..nnkUInt64Lit, nnkFloatLit..nnkFloat128Lit:
        result = newLit(n.intVal)
      of nnkStrLit..nnkTripleStrLit:
        result = newLit(n.strVal)
      else:
        # Process child nodes
        for i in 0..<n.len:
          let child = n[i]
          # If the child is a statement list that's not empty, replace it with a marker
          if child.kind == nnkStmtList and child.len > 0:
            # Create a comment node to indicate statement list was here
            let marker = newCommentStmtNode("... stmt list ...")
            result.add(marker)
          else:
            # Recursively process non-statement list children
            result.add(filterStmtLists(child))
    
  # Filter out statement lists from the AST, then use the built-in repr
  let filteredNode = filterStmtLists(node)
  return filteredNode.repr

proc getAccQuoted(node: NimNode): seq[NimNode] =
  ## Recursively collects all nnkAccQuoted nodes from within the given NimNode.
  ## Returns a sequence of all found nnkAccQuoted nodes.
  
  var result = newSeq[NimNode]()
  
  proc traverse(n: NimNode) =
    if n.isNil:
      return
      
    # Check if current node is an nnkAccQuoted node
    if n.kind == nnkAccQuoted:
      result.add(n)
    
    # Recursively traverse all children
    for i in 0..<n.len:
      traverse(n[i])
  
  # Start the traversal
  traverse(node)

  return result
    
proc collectNonStrLitNodes(node: NimNode): seq[string] =
  ## Collects representations of non-string literal nodes for mixed properties
  var result = newSeq[string]()
  
  proc traverse(n: NimNode) =
    if n.isNil:
      return
      
    # Check if current node is not a string literal and is a value node
    if n.kind notin {nnkStrLit..nnkTripleStrLit} and n.kind in {
      nnkIntLit..nnkFloat128Lit, nnkIdent, nnkSym, nnkCall, nnkCommand, 
      nnkInfix, nnkPrefix, nnkDotExpr, nnkBracketExpr, nnkPar, nnkAccQuoted
    }:
      result.add(n.repr)
    
    # Recursively traverse all children
    for i in 0..<n.len:
      traverse(n[i])
  
  # Start the traversal
  traverse(node)
  return result
  
proc findNode(stmtList: NimNode, propertyName: string): NimNode =
  ## Find a specific property assignment node within a statement list by property name
  if stmtList.kind != nnkStmtList:
    echo "Expected a statement list, but got: ", stmtList.kind
    return nil
  
  for child in stmtList:
    # Look for property assignment (name: value)
    if child.kind == nnkCall and child.len == 2:
      let name = child[0].strVal
      let kebabName = camelToKebabCase(name)
      if kebabName == propertyName:
        return child
    elif child.kind == nnkExprColonExpr and child[0].kind in {nnkIdent, nnkAccQuoted}:
      let name = if child[0].kind == nnkIdent: child[0].strVal else: child[0].repr
      let kebabName = camelToKebabCase(name)
      
      if kebabName == propertyName:
        return child
    # Look for nested statements
    elif child.kind == nnkStmtList:
      let found = findNode(child, propertyName)
      if found != nil:
        return found
        
  return nil

proc separateStyleContent*(styleDoc: seq[WrittenDocumentNode]): (seq[WrittenDocumentNode], seq[WrittenDocumentNode]) =
  ## Separates root-level CSS properties from CSS selectors/rules
  ## Returns (rootLevelProperties, cssSelectorsAndRules)
  
  var rootLevelProperties: seq[WrittenDocumentNode] = @[]
  var cssSelectorsAndRules: seq[WrittenDocumentNode] = @[]
  
  for node in styleDoc:
    case node.kind:
    of cssikPROPERTY:
      # Check if this property has a selector (came from a rule)
      if node.selector != "" and node.selector != nil:
        # This property came from a selector/rule, treat as CSS content
        cssSelectorsAndRules.add(node)
      else:
        # This is a true root-level property (no selector)
        rootLevelProperties.add(node)
    
    of cssikRULE, cssikATRULE, cssikINLINE:
      # These are CSS selectors, at-rules, imports, keyframes, media queries, etc.
      # They should go in the <style> block
      cssSelectorsAndRules.add(node)
    
    else:
      # Handle other node types as needed
      # Default to treating as CSS selector/rule for safety
      cssSelectorsAndRules.add(node)
  
  return (rootLevelProperties, cssSelectorsAndRules)

proc computeClassesStr*(uuid: string, styles: seq[WrittenDocumentNode]): string =
  ## Generate CSS string from a seq[WrittenDocumentNode]
  
  # Create a table to group nodes by stack
  var stackTable: Table[string, seq[WrittenDocumentNode]] = initTable[string, seq[WrittenDocumentNode]]()
  var cssRules: seq[string] = @[]

  # Helper procedure to add nodes to the stack table
  proc addNode(stackTable: var Table[string, seq[WrittenDocumentNode]], node: WrittenDocumentNode) =
    case node.kind:
    of cssikPROPERTY:
      if not stackTable.hasKey(node.stack):
        stackTable[node.stack] = @[]
      stackTable[node.stack].add node
    of cssikRULE, cssikATRULE, cssikINLINE:
      # Handle other node types - add with empty stack for direct CSS rules
      if not stackTable.hasKey(""):
        stackTable[""] = @[]
      stackTable[""].add node

  # Group nodes by their stack value
  for node in styles:
    stackTable.addNode(node)

  # Process each stack and create CSS rules
  for stack, nodes in stackTable:
    if nodes.len > 0:
      var properties: seq[string] = @[]
      var targetSelector = ""
      var selector = "." & uuid & "_" & stack
      
      for node in nodes:
        if node.kind == cssikPROPERTY:
          if targetSelector.len == 0:
            targetSelector = node.selector
          
          let propName = node.property.name
          var propValue: string
          
          # Handle different property body types
          case node.property.body.kind:
          of pkPURE:
            propValue = node.property.body.value
          of pkMIXED:
            # For mixed properties, use placeholder for now
            propValue = "/* mixed property: " & propName & " */"
          
          # Add the property to our list
          properties.add("  " & propName & ": " & propValue & ";")
        
        elif node.kind == cssikRULE:
          # Direct CSS rule - add it as-is
          var ruleText = node.rule.selector & " {\n"
          for bodyNode in node.rule.body:
            if bodyNode.kind == cssikPROPERTY:
              let propName = bodyNode.property.name
              var propValue: string
              case bodyNode.property.body.kind:
              of pkPURE:
                propValue = bodyNode.property.body.value
              of pkMIXED:
                propValue = "/* mixed property: " & propName & " */"
              ruleText.add("  " & propName & ": " & propValue & ";\n")
          ruleText.add("}")
          cssRules.add(ruleText)
          continue
        
        elif node.kind == cssikATRULE:
          # At-rule - properly format with @ symbol and body content
          var atRuleText: string
          
          # Add @ symbol if not already present
          if node.atRule.name.startsWith("@"):
            atRuleText = node.atRule.name
          else:
            atRuleText = "@" & node.atRule.name
          
          # Add selector if present
          if node.atRule.selector.len > 0:
            atRuleText.add(" " & node.atRule.selector)
          
          atRuleText.add(" {\n")
          
          # Process the body content
          for bodyNode in node.atRule.body:
            case bodyNode.kind:
            of cssikPROPERTY:
              let propName = bodyNode.property.name
              var propValue: string
              case bodyNode.property.body.kind:
              of pkPURE:
                propValue = bodyNode.property.body.value
              of pkMIXED:
                propValue = "/* mixed property: " & propName & " */"
              atRuleText.add("  " & propName & ": " & propValue & ";\n")
            of cssikRULE:
              # Handle nested rules within at-rules (like keyframe percentages)
              atRuleText.add("  " & bodyNode.rule.selector & " {\n")
              for nestedProp in bodyNode.rule.body:
                if nestedProp.kind == cssikPROPERTY:
                  let propName = nestedProp.property.name
                  var propValue: string
                  case nestedProp.property.body.kind:
                  of pkPURE:
                    propValue = nestedProp.property.body.value
                  of pkMIXED:
                    propValue = "/* mixed property: " & propName & " */"
                  atRuleText.add("    " & propName & ": " & propValue & ";\n")
              atRuleText.add("  }\n")
            else:
              # Handle other content types as needed
              discard
          
          atRuleText.add("}")
          cssRules.add(atRuleText)
          continue
        
        elif node.kind == cssikINLINE:
          # Inline CSS - add it as-is  
          cssRules.add(node.content)
          continue
      
      # Handle selector determination for property groups
      if properties.len > 0:
        if targetSelector.len > 0:
          # Check if this is a pseudo-selector that needs a dot prefix
          if (":" in targetSelector or "[" in targetSelector) and 
             (targetSelector.startsWith(uuid & "_") or targetSelector.startsWith("obj-")):
            # This is a transformed pseudo-selector, add dot prefix
            selector = "." & targetSelector
          else:
            # Use the selector as-is - DSL should handle dot addition for !class syntax
            selector = targetSelector
        
        # Create the CSS rule for this group of properties
        var cssRule = selector & " {\n"
        cssRule.add(properties.join("\n"))
        cssRule.add("\n}")
        cssRules.add(cssRule)
  
  # Join all CSS rules
  return cssRules.join("\n\n")

proc computeClassesStr*(uuid: string, styles: Styles): string =
  ## Generate CSS string from a Styles object
  ## Since properties get transformed into stack entries, focus on styles.stack
  
  var cssRules: seq[string] = @[]
  
  # Process each stack in the styles object (this is where the real data is)
  for stackHash, nodes in styles.stack:
    if nodes.len == 0:
      continue
      
    # Determine the class name for this stack
    var className = "." & uuid & "_" & stackHash
    var hasCustomSelector = false
    
    # Check if any node has a custom selector
    for node in nodes:
      if node.selector.len > 0:
        # Check if it's a transformed pseudo-selector
        if (":" in node.selector or "[" in node.selector) and 
           (node.selector.startsWith(uuid & "_") or node.selector.startsWith("obj-")):
          # This is a transformed pseudo-selector, use it directly with dot prefix
          className = "." & node.selector
          hasCustomSelector = true
          break
        else:
          # Use the selector as-is - the DSL parsing should handle adding dots for !class syntax
          className = node.selector
          hasCustomSelector = true
          break
    
    # Collect all properties for this stack
    var properties: seq[string] = @[]
    
    for node in nodes:
      if node.kind == cssikPROPERTY:
        let propName = node.property.name
        var propValue: string
        
        # Handle different property body types
        case node.property.body.kind:
        of pkPURE:
          propValue = node.property.body.value
        of pkMIXED:
          # For mixed properties, we need to reconstruct the value
          # This is tricky since we only have the serialized node
          # For now, we'll use a placeholder - this might need enhancement
          propValue = "/* mixed property: " & propName & " */"
          # propValue = node.property.body.node.toNimNode()
          # TODO: Properly deserialize and evaluate the mixed property
        
        # Add the property to our list
        properties.add("  " & propName & ": " & propValue & ";")
    
    # Only create a rule if we have properties
    if properties.len > 0:
      var cssRule = className & " {\n"
      cssRule.add(properties.join("\n"))
      cssRule.add("\n}")
      cssRules.add(cssRule)
  
  # # Handle any remaining direct properties (probably rare after transformation)
  # if styles.properties.len > 0:
  #   let className = "." & uuid
  #   var properties: seq[string] = @[]
    
  #   for propName, propValue in styles.properties:
  #     properties.add("  " & propName & ": " & propValue & ";")
    
  #   if properties.len > 0:
  #     var cssRule = className & " {\n"
  #     cssRule.add(properties.join("\n"))
  #     cssRule.add("\n}")
  #     cssRules.add(cssRule)
  
  # Join all CSS rules
  return cssRules.join("\n\n")

proc computeClasses*(uuid: string, styles: seq[WrittenDocumentNode]): string =
  # Create a table to hold unique stacks
  var uniqueStacks = initTable[string, bool]()
  
  # Collect all unique stack values from the WrittenDocumentNode sequence
  for node in styles:
    case node.kind:
    of cssikPROPERTY:
      # Only add non-empty stacks
      if node.stack.len > 0:
        uniqueStacks[node.stack] = true
    of cssikRULE, cssikATRULE, cssikINLINE:
      # Handle other node types if they have stack information
      # (In the current implementation, these don't have stack values)
      discard
  
  # Build the class string
  var classNames: seq[string] = @[]
  for stack, _ in uniqueStacks:
    # echo "ADDING STACK TO CLASS 2: ", stack
    classNames.add(uuid & "_" & stack)
  
  # Join with spaces
  result = classNames.join(" ").strip()

import sets
proc computeClasses*(uuid: string, styles: Styles): string =
  var classNames: seq[string] = @[]
  var addedClasses: HashSet[string] = initHashSet[string]()
  
  # Add classes for each stack
  for stackHash, nodes in styles.stack:
    if nodes.len > 0:
      # Check if any node has a custom selector
      var hasCustomSelector = false
      
      for node in nodes:
        if node.selector.len > 0:
          # This has a custom selector
          hasCustomSelector = true
          
          # Extract the base class (without pseudo-selectors)
          var baseClass = node.selector
          
          # Remove pseudo-selectors
          let colonPos = baseClass.find(':')
          let bracketPos = baseClass.find('[')
          
          if colonPos >= 0 or bracketPos >= 0:
            let cutPos = if colonPos >= 0 and bracketPos >= 0: min(colonPos, bracketPos)
                         elif colonPos >= 0: colonPos
                         else: bracketPos
            baseClass = baseClass[0..<cutPos]
          
          # Add the base class if not already added
          if baseClass notin addedClasses:
            addedClasses.incl(baseClass)
            classNames.add(baseClass)
      
      # If no custom selector, add the default stack class
      if not hasCustomSelector:
        let defaultClass = uuid & "_" & stackHash
        if defaultClass notin addedClasses:
          addedClasses.incl(defaultClass)
          classNames.add(defaultClass)
  
  return classNames.join(" ").strip()

proc computeStyles*(uuid: string, body: NimNode): seq[WrittenDocumentNode] =
  # Parse the written document from the body
  let writtenDoc = parseWrittenDocument(body)
  # echo "WRITTEN DOC:"
  # echo writtenDoc.treeRepr

  var styles: seq[WrittenDocumentNode] = @[]
  
  # Variables to track parent rule context
  var currentRuleStack = ""
  var inRule = false

  # Process each node in the writtenDoc
  for docNode in writtenDoc:
    case docNode.kind:
    of cssikPROPERTY:
      let propName = docNode.property.name
      var propStack: seq[string] = @[]
      
      # If we're inside a rule, use the rule's stack as a base
      if inRule:
        propStack.add(currentRuleStack)
      
      # For mixed properties, add non-string literals to stack
      case docNode.property.body.kind:
      of pkPURE:
        # Pure string value - no additional stack items
        discard
      of pkMIXED:
        # Find the property in the AST
        let propertyNode = body.findNode(propName)
        if propertyNode != nil:
          # Extract variables and add to stack
          let nonStrLits = collectNonStrLitNodes(propertyNode)
          for expr in nonStrLits:
            propStack.add expr
        else:
          echo "Warning: Could not find property node for: ", propName
      
      # Calculate the stack hash for this property
      let stackHash = $fastHash(propStack.join(", "))
      
      # Store the node with updated stack in styles
      var propNode = WrittenDocumentNode(
        kind: cssikPROPERTY,
        property: docNode.property,
        stack: stackHash
      )
      styles.add propNode
      
    of cssikRULE:
      # Set rule context for nested properties
      inRule = true
      currentRuleStack = docNode.rule.selector
      
      # Add the rule itself to styles
      # styles.add docNode
      
      # For each property in the rule body

      var properties: seq[WrittenDocumentNode] = @[]
      for child in docNode.rule.body:
        if child.kind == cssikPROPERTY:
          var childStack: seq[string] = @[currentRuleStack]
          
          # Add variables for mixed properties
          case child.property.body.kind:
          of pkPURE:
            # Pure string value
            discard
          of pkMIXED:
            # Get variables for this property
            let propertyNode = body.findNode(child.property.name)
            if propertyNode != nil:
              let nonStrLits = collectNonStrLitNodes(propertyNode)
              for exprr in nonStrLits:
                childStack.add exprr
            
          let childStackHash = $fastHash(childStack.join(", "))
          # var childStackHash = docNode.rule.selector
          var selector = docNode.rule.selector

          echo "SELECTOR"
          echo selector
          echo "IS"
          echo isGlobalPseudoSelector(selector)

          # echo "Child stack: ", childStackHash
          if selector.startsWith(":") and not isGlobalPseudoSelector(selector):
            selector = uuid & "_" & childStackHash & selector
          # echo "Child stack hash: ", childStackHash

          # Create a node with updated stack
          var childNode = WrittenDocumentNode(
            kind: cssikPROPERTY,
            property: child.property,
            stack: childStackHash,
            selector: selector
          )
          styles.add childNode
      
      # Reset rule context
      inRule = false
      currentRuleStack = ""
      
    of cssikATRULE:
      # Process at-rule similar to rule but with additional name
      styles.add docNode
      
      # # For each property in the at-rule body
      # for child in docNode.atRule.body:
      #   if child.kind == cssikPROPERTY:
      #     var childStack: seq[string] = @[docNode.atRule.name & " " & docNode.atRule.selector]
          
      #     # Add variables for mixed properties
      #     case child.property.body.kind:
      #     of pkPURE:
      #       discard
      #     of pkMIXED:
      #       let propertyNode = body.findNode(child.property.name)
      #       if propertyNode != nil:
      #         let nonStrLits = collectNonStrLitNodes(propertyNode)
      #         for expr in nonStrLits:
      #           childStack.add expr
          
      #     let childStackHash = getMD5(childStack.join(", "))
          
      #     # Create a node with updated stack
      #     var childNode = WrittenDocumentNode(
      #       kind: cssikPROPERTY,
      #       property: child.property,
      #       stack: childStackHash
      #     )
      #     styles.add childNode
      
    of cssikINLINE:
      # Handle inline rules - typically just carry them through
      styles.add docNode
  
  # Return the computed styles
  return styles

proc computeRuntimeStackHash*(input: string): string =
  ## Public procedure for computing stack hashes at runtime
  ## This hides the MD5 implementation detail
  return $fastHash(input)

proc computeRuntimeStackHashWithContext*(context: seq[string], styleObjName: string, value: string): string =
  ## Public procedure for computing stack hashes with conditional context and style object name
  let combined = context.join(",") & "," & styleObjName & "," & value
  return $fastHash(combined)

proc computeRuntimeStackHashWithStyleObj*(styleObjName: string, value: string): string =
  ## Public procedure for computing stack hashes with just style object name
  let combined = styleObjName & "," & value
  return $fastHash(combined)

proc makeNodeString(node: NimNode): NimNode =
  # prefix with "$" unless its:
  const DONT_PREFIX = {nnkIfStmt, nnkIfExpr}
  # echo "NODE KIND"
  # echo $node.kind
  if node.kind notin DONT_PREFIX:
    return nnkPrefix.newTree(ident("$"), node)
  return node

proc generateRuntimeStackfastHash(baseComponents: seq[string], styleObjName: string, body: NimNode): NimNode =
  ## Generate code that computes stack hash at runtime
  if baseComponents.len == 0:
    # Simple case: just hash the style object name + expression value
    return nnkCall.newTree(
      ident("computeRuntimeStackHashWithStyleObj"),
      newStrLitNode(styleObjName),
      makeNodeString(body)
    )
  else:
    # Complex case: include conditional context + style object name
    var contextArray = nnkBracket.newTree()
    for comp in baseComponents:
      contextArray.add(newStrLitNode(comp))
    
    return nnkCall.newTree(
      ident("computeRuntimeStackHashWithContext"),
      nnkPrefix.newTree(ident("@"), contextArray),
      newStrLitNode(styleObjName),
      makeNodeString(body)
    )

proc computeRuntimeStackHashWithInputContext*(inputStyleStacks: seq[string], styleObjName: string, value: string): string =
  ## Compute stack hash including existing stacks from input style parameter
  let combined = inputStyleStacks.join(",") & "," & styleObjName & "," & value
  return toHex(fastHash(combined))

proc computeRuntimeStackHashWithInputAndContext*(inputStyleStacks: seq[string], context: seq[string], styleObjName: string, value: string): string =
  ## Compute stack hash including existing stacks from input + conditional context
  let combined = inputStyleStacks.join(",") & "," & context.join(",") & "," & styleObjName & "," & value
  return $fastHash(combined)

proc computeStylesCode*(uuid: string, body: NimNode): tuple[styles: seq[WrittenDocumentNode], transformedBody: NimNode] =
  # Combined function that both collects styles and transforms the body
  proc loop(node: NimNode, lastStack: seq[string] = @[]): tuple[styles: seq[WrittenDocumentNode], transformedBody: NimNode] =
    var styles: seq[WrittenDocumentNode] = @[]
    var transformedBody = node.copyNimTree()
    
    const CONDITIONAL_KINDS = {nnkIfStmt, nnkElifBranch, nnkElse, nnkCaseStmt, nnkOfBranch, nnkWhenStmt, nnkTryStmt, nnkExceptBranch, nnkFinally, nnkForStmt, nnkWhileStmt}
    
    # Process if it's a statement list
    if node.kind == nnkStmtList:
      transformedBody = newNimNode(nnkStmtList)
      for i, child in node:
        let childResult = loop(child, lastStack)
        styles.add childResult.styles
        transformedBody.add childResult.transformedBody
      return (styles: styles, transformedBody: transformedBody)
    
    # Process conditional nodes
    if node.kind in CONDITIONAL_KINDS:
      let lessRepr = stmtLessRepr(node)
      
      var newStack = lastStack
      newStack.add lessRepr
      
      transformedBody = node.kind.newTree()
      for i in 0..<node.len:
        let childResult = loop(node[i], newStack)
        styles.add childResult.styles
        transformedBody.add childResult.transformedBody
      return (styles: styles, transformedBody: transformedBody)
    
    # Process the add call with colon expression (styles.add: ...)
    if node.kind == nnkCall and node.len >= 2 and 
       node[0].kind == nnkDotExpr and 
       node[0][1].strVal == "add" and
       node[1].kind == nnkStmtList:
      
      let stylesObj = node[0][0]
      let addBody = node[1]
      
      echo "I AM HERE"

      # Use computeStyles to compute styles from the body
      let computedStyles = computeStyles(uuid, addBody)

      # Process the styles based on current context stack
      var finalStyles: seq[WrittenDocumentNode] = @[]
      for style in computedStyles:
        if style.kind == cssikPROPERTY:
          var propStack = lastStack
          propStack.add(style.stack)
          let finalStackHash = $fastHash(propStack.join(", "))
          
          var modifiedStyle = style
          modifiedStyle.stack = finalStackHash
          finalStyles.add modifiedStyle
        else:
          finalStyles.add style
      
      styles.add finalStyles
      
      # Create the new statement list for all transformed nodes
      let addNode = node.copyNimTree()
      let addNodeBody = addNode[1]
      expectKind(addNodeBody, nnkStmtList)
      
      let parsedAddNode = parseWrittenDocument(addNodeBody)
      let newAddNode = nnkCall.newTree(
        addNode[0].copyNimTree(),
        nnkStmtList.newTree()
      )
      for item in parsedAddNode:
        if item.kind == cssikPROPERTY:
          var propertyBody: NimNode
          if item.property.body.kind == pkPURE:
            propertyBody = newStrLitNode(item.property.body.value)
          elif item.property.body.kind == pkMIXED:
            propertyBody = item.property.body.node.toNimNode()
          
          newAddNode[1].add(
            nnkCall.newTree(
              newStrLitNode(item.property.name),
              nnkStmtList.newTree(
                propertyBody
              )
            )
          )

      var newStmtList: NimNode
      if newAddNode[1].len != 0:
        newStmtList = nnkStmtList.newTree(newAddNode)
      else:
        newStmtList = nnkStmtList.newTree()

      # For each computed style, create an addStack call
      for style in finalStyles:
        if style.kind == cssikPROPERTY:
          let stackHash = style.stack
          
          # Include the base class for pseudo-selectors
          if style.selector.len > 0 and (":" in style.selector or "[" in style.selector):
            # This ensures the base class is added to the element
            var baseClass = style.selector
            let pseudoPos = max(baseClass.find(':'), baseClass.find('['))
            if pseudoPos > 0:
              baseClass = baseClass[0..<pseudoPos]

          echo "LIFTING"
          echo style.repr
          let liftedNode = lift[WrittenDocumentNode](style)
          
          var addStackCall = nnkCall.newTree(
            nnkDotExpr.newTree(
              stylesObj,
              ident("addStack")
            ),
            newStrLitNode(stackHash),
            liftedNode,
          )
          
          # Add this call to our statement list
          newStmtList.add(addStackCall)
      
      # Return the transformed node - a statement list of all the addStack calls
      transformedBody = newStmtList
      return (styles: styles, transformedBody: transformedBody)
    
    # Process property assignments
    if node.kind == nnkAsgn and node[0].kind == nnkDotExpr:
      let repr = node.repr
      let leftSide = repr.split(" = ")[0]
      let name = camelToKebabCase(repr.split(" = ")[0].split(".")[^1].strip())
      
      # TODO: this does not work for, something.something.styles.opacity = "0.5"

      if name in properties and not leftSide.contains("("):
        var stack: seq[string] = lastStack
        let bodyExpr = node[1]
        
        # Get the style object name
        if node[0].repr.split(".")[^2] != "direct":
          
          let styleObjectName = node[0][0].strVal  # e.g., "styles"
          
          stack.add(styleObjectName)
          
          # extract partial variables
          let accQuoted = getAccQuoted(bodyExpr)
          for acc in accQuoted:
            stack.add acc.repr
            
          # For non-string literals, add them to the stack
          let nonStrLits = collectNonStrLitNodes(bodyExpr)
          for expr in nonStrLits:
            stack.add expr
          
          # Determine if this is a pure or mixed property
          let propertyKind = if bodyExpr.kind in {nnkStrLit..nnkTripleStrLit}: pkPURE else: pkMIXED
          
          case propertyKind:
          of pkPURE:
            # Static property - but we need to include input style context at runtime
            # Generate a call that includes the existing stacks from the input style
            
            let hashIdent = ident("stackHash")
            transformedBody = nnkStmtList.newTree(
              transformedBody.copyNimTree(),
              nnkBlockStmt.newTree(
                newEmptyNode(),
                nnkStmtList.newTree(
                  nnkLetSection.newTree(
                    nnkIdentDefs.newTree(
                      hashIdent,
                      newEmptyNode(),
                      # Runtime computation that includes existing input style stacks
                      nnkCall.newTree(
                        ident("computeRuntimeStackHashWithInputContext"),
                        nnkCall.newTree(
                          ident("toSeq"),
                          nnkDotExpr.newTree(
                            nnkDotExpr.newTree(
                              node[0][0],
                              ident("stack")
                            ),
                            ident("keys")
                          )
                        ),
                        newStrLitNode(styleObjectName),
                        bodyExpr
                      )
                    )
                  ),
                  nnkCall.newTree(
                    nnkDotExpr.newTree(
                      node[0][0],
                      ident("addStack")
                    ),
                    hashIdent,
                    nnkObjConstr.newTree(
                      ident("WrittenDocumentNode"),
                      nnkExprColonExpr.newTree(ident("kind"), ident("cssikPROPERTY")),
                      nnkExprColonExpr.newTree(ident("stack"), 
                        hashIdent
                      ),
                      nnkExprColonExpr.newTree(ident("selector"), newStrLitNode("")),
                      nnkExprColonExpr.newTree(
                        ident("property"),
                        nnkObjConstr.newTree(
                          ident("WrittenProperty"),
                          nnkExprColonExpr.newTree(ident("name"), newStrLitNode(name)),
                          nnkExprColonExpr.newTree(
                            ident("body"),
                            nnkObjConstr.newTree(
                              ident("WrittenPropertyBody"),
                              nnkExprColonExpr.newTree(ident("kind"), ident("pkPURE")),
                              nnkExprColonExpr.newTree(ident("value"), bodyExpr)
                            )
                          )
                        )
                      )
                    )
                  )
                )
              )
            )
            
            # For compile-time tracking, use a placeholder hash
            let placeholderStackHash = "RUNTIME_INPUT_" & $fastHash(stack.join(", "))
            
            let property = WrittenProperty(
              name: name,
              body: WrittenPropertyBody(kind: pkPURE, value: bodyExpr.strVal)
            )
            
            let docNode = WrittenDocumentNode(
              kind: cssikPROPERTY,
              property: property,
              stack: placeholderStackHash
            )
            styles.add docNode
            
          of pkMIXED:
            # Dynamic property - compute stack at runtime including input context
            
            # Generate runtime stack computation that includes existing input stacks
            var runtimeStackExpr: NimNode
            if lastStack.len == 0:
              # Just include input stacks + style object + expression
              runtimeStackExpr = nnkCall.newTree(
                ident("computeRuntimeStackHashWithInputContext"),
                nnkCall.newTree(
                  ident("toSeq"),
                  nnkDotExpr.newTree(
                    nnkDotExpr.newTree(
                      node[0][0],
                      ident("stack")
                    ),
                    ident("keys")
                  )
                ),
                newStrLitNode(styleObjectName),
                makeNodeString(bodyExpr)
              )
            else:
              # Include conditional context + input stacks + style object + expression
              var contextArray = nnkBracket.newTree()
              for comp in lastStack:
                contextArray.add(newStrLitNode(comp))
              
              runtimeStackExpr = nnkCall.newTree(
                ident("computeRuntimeStackHashWithInputAndContext"),
                nnkCall.newTree(
                  ident("toSeq"),
                  nnkDotExpr.newTree(
                    nnkDotExpr.newTree(
                      node[0][0],
                      ident("stack")
                    ),
                    ident("keys")
                  )
                ),
                nnkPrefix.newTree(ident("@"), contextArray),
                newStrLitNode(styleObjectName),
                makeNodeString(bodyExpr)
              )
            
            # For tracking purposes, use a placeholder hash
            let placeholderStackHash = "RUNTIME_INPUT_" & $fastHash(stack.join(", "))
            
            let property = WrittenProperty(
              name: name,
              body: WrittenPropertyBody(kind: pkMIXED, node: bodyExpr.toSerializedNode)
            )
            
            let docNode = WrittenDocumentNode(
              kind: cssikPROPERTY,
              property: property,
              stack: placeholderStackHash
            )
            styles.add docNode
            
            # Generate dynamic addStack call
            transformedBody = nnkStmtList.newTree(
              transformedBody.copyNimTree(),
              nnkCall.newTree(
                nnkDotExpr.newTree(
                  node[0][0],
                  ident("addStack")
                ),
                runtimeStackExpr,  # Runtime-computed hash with input context
                nnkObjConstr.newTree(
                  ident("WrittenDocumentNode"),
                  nnkExprColonExpr.newTree(ident("kind"), ident("cssikPROPERTY")),
                  nnkExprColonExpr.newTree(ident("stack"), runtimeStackExpr),
                  nnkExprColonExpr.newTree(ident("selector"), newStrLitNode("")),
                  nnkExprColonExpr.newTree(
                    ident("property"),
                    nnkObjConstr.newTree(
                      ident("WrittenProperty"),
                      nnkExprColonExpr.newTree(ident("name"), newStrLitNode(name)),
                      nnkExprColonExpr.newTree(
                        ident("body"),
                        nnkObjConstr.newTree(
                          ident("WrittenPropertyBody"),
                          nnkExprColonExpr.newTree(ident("kind"), ident("pkPURE")),
                          nnkExprColonExpr.newTree(
                            ident("value"),
                            makeNodeString(bodyExpr)
                          )
                        )
                      )
                    )
                  )
                )
              )
            )
          
      else:
        hint "Unknown property: " & name
      
    return (styles: styles, transformedBody: transformedBody)

  # Apply the combined logic
  let loopResult = loop(body)
  var stylesList = loopResult.styles
  let transformedBody = loopResult.transformedBody
  
  # Process styles and group by stack (rest remains the same)
  var stackTable: Table[string, seq[WrittenDocumentNode]] = initTable[string, seq[WrittenDocumentNode]]()

  proc addNode(stackTable: var Table[string, seq[WrittenDocumentNode]], node: WrittenDocumentNode) =
    case node.kind:
    of cssikPROPERTY:
      if not stackTable.hasKey(node.stack):
        stackTable[node.stack] = @[]
      stackTable[node.stack].add node
    of cssikRULE, cssikATRULE, cssikINLINE:
      if not stackTable.hasKey(""):
        stackTable[""] = @[]
      stackTable[""].add node

  for node in stylesList:
    stackTable.addNode(node)

  var finalStyles: seq[WrittenDocumentNode] = @[]
  for stack, nodes in stackTable:
    if nodes.len > 0:
      var body: seq[WrittenDocumentNode] = @[]
      
      var targetSelector = ""
      var selector = "." & uuid & "_" & stack
      for node in nodes:
        if targetSelector.len == 0:
          targetSelector = node.selector
        if node.kind == cssikPROPERTY:
          body.add node
        else:
          finalStyles.add node
          continue
      if targetSelector.len > 0:
        selector = targetSelector

      if body.len > 0:
        finalStyles.add WrittenDocumentNode(
          kind: cssikRULE,
          rule: WrittenRule(
            selector: selector,
            body: body,
            nodeBody: newNimNode(nnkStmtList).toSerializedNode
          )
        )
  
  return (styles: finalStyles, transformedBody: transformedBody)

macro test(body: untyped): untyped =
  let (doc, newBody) = computeStylesCode("element", body)
  echo "Computed document: \n" & doc.toSource
  result = newBody
  
  echo "\nTransformed body: \n"
  echo newBody.repr

  


when isMainModule:
  test:
    var styles = newStyles()
    styles.add:
      opacity: 0.2
      margin: 10.px

    styles.add:
      [hover]:
        opacity: 0.5
      [active]:
        opacity: 0.8

      [_]:
        color: "red"

    echo computeClassesStr("element", styles)
    echo computeClasses("element", styles)


    # let fontSizeValue = "13px"
    # styles.fontSize = fontSizeValue

    # if true:
    #   styles.display = "flex"
    # else:
    #   styles.display = "block"
      # # Test rule
      # !test:
      #   padding: 5.px

      # @media (max-width: 600px):
      #   padding: 5.px
      #   # Dynamic property inside rule
      #   width: `screenWidth * 0.9`
        
    # echo $styles