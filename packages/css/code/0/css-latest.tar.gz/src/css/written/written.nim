import macros
import strutils


import types
export types

import util
export util

import selector
import ../util
import ../types
import ../core



import pkg/lifter
import pkg/jsony_plus/serialized_node

const DO_VALIDATE = false

proc parseWrittenRule*(selectorStr: string, selectorNode: NimNode, body: NimNode): WrittenRule
proc parseWrittenAtRule*(name: string, selectorStr: string, body: NimNode): WrittenAtRule

proc extractRuleSelectorAndBody(node: NimNode): tuple[selector: string, body: NimNode] =
  ## Extracts the CSS selector string and statement list from a CSS-like Nim AST
    
  var body = newStmtList()
    
  var newNode = node.kind.newNimNode()
    
  for child in node:
    if child.kind == nnkStmtList:
      body = child
    else:
      newNode.add child
      

  var selector = newNode.repr.replace(" - ", "-")
  # echo "SELECTOR: " & selector
  # if selector.endsWith("\"()"):
  #   selector = selector[1 .. ^4]
  if selector.endsWith("()"):
    selector = selector[0 .. ^3]
  if selector.startsWith("\"") and selector.endsWith("\""):
    selector = selector[1..^2]
  # echo "SELECTOR: " & selector
  if selector.startsWith("{") and selector.endsWith("}"):
    selector = selector[1..^2]

  let actualSelector = processWrittenSelector(selector)

  return (actualSelector, body)


proc parseWrittenPropertyBody*(body: NimNode, syntax: string = ""): WrittenPropertyBody =
  var valueStr = body.repr.strip().replaceUnits().replace("def (", "var(").replace("def (", "var(").replace("def(", "var(").replace("def (", "var(").replace("def(", "var(").replace("{", "").replace("}", "")
  if body.kind != nnkStrLit:
    valueStr = valueStr.replace(" - ", "-")

  if valueStr.contains("`"):
    
    var nodes: seq[NimNode] = @[]
    
    var str = ""
    var inside = false
    for ch in valueStr:
      if ch == '\n':
        continue
      if ch == '`':
        inside = not inside
        if inside:
          if str.len > 0:
            nodes.add newStrLitNode(str)
            str = ""
        else:
          if str.len > 0:
            nodes.add ident(str)
            str = ""
        continue
      
      str.add ch
    if str.len > 0:
      nodes.add newStrLitNode(str)


    if nodes.len == 0:
      raise newException(ValueError, "Invalid CSS value! Not enough nodes.")
    
    var node = nodes[0]
    if nodes.len >= 2:
      node = nnkInfix.newTree(
        ident("&"),
        node,
        nodes[1],
      )

    if nodes.len > 2:
      for i in 2 ..< nodes.len:
        node = nnkInfix.newTree(
          ident("&"),
          node,
          nodes[i],
        )

    
    return WrittenPropertyBody(kind: pkMIXED, node: node.toSerializedNode())
  else:
    # valueStr = valueStr.strip()
    # echo valueStr
    # echo body.treeRepr

    if valueStr.len >= 3 and valueStr[0] == '"' and valueStr[^1] == '"':
      valueStr = valueStr[1 .. ^2]

    if valueStr.startsWith("--") and not valueStr.contains(" "):
      valueStr = "var(" & valueStr & ")"
    
    # echo "VALUE STR"
    # echo valueStr

    # echo "Attempting \"" & valueStr & "\""
    # echo valueStr
    # echo valueStr

    var validateResponse = ValidatorResult(valid: true, errors: @[])
    if DO_VALIDATE and syntax != "":
      if syntax != "<declaration-value>":
        validateResponse = validateSyntaxValue(syntax, valueStr)
      let valid  = validateResponse.valid
      let errors = validateResponse.errors
      if not valid:
        let errorStr = errors.join("\n")
        hint "Invalid CSS value!\n" & errorStr, body
    
    if valueStr.startsWith("\n"):
      valueStr = valueStr[1..^1]

    return WrittenPropertyBody(kind: pkPURE, value: valueStr)
proc parseWrittenProperty*(node: NimNode): WrittenProperty =
  # echo node.treeRepr
  # echo node.treeRepr
  expectKind(node, {nnkCall, nnkInfix, nnkPrefix})
  
  var cssPropertyName: string
  var isVariable = false
  var propertyNodeBody: NimNode


  # echo node.treeRepr

  if node.kind == nnkCall:
    expectLen(node, 2)
    expectKind(node[0], {nnkStrLit, nnkIdent})
    expectKind(node[1], nnkStmtList)
    if node[0].kind == nnkStrLit:
      cssPropertyName = node[0].strVal
    elif node[0].kind == nnkIdent:
      let nimPropertyName = node[0].strVal
      cssPropertyName = toKebabCase(nimPropertyName)
    else:
      error "Expected a string literal or an identifier"
    propertyNodeBody = node[1]
  elif node.kind == nnkInfix:
    expectMinLen(node, 3)
    expectKind(node[^1], nnkStmtList)
    propertyNodeBody = node[^1]
    cssPropertyName = node[1].repr.replace(" - ", "-") & "-" & node[2].repr.replace(" - ", "-")
    isVariable = true
  elif node.kind == nnkPrefix:
    expectLen(node, 3)
    expectKind(node[^1], nnkStmtList)
    expectKind(node[0], nnkIdent)
    if node[0].strVal != "--":
      error "Expected a variable declaration starting with --"
    propertyNodeBody = node[^1]
    cssPropertyName = "--" & node[1].repr.replace(" - ", "-")
    isVariable = true
  else:
    error "Expected a call or infix node"


  if cssPropertyName.startsWith("WebKit"):
    cssPropertyName = "-webkit-" & cssPropertyName[6..^1]
  elif cssPropertyName.startsWith("Moz"):
    cssPropertyName = "-moz-" & cssPropertyName[3..^1]
  elif cssPropertyName.startsWith("Ms"):
    cssPropertyName = "-ms-" & cssPropertyName[2..^1]
  elif cssPropertyName.startsWith("webkit"):
    cssPropertyName = "-webkit-" & cssPropertyName[7..^1]
  elif cssPropertyName.startsWith("moz"):
    cssPropertyName = "-moz-" & cssPropertyName[3..^1]
  elif cssPropertyName.startsWith("ms"):
    cssPropertyName = "-ms-" & cssPropertyName[2..^1]
  elif cssPropertyName.startsWith("o-"):
    cssPropertyName = "-o-" & cssPropertyName[2..^1]

  # var syntax: string = "<declaration-value>"
  var syntax: string = ""
  if not isVariable:
    if cssPropertyName != "src":
      if not validatePropertyName(cssPropertyName).valid:
        error "Unknown CSS property name: " & cssPropertyName, node[0]
      syntax = getProperty(cssPropertyName).syntax


      # let bodyStr = parsePropertyBody(cssProp.get, propertyBody)
  let propertyBody = parseWrittenPropertyBody(propertyNodeBody, syntax)
  return WrittenProperty(name: cssPropertyName, body: propertyBody)
  # return WrittenProperty(name: cssPropertyName, body: WrittenPropertyBody(kind: pkPURE, value: propertyNodeBody.repr))

import options
proc parseWrittenNode*(node: NimNode): WrittenDocumentNode =
  
  # echo node.treeRepr
  
  proc getStmtList(node: NimNode): Option[NimNode] =
    for child in node:
      if child.kind == nnkStmtList:
        return some(child)
    return none(NimNode)

  var stmtList = getStmtList(node)
  if stmtList.isSome and stmtList.get.len == 1:
    if stmtList.get[0].getStmtList().isNone:
      stmtList = none(NimNode)

  var isProperty = stmtList.isNone
  # if isProperty and node[1].kind == nnkStmtList and node[1].len == 1 and node[1][0].kind == nnkCall:
  #  isProperty = false # is something like `body: { backgroundColor: "" }`
  # echo $isProperty

  # (node[1][0].kind != nnkCall and node[1][0].len != 2)
  var isInline = node.kind == nnkImportStmt


  # echo node.treeRepr
  # echo isProperty

    # echo "CSS HERE:"
    # echo node.treeRepr
    # echo isProperty

  if isInline:
    var content = node.repr
    if content.startsWith("import"):
      content = content.replace("import\n ", "@import")
    if content.endsWith("\n"):
      content = content[0..^2]
    content = content.strip()
    if content.endsWith(";"):
      content = content[0..^2]

    return WrittenDocumentNode(kind: cssikINLINE, content: content)
  else:
    if isProperty:
      return WrittenDocumentNode(kind: cssikPROPERTY, property: parseWrittenProperty(node))
    else:

      let (selectorStr, body) = extractRuleSelectorAndBody(node)
      # echo "SELECTOR STR: " & selectorStr
      if selectorStr.startsWith("@"):
        let atRuleName = selectorStr.split(" ")[0][1..^1]
        let atRuleSelector = selectorStr.split(" ")[1..^1].join(" ")
        return WrittenDocumentNode(kind: cssikATRULE, atRule: parseWrittenAtRule(atRuleName, atRuleSelector, body))
      else:
        return WrittenDocumentNode(kind: cssikRULE, rule: parseWrittenRule(selectorStr, node, body))

proc parseWrittenRuleBody*(body: NimNode): seq[WrittenDocumentNode] =
  for node in body:
    result.add parseWrittenNode(node)
proc parseWrittenRule*(selectorStr: string, selectorNode: NimNode, body: NimNode): WrittenRule =
  # let selectorValidation = isValidCSSSelector(selectorStr)
  # if not selectorValidation.valid:
    # let errorStr = selectorValidation.errors.join("\n")
    # error "Invalid CSS selector!\n" & errorStr, selectorNode
  
  let ruleBody = parseWrittenRuleBody(body)
  result = WrittenRule(selector: selectorStr, body: ruleBody, nodeBody: body.toSerializedNode())
proc parseWrittenAtRule*(name: string, selectorStr: string, body: NimNode): WrittenAtRule =
  # let selectorValidation = isValidCSSSelector(selectorStr)
  # if not selectorValidation.valid:
    # let errorStr = selectorValidation.errors.join("\n")
    # error "Invalid CSS selector!\n" & errorStr, selectorNode
  
  let ruleBody = parseWrittenRuleBody(body)
  result = WrittenAtRule(name: name, selector: selectorStr, body: ruleBody, nodeBody: body.toSerializedNode())

proc parseWrittenDocument*(body: NimNode): WrittenDocument =
  # echo body.treeRepr
  for node in body:
    result.add parseWrittenNode(node)

proc split*(node: WrittenDocument): tuple[properties: seq[WrittenDocumentNode], rules: seq[WrittenDocumentNode]] =
  ## Converts a WrittenDocument to a tuple of properties and rules.
  var properties: seq[WrittenDocumentNode] = @[]
  var rules: seq[WrittenDocumentNode] = @[]
  for n in node:
    case n.kind:
    of cssikPROPERTY:
      properties.add n
    of cssikRULE, cssikATRULE, cssikINLINE:
      rules.add n
  return (properties, rules)


genLift(WrittenDocument)
macro css*(body: untyped): untyped =
  let document = parseWrittenDocument(body)
  # echo document
  result = lift(document)


when isMainModule:
  let doc = css:
    [root]:
      # Global non-theme Colors
      --action-rgb: {100, 134, 255}
      --red-rgb: {255, 101, 101}
      --hover-rgb: {144, 144, 144}
  
  echo $doc