# std
import macros
import strutils

# local
import types

# pkgs
import jsony_plus/serialized_node


const DO_VALIDATE = false


# Forward declarations for internal procedures with level parameter
proc stringRepr(prop: WrittenProperty, level: int): string {.gcsafe.}
proc stringRepr(rule: WrittenRule, level: int): string {.gcsafe.}
proc stringRepr(atRule: WrittenAtRule, level: int): string {.gcsafe.}
proc stringRepr(docNode: WrittenDocumentNode, level: int): string {.gcsafe.}

# Public string representation operators
proc toSource*(prop: WrittenProperty): string {.gcsafe.}
proc toSource*(rule: WrittenRule): string {.gcsafe.}
proc toSource*(atRule: WrittenAtRule): string {.gcsafe.}
proc toSource*(docNode: WrittenDocumentNode): string {.gcsafe.}
proc toSource*(doc: WrittenDocument): string {.gcsafe.}

proc indent(level: int): string =
  "  ".repeat(level)

# Internal implementations with indentation level
proc stringRepr(prop: WrittenProperty, level: int): string =
  result = indent(level)
  case prop.body.kind:
  of pkPURE:
    result.add prop.name & ": " & prop.body.value & ";\n"
  of pkMIXED:
    result.add prop.name & ": " & prop.body.node.repr & ";\n"

proc stringRepr(rule: WrittenRule, level: int): string =
  result = indent(level) & rule.selector & " {\n"
  for node in rule.body:
    result.add stringRepr(node, level + 1)
  result.add indent(level) & "}\n"

proc stringRepr(atRule: WrittenAtRule, level: int): string =
  result = indent(level) & "@" & atRule.name & " " & atRule.selector & " {\n"
  for node in atRule.body:
    result.add stringRepr(node, level + 1)
  result.add indent(level) & "}\n"

proc stringRepr(docNode: WrittenDocumentNode, level: int): string =
  case docNode.kind:
  of cssikPROPERTY:
    result = stringRepr(docNode.property, level)
  of cssikRULE:
    result = stringRepr(docNode.rule, level)
  of cssikATRULE:
    result = stringRepr(docNode.atRule, level)
  of cssikINLINE:
    var content = docNode.content.strip()
    if not content.endsWith(";"):
      content.add ";"
    result = indent(level) & content & "\n"

# Public string representation operators that use the internal implementations
proc toSource*(prop: WrittenProperty): string =
  stringRepr(prop, 0)

proc toSource*(rule: WrittenRule): string =
  stringRepr(rule, 0)

proc toSource*(atRule: WrittenAtRule): string =
  stringRepr(atRule, 0)

proc toSource*(docNode: WrittenDocumentNode): string =
  stringRepr(docNode, 0)

proc toSource*(doc: WrittenDocument): string =
  for node in doc:
    result.add stringRepr(node, 0)

when isMainModule:
  # construct document of inline then rule
  let inline = WrittenDocumentNode(
    kind: cssikINLINE,
    content: "@import 'styles.css'"
  )
  let rule = WrittenDocumentNode(
    kind: cssikRULE,
    rule: WrittenRule(
      selector: ".example",
      body: @[
        WrittenDocumentNode(
          kind: cssikPROPERTY,
          property: WrittenProperty(
            name: "color",
            body: WrittenPropertyBody(kind: pkPURE, value: "red")
          )
        )
      ]
    )
  )
  let doc = WrittenDocument(@[inline, rule])
  echo $doc



proc treeRepr*(node: WrittenDocumentNode, level: int = 0): string =
  ## Generate a readable tree representation of a WrittenDocumentNode
  result = indent(level)
  
  case node.kind:
  of cssikPROPERTY:
    result.add "PROPERTY " & node.property.name & ": "
    case node.property.body.kind:
    of pkPURE:
      result.add node.property.body.value
    of pkMIXED:
      result.add "MixedNode(" & $node.property.body.node.kind & ")"
  
  of cssikATRULE:
    result.add "AT-RULE " & node.atRule.name & " " & node.atRule.selector & " {\n"
    for child in node.atRule.body:
      result.add treeRepr(child, level + 1) & "\n"
    result.add indent(level) & "}"

  of cssikRULE:
    result.add "RULE " & node.rule.selector & " {\n"
    for child in node.rule.body:
      result.add treeRepr(child, level + 1) & "\n"
    result.add indent(level) & "}"
    # Add nodeBody representation if needed
    # if node.rule.nodeBody.kind != SerializedNode.default.kind:
    #   result.add " <nodeBody: " & $node.rule.nodeBody.kind & ">"
  
  of cssikINLINE:
    result.add "INLINE " & node.content

proc treeRepr*(document: WrittenDocument, level: int = 0): string =
  ## Generate a readable tree representation of a WrittenDocument
  result = indent(level) & "CSS DOCUMENT:\n"
  for node in document:
    result.add treeRepr(node, level + 1) & "\n"


# Forward declarations
# proc toNimNode*(prop: WrittenProperty): NimNode {.gcsafe.}
proc toNimNode*(rule: WrittenRule): NimNode {.gcsafe.}
proc toNimNode*(atRule: WrittenAtRule): NimNode {.gcsafe.}
proc toNimNode*(docNode: WrittenDocumentNode): NimNode {.gcsafe.}
proc toNimNode*(doc: WrittenDocument): tuple[styleContent: NimNode, inlineStyles: seq[NimNode]] {.gcsafe.}

proc propertyToNimNode(property: WrittenProperty): NimNode =
  ## Converts a property to NimNode representation
  if property.body.kind == pkPURE:
    result = newStrLitNode(property.name & ": " & property.body.value & "; ")
  else:
    result = nnkInfix.newTree(
      ident("&"),
      newStrLitNode(property.name & ": "),
      nnkInfix.newTree(
        ident("&"),
        nnkCall.newTree(
          ident("runtimeValidatePropertyValue"),
          newStrLitNode(property.name),
          property.body.node.toNimNode()
        ),
        newStrLitNode("; ")
      )
    )

proc propertyToInlineStyle(property: WrittenProperty): NimNode =
  ## Converts a property to inline style NimNode representation
  if property.body.kind == pkPURE:
    result = newStrLitNode(property.name & ": " & property.body.value)
  else:
    result = nnkInfix.newTree(
      ident("&"),
      newStrLitNode(property.name & ": "),
      nnkCall.newTree(
        ident("runtimeValidatePropertyValue"),
        newStrLitNode(property.name),
        property.body.node.toNimNode()
      )
    )

proc toNimNode*(rule: WrittenRule): NimNode =
  ## Converts a rule to NimNode representation
  result = newStrLitNode(rule.selector & " { ")
  
  for node in rule.body:
    case node.kind:
    of cssikPROPERTY:
      let propNode = propertyToNimNode(node.property)
      result = nnkInfix.newTree(ident("&"), result, propNode)
    of cssikRULE:
      # Handle nested rules
      let nestedRuleNode = node.rule.toNimNode()
      result = nnkInfix.newTree(ident("&"), result, nestedRuleNode)
    of cssikATRULE:
      # Handle at-rules within rules
      let atRuleNode = node.atRule.toNimNode()
      result = nnkInfix.newTree(ident("&"), result, atRuleNode)
    of cssikINLINE:
      result = nnkInfix.newTree(
        ident("&"), 
        result, 
        newStrLitNode(node.content & "; ")
      )
  
  result = nnkInfix.newTree(ident("&"), result, newStrLitNode("} "))

proc toNimNode*(atRule: WrittenAtRule): NimNode =
  ## Converts an at-rule to NimNode representation
  result = newStrLitNode("@" & atRule.name & " " & atRule.selector & " { ")
  
  for node in atRule.body:
    case node.kind:
    of cssikPROPERTY:
      let propNode = propertyToNimNode(node.property)
      result = nnkInfix.newTree(ident("&"), result, propNode)
    of cssikRULE:
      let ruleNode = node.rule.toNimNode()
      result = nnkInfix.newTree(ident("&"), result, ruleNode)
    of cssikATRULE:
      # Handle nested at-rules
      let nestedAtRuleNode = node.atRule.toNimNode()
      result = nnkInfix.newTree(ident("&"), result, nestedAtRuleNode)
    of cssikINLINE:
      result = nnkInfix.newTree(
        ident("&"), 
        result, 
        newStrLitNode(node.content & "; ")
      )
  
  result = nnkInfix.newTree(ident("&"), result, newStrLitNode("} "))

proc toNimNode*(docNode: WrittenDocumentNode): NimNode =
  ## Converts a document node to NimNode representation
  case docNode.kind:
  of cssikPROPERTY:
    result = propertyToNimNode(docNode.property)
  of cssikRULE:
    result = toNimNode(docNode.rule)
  of cssikATRULE:
    result = toNimNode(docNode.atRule)
  of cssikINLINE:
    result = newStrLitNode(docNode.content & "; ")

proc toNimNode*(doc: WrittenDocument): tuple[styleContent: NimNode, inlineStyles: seq[NimNode]] =
  ## Converts a WrittenDocument to a tuple of NimNodes for style content and inline styles
  var styleContent = newEmptyNode()
  var inlineStyles: seq[NimNode] = @[]
  
  var isFirstNode = true
  
  for node in doc:
    case node.kind:
    of cssikPROPERTY:
      # Root-level properties get added to inlineStyles
      inlineStyles.add(propertyToInlineStyle(node.property))
    of cssikRULE, cssikATRULE:
      let nodeContent = toNimNode(node)
      if isFirstNode:
        styleContent = nodeContent
        isFirstNode = false
      else:
        styleContent = nnkInfix.newTree(ident("&"), styleContent, nodeContent)
    of cssikINLINE:
      let content = newStrLitNode(node.content & "; ")
      if isFirstNode:
        styleContent = content
        isFirstNode = false
      else:
        styleContent = nnkInfix.newTree(ident("&"), styleContent, content)
  
  if styleContent.kind == nnkEmpty:
    styleContent = newStrLitNode("")
  
  result = (styleContent, inlineStyles)