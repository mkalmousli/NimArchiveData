import pkg/jsony_plus/serialized_node

type
  WrittenPropertyKind* = enum
    pkPURE
    pkMIXED
  
  WrittenPropertyBody* = ref object of RootObj
    case kind*: WrittenPropertyKind
    of pkPURE:
      value*: string
    of pkMIXED:
      node*: SerializedNode

  WrittenProperty* = ref object of RootObj
    name*: string
    body*: WrittenPropertyBody

  WrittenRule* = ref object of RootObj
    selector*: string
    body*: seq[WrittenDocumentNode]
    nodeBody*: SerializedNode

  WrittenAtRule* = ref object of RootObj
    name*: string
    selector*: string
    body*: seq[WrittenDocumentNode]
    nodeBody*: SerializedNode

  WrittenDocumentNodeKind* = enum
    cssikPROPERTY,  # a property at root level
    cssikRULE,      # a rule
    cssikATRULE,    # an at-rule
    cssikINLINE     # single line- non-property

  WrittenDocumentNode* = ref object of RootObj
    stack*: string
    selector*: string
    case kind*: WrittenDocumentNodeKind
    of cssikPROPERTY:
      property*: WrittenProperty
    of cssikRULE:
      rule*: WrittenRule
    of cssikATRULE:
      atRule*: WrittenAtRule
    of cssikINLINE:
      content*: string
      
  WrittenDocument* = seq[WrittenDocumentNode]