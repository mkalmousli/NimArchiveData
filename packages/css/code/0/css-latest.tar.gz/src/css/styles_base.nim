import macros
import strutils, tables

import util
import core
import types
import imports/imports

export tables
import ./written/written

import jsony_plus/serialized_node

const DO_VALIDATE = false

import lifter
genPrivateLift WrittenDocumentNode


macro makeStyles*(stylesName: untyped): untyped =
  let stylesIdent = stylesName
  # let directStylesName = ident($stylesName & "Direct")
  
  result = nnkStmtList.newTree(
    quote do:      
      type
        # `directStylesName` = distinct TableRef[string, string]
        `stylesIdent` = object
          properties*: TableRef[string, string]
          rules*: seq[WrittenDocumentNode]
          atRules*: seq[WrittenDocumentNode]
          inline*: seq[WrittenDocumentNode]
          # stack*: TableRef[string, seq[WrittenDocumentNode]]
          # direct*: `directStylesName`
      
      # iterator pairs*(direct: `directStylesName`): (string, string) {.borrow.}
  )

  # Generate property accessors for both Styles and DirectStyles
  for propertyName, propertyValue in properties:
    if propertyName == "--*":
      continue
  
    var name = propertyName.kebabToCamelCase
    var nameEqualsIdent = nnkAccQuoted.newTree(ident(name & "="))
    var nameIdent = ident(name)

    result.add quote do:
      # Styles property accessors
      proc `nameIdent`*(style: `stylesIdent`): string {.inline.} =
        if style.properties.hasKey(`propertyName`):
          return style.properties[`propertyName`]
        return ""

      macro `nameIdent`*(style: var `stylesIdent`, value: untyped): untyped =
        result = nnkCommand.newTree(
          nnkDotExpr.newTree(
            style,
            ident("setProperty")
          ),
          newStrLitNode(`propertyName`),
          value
        )

      macro `nameEqualsIdent`*(style: var `stylesIdent`, value: untyped): untyped =
        if value.kind == nnkStrLit:
          let validationResult = core.validatePropertyValue(`propertyName`, value.strVal)
          if not validationResult.valid:
            if DO_VALIDATE:
              error "Invalid value for " & `propertyName` & ": " & validationResult.errors.join("\n"), value
            else:
              hint "Invalid value for " & `propertyName` & ": " & validationResult.errors.join("\n"), value
          
          result = nnkAsgn.newTree(
            nnkBracketExpr.newTree(
              nnkDotExpr.newTree(
                style,
                ident("properties")
              ),
              newStrLitNode(`propertyName`)
            ),
            value
          )
        else:
          result = nnkAsgn.newTree(
            nnkBracketExpr.newTree(
              nnkDotExpr.newTree(
                style,
                ident("properties")
              ),
              newStrLitNode(`propertyName`)
            ),
            value
          )

      # # DirectStyles property accessors
      # proc `nameIdent`*(direct: `directStylesName`): string {.inline.} =
      #   let table = TableRef[string, string](direct)
      #   if table.hasKey(`propertyName`):
      #     return table[`propertyName`]
      #   return ""

      # proc `nameEqualsIdent`*(direct: var `directStylesName`, value: string) =
      #   TableRef[string, string](direct)[`propertyName`] = value
        
  # Global procedures and constructors
  let toStr = nnkAccQuoted.newTree(ident("$"))
  let equalsIdent = nnkAccQuoted.newTree(ident("[]="))
  let nonEqualsIdent = nnkAccQuoted.newTree(ident("[]"))
  let newStylesName = ident("new" & $stylesName)
  # let newDirectStylesName = ident("new" & $stylesName & "DirectStyles")
  
  result.add quote do:
    # Constructors
    proc `newStylesName`*(): `stylesIdent` =
      return `stylesIdent`(
        properties: new(TableRef[string, string]),
        # stack: new(TableRef[string, seq[WrittenDocumentNode]]),
        # direct: `directStylesName`(new(TableRef[string, string]))
      )

    # proc `newDirectStylesName`*(): `directStylesName` =
    #   result = `directStylesName`(new(TableRef[string, string]))

    # String representations
    proc `toStr`*(styles: `stylesIdent`): string =
      for key, value in styles.properties:
        result.add key & ": " & value & "; "
      if result.len > 0:
        return result[0..^3]  # Remove trailing "; "
      return ""

    # # DirectStyles operations - define explicitly instead of borrowing
    # proc hasKey*(direct: `directStylesName`, key: string): bool =
    #   TableRef[string, string](direct).hasKey(key)
    
    # proc `equalsIdent`*(direct: `directStylesName`, key: string, value: string) =
    #   TableRef[string, string](direct)[key] = value
    
    # proc `nonEqualsIdent`*(direct: `directStylesName`, key: string): string =
    #   TableRef[string, string](direct)[key]
    
    # proc len*(direct: `directStylesName`): int =
    #   TableRef[string, string](direct).len
    
    # iterator pairs*(direct: `directStylesName`): (string, string) =
    #   for key, value in TableRef[string, string](direct):
    #     yield (key, value)

    # proc `toStr`*(direct: `directStylesName`): string =
    #   for key, value in direct:
    #     result.add key & ": " & value & "; "
    #   if result.len > 0:
    #     return result[0..^3]  # Remove trailing "; "
    #   return ""



    # # Then your procs become much simpler:
    # proc `toStr`*(direct: `directStylesName`): string =
    #   for key, value in direct:
    #     result.add key & ": " & value & "; "
    #   if result.len > 0:
    #     return result[0..^3]  # Remove trailing "; "
    #   return ""

    # proc `equalsIdent`*(direct: `directStylesName`, key, value: string) =
    #   direct[key] = value

    # proc `nonEqualsIdent`*(direct: `directStylesName`, key: string): string =
    #   direct[key]


    # Styles operations
    proc setProperty*(style: var `stylesIdent`, key: string, value: string) =
      style.properties[key] = value

    macro setProperty*(style: var `stylesIdent`, key: string, value: untyped): untyped =
      var valueStr = value.repr
      if value.kind == nnkStrLit:
        valueStr = value.strVal
      
      var isPure = true
      if valueStr.contains("`"):
        isPure = false
      
      if not isPure:
        var node: NimNode = newEmptyNode()
        var str = ""
        var isInside = false
        for i, c in value.repr:
          if c == '`':
            if isInside:
              isInside = false
              if node.kind == nnkEmpty:
                node = ident(str)
              else:
                node = nnkInfix.newTree(
                  ident("&"),
                  node,
                  ident(str)
                )
              str = ""
            else:
              isInside = true
              if node.kind == nnkEmpty:
                node = newStrLitNode(str)
              else:
                node = nnkInfix.newTree(
                  ident("&"),
                  node,
                  newStrLitNode(str.replaceUnits())
                )
              str = ""
          else:
            str.add c
          
        result = nnkAsgn.newTree(
          nnkBracketExpr.newTree(
            nnkDotExpr.newTree(
              style,
              ident("properties")
            ),
            key
          ),
          node
        )
      else:
        valueStr = valueStr.replaceUnits()
        
        let validationResult = core.validatePropertyValue(key.strVal, valueStr)
        if not validationResult.valid:
          if DO_VALIDATE:
            error "Invalid value for " & key.strVal & ": " & validationResult.errors.join("\n"), value
          else:
            hint "Invalid value for " & key.strVal & ": " & validationResult.errors.join("\n"), value
        
        result = nnkAsgn.newTree(
          nnkBracketExpr.newTree(
            nnkDotExpr.newTree(
              style,
              ident("properties")
            ),
            key
          ),
          newStrLitNode(valueStr)
        )

    proc hasProperty*(style: `stylesIdent`, key: string): bool {.inline.} =
      return style.properties.hasKey(key)

    
    proc toConstr(node: WrittenDocumentNode): NimNode
    proc toConstr(prop: WrittenProperty): NimNode
    proc toConstr(rule: WrittenRule): NimNode
    proc toConstr(atRule: WrittenAtRule): NimNode

    proc toConstr(prop: WrittenProperty): NimNode =
      var value: NimNode
      if prop.body.kind == pkPURE:
        value = newStrLitNode(prop.body.value)
      else:
        value = prop.body.node.toNimNode()
      result = nnkObjConstr.newTree(
        ident("WrittenProperty"),
        nnkExprColonExpr.newTree(
          ident("name"),
          newStrLitNode(prop.name)
        ),
        nnkExprColonExpr.newTree(
          ident("body"),
          nnkObjConstr.newTree(
            ident("WrittenPropertyBody"),
            nnkExprColonExpr.newTree(
              ident("kind"),
              ident("pkPURE")
            ),
            nnkExprColonExpr.newTree(
              ident("value"),
              value
            )
          )
        )
      )
    proc toConstr(rule: WrittenRule): NimNode =
      var body: NimNode = nnkPrefix.newTree(
        ident("@"),
        nnkBracket.newTree()
      )
      for node in rule.body:
        body[1].add node.toConstr()
      result = nnkObjConstr.newTree(
        ident("WrittenRule"),
        nnkExprColonExpr.newTree(
          ident("selector"),
          newStrLitNode(rule.selector)
        ),
        nnkExprColonExpr.newTree(
          ident("body"),
          body
        )
      )
    proc toConstr(atRule: WrittenAtRule): NimNode =
      var body: NimNode = nnkPrefix.newTree(
        ident("@"),
        nnkBracket.newTree()
      )
      for node in atRule.body:
        body[1].add node.toConstr()
      result = nnkObjConstr.newTree(
        ident("WrittenAtRule"),
        nnkExprColonExpr.newTree(
          ident("name"),
          newStrLitNode(atRule.name)
        ),
        nnkExprColonExpr.newTree(
          ident("selector"),
          newStrLitNode(atRule.selector)
        ),
        nnkExprColonExpr.newTree(
          ident("body"),
          body
        )
      )
    proc toConstr(node: WrittenDocumentNode): NimNode =
      result = nnkObjConstr.newTree(
        ident("WrittenDocumentNode"),
        nnkExprColonExpr.newTree(
          ident("selector"),
          newStrLitNode(node.selector)
        )
      )
      case node.kind:
      of cssikPROPERTY:
        result.add nnkExprColonExpr.newTree(
          ident("kind"),
          ident("cssikPROPERTY")
        )
        result.add nnkExprColonExpr.newTree(
          ident("property"),
          node.property.toConstr()
        )
      of cssikRULE:
        result.add nnkExprColonExpr.newTree(
          ident("kind"),
          ident("cssikRULE")
        )
        result.add nnkExprColonExpr.newTree(
          ident("rule"),
          node.rule.toConstr()
        )
      of cssikATRULE:
        result.add nnkExprColonExpr.newTree(
          ident("kind"),
          ident("cssikATRULE")
        )
        result.add nnkExprColonExpr.newTree(
          ident("atRule"),
          node.atRule.toConstr()
        )
      of cssikINLINE:
        result.add nnkExprColonExpr.newTree(
          ident("kind"),
          ident("cssikINLINE")
        )
        result.add nnkExprColonExpr.newTree(
          ident("content"),
          newStrLitNode(node.content)
        )


    # proc addStack*(styles: var `stylesIdent`, stackHash: string, node: WrittenDocumentNode) = 
    #   styles.stack.mgetOrPut(stackHash, newSeq[WrittenDocumentNode]()).add(node)

    # CSS-like macro for Styles
    macro add*(styles: var `stylesIdent`, body: untyped): untyped =
      if body.kind != nnkStmtList:
        error "Expecting a statement list", body
      
      result = nnkStmtList.newNimNode()
      let doc = parseWrittenDocument(body)
      
      for docNode in doc:
        case docNode.kind:
        of cssikPROPERTY:
          let property = docNode.property
          let body = docNode.property.body
          let name = property.name
          
          if body.kind == pkPURE:
            let content = body.value
            # result.add quote do:
            #   `styles`.setProperty(`name`, `content`) 
            result.add nnkCall.newTree(
              nnkDotExpr.newTree(
                styles,
                ident("setProperty")
              ),
              newStrLitNode(name),
              newStrLitNode(content)
            )
          else:
            let content = body.node
            result.add nnkCall.newTree(
              nnkDotExpr.newTree(
                styles,
                ident("setProperty")
              ),
              newStrLitNode(name),
              content.toNimNode()
            )
        of cssikRULE:
          # ensure rule only starts with pseudo selector- otherwise its invalid in this configuration
          # if not docNode.rule.selector.startsWith(":"):
          #   raise newException(ValueError, "Invalid CSS rule selector: " & docNode.rule.selector)
          result.add nnkCall.newTree(
            nnkDotExpr.newTree(
              nnkDotExpr.newTree(
                styles,
                ident("rules")
              ),
              ident("add")
            ),
            docNode.toConstr()
          )
        of cssikATRULE:
          result.add nnkCall.newTree(
            nnkDotExpr.newTree(
              nnkDotExpr.newTree(
                styles,
                ident("rules")
              ),
              ident("add")
            ),
            docNode.toConstr()
          )
        of cssikINLINE:
          result.add nnkCall.newTree(
            nnkDotExpr.newTree(
              nnkDotExpr.newTree(
                styles,
                ident("inline")
              ),
              ident("add")
            ),
            docNode.toConstr()
          )
        else:
          raise newException(ValueError, "Invalid CSS document! " & $docNode.kind & " is not supported in a Styles object.\n\n" & $docNode.repr)
        
    # # CSS-like macro for DirectStyles
    # macro add*(direct: var `directStylesName`, body: untyped): untyped =
    #   if body.kind != nnkStmtList:
    #     error "Expecting a statement list", body
      
    #   result = nnkStmtList.newNimNode()
    #   let doc = parseWrittenDocument(body)
      
    #   for docNode in doc:
    #     case docNode.kind:
    #     of cssikPROPERTY:
    #       let property = docNode.property
    #       let body = docNode.property.body
    #       let name = property.name
          
    #       if body.kind == pkPURE:
    #         let content = body.value
    #         # Change Table to TableRef
    #         result.add nnkAsgn.newTree(
    #           nnkBracketExpr.newTree(
    #             nnkCall.newTree(
    #               nnkBracketExpr.newTree(
    #                 ident("TableRef"),  # Changed from "Table"
    #                 ident("string"),
    #                 ident("string")
    #               ),
    #               direct
    #             ),
    #             newStrLitNode(name)
    #           ),
    #           newStrLitNode(content)
    #         )
            
    #       else:
    #         let content = body.node
    #         # Change Table to TableRef
    #         result.add nnkAsgn.newTree(
    #           nnkBracketExpr.newTree(
    #             nnkCall.newTree(
    #               nnkBracketExpr.newTree(
    #                 ident("TableRef"),  # Changed from "Table"
    #                 ident("string"),
    #                 ident("string")
    #               ),
    #               direct
    #             ),
    #             newStrLitNode(name)
    #           ),
    #           content.toNimNode()
    #         )
    #     else:
    #       raise newException(ValueError, "Invalid CSS document! " & $docNode.kind & " is not supported.")

# Generate the types and procedures
makeStyles Styles

# Export the main types
export Styles

# Test code
when isMainModule:
  var styles = newStyles()
  styles.display = "flex"

  let something = "orange"

  styles.add:
    opacity: 0.2

    [hover]:
      color: `something`

  # styles.direct.add:
  #   color: "red"
  
  # styles.direct.opacity = "0.5"

  # styles.direct.add:
  #   background: "blue"

  echo "Styles: ", $styles
  echo "Rules: " & styles.rules.repr