import strutils, os, times

import ../src/css
import ../src/css/analyzer/value_parser

import pkg/colors

const SHOW_ERRORS = false
const MAX_ERRORS = 10

# Safe, simple nil detector that won't crash
proc safeCheckNil(vt: ptr ValueToken, path: string = "root"): seq[string] =
  var result: seq[string] = @[]
  
  if vt == nil:
    result.add(path & " = nil")
    return result
  
  # Check children
  for i in 0..<vt[].children.len:
    let child = vt[].children[i]
    if child == nil:
      result.add(path & ".children[" & $i & "] = nil")
    else:
      # We don't recursively check children to avoid potential crashes
      discard
  
  # Check body for rules
  if vt[].kind in {vtkAtRule, vtkRule}:
    for i in 0..<vt[].body.len:
      let item = vt[].body[i]
      if item == nil:
        result.add(path & ".body[" & $i & "] = nil")
  
  return result

proc testFile(path: string) =
  if not fileExists(path):
    raise newException(Exception, "File not found: " & path)
  let content = readFile(path)

  echo "\nTesting: " & path
  let startTime = getTime()
  let pool = newTokenPool(10000)
  let tokens = tokenizeValueFast(pool, content)
  echo "Tokenized in: " & $(getTime() - startTime)

  # echo "Checking nil"
  # for i in 0..<tokens.len:
  #   try:
  #     # First just check if the token itself is nil
  #     if i >= tokens.len:
  #       echo "Index out of bounds: ", i
  #       continue
        
  #     let token = tokens[i]
  #     if token == nil:
  #       echo "Token[", i, "] is nil"
  #       continue
        
  #     # Now check its basic properties
  #     echo "Token[", i, "] kind: ", token[].kind, ", value: ", token[].value
      
  #     # Check for nil pointers in children/body
  #     let nilErrors = safeCheckNil(token, "tokens[" & $i & "]")
  #     if nilErrors.len > 0:
  #       echo "  Nil pointers found:"
  #       for err in nilErrors:
  #         echo "    ", err
          
  #   except:
  #     echo "Error processing token[", i, "]"

  var count = 00
  var errorCount = 0
  
  echo "HERE"
  # echo tokens.repr
  echo "DONE"

  let startValidateTime = getTime()
  let validation = validateCSS(tokens, allowProperties = false, allowRules = true)
  echo "Validated in: " & $(getTime() - startValidateTime)
  for error in validation.errors:
    if SHOW_ERRORS:
      if errorCount >= MAX_ERRORS:
        echo "\nMax errors reached.".red
        break
    count.inc
    errorCount.inc()
    if SHOW_ERRORS:
      echo "  Errors: ".red
      for error in validation.errors:
        if error.message.contains("Invalid property name"):
          echo "    - " & error.message.bgRed
        else:
          echo "    - " & error.message

  echo "Total error count: " & $count
  if SHOW_ERRORS:
    echo "Error count: " & $errorCount & " / " & $MAX_ERRORS & " max"
  
  echo "Finished in: " & $(getTime() - startTime)

# current: 31-33ms

when isMainModule:
  # if paramCount() != 1:
  #   echo "Usage: css <file.css>"
  #   quit(1)
  # let filePath = paramStr(1)
  # if not fileExists(filePath):
  #   echo "File not found: " & filePath
  #   quit(1)
  # echo "Testing..."
  # testFile(filePath)

  testFile("./tests/data/bootstrap.css")
  # testSingle("background-color", "rgba(1,2,3 / 0.5)")
  # testFile("./tests/data/bootstrap-utilities.css")
  # testFile("./tests/data/bootstrap-reboot.css")
  # testFile("./tests/data/bootstrap-grid.css")

  # testFile("./tests/data/foundation.css")