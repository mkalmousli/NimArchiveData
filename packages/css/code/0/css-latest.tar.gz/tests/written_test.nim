import ../src/css

when isMainModule:
  let doc = css:
    @keyframes test:
      to:
        color: red
  
  echo doc.treeRepr
  echo $doc