# Package

version       = "0.1.68"
author        = "savannt"
description   = "CSS parser and validator"
license       = "MIT"
srcDir        = "src"


# Dependencies

requires "nim >= 1.0.0"
requires "lifter >= 0.1.0"












































