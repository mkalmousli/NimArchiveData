import indexes

export indexes

const reserved_records* = [
  "ACTI", "ALCH", "APPA", "ARMO", "BODY", "BOOK", "BSGN", "CELL", "CLAS", "CLOT", "CONT", "CREA", "DIAL", "DOOR", "ENCH",
  "FACT", "GLOB", "GMST", "INFO", "INGR", "LAND", "LEVC", "LEVI", "LIGH", "LOCK", "LTEX", "MGEF", "MISC", "NPC_", "PGRD",
  "PROB", "RACE", "REGN", "REPA", "SCPT", "SKIL", "SNDG", "SOUN", "SPEL", "SSCR", "STAT", "TES3", "WEAP"
]

type
  ParseError* = object of Exception

type
  # === Base object : all main records inherit from it ===
  MWRecordHeader* = object
    name*  : string # formally 'array[4, char]', but it's not particularly practical
    size*  : uint32
    dummy* : uint32
    flags* : uint32
  MWRecordData* = object of RootObj
    size* : int # formally uint32, but is parsed into 'int' by 'getLength'
  MWRecord* = object of RootObj
    header*   : MWRecordHeader
    deleted*  : bool
    disabled* : bool
    blocked*  : bool
    persrf*   : bool # persistent reference

  # === Records & subrecords ===
  MWClothData* = object of MWRecordData
    kind*   : uint32  # type (please refer to `MWClothType` enum in -indexes.nim-)
    weight* : float32 # weight
    value*  : uint16  # value
    ench*   : uint16  # enchantment points
  MWClothObj* = object of MWRecordData
    #[ TODO: Is this a struct with `mname/fname`, or are those separate? Ref: https://en.uesp.net/wiki/Morrowind_Mod:Mod_File_Format/CLOT ]#
    biped* : uint8       # biped object (please refer to `MWBipedType` enum in -indexes.nim-)
    mname* : string = "" # male name for cloth (optional)
    fname* : string = "" # female name for cloth (optional, `mname` used if absent)
  MWCloth* = object of MWRecord
    id*     : string          # ID
    model*  : string          # model name
    name*   : string = ""     # name (optional)
    script* : string = ""     # script name (optional)
    enchnm* : string = ""     # enchantment name (optional)
    icon*   : string = ""     # icon name (optional)
    data*   : MWClothData
    objs*   : seq[MWClothObj] # objects (repeatable)
  MWMiscData* = object of MWRecordData
    weight* : float32 # weight
    value*  : uint32  # value
    unkn*   : uint32  # unknown field, only uses 0 and 1, but usually unused
  MWMisc* = object of MWRecord
    id*     : string      # ID
    model*  : string      # model name
    name*   : string = "" # name (optional)
    script* : string = "" # script name (optional)
    icon*   : string = "" # icon name (optional)
    data*   : MWMiscData
  MWStatic* = object of MWRecord
    id*    : string # ID
    model* : string # model name
  MWContainerObject* = object of MWRecordData
    name*  : array[32, char]
    count* : int32
  MWContainer* = object of MWRecord
    id*       : string      # ID
    model*    : string      # model name
    name*     : string = "" # name (optional)
    script*   : string = "" # script name (optional)
    weight*   : float32
    flags*    : uint32      # 0x1 = organic, 0x2 = respawns (organic only), 0x8 = unknown, always set
    contents* : seq[MWContainerObject]
  MWActivator* = object of MWRecord
    id*       : string      # ID
    model*    : string      # model name
    name*     : string = "" # name (optional)
    script*   : string = "" # script name (optional)
  MWLightData* = object of MWRecordData
    weight*   : float32
    value*    : uint32
    time*     : int32
    radius*   : uint32
    color*    : (uint8, uint8, uint8, uint8) # rgb(a)?
    flags*    : uint32
  MWLight* = object of MWRecord
    id*       : string      # ID
    model*    : string      # model name
    name*     : string = "" # name (optional)
    script*   : string = "" # script name (optional)
    sound*    : string = "" # sound name (optional)
    icon*     : string = "" # icon name (optional)
    data*     : MWLightData
  MWIngredientData* = object of MWRecordData
    weight*   : float32         # weight
    value*    : uint32          # value
    effindex* : array[4, int32] # effect indexes
    skill*    : array[4, int32] # skill IDs
    attr*     : array[4, int32] # attribute IDs
  MWIngredient* = object of MWRecord
    id*     : string      # ID
    model*  : string      # model name
    name*   : string = "" # name (optional)
    script* : string = "" # script name (optional)
    icon*   : string = "" # icon name (optional)
    data*   : MWIngredientData
  MWPotionData* = object of MWRecordData
    weight*   : float32
    value*    : uint32
    flags*    : uint32 # 0x1 = autocalc
  MWPotionEnch* = object of MWRecordData
    effindex* : uint16
    skill*    : int8   # skill affected (-1 if not applicable)
    attr*     : int8   # attribute affected (-1 if not applicable)
    range*    : uint32 # 0 = self, 1 = touch, 2 = target
    area*     : uint32
    duration* : uint32
    mmin*     : uint32 # magnitude min
    mmax*     : uint32 # magnitude max
  MWPotion* = object of MWRecord
    id*     : string      # ID
    model*  : string      # model name
    name*   : string = "" # name (optional)
    script* : string = "" # script name (optional)
    icon*   : string = "" # icon name (optional)
    data*   : MWPotionData
    ench*   : seq[MWPotionEnch]
  MWBookData* = object of MWRecordData
    weight* : float32 # weight
    value*  : uint32  # value
    flags*  : uint32  # if scroll or not
    skill*  : int32   # -1 if none
    ench*   : uint32  # enchantment points
  MWBook* = object of MWRecord
    id*     : string      # ID
    model*  : string      # model name
    name*   : string = "" # name (optional)
    script* : string = "" # script name (optional)
    enchnm* : string = "" # enchantment name (optional)
    text*   : string = "" # text contents (optional)
    icon*   : string = "" # icon name (optional)
    data*   : MWBookData
  MWLeveledItem* = object of MWRecord
    id*      : string      # ID
    flags*   : uint32      # flags (0x1 = Calculate for each item in count | 0x2 = Calculate from all levels <= PC's level)
    nchance* : uint8       # chance none?
    count*   : uint32 = 0  # count of following items (optional)
    items*   : seq[(string, uint16)] # (item name, PC level)
  MWDoor* = object of MWRecord
    id*       : string      # ID
    model*    : string      # model name
    name*     : string = "" # name (optional)
    script*   : string = "" # script name (optional)
    soundo*   : string = "" # sound name: open (optional)
    soundc*   : string = "" # sound name: close (optional)
  MWLandHeightData* = object of MWRecordData
    hoffset*  : float32
    hdata*    : array[65, array[65, int8]] # height data is not absolute values but uses differences between adjacent pixels
                                           # thus a pixel value of 0 means it has the same height as the last pixel
                                           # note that the Y-direction of the data is from the bottom up
    junk*     : array[3, uint8]
  MWLand* = object of MWRecord
    coord*    : (int32, int32)
    flags*    : uint32         # data types included; if the relevant bit isn't set, the related fields will not be loaded, even if present
                                 # 0x01 = Includes VNML, VHGT and WNAM
                                 # 0x02 = Includes VCLR
                                 # 0x04 = Includes VTEX
    vnormals* : array[65, array[65, (int8, int8, int8)]]    # (x, y, z); y-direction of the data is from the bottom up
    hgdata*   : MWLandHeightData                            # heights for terrain
    hgmap*    : array[9,  array[9, uint8]]                  # heights for map
    vcolors*  : array[65, array[65, (uint8, uint8, uint8)]] # doesn't contain alpha
    vtex*     : array[16, array[16, uint16]]
  MWLandTexture* = object of MWRecord
    id*       : string      # ID
    index*    : uint32      # although nominally a uint32, uint16s are used as indices in LAND records, so these are effectively restricted to uint16 values
    tex*      : string
  MWRegionSoundChances* = object of MWRecordData
    name*     : array[32, char]
    chance*   : uint8
  MWRegionWeatherChances* = object of MWRecordData
    clear*    : uint8
    cloudy*   : uint8
    foggy*    : uint8
    overcast* : uint8
    rain*     : uint8
    thunder*  : uint8
    ash*      : uint8
    blight*   : uint8
    snow*     : uint8 # Bloodmoon/Tribunal only, set to 0 if not available
    blizzard* : uint8 # Bloodmoon/Tribunal only, set to 0 if not available
  MWRegion* = object of MWRecord
    id*       : string                    # ID
    name*     : string                    # name
    weather*  : MWRegionWeatherChances
    sleep_cr* : string                    # sleep creature
    map_col*  : (uint8, uint8,            # map colour
                 uint8, uint8)
    sound_ch* : seq[MWRegionSoundChances] # sound chances
  MWRepairToolData* = object of MWRecordData
    weight*   : float32
    value*    : uint32
    uses*     : uint32
    quality*  : float32
  MWRepairTool* = object of MWRecord
    id*       : string      # ID
    model*    : string      # model name
    name*     : string = "" # name (optional)
    script*   : string = "" # script name (optional)
    icon*     : string = "" # icon name (optional)
    data*     : MWRepairToolData
  MWApparatusData* = object of MWRecordData
    kind*     : uint32 # type of apparatus (please refer to `MWApparatusType` enum in -indexes.nim-)
    quality*  : float32
    weight*   : float32
    value*    : uint32
  MWApparatus* = object of MWRecord
    id*       : string      # ID
    model*    : string = "" # model name (optional apparently)
    name*     : string = "" # name (optional)
    script*   : string = "" # script name (optional)
    icon*     : string = "" # icon name (optional)
    data*     : MWApparatusData
  MWLockData* = object of MWRecordData
    weight*   : float32
    value*    : uint32
    quality*  : float32
    uses*     : uint32
  MWLock* = object of MWRecord
    id*       : string      # ID
    model*    : string      # model name
    name*     : string = "" # name (optional)
    script*   : string = "" # script name (optional)
    icon*     : string = "" # icon name (optional)
    data*     : MWLockData
  MWProbeData* = object of MWRecordData
    weight*   : float32
    value*    : uint32
    quality*  : float32
    uses*     : uint32
  MWProbe* = object of MWRecord
    id*       : string      # ID
    model*    : string      # model name
    name*     : string = "" # name (optional)
    script*   : string = "" # script name (optional)
    icon*     : string = "" # icon name (optional)
    data*     : MWProbeData
  MWSkillData* = object of MWRecordData
    attr*     : uint32             # attribute
    spec*     : uint32             # specialisation
    usev*     : (float32, float32, # use values
                 float32, float32)
  MWSkill* = object of MWRecord
    index*    : uint32      # index
    descr*    : string = "" # description
    data*     : MWSkillData
  MWScriptHeader* = object of MWRecordData
    name*     : array[32, char]
    numshort* : uint32 # NumShorts
    numlong*  : uint32 # NumLongs
    numfloat* : uint32 # NumFloats
    size_sdt* : uint32 # ScriptDataSize (same as size of SCDT)
    size_lvr* : uint32 # LocalVarSize (same as size of SCVR)
  MWScriptVariables* = object of MWRecordData
    raw*    : string # raw string representation
    shorts* : seq[string]
    longs*  : seq[string]
    floats* : seq[string]
  MWScript* = object of MWRecord
    sheader*  : MWScriptHeader
    vars*     : MWScriptVariables # originally as string (reachable by vars.raw); length derived from header (size_lvr)
    cdata*    : seq[uint8]        # compiled script data; seq as it is derived from header (size_sdt)
    text*     : string
  MWGlobal* = object of MWRecord
    name*     : string
    ftype*    : char     # field type
    value*    : float32  # UESP:
    #[ All globals are stored as floats, regardless of their specified type
    This creates issues with rounding and a loss of precision when using very large positive or negative long values
    Be sure to convert the value to the specified type before using it
    Integer values like zero are often stored as very small float values, rather than a true zero value ]#
  MWStartScript* = object of MWRecord
    name* : string
    data* : string # ASCII digits of unknown meaning
  MWBodyData* = object of MWRecordData
    part*    : uint8 # body part
    vampire* : uint8
    flags*   : uint8 # 1 - female, 2 - playable
    pkind*   : uint8 # body part type
  MWBody* = object of MWRecord
    id*    : string
    model* : string
    race*  : string
    data*  : MWBodyData
  MWGameSetting* = object of MWRecord
    name*   : string  # name[0] directs to type used
    kind*   : char    # not in plugin file, used as support field for name[0] check
    valfl*  : float32 # values (optional)
    vali*   : int32
    vals*   : string
  MWWeaponData* = object of MWRecordData
    weight*  : float32
    value*   : uint32
    kind*    : uint16 # type (please refer to `MWWeaponType` enum in -indexes.nim-)
    health*  : uint16
    speed*   : float32
    reach*   : float32
    enchpts* : uint16 # enchantment points
    chopmin* : uint8  # chop damage
    chopmax* : uint8
    slshmin* : uint8  # slash damage
    slshmax* : uint8
    thrsmin* : uint8  # thrust damage
    thrsmax* : uint8
    flags*   : uint32 # flags, 0 means none (please refer to `MWWeaponFlag` enum in -indexes.nim-)
  MWWeapon* = object of MWRecord
    id*       : string      # ID
    model*    : string      # model name
    name*     : string = "" # name (optional)
    script*   : string = "" # script name (optional)
    enchnm*   : string = "" # enchantment name (optional)
    icon*     : string = "" # icon name (optional)
    data*     : MWWeaponData
  MWArmorData* = object of MWRecordData
    weight*  : float32
    value*   : uint32
    kind*    : uint32 # type (please refer to `MWWeaponType` enum in -indexes.nim-)
    health*  : uint32
    enchpts* : uint32 # enchantment points
    ar*      : uint32 # armor rating
  MWArmorObj* = object of MWRecordData
    #[ TODO: Is this a struct with `mname/fname`, or are those separate? Ref: https://en.uesp.net/wiki/Morrowind_Mod:Mod_File_Format/CLOT ]#
    biped* : uint8       # biped object (please refer to `MWBipedType` enum in -indexes.nim-)
    mname* : string = "" # male name for cloth (optional)
    fname* : string = "" # female name for cloth (optional, `mname` used if absent)
  MWArmor* = object of MWRecord
    id*       : string      # ID
    model*    : string      # model name
    name*     : string = "" # name (optional)
    script*   : string = "" # script name (optional)
    enchnm*   : string = "" # enchantment name (optional)
    icon*     : string = "" # icon name (optional)
    data*     : MWArmorData
    objs*     : seq[MWArmorObj] # objects (repeatable)
  MWClassData* = object of MWRecordData
    attr*    : array[2, uint32]           # primary attributes
    spec*    : uint32                     # specialisation
    skill*   : array[5, array[2, uint32]] # skills (5 sets of [minor, major])
    flags*   : uint32                     # playability (0 - NPC, 1 - playable)
    flagsac* : uint32                     # auto-calc trade/services flags
  MWClass* = object of MWRecord
    id*    : string      # ID
    name*  : string      # name
    data*  : MWClassData
    descr* : string = "" # description (optional)
  MWRaceData* = object of MWRecordData
    skill*  : array[7, (int32, int32)]   # skill bonuses (ID, bonus) [ID:-1 - empty]
    attr*   : array[8, array[2, uint32]] # attributes (8 IDs of [male, female])
    height* : (float32, float32)         # height (male, female)
    weight* : (float32, float32)         # weight (male, female)
    flags*  : uint32                     # playable/beast
  MWRace* = object of MWRecord
    id*    : string               # ID
    name*  : string = ""          # name (optional)
    power* : seq[array[32, char]] # special power/ability
    descr* : string = ""          # description (optional)
    data*  : MWRaceData
  MWBirthsign* = object of MWRecord
    id*      : string               # ID
    name*    : string = ""          # name (optional)
    spell*   : seq[array[32, char]] # spells
    texture* : string = ""          # filename (optional)
    descr*   : string = ""          # description (optional)
  MWMagicEffectData* = object of MWRecordData
    school*  : uint32  # magic school
    bcost*   : float32 # base cost
    flags*   : uint32
    red*     : uint32
    green*   : uint32
    blue*    : uint32
    speedx*  : float32
    sizex*   : float32
    sizecap* : float32
  MWMagicEffect* = object of MWRecord
    index* : uint32
    icon*  : string            # icon texture
    partc* : string            # particle texture
    sndb*  : string            # sounds: bolt
    sndc*  : string            #         casting
    sndh*  : string            #         hit
    snda*  : string            #         area
    visb*  : string            # visual: bolt    | missing visual effects default to VFX_DefaultArea, VFX_DefaultBolt, etc.
    visc*  : string            #         casting
    vish*  : string            #         hit
    visa*  : string            #         area
    descr* : string = ""
    data*  : MWMagicEffectData
  MWSpellEnch* = object of MWRecordData
    effindex* : uint16 # effect index (please refer to `MWEffectType` enum in -indexes.nim-)
    skill*    : int8   # skill affected (-1 if not applicable)
    attr*     : int8   # attribute affected (-1 if not applicable)
    range*    : uint32 # 0 = self, 1 = touch, 2 = target
    area*     : uint32
    duration* : uint32
    mmin*     : uint32 # magnitude min
    mmax*     : uint32 # magnitude max
  MWEnchantmentData* = object of MWRecordData
    kind*   : uint32 # type (please refer to `MWEnchantmentType` enum in -indexes.nim-)
    cost*   : uint32
    charge* : uint32
    flags*  : uint32 # 0x1 - autocalc
  MWEnchantment* = object of MWRecord
    id*   : string
    data* : MWEnchantmentData
    ench* : seq[MWSpellEnch]
  MWSpellData* = object of MWRecordData
    kind*  : uint32
    cost*  : uint32
    flags* : uint32
  MWSpell* = object of MWRecord
    id*   : string           # ID
    name* : string = ""      # name (optional)
    data* : MWSpellData
    ench* : seq[MWSpellEnch]
  MWRankData* = object of MWRecordData
    attr_mod* : (uint32, uint32) # attribute modifier
    pr_skill* : uint32           # primary skill
    fv_skill* : uint32           # favoured skill
    fact_rc*  : uint32           # faction reaction modifier
  MWFactionData* = object of MWRecordData
    attr*     : (uint32, uint32)
    rankdata* : array[10, MWRankData]
    skill*    : array[7, int32]
    flags*    : uint32                # 1 = hidden from player
  MWFaction* = object of MWRecord
    id*        : string               # ID
    name*      : string               # name
    ranks*     : seq[string]          # rank names (technically 10 are always used, but not required)
    relations* : seq[(string, int32)] # (faction ID, reaction value [usually between -3..+3])
    data*      : MWFactionData
  MWSoundData* = object of MWRecordData
    volume*    : uint8 # (0=0.00, 255=1.00)
    range_min* : uint8
    range_max* : uint8
  MWSound* = object of MWRecord
    id*    : string      # ID
    fname* : string      # file name
    data*  : MWSoundData
  MWSoundGenerator* = object of MWRecord
    id*     : string # ID | UESP: this appears to be generated from the creature name (or DEFAULT) combined with the type formatted as a four-digit number
                                # with leading zeroes (e.g., the ID for an alit scream is alit0006).
    kind*   : uint32
    crea*   : string # creature
    snd_id* : string # sound ID
  MWCreatureData* = object of MWRecordData
    kind*     : uint32
    level*    : uint32
    attr*     : array[8, uint32] # attributes (in order of Attribute ID, as found in MWAttributeType enum in -indexes.nim-)
    health*   : uint32           # health points
    mana*     : uint32           # magic points
    fatigue*  : uint32           # fatigue points
    soul*     : uint32
    combat*   : uint32
    magic*    : uint32
    stealth*  : uint32
    att1_min* : uint32
    att1_max* : uint32
    att2_min* : uint32
    att2_max* : uint32
    att3_min* : uint32
    att3_max* : uint32
    gold*     : uint32
  MWCarriedObject* = object of MWRecordData
    count* : uint32
    name*  : array[32, char]
  MWAIData* = object of MWRecordData
    hello*   : uint8
    unknown* : uint8
    fight*   : uint8
    flee*    : uint8
    alarm*   : uint8
    alg_pad* : (uint8, uint8, uint8) # alignment padding (junk)
    flags*   : uint32                # represented by MWServicesTradesType enum in -indexes.nim-
  MWCellTravelDestination* = object of MWRecordData
    pos_x*    : float32
    pos_y*    : float32
    pos_z*    : float32
    rot_x*    : float32
    rot_y*    : float32
    rot_z*    : float32
    prv_dest* : string  # previous destination cell name (if interior)
  # [ AI Packages ] #
  # Note: duration parameters in all packages are in hours
  # Any value greater than 24 should be divided by 100, and set to 24 if still greater than 24
  # The unknown value for each package seems to be an end-of-data marker; it is always a byte
  # value set to 1 with any remaining data in the structure undefined and ignored.
  MWAIPackageActivate* = object of MWRecordData
    name*    : array[32, char]
    unknown* : uint8
  MWAIPackageEscort* = object of MWRecordData
    pos_x*    : float32
    pos_y*    : float32
    pos_z*    : float32
    duration* : uint16
    id*       : array[32, char]
    unknown*  : uint8
    unused*   : uint8
    cell*     : string = ""
  MWAIPackageFollow* = object of MWRecordData
    pos_x*    : float32
    pos_y*    : float32
    pos_z*    : float32
    duration* : uint16
    id*       : array[32, char]
    unknown*  : uint8
    unused*   : uint8
    cell*     : string = ""
  MWAIPackageTravel* = object of MWRecordData
    pos_x*    : float32
    pos_y*    : float32
    pos_z*    : float32
    unknown*  : uint8
    unused*   : uint8
  MWAIPackageWander* = object of MWRecordData
    distance* : uint16
    duration* : uint16
    daytime*  : uint8  # time of day
    idles*    : (uint8, uint8, uint8, uint8,
                 uint8, uint8, uint8, uint8)
    unknown*  : uint8
  MWCreature* = object of MWRecord
    id*     : string   # ID
    name*   : string   # name
    model*  : string   # model name
    sgen*   : string   # sound gen creature
    script* : string   # script
    flags*  : uint32   # creature flags
    scale*  : float32  # (1.0 if missing)
    carry*  : seq[MWCarriedObject]
    spells* : seq[array[32, char]]
    dest*   : seq[MWCellTravelDestination]
    data*   : MWCreatureData
    aidata* : MWAIData
    aipkg*  : ((int, MWAIPackageActivate), # int in tuple is order number (1..5), if not found it is -1
               (int, MWAIPackageEscort),
               (int, MWAIPackageFollow),
               (int, MWAIPackageTravel),
               (int, MWAIPackageWander))
  MWLeveledCreature* = object of MWRecord
    id*      : string
    flags*   : uint32                # 0x1 (1) = calculate from all levels <= PC's level
    nchance* : uint8
    count*   : uint32                # count of following creatures
    crea*    : seq[(string, uint16)] # list of (creature ID, PC level)
  MWNPCDataACSet* = object of MWRecordData
    level*   : uint16
    disp*    : uint8
    rep*     : uint8
    rank*    : uint8
    alg_pad* : array[3, uint8]
    gold*    : uint32
  MWNPCDataACClear* = object of MWRecordData
    level*   : uint16
    attr*    : array[8, uint8]
    skill*   : array[27, uint8]
    alg_pad* : uint8
    hp*      : uint16
    mp*      : uint16
    fatigue* : uint16
    disp*    : uint8
    rep*     : uint8
    rank*    : uint8
    alg_p2d* : uint8
    gold*    : uint32
  MWNPC* = object of MWRecord
    id*      : string       # ID
    name*    : string = ""  # name (optional)
    model*   : string = ""  # model name (optional)
    race*    : string
    class*   : string
    faction* : string
    head*    : string
    hair*    : string
    script*  : string
    flags*   : uint32
    auc*     : bool         # additional check for whether `data` has autocalc set or not (used to check flags)
    carry*   : seq[MWCarriedObject]
    spells*  : seq[array[32, char]]
    dest*    : seq[MWCellTravelDestination]
    data*    : (MWNPCDataACClear, MWNPCDataACSet) # whether first or second is used is decided by 'autocalc' in flags
    aidata*  : MWAIData
    aipkg*   : ((int, MWAIPackageActivate), # int in tuple is order number (1..5), if not found it is -1
                (int, MWAIPackageEscort),
                (int, MWAIPackageFollow),
                (int, MWAIPackageTravel),
                (int, MWAIPackageWander))
  MWDialogueTopicData* = object of MWRecordData
    kind*    : uint8
    dummy*   : array[3, uint8]
    disp_ji* : uint32
    rank*    : int8
    gender*  : int8
    pcrank*  : int8
    dummy2*  : uint8
  MWDialogueTopic* = object of MWRecord
    id*   : string
    prev* : string
    next* : string
    data* : MWDialogueTopicData
    actor*  : string
    race*   : string
    class*  : string
    fact*   : string                         # faction
    cell*   : string
    pcfact* : string                         # PC faction
    sound*  : string
    resp*   : string                         # response text
    fvstr*  : seq[(string, uint32, float32)] # strings for the Function/Variable list
    rest*   : string                         # result text
    qname*  : uint8                          # journal # bool8 | quest name      | only one of `q..` can be set to 1
    qfin*   : uint8                                    # bool8 | quest finished  | meaning it is working as enum
    qres*   : uint8                                    # bool8 | quest restarted
  MWDialogue* = object of MWRecord
    name*   : string
    kind*   : uint8
    topics* : seq[MWDialogueTopic] # topics following DIAL entry
  MWPathPoint* = object of MWRecordData
    x*         : int32
    y*         : int32
    z*         : int32
    flags*     : uint8
    con_count* : uint8  # connection count (number of entries in PGRC)
    unknown*   : uint16 # unknown (likely alignment padding)
  MWPathgridData* = object of MWRecordData
    grid_x*       : int32
    grid_y*       : int32
    flags*        : uint16
    ppoint_count* : uint16 # path point count (used by .ppoint and .clist of main record)
  MWPathgrid* = object of MWRecord
    data*   : MWPathgridData
    cell*   : string           # cell name the path grid belongs to
    ppoint* : seq[MWPathPoint] # path points
    clist*  : seq[uint32]      # connection list
  MWCellData* = object of MWRecordData
    flags*  : uint32
    grid_x* : int32
    grid_y* : int32
  MWAmbientLight* = object of MWRecordData
    ambcol* : (uint8, uint8, # ambient colour
               uint8, uint8)
    suncol* : (uint8, uint8, # sunlight colour
               uint8, uint8)
    fogcol* : (uint8, uint8, # fog colour
               uint8, uint8)
    fogden* : float32        # fog density
  MWReferencePosition* = object of MWRecordData
    pos_x*    : float32
    pos_y*    : float32
    pos_z*    : float32
    rot_x*    : float32
    rot_y*    : float32
    rot_z*    : float32
  MWFormReference* = object of MWRecordData
    ref_id*   : uint32           # reference ID
    obj_id*   : string           # object ID / PlayerSaveGame
    blocked*  : uint8            # value is always 0; present if Blocked is set in the reference's record header, otherwise absent
    scale*    : float32          # scale, if applicable and not 1.0
    npc*      : (string, string) # (NPC ID [if applicable], variable)
    faction*  : (string, uint32) # (Faction ID [not light, NPC, or static], rank)
    soul*     : string           # ID of soul in gem (soul gems only)
    charge*   : float32          # enchantment charge (charged items with non-zero charges)
    rem*      : string           # remaining usages (dependent on type) | uint32  | health remaining (weapons and armor)
                                 # string contains bytes                | uint32  | uses remaining (locks, probes, repair items)
                                 # to be converted later                | float32 | time remaining (lights)
    value*    : uint32
    dest*     : seq[MWCellTravelDestination]
    lockdif*  : uint32           # lock difficulty
    keyname*  : string           # key name
    trpname*  : string           # trap name
    disabled* : uint8            # reference is disabled (always 0). Like UNAM ('blocked'), this will be emitted if the relevant flag is set in the reference's
                                 # record header; this may only be possible via scripting
                                 # also, even if present in the file, the field appears to be ignored on loading
    pos*      : MWReferencePosition
  MWMovedReference* = object of MWRecordData
    ref_id*  : uint32          # the same as reference in 'ref_obj'
    cell*    : string          # name of the cell the reference was moved to (interior cells only)
    coords*  : (int32, int32)  # coordinates of the cell the reference was moved to (exterior cells only)
    ref_obj* : MWFormReference
  MWCell* = object of MWRecord
    name*    : string         # unlike other NAME fields, this is the localized, human-readable name of the cell, not a language-agnostic ID string
                              # exterior regions are mostly empty strings; for these, the region name is used in the Construction Set
    region*  : string         # region name (exterior and like-exterior only)
    mapcol*  : (uint8, uint8, # map color   (exterior and like-exterior only)
                uint8, uint8)
    waterh*  : float32               # water height (interior only)
    light*   : MWAmbientLight
    ref_mv*  : seq[MWMovedReference] # moved references
    ch_pers* : seq[MWFormReference]  # persistent children
    ch_temp* : seq[MWFormReference]  # temporary children
    ch_tcnt* : uint32                # temporary children (count)
    data*    : MWCellData

type
  MWCommonRecord* = MWCloth | MWMisc | MWStatic | MWIngredient  | MWContainer | MWBook        | MWLeveledItem | MWActivator | MWArmor |
                    MWLight | MWDoor | MWPotion | MWLandTexture | MWRegion    | MWRepairTool  | MWApparatus   | MWLock      | MWProbe |
                    MWBody  | MWRace | MWClass  | MWWeapon      | MWBirthsign | MWEnchantment | MWSpell       | MWFaction   | MWSound |
                    MWNPC   | MWCreature        | MWLeveledCreature           | MWSoundGenerator              | MWDialogueTopic
