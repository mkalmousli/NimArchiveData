import espirit/mwparsers/[
    mwcell, mwstat, mwmisc, mwingr, mwlevi, mwcont, mwbook, mwacti, mwclot, mwligh, mwdoor,
    mwalch, mwland, mwltex, mwregn, mwrepa, mwappa, mwprob, mwlock, mwskil, mwscpt, mwglob,
    mwsscr, mwbody, mwgmst, mwarmo, mwweap, mwclas, mwrace, mwbsgn, mwmgef, mwench, mwspel,
    mwfact, mwsoun, mwsndg, mwcrea, mwlevc, mwdial, mwpgrd, mwnpc
]
import espirit/[formats, records, recordsutils, indexes, parse, common]
import std/[strformat, strutils, times, math, os]
import streams
import tables

export records
export recordsutils
export indexes
export tables

type
  PluginHeader = object
    bytestr* : string

  MWPlugin = object
    name*   : string
    master* : bool
    head*   : PluginHeader
    deps*   : OrderedTable[string, uint64] # esm dependencies as [.esm file, bytes size]
    fin*    : bool                         # whether it was read fully to the last byte
    rem*    : string                       # remaining string (non-empty only if fin == false)
    # Plugin regular records
    cell*   : seq[MWCell]            # cells (see `MWCell` in records.nim for reference)
    clot*   : seq[MWCloth]           # clothes (see `MWCloth` in records.nim for reference)
    misc*   : seq[MWMisc]            # misc items (see `MWMisc` in records.nim for reference)
    stat*   : seq[MWStatic]          # statics (see `MWStatic` in records.nim for reference)
    cont*   : seq[MWContainer]       # containers (see `MWContainer` in records.nim for reference)
    acti*   : seq[MWActivator]       # activators (see `MWActivator` in records.nim for reference)
    ligh*   : seq[MWLight]           # lights (see `MWLight` in records.nim for reference)
    ingr*   : seq[MWIngredient]      # ingredients (see `MWIngredient` in records.nim for reference)
    alch*   : seq[MWPotion]          # potion (see `MWPotion` in records.nim for reference)
    book*   : seq[MWBook]            # books (see `MWBook` in records.nim for reference)
    repa*   : seq[MWRepairTool]      # repair tools (see `MWRepairTool` in records.nim for reference)
    appa*   : seq[MWApparatus]       # apparatuses (see `MWApparatus` in records.nim for reference)
    lock*   : seq[MWLock]            # locks (see `MWLock` in records.nim for reference)
    prob*   : seq[MWProbe]           # probes (see `MWProbe` in records.nim for reference)
    levi*   : seq[MWLeveledItem]     # leveled items (see `MWLeveledItem` in records.nim for reference)
    door*   : seq[MWDoor]            # doors (see `MWDoor` in records.nim for reference)
    land*   : seq[MWLand]            # lands (see `MWLand` in records.nim for reference)
    ltex*   : seq[MWLandTexture]     # land textures (see `MWLandTexture` in records.nim for reference)
    regn*   : seq[MWRegion]          # regions (see `MWRegion` in records.nim for reference)
    skil*   : seq[MWSkill]           # skills (see `MWSkill` in records.nim for reference)
    scpt*   : seq[MWScript]          # scripts (see `MWScript` in records.nim for reference)
    glob*   : seq[MWGlobal]          # globals (see `MWGlobal` in records.nim for reference)
    sscr*   : seq[MWStartScript]     # start scripts (see `MWStartScript` in records.nim for reference)
    body*   : seq[MWBody]            # body parts (see `MWBody` in records.nim for reference)
    gmst*   : seq[MWGameSetting]     # game settings (see `MWGameSetting` in records.nim for reference)
    weap*   : seq[MWWeapon]          # weapons (see `MWWeapon` in records.nim for reference)
    armo*   : seq[MWArmor]           # armors (see `MWArmor` in records.nim for reference)
    clas*   : seq[MWClass]           # classes (see `MWClass` in records.nim for reference)
    race*   : seq[MWRace]            # races (see `MWRace` in records.nim for reference)
    bsgn*   : seq[MWBirthsign]       # birthsigns (see `MWBirthsign` in records.nim for reference)
    mgef*   : seq[MWMagicEffect]     # magic effects (see `MWMagicEffect` in records.nim for reference)
    ench*   : seq[MWEnchantment]     # enchantments (see `MWEnchantment` in records.nim for reference)
    spel*   : seq[MWSpell]           # spells (see `MWSpell` in records.nim for reference)
    fact*   : seq[MWFaction]         # factions (see `MWFaction` in records.nim for reference)
    soun*   : seq[MWSound]           # sounds (see `MWSound` in records.nim for reference)
    sndg*   : seq[MWSoundGenerator]  # sound generators (see `MWSoundGenerator` in records.nim for reference)
    crea*   : seq[MWCreature]        # creatures (see `MWCreature` in records.nim for reference)
    levc*   : seq[MWLeveledCreature] # leveled creatures (see `MWLeveledCreature` in records.nim for reference)
    pgrd*   : seq[MWPathgrid]        # pathgrids (see `MWPathgrid` in records.nim for reference)
    dial*   : seq[MWDialogue]        # dialogues (see `MWDialogue` in records.nim for reference)
    info*   : seq[MWDialogueTopic]   # dialogue topics (see `MWDialogueTopic` in records.nim for reference)
    npc*    : seq[MWNPC]             # NPCs (see `MWNPC` in records.nim for reference)

proc `$`* (plugin: MWPlugin): string =
    var deps = ""
    for k, _ in plugin.deps:
      deps.add("\n" & "* " & k)
    result = fmt"""
    [{plugin.name}]
    Dependencies: {deps}

    Data:
    * cells:             {plugin.cell.len}
    * statics:           {plugin.stat.len}
    * containers:        {plugin.cont.len}
    * activators:        {plugin.acti.len}
    * lights:            {plugin.ligh.len}
    * miscs:             {plugin.misc.len}
    * clothes:           {plugin.clot.len}
    * armors:            {plugin.armo.len}
    * ingredients:       {plugin.ingr.len}
    * potions:           {plugin.alch.len}
    * books:             {plugin.book.len}
    * weapons:           {plugin.weap.len}
    * repair tools:      {plugin.repa.len}
    * apparatuses:       {plugin.appa.len}
    * locks:             {plugin.lock.len}
    * probes:            {plugin.prob.len}
    * leveled items:     {plugin.levi.len}
    * doors:             {plugin.door.len}
    * land:              {plugin.land.len}
    * land textures:     {plugin.ltex.len}
    * regions:           {plugin.regn.len}
    * skills:            {plugin.skil.len}
    * scripts:           {plugin.scpt.len}
    * globals:           {plugin.glob.len}
    * start scripts:     {plugin.sscr.len}
    * game settings:     {plugin.gmst.len}
    * body parts:        {plugin.body.len}
    * classes:           {plugin.clas.len}
    * races:             {plugin.race.len}
    * birthsigns:        {plugin.bsgn.len}
    * magic effects:     {plugin.mgef.len}
    * enchantments:      {plugin.ench.len}
    * spells:            {plugin.spel.len}
    * factions:          {plugin.fact.len}
    * sounds:            {plugin.soun.len}
    * sound generators:  {plugin.sndg.len}
    * creatures:         {plugin.crea.len}
    * leveled creatures: {plugin.levc.len}
    * pathgrids:         {plugin.pgrd.len}
    * dialogues:         {plugin.dial.len}
    * dialogue topics:   {plugin.info.len}
    * NPCs:              {plugin.npc.len}
    """.unindent()

proc newPluginHeader(header_string: string): PluginHeader =
    result.bytestr = header_string

proc newMWPlugin* (path: string, echo_index = false, echo_details = false): MWPlugin =
    # echo arguments allow you to track parsing of MWPlugin (mostly useful for big files)
    let fs : FileStream = newFileStream(path)
    var fr : string     = fs.readAll()        # file read: string here == seq[bytes]
    # echo variables
    var ei : int        = 0
    var em : string     = ""

    if readStr(fr, 4) != "TES3": # initial .esp check
      raise newException(ParseError, fmt"File scanned does not follow correct Morrowind .esp/.esm plugin record format. File path: {path}.")
    close(fs)

    if endswith(toLowerAscii(path), ".esp"):
      result.name   = path.replace(".esp", "")
      result.master = false
    elif endsWith(toLowerAscii(path), ".esm"):
      result.name   = path.replace(".esm", "")
      result.master = true
    else: raise newException(ParseError, fmt"Cannot verify file: {path}. Make sure the file scanned is of .esp/.esm format.")

    discard readStr(fr, 12) # loose bytes
    if readStr(fr, 4) != "HEDR": # check for header
      raise newException(ParseError, fmt"File header for file: {path} not found.")
    discard readStr(fr, 4) # loose bytes

    result.head = newPluginHeader(fr.read(300)) # 300 bytes after initial check (w/o TES3 header)
    result.fin  = true                          # default, will be overwritten later if 'false'

    # records
    while fr.len > 0:
      if fr.len < 4:
        result.fin = false
        break
      let time = cpuTime()
      if echo_index and echo_details:
        em = fmt" | Type: {fr[0..3]} | Remaining bytes: {len(fr)}"

      if fr[0..3] == "MAST":
        parseMAST(fr, result.deps)
      else:
        let header = parseRecordHeader(fr)
        case header.name: # checks record type (consumed during record header parsing)
          of "CLOT": result.clot.add(parseCLOT(fr, header))
          of "STAT": result.stat.add(parseSTAT(fr, header))
          of "MISC": result.misc.add(parseMISC(fr, header))
          of "INGR": result.ingr.add(parseINGR(fr, header))
          of "CONT": result.cont.add(parseCONT(fr, header))
          of "LEVI": result.levi.add(parseLEVI(fr, header))
          of "BOOK": result.book.add(parseBOOK(fr, header))
          of "ACTI": result.acti.add(parseACTI(fr, header))
          of "LIGH": result.ligh.add(parseLIGH(fr, header))
          of "DOOR": result.door.add(parseDOOR(fr, header))
          of "ALCH": result.alch.add(parseALCH(fr, header))
          of "LAND": result.land.add(parseLAND(fr, header))
          of "LTEX": result.ltex.add(parseLTEX(fr, header))
          of "REGN": result.regn.add(parseREGN(fr, header, result.deps))
          of "CELL": result.cell.add(parseCELL(fr, header))
          of "WEAP": result.weap.add(parseWEAP(fr, header))
          of "ARMO": result.armo.add(parseARMO(fr, header))
          of "REPA": result.repa.add(parseREPA(fr, header))
          of "APPA": result.appa.add(parseAPPA(fr, header))
          of "LOCK": result.lock.add(parseLOCK(fr, header))
          of "PROB": result.prob.add(parsePROB(fr, header))
          of "SKIL": result.skil.add(parseSKIL(fr, header))
          of "SCPT": result.scpt.add(parseSCPT(fr, header))
          of "GLOB": result.glob.add(parseGLOB(fr, header))
          of "SSCR": result.sscr.add(parseSSCR(fr, header))
          of "BODY": result.body.add(parseBODY(fr, header))
          of "GMST": result.gmst.add(parseGMST(fr, header))
          of "CLAS": result.clas.add(parseCLAS(fr, header))
          of "RACE": result.race.add(parseRACE(fr, header))
          of "SPEL": result.spel.add(parseSPEL(fr, header))
          of "ENCH": result.ench.add(parseENCH(fr, header))
          of "MGEF": result.mgef.add(parseMGEF(fr, header))
          of "BSGN": result.bsgn.add(parseBSGN(fr, header))
          of "FACT": result.fact.add(parseFACT(fr, header))
          of "SOUN": result.soun.add(parseSOUN(fr, header))
          of "SNDG": result.sndg.add(parseSNDG(fr, header))
          of "CREA": result.crea.add(parseCREA(fr, header))
          of "LEVC": result.levc.add(parseLEVC(fr, header))
          of "PGRD": result.pgrd.add(parsePGRD(fr, header))
          of "DIAL": result.dial.add(parseDIAL(fr, header, result.info))                    # Includes also INFO
          of "INFO": raise newException(ParseError, fmt"INFO record out of order!") # INFO should always be parsed by DIAL
          of "NPC_": result.npc.add(parseNPC(fr, header))
          else:
            result.fin = false
            break

      if echo_index:
        ei += 1
        echo fmt"Record {ei} parsed! Time: {trunc(cpuTime() - time)}s{em}"

    if result.fin == false: result.rem = fr