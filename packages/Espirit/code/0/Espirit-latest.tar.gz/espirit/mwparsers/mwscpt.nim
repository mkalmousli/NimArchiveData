import ../records
import ../common
import ../parse

const field_key = "SCPT"

proc parseSCPT* (fr: var string, header: MWRecordHeader): MWScript =
    #[ Parses single SCPT key of .esm/.esp files and returns it as MWScript object ]#
    # optional handling uses `fr[0..3]` for scouting, instead of `readStr`/other
    setRecordData(result, header)

    if objectField(fr, "SCHD", result.sheader):
      result.sheader = MWScriptHeader(name:     read32Chars(fr),
                                      numshort: readUint32(fr),
                                      numlong:  readUint32(fr),
                                      numfloat: readUint32(fr),
                                      size_sdt: readUint32(fr),
                                      size_lvr: readUint32(fr))

    if len(fr) >= 4:
      if fr[0..3] == "SCVR":
        discard readStr(fr, 4) # SCVR
        discard readStr(fr, 4) # loose bytes
        # raw string copy
        let raw = fr[0..result.sheader.size_lvr-1]
        var ssh = newSeq[string]()
        var slg = newSeq[string]()
        var sfl = newSeq[string]()

        # concrete values
        if result.sheader.numshort > 0:
          for _ in 1..result.sheader.numshort:
            ssh.add(parseZString(fr))
        if result.sheader.numlong > 0:
          for _ in 1..result.sheader.numlong:
            slg.add(parseZString(fr))
        if result.sheader.numfloat > 0:
          for _ in 1..result.sheader.numfloat:
            sfl.add(parseZString(fr))

        # putting all elements in struct
        result.vars = MWScriptVariables(raw:    raw,
                                        shorts: ssh,
                                        longs:  slg,
                                        floats: sfl)

    if len(fr) >= 4:
      if fr[0..3] == "SCDT":
        discard readStr(fr, 4) # SCDT
        discard readStr(fr, 4) # loose bytes
        for _ in 1..result.sheader.size_sdt:
          result.cdata.add(readUint8(fr))

    result.text = optionalField[string](fr, "SCTX")