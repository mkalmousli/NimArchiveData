*********
Changelog
*********

-   [!]—backward incompatible change
-   [+]—new feature
-   [f]—bugfix
-   [r]—refactoring
-   [t]—test suite improvement


2.0.0 (July 26, 2020)
=====================

-   [r] Complete rewrite to match Norm 2.


1.0.2 (March 13, 2020)
======================

-   [f] Require Norm >= 1.1.2.


1.0.1 (March 13, 2020)
======================

-   [f] Fixed issue with ``importBackend`` not exporting the imported backend making it unusable in moduled importing ``models``.


1.0.0 (March 12, 2020)
======================

-   🎉 Initial release.
