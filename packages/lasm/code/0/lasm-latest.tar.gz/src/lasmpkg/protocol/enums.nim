type ErrorCode* = enum
  RequestFailed = -32803
  ServerCancelled = -32802
  ContentModified = -32801
  RequestCancelled = -32800 # All the other error codes are from JSON-RPC
  ParseError = -32700
  InternalError = -32603
  InvalidParams = -32602
  MethodNotFound = -32601
  InvalidRequest = -32600
  ServerErrorStart = -32099
  ServerNotInitialized = -32002
  UnknownErrorCode = -32001
  ServerErrorEnd = -32000

# Anything below here comes from the LSP specification
type
  DiagnosticSeverity* {.pure.} = enum
    Error = 1
    Warning = 2
    Information = 3
    Hint = 4

  DiagnosticTag* {.pure.} = enum
    Unnecessary = 1
    Deprecated = 2

  SymbolKind* {.pure.} = enum
    File = 1
    Module = 2
    Namespace = 3
    Package = 4
    Class = 5
    Method = 6
    Property = 7
    Field = 8
    Constructor = 9
    Enum = 10
    Interface = 11
    Function = 12
    Variable = 13
    Constant = 14
    String = 15
    Number = 16
    Boolean = 17
    Array = 18
    Object = 19
    Key = 20
    Null = 21
    EnumMember = 22
    Struct = 23
    Event = 24
    Operator = 25
    TypeParameter = 26

  CompletionItemKind* {.pure.} = enum
    Text = 1
    Method = 2
    Function = 3
    Constructor = 4
    Field = 5
    Variable = 6
    Class = 7
    Interface = 8
    Module = 9
    Property = 10
    Unit = 11
    Value = 12
    Enum = 13
    Keyword = 14
    Snippet = 15
    Color = 16
    File = 17
    Reference = 18
    Folder = 19
    EnumMember = 20
    Constant = 21
    Struct = 22
    Event = 23
    Operator = 24
    TypeParameter = 25

  TextDocumentSyncKind* {.pure.} = enum
    None = 0
    Full = 1
    Incremental = 2

  MessageType* {.pure.} = enum
    Error = 1
    Warning = 2
    Info = 3
    Log = 4
    Debug = 5

  FileChangeType* {.pure.} = enum
    Created = 1
    Changed = 2
    Deleted = 3

  WatchKind* {.pure.} = enum
    Create = 1
    Change = 2
    Delete = 4

  TextDocumentSaveReason* {.pure.} = enum
    Manual = 1
    AfterDelay = 2
    FocusOut = 3

  CompletionTriggerKind* {.pure.} = enum
    Invoked = 1
    TriggerCharacter = 2
    TriggerForIncompleteCompletions = 3

  InsertTextFormat* {.pure.} = enum
    PlainText = 1
    Snippet = 2

  DocumentHighlightKind* {.pure.} = enum
    Text = 1
    Read = 2
    Write = 3

  SignatureHelpTriggerKind* {.pure.} = enum
    Invoked = 1
    TriggerCharacter = 2
    ContentChange = 3

  InitializeErrorCodes* {.pure.} = enum
    unknownProtocolVersion = 1

  NotebookCellKind* {.pure.} = enum
    Markup = 1
    Code = 2

  SymbolTag* {.pure.} = enum
    Deprecated = 1

  InlayHintKind* {.pure.} = enum
    Type = 1
    Parameter = 2

  CompletionItemTag* {.pure.} = enum
    Deprecated = 1

  InsertTextMode* {.pure.} = enum
    asIs = 1
    adjustIndentation = 2

  CodeActionTriggerKind* {.pure.} = enum
    Invoked = 1
    Automatic = 2

  PrepareSupportDefaultBehavior* {.pure.} = enum
    Identifier = 1

  SemanticTokenTypes* {.pure.} = enum
    Namespace = 0
    Type = 1
    Class = 2
    Enum = 3
    Interface = 4
    Struct = 5
    TypeParameter = 6
    Parameter = 7
    Variable = 8
    Property = 9
    EnumMember = 10
    Event = 11
    Function = 12
    Method = 13
    Macro = 14
    Keyword = 15
    Modifier = 16
    Comment = 17
    String = 18
    Number = 19
    Regexp = 20
    Operator = 21
    Decorator = 22

  SemanticTokenModifiers* {.pure.} = enum
    Declaration = 0
    Definition = 1
    Readonly = 2
    Static = 3
    Deprecated = 4
    Abstract = 5
    Async = 6
    Modification = 7
    Documentation = 8
    DefaultLibrary = 9
