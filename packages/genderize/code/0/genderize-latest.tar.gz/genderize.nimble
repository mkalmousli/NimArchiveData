# Package

version       = "0.1.0"
author        = "Nemuel Wainaina"
description   = "Nim wrapper for the Genderize.io API"
license       = "GPL-3.0-only"
srcDir        = "src"


# Dependencies

requires "nim >= 1.6"
requires "jsony"
requires "results"
