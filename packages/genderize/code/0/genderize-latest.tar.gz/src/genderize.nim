import httpclient, jsony, options, results, sequtils, strformat, strutils

const BaseUrl = "https://api.genderize.io/?"

type
  GenderizeClient* = object
    apiKey*: string
    client*: HttpClient

  Gender* = object
    name*: string
    gender*: Option[string]
    count*: int
    probability*: float
    country_id*: Option[string]

  Error* = object
    error*: string

proc makeRequest[T](self: GenderizeClient, url: string): Result[T, string] =
  var url = url
  if self.apiKey.len > 0:
    url = fmt"{url}&apikey={self.apiKey}"

  let response = self.client.request(url)
  let body = response.body
  if response.status != "200 OK":
    let error = body.fromJson(Error)
    return err(error.error)

  return ok(body.fromJson(T))

proc newGenderizeClient*(apiKey = ""): GenderizeClient =
  ## initialize a new client for interacting with the API
  ##
  ## params:
  ##  `apiKey`: optional API key
  ##
  ## returns:
  ##  `GenderizeClient`

  result.apiKey = apiKey
  result.client = newHttpClient()
  result.client.headers = newHttpHeaders({"User-Agent": "genderize/0.1.0 (Nim)"})

proc predictGender*(self: GenderizeClient, name: string, countryId = ""): Result[Gender, string] =
  ## predict the gender of a single name
  ##
  ## params:
  ##  `name`: name whose gender is to be predicted
  ##  `countryId`: optional country filter to apply
  ##
  ## returns:
  ##  `Result[Gender, string]`

  var url = BaseUrl
  url = fmt"{url}name={name}"
  if countryId.len > 0:
    url = fmt"{url}&country_id={countryId}"

  return makeRequest[Gender](self, url)

proc predictGenders*(self: GenderizeClient, names: seq[string], countryId = ""): Result[seq[Gender], string] =
  ## predict the genders of a list of names
  ##
  ## params:
  ##  `names`: list of names whose genders are to be predicted
  ##  `countryId`: optional country filter to apply
  ##
  ## returns:
  ##  `Result[seq[Gender], string]`

  var url = BaseUrl
  let namesParam = names.mapIt(fmt"name[]={it}").join("&")
  url = fmt"{url}{namesParam}"
  if countryId.len > 0:
    url = fmt"{url}&country_id={countryId}"

  return makeRequest[seq[Gender]](self, url)
