import strutils

proc getNimbleVersion(): string =
  for line in "rin.nimble".slurp.splitLines:
    if line.strip.startsWith("version"):
      return line.split("\"")[1]
  return "dev"

switch("define", "Version=" & getNimbleVersion())
switch("passC", "-I/usr/include/dbus-1.0 -I/usr/lib/dbus-1.0/include")
