# Package
version       = "0.1.0"
author        = "Carlo"
description   = "Tiny CLI timer with desktop notification and alarm sound"
license       = "MIT"
srcDir        = "src"
bin           = @["rin"]

# Dependencies
requires "nim >= 2.0.0"
