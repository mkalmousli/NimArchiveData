## rin — set a timer, get a notification
## usage: rin <minutes> [message...]

import std/[os, posix, strutils, strformat]

const Version {.strdefine.} = "dev"

# ── Embedded alarm WAV ──────────────────────────────────────────────
const alarmWav = staticRead("../alarm.wav")

# ── PulseAudio simple API ──────────────────────────────────────────
type
  PaSampleFormat {.size: sizeof(cint).} = enum
    PA_SAMPLE_S16LE = 3
  PaSampleSpec {.importc: "pa_sample_spec", header: "<pulse/simple.h>".} = object
    format: PaSampleFormat
    rate: uint32
    channels: uint8
  PaSimple = pointer

const libpulse = "libpulse-simple.so.0"

proc pa_simple_new(server: cstring, name: cstring, dir: cint,
    dev: cstring, stream_name: cstring, ss: ptr PaSampleSpec,
    map: pointer, attr: pointer, error: ptr cint): PaSimple
    {.importc, dynlib: libpulse.}
proc pa_simple_write(s: PaSimple, data: pointer, bytes: csize_t,
    error: ptr cint): cint
    {.importc, dynlib: libpulse.}
proc pa_simple_drain(s: PaSimple, error: ptr cint): cint
    {.importc, dynlib: libpulse.}
proc pa_simple_free(s: PaSimple)
    {.importc, dynlib: libpulse.}

proc playAlarm() =
  var ss = PaSampleSpec(format: PA_SAMPLE_S16LE, rate: 44100, channels: 2)
  var err: cint
  let pa = pa_simple_new(nil, "rin", 1, nil, "alarm", addr ss, nil, nil, addr err)
  if pa == nil: return
  # WAV header is 44 bytes; skip it
  let pcm = alarmWav[44..^1]
  discard pa_simple_write(pa, unsafeAddr pcm[0], pcm.len.csize_t, addr err)
  discard pa_simple_drain(pa, addr err)
  pa_simple_free(pa)

# ── D-Bus notifications ───────────────────────────────────────────
type
  DBusConnection = pointer
  DBusMessage = pointer
  DBusError {.importc: "DBusError", header: "<dbus/dbus.h>".} = object
    name: cstring
    message: cstring
    dummy1: cuint
    dummy2, dummy3, dummy4, dummy5: pointer
  DBusMessageIter {.importc: "DBusMessageIter", header: "<dbus/dbus.h>".} = object
    pad: array[56, byte]

const libdbus = "libdbus-1.so.3"

proc dbus_error_init(err: ptr DBusError)
    {.importc, dynlib: libdbus.}
proc dbus_bus_get(typ: cint, err: ptr DBusError): DBusConnection
    {.importc, dynlib: libdbus.}
proc dbus_message_new_method_call(dest, path, iface, meth: cstring): DBusMessage
    {.importc, dynlib: libdbus.}
proc dbus_connection_send_with_reply_and_block(conn: DBusConnection,
    msg: DBusMessage, timeout: cint, err: ptr DBusError): DBusMessage
    {.importc, dynlib: libdbus.}
proc dbus_message_unref(msg: DBusMessage)
    {.importc, dynlib: libdbus.}
proc dbus_message_iter_init_append(msg: DBusMessage, iter: ptr DBusMessageIter)
    {.importc, dynlib: libdbus.}
proc dbus_message_iter_append_basic(iter: ptr DBusMessageIter, typ: cint,
    value: pointer): cint
    {.importc, dynlib: libdbus.}
proc dbus_message_iter_open_container(iter: ptr DBusMessageIter, typ: cint,
    sig: cstring, sub: ptr DBusMessageIter): cint
    {.importc, dynlib: libdbus.}
proc dbus_message_iter_close_container(iter: ptr DBusMessageIter,
    sub: ptr DBusMessageIter): cint
    {.importc, dynlib: libdbus.}

const
  DBUS_TYPE_STRING: cint = 's'.ord
  DBUS_TYPE_UINT32: cint = 'u'.ord
  DBUS_TYPE_INT32: cint = 'i'.ord
  DBUS_TYPE_ARRAY: cint = 'a'.ord
  DBUS_TYPE_INVALID {.used.}: cint = 0

proc notify(summary, body: string) =
  var err: DBusError
  dbus_error_init(addr err)
  let conn = dbus_bus_get(0, addr err)  # DBUS_BUS_SESSION
  if conn == nil: return

  let msg = dbus_message_new_method_call(
    "org.freedesktop.Notifications",
    "/org/freedesktop/Notifications",
    "org.freedesktop.Notifications",
    "Notify")
  if msg == nil: return

  var iter, arrIter: DBusMessageIter
  dbus_message_iter_init_append(msg, addr iter)

  var
    appName: cstring = "rin"
    replacesId: uint32 = 0
    appIcon: cstring = "alarm-symbolic"
    cSummary: cstring = summary
    cBody: cstring = body
    timeout: int32 = 5000

  discard dbus_message_iter_append_basic(addr iter, DBUS_TYPE_STRING, addr appName)
  discard dbus_message_iter_append_basic(addr iter, DBUS_TYPE_UINT32, addr replacesId)
  discard dbus_message_iter_append_basic(addr iter, DBUS_TYPE_STRING, addr appIcon)
  discard dbus_message_iter_append_basic(addr iter, DBUS_TYPE_STRING, addr cSummary)
  discard dbus_message_iter_append_basic(addr iter, DBUS_TYPE_STRING, addr cBody)

  # actions: as (empty)
  discard dbus_message_iter_open_container(addr iter, DBUS_TYPE_ARRAY, "s", addr arrIter)
  discard dbus_message_iter_close_container(addr iter, addr arrIter)

  # hints: a{sv} (empty)
  discard dbus_message_iter_open_container(addr iter, DBUS_TYPE_ARRAY, "{sv}", addr arrIter)
  discard dbus_message_iter_close_container(addr iter, addr arrIter)

  discard dbus_message_iter_append_basic(addr iter, DBUS_TYPE_INT32, addr timeout)

  let reply = dbus_connection_send_with_reply_and_block(conn, msg, 3000, addr err)
  if reply != nil: dbus_message_unref(reply)
  dbus_message_unref(msg)

# ── Main ───────────────────────────────────────────────────────────
proc main() =
  let args = commandLineParams()

  if args.len > 0 and args[0] in ["-v", "--version"]:
    echo "rin " & Version
    quit(0)

  if args.len == 0:
    echo "usage: rin <minutes> [message...]"
    quit(1)

  var minutes: int
  try: minutes = parseInt(args[0])
  except: echo "error: first argument must be a number of minutes"; quit(1)

  let msg = if args.len > 1: args[1..^1].join(" ")
            else: &"{minutes} minute timer is up!"

  let pid = fork()
  if pid < 0:
    echo "error: fork failed"
    quit(1)
  elif pid > 0:
    echo &"timer set for {minutes}m (pid {pid})"
    quit(0)
  else:
    discard setsid()
    sleep(minutes * 60 * 1000)
    notify("Timer", msg)
    playAlarm()

main()
