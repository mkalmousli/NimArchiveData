switch "path", "$projectDir/../src"
