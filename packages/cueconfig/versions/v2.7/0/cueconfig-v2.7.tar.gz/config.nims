switch("path",thisDir() & "/src")
