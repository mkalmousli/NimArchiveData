conflict: "A"
onlyInA: "A"