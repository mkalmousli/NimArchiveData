# Package
version       = "0.1.0"
author        = "Carlo Capocasa"
description   = "Extract and display DMARC aggregate reports from Maildir"
license       = "MIT"
srcDir        = "src"
bin           = @["dmarcmaster"]

# Dependencies
requires "nim >= 2.0.0"
requires "zippy >= 0.10.0"
