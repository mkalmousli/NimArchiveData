import std/[os, strutils, sequtils, parseopt, tables, algorithm, base64, json, times]
import std/xmlparser, std/xmltree
import zippy, zippy/ziparchives

const
  KnownServers = ["65.108.71.196"]
  DefaultMaildir = "~/.Postmaster" # expanded at runtime

type
  DmarcRecord = object
    reportId: string
    orgName: string
    dateBegin: int64
    dateEnd: int64
    domain: string
    sourceIp: string
    count: int
    dkimEval: string
    spfEval: string
    disposition: string
    envelopeFrom: string
    headerFrom: string
    envelopeTo: string

  OutputMode = enum
    omTable, omJson, omSummary

proc expandHome(p: string): string =
  if p.startsWith("~"):
    getHomeDir() / p[2..^1]
  else:
    p

proc findBoundary(headers: string): string =
  for line in headers.splitLines:
    let lower = line.strip.toLowerAscii
    if lower.startsWith("boundary="):
      result = line.strip.split("=", 1)[1].strip(chars = {'"', '\''})
      return
    if "boundary=" in lower:
      let idx = line.find("boundary=")
      if idx >= 0:
        result = line[idx + 9 .. ^1].strip(chars = {'"', '\'', ';', ' '})
        return

proc extractAttachment(content: string, depth: int = 0): string =
  ## Extract DMARC XML from a MIME email. Returns XML string or empty.
  if depth > 5: return ""

  let headerEnd = content.find("\r\n\r\n")
  let headerEnd2 = content.find("\n\n")
  let sepPos = if headerEnd >= 0 and (headerEnd2 < 0 or headerEnd < headerEnd2):
    headerEnd else: headerEnd2

  if sepPos < 0: return ""
  let headers = content[0 ..< sepPos]

  # Find outermost boundary
  let boundary = findBoundary(headers)
  if boundary == "":
    return ""

  # Split on boundary
  let parts = content.split("--" & boundary)

  for part in parts:
    let partLower = part.toLowerAscii
    # Look for gzip or zip attachment
    let isGzip = "application/gzip" in partLower or
                 "application/x-gzip" in partLower or
                 ".xml.gz" in partLower
    let isZip = "application/zip" in partLower or
                "application/x-zip" in partLower or
                ".zip" in partLower

    if not isGzip and not isZip:
      # Check nested multipart
      if "content-type: multipart/" in partLower:
        let nested = extractAttachment(part.strip(chars = {'-', '\n', '\r'}), depth + 1)
        if nested != "":
          return nested
      continue

    # Find the base64 body
    let bodyMarkers = ["\r\n\r\n", "\n\n"]
    var bodyStart = -1
    for marker in bodyMarkers:
      let pos = part.find(marker)
      if pos >= 0:
        bodyStart = pos + marker.len
        break
    if bodyStart < 0: continue

    var b64 = part[bodyStart .. ^1].strip
    # Remove trailing boundary markers
    let dashIdx = b64.rfind("\n--")
    if dashIdx >= 0:
      b64 = b64[0 ..< dashIdx]
    b64 = b64.multiReplace({"\r": "", "\n": "", " ": ""})

    var decoded: seq[byte]
    try:
      decoded = cast[seq[byte]](decode(b64))
    except CatchableError:
      continue

    if decoded.len == 0: continue

    if isGzip:
      try:
        return cast[string](zippy.uncompress(cast[string](decoded), dfGzip))
      except CatchableError:
        continue

    if isZip:
      try:
        let reader = openZipArchive(cast[string](decoded))
        for path in reader.walkFiles:
          if path.endsWith(".xml"):
            let xml = reader.extractFile(path)
            reader.close()
            return xml
        reader.close()
      except CatchableError:
        continue

  return ""

proc getText(node: XmlNode, tag: string): string =
  let child = node.child(tag)
  if child != nil:
    return child.innerText.strip
  return ""

proc parseReport(xml: string): seq[DmarcRecord] =
  var root: XmlNode
  try:
    root = parseXml(xml)
  except CatchableError:
    return @[]

  let meta = root.child("report_metadata")
  let policy = root.child("policy_published")

  var reportId, orgName, domain: string
  var dateBegin, dateEnd: int64

  if meta != nil:
    reportId = meta.getText("report_id")
    orgName = meta.getText("org_name")
    let dr = meta.child("date_range")
    if dr != nil:
      try: dateBegin = parseBiggestInt(dr.getText("begin"))
      except ValueError: discard
      try: dateEnd = parseBiggestInt(dr.getText("end"))
      except ValueError: discard

  if policy != nil:
    domain = policy.getText("domain")

  for child in root:
    if child.tag == "record":
      var rec = DmarcRecord(
        reportId: reportId,
        orgName: orgName,
        dateBegin: dateBegin,
        dateEnd: dateEnd,
        domain: domain,
      )

      let row = child.child("row")
      if row != nil:
        rec.sourceIp = row.getText("source_ip")
        try: rec.count = parseInt(row.getText("count"))
        except ValueError: rec.count = 0
        let pe = row.child("policy_evaluated")
        if pe != nil:
          rec.disposition = pe.getText("disposition")
          rec.dkimEval = pe.getText("dkim")
          rec.spfEval = pe.getText("spf")

      let ids = child.child("identifiers")
      if ids != nil:
        rec.envelopeFrom = ids.getText("envelope_from")
        rec.headerFrom = ids.getText("header_from")
        rec.envelopeTo = ids.getText("envelope_to")

      result.add(rec)

proc formatDate(ts: int64): string =
  if ts == 0: return "?"
  fromUnix(ts).utc.format("yyyy-MM-dd")

proc printTable(records: seq[DmarcRecord]) =
  # Header
  echo "DATE       | SUBMITTER                    | SOURCE_IP        | CNT | DKIM | SPF  | DISP | FROM             | TO"
  echo "-".repeat(140)
  for r in records:
    let date = formatDate(r.dateBegin)
    let flag = if r.dkimEval != "pass" or r.spfEval != "pass" or
                  r.disposition != "none" or
                  r.sourceIp notin KnownServers: "!" else: " "
    echo flag & date.alignLeft(10) & " | " &
         r.orgName.alignLeft(28) & " | " &
         r.sourceIp.alignLeft(16) & " | " &
         ($r.count).align(3) & " | " &
         r.dkimEval.alignLeft(4) & " | " &
         r.spfEval.alignLeft(4) & " | " &
         r.disposition.alignLeft(4) & " | " &
         r.headerFrom.alignLeft(16) & " | " &
         r.envelopeTo

proc printJson(records: seq[DmarcRecord]) =
  var arr = newJArray()
  for r in records:
    arr.add(%*{
      "report_id": r.reportId,
      "org_name": r.orgName,
      "date_begin": formatDate(r.dateBegin),
      "date_end": formatDate(r.dateEnd),
      "domain": r.domain,
      "source_ip": r.sourceIp,
      "count": r.count,
      "dkim": r.dkimEval,
      "spf": r.spfEval,
      "disposition": r.disposition,
      "envelope_from": r.envelopeFrom,
      "header_from": r.headerFrom,
      "envelope_to": r.envelopeTo,
    })
  echo $arr

proc printSummary(records: seq[DmarcRecord]) =
  var byIp = initTable[string, tuple[total, dkimFail, spfFail: int]]()
  var anomalies: seq[string]

  for r in records:
    var entry = byIp.getOrDefault(r.sourceIp, (0, 0, 0))
    entry.total += r.count
    if r.dkimEval != "pass": entry.dkimFail += r.count
    if r.spfEval != "pass": entry.spfFail += r.count
    byIp[r.sourceIp] = entry

    if r.disposition != "none":
      anomalies.add("DISPOSITION " & r.disposition & " for " & r.sourceIp &
        " (" & r.orgName & ", " & formatDate(r.dateBegin) & ")")
    if r.dkimEval != "pass":
      anomalies.add("DKIM FAIL from " & r.sourceIp &
        " (" & r.orgName & ", " & formatDate(r.dateBegin) & ")")
    if r.spfEval != "pass":
      anomalies.add("SPF FAIL from " & r.sourceIp &
        " (" & r.orgName & ", " & formatDate(r.dateBegin) & ")")
    if r.sourceIp notin KnownServers:
      anomalies.add("UNKNOWN IP " & r.sourceIp &
        " (" & r.orgName & ", " & formatDate(r.dateBegin) & ")")

  echo "=== DMARC Summary ==="
  echo ""
  echo "SOURCE_IP        | TOTAL | DKIM_FAIL | SPF_FAIL | KNOWN"
  echo "-".repeat(70)
  for ip, stats in byIp:
    let known = if ip in KnownServers: "yes" else: "NO"
    echo ip.alignLeft(16) & " | " &
         ($stats.total).align(5) & " | " &
         ($stats.dkimFail).align(9) & " | " &
         ($stats.spfFail).align(8) & " | " &
         known

  if anomalies.len > 0:
    echo ""
    echo "=== Anomalies ==="
    for a in anomalies.deduplicate:
      echo "  ! " & a
  else:
    echo ""
    echo "No anomalies detected."

proc usage() =
  echo "dmarcmaster - DMARC aggregate report extractor"
  echo ""
  echo "Usage: dmarcmaster [options] [maildir-path]"
  echo ""
  echo "Options:"
  echo "  -n          new messages only"
  echo "  -j          JSON output"
  echo "  -s          summary mode (group by IP, flag anomalies)"
  echo "  --since=D   filter reports starting from date (YYYY-MM-DD)"
  echo "  -h, --help  show this help"
  echo ""
  echo "Default maildir: ~/Maildir/.Postmaster"

proc main() =
  var mode = omTable
  var newOnly = false
  var sinceTs: int64 = 0
  var maildirPath = expandHome("~/Maildir/.Postmaster")

  var p = initOptParser()
  while true:
    p.next()
    case p.kind
    of cmdEnd: break
    of cmdShortOption:
      case p.key
      of "n": newOnly = true
      of "j": mode = omJson
      of "s": mode = omSummary
      of "h": usage(); quit(0)
      else: discard
    of cmdLongOption:
      case p.key
      of "since":
        try:
          sinceTs = parse(p.val, "yyyy-MM-dd", utc()).toTime.toUnix
        except TimeFormatParseError:
          stderr.writeLine "Invalid date: " & p.val
          quit(1)
      of "help": usage(); quit(0)
      else: discard
    of cmdArgument:
      maildirPath = expandHome(p.key)

  # Collect maildir files
  var files: seq[string]
  let newDir = maildirPath / "new"
  let curDir = maildirPath / "cur"

  if dirExists(newDir):
    for f in walkDir(newDir, relative = false):
      if f.kind == pcFile:
        files.add(f.path)
  if not newOnly and dirExists(curDir):
    for f in walkDir(curDir, relative = false):
      if f.kind == pcFile:
        files.add(f.path)

  if files.len == 0:
    stderr.writeLine "No messages found in " & maildirPath
    quit(1)

  var seen = initTable[string, bool]()
  var allRecords: seq[DmarcRecord]

  for path in files:
    let content = readFile(path)
    let xml = extractAttachment(content)
    if xml == "":
      continue

    let records = parseReport(xml)
    for r in records:
      if r.reportId != "" and r.reportId in seen:
        continue
      if sinceTs > 0 and r.dateEnd < sinceTs:
        continue
      allRecords.add(r)
      if r.reportId != "":
        seen[r.reportId] = true

  # Sort by date
  allRecords.sort(proc(a, b: DmarcRecord): int =
    cmp(a.dateBegin, b.dateBegin))

  if allRecords.len == 0:
    stderr.writeLine "No DMARC reports found."
    quit(0)

  case mode
  of omTable: printTable(allRecords)
  of omJson: printJson(allRecords)
  of omSummary: printSummary(allRecords)

when isMainModule:
  main()
