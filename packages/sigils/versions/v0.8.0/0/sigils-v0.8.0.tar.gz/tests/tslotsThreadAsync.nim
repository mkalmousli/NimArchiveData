import std/[unittest, asyncdispatch, times, strutils]
import sigils
import sigils/threadAsyncs

type
  SomeAction* = ref object of Agent
    value: int
  Counter* = ref object of Agent
    value: int

proc valueChanged*(tp: SomeAction, val: int) {.signal.}
proc updated*(tp: Counter, final: int) {.signal.}

## -------------------------------------------------------- ##
let start = epochTime()

proc ticker(self: Counter) {.async.} =
  ## This simple procedure will echo out "tick" ten times with 100ms between
  ## each tick. We use it to visualise the time between other procedures.
  for i in 1..3:
    await sleepAsync(100)
    echo "tick ",
         i*100, "ms ",
         split($((epochTime() - start)*1000), '.')[0], "ms (real)"

  emit self.updated(epochTime().toInt())
    
proc setValue*(self: Counter, value: int) {.slot.} =
  echo "setValue! ", value, " (th:", getThreadId(), ")"
  if self.value != value:
    self.value = value
  asyncCheck ticker(self)

proc completed*(self: SomeAction, final: int) {.slot.} =
  echo "Action done! final: ", final, " (th:", getThreadId(), ")"
  self.value = final

proc value*(self: Counter): int =
  self.value

suite "threaded agent slots":
  teardown:
    GC_fullCollect()

  test "sigil object thread runner":
    var
      a = SomeAction.new()
      b = Counter.new()

    echo "thread runner!", " (th:", getThreadId(), ")"
    echo "obj a: ", a.unsafeWeakRef

    let thread = newSigilAsyncThread()
    thread.start()
    startLocalThread()

    let bp: AgentProxy[Counter] = b.moveToThread(thread)
    connect(a, valueChanged, bp, setValue)
    connect(bp, updated, a, SomeAction.completed())

    emit a.valueChanged(314)
    let ct = getCurrentSigilThread()
    ct.poll()
