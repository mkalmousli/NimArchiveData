// SPDX-License-Identifier: MPL-2.0
// Copyright (c) 2026 Jonathan D.A. Jewell (hyperpolymath) <j.d.a.jewell@open.ac.uk>

/**
 * SafeString - String operations that cannot crash.
 *
 * Thin FFI wrapper: all computation delegates to libproven (Idris 2 + Zig).
 *
 * @module
 */

import { getLib, ProvenStatus, readAndFreeString, statusToError } from './ffi.ts';
import { err, ok, type Result } from './result.ts';

/**
 * Safe string operations backed by formally verified Idris 2 code.
 */
export class SafeString {
  /**
   * Check if a byte sequence is valid UTF-8.
   *
   * @param input - Input string or bytes.
   * @returns Result containing a boolean or an error string.
   */
  static isValidUtf8(input: string | Uint8Array): Result<boolean> {
    const symbols = getLib();
    const bytes = typeof input === 'string' ? new TextEncoder().encode(input) : input;
    const result = symbols.proven_string_is_valid_utf8(bytes, bytes.length);
    if (result[0] !== ProvenStatus.OK) return err(statusToError(result[0]));
    return ok(result[1]);
  }

  /**
   * Escape a string for safe use in SQL queries (single-quote escaping).
   *
   * @param str - Input string.
   * @returns Result containing the escaped string or an error.
   */
  static escapeSql(str: string): Result<string> {
    const symbols = getLib();
    const bytes = new TextEncoder().encode(str);
    const result = symbols.proven_string_escape_sql(bytes, bytes.length);
    const status = result[0];
    if (status !== ProvenStatus.OK) return err(statusToError(status));
    const escaped = readAndFreeString(result[1], Number(result[2]));
    if (escaped === null) return err('Null string returned');
    return ok(escaped);
  }

  /**
   * Escape a string for safe use in HTML (prevents XSS).
   *
   * @param str - Input string.
   * @returns Result containing the escaped string or an error.
   */
  static escapeHtml(str: string): Result<string> {
    const symbols = getLib();
    const bytes = new TextEncoder().encode(str);
    const result = symbols.proven_string_escape_html(bytes, bytes.length);
    const status = result[0];
    if (status !== ProvenStatus.OK) return err(statusToError(status));
    const escaped = readAndFreeString(result[1], Number(result[2]));
    if (escaped === null) return err('Null string returned');
    return ok(escaped);
  }

  /**
   * Escape a string for safe use in JavaScript string literals.
   *
   * @param str - Input string.
   * @returns Result containing the escaped string or an error.
   */
  static escapeJs(str: string): Result<string> {
    const symbols = getLib();
    const bytes = new TextEncoder().encode(str);
    const result = symbols.proven_string_escape_js(bytes, bytes.length);
    const status = result[0];
    if (status !== ProvenStatus.OK) return err(statusToError(status));
    const escaped = readAndFreeString(result[1], Number(result[2]));
    if (escaped === null) return err('Null string returned');
    return ok(escaped);
  }
}
