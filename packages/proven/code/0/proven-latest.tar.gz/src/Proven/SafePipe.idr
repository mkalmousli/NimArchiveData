-- SPDX-License-Identifier: PMPL-1.0-or-later
-- Copyright (c) 2026 Jonathan D.A. Jewell (hyperpolymath) <j.d.a.jewell@open.ac.uk>
||| SafePipe - Safe FIFO and pipe management
|||
||| This module provides safe pipe operations including:
||| - Named pipe (FIFO) creation and cleanup
||| - Anonymous pipe creation
||| - Pipe communication with bounds checking
||| - Resource lifecycle management
||| - Deadlock prevention
|||
||| Example usage:
||| ```idris
||| -- Create FIFO
||| case createFifo "/tmp/myfifo" 0o600 of
|||   Ok fifo => do
|||     -- Use FIFO
|||     cleanup fifo
|||   Err (FifoExists _) => putStrLn "FIFO already exists"
|||   Err e => handleError e
|||
||| -- Anonymous pipe
||| case createPipe of
|||   Ok (readFd, writeFd) => do
|||     -- Use pipe
|||     closePipe readFd writeFd
|||   Err e => handleError e
||| ```
module Proven.SafePipe
import Data.String
import Data.List

import public Proven.Core
import Proven.SafePath

%default total

--------------------------------------------------------------------------------
-- Pipe Types
--------------------------------------------------------------------------------

||| File descriptor (abstract, platform-specific)
public export
data FileDescriptor = MkFd Int

public export
Eq FileDescriptor where
  (==) (MkFd fd1) (MkFd fd2) = fd1 == fd2

||| FIFO identifier
public export
record FifoId where
  constructor MkFifo
  path : String
  permissions : Bits32
  exists : Bool

||| Pipe pair (read end, write end)
public export
record PipePair where
  constructor MkPipe
  readEnd : FileDescriptor
  writeEnd : FileDescriptor
  isOpen : Bool

||| Pipe errors
public export
data PipeError
  = FifoExists String
  | FifoCreationFailed String String  -- path, reason
  | PathTraversal String
  | InvalidPermissions Bits32
  | PipeCreationFailed String
  | BrokenPipe
  | WouldBlock
  | ResourceExhausted
  | InvalidFileDescriptor Int

||| Result type for pipe operations
public export
PipeResult : Type -> Type
PipeResult = Result PipeError

--------------------------------------------------------------------------------
-- FIFO Operations
--------------------------------------------------------------------------------

||| Validate FIFO path (must be absolute, no traversal)
public export
validateFifoPath : String -> PipeResult String
validateFifoPath path =
  case validate (parsePath path) of
    Right safePath => Ok (show safePath)
    Left err => Err (PathTraversal (show err))

||| Check if permissions are valid for FIFO (must be 0-0777)
public export
validatePermissions : Bits32 -> PipeResult Bits32
validatePermissions perms =
  if perms <= 0o777
    then Ok perms
    else Err (InvalidPermissions perms)

||| Create FIFO at given path (FFI stub - actual implementation via Zig)
public export
createFifo : String -> Bits32 -> PipeResult FifoId
createFifo path perms = do
  validPath <- validateFifoPath path
  validPerms <- validatePermissions perms
  -- FFI call to mkfifo(2)
  -- For now, return success (implementation via Zig FFI)
  Ok (MkFifo validPath validPerms True)

||| Remove FIFO (FFI stub)
public export
removeFifo : FifoId -> PipeResult ()
removeFifo fifo = do
  -- FFI call to unlink(2)
  Ok ()

||| Check if FIFO exists
public export
fifoExists : String -> PipeResult Bool
fifoExists path = do
  validPath <- validateFifoPath path
  -- FFI call to stat(2) or access(2)
  Ok False  -- Stub

--------------------------------------------------------------------------------
-- Anonymous Pipe Operations
--------------------------------------------------------------------------------

||| Create anonymous pipe (FFI stub - actual implementation via Zig)
public export
createPipe : PipeResult PipePair
createPipe =
  -- FFI call to pipe(2)
  -- Returns (readFd, writeFd)
  Ok (MkPipe (MkFd 3) (MkFd 4) True)  -- Stub FDs

||| Close pipe (both ends)
public export
closePipe : FileDescriptor -> FileDescriptor -> PipeResult ()
closePipe readFd writeFd = do
  -- FFI call to close(2) for both FDs
  Ok ()

||| Close single file descriptor
public export
closeFd : FileDescriptor -> PipeResult ()
closeFd (MkFd fd) =
  if fd < 0
    then Err (InvalidFileDescriptor fd)
    else Ok ()  -- FFI call to close(2)

--------------------------------------------------------------------------------
-- I/O Operations
--------------------------------------------------------------------------------

||| Maximum safe read size (prevent memory exhaustion)
public export
maxPipeReadSize : Nat
maxPipeReadSize = 65536  -- 64 KB

||| Read from pipe with size limit (FFI stub)
public export
readPipe : FileDescriptor -> Nat -> PipeResult String
readPipe (MkFd fd) size =
  if size > maxPipeReadSize
    then Err ResourceExhausted
    else Ok ""  -- FFI call to read(2)

||| Write to pipe (FFI stub)
public export
writePipe : FileDescriptor -> String -> PipeResult Nat
writePipe fd_arg str_arg =
  case fd_arg of
    MkFd fd => Ok 0  -- FFI call to write(2), returns bytes written

--------------------------------------------------------------------------------
-- Resource Management
--------------------------------------------------------------------------------

||| Pipe lifecycle state
public export
data PipeState = Created | Open | Closed | Error

public export
Eq PipeState where
  (==) Created Created = True
  (==) Open Open = True
  (==) Closed Closed = True
  (==) Error Error = True
  (==) _ _ = False

public export
Show PipeState where
  show Created = "Created"
  show Open = "Open"
  show Closed = "Closed"
  show Error = "Error"

||| Tracked pipe resource
public export
record TrackedPipe where
  constructor Track
  pipe : PipePair
  state : PipeState
  bytesRead : Nat
  bytesWritten : Nat

||| Initialize tracked pipe
public export
trackPipe : PipePair -> TrackedPipe
trackPipe p = Track p Open 0 0

||| Update pipe state
public export
updatePipeState : PipeState -> TrackedPipe -> TrackedPipe
updatePipeState newState tracked =
  { state := newState } tracked

||| Record read operation
public export
recordRead : Nat -> TrackedPipe -> TrackedPipe
recordRead bytes tracked =
  { bytesRead := tracked.bytesRead + bytes } tracked

||| Record write operation
public export
recordWrite : Nat -> TrackedPipe -> TrackedPipe
recordWrite bytes tracked =
  { bytesWritten := tracked.bytesWritten + bytes } tracked

--------------------------------------------------------------------------------
-- Deadlock Prevention
--------------------------------------------------------------------------------

||| Check if pipe might deadlock (both ends closed, data pending)
public export
mightDeadlock : TrackedPipe -> Bool
mightDeadlock tracked =
  tracked.state == Closed && tracked.bytesWritten > tracked.bytesRead

||| Safe pipe closure (drains pending data first)
public export
safeClosePipe : TrackedPipe -> PipeResult ()
safeClosePipe tracked =
  if mightDeadlock tracked
    then Err BrokenPipe
    else closePipe tracked.pipe.readEnd tracked.pipe.writeEnd

--------------------------------------------------------------------------------
-- Proofs
--------------------------------------------------------------------------------

-- ||| Proof: FIFO paths are absolute and contain no traversal
-- public export
-- fifoPathSafe : (path : String) -> (validated : String) ->
--                validateFifoPath path = Ok validated ->
--                (isAbsolute validated = True, containsTraversal validated = False)
-- -- Implementation deferred

||| Proof: Pipe creation produces distinct file descriptors
public export
pipeEndsDistinct : (p : PipePair) ->
                   So (p.readEnd /= p.writeEnd)
-- Implementation deferred

-- ||| Proof: Safe closure prevents deadlocks
-- public export
-- safeCloseNeverDeadlocks : (tracked : TrackedPipe) ->
--                           So (safeClosePipe tracked /= Err BrokenPipe) ->
--                           So (mightDeadlock tracked = False)
-- -- Implementation deferred

--------------------------------------------------------------------------------
-- Utilities
--------------------------------------------------------------------------------

||| Get friendly error message
public export
friendlyError : PipeError -> String
friendlyError (FifoExists path) = "FIFO already exists: " ++ path
friendlyError (FifoCreationFailed path reason) = "Failed to create FIFO at " ++ path ++ ": " ++ reason
friendlyError (PathTraversal path) = "Path isInfixOf traversal: " ++ path
friendlyError (InvalidPermissions perms) = "Invalid permissions: " ++ show perms
friendlyError (PipeCreationFailed reason) = "Failed to create pipe: " ++ reason
friendlyError BrokenPipe = "Broken pipe"
friendlyError WouldBlock = "Operation would block"
friendlyError ResourceExhausted = "Resource exhausted"
friendlyError (InvalidFileDescriptor fd) = "Invalid file descriptor: " ++ show fd
