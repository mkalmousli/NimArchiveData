# Package
version = "0.2.2"
author = "Knaque"
description = "A Nim implementation of the Stalin Sort algorithm."
license = "CC0-1.0"

# Deps
requires "nim >= 1.0.0"


srcDir = "src"