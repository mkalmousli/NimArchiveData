import std/os

import nimtk/all

let
  tk = newTk()
  root = tk.getRoot()

root.geometry("300x400")
root.title = "File & Directory Dialogs"

let
  openButton = root.newButton("Open File")
  saveButton = root.newButton("Save File")
  dirButton = root.newButton("Choose Directory")

openButton.pack(padx=30, pady=50)
saveButton.pack(padx=30, pady=50)
dirButton.pack(padx=30, pady=50)

openButton.setCommand() do (_: Widget):
  let files = root.getOpenFile(
    title = "Open a file",
    filetypes = @[
      ("Nim Source Files", @[".nimf", ".nim", ".nims", ".nimble"]),
      ("Stylesheets", @[".css", ".less", ".sass", ".scss", ".bass"]),
      ("Any File", @["*"])
    ],
    initialfile = currentSourcePath(),
    initialdir = currentSourcePath().parentDir(),
    multiple = true
  )

  if files.len < 1:
    return

  discard root.messageBox(
    title = "You opened a file!",
    message = "You opened " & files[0].splitPath().tail,
    detail = "Directory: " & files[0].parentDir().splitPath().tail
  )

saveButton.setCommand() do (_: Widget):
  let file = root.getSaveFile(
    title = "Open a file",
    filetypes = @[
      ("C/C++ Source Files", @[".c", ".cc", ".h", ".hh", ".cpp", ".hpp"]),
      ("Any File", @["*"])
    ],
    initialfile = currentSourcePath(),
    initialdir = currentSourcePath().parentDir(),
    confirmoverwrite = true
  )

  if file.len < 1:
    return

  discard root.messageBox(
    title = "You saved a file!",
    message = "You opened " & file.splitPath().tail,
    detail = "Directory: " & file.parentDir().splitPath().tail
  )

dirButton.setCommand() do (_: Widget):
  let dir = root.chooseDirectory(
    title = "Open a file",
    initialdir = currentSourcePath().parentDir(),
    mustexist = true
  )

  if dir.len < 1:
    return

  discard root.messageBox(
    title = "You chose a directory!",
    message = "Directory: " & dir.parentDir().splitPath().tail
  )

tk.mainloop()
