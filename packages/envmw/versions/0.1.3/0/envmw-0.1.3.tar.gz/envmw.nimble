# Package

version = "0.1.3"
author = "Pulux"
description = "Key-Value Service in RAM"
license = "MIT"
srcDir = "src"
bin = @["envmw"]


# Dependencies

requires "nim >= 2.0", "jsony", "mike >= 1.3.3", "octolog", "argparse"

task release, "Build for release":
  exec "nimble build -d:release --opt:speed -d:strip"

task debug, "Build for debug":
  exec "nimble build -d:debug --debugger:native --verbose -y"

task client, "Build Client":
  exec "nim c -d:ssl -d:release --opt:speed src/envmwc.nim"
