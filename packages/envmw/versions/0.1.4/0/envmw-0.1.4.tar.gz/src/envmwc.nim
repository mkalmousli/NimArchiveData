import strformat
import httpclient
import argparse
import jsony

type
  KV = object
    key: string
    value: string
    expire: float

var
  key: string
  value: string
  expire: float
  sep = ""
  url = ""
  host = "127.0.0.1"

var p = newParser:
  help("set, get, keys")
  option("-r", "--remote", default = some("http://127.0.0.1:6380"))
  flag("-d", "--debug")
  run:
    host = opts.remote
  command "keys":
    run:
      url = host & "/keys"

  command "set":
    help("set -e=,--expire= key value")
    arg("key")
    arg("value")
    option("-e", "--expire", default = some("0.0"))
    run:
      if opts.key[0] != '/':
        sep = "/"
      key = sep & opts.key
      value = opts.value
      expire = opts.expire.parseFloat()
      url = host & "/set"

  command "get":
    help("get key")
    arg("key")
    run:
      if opts.key[0] != '/':
        sep = "/"
      url = host & "/get" & sep & opts.key

try:
  let cl = newHttpClient()
  var opts = p.parse()
  p.run()
  if opts.debug:
    echo(fmt"{url=}, {key=}, {value=}")
  case opts.command:
    of "get":
      echo cl.getContent(url).strip()
    of "set":
      var data: KV
      data.key = key
      data.value = value
      data.expire = expire
      discard cl.postContent(url, body = data.toJson())
    of "keys":
      echo cl.getContent(url).strip()
      #except:
      #  quit(1)
    else:
      discard
  cl.close()
except ValueError:
  echo(p.help)
  quit(1)
except UsageError:
  echo(p.help)
  quit(2)
except ShortCircuit as e:
  echo(p.help)
  quit(3)
