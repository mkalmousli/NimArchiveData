import os
import std/[asyncdispatch, strutils, strformat, tables, base64, times]
import jsony
import mike
from std/posix import onSignal, SIGUSR2
import octolog
import argparse

type
  KV = object
    key: string
    value: string
    expire: float

var
  debugf = false
  iload = false

var p = newParser:
  help("InMemory DB")
  option("-b", "--bindAddr", default = some("127.0.0.1"))
  option("-p", "--port", default = some("6380"))
  option("-s", "--storePath", default = some("data"))
  flag("-d", "--debug")
  flag("-l", "--load")

try:
  var opts = p.parse()
  debugf = opts.debug
  iload = opts.load

  octologStart(usefilelogger = false)
  if fileExists("conf/app.json"):
    try:
      putEnv("ENVMW_W", readFile("conf/app.json"))
      if debugf:
        debug("use auth")
    except:
      delEnv("ENVMW_W")
  else:
    delEnv("ENVMW_W")

  proc saveState() =
    if dirExists(opts.storePath):
      for i in envPairs():
        if i.key.count("key_") == 1 or i.key.count("keyex_") == 1:
          let exkey = i.key.replace("key_", "keyex_")
          let name = fmt"{opts.storePath}/{i.key}"
          let exname = fmt"{opts.storePath}/{exkey}"
          if not existsEnv(exkey) and symlinkExists(exname):
            removeFile(exname)

          if symlinkExists(name):
            removeFile(name)
          try:
            createSymlink(i.value.encode(), name)
            info(fmt"save {i.key}")
          except:
            discard

  proc restoreState() =
    if dirExists(opts.storePath):
      for kind, path in walkDir(opts.storePath):
        if kind == pcLinkToFile:
          if path.count("key_") == 1 or path.count("keyex_") == 1:
            let value = expandSymlink(path).decode()
            let key = path.replace(fmt"{opts.storePath}/", "")
            putEnv(key, value)
            info(fmt"load: {key}")
    else:
      info("no state found")

  when not defined windows:
    onSignal(SIGUSR2):
      saveState()
      info(fmt"state saved on {opts.storePath}/")
    # not known on Win

  proc ctrlc() {.noconv.} =
    saveState()
    octologStop()
    quit(0)

  proc setKV(kvset: KV): int =
    var
      key: string = kvset.key.encode().replace("=", "-")
      value = kvset.value
      expire: bool = false
      exv: float
    if kvset.expire > 0:
      exv = epochTime() + kvset.expire
      expire = true
    else:
      expire = false
    if value != "":
      try:
        putEnv("key_" & key, value)
        let ckey = key.replace("-", "=")
        if debugf:
          debug(fmt"set {ckey.decode()} {key}")
        if expire:
          putEnv("keyex_" & key, $exv)
        else:
          if existsEnv("keyex_" & key):
            delEnv("keyex_" & key)
        result = 0
      except:
        result = 1
    else:
      result = 2

  if iload:
    restoreState()
  setControlCHook(ctrlc)

  "/ping" -> get:
    ctx.send "pong\n"

  "/get/^path" -> get:
    let key = ("/" & ctx.pathParams["path"]).replace(" ", "+").encode().replace(
        "=", "-")
    let ckey = key.replace("-", "=")

    if existsEnv("key_" & key):
      if existsEnv("keyex_" & key):
        let now = epochTime()
        let exv = getEnv("keyex_" & key).parseFloat()
        if now > exv:
          delEnv("key_" & key)
          delEnv("keyex_" & key)
          ctx.send "\n"
        else:
          if debugf:
            debug(fmt"get {ckey.decode()}")
          ctx.send getEnv("key_" & key) & "\n"
      else:
        if debugf:
          debug(fmt"get {ckey.decode()}")
        ctx.send getEnv("key_" & key) & "\n"
    else:
      ctx.send "\n"

  "/keys" -> get:
    var
      keys: seq[string]
    for i in envPairs():
      if i.key.count("key_") == 1:
        keys.add(i.key.replace("key_", "").replace("-", "=").decode())
    ctx.send jsony.toJson(keys) & "\n"

  "/set/:code" -> post:
    if existsEnv("ENVMW_W"):
      let wc = getEnv("ENVMW_W")
      try:
        let wconf = wc.fromJson(Table[string, string])
        let code = ctx.pathParams["code"]
        if (code in wconf) == false:
          if debugf:
            debug("auth fail for {code}")
          ctx.send Http401
        else:
          info("auth for {code}")
      except:
        ctx.send Http401
    else:
      discard

  "/admin" -> get(token: Header[string]):
    if existsEnv("ENVMW_W"):
      let wc = getEnv("ENVMW_W")
      try:
        let wconf = wc.fromJson(Table[string, string])
        if token in wconf:
          echo "found"
      except:
        discard
    var kvset: KV
    try:
      kvset = ctx.body.fromJson(KV)
    except:
      ctx.send Http400

    if kvset.key[0] != '/':
      ctx.send Http400
    let s = setKV(kvset)
    if s == 0:
      ctx.send Http201
    if s == 1:
      ctx.send Http403
    else:
      ctx.send Http501

  "/set" -> post:
    var kvset: KV
    try:
      kvset = ctx.body.fromJson(KV)
    except:
      ctx.send Http400

    if kvset.key[0] != '/':
      ctx.send Http400
    let s = setKV(kvset)
    if s == 0:
      ctx.send Http201
    if s == 1:
      ctx.send Http403
    else:
      ctx.send Http501
  run(port = opts.port.parseInt(), bindAddr = opts.bindAddr)
  octologStop()
except ValueError:
  echo(p.help)
  quit(1)
except UsageError:
  echo(p.help)
  quit(2)
except ShortCircuit:
  echo(p.help)
  quit(3)
