import strformat
import httpclient
import argparse
import jsony

type
  KV = object
    key: string
    value: string
    expire: float

var
  key: string
  value: string
  expire: float
  sep = ""
  url = ""
  host = "127.0.0.1"
  code = ""

var p = newParser:
  help("set, get, keys")
  option("-r", "--remote", default = some("http://127.0.0.1:6380"))
  option("-c", "--code", default = some(""))
  flag("-d", "--debug")
  flag("-f", "--flow")
  run:
    host = opts.remote
    if opts.code != "":
      code = fmt"/{opts.code}"
  command "keys":
    run:
      url = host & "/keys" & code

  command "set":
    help("set -e=,--expire= key value")
    arg("key")
    arg("value")
    option("-e", "--expire", default = some("0.0"))
    run:
      if opts.key[0] != '/':
        sep = "/"
      key = sep & opts.key
      value = opts.value
      expire = opts.expire.parseFloat()
      url = host & "/set" & code

  command "get":
    help("get key")
    arg("key")
    run:
      if opts.key[0] != '/':
        sep = "/"
      url = host & "/get" & code & sep & opts.key

try:
  let cl = newHttpClient()
  var opts = p.parse()
  p.run()
  if opts.debug:
    echo(fmt"{url=}, {key=}, {value=}")
  case opts.command:
    of "get":
      if not opts.flow:
        try:
          echo cl.getContent(url)
          cl.close()
        except HttpRequestError:
          quit(1)
      else:
        var rpo, rpn: string
        while true:
          try:
            rpn = cl.getContent(url)
            if rpn != rpo:
              rpo = rpn
              echo rpn
            sleep(100)
          except HttpRequestError:
            quit(1)
    of "set":
      var data: KV
      data.key = key
      data.value = value
      data.expire = expire
      try:
        discard cl.postContent(url, body = data.toJson())
      except HttpRequestError:
        quit(1)
    of "keys":
      try:
        echo cl.getContent(url)
      except HttpRequestError:
        quit(1)
    else:
      discard
  cl.close()
except ValueError as ve:
  echo(fmt"{ve.msg=}")
  # echo(p.help)
  quit(1)
except UsageError:
  echo(p.help)
  quit(2)
except ShortCircuit:
  echo(p.help)
  quit(3)
