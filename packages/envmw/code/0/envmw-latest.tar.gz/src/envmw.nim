import os
import std/[asyncdispatch, strutils, strformat, tables, base64, times]
import jsony
import mike
from std/posix import onSignal, SIGUSR2
import argparse

type
  KV = object
    key: string
    value: string
    expire: float

var
  debugf = false
  iload = false

var p = newParser:
  help("InMemory DB")
  option("-b", "--bindAddr", default = some("127.0.0.1"))
  option("-p", "--port", default = some("6380"))
  option("-s", "--storePath", default = some("data"))
  flag("-d", "--debug")
  flag("-l", "--load")

proc log(kind: string, msg: string) =
  if kind == "debug" and debugf:
    stderr.writeline(fmt"DEBUG {msg}")
  elif kind == "info":
    stderr.writeline(fmt"INFO {msg}")
  flushFile(stderr)
  
proc saveState(storePath: string) =
  if dirExists(storePath):
    for i in envPairs():
      if i.key.count("key_") == 1 or i.key.count("keyex_") == 1:
        let exkey = i.key.replace("key_", "keyex_")
        let name = fmt"{storePath}/{i.key}"
        let exname = fmt"{storePath}/{exkey}"
        if not existsEnv(exkey) and symlinkExists(exname):
          removeFile(exname)

        if symlinkExists(name):
          removeFile(name)
        try:
          createSymlink(i.value.encode(), name)
          log("info", fmt"save {i.key}")
        except:
          discard

proc restoreState(storePath: string) =
  if dirExists(storePath):
    for kind, path in walkDir(storePath):
      if kind == pcLinkToFile:
        if path.count("key_") == 1 or path.count("keyex_") == 1:
          let value = expandSymlink(path).decode()
          let key = path.replace(fmt"{storePath}/", "")
          putEnv(key, value)
          log("info", fmt"load: {key}")
  else:
    log("info", "no state found")

proc setKV(kvset: KV): int =
  var
    key: string = kvset.key.encode().replace("=", "-")
    value = kvset.value
    expire: bool = false
    exv: float
  if kvset.expire > 0:
    exv = epochTime() + kvset.expire
    expire = true
  else:
    expire = false
  if value != "":
    try:
      putEnv("key_" & key, value)
      let ckey = key.replace("-", "=")
      log("debug", fmt"set {ckey.decode()} {key}")
      if expire:
        putEnv("keyex_" & key, $exv)
      else:
        if existsEnv("keyex_" & key):
          delEnv("keyex_" & key)
      result = 0
    except:
      result = 1
  else:
    result = 2

proc getV(key: string): string =
  let ckey = key.replace("-", "=")

  if existsEnv("key_" & key):
    if existsEnv("keyex_" & key):
      let now = epochTime()
      let exv = getEnv("keyex_" & key).parseFloat()
      if now > exv:
        delEnv("key_" & key)
        delEnv("keyex_" & key)
        result = ""
      else:
        log("debug", fmt"get {ckey.decode()}")
        result = getEnv("key_" & key)
    else:
      log("debug", fmt"get {ckey.decode()}")
      result = getEnv("key_" & key)
  else:
    result = ""

proc genHttpCode(status: int): HttpCode =
  case status:
    of 0:
      result = Http201
    of 1:
      result = Http403
    of 2:
      result = Http401
    else:
      result = Http501

try:
  var opts = p.parse()
  debugf = opts.debug
  iload = opts.load

  if fileExists("conf/app.json"):
    try:
      putEnv("ENVMW_W", readFile("conf/app.json"))
      log("debug", "use auth")
    except:
      delEnv("ENVMW_W")
  else:
    delEnv("ENVMW_W")

  proc ctrlc() {.noconv.} =
    saveState(opts.storePath)
    quit(0)

  when not defined windows:
    onSignal(SIGUSR2):
      saveState(opts.storePath)
      log("info", fmt"state saved on {opts.storePath}/")
    # not known on Win

  if iload:
    restoreState(opts.storePath)
  setControlCHook(ctrlc)

  "/ping" -> get:
    ctx.send "pong\n"

  "/keys" -> get:
    try:
      let wc = getEnv("ENVMW_W")
      let wconf = wc.fromJson(Table[string, string])
      if wconf.len > 0:
        ctx.send Http401
        return
    except:
      discard
    var
      keys: seq[string]
    for i in envPairs():
      if i.key.count("key_") == 1:
        keys.add(i.key.replace("key_", "").replace("-", "=").decode())
    ctx.send jsony.toJson(keys) & "\n"

  "/keys/:code" -> get:
    var keys: seq[string]
    if existsEnv("ENVMW_W"):
      let wc = getEnv("ENVMW_W")
      try:
        let wconf = wc.fromJson(Table[string, string])
        let code = ctx.pathParams["code"]
        if (code in wconf) == false:
          ctx.send Http401
        else:
          for i in envPairs():
            if i.key.count("key_") == 1:
              keys.add(i.key.replace("key_", "").replace("-", "=").decode())
          ctx.send jsony.toJson(keys)
      except:
        ctx.send Http401
    else:
      for i in envPairs():
        if i.key.count("key_") == 1:
          keys.add(i.key.replace("key_", "").replace("-", "=").decode())
      ctx.send jsony.toJson(keys)

  "/get/^path" -> get:
    var key: string
    if existsEnv("ENVMW_W"):
      let code = ctx.pathParams["path"].replace(" ", "+").split("/")[0]
      let rkey = "/" & (ctx.pathParams["path"]).replace(" ", "+").split("/")[1 .. ^1].join("/")
      key = rkey.encode().replace("=", "-")
      log("debug", fmt"{code=}, {key=}, {rkey=}")
      let wc = getEnv("ENVMW_W")
      try:
        let wconf = wc.fromJson(Table[string, string])
        if (code in wconf) == false:
          log("debug", fmt"auth fail for {code}")
          ctx.send Http401
        else:
          log("debug", fmt"auth for {code=}, {key=}")
          ctx.send getV(key)
      except:
        ctx.send Http401
    else:
      key = ("/" & ctx.pathParams["path"]).replace(" ", "+").encode().replace(
        "=", "-")
      ctx.send getV(key)

  "/set" -> post:
    try:
      let wc = getEnv("ENVMW_W")
      let wconf = wc.fromJson(Table[string, string])
      if wconf.len > 0:
        ctx.send Http401
        return
    except:
      discard
    var kvset: KV
    try:
      kvset = ctx.body.fromJson(KV)
    except:
      ctx.send Http400

    if kvset.key[0] != '/':
      ctx.send Http400
    ctx.send genHttpCode(setKV(kvset))

  "/set/:code" -> post:
    if existsEnv("ENVMW_W"):
      let wc = getEnv("ENVMW_W")
      try:
        let wconf = wc.fromJson(Table[string, string])
        let code = ctx.pathParams["code"]
        if (code in wconf) == false:
          log("debug", fmt"auth fail for {code}")
          ctx.send Http401
        else:
          log("debug", fmt"auth for {code}")
          var kvset: KV
          try:
            kvset = ctx.body.fromJson(KV)
          except:
            ctx.send Http400

          if kvset.key[0] != '/':
            ctx.send Http400
          ctx.send genHttpCode(setKV(kvset))
      except:
        ctx.send Http401
    else:
      var kvset: KV
      try:
        kvset = ctx.body.fromJson(KV)
      except:
        ctx.send Http400

      if kvset.key[0] != '/':
        ctx.send Http400
      ctx.send genHttpCode(setKV(kvset))

  run(port = opts.port.parseInt(), bindAddr = opts.bindAddr)
except ValueError:
  echo(p.help)
  quit(1)
except UsageError:
  echo(p.help)
  quit(2)
except ShortCircuit:
  echo(p.help)
  quit(3)
