import os
import std/[times, asyncdispatch, strformat, strutils]
import httpclient, httpcore
import jsony

type
  KV = object
    key: string
    value: string
    expire: float

var
  data: KV
  t1, t2: float
  n = 500
  client: HttpClient

proc twrite(data: KV) {.async.} =
  let client = newAsyncHttpClient()
  #client.headers = newHttpHeaders({"Content-Type": "application/json"})
  discard await client.postContent("http://127.0.0.1:6380/set",
      body = data.toJson())
  client.close()


proc main() {.async.} =
  while true:
    t1 = epochTime()
    for i in 1 .. n:
      data.key = fmt"/app/part1/subpart3/key{i}"
      data.expire = i/10
      data.value = fmt"{epochTime()=}, {i=}"
      await twrite(data)
    t2 = epochTime()

    echo fmt"{(t2-t1)/n.toFloat() * 1000} ms/req"
    client = newHttpClient()
    let key = "/app/part1/subpart3/key10"
    echo client.getContent(fmt"http://127.0.0.1:6380/get{key}").strip()
    sleep(500)
    echo client.getContent(fmt"http://127.0.0.1:6380/get{key}").strip()
    sleep(600)
    assert client.getContent(fmt"http://127.0.0.1:6380/get{key}") == "\n"
    client.close()


when isMainModule:
  waitFor main()
