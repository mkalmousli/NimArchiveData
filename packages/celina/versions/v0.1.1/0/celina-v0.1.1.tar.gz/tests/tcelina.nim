# Test suite for main celina module

import std/[unittest, strutils, options]

import ../celina/async/async_backend
import ../celina {.all.}

suite "Celina Main Module Tests":
  suite "Basic API Tests":
    test "version returns valid version string":
      let ver = celinaVersion()
      check ver.len > 0
      check "." in ver # Should contain at least one dot for semantic versioning

    test "sync app creation":
      let app = newApp()
      check not app.isNil

    test "sync app with custom config":
      let config = AppConfig(
        title: "Test App",
        alternateScreen: false,
        mouseCapture: true,
        rawMode: false,
        windowMode: true,
        targetFps: 30,
      )
      let app = newApp(config)
      check not app.isNil

  suite "Cursor Control API":
    test "App cursor state initialization":
      var app = newApp()
      let (x, y) = app.getCursorPos()
      check x == -1 # Not set initially
      check y == -1
      check app.isCursorVisible() == false # Hidden by default

    test "setCursor with coordinates":
      var app = newApp()
      app.setCursor(10, 20)
      let (x, y) = app.getCursorPos()
      check x == 10
      check y == 20
      check app.isCursorVisible() == true # Should become visible

    test "setCursor with Position":
      var app = newApp()
      let pos = Position(x: 15, y: 25)
      app.setCursor(pos)
      let (x, y) = app.getCursorPos()
      check x == 15
      check y == 25
      check app.isCursorVisible() == true

    test "cursor visibility control":
      var app = newApp()

      # Initially hidden
      check app.isCursorVisible() == false

      # Show cursor
      app.showCursor()
      check app.isCursorVisible() == true

      # Hide cursor
      app.hideCursor()
      check app.isCursorVisible() == false

    test "cursor style setting":
      var app = newApp()

      # Test different cursor styles (mainly ensures the API works without errors)
      app.setCursorStyle(CursorStyle.BlinkingBlock)
      app.setCursorStyle(CursorStyle.SteadyUnderline)
      app.setCursorStyle(CursorStyle.BlinkingBar)

  suite "Async Backend Detection":
    test "hasAsyncSupport reflects backend status":
      when async_backend.asyncBackend == "none":
        check not hasAsyncSupport
      elif async_backend.asyncBackend == "asyncdispatch":
        check hasAsyncSupport
      elif async_backend.asyncBackend == "chronos":
        check hasAsyncSupport

    test "hasChronos reflects chronos backend":
      when async_backend.asyncBackend == "none":
        check not hasAsyncDispatch
        check not hasChronos
      elif async_backend.asyncBackend == "asyncdispatch":
        check hasAsyncDispatch
        check not hasChronos
      elif async_backend.asyncBackend == "chronos":
        check not hasAsyncDispatch
        check hasChronos

  suite "Type Exports":
    test "core types are available":
      # Test that essential types are exported
      let
        position = pos(10, 20)
        rectangle = rect(0, 0, 100, 50)
        dimensions = size(80, 40)
        color = Color.Red
        style = defaultStyle()

      check position.x == 10
      check rectangle.width == 100
      check dimensions.height == 40
      check color == Color.Red
      check style.fg.kind == Default # Use the style variable

    test "app config type is available":
      let config = AppConfig(
        title: "Export Test",
        alternateScreen: true,
        mouseCapture: false,
        rawMode: true,
        windowMode: false,
        targetFps: 60,
      )
      check config.title == "Export Test"
      check config.alternateScreen == true
      check config.targetFps == 60

  suite "Window Management API":
    test "app without window mode handles gracefully":
      let app = newApp()

      # These should not crash even without window mode
      let windowCount = app.getWindowCount()
      let windows = app.getWindows()
      let focusedId = app.getFocusedWindowId()

      check windowCount == 0
      check windows.len == 0
      check focusedId.isNone()

    test "enabling window mode":
      let app = newApp()
      app.enableWindowMode()

      # After enabling, should still work
      let windowCount = app.getWindowCount()
      check windowCount == 0

  suite "Event Handler Setup":
    test "event handler can be set":
      let app = newApp()
      var eventHandlerCalled = false

      app.onEvent proc(event: Event): bool =
        eventHandlerCalled = true
        return false

      # We can't easily trigger events in tests, but we can verify the handler is set
      check not app.isNil

    test "render handler can be set":
      let app = newApp()
      var renderHandlerCalled = false

      app.onRender proc(buffer: var Buffer) =
        renderHandlerCalled = true

      check not app.isNil

when hasAsyncSupport and hasChronos:
  suite "Async API Tests":
    test "async app creation":
      let app = newAsyncApp()
      check not app.isNil

    test "async app with config":
      let config = AsyncAppConfig(
        title: "Async Test App",
        alternateScreen: true,
        mouseCapture: false,
        rawMode: true,
        windowMode: false,
        targetFps: 30,
      )
      let app = newAsyncApp(config)
      check not app.isNil

    test "async performance monitor":
      let monitor = newAsyncPerfMonitor()
      check not monitor.isNil

      # Test initial values
      check monitor.getFPS() >= 0.0
      check monitor.getEventRate() >= 0.0

    test "async utility functions":
      # Test asyncToSync utility (with a simple future)
      proc simpleAsync(): Future[int] {.async.} =
        return 42

      let result = asyncToSync(simpleAsync())
      check result == 42

  suite "Backend Configuration":
    test "async backend is chronos when enabled":
      check hasAsyncSupport
      check hasAsyncDispatch or hasChronos

suite "Integration Tests":
  test "quickRun function signature":
    # Test that quickRun exists and has correct signature
    # We can't actually run it in tests, but we can verify it compiles

    # This should compile without errors
    when declared(quickRun):
      check true

      # Test that the function type matches expected signature
      proc testEventHandler(event: Event): bool =
        false

      proc testRenderHandler(buffer: var Buffer) =
        discard

      # Verify the handlers have correct types (compilation check)
      let _ = testEventHandler
      let _ = testRenderHandler
    else:
      fail("quickRun should be available")

  suite "Module Documentation":
    test "version is semantic":
      let ver = celinaVersion()
      let parts = ver.split('.')
      check parts.len >= 2 # At least major.minor

      # Check that parts are numeric (or at least start with numbers)
      for part in parts:
        check part.len > 0
        check part[0].isDigit()

  suite "Error Handling":
    test "app creation doesn't crash":
      # Test multiple app creations
      for i in 0 .. 2:
        let app = newApp()
        check not app.isNil

    test "window operations on non-window app":
      let app = newApp()

      # These operations should be safe even without window mode
      let info = app.getWindowInfo(WindowId(1))
      check info.isNone()

      let handled = app.handleWindowEvent(Event(kind: EventKind.Unknown))
      check handled == false

  suite "FPS Control API":
    test "default FPS is 60":
      let app = newApp()
      check app.getTargetFps() == 60

    test "FPS can be set and retrieved":
      let app = newApp()
      app.setTargetFps(30)
      check app.getTargetFps() == 30

      app.setTargetFps(120)
      check app.getTargetFps() == 120

    test "FPS validation - valid range":
      let app = newApp()

      # Test valid values
      app.setTargetFps(1)
      check app.getTargetFps() == 1

      app.setTargetFps(60)
      check app.getTargetFps() == 60

      app.setTargetFps(120)
      check app.getTargetFps() == 120

    test "FPS validation - invalid range throws exception":
      let app = newApp()

      # Test invalid values
      expect(ValueError):
        app.setTargetFps(0)

      expect(ValueError):
        app.setTargetFps(-10)

      expect(ValueError):
        app.setTargetFps(121)

      expect(ValueError):
        app.setTargetFps(1000)

    test "getCurrentFps returns non-negative value":
      let app = newApp()
      let fps = app.getCurrentFps()
      check fps >= 0.0

    test "AppConfig accepts targetFps":
      let config = AppConfig(title: "FPS Test", targetFps: 45)
      let app = newApp(config)
      check app.getTargetFps() == 45

    test "frame timeout calculation":
      let app = newApp()

      # Test different FPS values and their expected timeouts
      app.setTargetFps(60)
      # 1000ms / 60fps = 16.67ms ≈ 16ms (integer division)
      check app.getTargetFps() == 60

      app.setTargetFps(30)
      # 1000ms / 30fps = 33.33ms ≈ 33ms
      check app.getTargetFps() == 30

      app.setTargetFps(120)
      # 1000ms / 120fps = 8.33ms ≈ 8ms
      check app.getTargetFps() == 120

    test "default FPS is applied when not specified in config":
      # Test that config without targetFps uses default 60 FPS
      let configWithoutFps = AppConfig(title: "No FPS Test")
      let app1 = newApp(configWithoutFps)
      check app1.getTargetFps() == 60 # Should use default

      # Test that newApp() without config uses default
      let app2 = newApp()
      check app2.getTargetFps() == 60 # Should use default
