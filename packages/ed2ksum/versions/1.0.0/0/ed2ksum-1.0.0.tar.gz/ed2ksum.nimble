# Package

version       = "1.0.0"
author        = "Mark Glines"
description   = "ED2Ksum hash calculation"
license       = "MIT"
srcDir        = "src"
installExt    = @["nim"]
bin           = @["ed2ksum"]


# Dependencies

requires "nim >= 2.2.0"
requires "md4 >= 1.0.0"
requires "malebolgia >= 1.3.2"
