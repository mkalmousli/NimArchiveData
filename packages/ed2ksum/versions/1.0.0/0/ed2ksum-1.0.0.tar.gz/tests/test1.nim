import std/[files, paths, strformat, syncio, tempfiles, unittest]

include ed2ksum

type hash_testcase = tuple
  result: string
  value: char
  flavors: seq[ed2kFlavor]
  count: int64

const cases: seq[hash_testcase] = @[
  ( result: "021040415a5881fd1776f38cdb61cdba", value: char(0x11), flavors: @[ed2kRed, ed2kBlue], count: 1 ),
  ( result: "dfb9d81cfefc58e3339a9d62ec836fbd", value: char(0x22), flavors: @[ed2kRed, ed2kBlue], count: 128 ),
  ( result: "88991e8799418c003d5867a6672e3d36", value: char(0x33), flavors: @[ed2kRed, ed2kBlue], count: 20479 ),
  ( result: "516970edb3181667fa6d4c6e68eb044a", value: char(0x44), flavors: @[ed2kRed, ed2kBlue], count: 20480 ),
  ( result: "3e77bd5a4d3d77912f3b1c484865cd15", value: char(0x55), flavors: @[ed2kRed, ed2kBlue], count: 20481 ),
  ( result: "a17c2d81a094866bd1ab9cceddfd90f4", value: char(0x66), flavors: @[ed2kRed, ed2kBlue], count: 9727999 ),
  ( result: "1a806d0b52b735530e336327e874f81a", value: char(0x77), flavors: @[ed2kRed          ], count: 9728000 ),
  ( result: "70afa7b3e3a3af3722b2af9bd45af22c", value: char(0x77), flavors: @[         ed2kBlue], count: 9728000 ),
  ( result: "24980cc0bed565c979df90ca841fd1da", value: char(0x88), flavors: @[ed2kRed, ed2kBlue], count: 9728001 ),
  ( result: "e4c8cefbd2476d4c73103db526dc1a9b", value: char(0x99), flavors: @[ed2kRed, ed2kBlue], count: 19455999 ),
  ( result: "0101ae3b722e2ce7a3200ba1df1567bd", value: char(0xaa), flavors: @[ed2kRed          ], count: 19456000 ),
  ( result: "55c7bb8e8ba71165535406e13658336c", value: char(0xaa), flavors: @[         ed2kBlue], count: 19456000 ),
  ( result: "9878cc3fceb6636cc37b665efc448bb3", value: char(0xbb), flavors: @[ed2kRed, ed2kBlue], count: 19456001 ),
]

suite "fencepost tests":
  for (expected, value, flavors, count) in cases:

    # generate a temp file
    var (f, fn) = createTempFile("ed2k_", ".dat")
    for i in 0 ..< count:
      f.write(value)
    f.close()

    for flavor in flavors:
      test fmt"value={int(value):#x} flavor={flavor} count={count:#x}":

        # hash it
        var ctx: ED2K_CTX
        ctx = NewED2K(fn, flavor=flavor)
        ctx.Run_singlethreaded()
        let rawoutput = ctx.Final()
        let hexoutput = toLowerAscii(map(rawoutput, proc(x: byte): string = toHex(x)).join)
        check(hexoutput == expected)

    # clean it up
    removeFile(Path(fn))