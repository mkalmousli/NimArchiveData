# Copyright © 2025 Mark Glines
# License: MIT

## This is a Nim implementation of ed2ksum.
## It's mostly useful for identifying large media files for use with online
## databases, like [anidb](https://anidb.net).
##
## It uses a pure-Nim MD4 library under the hood.
## The output is an array of 16 bytes.
## It operates on blocks of 9728000 bytes.
## Unlike most hash algorithms, the blocks can be hashed in parallel, which
## is nice when processing large media files.
##
## This can be installed as a library and as a command-line tool.  The command-
## line tool works a lot like `md5sum`, `sha256sum`, etc.  Give it some filenames
## and it'll hash the heck outta 'em.  Give it nothing and it'll read from stdin
## (in single-threaded mode).
##
## There are two flavors of algorithm, depending on a subtle difference in
## behavior when the input file is an exact multiple of the block size.
## This library supports both flavors, defaulting to the "blue" flavor.
## See [this anidb wiki page](https://wiki.anidb.net/Ed2k-hash) for details.
##
## Disclaimers:
## * As far as I know, the ED2K hash was never intended to be a secure cryptographic hash, it's meant to identify media files.
## * It's based on MD4, which is kinda old, and is also not considered a secure cryptographic hash nowadays.
## * The unpredictability of its output should not be relied upon for security purposes.
## * This library makes no attempt to protect your data against side-channel attacks, or anything else, really.


import std/[math, sequtils, strformat, strutils, syncio]
import md4

type ed2kFlavor = enum
    ed2kBlue, ed2kRed

const chunksize = 9728000
const bufsize = 20480

type ED2K_CTX = tuple
    fn: string
    flavor: ed2kFlavor
    fsize: int64
    sums: seq[array[16, byte]]

proc NewED2K*(fn: string, flavor: ed2kFlavor = ed2kBlue): ED2K_CTX =
    ## set up a context for calculating a file's ed2k sum.
    ## If fn is '-', you should call Run_stdin to read data from stdin.
    if fn != "-":
        # ensure file exists and is readable
        var f = open(fn, mode = fmRead)
        result.fsize = getFileSize(f)
        close(f)
    result.fn = fn
    result.flavor = flavor

proc Run_singlethreaded*(ctx: var ED2K_CTX) =
    ## stupid single-threaded version that only opens the file once
    var i: int64
    var buffer: array[bufsize, byte]
    var f = open(ctx.fn, mode = fmRead)
    try:
        while i < ctx.fsize:
            var md4ctx = NewMD4()
            let nextchunk = min(i + chunksize, ctx.fsize)
            while i < nextchunk:
                # echo fmt"  offset {i}"
                let thissize = min(bufsize, ctx.fsize - i)
                let rv = f.readBuffer(buffer.addr, thissize)
                md4ctx.Update(buffer[0..rv-1])
                if rv < thissize:
                    echo fmt"underrun at offset {i} (rv is {rv})"
                    # syncio shouldn't have short reads
                    assert i + thissize >= ctx.fsize
                    break
                i += thissize
            ctx.sums.add(md4ctx.Final())
            i = nextchunk
    finally:
        f.close()

proc Run_stdin*(ctx: var ED2K_CTX) =
    ## stupid single-threaded version that reads from stdin
    var i: int64
    var buffer: array[bufsize, byte]
    var is_eof = false
    var f = stdin
    while not is_eof:
        var md4ctx = NewMD4()
        let thischunk = i
        let nextchunk = i + chunksize
        block chunk:
            while i < nextchunk:
                # echo fmt"  offset {i}"
                let thissize = bufsize
                let rv = f.readBuffer(buffer.addr, thissize)
                if rv == 0 and i == thischunk:
                    # EOF, and filesize is a multiple of chunksize
                    # the md4 is empty, don't emit it.
                    is_eof = true
                    break chunk
                md4ctx.Update(buffer[0..rv-1])
                if rv < thissize:
                    # normal EOF
                    # the md4 hash got some data, process it.
                    is_eof = true
                    break
                i += thissize
            ctx.sums.add(md4ctx.Final())
            i = nextchunk

when compileOption("threads"):
    import malebolgia

    proc Run_one_block(fn: string, fsize, idx, off: int64): array[16, byte] =
        # echo "Run_one_block"
        # stupid single-threaded version that uses a single file handle
        var i = off
        let nextchunk = min(i + chunksize, fsize)

        var f = open(fn, mode = fmRead)
        try:
            f.setFilePos(i, relativeTo = fspSet)

            var md4ctx = NewMD4()
            var buffer: array[bufsize, byte]
            while i < nextchunk:
                let thissize = min(bufsize, fsize - i)
                let rv = f.readBuffer(buffer.addr, thissize)
                md4ctx.Update(buffer[0..rv-1])
                if rv < thissize:
                    # syncio shouldn't have short reads
                    assert i + thissize >= fsize
                    break
                i += thissize
            return md4ctx.Final()
        finally:
            f.close()

    proc Run_threaded*(ctx: var ED2K_CTX) =
        ## fancy multi-threaded version that opens the file once per chunk
        let nrounds = int(ceil(ctx.fsize / chunksize))
        var m = createMaster()

        var sums = newSeq[array[16, byte]](nrounds)

        m.awaitAll:
            for i in 0 ..< nrounds:
                m.spawn Run_one_block(ctx.fn, ctx.fsize, i, i * chunksize) -> sums[i]

        for i in 0 ..< nrounds:
            ctx.sums.add(sums[i])


proc Final*(ctx: var ED2K_CTX): array[16, byte] =
    # echo fmt"Final: len(sums) is {len(ctx.sums)}"

    if ctx.flavor == ed2kRed:
        if ctx.fsize > 0:
            if ctx.fsize mod chunksize == 0:
                # red code appends the md4sum of an empty block in this case.
                var md4 = NewMD4()
                ctx.sums.add(md4.Final())

    if len(ctx.sums) == 1:
        return ctx.sums[0]

    var md4ctx = NewMD4()
    for sum in ctx.sums:
        # let hexstr = toLowerAscii(map(sum, proc(x: byte): string = toHex(x)).join)
        # md4ctx.Update(hexstr)
        md4ctx.Update(sum)
    return md4ctx.Final()

when isMainModule:
    # as a command line tool, generate hashes of the given filenames.
    import std/[cmdline]
    var params = commandLineParams()

    if len(params) < 1:
        # read from stdin by default
        params = @["-"]

    for fn in commandLineParams():
        var ctx: ED2K_CTX
        ctx = NewED2K(fn)
        let is_stdin = fn == "-"
        if is_stdin:
            ctx.Run_stdin()
        else:
            when compileOption("threads"):
                ctx.Run_threaded()
            else:
                ctx.Run_singlethreaded()
        let rawoutput = ctx.Final()
        let hexoutput = toLowerAscii(map(rawoutput, proc(x: byte): string = toHex(x)).join)
        echo fmt"{hexoutput}  {fn}"
