import
  std/[unittest, options, strutils, tables, os, math, deques, importutils, net, json]
from std/times import
  DateTime, dateTime, mMar, mJun, mJan, mDec, utc, year, month, monthday, hour, minute,
  second, toTime, toUnix, nanosecond

import ../async_postgres/[async_backend, pg_protocol, pg_types, pg_replication]

when hasChronos:
  import std/sets

import ../async_postgres/pg_client {.all.}
import ../async_postgres/pg_pool {.all.}
import ../async_postgres/pg_connection {.all.}

privateAccess(PgConnection)

const
  PgHost = "127.0.0.1"
  PgPort = 15432
  PgUser = "test"
  PgPassword = "test"
  PgDatabase = "test"

proc plainConfig(): ConnConfig =
  ConnConfig(
    host: PgHost,
    port: PgPort,
    user: PgUser,
    password: PgPassword,
    database: PgDatabase,
    sslMode: sslDisable,
  )

proc sslConfig(mode: SslMode = sslRequire): ConnConfig =
  ConnConfig(
    host: PgHost,
    port: PgPort,
    user: PgUser,
    password: PgPassword,
    database: PgDatabase,
    sslMode: mode,
  )

proc loadCaCert(): string =
  let certsDir = currentSourcePath().parentDir / "certs"
  readFile(certsDir / "ca.crt")

proc loadWrongCaCert(): string =
  let certsDir = currentSourcePath().parentDir / "certs"
  readFile(certsDir / "wrong_ca.crt")

proc toBytes(s: string): seq[byte] =
  @(s.toOpenArrayByte(0, s.high))

proc toString(b: seq[byte]): string =
  result = newString(b.len)
  if b.len > 0:
    copyMem(addr result[0], addr b[0], b.len)

suite "E2E: Basic Connection":
  test "plain connection and close":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      doAssert conn.state == csReady
      doAssert conn.sslEnabled == false
      await conn.close()
      doAssert conn.state == csClosed

    waitFor t()

  test "connect with DSN string":
    proc t() {.async.} =
      let dsn =
        "postgresql://" & PgUser & ":" & PgPassword & "@" & PgHost & ":" & $PgPort & "/" &
        PgDatabase & "?sslmode=disable"
      let conn = await connect(dsn)
      doAssert conn.state == csReady
      let res = await conn.simpleQuery("SELECT 1")
      doAssert res[0].rows[0][0].get().toString() == "1"
      await conn.close()
      doAssert conn.state == csClosed

    waitFor t()

  test "connect with keyword=value DSN string":
    proc t() {.async.} =
      let dsn =
        "host=" & PgHost & " port=" & $PgPort & " user=" & PgUser & " password=" &
        PgPassword & " dbname=" & PgDatabase & " sslmode=disable"
      let conn = await connect(dsn)
      doAssert conn.state == csReady
      await conn.close()

    waitFor t()

  test "server parameters available":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      doAssert conn.serverParams.hasKey("server_version")
      doAssert conn.serverParams.hasKey("server_encoding")
      await conn.close()

    waitFor t()

suite "E2E: ConnConfig Options":
  test "applicationName is sent to server":
    proc t() {.async.} =
      var cfg = plainConfig()
      cfg.applicationName = "chronos-pg-test"
      let conn = await connect(cfg)
      let res = await conn.simpleQuery("SHOW application_name")
      doAssert res[0].rows[0][0].get().toString() == "chronos-pg-test"
      await conn.close()

    waitFor t()

  test "extraParams are sent to server":
    proc t() {.async.} =
      var cfg = plainConfig()
      cfg.extraParams = @[("application_name", "from-extra")]
      let conn = await connect(cfg)
      let res = await conn.simpleQuery("SHOW application_name")
      doAssert res[0].rows[0][0].get().toString() == "from-extra"
      await conn.close()

    waitFor t()

  test "connectTimeout raises on unreachable host":
    proc t() {.async.} =
      var cfg = plainConfig()
      cfg.host = "192.0.2.1" # TEST-NET, non-routable
      cfg.connectTimeout = milliseconds(200)
      var raised = false
      try:
        let conn = await connect(cfg)
        await conn.close()
      except AsyncTimeoutError:
        raised = true
      doAssert raised

    waitFor t()

  test "connectTimeout does not interfere with normal connection":
    proc t() {.async.} =
      var cfg = plainConfig()
      cfg.connectTimeout = seconds(10)
      let conn = await connect(cfg)
      doAssert conn.state == csReady
      await conn.close()

    waitFor t()

suite "E2E: Simple Query Protocol":
  test "SELECT 1":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let results = await conn.simpleQuery("SELECT 1 AS num")
      doAssert results.len == 1
      doAssert results[0].fields.len == 1
      doAssert results[0].fields[0].name == "num"
      doAssert results[0].rows.len == 1
      doAssert results[0].rows[0][0].get().toString() == "1"
      await conn.close()

    waitFor t()

  test "multiple rows with generate_series":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let results = await conn.simpleQuery("SELECT generate_series(1,3)")
      doAssert results.len == 1
      doAssert results[0].rows.len == 3
      doAssert results[0].rows[0][0].get().toString() == "1"
      doAssert results[0].rows[1][0].get().toString() == "2"
      doAssert results[0].rows[2][0].get().toString() == "3"
      await conn.close()

    waitFor t()

  test "empty query":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let results = await conn.simpleQuery("")
      doAssert results.len == 1
      doAssert results[0].fields.len == 0
      doAssert results[0].rows.len == 0
      doAssert results[0].commandTag == ""
      await conn.close()

    waitFor t()

  test "invalid SQL raises PgError":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      var raised = false
      try:
        discard await conn.simpleQuery("INVALID SQL STATEMENT")
      except PgError:
        raised = true
      doAssert raised
      doAssert conn.state == csReady
      await conn.close()

    waitFor t()

  test "invalid SQL raises PgQueryError with SQLSTATE":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      var sqlState = ""
      var severity = ""
      try:
        discard await conn.simpleQuery("SELECT FROM nonexistent_table_xyz")
      except PgQueryError as e:
        sqlState = e.sqlState
        severity = e.severity
      doAssert sqlState.len == 5, "expected 5-char SQLSTATE, got: " & sqlState
      doAssert severity == "ERROR"
      doAssert conn.state == csReady
      await conn.close()

    waitFor t()

suite "E2E: Extended Query Protocol":
  test "exec CREATE TABLE and INSERT":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_e2e")
      let createTag = await conn.exec(
        "CREATE TABLE test_e2e (id serial PRIMARY KEY, name text NOT NULL)"
      )
      doAssert "CREATE TABLE" in createTag
      let insertTag = await conn.exec(
        "INSERT INTO test_e2e (name) VALUES ($1)", @[toPgParam("alice")]
      )
      doAssert "INSERT" in insertTag
      discard await conn.exec("DROP TABLE test_e2e")
      await conn.close()

    waitFor t()

  test "query with parameters":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_e2e_q")
      discard
        await conn.exec("CREATE TABLE test_e2e_q (id serial PRIMARY KEY, name text)")
      discard await conn.exec(
        "INSERT INTO test_e2e_q (name) VALUES ($1), ($2)",
        @[toPgParam("alice"), toPgParam("bob")],
      )
      let res = await conn.query(
        "SELECT name FROM test_e2e_q WHERE name = $1", @[toPgParam("bob")]
      )
      doAssert res.rows.len == 1
      doAssert res.rows[0][0].get().toString() == "bob"
      discard await conn.exec("DROP TABLE test_e2e_q")
      await conn.close()

    waitFor t()

  test "prepare, execute, and close statement":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_e2e_ps")
      discard
        await conn.exec("CREATE TABLE test_e2e_ps (id serial PRIMARY KEY, val text)")
      discard await conn.exec(
        "INSERT INTO test_e2e_ps (val) VALUES ($1), ($2)",
        @[toPgParam("x"), toPgParam("y")],
      )

      let stmt =
        await conn.prepare("my_stmt", "SELECT val FROM test_e2e_ps WHERE val = $1")
      doAssert stmt.name == "my_stmt"
      doAssert stmt.fields.len == 1
      doAssert stmt.paramOids.len == 1

      let res = await stmt.execute(@[toPgParam("x")])
      doAssert res.rows.len == 1
      doAssert res.rows[0][0].get().toString() == "x"

      await stmt.close()

      # Connection still usable after statement close
      let r2 = await conn.query("SELECT 1 AS check_col")
      doAssert r2.rows.len == 1

      discard await conn.exec("DROP TABLE test_e2e_ps")
      await conn.close()

    waitFor t()

suite "E2E: SSL Connection":
  test "sslRequire connects with SSL":
    proc t() {.async.} =
      let conn = await connect(sslConfig(sslRequire))
      doAssert conn.state == csReady
      doAssert conn.sslEnabled == true
      await conn.close()

    waitFor t()

  test "sslPrefer connects with SSL when server supports it":
    proc t() {.async.} =
      let conn = await connect(sslConfig(sslPrefer))
      doAssert conn.state == csReady
      doAssert conn.sslEnabled == true
      await conn.close()

    waitFor t()

  test "sslDisable connects without SSL":
    proc t() {.async.} =
      let conn = await connect(sslConfig(sslDisable))
      doAssert conn.state == csReady
      doAssert conn.sslEnabled == false
      await conn.close()

    waitFor t()

  test "sslAllow connects without SSL when server accepts plaintext":
    proc t() {.async.} =
      let conn = await connect(sslConfig(sslAllow))
      doAssert conn.state == csReady
      doAssert conn.sslEnabled == false
      await conn.close()

    waitFor t()

  test "query over SSL connection":
    proc t() {.async.} =
      let conn = await connect(sslConfig(sslRequire))
      let results = await conn.simpleQuery("SELECT 42 AS answer")
      doAssert results[0].rows[0][0].get().toString() == "42"
      await conn.close()

    waitFor t()

suite "E2E: SSL Verification":
  test "sslVerifyCa connects with CA verification":
    proc t() {.async.} =
      let conn = await connect(
        ConnConfig(
          host: PgHost,
          port: PgPort,
          user: PgUser,
          password: PgPassword,
          database: PgDatabase,
          sslMode: sslVerifyCa,
          sslRootCert: loadCaCert(),
        )
      )
      doAssert conn.state == csReady
      doAssert conn.sslEnabled == true
      await conn.close()

    waitFor t()

  test "sslVerifyFull connects with full verification":
    proc t() {.async.} =
      # Use localhost (matches SAN DNS:localhost in server cert)
      let conn = await connect(
        ConnConfig(
          host: "localhost",
          port: PgPort,
          user: PgUser,
          password: PgPassword,
          database: PgDatabase,
          sslMode: sslVerifyFull,
          sslRootCert: loadCaCert(),
        )
      )
      doAssert conn.state == csReady
      doAssert conn.sslEnabled == true
      await conn.close()

    waitFor t()

  test "sslVerifyCa fails with wrong CA":
    proc t() {.async.} =
      var raised = false
      try:
        let conn = await connect(
          ConnConfig(
            host: PgHost,
            port: PgPort,
            user: PgUser,
            password: PgPassword,
            database: PgDatabase,
            sslMode: sslVerifyCa,
            sslRootCert: loadWrongCaCert(),
          )
        )
        await conn.close()
      except CatchableError:
        raised = true
      doAssert raised

    waitFor t()

  test "sslVerifyFull fails with wrong CA":
    proc t() {.async.} =
      var raised = false
      try:
        let conn = await connect(
          ConnConfig(
            host: "localhost",
            port: PgPort,
            user: PgUser,
            password: PgPassword,
            database: PgDatabase,
            sslMode: sslVerifyFull,
            sslRootCert: loadWrongCaCert(),
          )
        )
        await conn.close()
      except CatchableError:
        raised = true
      doAssert raised

    waitFor t()

  test "query over sslVerifyCa connection":
    proc t() {.async.} =
      let conn = await connect(
        ConnConfig(
          host: PgHost,
          port: PgPort,
          user: PgUser,
          password: PgPassword,
          database: PgDatabase,
          sslMode: sslVerifyCa,
          sslRootCert: loadCaCert(),
        )
      )
      let results = await conn.simpleQuery("SELECT 42 AS answer")
      doAssert results[0].rows[0][0].get().toString() == "42"
      await conn.close()

    waitFor t()

  test "query over sslVerifyFull connection":
    proc t() {.async.} =
      let conn = await connect(
        ConnConfig(
          host: "localhost",
          port: PgPort,
          user: PgUser,
          password: PgPassword,
          database: PgDatabase,
          sslMode: sslVerifyFull,
          sslRootCert: loadCaCert(),
        )
      )
      let results = await conn.simpleQuery("SELECT 42 AS answer")
      doAssert results[0].rows[0][0].get().toString() == "42"
      await conn.close()

    waitFor t()

suite "E2E: Authentication":
  test "valid credentials succeed":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      doAssert conn.state == csReady
      await conn.close()

    waitFor t()

  test "wrong password raises PgError":
    proc t() {.async.} =
      let badConfig = ConnConfig(
        host: PgHost,
        port: PgPort,
        user: PgUser,
        password: "wrong_password",
        database: PgDatabase,
        sslMode: sslDisable,
      )
      var raised = false
      try:
        let conn = await connect(badConfig)
        await conn.close()
      except PgError:
        raised = true
      doAssert raised

    waitFor t()

suite "E2E: Connection Pool":
  test "basic acquire and release":
    proc t() {.async.} =
      let pool =
        await newPool(PoolConfig(connConfig: plainConfig(), minSize: 1, maxSize: 3))
      let conn = await pool.acquire()
      doAssert conn.state == csReady
      conn.release()
      await pool.close()

    waitFor t()

  test "withConnection template":
    proc t() {.async.} =
      let pool =
        await newPool(PoolConfig(connConfig: plainConfig(), minSize: 1, maxSize: 3))
      pool.withConnection(conn):
        let results = await conn.simpleQuery("SELECT 1")
        doAssert results.len == 1
      await pool.close()

    waitFor t()

  test "multiple concurrent acquires":
    proc t() {.async.} =
      let pool =
        await newPool(PoolConfig(connConfig: plainConfig(), minSize: 1, maxSize: 3))
      let c1 = await pool.acquire()
      let c2 = await pool.acquire()
      let c3 = await pool.acquire()
      doAssert c1.state == csReady
      doAssert c2.state == csReady
      doAssert c3.state == csReady
      c1.release()
      c2.release()
      c3.release()
      await pool.close()

    waitFor t()

  test "maxLifetime recycles connections":
    proc t() {.async.} =
      let pool = await newPool(
        PoolConfig(
          connConfig: plainConfig(),
          minSize: 1,
          maxSize: 3,
          maxLifetime: milliseconds(500),
          maintenanceInterval: milliseconds(100),
        )
      )

      # Get the initial connection and remember its pid
      let conn1 = await pool.acquire()
      let pid1 = conn1.pid
      doAssert conn1.state == csReady
      conn1.release()

      # Wait for maxLifetime to expire
      await sleepAsync(milliseconds(600))

      # Maintenance should have closed the expired connection
      # Next acquire should create a new one
      let conn2 = await pool.acquire()
      doAssert conn2.state == csReady
      # The new connection should be different (different pid from server)
      doAssert conn2.pid != pid1
      conn2.release()

      await pool.close()

    waitFor t()

  test "idleTimeout removes unused connections":
    proc t() {.async.} =
      let pool = await newPool(
        PoolConfig(
          connConfig: plainConfig(),
          minSize: 0,
          maxSize: 3,
          idleTimeout: milliseconds(200),
          maintenanceInterval: milliseconds(100),
        )
      )

      # Create and release a connection so it sits idle
      let conn = await pool.acquire()
      doAssert conn.state == csReady
      conn.release()

      # Wait for idleTimeout + maintenance cycle
      await sleepAsync(milliseconds(500))

      # Pool should have cleaned up idle connections
      doAssert pool.idleCount == 0

      await pool.close()

    waitFor t()

  test "idleTimeout respects minSize":
    proc t() {.async.} =
      let pool = await newPool(
        PoolConfig(
          connConfig: plainConfig(),
          minSize: 2,
          maxSize: 3,
          idleTimeout: milliseconds(200),
          maintenanceInterval: milliseconds(100),
        )
      )

      # Create 3 connections and release them all
      let c1 = await pool.acquire()
      let c2 = await pool.acquire()
      let c3 = await pool.acquire()
      c1.release()
      c2.release()
      c3.release()
      doAssert pool.idleCount == 3

      # Wait for idleTimeout + maintenance cycles
      await sleepAsync(milliseconds(500))

      # Should shrink to minSize, not below
      doAssert pool.idleCount == 2

      await pool.close()

    waitFor t()

  test "acquire skips expired connections without waiting for maintenance":
    proc t() {.async.} =
      let pool = await newPool(
        PoolConfig(
          connConfig: plainConfig(),
          minSize: 1,
          maxSize: 3,
          maxLifetime: milliseconds(300),
          maintenanceInterval: seconds(60), # long interval so maintenance won't run
        )
      )

      let conn1 = await pool.acquire()
      let pid1 = conn1.pid
      conn1.release()

      # Wait for maxLifetime to expire
      await sleepAsync(milliseconds(400))

      # Maintenance hasn't run (60s interval), but acquire should skip expired
      let conn2 = await pool.acquire()
      doAssert conn2.state == csReady
      doAssert conn2.pid != pid1
      conn2.release()

      await pool.close()

    waitFor t()

  test "recycled connection is fully functional":
    proc t() {.async.} =
      let pool = await newPool(
        PoolConfig(
          connConfig: plainConfig(),
          minSize: 1,
          maxSize: 3,
          maxLifetime: milliseconds(300),
          maintenanceInterval: milliseconds(100),
        )
      )

      let conn1 = await pool.acquire()
      conn1.release()

      # Wait for maxLifetime to expire and maintenance to clean up
      await sleepAsync(milliseconds(500))

      # New connection after recycle should execute queries correctly
      pool.withConnection(conn):
        let res = await conn.simpleQuery("SELECT 42 AS answer")
        doAssert res.len == 1
        doAssert res[0].rows[0][0].get().toString() == "42"

      await pool.close()

    waitFor t()

  test "released connection is reused":
    proc t() {.async.} =
      let pool = await newPool(
        PoolConfig(
          connConfig: plainConfig(),
          minSize: 0,
          maxSize: 3,
          idleTimeout: minutes(10),
          maintenanceInterval: seconds(30),
        )
      )

      let conn1 = await pool.acquire()
      let pid1 = conn1.pid
      conn1.release()

      # Immediate re-acquire should return the same connection
      let conn2 = await pool.acquire()
      doAssert conn2.pid == pid1
      conn2.release()

      await pool.close()

    waitFor t()

suite "E2E: Pool Extended Query":
  test "pool.exec creates table":
    proc t() {.async.} =
      let pool =
        await newPool(PoolConfig(connConfig: plainConfig(), minSize: 1, maxSize: 3))
      discard await pool.exec("DROP TABLE IF EXISTS test_pool_eq")
      let tag = await pool.exec(
        "CREATE TABLE test_pool_eq (id serial PRIMARY KEY, name text NOT NULL)"
      )
      doAssert "CREATE TABLE" in tag
      discard await pool.exec("DROP TABLE test_pool_eq")
      await pool.close()

    waitFor t()

  test "pool.query returns rows":
    proc t() {.async.} =
      let pool =
        await newPool(PoolConfig(connConfig: plainConfig(), minSize: 1, maxSize: 3))
      let res = await pool.query("SELECT 1 AS num, 'hello' AS msg")
      doAssert res.rows.len == 1
      doAssert res.fields.len == 2
      doAssert res.fields[0].name == "num"
      doAssert res.fields[1].name == "msg"
      doAssert res.rows[0][0].get().toString() == "1"
      doAssert res.rows[0][1].get().toString() == "hello"
      await pool.close()

    waitFor t()

  test "pool.query with params":
    proc t() {.async.} =
      let pool =
        await newPool(PoolConfig(connConfig: plainConfig(), minSize: 1, maxSize: 3))
      discard await pool.exec("DROP TABLE IF EXISTS test_pool_qp")
      discard
        await pool.exec("CREATE TABLE test_pool_qp (id serial PRIMARY KEY, name text)")
      discard await pool.exec(
        "INSERT INTO test_pool_qp (name) VALUES ($1), ($2)",
        @[toPgParam("alice"), toPgParam("bob")],
      )
      let res = await pool.query(
        "SELECT name FROM test_pool_qp WHERE name = $1", @[toPgParam("bob")]
      )
      doAssert res.rows.len == 1
      doAssert res.rows[0][0].get().toString() == "bob"
      discard await pool.exec("DROP TABLE test_pool_qp")
      await pool.close()

    waitFor t()

  test "pool.simpleQuery":
    proc t() {.async.} =
      let pool =
        await newPool(PoolConfig(connConfig: plainConfig(), minSize: 1, maxSize: 3))
      let results = await pool.simpleQuery("SELECT 1 AS a; SELECT 2 AS b")
      doAssert results.len == 2
      doAssert results[0].rows[0][0].get().toString() == "1"
      doAssert results[1].rows[0][0].get().toString() == "2"
      await pool.close()

    waitFor t()

  test "pool.notify sends notification":
    proc t() {.async.} =
      let pool =
        await newPool(PoolConfig(connConfig: plainConfig(), minSize: 1, maxSize: 3))

      var received: seq[Notification]
      pool.withConnection(listener):
        listener.onNotify(
          proc(n: Notification) {.gcsafe, raises: [].} =
            received.add(n)
        )
        await listener.listen("pool_notify_chan")

        await pool.notify("pool_notify_chan", "from_pool")

        # Pump receives notification in background
        await sleepAsync(milliseconds(200))

        doAssert received.len == 1
        doAssert received[0].channel == "pool_notify_chan"
        doAssert received[0].payload == "from_pool"

        await listener.unlisten("pool_notify_chan")

      await pool.close()

    waitFor t()

suite "E2E: Transaction":
  test "withTransaction commits on success":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_tx")
      discard await conn.exec("CREATE TABLE test_tx (id serial PRIMARY KEY, val text)")

      conn.withTransaction:
        discard await conn.exec(
          "INSERT INTO test_tx (val) VALUES ($1)", @[toPgParam("committed")]
        )

      let res = await conn.query("SELECT val FROM test_tx")
      doAssert res.rows.len == 1
      doAssert res.rows[0].getStr(0) == "committed"

      discard await conn.exec("DROP TABLE test_tx")
      await conn.close()

    waitFor t()

  test "withTransaction rolls back on exception":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_tx_rb")
      discard
        await conn.exec("CREATE TABLE test_tx_rb (id serial PRIMARY KEY, val text)")

      var raised = false
      var shouldRaise = true
      try:
        conn.withTransaction:
          discard await conn.exec(
            "INSERT INTO test_tx_rb (val) VALUES ($1)", @[toPgParam("rollback_me")]
          )
          if shouldRaise:
            raise newException(ValueError, "intentional error")
      except ValueError:
        raised = true

      doAssert raised
      let res = await conn.query("SELECT val FROM test_tx_rb")
      doAssert res.rows.len == 0

      discard await conn.exec("DROP TABLE test_tx_rb")
      await conn.close()

    waitFor t()

  test "pool.withTransaction commits on success":
    proc t() {.async.} =
      let pool =
        await newPool(PoolConfig(connConfig: plainConfig(), minSize: 1, maxSize: 3))
      discard await pool.exec("DROP TABLE IF EXISTS test_ptx")
      discard await pool.exec("CREATE TABLE test_ptx (id serial PRIMARY KEY, val text)")

      pool.withTransaction(conn):
        discard await conn.exec(
          "INSERT INTO test_ptx (val) VALUES ($1)", @[toPgParam("pool_commit")]
        )

      let res = await pool.query("SELECT val FROM test_ptx")
      doAssert res.rows.len == 1
      doAssert res.rows[0].getStr(0) == "pool_commit"

      discard await pool.exec("DROP TABLE test_ptx")
      await pool.close()

    waitFor t()

  test "pool.withTransaction rolls back on exception":
    proc t() {.async.} =
      let pool =
        await newPool(PoolConfig(connConfig: plainConfig(), minSize: 1, maxSize: 3))
      discard await pool.exec("DROP TABLE IF EXISTS test_ptx_rb")
      discard
        await pool.exec("CREATE TABLE test_ptx_rb (id serial PRIMARY KEY, val text)")

      var raised = false
      var shouldRaise = true
      try:
        pool.withTransaction(conn):
          discard await conn.exec(
            "INSERT INTO test_ptx_rb (val) VALUES ($1)", @[toPgParam("pool_rollback")]
          )
          if shouldRaise:
            raise newException(ValueError, "intentional error")
      except ValueError:
        raised = true

      doAssert raised
      let res = await pool.query("SELECT val FROM test_ptx_rb")
      doAssert res.rows.len == 0

      discard await pool.exec("DROP TABLE test_ptx_rb")
      await pool.close()

    waitFor t()

  test "withTransaction propagates original exception when ROLLBACK fails":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let killer = await connect(plainConfig())

      var raised = false
      var shouldRaise = true
      try:
        conn.withTransaction:
          let pidRes = await conn.query("SELECT pg_backend_pid()")
          let pid = pidRes.rows[0].getStr(0)
          # Kill the connection from another session
          discard await killer.query(
            "SELECT pg_terminate_backend($1)", @[toPgParam(parseInt(pid).int32)]
          )
          # Give the server a moment to terminate the backend
          await sleepAsync(milliseconds(100))
          if shouldRaise:
            raise newException(ValueError, "original error")
      except ValueError as e:
        raised = true
        doAssert e.msg == "original error"

      doAssert raised
      await killer.close()

    waitFor t()

  test "pool.withTransaction propagates original exception when ROLLBACK fails":
    proc t() {.async.} =
      let pool =
        await newPool(PoolConfig(connConfig: plainConfig(), minSize: 1, maxSize: 3))
      let killer = await connect(plainConfig())

      var raised = false
      var shouldRaise = true
      try:
        pool.withTransaction(conn):
          let pidRes = await conn.query("SELECT pg_backend_pid()")
          let pid = pidRes.rows[0].getStr(0)
          discard await killer.query(
            "SELECT pg_terminate_backend($1)", @[toPgParam(parseInt(pid).int32)]
          )
          await sleepAsync(milliseconds(100))
          if shouldRaise:
            raise newException(ValueError, "original error")
      except ValueError as e:
        raised = true
        doAssert e.msg == "original error"

      doAssert raised
      await killer.close()
      await pool.close()

    waitFor t()

  test "withTransaction with timeout only":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_tx_timeout")
      discard await conn.exec(
        "CREATE TABLE test_tx_timeout (id serial PRIMARY KEY, val text)"
      )

      conn.withTransaction(seconds(5)):
        discard await conn.exec(
          "INSERT INTO test_tx_timeout (val) VALUES ($1)", @[toPgParam("timeout_only")]
        )

      let res = await conn.query("SELECT val FROM test_tx_timeout")
      doAssert res.rows.len == 1
      doAssert res.rows[0].getStr(0) == "timeout_only"

      discard await conn.exec("DROP TABLE test_tx_timeout")
      await conn.close()

    waitFor t()

  test "withTransaction with isolation level commits":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_tx_iso")
      discard
        await conn.exec("CREATE TABLE test_tx_iso (id serial PRIMARY KEY, val text)")

      conn.withTransaction(TransactionOptions(isolation: ilSerializable)):
        discard await conn.exec(
          "INSERT INTO test_tx_iso (val) VALUES ($1)", @[toPgParam("serializable")]
        )

      let res = await conn.query("SELECT val FROM test_tx_iso")
      doAssert res.rows.len == 1
      doAssert res.rows[0].getStr(0) == "serializable"

      discard await conn.exec("DROP TABLE test_tx_iso")
      await conn.close()

    waitFor t()

  test "withTransaction with READ ONLY rejects writes":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_tx_ro")
      discard
        await conn.exec("CREATE TABLE test_tx_ro (id serial PRIMARY KEY, val text)")

      var raised = false
      try:
        conn.withTransaction(TransactionOptions(access: amReadOnly)):
          discard await conn.exec(
            "INSERT INTO test_tx_ro (val) VALUES ($1)", @[toPgParam("nope")]
          )
      except PgError:
        raised = true

      doAssert raised

      discard await conn.exec("DROP TABLE test_tx_ro")
      await conn.close()

    waitFor t()

  test "withTransaction with all options":
    proc t() {.async.} =
      let conn = await connect(plainConfig())

      conn.withTransaction(
        TransactionOptions(
          isolation: ilSerializable, access: amReadOnly, deferrable: dmDeferrable
        )
      ):
        let res = await conn.query("SELECT 1")
        doAssert res.rows.len == 1

      await conn.close()

    waitFor t()

  test "pool.withTransaction with options":
    proc t() {.async.} =
      let pool =
        await newPool(PoolConfig(connConfig: plainConfig(), minSize: 1, maxSize: 3))
      discard await pool.exec("DROP TABLE IF EXISTS test_ptx_opts")
      discard
        await pool.exec("CREATE TABLE test_ptx_opts (id serial PRIMARY KEY, val text)")

      pool.withTransaction(conn, TransactionOptions(isolation: ilRepeatableRead)):
        discard await conn.exec(
          "INSERT INTO test_ptx_opts (val) VALUES ($1)", @[toPgParam("pool_opts")]
        )

      let res = await pool.query("SELECT val FROM test_ptx_opts")
      doAssert res.rows.len == 1
      doAssert res.rows[0].getStr(0) == "pool_opts"

      discard await pool.exec("DROP TABLE test_ptx_opts")
      await pool.close()

    waitFor t()

  test "pool.withTransaction with timeout only":
    proc t() {.async.} =
      let pool =
        await newPool(PoolConfig(connConfig: plainConfig(), minSize: 1, maxSize: 3))
      discard await pool.exec("DROP TABLE IF EXISTS test_ptx_timeout")
      discard await pool.exec(
        "CREATE TABLE test_ptx_timeout (id serial PRIMARY KEY, val text)"
      )

      pool.withTransaction(conn, seconds(5)):
        discard await conn.exec(
          "INSERT INTO test_ptx_timeout (val) VALUES ($1)", @[toPgParam("pool_timeout")]
        )

      let res = await pool.query("SELECT val FROM test_ptx_timeout")
      doAssert res.rows.len == 1
      doAssert res.rows[0].getStr(0) == "pool_timeout"

      discard await pool.exec("DROP TABLE test_ptx_timeout")
      await pool.close()

    waitFor t()

  test "withTransaction with TransactionOptions variable":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_tx_opts_var")
      discard await conn.exec(
        "CREATE TABLE test_tx_opts_var (id serial PRIMARY KEY, val text)"
      )

      let opts = TransactionOptions(isolation: ilSerializable)
      conn.withTransaction(opts):
        discard await conn.exec(
          "INSERT INTO test_tx_opts_var (val) VALUES ($1)", @[toPgParam("opts_var")]
        )

      let res = await conn.query("SELECT val FROM test_tx_opts_var")
      doAssert res.rows.len == 1
      doAssert res.rows[0].getStr(0) == "opts_var"

      discard await conn.exec("DROP TABLE test_tx_opts_var")
      await conn.close()

    waitFor t()

  test "withTransaction with Duration variable":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_tx_dur_var")
      discard await conn.exec(
        "CREATE TABLE test_tx_dur_var (id serial PRIMARY KEY, val text)"
      )

      let timeout = seconds(5)
      conn.withTransaction(timeout):
        discard await conn.exec(
          "INSERT INTO test_tx_dur_var (val) VALUES ($1)", @[toPgParam("dur_var")]
        )

      let res = await conn.query("SELECT val FROM test_tx_dur_var")
      doAssert res.rows.len == 1
      doAssert res.rows[0].getStr(0) == "dur_var"

      discard await conn.exec("DROP TABLE test_tx_dur_var")
      await conn.close()

    waitFor t()

  test "pool.withTransaction with TransactionOptions variable":
    proc t() {.async.} =
      let pool =
        await newPool(PoolConfig(connConfig: plainConfig(), minSize: 1, maxSize: 3))
      discard await pool.exec("DROP TABLE IF EXISTS test_ptx_opts_var")
      discard await pool.exec(
        "CREATE TABLE test_ptx_opts_var (id serial PRIMARY KEY, val text)"
      )

      let opts = TransactionOptions(isolation: ilRepeatableRead)
      pool.withTransaction(conn, opts):
        discard await conn.exec(
          "INSERT INTO test_ptx_opts_var (val) VALUES ($1)",
          @[toPgParam("pool_opts_var")],
        )

      let res = await pool.query("SELECT val FROM test_ptx_opts_var")
      doAssert res.rows.len == 1
      doAssert res.rows[0].getStr(0) == "pool_opts_var"

      discard await pool.exec("DROP TABLE test_ptx_opts_var")
      await pool.close()

    waitFor t()

  test "pool.withTransaction with Duration variable":
    proc t() {.async.} =
      let pool =
        await newPool(PoolConfig(connConfig: plainConfig(), minSize: 1, maxSize: 3))
      discard await pool.exec("DROP TABLE IF EXISTS test_ptx_dur_var")
      discard await pool.exec(
        "CREATE TABLE test_ptx_dur_var (id serial PRIMARY KEY, val text)"
      )

      let timeout = seconds(5)
      pool.withTransaction(conn, timeout):
        discard await conn.exec(
          "INSERT INTO test_ptx_dur_var (val) VALUES ($1)", @[toPgParam("pool_dur_var")]
        )

      let res = await pool.query("SELECT val FROM test_ptx_dur_var")
      doAssert res.rows.len == 1
      doAssert res.rows[0].getStr(0) == "pool_dur_var"

      discard await pool.exec("DROP TABLE test_ptx_dur_var")
      await pool.close()

    waitFor t()

  test "withSavepoint releases on success":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_sp")
      discard await conn.exec("CREATE TABLE test_sp (id serial PRIMARY KEY, val text)")

      conn.withTransaction:
        conn.withSavepoint:
          discard await conn.exec(
            "INSERT INTO test_sp (val) VALUES ($1)", @[toPgParam("saved")]
          )

      let res = await conn.query("SELECT val FROM test_sp")
      doAssert res.rows.len == 1
      doAssert res.rows[0].getStr(0) == "saved"

      discard await conn.exec("DROP TABLE test_sp")
      await conn.close()

    waitFor t()

  test "withSavepoint rolls back on exception":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_sp_rb")
      discard
        await conn.exec("CREATE TABLE test_sp_rb (id serial PRIMARY KEY, val text)")

      var shouldRaise = true
      conn.withTransaction:
        discard await conn.exec(
          "INSERT INTO test_sp_rb (val) VALUES ($1)", @[toPgParam("before")]
        )
        try:
          conn.withSavepoint:
            discard await conn.exec(
              "INSERT INTO test_sp_rb (val) VALUES ($1)", @[toPgParam("inner")]
            )
            if shouldRaise:
              raise newException(ValueError, "savepoint error")
        except ValueError:
          discard

      let res = await conn.query("SELECT val FROM test_sp_rb ORDER BY id")
      doAssert res.rows.len == 1
      doAssert res.rows[0].getStr(0) == "before"

      discard await conn.exec("DROP TABLE test_sp_rb")
      await conn.close()

    waitFor t()

  test "nested withSavepoint":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_sp_nest")
      discard
        await conn.exec("CREATE TABLE test_sp_nest (id serial PRIMARY KEY, val text)")

      var shouldRaise = true
      conn.withTransaction:
        conn.withSavepoint:
          discard await conn.exec(
            "INSERT INTO test_sp_nest (val) VALUES ($1)", @[toPgParam("outer")]
          )
          try:
            conn.withSavepoint:
              discard await conn.exec(
                "INSERT INTO test_sp_nest (val) VALUES ($1)", @[toPgParam("inner")]
              )
              if shouldRaise:
                raise newException(ValueError, "inner error")
          except ValueError:
            discard

      let res = await conn.query("SELECT val FROM test_sp_nest ORDER BY id")
      doAssert res.rows.len == 1
      doAssert res.rows[0].getStr(0) == "outer"

      discard await conn.exec("DROP TABLE test_sp_nest")
      await conn.close()

    waitFor t()

  test "withSavepoint with named savepoint":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_sp_named")
      discard
        await conn.exec("CREATE TABLE test_sp_named (id serial PRIMARY KEY, val text)")

      conn.withTransaction:
        conn.withSavepoint("my_sp"):
          discard await conn.exec(
            "INSERT INTO test_sp_named (val) VALUES ($1)", @[toPgParam("named")]
          )

      let res = await conn.query("SELECT val FROM test_sp_named")
      doAssert res.rows.len == 1
      doAssert res.rows[0].getStr(0) == "named"

      discard await conn.exec("DROP TABLE test_sp_named")
      await conn.close()

    waitFor t()

  test "withSavepoint with timeout and name":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_sp_timeout_name")
      discard await conn.exec(
        "CREATE TABLE test_sp_timeout_name (id serial PRIMARY KEY, val text)"
      )

      conn.withTransaction:
        conn.withSavepoint("my_sp_tn", seconds(5)):
          discard await conn.exec(
            "INSERT INTO test_sp_timeout_name (val) VALUES ($1)",
            @[toPgParam("timeout_name")],
          )

      let res = await conn.query("SELECT val FROM test_sp_timeout_name")
      doAssert res.rows.len == 1
      doAssert res.rows[0].getStr(0) == "timeout_name"

      discard await conn.exec("DROP TABLE test_sp_timeout_name")
      await conn.close()

    waitFor t()

  test "withTransaction rejects return at compile time":
    doAssert not compiles(
      block:
        proc t() {.async.} =
          let conn = await connect(plainConfig())
          conn.withTransaction:
            return

    )

  test "withSavepoint rejects return at compile time":
    doAssert not compiles(
      block:
        proc t() {.async.} =
          let conn = await connect(plainConfig())
          conn.withSavepoint:
            return

    )

  test "withSavepoint (named) rejects return at compile time":
    doAssert not compiles(
      block:
        proc t() {.async.} =
          let conn = await connect(plainConfig())
          conn.withSavepoint("sp"):
            return

    )

  test "pool.withTransaction rejects return at compile time":
    doAssert not compiles(
      block:
        proc t() {.async.} =
          let pool =
            await newPool(initPoolConfig(plainConfig(), minSize = 1, maxSize = 1))
          pool.withTransaction(conn):
            return

    )

  test "return inside nested proc is allowed in withTransaction":
    doAssert compiles(
      block:
        proc t() {.async.} =
          let conn = await connect(plainConfig())
          conn.withTransaction:
            let inner = proc() =
              return
            inner()

    )

suite "E2E: Type Roundtrip":
  test "integer types roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res = await conn.query(
        "SELECT $1::int4, $2::int8", @[toPgParam("42"), toPgParam("9999999999")]
      )
      doAssert res.rows.len == 1
      doAssert res.rows[0].getInt(0) == 42'i32
      doAssert res.rows[0].getInt64(1) == 9999999999'i64
      await conn.close()

    waitFor t()

  test "float roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res = await conn.query("SELECT $1::float8", @[toPgParam("3.14")])
      doAssert res.rows.len == 1
      doAssert abs(res.rows[0].getFloat(0) - 3.14) < 1e-10
      await conn.close()

    waitFor t()

  test "bool roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res =
        await conn.query("SELECT $1::bool, $2::bool", @[toPgParam("t"), toPgParam("f")])
      doAssert res.rows.len == 1
      doAssert res.rows[0].getBool(0) == true
      doAssert res.rows[0].getBool(1) == false
      await conn.close()

    waitFor t()

  test "text roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res = await conn.query("SELECT $1::text", @[toPgParam("hello world")])
      doAssert res.rows[0].getStr(0) == "hello world"
      await conn.close()

    waitFor t()

  test "NULL handling":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res = await conn.query("SELECT NULL::text, $1::text", @[toPgParam("ok")])
      doAssert res.rows[0].isNull(0)
      doAssert not res.rows[0].isNull(1)
      doAssert res.rows[0].getStr(1) == "ok"
      await conn.close()

    waitFor t()

  test "NULL parameter with Option[T]":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res = await conn.query(
        "SELECT $1::text IS NULL, $2::int4", @[toPgParam(none(string)), toPgParam("7")]
      )
      doAssert res.rows[0].getStr(0) == "t"
      doAssert res.rows[0].getInt(1) == 7'i32
      await conn.close()

    waitFor t()

suite "E2E: PgParam Typed Parameters":
  test "exec and query with toPgParam (no explicit casts)":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_pgparam")
      discard
        await conn.exec("CREATE TABLE test_pgparam (id int, name text, active bool)")

      # Insert using PgParam — OIDs let PostgreSQL infer types without $1::type casts
      discard await conn.exec(
        "INSERT INTO test_pgparam (id, name, active) VALUES ($1, $2, $3)",
        @[toPgParam(42'i32), toPgParam("alice"), toPgParam(true)],
      )

      let res = await conn.query(
        "SELECT id, name, active FROM test_pgparam WHERE id = $1", @[toPgParam(42'i32)]
      )
      doAssert res.rows.len == 1
      doAssert res.rows[0].getInt(0) == 42'i32
      doAssert res.rows[0].getStr(1) == "alice"
      doAssert res.rows[0].getBool(2) == true

      discard await conn.exec("DROP TABLE test_pgparam")
      await conn.close()

    waitFor t()

  test "query with int (platform int) parameter":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res = await conn.query("SELECT $1 + 1", @[toPgParam(99)])
      doAssert res.rows.len == 1
      doAssert res.rows[0].getInt64(0) == 100'i64
      await conn.close()

    waitFor t()

  test "query with NULL via Option[T]":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res = await conn.query(
        "SELECT $1 IS NULL, $2", @[toPgParam(none(string)), toPgParam("ok")]
      )
      doAssert res.rows[0].getStr(0) == "t"
      doAssert res.rows[0].getStr(1) == "ok"
      await conn.close()

    waitFor t()

  test "exec with int64 and float64 params":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res =
        await conn.query("SELECT $1, $2", @[toPgParam(9999999999'i64), toPgParam(3.14)])
      doAssert res.rows[0].getInt64(0) == 9999999999'i64
      doAssert abs(res.rows[0].getFloat(1) - 3.14) < 1e-10
      await conn.close()

    waitFor t()

  test "pool exec and query with PgParam":
    proc t() {.async.} =
      let pool =
        await newPool(PoolConfig(connConfig: plainConfig(), minSize: 1, maxSize: 3))
      discard await pool.exec("DROP TABLE IF EXISTS test_pgparam_pool")
      discard await pool.exec("CREATE TABLE test_pgparam_pool (id int, val text)")
      discard await pool.exec(
        "INSERT INTO test_pgparam_pool (id, val) VALUES ($1, $2)",
        @[toPgParam(1'i32), toPgParam("pooled")],
      )
      let res = await pool.query(
        "SELECT val FROM test_pgparam_pool WHERE id = $1", @[toPgParam(1'i32)]
      )
      doAssert res.rows.len == 1
      doAssert res.rows[0].getStr(0) == "pooled"
      discard await pool.exec("DROP TABLE test_pgparam_pool")
      await pool.close()

    waitFor t()

  test "execute prepared statement with PgParam":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let stmt = await conn.prepare("pgparam_stmt", "SELECT $1::int4 + $2::int4")
      let res = await stmt.execute(@[toPgParam(10'i32), toPgParam(20'i32)])
      doAssert res.rows.len == 1
      doAssert res.rows[0].getInt(0) == 30'i32
      await stmt.close()
      await conn.close()

    waitFor t()

suite "E2E: COPY Protocol":
  test "copyIn inserts rows":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_copy_in")
      discard await conn.exec("CREATE TABLE test_copy_in (id int, name text)")

      # Prepare tab-delimited rows (PostgreSQL text format default)
      let rows =
        @["1\tAlice\n".toBytes(), "2\tBob\n".toBytes(), "3\tCharlie\n".toBytes()]
      let tag = await conn.copyIn("COPY test_copy_in FROM STDIN", rows)
      doAssert "COPY 3" in tag

      # Verify the data was inserted
      let res = await conn.query("SELECT id, name FROM test_copy_in ORDER BY id")
      doAssert res.rows.len == 3
      doAssert res.rows[0].getStr(1) == "Alice"
      doAssert res.rows[1].getStr(1) == "Bob"
      doAssert res.rows[2].getStr(1) == "Charlie"

      discard await conn.exec("DROP TABLE test_copy_in")
      await conn.close()

    waitFor t()

  test "copyOut retrieves rows":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_copy_out")
      discard await conn.exec("CREATE TABLE test_copy_out (id int, name text)")
      discard
        await conn.exec("INSERT INTO test_copy_out VALUES (1, 'Alice'), (2, 'Bob')")

      let r = await conn.copyOut("COPY test_copy_out TO STDOUT")
      doAssert r.format == cfText
      doAssert "COPY 2" in r.commandTag
      doAssert r.data.len == 2

      # Each row is a tab-delimited line with trailing newline
      doAssert r.data[0].toString() == "1\tAlice\n"
      doAssert r.data[1].toString() == "2\tBob\n"

      discard await conn.exec("DROP TABLE test_copy_out")
      await conn.close()

    waitFor t()

  test "copyIn with invalid SQL raises PgError":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      var raised = false
      try:
        discard await conn.copyIn(
          "COPY nonexistent_table FROM STDIN", @["1\ttest\n".toBytes()]
        )
      except PgError:
        raised = true
      doAssert raised
      doAssert conn.state == csReady
      await conn.close()

    waitFor t()

  test "copyOut with invalid SQL raises PgError":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      var raised = false
      try:
        discard await conn.copyOut("COPY nonexistent_table TO STDOUT")
      except PgError:
        raised = true
      doAssert raised
      doAssert conn.state == csReady
      await conn.close()

    waitFor t()

  test "copyIn empty data":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_copy_empty")
      discard await conn.exec("CREATE TABLE test_copy_empty (id int, name text)")

      let tag = await conn.copyIn("COPY test_copy_empty FROM STDIN", @[])
      doAssert "COPY 0" in tag

      let res = await conn.query("SELECT count(*) FROM test_copy_empty")
      doAssert res.rows[0].getStr(0) == "0"

      discard await conn.exec("DROP TABLE test_copy_empty")
      await conn.close()

    waitFor t()

  test "copyOut from empty table":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_copy_out_empty")
      discard await conn.exec("CREATE TABLE test_copy_out_empty (id int, name text)")

      let r = await conn.copyOut("COPY test_copy_out_empty TO STDOUT")
      doAssert r.data.len == 0
      doAssert "COPY 0" in r.commandTag
      doAssert conn.state == csReady

      discard await conn.exec("DROP TABLE test_copy_out_empty")
      await conn.close()

    waitFor t()

  test "copyIn large data (10000 rows)":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_copy_large")
      discard await conn.exec("CREATE TABLE test_copy_large (id int, val text)")

      var rows: seq[seq[byte]]
      for i in 1 .. 10000:
        rows.add(($i & "\trow_" & $i & "\n").toBytes())
      let tag = await conn.copyIn("COPY test_copy_large FROM STDIN", rows)
      doAssert "COPY 10000" in tag

      let res = await conn.query("SELECT count(*) FROM test_copy_large")
      doAssert res.rows[0].getStr(0) == "10000"

      discard await conn.exec("DROP TABLE test_copy_large")
      await conn.close()

    waitFor t()

  test "copyOut large data (10000 rows)":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_copy_out_large")
      discard await conn.exec("CREATE TABLE test_copy_out_large (id int)")
      discard await conn.exec(
        "INSERT INTO test_copy_out_large SELECT g FROM generate_series(1, 10000) AS g"
      )

      let r = await conn.copyOut("COPY test_copy_out_large TO STDOUT")
      doAssert r.data.len == 10000
      doAssert "COPY 10000" in r.commandTag

      discard await conn.exec("DROP TABLE test_copy_out_large")
      await conn.close()

    waitFor t()

  test "copyIn with NULL values":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_copy_null")
      discard await conn.exec("CREATE TABLE test_copy_null (id int, name text)")

      # \N is the PostgreSQL text-format representation of NULL
      let rows = @["1\tAlice\n".toBytes(), "2\t\\N\n".toBytes(), "\\N\tBob\n".toBytes()]
      let tag = await conn.copyIn("COPY test_copy_null FROM STDIN", rows)
      doAssert "COPY 3" in tag

      let res = await conn.query(
        "SELECT id, name FROM test_copy_null ORDER BY COALESCE(id, 999)"
      )
      doAssert res.rows[0].getStr(0) == "1"
      doAssert res.rows[0].getStr(1) == "Alice"
      doAssert res.rows[1].getStr(0) == "2"
      doAssert res.rows[1].isNull(1)
      doAssert res.rows[2].isNull(0)
      doAssert res.rows[2].getStr(1) == "Bob"

      discard await conn.exec("DROP TABLE test_copy_null")
      await conn.close()

    waitFor t()

  test "copyOut with NULL values":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_copy_out_null")
      discard await conn.exec("CREATE TABLE test_copy_out_null (id int, name text)")
      discard await conn.exec(
        "INSERT INTO test_copy_out_null VALUES (1, NULL), (NULL, 'Bob')"
      )

      let r = await conn.copyOut("COPY test_copy_out_null TO STDOUT")
      doAssert r.data.len == 2
      # NULL is represented as \N in text format
      doAssert r.data[0].toString() == "1\t\\N\n"
      doAssert r.data[1].toString() == "\\N\tBob\n"

      discard await conn.exec("DROP TABLE test_copy_out_null")
      await conn.close()

    waitFor t()

  test "copyIn with special characters (tab, backslash, newline in data)":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_copy_special")
      discard await conn.exec("CREATE TABLE test_copy_special (id int, val text)")

      # In PostgreSQL text COPY format:
      # \t = literal tab, \n = literal newline, \\ = literal backslash
      let rows = @[
        "1\thas\\\\backslash\n".toBytes(),
        "2\thas\\nnewline\n".toBytes(),
        "3\thas\\ttab\n".toBytes(),
      ]
      let tag = await conn.copyIn("COPY test_copy_special FROM STDIN", rows)
      doAssert "COPY 3" in tag

      let res = await conn.query("SELECT id, val FROM test_copy_special ORDER BY id")
      doAssert res.rows.len == 3
      doAssert res.rows[0].getStr(1) == "has\\backslash"
      doAssert res.rows[1].getStr(1) == "has\nnewline"
      doAssert res.rows[2].getStr(1) == "has\ttab"

      discard await conn.exec("DROP TABLE test_copy_special")
      await conn.close()

    waitFor t()

  test "copyIn with CSV format":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_copy_csv")
      discard await conn.exec("CREATE TABLE test_copy_csv (id int, name text)")

      let rows = @[
        "1,Alice\n".toBytes(),
        "2,\"Bob, Jr.\"\n".toBytes(),
        "3,\"Has \"\"quotes\"\"\"\n".toBytes(),
      ]
      let tag =
        await conn.copyIn("COPY test_copy_csv FROM STDIN WITH (FORMAT csv)", rows)
      doAssert "COPY 3" in tag

      let res = await conn.query("SELECT id, name FROM test_copy_csv ORDER BY id")
      doAssert res.rows[0].getStr(1) == "Alice"
      doAssert res.rows[1].getStr(1) == "Bob, Jr."
      doAssert res.rows[2].getStr(1) == "Has \"quotes\""

      discard await conn.exec("DROP TABLE test_copy_csv")
      await conn.close()

    waitFor t()

  test "copyOut with CSV format":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_copy_csv_out")
      discard await conn.exec("CREATE TABLE test_copy_csv_out (id int, name text)")
      discard await conn.exec(
        "INSERT INTO test_copy_csv_out VALUES (1, 'Alice'), (2, 'Bob, Jr.')"
      )

      let r = await conn.copyOut("COPY test_copy_csv_out TO STDOUT WITH (FORMAT csv)")
      doAssert r.data.len == 2
      doAssert r.data[0].toString() == "1,Alice\n"
      doAssert r.data[1].toString() == "2,\"Bob, Jr.\"\n"

      discard await conn.exec("DROP TABLE test_copy_csv_out")
      await conn.close()

    waitFor t()

  test "copyOutStream basic streaming":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_copy_stream")
      discard await conn.exec("CREATE TABLE test_copy_stream (id int, name text)")
      discard
        await conn.exec("INSERT INTO test_copy_stream VALUES (1, 'Alice'), (2, 'Bob')")

      var chunks: seq[seq[byte]]
      let cb = makeCopyOutCallback:
        chunks.add(data)
      let info = await conn.copyOutStream("COPY test_copy_stream TO STDOUT", cb)
      doAssert info.format == cfText
      doAssert "COPY 2" in info.commandTag
      doAssert chunks.len == 2
      doAssert chunks[0].toString() == "1\tAlice\n"
      doAssert chunks[1].toString() == "2\tBob\n"
      doAssert conn.state == csReady

      discard await conn.exec("DROP TABLE test_copy_stream")
      await conn.close()

    waitFor t()

  test "copyOutStream empty table":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_copy_stream_empty")
      discard await conn.exec("CREATE TABLE test_copy_stream_empty (id int, name text)")

      var callCount = 0
      let cb = makeCopyOutCallback:
        inc callCount
      let info = await conn.copyOutStream("COPY test_copy_stream_empty TO STDOUT", cb)
      doAssert callCount == 0
      doAssert "COPY 0" in info.commandTag
      doAssert conn.state == csReady

      discard await conn.exec("DROP TABLE test_copy_stream_empty")
      await conn.close()

    waitFor t()

  test "consecutive copyIn operations":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_copy_consecutive")
      discard await conn.exec("CREATE TABLE test_copy_consecutive (id int, batch int)")

      let rows1 = @["1\t1\n".toBytes(), "2\t1\n".toBytes()]
      let tag1 = await conn.copyIn("COPY test_copy_consecutive FROM STDIN", rows1)
      doAssert "COPY 2" in tag1

      let rows2 = @["3\t2\n".toBytes(), "4\t2\n".toBytes(), "5\t2\n".toBytes()]
      let tag2 = await conn.copyIn("COPY test_copy_consecutive FROM STDIN", rows2)
      doAssert "COPY 3" in tag2

      let res = await conn.query("SELECT count(*) FROM test_copy_consecutive")
      doAssert res.rows[0].getStr(0) == "5"

      discard await conn.exec("DROP TABLE test_copy_consecutive")
      await conn.close()

    waitFor t()

  test "copyIn single row with large payload":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_copy_big_row")
      discard await conn.exec("CREATE TABLE test_copy_big_row (id int, data text)")

      let bigText = 'x'.repeat(100_000)
      let rows = @[("1\t" & bigText & "\n").toBytes()]
      let tag = await conn.copyIn("COPY test_copy_big_row FROM STDIN", rows)
      doAssert "COPY 1" in tag

      let res = await conn.query("SELECT length(data) FROM test_copy_big_row")
      doAssert res.rows[0].getStr(0) == "100000"

      discard await conn.exec("DROP TABLE test_copy_big_row")
      await conn.close()

    waitFor t()

suite "E2E: Cancel Request":
  test "cancel aborts pg_sleep":
    proc t() {.async.} =
      let conn = await connect(plainConfig())

      # Start a long-running query
      let sleepFut = conn.simpleQuery("SELECT pg_sleep(30)")

      # Give the server time to start executing
      await sleepAsync(milliseconds(100))

      # Cancel the query via a separate TCP connection
      await conn.cancel()

      # The original query should fail with query_canceled (57014)
      var raised = false
      try:
        discard await sleepFut
      except PgError as e:
        raised = true
        doAssert "57014" in e.msg
      doAssert raised

      # Connection should still be usable after cancel
      doAssert conn.state == csReady
      let res = await conn.simpleQuery("SELECT 1 AS check_col")
      doAssert res[0].rows[0][0].get().toString() == "1"

      await conn.close()

    waitFor t()

suite "E2E: Notice Callback":
  test "RAISE NOTICE triggers noticeCallback":
    proc t() {.async.} =
      let conn = await connect(plainConfig())

      var received: seq[Notice]
      conn.noticeCallback = proc(n: Notice) {.gcsafe, raises: [].} =
        received.add(n)

      discard await conn.exec("DO $$ BEGIN RAISE NOTICE 'hello from notice'; END $$")

      doAssert received.len == 1
      # Check that the message field ('M') contains our text
      var foundMsg = false
      for f in received[0].fields:
        if f.code == 'M':
          doAssert f.value == "hello from notice"
          foundMsg = true
      doAssert foundMsg

      await conn.close()

    waitFor t()

  test "notice callback not set does not interfere":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      # No noticeCallback set — should not hang or error
      discard await conn.exec("DO $$ BEGIN RAISE NOTICE 'ignored'; END $$")
      let res = await conn.query("SELECT 1 AS check_col")
      doAssert res.rows.len == 1
      await conn.close()

    waitFor t()

suite "E2E: LISTEN/NOTIFY":
  test "basic notify and receive":
    proc t() {.async.} =
      let listener = await connect(plainConfig())
      let sender = await connect(plainConfig())

      var received: seq[Notification]
      listener.onNotify(
        proc(n: Notification) {.gcsafe, raises: [].} =
          received.add(n)
      )
      await listener.listen("test_chan")

      await sender.notify("test_chan", "hello")

      # Pump receives notification in background
      await sleepAsync(milliseconds(200))

      doAssert received.len == 1
      doAssert received[0].channel == "test_chan"
      doAssert received[0].payload == "hello"

      await listener.unlisten("test_chan")
      await listener.close()
      await sender.close()

    waitFor t()

  test "notify without payload":
    proc t() {.async.} =
      let listener = await connect(plainConfig())
      let sender = await connect(plainConfig())

      var received: seq[Notification]
      listener.onNotify(
        proc(n: Notification) {.gcsafe, raises: [].} =
          received.add(n)
      )
      await listener.listen("test_chan2")

      await sender.notify("test_chan2")

      await sleepAsync(milliseconds(200))

      doAssert received.len == 1
      doAssert received[0].channel == "test_chan2"
      doAssert received[0].payload == ""

      await listener.unlisten("test_chan2")
      await listener.close()
      await sender.close()

    waitFor t()

  test "multiple channels":
    proc t() {.async.} =
      let listener = await connect(plainConfig())
      let sender = await connect(plainConfig())

      var received: seq[Notification]
      listener.onNotify(
        proc(n: Notification) {.gcsafe, raises: [].} =
          received.add(n)
      )

      await listener.listen("chan_a")
      await listener.listen("chan_b")

      await sender.notify("chan_a", "msg_a")
      await sender.notify("chan_b", "msg_b")

      await sleepAsync(milliseconds(200))

      doAssert received.len == 2
      doAssert received[0].channel == "chan_a"
      doAssert received[0].payload == "msg_a"
      doAssert received[1].channel == "chan_b"
      doAssert received[1].payload == "msg_b"

      await listener.unlisten("chan_a")
      await listener.unlisten("chan_b")
      await listener.close()
      await sender.close()

    waitFor t()

  test "unlisten stops notifications":
    proc t() {.async.} =
      let listener = await connect(plainConfig())
      let sender = await connect(plainConfig())

      var received: seq[Notification]
      listener.onNotify(
        proc(n: Notification) {.gcsafe, raises: [].} =
          received.add(n)
      )
      await listener.listen("test_unsub")

      await sender.notify("test_unsub", "before")
      # Pump is running in background, wait for delivery
      await sleepAsync(milliseconds(100))
      doAssert received.len == 1

      await listener.unlisten("test_unsub")

      await sender.notify("test_unsub", "after")
      await sleepAsync(milliseconds(100))
      doAssert received.len == 1

      await listener.close()
      await sender.close()

    waitFor t()

suite "E2E: Background LISTEN Pump":
  test "notification arrives without explicit query":
    proc t() {.async.} =
      let listener = await connect(plainConfig())
      let sender = await connect(plainConfig())

      var received: seq[Notification]
      listener.onNotify(
        proc(n: Notification) {.gcsafe, raises: [].} =
          received.add(n)
      )
      await listener.listen("bg_chan")

      # Send notification — pump should receive it without SELECT 1
      await sender.notify("bg_chan", "background")
      await sleepAsync(milliseconds(200))

      doAssert received.len == 1
      doAssert received[0].channel == "bg_chan"
      doAssert received[0].payload == "background"

      await listener.unlisten("bg_chan")
      await listener.close()
      await sender.close()

    waitFor t()

  test "multiple channels received in background":
    proc t() {.async.} =
      let listener = await connect(plainConfig())
      let sender = await connect(plainConfig())

      var received: seq[Notification]
      listener.onNotify(
        proc(n: Notification) {.gcsafe, raises: [].} =
          received.add(n)
      )

      await listener.listen("bg_a")
      await listener.listen("bg_b")

      await sender.notify("bg_a", "msg_a")
      await sender.notify("bg_b", "msg_b")
      await sleepAsync(milliseconds(200))

      doAssert received.len == 2
      doAssert received[0].channel == "bg_a"
      doAssert received[1].channel == "bg_b"

      await listener.unlisten("bg_a")
      await listener.unlisten("bg_b")
      await listener.close()
      await sender.close()

    waitFor t()

  test "unlisten stops pump when no channels remain":
    proc t() {.async.} =
      let listener = await connect(plainConfig())
      let sender = await connect(plainConfig())

      var received: seq[Notification]
      listener.onNotify(
        proc(n: Notification) {.gcsafe, raises: [].} =
          received.add(n)
      )
      await listener.listen("bg_stop")

      await sender.notify("bg_stop", "before")
      await sleepAsync(milliseconds(100))
      doAssert received.len == 1

      await listener.unlisten("bg_stop")
      doAssert listener.state == csReady

      # Connection should be usable for queries after pump stops
      let res = await listener.simpleQuery("SELECT 1")
      doAssert res[0].rows[0][0].get().toString() == "1"

      await listener.close()
      await sender.close()

    waitFor t()

  test "close does not hang with active pump":
    proc t() {.async.} =
      let listener = await connect(plainConfig())

      listener.onNotify(
        proc(n: Notification) {.gcsafe, raises: [].} =
          discard
      )
      await listener.listen("bg_close")

      doAssert listener.state == csListening

      # close should cancel pump and not hang
      await listener.close()
      doAssert listener.state == csClosed

    waitFor t()

  test "unlisten partial channels keeps pump running":
    proc t() {.async.} =
      let listener = await connect(plainConfig())
      let sender = await connect(plainConfig())

      var received: seq[Notification]
      listener.onNotify(
        proc(n: Notification) {.gcsafe, raises: [].} =
          received.add(n)
      )

      await listener.listen("partial_a")
      await listener.listen("partial_b")

      # Unlisten only one channel — pump should still be running for the other
      await listener.unlisten("partial_a")
      doAssert listener.state == csListening

      await sender.notify("partial_b", "still_alive")
      await sleepAsync(milliseconds(200))

      doAssert received.len == 1
      doAssert received[0].channel == "partial_b"
      doAssert received[0].payload == "still_alive"

      # Notification on unlistened channel should not arrive
      await sender.notify("partial_a", "should_not_arrive")
      await sleepAsync(milliseconds(100))
      doAssert received.len == 1

      await listener.unlisten("partial_b")
      await listener.close()
      await sender.close()

    waitFor t()

  test "listen after unlisten restarts pump":
    proc t() {.async.} =
      let listener = await connect(plainConfig())
      let sender = await connect(plainConfig())

      var received: seq[Notification]
      listener.onNotify(
        proc(n: Notification) {.gcsafe, raises: [].} =
          received.add(n)
      )
      await listener.listen("bg_restart")

      await sender.notify("bg_restart", "first")
      await sleepAsync(milliseconds(100))
      doAssert received.len == 1

      await listener.unlisten("bg_restart")
      doAssert listener.state == csReady

      # Re-listen should restart pump (callback is preserved)
      await listener.listen("bg_restart2")
      doAssert listener.state == csListening

      await sender.notify("bg_restart2", "second")
      await sleepAsync(milliseconds(200))
      doAssert received.len == 2
      doAssert received[1].channel == "bg_restart2"
      doAssert received[1].payload == "second"

      await listener.unlisten("bg_restart2")
      await listener.close()
      await sender.close()

    waitFor t()

suite "E2E: Cursor/Streaming":
  test "cursor fetches all rows in chunks":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_cursor")
      discard await conn.exec("CREATE TABLE test_cursor (id int)")
      for i in 1 .. 100:
        discard await conn.exec(
          "INSERT INTO test_cursor (id) VALUES ($1)", @[toPgParam(i.int32)]
        )

      let cursor =
        await conn.openCursor("SELECT id FROM test_cursor ORDER BY id", chunkSize = 10)
      doAssert cursor.fields.len == 1

      var allRows: seq[Row]
      while true:
        let chunk = await cursor.fetchNext()
        if chunk.len == 0:
          break
        allRows.add(chunk)

      doAssert allRows.len == 100
      doAssert allRows[0].getStr(0) == "1"
      doAssert allRows[99].getStr(0) == "100"
      doAssert cursor.exhausted
      doAssert conn.state == csReady

      discard await conn.exec("DROP TABLE test_cursor")
      await conn.close()

    waitFor t()

  test "mid-stream close returns conn to ready":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_cursor_close")
      discard await conn.exec("CREATE TABLE test_cursor_close (id int)")
      for i in 1 .. 50:
        discard await conn.exec(
          "INSERT INTO test_cursor_close (id) VALUES ($1)", @[toPgParam(i.int32)]
        )

      let cursor = await conn.openCursor(
        "SELECT id FROM test_cursor_close ORDER BY id", chunkSize = 10
      )
      let chunk1 = await cursor.fetchNext()
      doAssert chunk1.len == 10

      await cursor.close()
      doAssert conn.state == csReady

      # Connection is usable after closing cursor mid-stream
      let res = await conn.query("SELECT 1 AS check_col")
      doAssert res.rows.len == 1

      discard await conn.exec("DROP TABLE test_cursor_close")
      await conn.close()

    waitFor t()

  test "withCursor template":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_cursor_with")
      discard await conn.exec("CREATE TABLE test_cursor_with (id int)")
      for i in 1 .. 25:
        discard await conn.exec(
          "INSERT INTO test_cursor_with (id) VALUES ($1)", @[toPgParam(i.int32)]
        )

      var total = 0
      conn.withCursor("SELECT id FROM test_cursor_with ORDER BY id", 10'i32, cur):
        while true:
          let chunk = await cur.fetchNext()
          if chunk.len == 0:
            break
          total += chunk.len

      doAssert total == 25
      doAssert conn.state == csReady

      discard await conn.exec("DROP TABLE test_cursor_with")
      await conn.close()

    waitFor t()

  test "cursor with zero rows":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_cursor_empty")
      discard await conn.exec("CREATE TABLE test_cursor_empty (id int)")

      let cursor =
        await conn.openCursor("SELECT id FROM test_cursor_empty", chunkSize = 10)
      doAssert cursor.exhausted
      let chunk = await cursor.fetchNext()
      doAssert chunk.len == 0
      doAssert conn.state == csReady

      discard await conn.exec("DROP TABLE test_cursor_empty")
      await conn.close()

    waitFor t()

  test "fetchNext on exhausted cursor returns empty":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_cursor_exhaust")
      discard await conn.exec("CREATE TABLE test_cursor_exhaust (id int)")
      discard
        await conn.exec("INSERT INTO test_cursor_exhaust (id) VALUES (1), (2), (3)")

      let cursor = await conn.openCursor(
        "SELECT id FROM test_cursor_exhaust ORDER BY id", chunkSize = 100
      )
      # First fetch gets all rows + marks exhausted
      let chunk1 = await cursor.fetchNext()
      doAssert chunk1.len == 3
      doAssert cursor.exhausted

      let chunk2 = await cursor.fetchNext()
      doAssert chunk2.len == 0

      doAssert conn.state == csReady

      discard await conn.exec("DROP TABLE test_cursor_exhaust")
      await conn.close()

    waitFor t()

  test "withCursor cleans up on exception":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_cursor_exc")
      discard await conn.exec("CREATE TABLE test_cursor_exc (id int)")
      for i in 1 .. 20:
        discard await conn.exec(
          "INSERT INTO test_cursor_exc (id) VALUES ($1)", @[toPgParam(i.int32)]
        )

      var raised = false
      try:
        conn.withCursor("SELECT id FROM test_cursor_exc ORDER BY id", 5'i32, cur):
          let chunk = await cur.fetchNext()
          doAssert chunk.len == 5
          raise newException(ValueError, "intentional error")
      except ValueError:
        raised = true

      doAssert raised
      doAssert conn.state == csReady

      # Connection is usable after exception in withCursor
      let res = await conn.query("SELECT 1 AS check_col")
      doAssert res.rows.len == 1

      discard await conn.exec("DROP TABLE test_cursor_exc")
      await conn.close()

    waitFor t()

  test "openCursor with invalid SQL raises PgError":
    proc t() {.async.} =
      let conn = await connect(plainConfig())

      var raised = false
      try:
        discard
          await conn.openCursor("SELECT * FROM nonexistent_table_xyz", chunkSize = 10)
      except PgError:
        raised = true

      doAssert raised
      doAssert conn.state == csReady

      # Connection is usable after cursor error
      let res = await conn.query("SELECT 1 AS check_col")
      doAssert res.rows.len == 1

      await conn.close()

    waitFor t()

  test "cursor with PgParam parameters":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_cursor_params")
      discard await conn.exec("CREATE TABLE test_cursor_params (id int, name text)")
      discard await conn.exec(
        "INSERT INTO test_cursor_params VALUES (1, 'alice'), (2, 'bob'), (3, 'alice')"
      )

      let cursor = await conn.openCursor(
        "SELECT id FROM test_cursor_params WHERE name = $1 ORDER BY id",
        @[toPgParam("alice")],
        chunkSize = 10,
      )
      let chunk = await cursor.fetchNext()
      doAssert chunk.len == 2
      doAssert chunk[0].getStr(0) == "1"
      doAssert chunk[1].getStr(0) == "3"

      let empty = await cursor.fetchNext()
      doAssert empty.len == 0
      doAssert conn.state == csReady

      discard await conn.exec("DROP TABLE test_cursor_params")
      await conn.close()

    waitFor t()

  test "cursor with timeout succeeds when fast enough":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_cursor_timeout")
      discard await conn.exec("CREATE TABLE test_cursor_timeout (id int)")
      for i in 1 .. 10:
        discard await conn.exec(
          "INSERT INTO test_cursor_timeout (id) VALUES ($1)", @[toPgParam(i.int32)]
        )

      let cursor = await conn.openCursor(
        "SELECT id FROM test_cursor_timeout ORDER BY id",
        chunkSize = 5,
        timeout = seconds(5),
      )
      doAssert cursor.fields.len == 1

      var allRows: seq[Row]
      while true:
        let chunk = await cursor.fetchNext()
        if chunk.len == 0:
          break
        allRows.add(chunk)

      doAssert allRows.len == 10
      doAssert cursor.exhausted
      doAssert conn.state == csReady

      discard await conn.exec("DROP TABLE test_cursor_timeout")
      await conn.close()

    waitFor t()

  test "openCursor times out on slow query":
    proc t() {.async.} =
      let conn = await connect(plainConfig())

      var raised = false
      try:
        # pg_sleep(10) will delay the first Execute response
        discard await conn.openCursor(
          "SELECT pg_sleep(10)", chunkSize = 1, timeout = milliseconds(100)
        )
      except PgError as e:
        raised = true
        doAssert "timed out" in e.msg

      doAssert raised
      doAssert conn.state == csClosed

    waitFor t()

  test "fetchNext times out on slow query":
    proc t() {.async.} =
      let conn = await connect(plainConfig())

      # Row v=1 returns instantly, v>=2 sleeps 2s — exceeds the 500ms timeout
      let cursor = await conn.openCursor(
        "SELECT v, CASE WHEN v = 1 THEN pg_sleep(0) ELSE pg_sleep(2) END " &
          "FROM generate_series(1, 5) AS v",
        chunkSize = 1,
        timeout = milliseconds(500),
      )
      # openCursor fetched v=1 (instant) into buffer
      let chunk1 = await cursor.fetchNext() # returns buffered data, no I/O
      doAssert chunk1.len == 1

      var raised = false
      try:
        discard await cursor.fetchNext() # v=2 sleeps 2s → timeout
      except PgError as e:
        raised = true
        doAssert "timed out" in e.msg

      doAssert raised
      doAssert conn.state == csClosed

    waitFor t()

  test "cursor with chunkSize 1 fetches one row at a time":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let cursor =
        await conn.openCursor("SELECT g FROM generate_series(1, 5) AS g", chunkSize = 1)

      for i in 1 .. 5:
        let chunk = await cursor.fetchNext()
        doAssert chunk.len == 1
        doAssert chunk[0].getStr(0) == $i

      let empty = await cursor.fetchNext()
      doAssert empty.len == 0
      doAssert cursor.exhausted
      doAssert conn.state == csReady
      await conn.close()

    waitFor t()

  test "cursor rows exactly equal to chunkSize (boundary)":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      # 20 rows with chunkSize=10 → exactly 2 full chunks, no partial
      let cursor = await conn.openCursor(
        "SELECT g FROM generate_series(1, 20) AS g", chunkSize = 10
      )

      let chunk1 = await cursor.fetchNext()
      doAssert chunk1.len == 10

      let chunk2 = await cursor.fetchNext()
      doAssert chunk2.len == 10

      # Next fetch should discover exhaustion
      let chunk3 = await cursor.fetchNext()
      doAssert chunk3.len == 0
      doAssert cursor.exhausted
      doAssert conn.state == csReady
      await conn.close()

    waitFor t()

  test "multiple sequential cursors on same connection":
    proc t() {.async.} =
      let conn = await connect(plainConfig())

      # First cursor
      let cursor1 = await conn.openCursor(
        "SELECT g FROM generate_series(1, 5) AS g", chunkSize = 10
      )
      let rows1 = await cursor1.fetchNext()
      doAssert rows1.len == 5
      doAssert cursor1.exhausted

      # Second cursor on same connection
      let cursor2 = await conn.openCursor(
        "SELECT g FROM generate_series(10, 15) AS g", chunkSize = 10
      )
      let rows2 = await cursor2.fetchNext()
      doAssert rows2.len == 6
      doAssert rows2[0].getStr(0) == "10"
      doAssert cursor2.exhausted

      # Third cursor to confirm no state leakage
      let cursor3 = await conn.openCursor("SELECT 42 AS answer", chunkSize = 10)
      let rows3 = await cursor3.fetchNext()
      doAssert rows3.len == 1
      doAssert rows3[0].getStr(0) == "42"

      doAssert conn.state == csReady
      await conn.close()

    waitFor t()

  test "cursor with NULL values in result":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_cursor_nulls")
      discard await conn.exec("CREATE TABLE test_cursor_nulls (id int, val text)")
      discard await conn.exec(
        "INSERT INTO test_cursor_nulls VALUES (1, 'a'), (2, NULL), (3, 'c'), (NULL, NULL)"
      )

      let cursor = await conn.openCursor(
        "SELECT id, val FROM test_cursor_nulls ORDER BY COALESCE(id, 999)",
        chunkSize = 2,
      )

      let chunk1 = await cursor.fetchNext()
      doAssert chunk1.len == 2
      doAssert chunk1[0].getStr(0) == "1"
      doAssert chunk1[0].getStr(1) == "a"
      doAssert chunk1[1].getStr(0) == "2"
      doAssert chunk1[1].isNull(1)

      let chunk2 = await cursor.fetchNext()
      doAssert chunk2.len == 2
      doAssert chunk2[0].getStr(0) == "3"
      doAssert chunk2[0].getStr(1) == "c"
      doAssert chunk2[1].isNull(0)
      doAssert chunk2[1].isNull(1)

      let empty = await cursor.fetchNext()
      doAssert empty.len == 0
      doAssert cursor.exhausted

      discard await conn.exec("DROP TABLE test_cursor_nulls")
      await conn.close()

    waitFor t()

  test "close on already exhausted cursor":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let cursor = await conn.openCursor("SELECT 1 AS x", chunkSize = 10)
      let chunk = await cursor.fetchNext()
      doAssert chunk.len == 1
      doAssert cursor.exhausted

      # close on exhausted cursor should be safe no-op
      await cursor.close()
      doAssert conn.state == csReady

      let res = await conn.query("SELECT 2 AS y")
      doAssert res.rows[0].getStr(0) == "2"
      await conn.close()

    waitFor t()

suite "E2E: Operation Timeouts":
  test "exec with timeout succeeds when fast enough":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let tag = await conn.exec("SELECT 1", timeout = seconds(5))
      doAssert tag == "SELECT 1"
      doAssert conn.state == csReady
      await conn.close()

    waitFor t()

  test "exec times out on slow query":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      var raised = false
      try:
        discard await conn.exec("SELECT pg_sleep(10)", timeout = milliseconds(100))
      except PgError as e:
        raised = true
        doAssert "timed out" in e.msg
      doAssert raised
      doAssert conn.state == csClosed

    waitFor t()

  test "query with timeout succeeds when fast enough":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let qr = await conn.query("SELECT 42 AS v", timeout = seconds(5))
      doAssert qr.rows.len == 1
      doAssert qr.rows[0][0].get().toString() == "42"
      doAssert conn.state == csReady
      await conn.close()

    waitFor t()

  test "query times out on slow query":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      var raised = false
      try:
        discard await conn.query("SELECT pg_sleep(10)", timeout = milliseconds(100))
      except PgError as e:
        raised = true
        doAssert "timed out" in e.msg
      doAssert raised
      doAssert conn.state == csClosed

    waitFor t()

  test "prepare and execute with timeout succeed when fast enough":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let stmt =
        await conn.prepare("test_timeout_stmt", "SELECT $1::int", timeout = seconds(5))
      let qr = await stmt.execute(@[toPgParam("7")], timeout = seconds(5))
      doAssert qr.rows.len == 1
      doAssert qr.rows[0][0].get().toString() == "7"
      await stmt.close(timeout = seconds(5))
      doAssert conn.state == csReady
      await conn.close()

    waitFor t()

  test "execute times out on slow query":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let stmt = await conn.prepare("test_timeout_exec", "SELECT pg_sleep($1::float)")
      var raised = false
      try:
        discard await stmt.execute(@[toPgParam("10")], timeout = milliseconds(100))
      except PgError as e:
        raised = true
        doAssert "timed out" in e.msg
      doAssert raised
      doAssert conn.state == csClosed

    waitFor t()

  test "pool exec with timeout succeeds":
    proc t() {.async.} =
      let pool =
        await newPool(PoolConfig(connConfig: plainConfig(), minSize: 1, maxSize: 2))
      let tag = await pool.exec("SELECT 1", timeout = seconds(5))
      doAssert tag == "SELECT 1"
      await pool.close()

    waitFor t()

  test "pool query times out on slow query":
    proc t() {.async.} =
      let pool =
        await newPool(PoolConfig(connConfig: plainConfig(), minSize: 1, maxSize: 2))
      var raised = false
      try:
        discard await pool.query("SELECT pg_sleep(10)", timeout = milliseconds(100))
      except PgError as e:
        raised = true
        doAssert "timed out" in e.msg
      doAssert raised
      await pool.close()

    waitFor t()

suite "E2E: Pool minSize Replenishment":
  test "replenishes to minSize after maxLifetime expiry":
    proc t() {.async.} =
      let pool = await newPool(
        PoolConfig(
          connConfig: plainConfig(),
          minSize: 2,
          maxSize: 5,
          maxLifetime: milliseconds(200),
          maintenanceInterval: milliseconds(100),
        )
      )

      doAssert pool.idleCount == 2

      # Wait for maxLifetime to expire + maintenance to clean + replenish
      await sleepAsync(milliseconds(600))

      doAssert pool.idleCount == 2

      # Verify replenished connections are functional
      let conn = await pool.acquire()
      doAssert conn.state == csReady
      let res = await conn.simpleQuery("SELECT 1")
      doAssert res[0].rows[0][0].get().toString() == "1"
      conn.release()

      await pool.close()

    waitFor t()

suite "E2E: Extended Type Roundtrip":
  test "bytea roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("CREATE TEMP TABLE test_bytea (data bytea)")
      # Insert via SQL hex literal (toPgParam for bytea uses text format, so
      # raw non-UTF8 bytes are rejected by PostgreSQL — use hex literals instead)
      discard
        await conn.exec("INSERT INTO test_bytea (data) VALUES ('\\x00DEADBEEFFF')")
      let res = await conn.query("SELECT data FROM test_bytea")
      doAssert res.rows.len == 1
      doAssert res.rows[0].getBytes(0) == @[0x00'u8, 0xDE, 0xAD, 0xBE, 0xEF, 0xFF]
      # Also test toPgParam with ASCII-safe bytes
      let safeInput = @[0x41'u8, 0x42, 0x43] # "ABC"
      discard await conn.exec(
        "INSERT INTO test_bytea (data) VALUES ($1)", @[toPgParam(safeInput)]
      )
      let res2 = await conn.query(
        "SELECT data FROM test_bytea WHERE data = $1", @[toPgParam(safeInput)]
      )
      doAssert res2.rows.len == 1
      doAssert res2.rows[0].getBytes(0) == safeInput
      await conn.close()

    waitFor t()

  test "timestamp roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let dt = dateTime(2025, mMar, 15, 10, 30, 45, zone = utc())
      let res = await conn.query("SELECT $1::timestamp", @[toPgParam(dt)])
      doAssert res.rows.len == 1
      let got = res.rows[0].getTimestamp(0)
      doAssert got.year == 2025
      doAssert got.month == mMar
      doAssert got.monthday == 15
      doAssert got.hour == 10
      doAssert got.minute == 30
      doAssert got.second == 45
      await conn.close()

    waitFor t()

  test "date roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res = await conn.query("SELECT '2025-06-15'::date")
      doAssert res.rows.len == 1
      let got = res.rows[0].getDate(0)
      doAssert got.year == 2025
      doAssert got.month == mJun
      doAssert got.monthday == 15
      await conn.close()

    waitFor t()

  test "time roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let tm = PgTime(hour: 14, minute: 30, second: 45, microsecond: 123456)
      let res = await conn.query("SELECT $1::time", @[toPgParam(tm)])
      doAssert res.rows.len == 1
      let got = res.rows[0].getTime(0)
      doAssert got.hour == 14
      doAssert got.minute == 30
      doAssert got.second == 45
      doAssert got.microsecond == 123456
      await conn.close()

    waitFor t()

  test "timetz roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let tm =
        PgTimeTz(hour: 14, minute: 30, second: 45, microsecond: 0, utcOffset: 18000)
      let res = await conn.query("SELECT $1::timetz", @[toPgParam(tm)])
      doAssert res.rows.len == 1
      let got = res.rows[0].getTimeTz(0)
      doAssert got.hour == 14
      doAssert got.minute == 30
      doAssert got.second == 45
      doAssert got.utcOffset == 18000
      await conn.close()

    waitFor t()

  test "date param roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let dt = dateTime(2025, mJun, 15, 0, 0, 0, zone = utc())
      let res = await conn.query("SELECT $1::date", @[toPgDateParam(dt)])
      doAssert res.rows.len == 1
      let got = res.rows[0].getDate(0)
      doAssert got.year == 2025
      doAssert got.month == mJun
      doAssert got.monthday == 15
      await conn.close()

    waitFor t()

  test "timestamptz roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let dt = dateTime(2025, mMar, 15, 10, 30, 45, zone = utc())
      let res = await conn.query("SELECT $1::timestamptz", @[toPgTimestampTzParam(dt)])
      doAssert res.rows.len == 1
      let got = res.rows[0].getTimestampTz(0)
      doAssert got.utc().year == 2025
      doAssert got.utc().month == mMar
      doAssert got.utc().monthday == 15
      doAssert got.utc().hour == 10
      doAssert got.utc().minute == 30
      doAssert got.utc().second == 45
      await conn.close()

    waitFor t()

  test "UUID roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let uuid = PgUuid("a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11")
      let res = await conn.query("SELECT $1::uuid", @[toPgParam(uuid)])
      doAssert res.rows.len == 1
      doAssert $res.rows[0].getUuid(0) == "a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11"
      await conn.close()

    waitFor t()

  test "int16 and float32 roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res = await conn.query(
        "SELECT $1::int2, $2::float4", @[toPgParam(42'i16), toPgParam(3.14'f32)]
      )
      doAssert res.rows.len == 1
      doAssert res.rows[0].getInt(0) == 42'i32
      doAssert abs(res.rows[0].getFloat(1) - 3.14) < 0.01
      await conn.close()

    waitFor t()

  test "empty string vs NULL":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("CREATE TEMP TABLE test_empty_null (val text)")
      discard await conn.exec(
        "INSERT INTO test_empty_null (val) VALUES ($1)", @[toPgParam("")]
      )
      discard await conn.exec(
        "INSERT INTO test_empty_null (val) VALUES ($1)", @[toPgParam(none(string))]
      )
      let res =
        await conn.query("SELECT val FROM test_empty_null ORDER BY val NULLS LAST")
      doAssert res.rows.len == 2
      doAssert not res.rows[0].isNull(0)
      doAssert res.rows[0].getStr(0) == ""
      doAssert res.rows[1].isNull(0)
      await conn.close()

    waitFor t()

  test "special characters":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let values = @["こんにちは世界", "it's a test", "back\\slash", "NULL"]
      for v in values:
        let res = await conn.query("SELECT $1::text", @[toPgParam(v)])
        doAssert res.rows[0].getStr(0) == v
      await conn.close()

    waitFor t()

suite "E2E: Pool Stress":
  test "concurrent pool operations":
    proc t() {.async.} =
      let pool = await newPool(
        PoolConfig(
          connConfig: plainConfig(),
          minSize: 1,
          maxSize: 3,
          acquireTimeout: seconds(30),
          maintenanceInterval: seconds(30),
        )
      )

      var futures: seq[Future[QueryResult]]
      for i in 0 ..< 20:
        futures.add(pool.query("SELECT pg_backend_pid()"))

      await allFutures(futures)
      var successCount = 0
      for f in futures:
        if f.completed():
          let qr = f.read()
          doAssert qr.rows.len == 1
          successCount.inc
      doAssert successCount == 20

      await pool.close()

    waitFor t()

  test "pool acquire timeout under contention":
    proc t() {.async.} =
      let pool = await newPool(
        PoolConfig(
          connConfig: plainConfig(),
          minSize: 1,
          maxSize: 1,
          acquireTimeout: milliseconds(200),
          maintenanceInterval: seconds(30),
        )
      )

      # Hold the only connection
      let conn = await pool.acquire()

      # Second acquire should timeout
      var raised = false
      try:
        let conn2 = await pool.acquire()
        conn2.release()
      except PgError as e:
        raised = true
        doAssert "timeout" in e.msg.toLowerAscii()

      doAssert raised

      # Release and verify pool still works
      conn.release()
      let res = await pool.query("SELECT 1")
      doAssert res.rows.len == 1
      doAssert res.rows[0].getStr(0) == "1"

      await pool.close()

    waitFor t()

  test "pool handles broken connection":
    proc t() {.async.} =
      let pool = await newPool(
        PoolConfig(
          connConfig: plainConfig(),
          minSize: 1,
          maxSize: 3,
          acquireTimeout: seconds(10),
          maintenanceInterval: seconds(30),
          # Health check with very short idle threshold so acquire pings the connection
          healthCheckTimeout: milliseconds(1),
          pingTimeout: seconds(5),
        )
      )

      # Get a connection and kill its backend
      let conn = await pool.acquire()
      let pidRes = await conn.query("SELECT pg_backend_pid()")
      let pid = pidRes.rows[0].getInt(0)
      conn.release()

      # Kill the backend via a separate connection
      let killer = await connect(plainConfig())
      discard await killer.exec("SELECT pg_terminate_backend($1)", @[toPgParam(pid)])
      await killer.close()

      # Give the server time to terminate the backend
      await sleepAsync(milliseconds(200))

      # Pool should detect broken connection via health check, discard it,
      # create a new connection and work fine
      let res = await pool.query("SELECT 42 AS val")
      doAssert res.rows.len == 1
      doAssert res.rows[0].getStr(0) == "42"

      await pool.close()

    waitFor t()

suite "E2E: Multi-Statement and Large Results":
  test "simpleQuery multiple statements":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let results = await conn.simpleQuery("SELECT 1 AS a; SELECT 2 AS b, 3 AS c")
      doAssert results.len == 2
      doAssert results[0].fields.len == 1
      doAssert results[0].rows.len == 1
      doAssert results[0].rows[0][0].get().toString() == "1"
      doAssert results[1].fields.len == 2
      doAssert results[1].rows.len == 1
      doAssert results[1].rows[0][0].get().toString() == "2"
      doAssert results[1].rows[0][1].get().toString() == "3"
      await conn.close()

    waitFor t()

  test "query 10000 rows":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res = await conn.query("SELECT g FROM generate_series(1, 10000) AS g")
      doAssert res.rows.len == 10000
      doAssert res.rows[0].getStr(0) == "1"
      doAssert res.rows[9999].getStr(0) == "10000"
      await conn.close()

    waitFor t()

  test "cursor over 10000 rows":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let cursor = await conn.openCursor(
        "SELECT g FROM generate_series(1, 10000) AS g", chunkSize = 100
      )

      var totalRows = 0
      while true:
        let chunk = await cursor.fetchNext()
        if chunk.len == 0:
          break
        doAssert chunk.len <= 100
        totalRows += chunk.len

      doAssert totalRows == 10000
      doAssert cursor.exhausted
      doAssert conn.state == csReady
      await conn.close()

    waitFor t()

suite "E2E: Prepared Statement Edge Cases":
  test "20 parameters":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      var placeholders: seq[string]
      var params: seq[PgParam]
      for i in 1 .. 20:
        placeholders.add("$" & $i & "::int")
        params.add(toPgParam(int32(i * 10)))
      let sql = "SELECT " & placeholders.join(", ")
      let stmt = await conn.prepare("stmt_20_params", sql)
      let res = await stmt.execute(params)
      doAssert res.rows.len == 1
      for i in 0 ..< 20:
        doAssert res.rows[0].getInt(i) == int32((i + 1) * 10)
      await stmt.close()
      await conn.close()

    waitFor t()

  test "duplicate name raises error":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let stmt1 = await conn.prepare("dup_stmt", "SELECT 1")
      var raised = false
      try:
        let stmt2 = await conn.prepare("dup_stmt", "SELECT 2")
        discard stmt2
      except PgError:
        raised = true
      doAssert raised
      # Connection should still be usable
      doAssert conn.state == csReady
      let res = await conn.query("SELECT 42")
      doAssert res.rows[0].getStr(0) == "42"
      await stmt1.close()
      await conn.close()

    waitFor t()

suite "E2E: DSN Connection":
  test "connect via parseDsn":
    proc t() {.async.} =
      let config =
        parseDsn("postgresql://test:test@127.0.0.1:15432/test?sslmode=disable")
      let conn = await connect(config)
      doAssert conn.state == csReady
      let res = await conn.query("SELECT 1 AS val")
      doAssert res.rows.len == 1
      doAssert res.rows[0].getStr(0) == "1"
      await conn.close()

    waitFor t()

suite "E2E: JSON and Numeric":
  test "JSON/JSONB as text":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res = await conn.query("""SELECT '{"k":"v"}'::json, '{"n":42}'::jsonb""")
      doAssert res.rows.len == 1
      doAssert res.rows[0].getStr(0) == "{\"k\":\"v\"}"
      doAssert res.rows[0].getStr(1) == "{\"n\": 42}"
      await conn.close()

    waitFor t()

  test "numeric precision":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res = await conn.query(
        "SELECT 12345.6789::numeric, 0.00001::numeric, 99999999999999999.12345678901234567890::numeric"
      )
      doAssert res.rows.len == 1
      doAssert $res.rows[0].getNumeric(0) == "12345.6789"
      doAssert $res.rows[0].getNumeric(1) == "0.00001"
      # Precision preserved - float64 would lose digits here
      doAssert $res.rows[0].getNumeric(2) == "99999999999999999.12345678901234567890"
      await conn.close()

    waitFor t()

  test "numeric negative and NaN":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res = await conn.query("SELECT -123.456::numeric, 'NaN'::numeric")
      doAssert res.rows.len == 1
      doAssert $res.rows[0].getNumeric(0) == "-123.456"
      doAssert $res.rows[0].getNumeric(1) == "NaN"
      await conn.close()

    waitFor t()

  test "numeric fixed precision":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res = await conn.query("SELECT 1.5::numeric(10,4), 0::numeric(8,2)")
      doAssert res.rows.len == 1
      doAssert $res.rows[0].getNumeric(0) == "1.5000"
      doAssert $res.rows[0].getNumeric(1) == "0.00"
      await conn.close()

    waitFor t()

  test "numeric NULL":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res = await conn.query("SELECT NULL::numeric")
      doAssert res.rows.len == 1
      doAssert res.rows[0].getNumericOpt(0) == none(PgNumeric)
      await conn.close()

    waitFor t()

  test "numeric as parameter":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_numeric_param")
      discard await conn.exec("CREATE TABLE test_numeric_param (val numeric(20,8))")
      discard await conn.exec(
        "INSERT INTO test_numeric_param VALUES ($1)",
        @[toPgParam(parsePgNumeric("123456789012.56789012"))],
      )
      let res = await conn.query("SELECT val FROM test_numeric_param")
      doAssert res.rows.len == 1
      doAssert $res.rows[0].getNumeric(0) == "123456789012.56789012"
      discard await conn.exec("DROP TABLE test_numeric_param")
      await conn.close()

    waitFor t()

  test "numeric large integer":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res = await conn.query("SELECT 99999999999999999999999999999::numeric")
      doAssert res.rows.len == 1
      doAssert $res.rows[0].getNumeric(0) == "99999999999999999999999999999"
      await conn.close()

    waitFor t()

suite "E2E: Money":
  test "money binary param and binary result roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      for v in [
        initPgMoney(0),
        initPgMoney(123456),
        initPgMoney(-123456),
        initPgMoney(low(int64)),
        initPgMoney(high(int64)),
      ]:
        let res =
          await conn.query("SELECT $1::money", @[toPgParam(v)], resultFormat = rfBinary)
        doAssert res.rows.len == 1
        doAssert res.rows[0].getMoney(0) == v
      await conn.close()

    waitFor t()

  test "money text result from server":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      # Force C-locale formatting so the test is deterministic regardless of
      # the server's lc_monetary setting.
      discard await conn.exec("SET lc_monetary = 'C'")
      let res = await conn.query("SELECT 1234.56::money")
      doAssert res.rows.len == 1
      doAssert res.rows[0].getMoney(0) == initPgMoney(123456)
      await conn.close()

    waitFor t()

  test "money stored in table":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_money")
      discard await conn.exec("CREATE TABLE test_money (id int, val money)")
      discard await conn.exec(
        "INSERT INTO test_money VALUES (1, $1), (2, $2), (3, $3)",
        @[
          toPgParam(initPgMoney(0)),
          toPgParam(initPgMoney(-123456)),
          toPgParam(initPgMoney(99999999)),
        ],
      )
      let res = await conn.query(
        "SELECT val FROM test_money ORDER BY id", resultFormat = rfBinary
      )
      doAssert res.rows.len == 3
      doAssert res.rows[0].getMoney(0) == initPgMoney(0)
      doAssert res.rows[1].getMoney(0) == initPgMoney(-123456)
      doAssert res.rows[2].getMoney(0) == initPgMoney(99999999)
      discard await conn.exec("DROP TABLE test_money")
      await conn.close()

    waitFor t()

  test "money NULL":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res = await conn.query("SELECT NULL::money", resultFormat = rfBinary)
      doAssert res.rows.len == 1
      doAssert res.rows[0].getMoneyOpt(0) == none(PgMoney)
      await conn.close()

    waitFor t()

  test "money array roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let values = @[initPgMoney(100), initPgMoney(-50), initPgMoney(999999)]
      let res = await conn.query(
        "SELECT $1::money[]", @[toPgParam(values)], resultFormat = rfBinary
      )
      doAssert res.rows.len == 1
      doAssert res.rows[0].getMoneyArray(0) == values
      await conn.close()

    waitFor t()

suite "E2E: Connection Edge Cases":
  test "double close is safe":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      doAssert conn.state == csReady
      await conn.close()
      doAssert conn.state == csClosed
      await conn.close()
      doAssert conn.state == csClosed

    waitFor t()

  test "operations on closed connection":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      await conn.close()

      var raised1 = false
      try:
        discard await conn.exec("SELECT 1")
      except PgError:
        raised1 = true
      doAssert raised1

      var raised2 = false
      try:
        discard await conn.query("SELECT 1")
      except PgError:
        raised2 = true
      doAssert raised2

      var raised3 = false
      try:
        discard await conn.simpleQuery("SELECT 1")
      except PgError:
        raised3 = true
      doAssert raised3

    waitFor t()

suite "E2E: Binary Format":
  test "binary results for int types":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let qr = await conn.query(
        "SELECT 42::int2, 123456::int4, 9999999999::int8", resultFormat = rfBinary
      )
      doAssert qr.rows.len == 1
      let row = qr.rows[0]
      doAssert row.getInt(0) == 42'i32 # int2 promoted via getInt
      doAssert row.getInt(1) == 123456'i32
      doAssert row.getInt64(2) == 9999999999'i64
      # getInt64 should also work on int2/int4 columns (promotion)
      doAssert row.getInt64(0) == 42'i64
      doAssert row.getInt64(1) == 123456'i64
      await conn.close()

    waitFor t()

  test "binary results for float types":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let qr =
        await conn.query("SELECT 3.14::float8, 1.5::float4", resultFormat = rfBinary)
      doAssert qr.rows.len == 1
      let row = qr.rows[0]
      doAssert abs(row.getFloat(0) - 3.14) < 1e-10
      doAssert abs(row.getFloat(1) - 1.5) < 1e-5
      await conn.close()

    waitFor t()

  test "binary results for bool":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let qr = await conn.query("SELECT true, false", resultFormat = rfBinary)
      doAssert qr.rows.len == 1
      doAssert qr.rows[0].getBool(0) == true
      doAssert qr.rows[0].getBool(1) == false
      await conn.close()

    waitFor t()

  test "binary results for text":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let qr = await conn.query(
        "SELECT 'hello'::text, 'world'::varchar", resultFormat = rfBinary
      )
      doAssert qr.rows.len == 1
      doAssert qr.rows[0].getStr(0) == "hello"
      doAssert qr.rows[0].getStr(1) == "world"
      await conn.close()

    waitFor t()

  test "binary results for bytea":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let qr = await conn.query("SELECT '\\xDEADBEEF'::bytea", resultFormat = rfBinary)
      doAssert qr.rows.len == 1
      doAssert qr.rows[0].getBytes(0) == @[0xDE'u8, 0xAD, 0xBE, 0xEF]
      await conn.close()

    waitFor t()

  test "binary results for timestamp":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let qr = await conn.query(
        "SELECT '2024-01-15 10:30:00'::timestamp", resultFormat = rfBinary
      )
      doAssert qr.rows.len == 1
      let dt = qr.rows[0].getTimestamp(0)
      doAssert dt.year == 2024
      doAssert dt.month == mJan
      doAssert dt.monthday == 15
      doAssert dt.hour == 10
      doAssert dt.minute == 30
      await conn.close()

    waitFor t()

  test "binary results for date":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let qr = await conn.query("SELECT '2024-01-15'::date", resultFormat = rfBinary)
      doAssert qr.rows.len == 1
      let dt = qr.rows[0].getDate(0)
      doAssert dt.year == 2024
      doAssert dt.month == mJan
      doAssert dt.monthday == 15
      await conn.close()

    waitFor t()

  test "binary results for uuid":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let qr = await conn.query(
        "SELECT '550e8400-e29b-41d4-a716-446655440000'::uuid", resultFormat = rfBinary
      )
      doAssert qr.rows.len == 1
      let data = qr.rows[0].getBytes(0)
      doAssert data.len == 16
      doAssert data[0] == 0x55'u8
      doAssert data[1] == 0x0e'u8
      await conn.close()

    waitFor t()

  test "binary params and binary results roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let params = @[
        toPgBinaryParam(42'i32), toPgBinaryParam(9999999999'i64), toPgBinaryParam(true)
      ]
      let qr = await conn.query(
        "SELECT $1::int4, $2::int8, $3::bool", params, resultFormat = rfBinary
      )
      doAssert qr.rows.len == 1
      doAssert qr.rows[0].getInt(0) == 42'i32
      doAssert qr.rows[0].getInt64(1) == 9999999999'i64
      doAssert qr.rows[0].getBool(2) == true
      await conn.close()

    waitFor t()

  test "binary params with text results":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let params = @[toPgBinaryParam(42'i32)]
      let qr = await conn.query("SELECT $1::int4", params)
      doAssert qr.rows.len == 1
      doAssert qr.rows[0].getInt(0) == 42'i32
      await conn.close()

    waitFor t()

  test "text params with binary results":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let params = @[toPgParam(42'i32)]
      let qr = await conn.query("SELECT $1::int4", params, resultFormat = rfBinary)
      doAssert qr.rows.len == 1
      doAssert qr.rows[0].getInt(0) == 42'i32
      await conn.close()

    waitFor t()

  test "NULL handling in binary mode":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let qr =
        await conn.query("SELECT NULL::int4, NULL::text", resultFormat = rfBinary)
      doAssert qr.rows.len == 1
      doAssert qr.rows[0].isNull(0)
      doAssert qr.rows[0].isNull(1)
      await conn.close()

    waitFor t()

  test "prepared statement with binary results":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let stmt = await conn.prepare("bin_stmt", "SELECT $1::int4 + 10")
      let qr = await stmt.execute(@[toPgBinaryParam(32'i32)], resultFormat = rfBinary)
      doAssert qr.rows.len == 1
      doAssert qr.rows[0].getInt(0) == 42'i32
      await stmt.close()
      await conn.close()

    waitFor t()

  test "binary timestamp param roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let dt = dateTime(2024, mJan, 15, 10, 30, 0, 0, utc())
      let params = @[toPgBinaryParam(dt)]
      let qr = await conn.query("SELECT $1::timestamp", params, resultFormat = rfBinary)
      doAssert qr.rows.len == 1
      let r = qr.rows[0].getTimestamp(0)
      doAssert r.year == 2024
      doAssert r.month == mJan
      doAssert r.monthday == 15
      doAssert r.hour == 10
      doAssert r.minute == 30
      await conn.close()

    waitFor t()

  test "binary time param roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let tm = PgTime(hour: 14, minute: 30, second: 45, microsecond: 123456)
      let params = @[toPgBinaryParam(tm)]
      let qr = await conn.query("SELECT $1::time", params, resultFormat = rfBinary)
      doAssert qr.rows.len == 1
      let got = qr.rows[0].getTime(0)
      doAssert got == tm
      await conn.close()

    waitFor t()

  test "binary timetz param roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let tm =
        PgTimeTz(hour: 14, minute: 30, second: 45, microsecond: 0, utcOffset: 18000)
      let params = @[toPgBinaryParam(tm)]
      let qr = await conn.query("SELECT $1::timetz", params, resultFormat = rfBinary)
      doAssert qr.rows.len == 1
      let got = qr.rows[0].getTimeTz(0)
      doAssert got == tm
      await conn.close()

    waitFor t()

  test "binary date param roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let dt = dateTime(2024, mJan, 15, 0, 0, 0, 0, utc())
      let params = @[toPgBinaryDateParam(dt)]
      let qr = await conn.query("SELECT $1::date", params, resultFormat = rfBinary)
      doAssert qr.rows.len == 1
      let got = qr.rows[0].getDate(0)
      doAssert got.year == 2024
      doAssert got.month == mJan
      doAssert got.monthday == 15
      await conn.close()

    waitFor t()

  test "binary timestamptz param roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let dt = dateTime(2024, mJan, 15, 10, 30, 0, 0, utc())
      let params = @[toPgBinaryTimestampTzParam(dt)]
      let qr =
        await conn.query("SELECT $1::timestamptz", params, resultFormat = rfBinary)
      doAssert qr.rows.len == 1
      let got = qr.rows[0].getTimestampTz(0)
      doAssert got.year == 2024
      doAssert got.month == mJan
      doAssert got.monthday == 15
      doAssert got.hour == 10
      doAssert got.minute == 30
      await conn.close()

    waitFor t()

  test "binary float roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let params = @[toPgBinaryParam(3.14159265358979)]
      let qr = await conn.query("SELECT $1::float8", params, resultFormat = rfBinary)
      doAssert qr.rows.len == 1
      doAssert abs(qr.rows[0].getFloat(0) - 3.14159265358979) < 1e-14
      await conn.close()

    waitFor t()

  test "binary bytea param roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let data = @[0xDE'u8, 0xAD, 0xBE, 0xEF, 0x00, 0xFF]
      let params = @[toPgBinaryParam(data)]
      let qr = await conn.query("SELECT $1::bytea", params, resultFormat = rfBinary)
      doAssert qr.rows.len == 1
      doAssert qr.rows[0].getBytes(0) == data
      await conn.close()

    waitFor t()

suite "E2E: recvMessage Timeout":
  test "recvMessage with timeout succeeds on immediate response":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      # Send a simple query and receive with timeout
      await conn.sendMsg(encodeQuery("SELECT 1"))
      var gotRowData = false
      var gotComplete = false
      while true:
        let msg = await conn.recvMessage(timeout = seconds(5))
        case msg.kind
        of bmkRowDescription:
          discard
        of bmkDataRow:
          gotRowData = true
        of bmkCommandComplete:
          gotComplete = true
        of bmkReadyForQuery:
          break
        else:
          discard
      doAssert gotRowData
      doAssert gotComplete
      await conn.close()

    waitFor t()

  test "recvMessage with timeout raises AsyncTimeoutError when no data":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      # Don't send anything — recvMessage should timeout waiting for data
      var raised = false
      try:
        discard await conn.recvMessage(timeout = milliseconds(100))
      except AsyncTimeoutError:
        raised = true
      doAssert raised

    waitFor t()

  test "recvMessage buffer restored after timeout":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      # Logical unconsumed size (compactRecvBuf may shrink the raw buffer)
      let unconsumedBefore = conn.recvBuf.len - conn.recvBufStart
      # Trigger a timeout with no pending server data
      try:
        discard await conn.recvMessage(timeout = milliseconds(100))
      except AsyncTimeoutError:
        discard
      # recvBuf must not grow from the failed read
      let unconsumedAfter = conn.recvBuf.len - conn.recvBufStart
      doAssert unconsumedAfter == unconsumedBefore
      await conn.close()

    waitFor t()

  test "recvMessage timeout on large result set":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      # Start a query that produces a large result, then timeout mid-stream
      await conn.sendMsg(encodeQuery("SELECT generate_series(1, 100000)"))
      var raised = false
      try:
        # Very short timeout — unlikely to receive all messages in time
        while true:
          discard await conn.recvMessage(timeout = milliseconds(1))
      except AsyncTimeoutError:
        raised = true
      doAssert raised

    waitFor t()

  test "recvMessage without timeout (default) does not raise on normal message":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      await conn.sendMsg(encodeQuery("SELECT 42"))
      var value = ""
      while true:
        let msg = await conn.recvMessage() # default: no timeout
        case msg.kind
        of bmkDataRow:
          if msg.columns.len > 0 and msg.columns[0].isSome:
            value = cast[string](msg.columns[0].get())
        of bmkReadyForQuery:
          break
        else:
          discard
      doAssert value == "42"
      await conn.close()

    waitFor t()

suite "E2E: Notification Buffering":
  test "notifications buffered without callback":
    proc t() {.async.} =
      let listener = await connect(plainConfig())
      let sender = await connect(plainConfig())

      # No callback set — notifications should still be buffered
      await listener.listen("buf_nocb")

      await sender.notify("buf_nocb", "msg1")
      await sender.notify("buf_nocb", "msg2")
      await sleepAsync(milliseconds(200))

      doAssert listener.notifyQueue.len == 2
      let n1 = listener.notifyQueue.popFirst()
      doAssert n1.channel == "buf_nocb"
      doAssert n1.payload == "msg1"
      let n2 = listener.notifyQueue.popFirst()
      doAssert n2.channel == "buf_nocb"
      doAssert n2.payload == "msg2"

      await listener.unlisten("buf_nocb")
      await listener.close()
      await sender.close()

    waitFor t()

  test "notifications buffered alongside callback":
    proc t() {.async.} =
      let listener = await connect(plainConfig())
      let sender = await connect(plainConfig())

      var cbReceived: seq[Notification]
      listener.onNotify(
        proc(n: Notification) {.gcsafe, raises: [].} =
          cbReceived.add(n)
      )
      await listener.listen("buf_both")

      await sender.notify("buf_both", "hello")
      await sleepAsync(milliseconds(200))

      # Both callback and queue should have the notification
      doAssert cbReceived.len == 1
      doAssert listener.notifyQueue.len == 1
      doAssert listener.notifyQueue.peekFirst().payload == "hello"

      await listener.unlisten("buf_both")
      await listener.close()
      await sender.close()

    waitFor t()

  test "buffer respects max queue size and tracks drops":
    proc t() {.async.} =
      let listener = await connect(plainConfig())
      let sender = await connect(plainConfig())

      listener.notifyMaxQueue = 3
      await listener.listen("buf_max")

      for i in 1 .. 5:
        await sender.notify("buf_max", $i)
      await sleepAsync(milliseconds(300))

      # Only last 3 should remain (oldest dropped)
      doAssert listener.notifyQueue.len == 3
      doAssert listener.notifyDropped == 2

      # waitNotification should raise PgNotifyOverflowError
      var caught = false
      try:
        discard await listener.waitNotification()
      except PgNotifyOverflowError as e:
        caught = true
        doAssert e.dropped == 2
      doAssert caught

      # After overflow is cleared, normal access works
      doAssert listener.notifyDropped == 0
      let n = await listener.waitNotification()
      doAssert n.payload == "3"
      doAssert listener.notifyQueue.popFirst().payload == "4"
      doAssert listener.notifyQueue.popFirst().payload == "5"

      await listener.unlisten("buf_max")
      await listener.close()
      await sender.close()

    waitFor t()

  test "notifyOverflowCallback fires on drop":
    proc t() {.async.} =
      let listener = await connect(plainConfig())
      let sender = await connect(plainConfig())

      listener.notifyMaxQueue = 2
      var cbDropped = 0
      listener.notifyOverflowCallback = proc(dropped: int) {.gcsafe, raises: [].} =
        cbDropped += dropped

      await listener.listen("buf_cb")

      for i in 1 .. 4:
        await sender.notify("buf_cb", $i)
      await sleepAsync(milliseconds(300))

      # 4 notifications into queue of 2: 2 dropped
      doAssert cbDropped == 2
      doAssert listener.notifyDropped == 2

      await listener.unlisten("buf_cb")
      await listener.close()
      await sender.close()

    waitFor t()

suite "E2E: waitNotification":
  test "waitNotification returns buffered notification immediately":
    proc t() {.async.} =
      let listener = await connect(plainConfig())
      let sender = await connect(plainConfig())

      await listener.listen("wait_imm")

      await sender.notify("wait_imm", "instant")
      await sleepAsync(milliseconds(200))

      let notif = await listener.waitNotification()
      doAssert notif.channel == "wait_imm"
      doAssert notif.payload == "instant"
      doAssert listener.notifyQueue.len == 0

      await listener.unlisten("wait_imm")
      await listener.close()
      await sender.close()

    waitFor t()

  test "waitNotification blocks until notification arrives":
    proc t() {.async.} =
      let listener = await connect(plainConfig())
      let sender = await connect(plainConfig())

      await listener.listen("wait_block")

      # Start waiting before notification is sent
      let waitFut = listener.waitNotification()

      await sleepAsync(milliseconds(50))
      doAssert not waitFut.finished

      await sender.notify("wait_block", "delayed")
      await sleepAsync(milliseconds(200))

      doAssert waitFut.finished
      let notif = await waitFut
      doAssert notif.channel == "wait_block"
      doAssert notif.payload == "delayed"

      await listener.unlisten("wait_block")
      await listener.close()
      await sender.close()

    waitFor t()

  test "waitNotification with timeout raises on expiry":
    proc t() {.async.} =
      let listener = await connect(plainConfig())

      await listener.listen("wait_timeout")

      var raised = false
      try:
        discard await listener.waitNotification(timeout = milliseconds(100))
      except PgError as e:
        raised = true
        doAssert "timed out" in e.msg
      doAssert raised

      await listener.unlisten("wait_timeout")
      await listener.close()

    waitFor t()

  test "waitNotification drains queue in order":
    proc t() {.async.} =
      let listener = await connect(plainConfig())
      let sender = await connect(plainConfig())

      await listener.listen("wait_order")

      await sender.notify("wait_order", "first")
      await sender.notify("wait_order", "second")
      await sender.notify("wait_order", "third")
      await sleepAsync(milliseconds(200))

      let n1 = await listener.waitNotification()
      let n2 = await listener.waitNotification()
      let n3 = await listener.waitNotification()
      doAssert n1.payload == "first"
      doAssert n2.payload == "second"
      doAssert n3.payload == "third"

      await listener.unlisten("wait_order")
      await listener.close()
      await sender.close()

    waitFor t()

when hasChronos:
  suite "E2E: LISTEN/NOTIFY Auto-Reconnect":
    test "reconnectInPlace restores connection and re-subscribes":
      proc t() {.async.} =
        let listener = await connect(plainConfig())
        let sender = await connect(plainConfig())

        var received: seq[Notification]
        listener.onNotify(
          proc(n: Notification) {.gcsafe, raises: [].} =
            received.add(n)
        )
        await listener.listen("reconn_manual")

        # Send before reconnect
        await sender.notify("reconn_manual", "before")
        await sleepAsync(milliseconds(200))
        doAssert received.len == 1

        # Force reconnect
        await listener.stopListening()
        await listener.reconnectInPlace()
        doAssert listener.state == csReady
        doAssert sets.contains(listener.listenChannels, "reconn_manual")

        # Channel was re-LISTENed by reconnectInPlace, start pump again
        listener.state = csListening
        listener.listenTask = listener.listenPump()

        await sender.notify("reconn_manual", "after")
        await sleepAsync(milliseconds(200))
        doAssert received.len == 2
        doAssert received[1].payload == "after"

        await listener.close()
        await sender.close()

      waitFor t()

    test "reconnectCallback is invoked on auto-reconnect":
      proc t() {.async.} =
        let listener = await connect(plainConfig())

        var reconnected = false
        listener.reconnectCallback = proc() {.gcsafe, raises: [].} =
          reconnected = true

        await listener.listen("reconn_cb")

        # Kill the connection from the server side
        let killer = await connect(plainConfig())
        try:
          discard await killer.exec(
            "SELECT pg_terminate_backend($1)", @[toPgParam(listener.pid)]
          )
        except PgError:
          discard
        await killer.close()

        # Wait for reconnect (backoff starts at 1s)
        await sleepAsync(milliseconds(3000))

        doAssert reconnected
        doAssert listener.state == csListening

        # Verify notifications still work after reconnect
        let sender = await connect(plainConfig())
        var received: seq[Notification]
        listener.onNotify(
          proc(n: Notification) {.gcsafe, raises: [].} =
            received.add(n)
        )

        await sender.notify("reconn_cb", "after_reconnect")
        await sleepAsync(milliseconds(200))
        doAssert received.len == 1
        doAssert received[0].payload == "after_reconnect"

        await listener.close()
        await sender.close()

      waitFor t()

    test "close during reconnect does not hang":
      proc t() {.async.} =
        let listener = await connect(plainConfig())
        await listener.listen("reconn_close")

        # Kill the connection
        let killer = await connect(plainConfig())
        try:
          discard await killer.exec(
            "SELECT pg_terminate_backend($1)", @[toPgParam(listener.pid)]
          )
        except PgError:
          discard
        await killer.close()

        # Give pump time to detect the failure and start reconnecting
        await sleepAsync(milliseconds(500))

        # Close should not hang even if reconnect is in progress
        await listener.close().wait(seconds(5))
        doAssert listener.state == csClosed

      waitFor t()

    test "listenReconnect config defaults":
      proc t() {.async.} =
        let conn = await connect(plainConfig())
        doAssert conn.listenReconnectMaxAttempts == 10
        doAssert conn.listenReconnectMaxBackoff == 30
        await conn.close()

      waitFor t()

    test "listenReconnect config setters":
      proc t() {.async.} =
        let conn = await connect(plainConfig())
        conn.listenReconnectMaxAttempts = 3
        conn.listenReconnectMaxBackoff = 5
        doAssert conn.listenReconnectMaxAttempts == 3
        doAssert conn.listenReconnectMaxBackoff == 5
        # 0 = unlimited (sentinel)
        conn.listenReconnectMaxAttempts = 0
        doAssert conn.listenReconnectMaxAttempts == 0
        await conn.close()

      waitFor t()

    test "auto-reconnect honors custom maxAttempts setting":
      proc t() {.async.} =
        let listener = await connect(plainConfig())
        listener.listenReconnectMaxAttempts = 2
        listener.listenReconnectMaxBackoff = 1

        var reconnected = false
        listener.reconnectCallback = proc() {.gcsafe, raises: [].} =
          reconnected = true

        await listener.listen("reconn_custom")

        let killer = await connect(plainConfig())
        try:
          discard await killer.exec(
            "SELECT pg_terminate_backend($1)", @[toPgParam(listener.pid)]
          )
        except PgError:
          discard
        await killer.close()

        # First retry runs after backoff=1s; reconnect should succeed.
        await sleepAsync(milliseconds(3000))
        doAssert reconnected
        doAssert listener.state == csListening

        await listener.close()

      waitFor t()

    test "auto-reconnect with unlimited attempts (maxAttempts=0)":
      proc t() {.async.} =
        let listener = await connect(plainConfig())
        listener.listenReconnectMaxAttempts = 0 # unlimited
        listener.listenReconnectMaxBackoff = 1

        var reconnected = false
        listener.reconnectCallback = proc() {.gcsafe, raises: [].} =
          reconnected = true

        await listener.listen("reconn_unlimited")

        let killer = await connect(plainConfig())
        try:
          discard await killer.exec(
            "SELECT pg_terminate_backend($1)", @[toPgParam(listener.pid)]
          )
        except PgError:
          discard
        await killer.close()

        await sleepAsync(milliseconds(3000))
        doAssert reconnected
        doAssert listener.state == csListening

        await listener.close()

      waitFor t()

    test "waitNotification fails on close":
      proc t() {.async.} =
        let listener = await connect(plainConfig())
        await listener.listen("wait_close")

        let waitFut = listener.waitNotification()
        await sleepAsync(milliseconds(50))
        doAssert not waitFut.finished

        await listener.close()

        var raised = false
        try:
          discard await waitFut
        except PgError:
          raised = true
        doAssert raised

      waitFor t()

    test "concurrent waitNotification raises error":
      proc t() {.async.} =
        let listener = await connect(plainConfig())
        await listener.listen("wait_concurrent")

        let waitFut1 = listener.waitNotification()
        await sleepAsync(milliseconds(10))
        doAssert not waitFut1.finished

        var raised = false
        try:
          discard await listener.waitNotification()
        except PgError:
          raised = true
        doAssert raised

        # Clean up: complete the first waiter by sending a notification
        let sender = await connect(plainConfig())
        discard await sender.query("NOTIFY wait_concurrent, 'done'")
        let notif = await waitFut1
        doAssert notif.channel == "wait_concurrent"
        doAssert notif.payload == "done"

        await sender.close()
        await listener.close()

      waitFor t()

suite "E2E: Array Types":
  test "int4 array roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res = await conn.query("SELECT $1::int4[]", @[toPgParam(@[1'i32, 2, 3])])
      doAssert res.rows.len == 1
      doAssert res.rows[0].getIntArray(0) == @[1'i32, 2, 3]
      await conn.close()

    waitFor t()

  test "int8 array roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res =
        await conn.query("SELECT $1::int8[]", @[toPgParam(@[9999999999'i64, -1'i64])])
      doAssert res.rows.len == 1
      doAssert res.rows[0].getInt64Array(0) == @[9999999999'i64, -1'i64]
      await conn.close()

    waitFor t()

  test "bool array roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res =
        await conn.query("SELECT $1::bool[]", @[toPgParam(@[true, false, true])])
      doAssert res.rows.len == 1
      doAssert res.rows[0].getBoolArray(0) == @[true, false, true]
      await conn.close()

    waitFor t()

  test "text array roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res = await conn.query(
        "SELECT $1::text[]", @[toPgParam(@["hello", "world", "foo bar"])]
      )
      doAssert res.rows.len == 1
      doAssert res.rows[0].getStrArray(0) == @["hello", "world", "foo bar"]
      await conn.close()

    waitFor t()

  test "text array with special characters":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res = await conn.query(
        "SELECT $1::text[]", @[toPgParam(@["a\"b", "c\\d", "e,f", ""])]
      )
      doAssert res.rows.len == 1
      doAssert res.rows[0].getStrArray(0) == @["a\"b", "c\\d", "e,f", ""]
      await conn.close()

    waitFor t()

  test "empty array roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res = await conn.query("SELECT $1::int4[]", @[toPgParam(newSeq[int32]())])
      doAssert res.rows.len == 1
      doAssert res.rows[0].getIntArray(0).len == 0
      await conn.close()

    waitFor t()

  test "float8 array roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res = await conn.query("SELECT $1::float8[]", @[toPgParam(@[3.14, 2.72])])
      doAssert res.rows.len == 1
      let arr = res.rows[0].getFloatArray(0)
      doAssert abs(arr[0] - 3.14) < 1e-10
      doAssert abs(arr[1] - 2.72) < 1e-10
      await conn.close()

    waitFor t()

  test "NULL array column":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res = await conn.query("SELECT $1::int4[]", @[toPgParam(none(seq[int32]))])
      doAssert res.rows.len == 1
      doAssert res.rows[0].isNull(0)
      doAssert res.rows[0].getIntArrayOpt(0).isNone
      await conn.close()

    waitFor t()

suite "E2E: COPY IN Stream":
  test "copyInStream basic streaming":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_copyin_stream")
      discard await conn.exec("CREATE TABLE test_copyin_stream (id int, name text)")

      var idx = 0
      let rows =
        @["1\tAlice\n".toBytes(), "2\tBob\n".toBytes(), "3\tCharlie\n".toBytes()]
      let cb = makeCopyInCallback:
        if idx < rows.len:
          let chunk = rows[idx]
          inc idx
          chunk
        else:
          newSeq[byte]()

      let info = await conn.copyInStream("COPY test_copyin_stream FROM STDIN", cb)
      doAssert "COPY 3" in info.commandTag
      doAssert info.format == cfText
      doAssert conn.state == csReady

      let res = await conn.query("SELECT id, name FROM test_copyin_stream ORDER BY id")
      doAssert res.rows.len == 3
      doAssert res.rows[0].getStr(1) == "Alice"
      doAssert res.rows[2].getStr(1) == "Charlie"

      discard await conn.exec("DROP TABLE test_copyin_stream")
      await conn.close()

    waitFor t()

  test "copyInStream empty data (immediate EOF)":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_copyin_empty")
      discard await conn.exec("CREATE TABLE test_copyin_empty (id int)")

      let cb = makeCopyInCallback:
        newSeq[byte]()

      let info = await conn.copyInStream("COPY test_copyin_empty FROM STDIN", cb)
      doAssert "COPY 0" in info.commandTag
      doAssert conn.state == csReady

      discard await conn.exec("DROP TABLE test_copyin_empty")
      await conn.close()

    waitFor t()

  test "copyInStream callback error sends CopyFail":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_copyin_fail")
      discard await conn.exec("CREATE TABLE test_copyin_fail (id int)")

      var callCount = 0
      let cb = makeCopyInCallback:
        inc callCount
        if callCount == 1:
          "1\n".toBytes()
        else:
          raise newException(CatchableError, "callback failed")

      var raised = false
      try:
        discard await conn.copyInStream("COPY test_copyin_fail FROM STDIN", cb)
      except CatchableError as e:
        raised = true
        doAssert "callback failed" in e.msg
      doAssert raised
      doAssert conn.state == csReady

      # Connection should still be usable
      let res = await conn.query("SELECT count(*) FROM test_copyin_fail")
      doAssert res.rows[0].getStr(0) == "0" # CopyFail aborted the COPY

      discard await conn.exec("DROP TABLE test_copyin_fail")
      await conn.close()

    waitFor t()

  test "copyInStream invalid SQL raises PgError":
    proc t() {.async.} =
      let conn = await connect(plainConfig())

      let cb = makeCopyInCallback:
        newSeq[byte]()

      var raised = false
      try:
        discard await conn.copyInStream("COPY nonexistent_table FROM STDIN", cb)
      except PgError:
        raised = true
      doAssert raised
      doAssert conn.state == csReady

      # Connection should still be usable
      let res = await conn.simpleQuery("SELECT 1")
      doAssert res[0].rows[0][0].get().toString() == "1"

      await conn.close()

    waitFor t()

  test "copyInStream large data (10000 rows)":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_copyin_large")
      discard await conn.exec("CREATE TABLE test_copyin_large (id int, val text)")

      var idx = 0
      let cb = makeCopyInCallback:
        if idx < 10000:
          let row = ($idx & "\trow_" & $idx & "\n").toBytes()
          inc idx
          row
        else:
          newSeq[byte]()

      let info = await conn.copyInStream("COPY test_copyin_large FROM STDIN", cb)
      doAssert "COPY 10000" in info.commandTag
      doAssert conn.state == csReady

      let res = await conn.query("SELECT count(*) FROM test_copyin_large")
      doAssert res.rows[0].getStr(0) == "10000"

      discard await conn.exec("DROP TABLE test_copyin_large")
      await conn.close()

    waitFor t()

  test "copyInStream format info in CopyInInfo":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_copyin_info")
      discard await conn.exec("CREATE TABLE test_copyin_info (id int, name text)")

      let cb = makeCopyInCallback:
        newSeq[byte]()

      let info = await conn.copyInStream("COPY test_copyin_info FROM STDIN", cb)
      doAssert info.format == cfText
      doAssert info.columnFormats.len == 2
      doAssert info.columnFormats[0] == 0'i16 # text format
      doAssert info.columnFormats[1] == 0'i16

      discard await conn.exec("DROP TABLE test_copyin_info")
      await conn.close()

    waitFor t()

suite "E2E: COPY Failure Recovery":
  test "copyIn bad data inside txn: rollback recovers and next query works":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_copy_fail_txn")
      discard await conn.exec("CREATE TABLE test_copy_fail_txn (id int, name text)")

      discard await conn.exec("BEGIN")
      doAssert conn.txStatus == tsInTransaction

      var raised = false
      try:
        # "abc" is not a valid int4 -> server raises invalid_text_representation
        discard await conn.copyIn(
          "COPY test_copy_fail_txn FROM STDIN", @["abc\tAlice\n".toBytes()]
        )
      except PgError:
        raised = true
      doAssert raised
      doAssert conn.state == csReady
      doAssert conn.txStatus == tsInFailedTransaction

      # Any query in a failed txn errors until ROLLBACK
      var stillFailed = false
      try:
        discard await conn.query("SELECT 1")
      except PgError:
        stillFailed = true
      doAssert stillFailed
      doAssert conn.txStatus == tsInFailedTransaction

      discard await conn.exec("ROLLBACK")
      doAssert conn.txStatus == tsIdle

      let res = await conn.query("SELECT 1")
      doAssert res.rows[0].getStr(0) == "1"

      let cnt = await conn.query("SELECT count(*) FROM test_copy_fail_txn")
      doAssert cnt.rows[0].getStr(0) == "0"

      discard await conn.exec("DROP TABLE test_copy_fail_txn")
      await conn.close()

    waitFor t()

  test "copyIn invalid SQL inside txn: rollback recovers":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("BEGIN")
      doAssert conn.txStatus == tsInTransaction

      var raised = false
      try:
        discard await conn.copyIn(
          "COPY nonexistent_table_xyz FROM STDIN", @["1\ttest\n".toBytes()]
        )
      except PgError:
        raised = true
      doAssert raised
      doAssert conn.state == csReady
      doAssert conn.txStatus == tsInFailedTransaction

      discard await conn.exec("ROLLBACK")
      doAssert conn.txStatus == tsIdle

      let res = await conn.query("SELECT 42")
      doAssert res.rows[0].getStr(0) == "42"

      await conn.close()

    waitFor t()

  test "copyInStream callback error inside txn: rollback recovers":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_copy_fail_stream_txn")
      discard
        await conn.exec("CREATE TABLE test_copy_fail_stream_txn (id int, name text)")

      discard await conn.exec("BEGIN")
      doAssert conn.txStatus == tsInTransaction
      discard
        await conn.exec("INSERT INTO test_copy_fail_stream_txn VALUES (1, 'pre-copy')")

      var callCount = 0
      let cb = makeCopyInCallback:
        inc callCount
        if callCount == 1:
          "1\tfirst\n".toBytes()
        else:
          raise newException(CatchableError, "stream aborted")

      var raised = false
      try:
        discard await conn.copyInStream("COPY test_copy_fail_stream_txn FROM STDIN", cb)
      except CatchableError as e:
        raised = true
        doAssert "stream aborted" in e.msg
      doAssert raised
      doAssert conn.state == csReady
      # CopyFail inside txn aborts the transaction
      doAssert conn.txStatus == tsInFailedTransaction

      discard await conn.exec("ROLLBACK")
      doAssert conn.txStatus == tsIdle

      # Table was created + pre-copy row inserted, both rolled back
      let cnt = await conn.query("SELECT count(*) FROM test_copy_fail_stream_txn")
      doAssert cnt.rows[0].getStr(0) == "0"

      discard await conn.exec("DROP TABLE test_copy_fail_stream_txn")
      await conn.close()

    waitFor t()

  test "copyOut invalid SQL inside txn: rollback recovers":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("BEGIN")
      doAssert conn.txStatus == tsInTransaction

      var raised = false
      try:
        discard await conn.copyOut("COPY nonexistent_table_xyz TO STDOUT")
      except PgError:
        raised = true
      doAssert raised
      doAssert conn.state == csReady
      doAssert conn.txStatus == tsInFailedTransaction

      discard await conn.exec("ROLLBACK")
      doAssert conn.txStatus == tsIdle

      let res = await conn.query("SELECT 7")
      doAssert res.rows[0].getStr(0) == "7"

      await conn.close()

    waitFor t()

  test "copyOutStream callback error inside txn: rollback recovers":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_copy_out_fail_txn")
      discard await conn.exec("CREATE TABLE test_copy_out_fail_txn (id int)")
      discard await conn.exec(
        "INSERT INTO test_copy_out_fail_txn SELECT g FROM generate_series(1, 200) AS g"
      )

      discard await conn.exec("BEGIN")
      doAssert conn.txStatus == tsInTransaction

      var chunkCount = 0
      let failingCb = makeCopyOutCallback:
        inc chunkCount
        raise newException(CatchableError, "out callback failed")

      var raised = false
      try:
        discard
          await conn.copyOutStream("COPY test_copy_out_fail_txn TO STDOUT", failingCb)
      except CatchableError as e:
        raised = true
        doAssert "out callback failed" in e.msg
      doAssert raised
      doAssert chunkCount >= 1
      doAssert conn.state == csReady
      # COPY OUT has no client->server abort; server completes normally so tx
      # remains in-transaction even though the client callback failed.
      doAssert conn.txStatus == tsInTransaction

      discard await conn.exec("ROLLBACK")
      doAssert conn.txStatus == tsIdle

      let res = await conn.query("SELECT 1")
      doAssert res.rows[0].getStr(0) == "1"

      discard await conn.exec("DROP TABLE test_copy_out_fail_txn")
      await conn.close()

    waitFor t()

  test "cursor works after copyIn failure (portal state clean)":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_copy_portal")
      discard await conn.exec("CREATE TABLE test_copy_portal (id int)")
      discard await conn.exec(
        "INSERT INTO test_copy_portal SELECT g FROM generate_series(1, 30) AS g"
      )

      var raised = false
      try:
        discard await conn.copyIn(
          "COPY test_copy_portal FROM STDIN", @["not_an_int\n".toBytes()]
        )
      except PgError:
        raised = true
      doAssert raised
      doAssert conn.state == csReady
      doAssert conn.txStatus == tsIdle

      # Subsequent portal-based cursor op must succeed
      let cursor = await conn.openCursor(
        "SELECT id FROM test_copy_portal ORDER BY id", chunkSize = 10
      )
      var total = 0
      while true:
        let chunk = await cursor.fetchNext()
        if chunk.len == 0:
          break
        total += chunk.len
      doAssert total == 30
      doAssert conn.state == csReady

      discard await conn.exec("DROP TABLE test_copy_portal")
      await conn.close()

    waitFor t()

  test "cursor works after copyOut failure (portal state clean)":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_copy_out_portal")
      discard await conn.exec("CREATE TABLE test_copy_out_portal (id int)")
      discard await conn.exec(
        "INSERT INTO test_copy_out_portal SELECT g FROM generate_series(1, 15) AS g"
      )

      var raised = false
      try:
        discard await conn.copyOut("COPY nonexistent_portal_tbl TO STDOUT")
      except PgError:
        raised = true
      doAssert raised
      doAssert conn.state == csReady
      doAssert conn.txStatus == tsIdle

      let cursor = await conn.openCursor(
        "SELECT id FROM test_copy_out_portal ORDER BY id", chunkSize = 5
      )
      var total = 0
      while true:
        let chunk = await cursor.fetchNext()
        if chunk.len == 0:
          break
        total += chunk.len
      doAssert total == 15

      discard await conn.exec("DROP TABLE test_copy_out_portal")
      await conn.close()

    waitFor t()

suite "E2E: COPY IN openArray[byte]":
  test "copyIn with openArray[byte] inserts rows":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_copy_raw")
      discard await conn.exec("CREATE TABLE test_copy_raw (id int, name text)")

      let data = "1\tAlice\n2\tBob\n3\tCharlie\n"
      let tag = await conn.copyIn(
        "COPY test_copy_raw FROM STDIN", data.toOpenArrayByte(0, data.high)
      )
      doAssert "COPY 3" in tag

      let res = await conn.query("SELECT id, name FROM test_copy_raw ORDER BY id")
      doAssert res.rows.len == 3
      doAssert res.rows[0].getStr(1) == "Alice"
      doAssert res.rows[2].getStr(1) == "Charlie"

      discard await conn.exec("DROP TABLE test_copy_raw")
      await conn.close()

    waitFor t()

  test "copyIn with openArray[byte] empty data":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_copy_raw_empty")
      discard await conn.exec("CREATE TABLE test_copy_raw_empty (id int, name text)")

      let empty: seq[byte] = @[]
      let tag = await conn.copyIn("COPY test_copy_raw_empty FROM STDIN", empty)
      doAssert "COPY 0" in tag

      discard await conn.exec("DROP TABLE test_copy_raw_empty")
      await conn.close()

    waitFor t()

  test "copyIn with openArray[byte] large data":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_copy_raw_large")
      discard await conn.exec("CREATE TABLE test_copy_raw_large (id int, val text)")

      var data = ""
      for i in 0 ..< 10000:
        data.add($i & "\trow" & $i & "\n")
      let tag = await conn.copyIn(
        "COPY test_copy_raw_large FROM STDIN", data.toOpenArrayByte(0, data.high)
      )
      doAssert "COPY 10000" in tag

      let res = await conn.query("SELECT count(*) FROM test_copy_raw_large")
      doAssert res.rows[0].getStr(0) == "10000"

      discard await conn.exec("DROP TABLE test_copy_raw_large")
      await conn.close()

    waitFor t()

suite "E2E: Binary COPY IN":
  test "binary copyIn with int, float, text, bool, NULL":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_copy_bin")
      discard await conn.exec(
        """
        CREATE TABLE test_copy_bin (
          id int,
          val double precision,
          name text,
          flag boolean
        )
      """
      )

      var buf: seq[byte]
      buf.addCopyBinaryHeader()
      # Row 1: all values
      buf.addCopyTupleStart(4)
      buf.addCopyFieldInt32(1'i32)
      buf.addCopyFieldFloat64(3.14)
      buf.addCopyFieldString("hello")
      buf.addCopyFieldBool(true)
      # Row 2: with NULL
      buf.addCopyTupleStart(4)
      buf.addCopyFieldInt32(2'i32)
      buf.addCopyFieldNull()
      buf.addCopyFieldString("world")
      buf.addCopyFieldBool(false)
      # Row 3
      buf.addCopyTupleStart(4)
      buf.addCopyFieldInt32(3'i32)
      buf.addCopyFieldFloat64(-1.5)
      buf.addCopyFieldText("bytes".toBytes())
      buf.addCopyFieldBool(true)
      buf.addCopyBinaryTrailer()

      let tag =
        await conn.copyIn("COPY test_copy_bin FROM STDIN WITH (FORMAT binary)", buf)
      doAssert "COPY 3" in tag

      let res =
        await conn.query("SELECT id, val, name, flag FROM test_copy_bin ORDER BY id")
      doAssert res.rows.len == 3
      doAssert res.rows[0].getStr(0) == "1"
      doAssert res.rows[0].getStr(2) == "hello"
      doAssert res.rows[0].getStr(3) == "t"
      # Row 2: NULL val
      doAssert res.rows[1].getStr(0) == "2"
      doAssert res.rows[1].isNull(1) == true
      doAssert res.rows[1].getStr(2) == "world"
      doAssert res.rows[1].getStr(3) == "f"
      # Row 3
      doAssert res.rows[2].getStr(0) == "3"
      doAssert res.rows[2].getStr(2) == "bytes"

      discard await conn.exec("DROP TABLE test_copy_bin")
      await conn.close()

    waitFor t()

  test "binary copyIn with int16 and int64 fields":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_copy_bin_ints")
      discard await conn.exec(
        """
        CREATE TABLE test_copy_bin_ints (
          a smallint,
          b bigint
        )
      """
      )

      var buf: seq[byte]
      buf.addCopyBinaryHeader()
      buf.addCopyTupleStart(2)
      buf.addCopyFieldInt16(42'i16)
      buf.addCopyFieldInt64(9_000_000_000'i64)
      buf.addCopyTupleStart(2)
      buf.addCopyFieldInt16(-1'i16)
      buf.addCopyFieldInt64(0'i64)
      buf.addCopyBinaryTrailer()

      let tag = await conn.copyIn(
        "COPY test_copy_bin_ints FROM STDIN WITH (FORMAT binary)", buf
      )
      doAssert "COPY 2" in tag

      let res = await conn.query("SELECT a, b FROM test_copy_bin_ints ORDER BY a")
      doAssert res.rows.len == 2
      doAssert res.rows[0].getStr(0) == "-1"
      doAssert res.rows[0].getStr(1) == "0"
      doAssert res.rows[1].getStr(0) == "42"
      doAssert res.rows[1].getStr(1) == "9000000000"

      discard await conn.exec("DROP TABLE test_copy_bin_ints")
      await conn.close()

    waitFor t()

  test "binary copyIn with float32":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_copy_bin_f32")
      discard await conn.exec("CREATE TABLE test_copy_bin_f32 (val real)")

      var buf: seq[byte]
      buf.addCopyBinaryHeader()
      buf.addCopyTupleStart(1)
      buf.addCopyFieldFloat32(1.5'f32)
      buf.addCopyTupleStart(1)
      buf.addCopyFieldFloat32(-0.25'f32)
      buf.addCopyBinaryTrailer()

      let tag =
        await conn.copyIn("COPY test_copy_bin_f32 FROM STDIN WITH (FORMAT binary)", buf)
      doAssert "COPY 2" in tag

      let res = await conn.query("SELECT val FROM test_copy_bin_f32 ORDER BY val")
      doAssert res.rows.len == 2
      doAssert res.rows[0].getStr(0) == "-0.25"
      doAssert res.rows[1].getStr(0) == "1.5"

      discard await conn.exec("DROP TABLE test_copy_bin_f32")
      await conn.close()

    waitFor t()

suite "E2E: Column Name Access":
  test "columnIndex on QueryResult":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res = await conn.query("SELECT 42::int4 AS id, 'alice'::text AS name")
      doAssert res.columnIndex("id") == 0
      doAssert res.columnIndex("name") == 1
      doAssert res.rows[0].getInt(res.columnIndex("id")) == 42'i32
      doAssert res.rows[0].getStr(res.columnIndex("name")) == "alice"
      await conn.close()

    waitFor t()

  test "columnMap for repeated access":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res =
        await conn.query("SELECT 1::int4 AS a, 'x'::text AS b UNION ALL SELECT 2, 'y'")
      let cols = res.fields.columnMap()
      doAssert res.rows[0].getInt(cols["a"]) == 1'i32
      doAssert res.rows[0].getStr(cols["b"]) == "x"
      doAssert res.rows[1].getInt(cols["a"]) == 2'i32
      doAssert res.rows[1].getStr(cols["b"]) == "y"
      await conn.close()

    waitFor t()

  test "columnIndex on PreparedStatement":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let stmt =
        await conn.prepare("col_idx_stmt", "SELECT $1::int4 AS val, $2::text AS label")
      doAssert stmt.columnIndex("val") == 0
      doAssert stmt.columnIndex("label") == 1
      let res = await stmt.execute(@[toPgParam(99'i32), toPgParam("test")])
      doAssert res.rows[0].getInt(stmt.columnIndex("val")) == 99'i32
      doAssert res.rows[0].getStr(stmt.columnIndex("label")) == "test"
      await stmt.close()
      await conn.close()

    waitFor t()

  test "columnIndex raises for missing column":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res = await conn.query("SELECT 1 AS x")
      var raised = false
      try:
        discard res.columnIndex("nonexistent")
      except PgTypeError:
        raised = true
      doAssert raised
      await conn.close()

    waitFor t()

  test "name-based row accessors via rows()":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res = await conn.query(
        "SELECT 42::int4 AS id, 'alice'::text AS name, true::bool AS active, 3.14::float8 AS score"
      )
      doAssert res.rows.len == 1
      let row = res.rows[0]
      doAssert row.getInt("id") == 42'i32
      doAssert row.getStr("name") == "alice"
      doAssert row.getBool("active") == true
      doAssert abs(row.getFloat("score") - 3.14) < 0.001
      doAssert row.isNull("name") == false
      await conn.close()

    waitFor t()

  test "name-based row accessors via items iterator":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res =
        await conn.query("SELECT 1::int4 AS v UNION ALL SELECT 2 UNION ALL SELECT 3")
      var vals: seq[int32]
      for row in res:
        vals.add(row.getInt("v"))
      doAssert vals == @[1'i32, 2'i32, 3'i32]
      await conn.close()

    waitFor t()

  test "name-based Opt accessors":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res = await conn.query("SELECT 10::int4 AS a, NULL::text AS b")
      let row = res.rows[0]
      doAssert row.getIntOpt("a") == some(10'i32)
      doAssert row.getStrOpt("b").isNone
      await conn.close()

    waitFor t()

  test "name-based queryRowOpt accessors":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let rowOpt =
        await conn.queryRowOpt("SELECT 99::int8 AS big, 'hello'::text AS msg")
      doAssert rowOpt.isSome
      let row = rowOpt.get
      doAssert row.getInt64("big") == 99'i64
      doAssert row.getStr("msg") == "hello"
      await conn.close()

    waitFor t()

  test "name-based accessor raises on missing column":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res = await conn.query("SELECT 1::int4 AS x")
      let row = res.rows[0]
      var raised = false
      try:
        discard row.getStr("nonexistent")
      except PgTypeError:
        raised = true
      doAssert raised
      await conn.close()

    waitFor t()

  test "name-based accessor raises without field metadata":
    proc t() {.async.} =
      # Row constructed manually without fields
      let row: Row = @[some(@[byte(49)])]
      var raised = false
      try:
        discard row.getStr("x")
      except PgTypeError:
        raised = true
      doAssert raised

    waitFor t()

suite "E2E: Convenience Query Methods":
  test "queryRowOpt returns first row":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let row = await conn.queryRowOpt("SELECT 1 AS a, 'hello' AS b")
      doAssert row.isSome
      doAssert row.get.getStr(0) == "1"
      doAssert row.get.getStr(1) == "hello"
      await conn.close()

    waitFor t()

  test "queryRowOpt returns none for empty result":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let row = await conn.queryRowOpt("SELECT 1 WHERE false")
      doAssert row.isNone
      await conn.close()

    waitFor t()

  test "queryRow returns first row":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let row = await conn.queryRow("SELECT 1 AS a, 'hello' AS b")
      doAssert row.getStr(0) == "1"
      doAssert row.getStr(1) == "hello"
      await conn.close()

    waitFor t()

  test "queryRow raises on no rows":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      var raised = false
      try:
        discard await conn.queryRow("SELECT 1 WHERE false")
      except PgNoRowsError:
        raised = true
      doAssert raised
      await conn.close()

    waitFor t()

  test "queryValue returns scalar":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let val = await conn.queryValue("SELECT 42")
      doAssert val == "42"
      await conn.close()

    waitFor t()

  test "queryValue raises on no rows":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      var raised = false
      try:
        discard await conn.queryValue("SELECT 1 WHERE false")
      except PgNoRowsError:
        raised = true
      doAssert raised
      await conn.close()

    waitFor t()

  test "queryValue raises on NULL":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      var raised = false
      try:
        discard await conn.queryValue("SELECT NULL::text")
      except PgNullError:
        raised = true
      doAssert raised
      await conn.close()

    waitFor t()

  test "queryValueOrDefault returns value":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let val = await conn.queryValueOrDefault("SELECT 'yes'")
      doAssert val == "yes"
      await conn.close()

    waitFor t()

  test "queryValueOrDefault returns default on no rows":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let val = await conn.queryValueOrDefault("SELECT 1 WHERE false", default = "nope")
      doAssert val == "nope"
      await conn.close()

    waitFor t()

  test "queryValueOrDefault returns default on NULL":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let val =
        await conn.queryValueOrDefault("SELECT NULL::text", default = "fallback")
      doAssert val == "fallback"
      await conn.close()

    waitFor t()

  test "queryValue with typedesc returns typed value":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let val = await conn.queryValue(int64, "SELECT 42")
      doAssert val == 42'i64
      let fval = await conn.queryValue(float64, "SELECT 3.14::float8")
      doAssert abs(fval - 3.14) < 0.001
      let bval = await conn.queryValue(bool, "SELECT true")
      doAssert bval == true
      let sval = await conn.queryValue(string, "SELECT 'hello'")
      doAssert sval == "hello"
      await conn.close()

    waitFor t()

  test "queryValue with typedesc raises on no rows":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      var raised = false
      try:
        discard await conn.queryValue(int32, "SELECT 1 WHERE false")
      except PgNoRowsError:
        raised = true
      doAssert raised
      await conn.close()

    waitFor t()

  test "queryValue with typedesc raises on NULL":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      var raised = false
      try:
        discard await conn.queryValue(int64, "SELECT NULL::int8")
      except PgNullError:
        raised = true
      doAssert raised
      await conn.close()

    waitFor t()

  test "queryValueOrDefault with typedesc":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let val =
        await conn.queryValueOrDefault(int64, "SELECT 1 WHERE false", default = -1'i64)
      doAssert val == -1'i64
      let val2 = await conn.queryValueOrDefault(int64, "SELECT 99", default = 0'i64)
      doAssert val2 == 99'i64
      await conn.close()

    waitFor t()

  test "queryValueOrDefault infers type from default":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let val = await conn.queryValueOrDefault("SELECT 1 WHERE false", default = -1'i64)
      doAssert val == -1'i64
      let val2 = await conn.queryValueOrDefault("SELECT 42", default = 0'i32)
      doAssert val2 == 42'i32
      await conn.close()

    waitFor t()

  test "queryValueOpt returns some on value":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let val = await conn.queryValueOpt("SELECT 'hello'")
      doAssert val == some("hello")
      await conn.close()

    waitFor t()

  test "queryValueOpt returns none on no rows":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let val = await conn.queryValueOpt("SELECT 1 WHERE false")
      doAssert val.isNone
      await conn.close()

    waitFor t()

  test "queryValueOpt returns none on NULL":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let val = await conn.queryValueOpt("SELECT NULL::text")
      doAssert val.isNone
      await conn.close()

    waitFor t()

  test "queryValueOpt with typedesc returns some":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let val = await conn.queryValueOpt(int64, "SELECT 42")
      doAssert val == some(42'i64)
      await conn.close()

    waitFor t()

  test "queryValueOpt with typedesc returns none on no rows":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let val = await conn.queryValueOpt(int32, "SELECT 1 WHERE false")
      doAssert val.isNone
      await conn.close()

    waitFor t()

  test "queryValueOpt with typedesc returns none on NULL":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let val = await conn.queryValueOpt(int64, "SELECT NULL::int8")
      doAssert val.isNone
      await conn.close()

    waitFor t()

  test "queryExists returns true when rows exist":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let exists = await conn.queryExists("SELECT 1")
      doAssert exists
      await conn.close()

    waitFor t()

  test "queryExists returns false when no rows":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let exists = await conn.queryExists("SELECT 1 WHERE false")
      doAssert not exists
      await conn.close()

    waitFor t()

  test "exec().affectedRows returns affected row count":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("CREATE TEMP TABLE ea_test (id int)")
      discard await conn.exec("INSERT INTO ea_test VALUES (1), (2), (3)")
      let cr = await conn.exec("DELETE FROM ea_test WHERE id > 1", newSeq[PgParam]())
      doAssert cr.affectedRows == 2
      await conn.close()

    waitFor t()

  test "queryColumn returns column values":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let vals = await conn.queryColumn("SELECT generate_series(1,3)::text")
      doAssert vals == @["1", "2", "3"]
      await conn.close()

    waitFor t()

  test "queryColumn raises on NULL":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      var raised = false
      try:
        discard await conn.queryColumn("SELECT NULL::text")
      except PgNullError:
        raised = true
      doAssert raised
      await conn.close()

    waitFor t()

  test "queryRowOpt returns only first row from multiple":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let row = await conn.queryRowOpt("SELECT generate_series(10,12)::text AS v")
      doAssert row.isSome
      doAssert row.get.getStr(0) == "10"
      await conn.close()

    waitFor t()

  test "queryColumn returns empty seq for no rows":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let vals = await conn.queryColumn("SELECT 1::text WHERE false")
      doAssert vals.len == 0
      await conn.close()

    waitFor t()

  test "exec().affectedRows returns 0 when no rows affected":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("CREATE TEMP TABLE ea_zero (id int)")
      let cr = await conn.exec("DELETE FROM ea_zero WHERE id = 999", newSeq[PgParam]())
      doAssert cr.affectedRows == 0
      await conn.close()

    waitFor t()

  test "queryRowOpt with params":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let row =
        await conn.queryRowOpt("SELECT $1::int + $2::int", @[3.toPgParam, 4.toPgParam])
      doAssert row.isSome
      doAssert row.get.getStr(0) == "7"
      await conn.close()

    waitFor t()

  test "query Row survives subsequent queries (lifetime bug)":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let qr1 = await conn.query("SELECT 'x'")
      let qr2 = await conn.query("SELECT 'y'")
      doAssert qr1.rowCount == 1
      doAssert qr2.rowCount == 1
      let row1 = initRow(qr1.data, 0)
      let row2 = initRow(qr2.data, 0)
      doAssert row1.getStr(0) == "x", "qr1 data was invalidated by qr2"
      doAssert row2.getStr(0) == "y"
      await conn.close()

    waitFor t()

  test "pool queryRowOpt":
    proc t() {.async.} =
      let pool = await newPool(initPoolConfig(plainConfig(), minSize = 1, maxSize = 2))
      let row = await pool.queryRowOpt("SELECT 'pooled'")
      doAssert row.isSome
      doAssert row.get.getStr(0) == "pooled"
      await pool.close()

    waitFor t()

  test "pool queryRow":
    proc t() {.async.} =
      let pool = await newPool(initPoolConfig(plainConfig(), minSize = 1, maxSize = 2))
      let row = await pool.queryRow("SELECT 'pooled' AS v")
      doAssert row.getStr("v") == "pooled"
      await pool.close()

    waitFor t()

  test "pool queryRow raises on no rows":
    proc t() {.async.} =
      let pool = await newPool(initPoolConfig(plainConfig(), minSize = 1, maxSize = 2))
      var raised = false
      try:
        discard await pool.queryRow("SELECT 1 WHERE false")
      except PgNoRowsError:
        raised = true
      doAssert raised
      await pool.close()

    waitFor t()

  test "pool queryValue":
    proc t() {.async.} =
      let pool = await newPool(initPoolConfig(plainConfig(), minSize = 1, maxSize = 2))
      let val = await pool.queryValue("SELECT 99")
      doAssert val == "99"
      await pool.close()

    waitFor t()

  test "pool queryValue raises on no rows":
    proc t() {.async.} =
      let pool = await newPool(initPoolConfig(plainConfig(), minSize = 1, maxSize = 2))
      var raised = false
      try:
        discard await pool.queryValue("SELECT 1 WHERE false")
      except PgNoRowsError:
        raised = true
      doAssert raised
      await pool.close()

    waitFor t()

  test "pool queryValue raises on NULL":
    proc t() {.async.} =
      let pool = await newPool(initPoolConfig(plainConfig(), minSize = 1, maxSize = 2))
      var raised = false
      try:
        discard await pool.queryValue("SELECT NULL::text")
      except PgNullError:
        raised = true
      doAssert raised
      await pool.close()

    waitFor t()

  test "pool queryExists":
    proc t() {.async.} =
      let pool = await newPool(initPoolConfig(plainConfig(), minSize = 1, maxSize = 2))
      doAssert (await pool.queryExists("SELECT 1"))
      doAssert not (await pool.queryExists("SELECT 1 WHERE false"))
      await pool.close()

    waitFor t()

  test "pool exec().affectedRows":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("CREATE TEMP TABLE pool_ea2 (id int)")
      discard await conn.exec("INSERT INTO pool_ea2 VALUES (1), (2)")
      let cr = await conn.exec("DELETE FROM pool_ea2", newSeq[PgParam]())
      doAssert cr.affectedRows == 2
      await conn.close()

    waitFor t()

  test "pool queryColumn":
    proc t() {.async.} =
      let pool = await newPool(initPoolConfig(plainConfig(), minSize = 1, maxSize = 2))
      let vals = await pool.queryColumn("SELECT generate_series(10,12)::text")
      doAssert vals == @["10", "11", "12"]
      await pool.close()

    waitFor t()

  test "pool queryValueOrDefault":
    proc t() {.async.} =
      let pool = await newPool(initPoolConfig(plainConfig(), minSize = 1, maxSize = 2))
      let val = await pool.queryValueOrDefault("SELECT 1 WHERE false", default = "x")
      doAssert val == "x"
      let val2 = await pool.queryValueOrDefault("SELECT 'ok'")
      doAssert val2 == "ok"
      await pool.close()

    waitFor t()

  test "pool queryValue with typedesc":
    proc t() {.async.} =
      let pool = await newPool(initPoolConfig(plainConfig(), minSize = 1, maxSize = 2))
      let val = await pool.queryValue(int64, "SELECT 123")
      doAssert val == 123'i64
      await pool.close()

    waitFor t()

  test "pool queryValue with typedesc raises on no rows":
    proc t() {.async.} =
      let pool = await newPool(initPoolConfig(plainConfig(), minSize = 1, maxSize = 2))
      var raised = false
      try:
        discard await pool.queryValue(int32, "SELECT 1 WHERE false")
      except PgNoRowsError:
        raised = true
      doAssert raised
      await pool.close()

    waitFor t()

  test "pool queryValue with typedesc raises on NULL":
    proc t() {.async.} =
      let pool = await newPool(initPoolConfig(plainConfig(), minSize = 1, maxSize = 2))
      var raised = false
      try:
        discard await pool.queryValue(int64, "SELECT NULL::int8")
      except PgNullError:
        raised = true
      doAssert raised
      await pool.close()

    waitFor t()

  test "pool queryValueOrDefault with typedesc":
    proc t() {.async.} =
      let pool = await newPool(initPoolConfig(plainConfig(), minSize = 1, maxSize = 2))
      let val =
        await pool.queryValueOrDefault(int32, "SELECT 1 WHERE false", default = -1'i32)
      doAssert val == -1'i32
      let val2 = await pool.queryValueOrDefault(int32, "SELECT 7", default = 0'i32)
      doAssert val2 == 7'i32
      await pool.close()

    waitFor t()

  test "pool queryValueOrDefault infers type from default":
    proc t() {.async.} =
      let pool = await newPool(initPoolConfig(plainConfig(), minSize = 1, maxSize = 2))
      let val = await pool.queryValueOrDefault("SELECT 1 WHERE false", default = -1'i32)
      doAssert val == -1'i32
      let val2 = await pool.queryValueOrDefault("SELECT 7", default = 0'i32)
      doAssert val2 == 7'i32
      await pool.close()

    waitFor t()

  test "pool queryValueOpt":
    proc t() {.async.} =
      let pool = await newPool(initPoolConfig(plainConfig(), minSize = 1, maxSize = 2))
      let val = await pool.queryValueOpt("SELECT 'ok'")
      doAssert val == some("ok")
      let none_val = await pool.queryValueOpt("SELECT 1 WHERE false")
      doAssert none_val.isNone
      await pool.close()

    waitFor t()

  test "pool queryValueOpt with typedesc":
    proc t() {.async.} =
      let pool = await newPool(initPoolConfig(plainConfig(), minSize = 1, maxSize = 2))
      let val = await pool.queryValueOpt(int64, "SELECT 123")
      doAssert val == some(123'i64)
      let none_val = await pool.queryValueOpt(int32, "SELECT 1 WHERE false")
      doAssert none_val.isNone
      await pool.close()

    waitFor t()

  test "stmt cache: repeated query uses cache":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      doAssert conn.stmtCacheCapacity == 256
      doAssert conn.stmtCache.len == 0

      # First call: cache miss -> populates cache
      let r1 = await conn.query("SELECT 1 AS v")
      doAssert r1.rows[0].getStr(0) == "1"
      doAssert conn.stmtCache.len == 1

      # Second call: cache hit
      let r2 = await conn.query("SELECT 1 AS v")
      doAssert r2.rows[0].getStr(0) == "1"
      doAssert conn.stmtCache.len == 1 # no new entry

      await conn.close()

    waitFor t()

  test "stmt cache: repeated exec uses cache":
    proc t() {.async.} =
      let conn = await connect(plainConfig())

      discard await conn.exec("SELECT 1")
      doAssert conn.stmtCache.len == 1

      discard await conn.exec("SELECT 1")
      doAssert conn.stmtCache.len == 1

      # Different SQL gets its own entry
      discard await conn.exec("SELECT 2")
      doAssert conn.stmtCache.len == 2

      await conn.close()

    waitFor t()

  test "stmt cache: query with params":
    proc t() {.async.} =
      let conn = await connect(plainConfig())

      let r1 = await conn.query(
        "SELECT $1::int + $2::int AS sum", @[toPgParam("1"), toPgParam("2")]
      )
      doAssert r1.rows[0].getStr(0) == "3"
      doAssert conn.stmtCache.len == 1

      # Same SQL, different params: cache hit
      let r2 = await conn.query(
        "SELECT $1::int + $2::int AS sum", @[toPgParam("3"), toPgParam("4")]
      )
      doAssert r2.rows[0].getStr(0) == "7"
      doAssert conn.stmtCache.len == 1

      await conn.close()

    waitFor t()

  test "stmt cache: binary result format works with cache":
    proc t() {.async.} =
      let conn = await connect(plainConfig())

      let r1 = await conn.query("SELECT 42::int4", resultFormat = rfBinary)
      doAssert r1.rows[0].getInt(0) == 42
      doAssert conn.stmtCache.len == 1

      # Cache hit with binary format
      let r2 = await conn.query("SELECT 42::int4", resultFormat = rfBinary)
      doAssert r2.rows[0].getInt(0) == 42

      await conn.close()

    waitFor t()

  test "stmt cache: clearStmtCache works":
    proc t() {.async.} =
      let conn = await connect(plainConfig())

      discard await conn.query("SELECT 1")
      discard await conn.query("SELECT 2")
      doAssert conn.stmtCache.len == 2

      conn.clearStmtCache()
      doAssert conn.stmtCache.len == 0

      # After clear, queries still work (cache miss path)
      let r = await conn.query("SELECT 3")
      doAssert r.rows[0].getStr(0) == "3"
      doAssert conn.stmtCache.len == 1

      await conn.close()

    waitFor t()

  test "stmt cache: disabled when capacity=0":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      conn.stmtCacheCapacity = 0

      discard await conn.query("SELECT 1")
      doAssert conn.stmtCache.len == 0

      discard await conn.exec("SELECT 1")
      doAssert conn.stmtCache.len == 0

      await conn.close()

    waitFor t()

  test "stmt cache: full cache evicts LRU entry":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      conn.stmtCacheCapacity = 2

      discard await conn.query("SELECT 1")
      discard await conn.query("SELECT 2")
      doAssert conn.stmtCache.len == 2

      # Cache full, LRU entry ("SELECT 1") is evicted
      let r = await conn.query("SELECT 3")
      doAssert r.rows[0].getStr(0) == "3"
      doAssert conn.stmtCache.len == 2
      doAssert not conn.stmtCache.hasKey("SELECT 1") # evicted
      doAssert conn.stmtCache.hasKey("SELECT 2")
      doAssert conn.stmtCache.hasKey("SELECT 3") # newly cached

      # Access "SELECT 2" to make it most recent, then add new
      discard await conn.query("SELECT 2")
      discard await conn.query("SELECT 4")
      doAssert conn.stmtCache.len == 2
      doAssert not conn.stmtCache.hasKey("SELECT 3") # evicted (was LRU)
      doAssert conn.stmtCache.hasKey("SELECT 2") # kept (was accessed)
      doAssert conn.stmtCache.hasKey("SELECT 4") # newly cached

      await conn.close()

    waitFor t()

  test "stmt cache: works with pool":
    proc t() {.async.} =
      let pool = await newPool(initPoolConfig(plainConfig(), minSize = 1, maxSize = 1))

      # First query populates cache on the pooled connection
      let r1 = await pool.query("SELECT 'cached'")
      doAssert r1.rows[0].getStr(0) == "cached"

      # Second query should hit cache
      let r2 = await pool.query("SELECT 'cached'")
      doAssert r2.rows[0].getStr(0) == "cached"

      await pool.close()

    waitFor t()

suite "E2E: simpleExec":
  test "simpleExec returns command tag":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_simpleexec")
      discard await conn.exec(
        "CREATE TABLE test_simpleexec (id serial PRIMARY KEY, val text)"
      )

      let tag = await conn.simpleExec("INSERT INTO test_simpleexec (val) VALUES ('a')")
      doAssert tag == "INSERT 0 1"

      let tag2 =
        await conn.simpleExec("INSERT INTO test_simpleexec (val) VALUES ('b'), ('c')")
      doAssert tag2 == "INSERT 0 2"

      discard await conn.exec("DROP TABLE test_simpleexec")
      await conn.close()

    waitFor t()

  test "simpleExec raises on error":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      var raised = false
      try:
        discard await conn.simpleExec("SELECT * FROM nonexistent_table_xyz")
      except PgError:
        raised = true
      doAssert raised
      doAssert conn.state == csReady
      await conn.close()

    waitFor t()

  test "pool.simpleExec":
    proc t() {.async.} =
      let pool =
        await newPool(PoolConfig(connConfig: plainConfig(), minSize: 1, maxSize: 3))
      let tag = await pool.simpleExec("SELECT 1")
      doAssert tag == "SELECT 1"
      await pool.close()

    waitFor t()

suite "E2E: execInTransaction / queryInTransaction":
  test "execInTransaction commits successfully":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_eit")
      discard await conn.exec("CREATE TABLE test_eit (id serial PRIMARY KEY, val text)")

      let tag = await conn.execInTransaction(
        "INSERT INTO test_eit (val) VALUES ($1)", @[toPgParam("pipelined")]
      )
      doAssert tag == "INSERT 0 1"

      # Verify committed
      let res = await conn.query("SELECT val FROM test_eit")
      doAssert res.rows.len == 1
      doAssert res.rows[0].getStr(0) == "pipelined"

      discard await conn.exec("DROP TABLE test_eit")
      await conn.close()

    waitFor t()

  test "execInTransaction rolls back on error":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_eit_err")
      discard await conn.exec(
        "CREATE TABLE test_eit_err (id serial PRIMARY KEY, val text UNIQUE)"
      )
      discard await conn.exec("INSERT INTO test_eit_err (val) VALUES ('existing')")

      var raised = false
      try:
        discard await conn.execInTransaction(
          "INSERT INTO test_eit_err (val) VALUES ($1)", @[toPgParam("existing")]
        )
      except PgError:
        raised = true

      doAssert raised
      doAssert conn.state == csReady

      # Verify no extra row was committed
      let res = await conn.query("SELECT count(*) FROM test_eit_err")
      doAssert res.rows[0].getStr(0) == "1"

      discard await conn.exec("DROP TABLE test_eit_err")
      await conn.close()

    waitFor t()

  test "execInTransaction with PgParam":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_eit_pg")
      discard await conn.exec("CREATE TABLE test_eit_pg (id int, name text)")

      let tag = await conn.execInTransaction(
        "INSERT INTO test_eit_pg (id, name) VALUES ($1, $2)",
        @[toPgParam(42'i32), toPgParam("typed")],
      )
      doAssert tag == "INSERT 0 1"

      let res = await conn.query("SELECT name FROM test_eit_pg WHERE id = 42")
      doAssert res.rows[0].getStr(0) == "typed"

      discard await conn.exec("DROP TABLE test_eit_pg")
      await conn.close()

    waitFor t()

  test "execInTransaction with TransactionOptions":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_eit_opts")
      discard
        await conn.exec("CREATE TABLE test_eit_opts (id serial PRIMARY KEY, val text)")

      let tag = await conn.execInTransaction(
        "INSERT INTO test_eit_opts (val) VALUES ($1)",
        @[toPgParam("serializable")],
        TransactionOptions(isolation: ilSerializable),
      )
      doAssert tag == "INSERT 0 1"

      let res = await conn.query("SELECT val FROM test_eit_opts")
      doAssert res.rows[0].getStr(0) == "serializable"

      discard await conn.exec("DROP TABLE test_eit_opts")
      await conn.close()

    waitFor t()

  test "queryInTransaction returns rows":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_qit")
      discard await conn.exec("CREATE TABLE test_qit (id serial PRIMARY KEY, val text)")
      discard await conn.exec("INSERT INTO test_qit (val) VALUES ('a'), ('b'), ('c')")

      let qr = await conn.queryInTransaction("SELECT val FROM test_qit ORDER BY id")
      doAssert qr.rows.len == 3
      doAssert qr.rows[0].getStr(0) == "a"
      doAssert qr.rows[1].getStr(0) == "b"
      doAssert qr.rows[2].getStr(0) == "c"

      discard await conn.exec("DROP TABLE test_qit")
      await conn.close()

    waitFor t()

  test "queryInTransaction with PgParam":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_qit_pg")
      discard await conn.exec("CREATE TABLE test_qit_pg (id int, val text)")
      discard
        await conn.exec("INSERT INTO test_qit_pg (id, val) VALUES (1, 'x'), (2, 'y')")

      let qr = await conn.queryInTransaction(
        "SELECT val FROM test_qit_pg WHERE id = $1", @[toPgParam(1'i32)]
      )
      doAssert qr.rows.len == 1
      doAssert qr.rows[0].getStr(0) == "x"

      discard await conn.exec("DROP TABLE test_qit_pg")
      await conn.close()

    waitFor t()

  test "queryInTransaction with TransactionOptions":
    proc t() {.async.} =
      let conn = await connect(plainConfig())

      let qr = await conn.queryInTransaction(
        "SELECT 1",
        @[],
        TransactionOptions(isolation: ilSerializable, access: amReadOnly),
      )
      doAssert qr.rows.len == 1

      await conn.close()

    waitFor t()

  test "pool.execInTransaction":
    proc t() {.async.} =
      let pool =
        await newPool(PoolConfig(connConfig: plainConfig(), minSize: 1, maxSize: 3))
      discard await pool.exec("DROP TABLE IF EXISTS test_peit")
      discard
        await pool.exec("CREATE TABLE test_peit (id serial PRIMARY KEY, val text)")

      let tag = await pool.execInTransaction(
        "INSERT INTO test_peit (val) VALUES ($1)", @[toPgParam("pool_tx")]
      )
      doAssert tag == "INSERT 0 1"

      let res = await pool.query("SELECT val FROM test_peit")
      doAssert res.rows[0].getStr(0) == "pool_tx"

      discard await pool.exec("DROP TABLE test_peit")
      await pool.close()

    waitFor t()

  test "pool.queryInTransaction":
    proc t() {.async.} =
      let pool =
        await newPool(PoolConfig(connConfig: plainConfig(), minSize: 1, maxSize: 3))

      let qr = await pool.queryInTransaction("SELECT 42::int4", @[])
      doAssert qr.rows.len == 1
      doAssert qr.rows[0].getStr(0) == "42"

      await pool.close()

    waitFor t()

  test "pipeline: multiple exec":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_pipe_exec")
      discard
        await conn.exec("CREATE TABLE test_pipe_exec (id serial PRIMARY KEY, val text)")

      let p = newPipeline(conn)
      p.addExec("INSERT INTO test_pipe_exec (val) VALUES ($1)", @[toPgParam("a")])
      p.addExec("INSERT INTO test_pipe_exec (val) VALUES ($1)", @[toPgParam("b")])
      p.addExec("INSERT INTO test_pipe_exec (val) VALUES ($1)", @[toPgParam("c")])
      let results = await p.execute()
      doAssert results.len == 3
      for r in results:
        doAssert r.kind == prkExec
        doAssert r.commandResult == "INSERT 0 1"

      let qr = await conn.query("SELECT val FROM test_pipe_exec ORDER BY id")
      doAssert qr.rowCount == 3
      doAssert qr.rows[0].getStr(0) == "a"
      doAssert qr.rows[1].getStr(0) == "b"
      doAssert qr.rows[2].getStr(0) == "c"

      discard await conn.exec("DROP TABLE test_pipe_exec")
      await conn.close()

    waitFor t()

  test "pipeline: multiple query":
    proc t() {.async.} =
      let conn = await connect(plainConfig())

      let p = newPipeline(conn)
      p.addQuery("SELECT 1::int4 AS a")
      p.addQuery("SELECT 2::int4 AS b, 3::int4 AS c")
      p.addQuery("SELECT 'hello'::text AS greeting")
      let results = await p.execute()
      doAssert results.len == 3

      doAssert results[0].kind == prkQuery
      doAssert results[0].queryResult.rowCount == 1
      doAssert results[0].queryResult.rows[0].getStr(0) == "1"

      doAssert results[1].kind == prkQuery
      doAssert results[1].queryResult.rowCount == 1
      doAssert results[1].queryResult.rows[0].getStr(0) == "2"
      doAssert results[1].queryResult.rows[0].getStr(1) == "3"

      doAssert results[2].kind == prkQuery
      doAssert results[2].queryResult.rowCount == 1
      doAssert results[2].queryResult.rows[0].getStr(0) == "hello"

      await conn.close()

    waitFor t()

  test "pipeline: mixed exec and query":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_pipe_mixed")
      discard await conn.exec(
        "CREATE TABLE test_pipe_mixed (id serial PRIMARY KEY, val text)"
      )

      let p = newPipeline(conn)
      p.addExec("INSERT INTO test_pipe_mixed (val) VALUES ($1)", @[toPgParam("x")])
      p.addQuery("SELECT val FROM test_pipe_mixed ORDER BY id")
      p.addExec("INSERT INTO test_pipe_mixed (val) VALUES ($1)", @[toPgParam("y")])
      p.addQuery("SELECT count(*)::int4 FROM test_pipe_mixed")
      let results = await p.execute()
      doAssert results.len == 4

      doAssert results[0].kind == prkExec
      doAssert results[0].commandResult == "INSERT 0 1"

      doAssert results[1].kind == prkQuery
      doAssert results[1].queryResult.rowCount == 1
      doAssert results[1].queryResult.rows[0].getStr(0) == "x"

      doAssert results[2].kind == prkExec
      doAssert results[2].commandResult == "INSERT 0 1"

      doAssert results[3].kind == prkQuery
      doAssert results[3].queryResult.rowCount == 1
      doAssert results[3].queryResult.rows[0].getStr(0) == "2"

      discard await conn.exec("DROP TABLE test_pipe_mixed")
      await conn.close()

    waitFor t()

  test "pipeline: statement cache hit/miss":
    proc t() {.async.} =
      let conn = await connect(plainConfig())

      # First execution: cache miss
      var p1 = newPipeline(conn)
      p1.addQuery("SELECT $1::text", @[toPgParam("first")])
      p1.addQuery("SELECT $1::int4", @[toPgParam(42'i32)])
      let r1 = await p1.execute()
      doAssert r1[0].queryResult.rows[0].getStr(0) == "first"
      doAssert r1[1].queryResult.rows[0].getStr(0) == "42"

      # Second execution: cache hit (same SQL)
      var p2 = newPipeline(conn)
      p2.addQuery("SELECT $1::text", @[toPgParam("second")])
      p2.addQuery("SELECT $1::int4", @[toPgParam(99'i32)])
      let r2 = await p2.execute()
      doAssert r2[0].queryResult.rows[0].getStr(0) == "second"
      doAssert r2[1].queryResult.rows[0].getStr(0) == "99"

      await conn.close()

    waitFor t()

  test "pipeline: error aborts remaining ops":
    proc t() {.async.} =
      let conn = await connect(plainConfig())

      let p = newPipeline(conn)
      p.addExec("SELECT 1")
      p.addExec("INVALID SQL THAT WILL FAIL")
      p.addExec("SELECT 2") # Should be skipped by server
      var gotError = false
      try:
        discard await p.execute()
      except PgError:
        gotError = true
      doAssert gotError

      # Connection should still be usable
      doAssert conn.state == csReady
      let qr = await conn.query("SELECT 1::int4")
      doAssert qr.rows[0].getStr(0) == "1"

      await conn.close()

    waitFor t()

  test "pipeline: PgParam raw overload":
    proc t() {.async.} =
      let conn = await connect(plainConfig())

      let p = newPipeline(conn)
      p.addExec("SELECT $1::text", @[toPgParam("hello")])
      p.addQuery("SELECT $1::text", @[toPgParam("world")])
      let results = await p.execute()
      doAssert results[0].kind == prkExec
      doAssert results[1].kind == prkQuery
      doAssert results[1].queryResult.rows[0].getStr(0) == "world"

      await conn.close()

    waitFor t()

  test "pipeline: PgParamInline overload roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_inline_pipe")
      discard
        await conn.exec("CREATE TABLE test_inline_pipe (id serial PRIMARY KEY, v int)")

      let p = newPipeline(conn)
      for i in 0 ..< 5:
        p.addExec(
          "INSERT INTO test_inline_pipe (v) VALUES ($1)", [i.int32.toPgParamInline]
        )
      p.addQuery("SELECT v FROM test_inline_pipe ORDER BY id")
      let results = await p.execute()
      doAssert results.len == 6
      for i in 0 ..< 5:
        doAssert results[i].commandResult == "INSERT 0 1"
      let qr = results[5].queryResult
      doAssert qr.rows.len == 5
      for i in 0 ..< 5:
        doAssert qr.rows[i].getStr(0) == $i

      discard await conn.exec("DROP TABLE test_inline_pipe")
      await conn.close()

    waitFor t()

  test "pipeline: PgParamInline and PgParam overloads can be mixed in one pipeline":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_mixed_pipe")
      discard await conn.exec(
        "CREATE TABLE test_mixed_pipe (id serial PRIMARY KEY, v int, s text)"
      )

      let p = newPipeline(conn)
      # inline path
      p.addExec(
        "INSERT INTO test_mixed_pipe (v, s) VALUES ($1, $2)",
        [1.int32.toPgParamInline, "from-inline".toPgParamInline],
      )
      # legacy path
      p.addExec(
        "INSERT INTO test_mixed_pipe (v, s) VALUES ($1, $2)",
        @[toPgParam(2'i32), toPgParam("from-legacy")],
      )
      p.addQuery("SELECT v, s FROM test_mixed_pipe ORDER BY id")
      let results = await p.execute()
      doAssert results.len == 3
      let rows = results[2].queryResult.rows
      doAssert rows.len == 2
      doAssert rows[0].getStr(0) == "1"
      doAssert rows[0].getStr(1) == "from-inline"
      doAssert rows[1].getStr(0) == "2"
      doAssert rows[1].getStr(1) == "from-legacy"

      discard await conn.exec("DROP TABLE test_mixed_pipe")
      await conn.close()

    waitFor t()

  test "pipeline: PgParamInline NULL via Option":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_inline_null")
      discard
        await conn.exec("CREATE TABLE test_inline_null (id serial PRIMARY KEY, v int)")

      let p = newPipeline(conn)
      p.addExec(
        "INSERT INTO test_inline_null (v) VALUES ($1)", [none(int32).toPgParamInline]
      )
      p.addQuery("SELECT v FROM test_inline_null ORDER BY id")
      let results = await p.execute()
      doAssert results[1].queryResult.rows[0].isNull(0)

      discard await conn.exec("DROP TABLE test_inline_null")
      await conn.close()

    waitFor t()

  test "pipeline: PgParamInline overflow path (long string)":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_inline_overflow")
      discard await conn.exec(
        "CREATE TABLE test_inline_overflow (id serial PRIMARY KEY, s text)"
      )

      let long = "abcdefghijklmnopqrstuvwxyz0123456789" # 36 chars → overflow
      let p = newPipeline(conn)
      p.addExec(
        "INSERT INTO test_inline_overflow (s) VALUES ($1)", [long.toPgParamInline]
      )
      p.addQuery("SELECT s FROM test_inline_overflow")
      let results = await p.execute()
      doAssert results[1].queryResult.rows[0].getStr(0) == long

      discard await conn.exec("DROP TABLE test_inline_overflow")
      await conn.close()

    waitFor t()

  test "pipeline: PgParamInline large overflow (16KB single value)":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_inline_large")
      discard await conn.exec(
        "CREATE TABLE test_inline_large (id serial PRIMARY KEY, s text)"
      )

      # 16 KB payload — well beyond PgInlineBufSize, exercises a single large
      # copy into the SoA inlineData buffer.
      var big = newStringOfCap(16 * 1024)
      for i in 0 ..< 16 * 1024:
        big.add char(ord('a') + (i mod 26))
      let p = newPipeline(conn)
      p.addExec("INSERT INTO test_inline_large (s) VALUES ($1)", [big.toPgParamInline])
      p.addQuery("SELECT s FROM test_inline_large")
      let results = await p.execute()
      doAssert results[0].commandResult == "INSERT 0 1"
      doAssert results[1].queryResult.rows[0].getStr(0) == big

      discard await conn.exec("DROP TABLE test_inline_large")
      await conn.close()

    waitFor t()

  test "pipeline: PgParamInline many large overflows stress SoA reallocation":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_inline_stress")
      discard await conn.exec(
        "CREATE TABLE test_inline_stress (id serial PRIMARY KEY, s text)"
      )

      # 50 × ~2 KB values across 50 ops in one pipeline. Each value is unique
      # so a bug in SoA offset accounting (e.g. slice aliasing, reuse of stale
      # offsets after inlineData grows) surfaces as a mismatched readback.
      let numOps = 50
      let valueSize = 2 * 1024
      var expected = newSeq[string](numOps)
      let p = newPipeline(conn)
      for i in 0 ..< numOps:
        var s = newStringOfCap(valueSize)
        # Prefix with the index so every value is distinct and order-sensitive.
        s.add "op" & $i & ":"
        while s.len < valueSize:
          s.add char(ord('a') + ((i + s.len) mod 26))
        expected[i] = s
        p.addExec("INSERT INTO test_inline_stress (s) VALUES ($1)", [s.toPgParamInline])
      p.addQuery("SELECT s FROM test_inline_stress ORDER BY id")
      let results = await p.execute()
      doAssert results.len == numOps + 1
      for i in 0 ..< numOps:
        doAssert results[i].commandResult == "INSERT 0 1"
      let rows = results[numOps].queryResult.rows
      doAssert rows.len == numOps
      for i in 0 ..< numOps:
        doAssert rows[i].getStr(0) == expected[i]

      discard await conn.exec("DROP TABLE test_inline_stress")
      await conn.close()

    waitFor t()

  test "pipeline: PgParamInline empty params on param-less SQL":
    # Edge case: caller reaches the inline overload with zero params (e.g. a
    # SQL that takes no bound parameters). executeImpl builds an empty
    # openArray via `toOpenArray(start, start-1)`; regression test that the
    # Bind message still goes out cleanly and the query round-trips.
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let p = newPipeline(conn)
      let empty: seq[PgParamInline] = @[]
      p.addQuery("SELECT 42", empty)
      p.addExec("SELECT 1", empty)
      let results = await p.execute()
      doAssert results.len == 2
      doAssert results[0].queryResult.rows[0].getStr(0) == "42"
      doAssert results[1].commandResult == "SELECT 1"
      await conn.close()

    waitFor t()

  test "exec: PgParamInline overload roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_exec_inline")
      discard
        await conn.exec("CREATE TABLE test_exec_inline (id serial PRIMARY KEY, v int)")

      # Multi-value INSERT (the benchmark workload): 100 params in one exec.
      var sql = "INSERT INTO test_exec_inline (v) VALUES "
      var params = newSeqOfCap[PgParamInline](100)
      for j in 0 ..< 100:
        if j > 0:
          sql.add ","
        sql.add "($" & $(j + 1) & ")"
        params.add j.int32.toPgParamInline
      let cr = await conn.exec(sql, params)
      doAssert cr.affectedRows == 100

      let qr =
        await conn.query("SELECT count(*)::int4, max(v)::int4 FROM test_exec_inline")
      doAssert qr.rows[0].getStr(0) == "100"
      doAssert qr.rows[0].getStr(1) == "99"

      discard await conn.exec("DROP TABLE test_exec_inline")
      await conn.close()

    waitFor t()

  test "pipeline: executeIsolated with PgParamInline roundtrip":
    # Covers the inline path through executeIsolatedImpl (per-op SYNC) and
    # its concurrent send/recv scheduling under chronos. Mixes inline and
    # legacy params across ops so both code paths in the op loop execute.
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_iso_inline")
      discard await conn.exec(
        "CREATE TABLE test_iso_inline (id serial PRIMARY KEY, v int, s text)"
      )

      let p = newPipeline(conn)
      p.addExec(
        "INSERT INTO test_iso_inline (v, s) VALUES ($1, $2)",
        [10.int32.toPgParamInline, "inline".toPgParamInline],
      )
      p.addExec(
        "INSERT INTO test_iso_inline (v, s) VALUES ($1, $2)",
        @[toPgParam(20'i32), toPgParam("legacy")],
      )
      p.addQuery(
        "SELECT v, s FROM test_iso_inline WHERE v > $1 ORDER BY id",
        [5.int32.toPgParamInline],
      )
      let ir = await p.executeIsolated()
      doAssert ir.results.len == 3
      for e in ir.errors:
        doAssert e == nil
      doAssert ir.results[0].commandResult == "INSERT 0 1"
      doAssert ir.results[1].commandResult == "INSERT 0 1"
      let rows = ir.results[2].queryResult.rows
      doAssert rows.len == 2
      doAssert rows[0].getStr(0) == "10"
      doAssert rows[0].getStr(1) == "inline"
      doAssert rows[1].getStr(0) == "20"
      doAssert rows[1].getStr(1) == "legacy"

      discard await conn.exec("DROP TABLE test_iso_inline")
      await conn.close()

    waitFor t()

  test "pipeline: executeIsolated with PgParamInline isolates per-op errors":
    # Confirms that per-op SYNC still provides error isolation when ops use
    # the inline overload: a failing inline op must not abort subsequent
    # inline ops, and the connection must remain usable afterwards.
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_iso_inline_err")
      discard await conn.exec(
        "CREATE TABLE test_iso_inline_err (id serial PRIMARY KEY, v int NOT NULL)"
      )

      let p = newPipeline(conn)
      p.addExec(
        "INSERT INTO test_iso_inline_err (v) VALUES ($1)", [1.int32.toPgParamInline]
      )
      # NULL inline param violates NOT NULL — isolated error.
      p.addExec(
        "INSERT INTO test_iso_inline_err (v) VALUES ($1)", [none(int32).toPgParamInline]
      )
      p.addExec(
        "INSERT INTO test_iso_inline_err (v) VALUES ($1)", [3.int32.toPgParamInline]
      )
      let ir = await p.executeIsolated()
      doAssert ir.results.len == 3
      doAssert ir.errors[0] == nil
      doAssert ir.errors[1] != nil
      doAssert ir.errors[2] == nil # not aborted

      doAssert conn.state == csReady
      let qr = await conn.query("SELECT v FROM test_iso_inline_err ORDER BY id")
      doAssert qr.rowCount == 2
      doAssert qr.rows[0].getStr(0) == "1"
      doAssert qr.rows[1].getStr(0) == "3"

      discard await conn.exec("DROP TABLE test_iso_inline_err")
      await conn.close()

    waitFor t()

  test "pipeline: empty pipeline":
    proc t() {.async.} =
      let conn = await connect(plainConfig())

      let p = newPipeline(conn)
      let results = await p.execute()
      doAssert results.len == 0

      await conn.close()

    waitFor t()

  test "pipeline: reset clears queued ops and allows reuse":
    proc t() {.async.} =
      let conn = await connect(plainConfig())

      let p = newPipeline(conn)
      p.addQuery("SELECT $1::int4", @[toPgParam(1'i32)])
      p.addQuery("SELECT $1::int4", @[toPgParam(2'i32)])
      let r1 = await p.execute()
      doAssert r1.len == 2

      # Without reset, queued ops would be executed again.
      p.reset()
      let r0 = await p.execute()
      doAssert r0.len == 0

      # Reused instance is healthy for a brand-new batch.
      p.addQuery("SELECT $1::text", @[toPgParam("reused")])
      let r2 = await p.execute()
      doAssert r2.len == 1
      doAssert r2[0].queryResult.rows[0].getStr(0) == "reused"

      await conn.close()

    waitFor t()

  test "pipeline: reset on empty pipeline is a no-op":
    proc t() {.async.} =
      let conn = await connect(plainConfig())

      let p = newPipeline(conn)
      p.reset()
      p.reset()
      let results = await p.execute()
      doAssert results.len == 0

      await conn.close()

    waitFor t()

  test "pipeline: autoReset clears state after execute":
    proc t() {.async.} =
      let conn = await connect(plainConfig())

      let p = newPipeline(conn, autoReset = true)
      p.addQuery("SELECT $1::int4", @[toPgParam(10'i32)])
      p.addQuery("SELECT $1::int4", @[toPgParam(20'i32)])
      let r1 = await p.execute()
      doAssert r1.len == 2

      # After the first execute(), autoReset has cleared queued ops, so
      # calling execute() again produces an empty result without replaying.
      let r0 = await p.execute()
      doAssert r0.len == 0

      # Same instance is safe to reuse for a new batch.
      p.addQuery("SELECT $1::text", @[toPgParam("auto")])
      let r2 = await p.execute()
      doAssert r2.len == 1
      doAssert r2[0].queryResult.rows[0].getStr(0) == "auto"

      await conn.close()

    waitFor t()

  test "pipeline: autoReset clears state after executeIsolated (incl. on error)":
    proc t() {.async.} =
      let conn = await connect(plainConfig())

      let p = newPipeline(conn, autoReset = true)
      p.addQuery("SELECT 1::int4")
      p.addQuery("SELECT * FROM __definitely_missing_table__")
      p.addQuery("SELECT 2::int4")
      let ir = await p.executeIsolated()
      doAssert ir.results.len == 3
      doAssert ir.errors.len == 3
      doAssert ir.errors[0] == nil
      doAssert ir.errors[1] != nil
      doAssert ir.errors[2] == nil

      # After executeIsolated, autoReset should have cleared queued ops.
      let ir0 = await p.executeIsolated()
      doAssert ir0.results.len == 0
      doAssert ir0.errors.len == 0

      await conn.close()

    waitFor t()

  test "pipeline: autoReset clears state when execute raises":
    # execute() uses a single SYNC, so a failing op aborts the batch and the
    # await re-raises. Confirms the finally-path reset runs on raise.
    proc t() {.async.} =
      let conn = await connect(plainConfig())

      let p = newPipeline(conn, autoReset = true)
      p.addExec("SELECT 1")
      p.addExec("INVALID SQL THAT WILL FAIL")
      p.addExec("SELECT 2")
      var gotError = false
      try:
        discard await p.execute()
      except PgError:
        gotError = true
      doAssert gotError

      # Connection should still be usable after the error.
      doAssert conn.state == csReady

      # autoReset must have cleared queued ops even though execute() raised.
      let r0 = await p.execute()
      doAssert r0.len == 0

      # Reused instance is healthy for a brand-new batch.
      p.addQuery("SELECT $1::int4", @[toPgParam(42'i32)])
      let r1 = await p.execute()
      doAssert r1.len == 1
      doAssert r1[0].queryResult.rows[0].getStr(0) == "42"

      await conn.close()

    waitFor t()

  test "pipeline: pool withPipeline":
    proc t() {.async.} =
      let pool =
        await newPool(PoolConfig(connConfig: plainConfig(), minSize: 1, maxSize: 3))
      discard await pool.exec("DROP TABLE IF EXISTS test_pipe_pool")
      discard
        await pool.exec("CREATE TABLE test_pipe_pool (id serial PRIMARY KEY, val text)")

      pool.withPipeline(p):
        p.addExec(
          "INSERT INTO test_pipe_pool (val) VALUES ($1)", @[toPgParam("pooled")]
        )
        p.addQuery("SELECT val FROM test_pipe_pool")
        let results = await p.execute()
        doAssert results.len == 2
        doAssert results[0].commandResult == "INSERT 0 1"
        doAssert results[1].queryResult.rows[0].getStr(0) == "pooled"

      discard await pool.exec("DROP TABLE test_pipe_pool")
      await pool.close()

    waitFor t()

  test "pipeline: query with multiple rows":
    proc t() {.async.} =
      let conn = await connect(plainConfig())

      let p = newPipeline(conn)
      p.addQuery("SELECT generate_series(1, 5)::int4 AS n")
      p.addQuery("SELECT generate_series(10, 12)::int4 AS m")
      let results = await p.execute()
      doAssert results.len == 2

      doAssert results[0].queryResult.rowCount == 5
      for i in 0 ..< 5:
        doAssert results[0].queryResult.rows[i].getStr(0) == $(i + 1)

      doAssert results[1].queryResult.rowCount == 3
      doAssert results[1].queryResult.rows[0].getStr(0) == "10"
      doAssert results[1].queryResult.rows[2].getStr(0) == "12"

      await conn.close()

    waitFor t()

  test "pipeline: query returning zero rows":
    proc t() {.async.} =
      let conn = await connect(plainConfig())

      let p = newPipeline(conn)
      p.addQuery("SELECT 1::int4 WHERE false")
      p.addQuery("SELECT 42::int4")
      let results = await p.execute()
      doAssert results.len == 2

      doAssert results[0].queryResult.rowCount == 0
      doAssert results[1].queryResult.rowCount == 1
      doAssert results[1].queryResult.rows[0].getStr(0) == "42"

      await conn.close()

    waitFor t()

  test "pipeline: single op":
    proc t() {.async.} =
      let conn = await connect(plainConfig())

      var p1 = newPipeline(conn)
      p1.addQuery("SELECT 'only'::text")
      let r1 = await p1.execute()
      doAssert r1.len == 1
      doAssert r1[0].queryResult.rows[0].getStr(0) == "only"

      var p2 = newPipeline(conn)
      p2.addExec("SELECT 1")
      let r2 = await p2.execute()
      doAssert r2.len == 1
      doAssert r2[0].kind == prkExec

      await conn.close()

    waitFor t()

  test "pipeline: cache full evicts LRU entries":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      conn.stmtCacheCapacity = 2

      # Fill the cache
      discard await conn.query("SELECT 1")
      discard await conn.query("SELECT 2")
      doAssert conn.stmtCache.len == 2

      # Pipeline with new SQL: evicts LRU entries
      let p = newPipeline(conn)
      p.addQuery("SELECT 100::int4")
      p.addQuery("SELECT 300::int4")
      let results = await p.execute()
      doAssert results.len == 2
      doAssert conn.stmtCache.len == 2
      doAssert conn.stmtCache.hasKey("SELECT 100::int4")
      doAssert conn.stmtCache.hasKey("SELECT 300::int4")

      doAssert results[0].queryResult.rows[0].getStr(0) == "100"
      doAssert results[1].queryResult.rows[0].getStr(0) == "300"

      await conn.close()

    waitFor t()

  test "pipeline: cache misses exceed capacity":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      conn.stmtCacheCapacity = 2

      # 3 cache misses with capacity 2: should not crash
      let p = newPipeline(conn)
      p.addQuery("SELECT 10::int4")
      p.addQuery("SELECT 20::int4")
      p.addQuery("SELECT 30::int4")
      let results = await p.execute()
      doAssert results.len == 3
      doAssert results[0].queryResult.rows[0].getStr(0) == "10"
      doAssert results[1].queryResult.rows[0].getStr(0) == "20"
      doAssert results[2].queryResult.rows[0].getStr(0) == "30"
      # Only first 2 are cached (3rd exceeds capacity)
      doAssert conn.stmtCache.len == 2

      await conn.close()

    waitFor t()

  test "pipeline: same SQL query repeated in single pipeline":
    proc t() {.async.} =
      let conn = await connect(plainConfig())

      let p = newPipeline(conn)
      p.addQuery("SELECT $1::text", @[toPgParam("aaa")])
      p.addQuery("SELECT $1::text", @[toPgParam("bbb")])
      p.addQuery("SELECT $1::text", @[toPgParam("ccc")])
      let results = await p.execute()
      doAssert results.len == 3
      doAssert results[0].queryResult.rows[0].getStr(0) == "aaa"
      doAssert results[1].queryResult.rows[0].getStr(0) == "bbb"
      doAssert results[2].queryResult.rows[0].getStr(0) == "ccc"

      # Second pipeline: same SQL should hit cache
      var p2 = newPipeline(conn)
      p2.addQuery("SELECT $1::text", @[toPgParam("cached")])
      let r2 = await p2.execute()
      doAssert r2[0].queryResult.rows[0].getStr(0) == "cached"

      await conn.close()

    waitFor t()

  test "pipeline: executeIsolated basic":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_pipe_iso")
      discard
        await conn.exec("CREATE TABLE test_pipe_iso (id serial PRIMARY KEY, val text)")

      let p = newPipeline(conn)
      p.addExec("INSERT INTO test_pipe_iso (val) VALUES ($1)", @[toPgParam("a")])
      p.addQuery("SELECT 42::int4")
      p.addExec("INSERT INTO test_pipe_iso (val) VALUES ($1)", @[toPgParam("b")])
      let ir = await p.executeIsolated()
      doAssert ir.results.len == 3
      doAssert ir.errors.len == 3
      for i in 0 ..< 3:
        doAssert ir.errors[i] == nil
      doAssert ir.results[0].kind == prkExec
      doAssert ir.results[0].commandResult == "INSERT 0 1"
      doAssert ir.results[1].kind == prkQuery
      doAssert ir.results[1].queryResult.rows[0].getStr(0) == "42"
      doAssert ir.results[2].kind == prkExec

      let qr = await conn.query("SELECT val FROM test_pipe_iso ORDER BY id")
      doAssert qr.rowCount == 2
      doAssert qr.rows[0].getStr(0) == "a"
      doAssert qr.rows[1].getStr(0) == "b"

      discard await conn.exec("DROP TABLE test_pipe_iso")
      await conn.close()

    waitFor t()

  test "pipeline: executeIsolated error does not abort subsequent ops":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_pipe_iso2")
      discard await conn.exec(
        "CREATE TABLE test_pipe_iso2 (id serial PRIMARY KEY, val text NOT NULL)"
      )

      let p = newPipeline(conn)
      p.addExec("INSERT INTO test_pipe_iso2 (val) VALUES ($1)", @[toPgParam("ok")])
      # This will fail: NULL violates NOT NULL constraint
      p.addExec("INSERT INTO test_pipe_iso2 (val) VALUES (NULL)")
      p.addExec("INSERT INTO test_pipe_iso2 (val) VALUES ($1)", @[toPgParam("also_ok")])
      let ir = await p.executeIsolated()
      doAssert ir.results.len == 3
      doAssert ir.errors[0] == nil
      doAssert ir.errors[1] != nil
      doAssert ir.errors[2] == nil # NOT aborted, unlike execute()

      # Connection should still be usable
      doAssert conn.state == csReady
      let qr = await conn.query("SELECT val FROM test_pipe_iso2 ORDER BY id")
      doAssert qr.rowCount == 2
      doAssert qr.rows[0].getStr(0) == "ok"
      doAssert qr.rows[1].getStr(0) == "also_ok"

      discard await conn.exec("DROP TABLE test_pipe_iso2")
      await conn.close()

    waitFor t()

  test "pipeline: executeIsolated empty":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let p = newPipeline(conn)
      let ir = await p.executeIsolated()
      doAssert ir.results.len == 0
      doAssert ir.errors.len == 0
      await conn.close()

    waitFor t()

  test "pipeline: executeIsolated with cache hit":
    proc t() {.async.} =
      let conn = await connect(plainConfig())

      # Warm the cache
      discard await conn.query("SELECT $1::text", @[toPgParam("warm")])

      let p = newPipeline(conn)
      p.addQuery("SELECT $1::text", @[toPgParam("cached")])
      p.addQuery("SELECT $1::int4", @[toPgParam(99'i32)])
      let ir = await p.executeIsolated()
      doAssert ir.errors[0] == nil
      doAssert ir.errors[1] == nil
      doAssert ir.results[0].queryResult.rows[0].getStr(0) == "cached"
      doAssert ir.results[1].queryResult.rows[0].getStr(0) == "99"

      await conn.close()

    waitFor t()

  test "pipeline: executeIsolated timeout":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let p = newPipeline(conn)
      p.addQuery("SELECT pg_sleep(10)")
      var caught = false
      try:
        discard await p.executeIsolated(timeout = milliseconds(100))
      except PgTimeoutError:
        caught = true
      doAssert caught
      doAssert conn.state == csClosed

    waitFor t()

  test "pipeline: executeIsolated cache eviction":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      conn.stmtCacheCapacity = 2

      # Warm cache with 2 entries
      discard await conn.query("SELECT 1")
      discard await conn.query("SELECT 2")
      doAssert conn.stmtCache.len == 2

      # Pipeline 2 new queries via executeIsolated => evicts both old entries
      let p = newPipeline(conn)
      p.addQuery("SELECT 100::int4")
      p.addQuery("SELECT 200::int4")
      let ir = await p.executeIsolated()
      doAssert ir.errors[0] == nil
      doAssert ir.errors[1] == nil
      doAssert ir.results[0].queryResult.rows[0].getStr(0) == "100"
      doAssert ir.results[1].queryResult.rows[0].getStr(0) == "200"

      doAssert conn.stmtCache.len == 2
      doAssert conn.stmtCache.hasKey("SELECT 100::int4")
      doAssert conn.stmtCache.hasKey("SELECT 200::int4")

      await conn.close()

    waitFor t()

suite "E2E: Pipelined Pool":
  test "pipelined pool: basic exec and query":
    proc t() {.async.} =
      let pool = await newPool(
        PoolConfig(connConfig: plainConfig(), minSize: 1, maxSize: 3, pipelined: true)
      )
      discard await pool.exec("DROP TABLE IF EXISTS test_pp")
      discard await pool.exec("CREATE TABLE test_pp (id serial PRIMARY KEY, val text)")

      discard
        await pool.exec("INSERT INTO test_pp (val) VALUES ($1)", @[toPgParam("hi")])
      let qr = await pool.query("SELECT val FROM test_pp")
      doAssert qr.rowCount == 1
      doAssert qr.rows[0].getStr(0) == "hi"

      discard await pool.exec("DROP TABLE test_pp")
      await pool.close()

    waitFor t()

  test "pipelined pool: concurrent ops are batched":
    proc t() {.async.} =
      let pool = await newPool(
        PoolConfig(connConfig: plainConfig(), minSize: 1, maxSize: 3, pipelined: true)
      )

      # Fire multiple queries concurrently within the same tick
      let f1 = pool.query("SELECT 1::int4")
      let f2 = pool.query("SELECT 2::int4")
      let f3 = pool.query("SELECT 3::int4")
      let r1 = await f1
      let r2 = await f2
      let r3 = await f3
      doAssert r1.rows[0].getStr(0) == "1"
      doAssert r2.rows[0].getStr(0) == "2"
      doAssert r3.rows[0].getStr(0) == "3"

      await pool.close()

    waitFor t()

  test "pipelined pool: error isolation between ops":
    proc t() {.async.} =
      let pool = await newPool(
        PoolConfig(connConfig: plainConfig(), minSize: 1, maxSize: 3, pipelined: true)
      )

      let f1 = pool.query("SELECT 1::int4")
      let f2 = pool.query("INVALID SQL HERE")
      let f3 = pool.query("SELECT 3::int4")

      let r1 = await f1
      doAssert r1.rows[0].getStr(0) == "1"

      var gotError = false
      try:
        discard await f2
      except PgError:
        gotError = true
      doAssert gotError

      let r3 = await f3
      doAssert r3.rows[0].getStr(0) == "3"

      await pool.close()

    waitFor t()

  test "pipelined pool: exec error isolation":
    proc t() {.async.} =
      let pool = await newPool(
        PoolConfig(connConfig: plainConfig(), minSize: 1, maxSize: 3, pipelined: true)
      )
      discard await pool.exec("DROP TABLE IF EXISTS test_pp_exec_err")
      discard await pool.exec("CREATE TABLE test_pp_exec_err (id int PRIMARY KEY)")
      discard await pool.exec("INSERT INTO test_pp_exec_err VALUES (1)")

      # Fire concurrent ops: one exec will violate PK, others should succeed
      let f1 = pool.query("SELECT 1::int4")
      let f2 = pool.exec("INSERT INTO test_pp_exec_err VALUES (1)") # duplicate PK
      let f3 = pool.query("SELECT 3::int4")

      let r1 = await f1
      doAssert r1.rows[0].getStr(0) == "1"

      var gotError = false
      try:
        discard await f2
      except PgError:
        gotError = true
      doAssert gotError

      let r3 = await f3
      doAssert r3.rows[0].getStr(0) == "3"

      discard await pool.exec("DROP TABLE test_pp_exec_err")
      await pool.close()

    waitFor t()

  test "pipelined pool: queryRowOpt works":
    proc t() {.async.} =
      let pool = await newPool(
        PoolConfig(connConfig: plainConfig(), minSize: 1, maxSize: 3, pipelined: true)
      )
      let row = await pool.queryRowOpt("SELECT 42::int4 AS answer")
      doAssert row.isSome
      doAssert row.get.getStr(0) == "42"

      let empty = await pool.queryRowOpt("SELECT 1 WHERE false")
      doAssert empty.isNone

      await pool.close()

    waitFor t()

  test "pipelined pool: queryValue works":
    proc t() {.async.} =
      let pool = await newPool(
        PoolConfig(connConfig: plainConfig(), minSize: 1, maxSize: 3, pipelined: true)
      )
      let v = await pool.queryValue("SELECT 'hello'::text")
      doAssert v == "hello"

      await pool.close()

    waitFor t()

  test "pipelined pool: queryValueOpt works":
    proc t() {.async.} =
      let pool = await newPool(
        PoolConfig(connConfig: plainConfig(), minSize: 1, maxSize: 3, pipelined: true)
      )
      let opt = await pool.queryValueOpt("SELECT 'found'::text")
      doAssert opt.isSome
      doAssert opt.get == "found"

      let optNone = await pool.queryValueOpt("SELECT 1 WHERE false")
      doAssert optNone.isNone

      await pool.close()

    waitFor t()

  test "pipelined pool: queryValueOrDefault works":
    proc t() {.async.} =
      let pool = await newPool(
        PoolConfig(connConfig: plainConfig(), minSize: 1, maxSize: 3, pipelined: true)
      )
      let v = await pool.queryValueOrDefault("SELECT 'val'::text", default = "fb")
      doAssert v == "val"

      let def =
        await pool.queryValueOrDefault("SELECT 1 WHERE false", default = "fallback")
      doAssert def == "fallback"

      await pool.close()

    waitFor t()

  test "pipelined pool: queryExists works":
    proc t() {.async.} =
      let pool = await newPool(
        PoolConfig(connConfig: plainConfig(), minSize: 1, maxSize: 3, pipelined: true)
      )
      let exists = await pool.queryExists("SELECT 1")
      doAssert exists

      let notExists = await pool.queryExists("SELECT 1 WHERE false")
      doAssert not notExists

      await pool.close()

    waitFor t()

  test "pipelined pool: queryColumn works":
    proc t() {.async.} =
      let pool = await newPool(
        PoolConfig(connConfig: plainConfig(), minSize: 1, maxSize: 3, pipelined: true)
      )
      let col = await pool.queryColumn(
        "SELECT v::text FROM (VALUES ('a'), ('b'), ('c')) AS t(v)"
      )
      doAssert col.len == 3
      doAssert col == @["a", "b", "c"]

      await pool.close()

    waitFor t()

  test "pipelined pool: close fails pending ops":
    proc t() {.async.} =
      let pool = await newPool(
        PoolConfig(connConfig: plainConfig(), minSize: 1, maxSize: 3, pipelined: true)
      )
      # Queue an op but close immediately
      let fut = pool.query("SELECT 1::int4")
      await pool.close()

      var gotError = false
      try:
        discard await fut
      except PgError:
        gotError = true
      doAssert gotError

    waitFor t()

  test "pipelined pool: maxPipelineSize limits batch":
    proc t() {.async.} =
      let pool = await newPool(
        PoolConfig(
          connConfig: plainConfig(),
          minSize: 1,
          maxSize: 3,
          pipelined: true,
          maxPipelineSize: 2,
        )
      )

      # Fire 4 queries concurrently; maxPipelineSize=2 means batches of 2
      let f1 = pool.query("SELECT 10::int4")
      let f2 = pool.query("SELECT 20::int4")
      let f3 = pool.query("SELECT 30::int4")
      let f4 = pool.query("SELECT 40::int4")
      doAssert (await f1).rows[0].getStr(0) == "10"
      doAssert (await f2).rows[0].getStr(0) == "20"
      doAssert (await f3).rows[0].getStr(0) == "30"
      doAssert (await f4).rows[0].getStr(0) == "40"

      await pool.close()

    waitFor t()

  test "pipelined pool: high concurrency distributes across connections":
    proc t() {.async.} =
      let pool = await newPool(
        PoolConfig(connConfig: plainConfig(), minSize: 2, maxSize: 4, pipelined: true)
      )

      # Fire 6 concurrent queries -- more than maxSize
      let f1 = pool.query("SELECT 1::int4")
      let f2 = pool.query("SELECT 2::int4")
      let f3 = pool.query("SELECT 3::int4")
      let f4 = pool.query("SELECT 4::int4")
      let f5 = pool.query("SELECT 5::int4")
      let f6 = pool.query("SELECT 6::int4")
      doAssert (await f1).rows[0].getStr(0) == "1"
      doAssert (await f2).rows[0].getStr(0) == "2"
      doAssert (await f3).rows[0].getStr(0) == "3"
      doAssert (await f4).rows[0].getStr(0) == "4"
      doAssert (await f5).rows[0].getStr(0) == "5"
      doAssert (await f6).rows[0].getStr(0) == "6"

      await pool.close()

    waitFor t()

suite "E2E: queryDirect / execDirect":
  test "queryDirect with int32 param":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let qr = await conn.queryDirect("SELECT $1::int4 + 10", 5'i32)
      doAssert qr.rowCount == 1
      doAssert qr.rows[0].getInt(0) == 15
      await conn.close()

    waitFor t()

  test "queryDirect with string param":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let qr = await conn.queryDirect("SELECT $1::text || ' world'", "hello")
      doAssert qr.rowCount == 1
      doAssert qr.rows[0].getStr(0) == "hello world"
      await conn.close()

    waitFor t()

  test "queryDirect with multiple params":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let qr = await conn.queryDirect(
        "SELECT $1::int4 + $2::int4, $3::text", 10'i32, 20'i32, "abc"
      )
      doAssert qr.rowCount == 1
      doAssert qr.rows[0].getInt(0) == 30
      doAssert qr.rows[0].getStr(1) == "abc"
      await conn.close()

    waitFor t()

  test "queryDirect cache hit on repeated call":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      for i in 0 ..< 5:
        let qr = await conn.queryDirect("SELECT $1::int4 * 2", int32(i))
        doAssert qr.rows[0].getInt(0) == int32(i * 2)
      await conn.close()

    waitFor t()

  test "queryDirect no params":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let qr = await conn.queryDirect("SELECT 42 AS answer")
      doAssert qr.rowCount == 1
      doAssert qr.rows[0].getInt(0) == 42
      await conn.close()

    waitFor t()

  test "queryDirect Row survives subsequent queries (lifetime bug)":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let qr1 = await conn.queryDirect("SELECT $1::text", "x")
      let qr2 = await conn.queryDirect("SELECT $1::text", "y")
      doAssert qr1.rowCount == 1
      doAssert qr2.rowCount == 1
      let row1 = initRow(qr1.data, 0)
      let row2 = initRow(qr2.data, 0)
      doAssert row1.getStr(0) == "x", "qr1 data was invalidated by qr2"
      doAssert row2.getStr(0) == "y"
      await conn.close()

    waitFor t()

  test "execDirect INSERT and UPDATE":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_exec_direct")
      discard await conn.exec(
        "CREATE TABLE test_exec_direct (id serial PRIMARY KEY, val int NOT NULL)"
      )

      let tag1 =
        await conn.execDirect("INSERT INTO test_exec_direct (val) VALUES ($1)", 100'i32)
      doAssert "INSERT" in tag1

      let tag2 = await conn.execDirect(
        "UPDATE test_exec_direct SET val = $1 WHERE val = $2", 200'i32, 100'i32
      )
      doAssert "UPDATE 1" in tag2

      let qr = await conn.queryDirect(
        "SELECT val FROM test_exec_direct WHERE val = $1", 200'i32
      )
      doAssert qr.rowCount == 1
      doAssert qr.rows[0].getInt(0) == 200

      discard await conn.exec("DROP TABLE test_exec_direct")
      await conn.close()

    waitFor t()

  test "execDirect cache hit on repeated call":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_exec_direct2")
      discard await conn.exec(
        "CREATE TABLE test_exec_direct2 (id serial PRIMARY KEY, val int NOT NULL)"
      )

      for i in 0 ..< 5:
        discard await conn.execDirect(
          "INSERT INTO test_exec_direct2 (val) VALUES ($1)", int32(i)
        )

      let qr = await conn.query("SELECT count(*) FROM test_exec_direct2")
      doAssert qr.rows[0].getInt64(0) == 5

      discard await conn.exec("DROP TABLE test_exec_direct2")
      await conn.close()

    waitFor t()

  test "execDirect with bool param":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let qr = await conn.queryDirect("SELECT $1::bool", true)
      doAssert qr.rowCount == 1
      doAssert qr.rows[0].getBool(0) == true
      await conn.close()

    waitFor t()

  test "execDirect with int64 param":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let qr = await conn.queryDirect("SELECT $1::int8 + 1", 9223372036854775806'i64)
      doAssert qr.rowCount == 1
      doAssert qr.rows[0].getInt64(0) == 9223372036854775807'i64
      await conn.close()

    waitFor t()

  test "execDirect with float64 param":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let qr = await conn.queryDirect("SELECT $1::float8 + 0.5", 1.25'f64)
      doAssert qr.rowCount == 1
      doAssert abs(qr.rows[0].getFloat(0) - 1.75) < 1e-10
      await conn.close()

    waitFor t()

suite "E2E: queryEach":
  test "basic - all rows passed to callback":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      var count = 0
      let rowCount = await conn.queryEach(
        "SELECT generate_series(1, 5)",
        callback = proc(row: Row) =
          count += 1,
      )
      doAssert count == 5
      doAssert rowCount == 5
      await conn.close()

    waitFor t()

  test "value access in callback":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      var values: seq[string]
      discard await conn.queryEach(
        "SELECT 'hello'::text, 42::int4, true::bool",
        callback = proc(row: Row) =
          values.add(row.getStr(0))
          values.add($row.getInt(1))
          values.add($row.getBool(2)),
      )
      doAssert values == @["hello", "42", "true"]
      await conn.close()

    waitFor t()

  test "with PgParam parameters":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      var sum = 0
      let rowCount = await conn.queryEach(
        "SELECT generate_series(1, $1::int4)",
        @[10'i32.toPgParam],
        callback = proc(row: Row) =
          sum += row.getInt(0),
      )
      doAssert rowCount == 10
      doAssert sum == 55
      await conn.close()

    waitFor t()

  test "zero rows - callback not called":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      var called = false
      let rowCount = await conn.queryEach(
        "SELECT 1 WHERE false",
        callback = proc(row: Row) =
          called = true,
      )
      doAssert not called
      doAssert rowCount == 0
      await conn.close()

    waitFor t()

  test "row.clone() retains row beyond callback lifetime":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      var saved: seq[Row] = @[]
      discard await conn.queryEach(
        "SELECT * FROM (VALUES ('a', 1), ('b', 2), ('c', 3)) AS t(s, n)",
        callback = proc(row: Row) =
          saved.add(row.clone()),
      )
      doAssert saved.len == 3
      doAssert saved[0].getStr(0) == "a"
      doAssert saved[0].getInt(1) == 1
      doAssert saved[1].getStr(0) == "b"
      doAssert saved[1].getInt(1) == 2
      doAssert saved[2].getStr(0) == "c"
      doAssert saved[2].getInt(1) == 3
      await conn.close()

    waitFor t()

  test "10000 rows":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      var count = 0
      let rowCount = await conn.queryEach(
        "SELECT generate_series(1, 10000)",
        callback = proc(row: Row) =
          count += 1,
      )
      doAssert count == 10000
      doAssert rowCount == 10000
      await conn.close()

    waitFor t()

  test "binary format with cache hit":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      # First call: cache miss, populates stmt cache
      var firstVal = 0
      discard await conn.queryEach(
        "SELECT 42::int4",
        callback = proc(row: Row) =
          firstVal = row.getInt(0),
      )
      doAssert firstVal == 42
      # Second call: cache hit, should use binary format automatically
      var secondVal = 0
      discard await conn.queryEach(
        "SELECT 42::int4",
        callback = proc(row: Row) =
          secondVal = row.getInt(0),
      )
      doAssert secondVal == 42
      await conn.close()

    waitFor t()

  test "callback exception is propagated":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      var count = 0
      var gotError = false
      try:
        discard await conn.queryEach(
          "SELECT generate_series(1, 5)",
          callback = proc(row: Row) =
            count += 1
            if count == 3:
              raise newException(ValueError, "test error")
          ,
        )
      except CatchableError:
        gotError = true
      doAssert gotError
      # Connection should be in ready state after exception
      doAssert conn.state == csReady
      # Connection should still be usable
      let qr = await conn.query("SELECT 1")
      doAssert qr.rowCount == 1
      await conn.close()

    waitFor t()

  test "NULL value handling":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      var gotNull = false
      var gotValue = false
      discard await conn.queryEach(
        "SELECT NULL::text, 'hello'::text",
        callback = proc(row: Row) =
          gotNull = row.isNull(0)
          gotValue = row.getStr(1) == "hello",
      )
      doAssert gotNull
      doAssert gotValue
      await conn.close()

    waitFor t()

  test "multiple rows have correct values":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      var values: seq[int]
      discard await conn.queryEach(
        "SELECT x FROM generate_series(1, 5) AS x ORDER BY x",
        callback = proc(row: Row) =
          values.add(row.getInt(0)),
      )
      doAssert values == @[1, 2, 3, 4, 5]
      await conn.close()

    waitFor t()

  test "consecutive queryEach on same connection":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      var sum1 = 0
      discard await conn.queryEach(
        "SELECT generate_series(1, 3)",
        callback = proc(row: Row) =
          sum1 += row.getInt(0),
      )
      var sum2 = 0
      discard await conn.queryEach(
        "SELECT generate_series(10, 12)",
        callback = proc(row: Row) =
          sum2 += row.getInt(0),
      )
      doAssert sum1 == 6
      doAssert sum2 == 33
      await conn.close()

    waitFor t()

  test "queryEach then query on same connection":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      var eachCount = 0
      discard await conn.queryEach(
        "SELECT generate_series(1, 5)",
        callback = proc(row: Row) =
          eachCount += 1,
      )
      doAssert eachCount == 5
      let qr = await conn.query("SELECT 42::int4")
      doAssert qr.rowCount == 1
      doAssert qr.rows[0].getInt(0) == 42
      await conn.close()

    waitFor t()

  test "invalid SQL raises PgError":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      var gotError = false
      try:
        discard await conn.queryEach(
          "SELECT FROM nonexistent_table_xyz",
          callback = proc(row: Row) =
            discard,
        )
      except PgError:
        gotError = true
      doAssert gotError
      doAssert conn.state == csReady
      await conn.close()

    waitFor t()

  test "without stmt cache":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      conn.stmtCacheCapacity = 0
      var values: seq[int]
      let rowCount = await conn.queryEach(
        "SELECT generate_series(1, 3)",
        callback = proc(row: Row) =
          values.add(row.getInt(0)),
      )
      doAssert rowCount == 3
      doAssert values == @[1, 2, 3]
      await conn.close()

    waitFor t()

  test "queryEach with params":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      var sum = 0
      let rowCount = await conn.queryEach(
        "SELECT generate_series(1, $1::int4)",
        @[toPgParam("5")],
        callback = proc(row: Row) =
          sum += row.getInt(0),
      )
      doAssert rowCount == 5
      doAssert sum == 15
      await conn.close()

    waitFor t()

  test "pool queryEach":
    proc t() {.async.} =
      let pool = await newPool(initPoolConfig(plainConfig(), minSize = 1, maxSize = 2))
      var count = 0
      let rowCount = await pool.queryEach(
        "SELECT generate_series(1, 5)",
        callback = proc(row: Row) =
          count += 1,
      )
      doAssert count == 5
      doAssert rowCount == 5
      await pool.close()

    waitFor t()

  test "pool queryEach with PgParam":
    proc t() {.async.} =
      let pool = await newPool(initPoolConfig(plainConfig(), minSize = 1, maxSize = 2))
      var sum = 0
      let rowCount = await pool.queryEach(
        "SELECT generate_series(1, $1::int4)",
        @[5'i32.toPgParam],
        callback = proc(row: Row) =
          sum += row.getInt(0),
      )
      doAssert rowCount == 5
      doAssert sum == 15
      await pool.close()

    waitFor t()

suite "E2E: Error type granularity":
  test "invalid SQL via exec raises PgQueryError with SQLSTATE":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      var sqlState = ""
      var detail = ""
      try:
        discard await conn.exec("INSERT INTO nonexistent_tbl VALUES (1)")
      except PgQueryError as e:
        sqlState = e.sqlState
        detail = e.detail
      doAssert sqlState == "42P01" # undefined_table
      doAssert conn.state == csReady
      await conn.close()

    waitFor t()

  test "syntax error via query raises PgQueryError":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      var sqlState = ""
      try:
        discard await conn.query("SELECTT 1")
      except PgQueryError as e:
        sqlState = e.sqlState
      doAssert sqlState == "42601" # syntax_error
      doAssert conn.state == csReady
      await conn.close()

    waitFor t()

  test "PgQueryError is catchable as PgError":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      var caught = false
      try:
        discard await conn.exec("INSERT INTO nonexistent_tbl VALUES (1)")
      except PgError:
        caught = true
      doAssert caught
      doAssert conn.state == csReady
      await conn.close()

    waitFor t()

  test "wrong password raises PgConnectionError":
    proc t() {.async.} =
      let badConfig = ConnConfig(
        host: PgHost,
        port: PgPort,
        user: PgUser,
        password: "wrong_password",
        database: PgDatabase,
        sslMode: sslDisable,
      )
      var caught = false
      try:
        let conn = await connect(badConfig)
        await conn.close()
      except PgConnectionError:
        caught = true
      except PgError:
        discard
      doAssert caught

    waitFor t()

  test "connection to bad host raises PgConnectionError":
    proc t() {.async.} =
      let badConfig = ConnConfig(
        host: "127.0.0.1",
        port: 1, # unlikely to have a PG server
        user: "test",
        password: "test",
        database: "test",
        sslMode: sslDisable,
      )
      var caught = false
      try:
        let conn = await connect(badConfig)
        await conn.close()
      except PgConnectionError:
        caught = true
      except CatchableError:
        discard
      doAssert caught

    waitFor t()

  test "PgConnectionError is catchable as PgError":
    proc t() {.async.} =
      let badConfig = ConnConfig(
        host: PgHost,
        port: PgPort,
        user: PgUser,
        password: "wrong_password",
        database: PgDatabase,
        sslMode: sslDisable,
      )
      var caught = false
      try:
        let conn = await connect(badConfig)
        await conn.close()
      except PgError:
        caught = true
      doAssert caught

    waitFor t()

  test "exec timeout raises PgTimeoutError":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      var caught = false
      try:
        discard await conn.exec("SELECT pg_sleep(10)", timeout = milliseconds(50))
      except PgTimeoutError:
        caught = true
      except PgError:
        discard
      doAssert caught
      # Connection should be closed after timeout
      doAssert conn.state == csClosed

    waitFor t()

  test "PgTimeoutError is catchable as PgError":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      var caught = false
      try:
        discard await conn.exec("SELECT pg_sleep(10)", timeout = milliseconds(50))
      except PgError:
        caught = true
      doAssert caught

    waitFor t()

  test "PgQueryError fields populated for constraint violation":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TABLE IF EXISTS test_err_types")
      discard await conn.exec(
        "CREATE TABLE test_err_types (id int PRIMARY KEY, val text NOT NULL)"
      )
      discard await conn.exec(
        "INSERT INTO test_err_types VALUES ($1, $2)", pgParams(1'i32, "hello")
      )

      var sqlState = ""
      var detail = ""
      try:
        discard await conn.exec(
          "INSERT INTO test_err_types VALUES ($1, $2)", pgParams(1'i32, "duplicate")
        )
      except PgQueryError as e:
        sqlState = e.sqlState
        detail = e.detail

      doAssert sqlState == "23505" # unique_violation
      doAssert detail.len > 0

      discard await conn.exec("DROP TABLE test_err_types")
      await conn.close()

    waitFor t()

suite "E2E: quoteIdentifier":
  test "simple identifier":
    doAssert quoteIdentifier("foo") == "\"foo\""

  test "identifier with double quotes":
    doAssert quoteIdentifier("foo\"bar") == "\"foo\"\"bar\""

  test "empty string":
    doAssert quoteIdentifier("") == "\"\""

  test "identifier with spaces":
    doAssert quoteIdentifier("my table") == "\"my table\""

suite "E2E: cancelNoWait":
  test "cancelNoWait aborts pg_sleep":
    proc t() {.async.} =
      let conn = await connect(plainConfig())

      # Start a long-running query
      let sleepFut = conn.simpleQuery("SELECT pg_sleep(30)")

      # Give the server time to start executing
      await sleepAsync(milliseconds(100))

      # Cancel the query without waiting
      conn.cancelNoWait()

      # The original query should fail with query_canceled (57014)
      var raised = false
      try:
        discard await sleepFut
      except PgError as e:
        raised = true
        doAssert "57014" in e.msg
      doAssert raised

      # Connection should still be usable after cancel
      doAssert conn.state == csReady
      let res = await conn.simpleQuery("SELECT 1 AS check_col")
      doAssert res[0].rows[0][0].get().toString() == "1"

      await conn.close()

    waitFor t()

  test "tsvector roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let v = PgTsVector("'cat':1A 'dog':3")
      let res = await conn.query("SELECT $1::tsvector", @[toPgParam(v)])
      doAssert res.rows.len == 1
      let got = res.rows[0].getTsVector(0)
      doAssert $got == "'cat':1A 'dog':3"
      await conn.close()

    waitFor t()

  test "to_tsvector function":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res =
        await conn.query("SELECT to_tsvector('english', 'The fat cat sat on the mat')")
      doAssert res.rows.len == 1
      let v = res.rows[0].getTsVector(0)
      let s = $v
      doAssert "'cat'" in s
      doAssert "'fat'" in s
      doAssert "'mat'" in s
      doAssert "'sat'" in s
      await conn.close()

    waitFor t()

  test "tsquery roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let q = PgTsQuery("'fat' & 'rat'")
      let res = await conn.query("SELECT $1::tsquery", @[toPgParam(q)])
      doAssert res.rows.len == 1
      let got = res.rows[0].getTsQuery(0)
      doAssert "'fat' & 'rat'" == $got
      await conn.close()

    waitFor t()

  test "full-text search with @@ operator":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res = await conn.query(
        "SELECT to_tsvector('english', 'the fat cat') @@ to_tsquery('english', 'fat & cat')"
      )
      doAssert res.rows.len == 1
      doAssert res.rows[0].getBool(0) == true
      let res2 = await conn.query(
        "SELECT to_tsvector('english', 'the fat cat') @@ to_tsquery('english', 'fat & dog')"
      )
      doAssert res2.rows[0].getBool(0) == false
      await conn.close()

    waitFor t()

  test "NULL tsvector and tsquery":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res = await conn.query("SELECT NULL::tsvector, NULL::tsquery")
      doAssert res.rows.len == 1
      doAssert res.rows[0].getTsVectorOpt(0).isNone
      doAssert res.rows[0].getTsQueryOpt(1).isNone
      await conn.close()

    waitFor t()

  test "tsvector binary results":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res =
        await conn.query("SELECT 'cat:1A dog:3'::tsvector", resultFormat = rfBinary)
      doAssert res.rows.len == 1
      let v = res.rows[0].getTsVector(0)
      let s = $v
      doAssert "'cat'" in s
      doAssert "'dog'" in s
      await conn.close()

    waitFor t()

  test "tsquery binary results":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res = await conn.query("SELECT 'fat & rat'::tsquery", resultFormat = rfBinary)
      doAssert res.rows.len == 1
      let q = res.rows[0].getTsQuery(0)
      let s = $q
      doAssert "'fat'" in s
      doAssert "'rat'" in s
      await conn.close()

    waitFor t()

  test "xml roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let v = PgXml("<root><item>hello</item></root>")
      let res = await conn.query("SELECT $1::xml", @[toPgParam(v)])
      doAssert res.rows.len == 1
      let got = res.rows[0].getXml(0)
      doAssert $got == "<root><item>hello</item></root>"
      await conn.close()

    waitFor t()

  test "xmlparse function":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res = await conn.query("SELECT xmlparse(CONTENT '<item>test</item>')")
      doAssert res.rows.len == 1
      let v = res.rows[0].getXml(0)
      doAssert "<item>test</item>" == $v
      await conn.close()

    waitFor t()

  test "NULL xml":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res = await conn.query("SELECT NULL::xml")
      doAssert res.rows.len == 1
      doAssert res.rows[0].getXmlOpt(0).isNone
      await conn.close()

    waitFor t()

  test "xml binary results":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res =
        await conn.query("SELECT '<root>data</root>'::xml", resultFormat = rfBinary)
      doAssert res.rows.len == 1
      let v = res.rows[0].getXml(0)
      doAssert "<root>data</root>" == $v
      await conn.close()

    waitFor t()

suite "E2E: Logical Replication":
  test "identifySystem returns valid info":
    proc t() {.async.} =
      let conn = await connectReplication(plainConfig())
      let info = await conn.identifySystem()
      doAssert info.systemId.len > 0
      doAssert info.timeline >= 1
      doAssert info.xLogPos != InvalidLsn
      doAssert info.dbName == PgDatabase
      await conn.close()

    waitFor t()

  test "create and drop temporary replication slot":
    proc t() {.async.} =
      let conn = await connectReplication(plainConfig())
      let slot =
        await conn.createReplicationSlot("test_temp_slot", "pgoutput", temporary = true)
      doAssert slot.slotName == "test_temp_slot"
      doAssert slot.consistentPoint != InvalidLsn
      doAssert slot.outputPlugin == "pgoutput"

      await conn.dropReplicationSlot("test_temp_slot")
      await conn.close()

    waitFor t()

  test "stream replication and receive insert":
    proc t() {.async.} =
      let writer = await connect(plainConfig())

      # Set up test table and publication
      discard await writer.simpleQuery("DROP PUBLICATION IF EXISTS test_repl_pub")
      discard await writer.simpleQuery("DROP TABLE IF EXISTS test_repl_tbl")
      discard await writer.simpleQuery(
        "CREATE TABLE test_repl_tbl (id serial PRIMARY KEY, val text)"
      )
      discard await writer.simpleQuery(
        "CREATE PUBLICATION test_repl_pub FOR TABLE test_repl_tbl"
      )

      # Replication connection
      let replConn = await connectReplication(plainConfig())
      let slot = await replConn.createReplicationSlot(
        "test_stream_slot", "pgoutput", temporary = true
      )

      var relations: RelationCache
      var gotInsert = false
      var insertRelName = ""
      var insertVal = ""

      let cb = makeReplicationCallback:
        case msg.kind
        of rmkXLogData:
          let pgMsg = decodePgOutput(msg.xlogData)
          case pgMsg.kind
          of pomkRelation:
            relations[pgMsg.relation.relationId] = pgMsg.relation
          of pomkInsert:
            gotInsert = true
            if pgMsg.insert.relationId in relations:
              insertRelName = relations[pgMsg.insert.relationId].name
            if pgMsg.insert.newTuple.len >= 2 and
                pgMsg.insert.newTuple[1].kind == tdkText:
              insertVal = pgMsg.insert.newTuple[1].toString()
            await replConn.sendStandbyStatus(msg.xlogData.endLsn)
            await replConn.stopReplication()
          of pomkCommit:
            discard
          else:
            discard
        of rmkPrimaryKeepalive:
          if msg.keepalive.replyRequested:
            await replConn.sendStandbyStatus(msg.keepalive.walEnd)

      # Insert a row from the writer connection after a short delay
      proc insertRow() {.async.} =
        await sleepAsync(milliseconds(200))
        discard await writer.simpleQuery(
          "INSERT INTO test_repl_tbl (val) VALUES ('hello_repl')"
        )

      let insertFut = insertRow()

      await replConn.startReplication(
        "test_stream_slot",
        slot.consistentPoint,
        options = @{"proto_version": "'1'", "publication_names": "'test_repl_pub'"},
        callback = cb,
      )

      await insertFut

      doAssert gotInsert, "Should have received an INSERT message"
      doAssert insertRelName == "test_repl_tbl"
      doAssert insertVal == "hello_repl"
      doAssert replConn.state == csReady

      await replConn.close()

      # Clean up
      discard await writer.simpleQuery("DROP PUBLICATION test_repl_pub")
      discard await writer.simpleQuery("DROP TABLE test_repl_tbl")
      await writer.close()

    waitFor t()

  test "connection state is csReady after replication ends":
    proc t() {.async.} =
      let writer = await connect(plainConfig())
      discard await writer.simpleQuery("DROP PUBLICATION IF EXISTS test_state_pub")
      discard await writer.simpleQuery("CREATE PUBLICATION test_state_pub")

      let replConn = await connectReplication(plainConfig())
      let slot = await replConn.createReplicationSlot(
        "test_state_slot", "pgoutput", temporary = true
      )

      let cb = makeReplicationCallback:
        case msg.kind
        of rmkXLogData:
          await replConn.sendStandbyStatus(msg.xlogData.endLsn)
        of rmkPrimaryKeepalive:
          # Stop immediately on first keepalive
          await replConn.sendStandbyStatus(msg.keepalive.walEnd)
          await replConn.stopReplication()

      await replConn.startReplication(
        "test_state_slot",
        slot.consistentPoint,
        options = @{"proto_version": "'1'", "publication_names": "'test_state_pub'"},
        callback = cb,
      )

      doAssert replConn.state == csReady

      # Connection should be reusable
      let info = await replConn.identifySystem()
      doAssert info.systemId.len > 0

      await replConn.close()

      discard await writer.simpleQuery("DROP PUBLICATION test_state_pub")
      await writer.close()

    waitFor t()

# User-defined type definitions for e2e tests (macros must be at top level)
type
  TestPoint = object
    x: float64
    y: float64

  TestPerson = object
    name: string
    age: int32
    score: float64

  TestNullable = object
    name: string
    age: Option[int32]
    note: Option[string]

pgComposite(TestPoint)
pgComposite(TestPerson)
pgComposite(TestNullable)

type TestMood = enum
  tmHappy = "happy"
  tmSad = "sad"
  tmOk = "ok"

pgEnum(TestMood)

type TestPosInt = distinct int32

pgDomain(TestPosInt, int32)

suite "E2E: User-Defined Types":
  test "composite roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.simpleQuery("DROP TYPE IF EXISTS test_e2e_point CASCADE")
      discard
        await conn.simpleQuery("CREATE TYPE test_e2e_point AS (x float8, y float8)")

      let res = await conn.query("SELECT ROW(1.5, 2.5)::test_e2e_point")
      doAssert res.rows.len == 1
      let got = getComposite[TestPoint](res.rows[0], 0)
      doAssert got.x == 1.5
      doAssert got.y == 2.5

      discard await conn.simpleQuery("DROP TYPE test_e2e_point")
      await conn.close()

    waitFor t()

  test "composite with strings":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.simpleQuery("DROP TYPE IF EXISTS test_e2e_person CASCADE")
      discard await conn.simpleQuery(
        "CREATE TYPE test_e2e_person AS (name text, age int4, score float8)"
      )

      let res = await conn.query("SELECT ROW('Alice', 30, 95.5)::test_e2e_person")
      doAssert res.rows.len == 1
      let got = getComposite[TestPerson](res.rows[0], 0)
      doAssert got.name == "Alice"
      doAssert got.age == 30'i32
      doAssert got.score == 95.5

      discard await conn.simpleQuery("DROP TYPE test_e2e_person")
      await conn.close()

    waitFor t()

  test "composite NULL fields":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.simpleQuery("DROP TYPE IF EXISTS test_e2e_nullable CASCADE")
      discard await conn.simpleQuery(
        "CREATE TYPE test_e2e_nullable AS (name text, age int4, note text)"
      )

      let res = await conn.query("SELECT ROW('Bob', NULL, NULL)::test_e2e_nullable")
      doAssert res.rows.len == 1
      let got = getComposite[TestNullable](res.rows[0], 0)
      doAssert got.name == "Bob"
      doAssert got.age.isNone
      doAssert got.note.isNone

      discard await conn.simpleQuery("DROP TYPE test_e2e_nullable")
      await conn.close()

    waitFor t()

  test "NULL composite":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.simpleQuery("DROP TYPE IF EXISTS test_e2e_point2 CASCADE")
      discard
        await conn.simpleQuery("CREATE TYPE test_e2e_point2 AS (x float8, y float8)")

      let res = await conn.query("SELECT NULL::test_e2e_point2")
      doAssert res.rows.len == 1
      let got = getCompositeOpt[TestPoint](res.rows[0], 0)
      doAssert got.isNone

      discard await conn.simpleQuery("DROP TYPE test_e2e_point2")
      await conn.close()

    waitFor t()

  test "composite param roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.simpleQuery("DROP TYPE IF EXISTS test_e2e_point3 CASCADE")
      discard
        await conn.simpleQuery("CREATE TYPE test_e2e_point3 AS (x float8, y float8)")

      let v = TestPoint(x: 3.14, y: 2.72)
      let res = await conn.query("SELECT $1::test_e2e_point3", @[toPgParam(v)])
      doAssert res.rows.len == 1
      let got = getComposite[TestPoint](res.rows[0], 0)
      doAssert got.x == 3.14
      doAssert got.y == 2.72

      discard await conn.simpleQuery("DROP TYPE test_e2e_point3")
      await conn.close()

    waitFor t()

  test "enum roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.simpleQuery("DROP TYPE IF EXISTS test_e2e_mood CASCADE")
      discard await conn.simpleQuery(
        "CREATE TYPE test_e2e_mood AS ENUM ('happy', 'sad', 'ok')"
      )

      let res = await conn.query("SELECT 'happy'::test_e2e_mood")
      doAssert res.rows.len == 1
      let got = getEnum[TestMood](res.rows[0], 0)
      doAssert got == tmHappy

      discard await conn.simpleQuery("DROP TYPE test_e2e_mood")
      await conn.close()

    waitFor t()

  test "enum param roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.simpleQuery("DROP TYPE IF EXISTS test_e2e_mood2 CASCADE")
      discard await conn.simpleQuery(
        "CREATE TYPE test_e2e_mood2 AS ENUM ('happy', 'sad', 'ok')"
      )

      let res = await conn.query("SELECT $1::test_e2e_mood2", @[toPgParam(tmSad)])
      doAssert res.rows.len == 1
      let got = getEnum[TestMood](res.rows[0], 0)
      doAssert got == tmSad

      discard await conn.simpleQuery("DROP TYPE test_e2e_mood2")
      await conn.close()

    waitFor t()

  test "enum in table":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.simpleQuery("DROP TABLE IF EXISTS test_e2e_mood_tbl CASCADE")
      discard await conn.simpleQuery("DROP TYPE IF EXISTS test_e2e_mood3 CASCADE")
      discard await conn.simpleQuery(
        "CREATE TYPE test_e2e_mood3 AS ENUM ('happy', 'sad', 'ok')"
      )
      discard await conn.simpleQuery(
        "CREATE TABLE test_e2e_mood_tbl (id serial, mood test_e2e_mood3)"
      )
      discard
        await conn.simpleQuery("INSERT INTO test_e2e_mood_tbl (mood) VALUES ('ok')")

      let res = await conn.query("SELECT mood FROM test_e2e_mood_tbl WHERE id = 1")
      doAssert res.rows.len == 1
      let got = getEnum[TestMood](res.rows[0], 0)
      doAssert got == tmOk

      discard await conn.simpleQuery("DROP TABLE test_e2e_mood_tbl")
      discard await conn.simpleQuery("DROP TYPE test_e2e_mood3")
      await conn.close()

    waitFor t()

  test "NULL enum":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.simpleQuery("DROP TYPE IF EXISTS test_e2e_mood4 CASCADE")
      discard await conn.simpleQuery(
        "CREATE TYPE test_e2e_mood4 AS ENUM ('happy', 'sad', 'ok')"
      )

      let res = await conn.query("SELECT NULL::test_e2e_mood4")
      doAssert res.rows.len == 1
      let got = getEnumOpt[TestMood](res.rows[0], 0)
      doAssert got.isNone

      discard await conn.simpleQuery("DROP TYPE test_e2e_mood4")
      await conn.close()

    waitFor t()

  test "domain roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.simpleQuery("DROP DOMAIN IF EXISTS test_e2e_posint CASCADE")
      discard await conn.simpleQuery(
        "CREATE DOMAIN test_e2e_posint AS int4 CHECK (VALUE > 0)"
      )

      let res =
        await conn.query("SELECT $1::test_e2e_posint", @[toPgParam(TestPosInt(42))])
      doAssert res.rows.len == 1
      let got = getDomain[TestPosInt](res.rows[0], 0)
      doAssert int32(got) == 42'i32

      discard await conn.simpleQuery("DROP DOMAIN test_e2e_posint")
      await conn.close()

    waitFor t()

  test "domain constraint violation":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.simpleQuery("DROP DOMAIN IF EXISTS test_e2e_posint2 CASCADE")
      discard await conn.simpleQuery(
        "CREATE DOMAIN test_e2e_posint2 AS int4 CHECK (VALUE > 0)"
      )

      var raised = false
      try:
        discard
          await conn.query("SELECT $1::test_e2e_posint2", @[toPgParam(TestPosInt(-1))])
      except PgError:
        raised = true
      doAssert raised

      discard await conn.simpleQuery("DROP DOMAIN test_e2e_posint2")
      await conn.close()

    waitFor t()

suite "E2E: Network Types":
  test "inet roundtrip IPv4":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let v = PgInet(address: parseIpAddress("192.168.1.5"), mask: 24)
      let res = await conn.query("SELECT $1::inet", @[toPgParam(v)])
      doAssert res.rows.len == 1
      let got = res.rows[0].getInet(0)
      doAssert got.address == parseIpAddress("192.168.1.5")
      doAssert got.mask == 24
      await conn.close()

    waitFor t()

  test "inet roundtrip IPv6":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let v = PgInet(address: parseIpAddress("::1"), mask: 128)
      let res = await conn.query("SELECT $1::inet", @[toPgParam(v)])
      doAssert res.rows.len == 1
      let got = res.rows[0].getInet(0)
      doAssert got.address == parseIpAddress("::1")
      doAssert got.mask == 128
      await conn.close()

    waitFor t()

  test "inet host address without mask":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let v = PgInet(address: parseIpAddress("10.0.0.1"), mask: 32)
      let res = await conn.query("SELECT $1::inet", @[toPgParam(v)])
      doAssert res.rows.len == 1
      let got = res.rows[0].getInet(0)
      doAssert got.address == parseIpAddress("10.0.0.1")
      doAssert got.mask == 32
      await conn.close()

    waitFor t()

  test "cidr roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let v = PgCidr(address: parseIpAddress("10.0.0.0"), mask: 8)
      let res = await conn.query("SELECT $1::cidr", @[toPgParam(v)])
      doAssert res.rows.len == 1
      let got = res.rows[0].getCidr(0)
      doAssert got.address == parseIpAddress("10.0.0.0")
      doAssert got.mask == 8
      await conn.close()

    waitFor t()

  test "macaddr roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let v = PgMacAddr("08:00:2b:01:02:03")
      let res = await conn.query("SELECT $1::macaddr", @[toPgParam(v)])
      doAssert res.rows.len == 1
      let got = res.rows[0].getMacAddr(0)
      doAssert $got == "08:00:2b:01:02:03"
      await conn.close()

    waitFor t()

  test "macaddr8 roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let v = PgMacAddr8("08:00:2b:01:02:03:04:05")
      let res = await conn.query("SELECT $1::macaddr8", @[toPgParam(v)])
      doAssert res.rows.len == 1
      let got = res.rows[0].getMacAddr8(0)
      doAssert $got == "08:00:2b:01:02:03:04:05"
      await conn.close()

    waitFor t()

  test "NULL network types":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res =
        await conn.query("SELECT NULL::inet, NULL::cidr, NULL::macaddr, NULL::macaddr8")
      doAssert res.rows.len == 1
      doAssert res.rows[0].getInetOpt(0).isNone
      doAssert res.rows[0].getCidrOpt(1).isNone
      doAssert res.rows[0].getMacAddrOpt(2).isNone
      doAssert res.rows[0].getMacAddr8Opt(3).isNone
      await conn.close()

    waitFor t()

  test "inet in table":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.simpleQuery("DROP TABLE IF EXISTS test_e2e_inet_tbl CASCADE")
      discard
        await conn.simpleQuery("CREATE TABLE test_e2e_inet_tbl (id serial, addr inet)")

      let v = PgInet(address: parseIpAddress("192.168.0.1"), mask: 24)
      discard await conn.exec(
        "INSERT INTO test_e2e_inet_tbl (addr) VALUES ($1)", @[toPgParam(v)]
      )
      let res = await conn.query("SELECT addr FROM test_e2e_inet_tbl WHERE id = 1")
      doAssert res.rows.len == 1
      let got = res.rows[0].getInet(0)
      doAssert got.address == parseIpAddress("192.168.0.1")
      doAssert got.mask == 24

      discard await conn.simpleQuery("DROP TABLE test_e2e_inet_tbl")
      await conn.close()

    waitFor t()

suite "E2E: Geometric Types":
  test "point roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let v = PgPoint(x: 1.5, y: 2.5)
      let res = await conn.query("SELECT $1::point", @[toPgParam(v)])
      doAssert res.rows.len == 1
      let got = res.rows[0].getPoint(0)
      doAssert got.x == 1.5
      doAssert got.y == 2.5
      await conn.close()

    waitFor t()

  test "line roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let v = PgLine(a: 1.0, b: -1.0, c: 0.0)
      let res = await conn.query("SELECT $1::line", @[toPgParam(v)])
      doAssert res.rows.len == 1
      let got = res.rows[0].getLine(0)
      doAssert got.a == 1.0
      doAssert got.b == -1.0
      doAssert got.c == 0.0
      await conn.close()

    waitFor t()

  test "lseg roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let v = PgLseg(p1: PgPoint(x: 0.0, y: 0.0), p2: PgPoint(x: 3.0, y: 4.0))
      let res = await conn.query("SELECT $1::lseg", @[toPgParam(v)])
      doAssert res.rows.len == 1
      let got = res.rows[0].getLseg(0)
      doAssert got.p1.x == 0.0
      doAssert got.p1.y == 0.0
      doAssert got.p2.x == 3.0
      doAssert got.p2.y == 4.0
      await conn.close()

    waitFor t()

  test "box roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let v = PgBox(high: PgPoint(x: 3.0, y: 4.0), low: PgPoint(x: 1.0, y: 2.0))
      let res = await conn.query("SELECT $1::box", @[toPgParam(v)])
      doAssert res.rows.len == 1
      let got = res.rows[0].getBox(0)
      doAssert got.high.x == 3.0
      doAssert got.high.y == 4.0
      doAssert got.low.x == 1.0
      doAssert got.low.y == 2.0
      await conn.close()

    waitFor t()

  test "path roundtrip closed":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let v = PgPath(
        closed: true,
        points:
          @[PgPoint(x: 0.0, y: 0.0), PgPoint(x: 1.0, y: 0.0), PgPoint(x: 0.0, y: 1.0)],
      )
      let res = await conn.query("SELECT $1::path", @[toPgParam(v)])
      doAssert res.rows.len == 1
      let got = res.rows[0].getPath(0)
      doAssert got.closed == true
      doAssert got.points.len == 3
      doAssert got.points[0].x == 0.0
      doAssert got.points[1].x == 1.0
      doAssert got.points[2].y == 1.0
      await conn.close()

    waitFor t()

  test "path roundtrip open":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let v = PgPath(
        closed: false, points: @[PgPoint(x: 0.0, y: 0.0), PgPoint(x: 5.0, y: 5.0)]
      )
      let res = await conn.query("SELECT $1::path", @[toPgParam(v)])
      doAssert res.rows.len == 1
      let got = res.rows[0].getPath(0)
      doAssert got.closed == false
      doAssert got.points.len == 2
      doAssert got.points[0].x == 0.0
      doAssert got.points[1].x == 5.0
      await conn.close()

    waitFor t()

  test "polygon roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let v = PgPolygon(
        points: @[
          PgPoint(x: 0.0, y: 0.0),
          PgPoint(x: 4.0, y: 0.0),
          PgPoint(x: 4.0, y: 3.0),
          PgPoint(x: 0.0, y: 3.0),
        ]
      )
      let res = await conn.query("SELECT $1::polygon", @[toPgParam(v)])
      doAssert res.rows.len == 1
      let got = res.rows[0].getPolygon(0)
      doAssert got.points.len == 4
      doAssert got.points[0].x == 0.0
      doAssert got.points[2].x == 4.0
      doAssert got.points[2].y == 3.0
      await conn.close()

    waitFor t()

  test "circle roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let v = PgCircle(center: PgPoint(x: 1.0, y: 2.0), radius: 5.0)
      let res = await conn.query("SELECT $1::circle", @[toPgParam(v)])
      doAssert res.rows.len == 1
      let got = res.rows[0].getCircle(0)
      doAssert got.center.x == 1.0
      doAssert got.center.y == 2.0
      doAssert got.radius == 5.0
      await conn.close()

    waitFor t()

  test "NULL geometric types":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res = await conn.query("SELECT NULL::point, NULL::line, NULL::circle")
      doAssert res.rows.len == 1
      doAssert res.rows[0].getPointOpt(0).isNone
      doAssert res.rows[0].getLineOpt(1).isNone
      doAssert res.rows[0].getCircleOpt(2).isNone
      await conn.close()

    waitFor t()

  test "geometric distance computation":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res = await conn.query("SELECT point '(1,2)' <-> point '(4,6)'")
      doAssert res.rows.len == 1
      let dist = parseFloat(res.rows[0].getStr(0))
      doAssert abs(dist - 5.0) < 1e-10
      await conn.close()

    waitFor t()

suite "E2E: Range Types":
  test "int4range roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let v = rangeOf(1'i32, 10'i32)
      let res = await conn.query("SELECT $1::int4range", @[toPgParam(v)])
      doAssert res.rows.len == 1
      let got = res.rows[0].getInt4Range(0)
      doAssert got.hasLower
      doAssert got.hasUpper
      doAssert got.lower.value == 1'i32
      doAssert got.lower.inclusive == true
      doAssert got.upper.value == 10'i32
      doAssert got.upper.inclusive == false
      await conn.close()

    waitFor t()

  test "int8range roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let v = rangeOf(100'i64, 999'i64)
      let res = await conn.query("SELECT $1::int8range", @[toPgParam(v)])
      doAssert res.rows.len == 1
      let got = res.rows[0].getInt8Range(0)
      doAssert got.lower.value == 100'i64
      doAssert got.upper.value == 999'i64
      await conn.close()

    waitFor t()

  test "numrange roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let v = rangeOf(parsePgNumeric("1.5"), parsePgNumeric("9.5"))
      let res = await conn.query("SELECT $1::numrange", @[toPgParam(v)])
      doAssert res.rows.len == 1
      let got = res.rows[0].getNumRange(0)
      doAssert $got.lower.value == "1.5"
      doAssert $got.upper.value == "9.5"
      await conn.close()

    waitFor t()

  test "daterange roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let lower = dateTime(2024, mJan, 1, zone = utc())
      let upper = dateTime(2024, mMar, 1, zone = utc())
      let v = rangeOf(lower, upper)
      let res = await conn.query("SELECT $1::daterange", @[toPgDateRangeParam(v)])
      doAssert res.rows.len == 1
      let got = res.rows[0].getDateRange(0)
      doAssert got.hasLower
      doAssert got.hasUpper
      doAssert got.lower.value.year == 2024
      doAssert got.lower.value.month == mJan
      doAssert got.lower.value.monthday == 1
      await conn.close()

    waitFor t()

  test "empty range":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let v = emptyRange[int32]()
      let res = await conn.query("SELECT $1::int4range", @[toPgParam(v)])
      doAssert res.rows.len == 1
      let got = res.rows[0].getInt4Range(0)
      doAssert got.isEmpty
      await conn.close()

    waitFor t()

  test "unbounded range":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let v = unboundedRange[int32]()
      let res = await conn.query("SELECT $1::int4range", @[toPgParam(v)])
      doAssert res.rows.len == 1
      let got = res.rows[0].getInt4Range(0)
      doAssert not got.isEmpty
      doAssert not got.hasLower
      doAssert not got.hasUpper
      await conn.close()

    waitFor t()

  test "half-bounded range rangeFrom":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let v = rangeFrom(5'i32)
      let res = await conn.query("SELECT $1::int4range", @[toPgParam(v)])
      doAssert res.rows.len == 1
      let got = res.rows[0].getInt4Range(0)
      doAssert got.hasLower
      doAssert not got.hasUpper
      doAssert got.lower.value == 5'i32
      doAssert got.lower.inclusive == true
      await conn.close()

    waitFor t()

  test "half-bounded range rangeTo":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let v = rangeTo(10'i32)
      let res = await conn.query("SELECT $1::int4range", @[toPgParam(v)])
      doAssert res.rows.len == 1
      let got = res.rows[0].getInt4Range(0)
      doAssert not got.hasLower
      doAssert got.hasUpper
      doAssert got.upper.value == 10'i32
      doAssert got.upper.inclusive == false
      await conn.close()

    waitFor t()

  test "inclusive upper bound normalizes for integers":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      # For integer ranges, PostgreSQL normalizes [1,10] to [1,11)
      let v = rangeOf(1'i32, 10'i32, upperInc = true)
      let res = await conn.query("SELECT $1::int4range", @[toPgParam(v)])
      doAssert res.rows.len == 1
      let got = res.rows[0].getInt4Range(0)
      doAssert got.lower.value == 1'i32
      doAssert got.lower.inclusive == true
      doAssert got.upper.value == 11'i32
      doAssert got.upper.inclusive == false
      await conn.close()

    waitFor t()

  test "NULL range":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res = await conn.query("SELECT NULL::int4range")
      doAssert res.rows.len == 1
      doAssert res.rows[0].getInt4RangeOpt(0).isNone
      await conn.close()

    waitFor t()

  test "range contains operator":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let v = rangeOf(1'i32, 10'i32)
      let res = await conn.query("SELECT $1::int4range @> 5::int4", @[toPgParam(v)])
      doAssert res.rows.len == 1
      doAssert res.rows[0].getBool(0) == true

      let res2 = await conn.query("SELECT $1::int4range @> 15::int4", @[toPgParam(v)])
      doAssert res2.rows[0].getBool(0) == false
      await conn.close()

    waitFor t()

suite "E2E: Multirange Types":
  test "int4multirange roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let v = toMultirange(rangeOf(1'i32, 3'i32), rangeOf(5'i32, 8'i32))
      let res = await conn.query("SELECT $1::int4multirange", @[toPgParam(v)])
      doAssert res.rows.len == 1
      let got = res.rows[0].getInt4Multirange(0)
      doAssert got.len == 2
      doAssert got[0].lower.value == 1'i32
      doAssert got[0].upper.value == 3'i32
      doAssert got[1].lower.value == 5'i32
      doAssert got[1].upper.value == 8'i32
      await conn.close()

    waitFor t()

  test "int8multirange roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let v = toMultirange(rangeOf(100'i64, 200'i64), rangeOf(300'i64, 400'i64))
      let res = await conn.query("SELECT $1::int8multirange", @[toPgParam(v)])
      doAssert res.rows.len == 1
      let got = res.rows[0].getInt8Multirange(0)
      doAssert got.len == 2
      doAssert got[0].lower.value == 100'i64
      doAssert got[1].upper.value == 400'i64
      await conn.close()

    waitFor t()

  test "empty multirange":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let v = toMultirange[int32]()
      let res = await conn.query("SELECT $1::int4multirange", @[toPgParam(v)])
      doAssert res.rows.len == 1
      let got = res.rows[0].getInt4Multirange(0)
      doAssert got.len == 0
      await conn.close()

    waitFor t()

  test "single range multirange":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let v = toMultirange(rangeOf(10'i32, 20'i32))
      let res = await conn.query("SELECT $1::int4multirange", @[toPgParam(v)])
      doAssert res.rows.len == 1
      let got = res.rows[0].getInt4Multirange(0)
      doAssert got.len == 1
      doAssert got[0].lower.value == 10'i32
      doAssert got[0].upper.value == 20'i32
      await conn.close()

    waitFor t()

  test "NULL multirange":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res = await conn.query("SELECT NULL::int4multirange")
      doAssert res.rows.len == 1
      doAssert res.rows[0].getInt4MultirangeOpt(0).isNone
      await conn.close()

    waitFor t()

suite "E2E: Temporal array types":
  test "timestamp array roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let dt1 = dateTime(2023, mJan, 15, 10, 30, 0, zone = utc())
      let dt2 = dateTime(2024, mJun, 20, 14, 45, 30, zone = utc())
      let res = await conn.query(
        "SELECT $1::timestamp[]", @[toPgTimestampArrayParam(@[dt1, dt2])]
      )
      doAssert res.rows.len == 1
      let arr = res.rows[0].getTimestampArray(0)
      doAssert arr.len == 2
      doAssert arr[0].year == 2023
      doAssert arr[1].year == 2024
      await conn.close()

    waitFor t()

  test "empty timestamp array":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res = await conn.query(
        "SELECT $1::timestamp[]", @[toPgTimestampArrayParam(newSeq[DateTime]())]
      )
      doAssert res.rows.len == 1
      doAssert res.rows[0].getTimestampArray(0).len == 0
      await conn.close()

    waitFor t()

  test "NULL timestamp array":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res = await conn.query("SELECT NULL::timestamp[]")
      doAssert res.rows.len == 1
      doAssert res.rows[0].getTimestampArrayOpt(0).isNone
      await conn.close()

    waitFor t()

  test "date array roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let dt1 = dateTime(2023, mMar, 10, zone = utc())
      let dt2 = dateTime(2024, mDec, 25, zone = utc())
      let res =
        await conn.query("SELECT $1::date[]", @[toPgDateArrayParam(@[dt1, dt2])])
      doAssert res.rows.len == 1
      let arr = res.rows[0].getDateArray(0)
      doAssert arr.len == 2
      doAssert arr[0].monthday == 10
      doAssert arr[1].month == mDec
      await conn.close()

    waitFor t()

  test "time array roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let t1 = PgTime(hour: 10, minute: 30, second: 0, microsecond: 0)
      let t2 = PgTime(hour: 23, minute: 59, second: 59, microsecond: 123456)
      let res = await conn.query("SELECT $1::time[]", @[toPgParam(@[t1, t2])])
      doAssert res.rows.len == 1
      let arr = res.rows[0].getTimeArray(0)
      doAssert arr.len == 2
      doAssert arr[0] == t1
      doAssert arr[1] == t2
      await conn.close()

    waitFor t()

  test "timetz array roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let t1 =
        PgTimeTz(hour: 10, minute: 30, second: 0, microsecond: 0, utcOffset: 3600)
      let t2 =
        PgTimeTz(hour: 23, minute: 59, second: 59, microsecond: 0, utcOffset: -18000)
      let res = await conn.query("SELECT $1::timetz[]", @[toPgParam(@[t1, t2])])
      doAssert res.rows.len == 1
      let arr = res.rows[0].getTimeTzArray(0)
      doAssert arr.len == 2
      doAssert arr[0] == t1
      doAssert arr[1] == t2
      await conn.close()

    waitFor t()

  test "interval array roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let iv1 = PgInterval(months: 2, days: 3, microseconds: 3600000000)
      let iv2 = PgInterval(months: 0, days: 0, microseconds: 1000000)
      let res = await conn.query("SELECT $1::interval[]", @[toPgParam(@[iv1, iv2])])
      doAssert res.rows.len == 1
      let arr = res.rows[0].getIntervalArray(0)
      doAssert arr.len == 2
      doAssert arr[0] == iv1
      doAssert arr[1] == iv2
      await conn.close()

    waitFor t()

suite "E2E: Identifier / network array types":
  test "uuid array roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let u1 = PgUuid("550e8400-e29b-41d4-a716-446655440000")
      let u2 = PgUuid("6ba7b810-9dad-11d1-80b4-00c04fd430c8")
      let res = await conn.query("SELECT $1::uuid[]", @[toPgParam(@[u1, u2])])
      doAssert res.rows.len == 1
      let arr = res.rows[0].getUuidArray(0)
      doAssert arr.len == 2
      doAssert arr[0] == u1
      doAssert arr[1] == u2
      await conn.close()

    waitFor t()

  test "inet array roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let i1 = PgInet(address: parseIpAddress("192.168.1.1"), mask: 32)
      let i2 = PgInet(address: parseIpAddress("10.0.0.0"), mask: 8)
      let res = await conn.query("SELECT $1::inet[]", @[toPgParam(@[i1, i2])])
      doAssert res.rows.len == 1
      let arr = res.rows[0].getInetArray(0)
      doAssert arr.len == 2
      doAssert $arr[0].address == "192.168.1.1"
      doAssert arr[1].mask == 8
      await conn.close()

    waitFor t()

  test "cidr array roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let c1 = PgCidr(address: parseIpAddress("192.168.1.0"), mask: 24)
      let c2 = PgCidr(address: parseIpAddress("10.0.0.0"), mask: 8)
      let res = await conn.query("SELECT $1::cidr[]", @[toPgParam(@[c1, c2])])
      doAssert res.rows.len == 1
      let arr = res.rows[0].getCidrArray(0)
      doAssert arr.len == 2
      doAssert arr[0].mask == 24
      doAssert arr[1].mask == 8
      await conn.close()

    waitFor t()

  test "macaddr array roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let m1 = PgMacAddr("08:00:2b:01:02:03")
      let m2 = PgMacAddr("aa:bb:cc:dd:ee:ff")
      let res = await conn.query("SELECT $1::macaddr[]", @[toPgParam(@[m1, m2])])
      doAssert res.rows.len == 1
      let arr = res.rows[0].getMacAddrArray(0)
      doAssert arr.len == 2
      doAssert arr[0] == m1
      doAssert arr[1] == m2
      await conn.close()

    waitFor t()

suite "E2E: Numeric / binary / JSON array types":
  test "numeric array roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let n1 = parsePgNumeric("123.45")
      let n2 = parsePgNumeric("0.001")
      let res = await conn.query("SELECT $1::numeric[]", @[toPgParam(@[n1, n2])])
      doAssert res.rows.len == 1
      let arr = res.rows[0].getNumericArray(0)
      doAssert arr.len == 2
      doAssert $arr[0] == "123.45"
      doAssert $arr[1] == "0.001"
      await conn.close()

    waitFor t()

  test "hstore array roundtrip (text cast)":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.simpleQuery("CREATE EXTENSION IF NOT EXISTS hstore;")
      var h1: PgHstore = initTable[string, Option[string]]()
      h1["a"] = some("1")
      var h2: PgHstore = initTable[string, Option[string]]()
      h2["b"] = none(string)
      let res = await conn.query("SELECT $1::hstore[]", @[toPgParam(@[h1, h2])])
      doAssert res.rows.len == 1
      let arr = res.rows[0].getHstoreArray(0)
      doAssert arr.len == 2
      doAssert arr[0] == h1
      doAssert arr[1] == h2
      await conn.close()

    waitFor t()

  test "hstore array roundtrip (binary)":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.simpleQuery("CREATE EXTENSION IF NOT EXISTS hstore;")
      doAssert conn.hstoreOid != 0
      doAssert conn.hstoreArrayOid != 0
      var h1: PgHstore = initTable[string, Option[string]]()
      h1["x"] = some("y")
      var h2: PgHstore = initTable[string, Option[string]]()
      h2["nul"] = none(string)
      let bin = toPgBinaryParam(@[h1, h2], conn.hstoreOid, conn.hstoreArrayOid)
      let res = await conn.query("SELECT $1", @[bin])
      doAssert res.rows.len == 1
      let arr = res.rows[0].getHstoreArray(0)
      doAssert arr.len == 2
      doAssert arr[0] == h1
      doAssert arr[1] == h2
      await conn.close()

    waitFor t()

  test "hstore array roundtrip (binary, conn overload)":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.simpleQuery("CREATE EXTENSION IF NOT EXISTS hstore;")
      var h1: PgHstore = initTable[string, Option[string]]()
      h1["k"] = some("v")
      let res = await conn.query("SELECT $1", @[conn.toPgBinaryParam(@[h1])])
      doAssert res.rows.len == 1
      let arr = res.rows[0].getHstoreArray(0)
      doAssert arr.len == 1
      doAssert arr[0] == h1
      await conn.close()

    waitFor t()

  test "bytea array roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let b1 = @[1'u8, 2, 3]
      let b2 = @[0xFF'u8, 0x00]
      let res =
        await conn.query("SELECT $1::bytea[]", @[toPgByteaArrayParam(@[b1, b2])])
      doAssert res.rows.len == 1
      let arr = res.rows[0].getBytesArray(0)
      doAssert arr.len == 2
      doAssert arr[0] == b1
      doAssert arr[1] == b2
      await conn.close()

    waitFor t()

  test "jsonb array roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let j1 = %*{"key": "value"}
      let j2 = %*[1, 2, 3]
      let res = await conn.query("SELECT $1::jsonb[]", @[toPgParam(@[j1, j2])])
      doAssert res.rows.len == 1
      let arr = res.rows[0].getJsonArray(0)
      doAssert arr.len == 2
      doAssert arr[0]["key"].getStr == "value"
      doAssert arr[1].len == 3
      await conn.close()

    waitFor t()

suite "E2E: Geometric array types":
  test "point array roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let p1 = PgPoint(x: 1.0, y: 2.0)
      let p2 = PgPoint(x: 3.5, y: 4.5)
      let res = await conn.query("SELECT $1::point[]", @[toPgParam(@[p1, p2])])
      doAssert res.rows.len == 1
      let arr = res.rows[0].getPointArray(0)
      doAssert arr.len == 2
      doAssert arr[0] == p1
      doAssert arr[1] == p2
      await conn.close()

    waitFor t()

  test "circle array roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let c1 = PgCircle(center: PgPoint(x: 1.0, y: 2.0), radius: 5.0)
      let res = await conn.query("SELECT $1::circle[]", @[toPgParam(@[c1])])
      doAssert res.rows.len == 1
      let arr = res.rows[0].getCircleArray(0)
      doAssert arr.len == 1
      doAssert arr[0].center.x == 1.0
      doAssert arr[0].radius == 5.0
      await conn.close()

    waitFor t()

  test "box array roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let b1 = PgBox(high: PgPoint(x: 3.0, y: 4.0), low: PgPoint(x: 1.0, y: 2.0))
      let res = await conn.query("SELECT $1::box[]", @[toPgParam(@[b1])])
      doAssert res.rows.len == 1
      let arr = res.rows[0].getBoxArray(0)
      doAssert arr.len == 1
      doAssert arr[0].high.x == 3.0
      await conn.close()

    waitFor t()

suite "E2E: Other array types":
  test "xml array roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let x1 = PgXml("<root/>")
      let x2 = PgXml("<data>hello</data>")
      let res = await conn.query("SELECT $1::xml[]", @[toPgParam(@[x1, x2])])
      doAssert res.rows.len == 1
      let arr = res.rows[0].getXmlArray(0)
      doAssert arr.len == 2
      doAssert string(arr[0]) == "<root/>"
      doAssert string(arr[1]) == "<data>hello</data>"
      await conn.close()

    waitFor t()

suite "E2E: Multirange array types":
  test "int4multirange array roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let mr1 = toMultirange(rangeOf(1'i32, 10'i32), rangeOf(20'i32, 30'i32))
      let mr2 = toMultirange(rangeOf(100'i32, 200'i32))
      let res =
        await conn.query("SELECT $1::int4multirange[]", @[toPgParam(@[mr1, mr2])])
      doAssert res.rows.len == 1
      let arr = res.rows[0].getInt4MultirangeArray(0)
      doAssert arr.len == 2
      doAssert seq[PgRange[int32]](arr[0]).len == 2
      doAssert seq[PgRange[int32]](arr[1]).len == 1
      doAssert seq[PgRange[int32]](arr[0])[0].lower.value == 1'i32
      await conn.close()

    waitFor t()

  test "int8multirange array roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let mr1 = toMultirange(rangeOf(100'i64, 200'i64))
      let res = await conn.query("SELECT $1::int8multirange[]", @[toPgParam(@[mr1])])
      doAssert res.rows.len == 1
      let arr = res.rows[0].getInt8MultirangeArray(0)
      doAssert arr.len == 1
      await conn.close()

    waitFor t()

  test "nummultirange array roundtrip":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let mr1 = toMultirange(rangeOf(parsePgNumeric("1.5"), parsePgNumeric("3.5")))
      let res = await conn.query("SELECT $1::nummultirange[]", @[toPgParam(@[mr1])])
      doAssert res.rows.len == 1
      let arr = res.rows[0].getNumMultirangeArray(0)
      doAssert arr.len == 1
      await conn.close()

    waitFor t()

  test "NULL multirange array":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res = await conn.query("SELECT NULL::int4multirange[]")
      doAssert res.rows.len == 1
      doAssert res.rows[0].getInt4MultirangeArrayOpt(0).isNone
      await conn.close()

    waitFor t()

suite "E2E: Option/NULL array input and element-level output":
  test "seq[Option[int32]] roundtrip with NULL element":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let arr = @[some(1'i32), none(int32), some(3'i32)]
      let res = await conn.query("SELECT $1::int4[] AS a", pgParams(arr))
      doAssert res.rows.len == 1
      doAssert res.rows[0].getIntArrayElemOpt(0) == arr
      await conn.close()

    waitFor t()

  test "seq[Option[string]] roundtrip with NULL element":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let arr = @[some("a"), none(string), some("c")]
      let res = await conn.query("SELECT $1::text[] AS a", pgParams(arr))
      doAssert res.rows.len == 1
      doAssert res.rows[0].getStrArrayElemOpt(0) == arr
      await conn.close()

    waitFor t()

  test "seq[Option[bool]] roundtrip with NULL element":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let arr = @[some(true), none(bool), some(false)]
      let res = await conn.query("SELECT $1::bool[] AS a", pgParams(arr))
      doAssert res.rows.len == 1
      doAssert res.rows[0].getBoolArrayElemOpt(0) == arr
      await conn.close()

    waitFor t()

  test "seq[Option[float64]] roundtrip with NULL element":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let arr = @[some(1.5), none(float64), some(3.25)]
      let res = await conn.query("SELECT $1::float8[] AS a", pgParams(arr))
      doAssert res.rows.len == 1
      let got = res.rows[0].getFloatArrayElemOpt(0)
      doAssert got.len == 3
      doAssert got[0].isSome and abs(got[0].get - 1.5) < 1e-10
      doAssert got[1].isNone
      doAssert got[2].isSome and abs(got[2].get - 3.25) < 1e-10
      await conn.close()

    waitFor t()

  test "all-NULL array roundtrips":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let arr = @[none(int32), none(int32)]
      let res = await conn.query("SELECT $1::int4[] AS a", pgParams(arr))
      doAssert res.rows.len == 1
      doAssert res.rows[0].getIntArrayElemOpt(0) == arr
      await conn.close()

    waitFor t()

  test "empty seq[Option[int32]] works":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let arr: seq[Option[int32]] = @[]
      let res = await conn.query("SELECT $1::int4[] AS a", pgParams(arr))
      doAssert res.rows.len == 1
      doAssert res.rows[0].getIntArrayElemOpt(0).len == 0
      await conn.close()

    waitFor t()

  test "literal ARRAY[1, NULL, 3] via getIntArrayElemOpt":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res = await conn.query("SELECT ARRAY[1, NULL, 3]::int4[] AS a")
      doAssert res.rows.len == 1
      doAssert res.rows[0].getIntArrayElemOpt(0) ==
        @[some(1'i32), none(int32), some(3'i32)]
      await conn.close()

    waitFor t()

  test "column NULL via getIntArrayElemOptOpt returns none":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      let res = await conn.query("SELECT NULL::int4[] AS a")
      doAssert res.rows.len == 1
      doAssert res.rows[0].getIntArrayElemOptOpt(0) == none(seq[Option[int32]])
      await conn.close()

    waitFor t()

type PgE2eMood = enum
  happy2 = "happy2"
  sad2 = "sad2"
  ok2 = "ok2"

pgEnum(PgE2eMood)

suite "E2E: enum arrays":
  test "enum array roundtrip with and without NULL":
    proc t() {.async.} =
      let conn = await connect(plainConfig())
      discard await conn.exec("DROP TYPE IF EXISTS e2e_mood CASCADE")
      discard await conn.exec("CREATE TYPE e2e_mood AS ENUM ('happy2', 'sad2', 'ok2')")
      block:
        let arr = @[happy2, sad2, ok2]
        let res = await conn.query("SELECT $1::e2e_mood[] AS a", @[toPgParam(arr)])
        doAssert res.rows.len == 1
        doAssert getEnumArray[PgE2eMood](res.rows[0], 0) == arr
      block:
        let arr = @[some(happy2), none(PgE2eMood), some(ok2)]
        let res = await conn.query("SELECT $1::e2e_mood[] AS a", @[toPgParam(arr)])
        doAssert res.rows.len == 1
        doAssert getEnumArrayElemOpt[PgE2eMood](res.rows[0], 0) == arr
      discard await conn.exec("DROP TYPE IF EXISTS e2e_mood CASCADE")
      await conn.close()

    waitFor t()

suite "E2E: queryRowOpt via pool":
  test "pool queryRowOpt returns first row and none on empty":
    proc t() {.async.} =
      let pool =
        await newPool(PoolConfig(connConfig: plainConfig(), minSize: 1, maxSize: 2))
      let row = await pool.queryRowOpt("SELECT 7 AS v")
      doAssert row.isSome
      doAssert row.get.getStr(0) == "7"
      let empty = await pool.queryRowOpt("SELECT 1 WHERE false")
      doAssert empty.isNone
      await pool.close()

    waitFor t()
