## Async PostgreSQL client for Nim.
##
## Implements the PostgreSQL wire protocol v3 with full support for the
## extended query protocol, connection pooling, SSL/TLS, and binary format
## optimization.
##
## Async Backend
## =============
## Select at compile time with ``-d:asyncBackend=asyncdispatch`` (default) or
## ``-d:asyncBackend=chronos``.
##
## Quick Start
## ===========
##
## .. code-block:: nim
##   import pkg/async_postgres
##
##   proc main() {.async.} =
##     let conn = await connect("postgresql://myuser:mypass@127.0.0.1:5432/mydb")
##     defer: await conn.close()
##
##     # Insert with typed parameters
##     let name = "Alice"
##     let age = 30'i32
##     let cr = await conn.exec(sql"INSERT INTO users (name, age) VALUES ({name}, {age})")
##     echo "Inserted: ", cr.affectedRows
##
##     # Query multiple rows
##     let minAge = 25'i32
##     let row = await conn.query(sql"SELECT id, name, age FROM users WHERE age > {minAge}")
##     for r in row:
##       echo r.getStr("name"), " age=", r.getInt("age")
##
##     # Query a single value
##     let count = await conn.queryValueOrDefault("SELECT count(*) FROM users", default = "0")
##     echo "Total users: ", count
##
##   waitFor main()
##
## Modules
## =======
## - `pg_connection <async_postgres/pg_connection.html>`_ — Connection management, DSN parsing, SSL, LISTEN/NOTIFY
## - `pg_client <async_postgres/pg_client.html>`_ — Query execution, prepared statements, cursors, pipelines, transactions, COPY, zero-alloc macros (``queryDirect``/``execDirect``)
## - `pg_pool <async_postgres/pg_pool.html>`_ — Connection pooling with health checks and maintenance
## - `pg_pool_cluster <async_postgres/pg_pool_cluster.html>`_ — Read replica pool cluster with automatic query routing
## - `pg_types <async_postgres/pg_types.html>`_ — Type conversions (``toPgParam``, row accessors, arrays, ranges, composites, enums)
## - `pg_protocol <async_postgres/pg_protocol.html>`_ — Wire protocol encoding/decoding
## - `pg_auth <async_postgres/pg_auth.html>`_ — MD5 and SCRAM-SHA-256 authentication
## - `pg_largeobject <async_postgres/pg_largeobject.html>`_ — Large Object API for streaming binary data
## - `async_backend <async_postgres/async_backend.html>`_ — Async framework abstraction (asyncdispatch / chronos)

import
  async_postgres/[
    async_backend, pg_protocol, pg_auth, pg_types, pg_connection, pg_client, pg_pool,
    pg_pool_cluster, pg_largeobject, pg_sql,
  ]

export
  async_backend, pg_protocol, pg_auth, pg_types, pg_connection, pg_client, pg_pool,
  pg_pool_cluster, pg_largeobject, pg_sql
