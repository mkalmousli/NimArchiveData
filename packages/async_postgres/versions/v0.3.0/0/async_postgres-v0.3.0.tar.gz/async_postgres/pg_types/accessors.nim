import std/[options, json, macros, parseutils, strutils, tables, times, net]

import ../pg_protocol
import core, decoding, encoding

proc cellInfo*(row: Row, col: int): tuple[off: int, len: int] {.inline.} =
  if col < 0 or col >= int(row.data.numCols):
    raise newException(
      IndexDefect, "column index " & $col & " out of range 0..<" & $row.data.numCols
    )
  let idx = (int(row.rowIdx) * int(row.data.numCols) + col) * 2
  result.off = int(row.data.cellIndex[idx])
  result.len = int(row.data.cellIndex[idx + 1])

template bufView*(row: Row, off, clen: int): openArray[char] =
  ## Zero-copy char view into row.data.buf for parseutils.
  cast[ptr UncheckedArray[char]](addr row.data.buf[off]).toOpenArray(0, clen - 1)

proc len*(row: Row): int {.inline.} =
  ## Return the number of columns in this row.
  int(row.data.numCols)

proc `[]`*(row: Row, col: int): Option[seq[byte]] =
  ## Backward-compatible cell access. Returns a copy of the cell data.
  let (off, clen) = cellInfo(row, col)
  if clen == -1:
    none(seq[byte])
  elif clen == 0:
    some(newSeq[byte](0))
  else:
    some(@(row.data.buf.toOpenArray(off, off + clen - 1)))

converter toRow*(cells: seq[Option[seq[byte]]]): Row =
  ## Backward-compatible converter: build a Row from ``seq[Option[seq[byte]]]``.
  let rd = RowData(
    numCols: int16(cells.len), buf: @[], cellIndex: newSeq[int32](cells.len * 2)
  )
  for i, cell in cells:
    if cell.isNone:
      rd.cellIndex[i * 2] = 0'i32
      rd.cellIndex[i * 2 + 1] = -1'i32
    else:
      let data = cell.get
      rd.cellIndex[i * 2] = int32(rd.buf.len)
      rd.cellIndex[i * 2 + 1] = int32(data.len)
      rd.buf.add(data)
  initRow(rd, 0)

proc parseAffectedRowsRaw*(tag: openArray[char]): int64 =
  ## Extract row count from the raw bytes of a command tag (e.g.
  ## "UPDATE 3" -> 3, "INSERT 0 1" -> 1). Unlike `parseAffectedRows(string)`
  ## this performs zero heap allocation — useful for pipelines that process
  ## many `CommandComplete` messages.
  ##
  ## Mirrors the legacy `split(' ')` semantics exactly: the last token (bytes
  ## after the final space) must parse as an integer; a trailing space or any
  ## non-numeric tail yields 0.
  if tag.len == 0:
    return 0
  var lo = tag.high
  while lo >= 0 and tag[lo] != ' ':
    dec lo
  inc lo
  if lo > tag.high:
    return 0
  var parsed: BiggestInt = 0
  try:
    let consumed = parseutils.parseBiggestInt(tag.toOpenArray(lo, tag.high), parsed)
    if consumed == 0 or consumed != tag.high - lo + 1:
      return 0
  except ValueError, OverflowDefect:
    return 0
  parsed

proc parseAffectedRows*(tag: string): int64 =
  ## Extract row count from command tag (e.g. "UPDATE 3" -> 3, "INSERT 0 1" -> 1).
  parseAffectedRowsRaw(tag.toOpenArray(0, tag.high))

proc initCommandResult*(tag: string): CommandResult {.inline.} =
  CommandResult(commandTag: tag)

proc affectedRows*(cr: CommandResult): int64 {.inline.} =
  ## Extract the number of affected rows from the command result.
  parseAffectedRows(cr.commandTag)

proc `$`*(cr: CommandResult): string {.inline.} =
  cr.commandTag

proc `==`*(cr: CommandResult, s: string): bool {.inline.} =
  cr.commandTag == s

proc contains*(cr: CommandResult, s: string): bool {.inline.} =
  ## Check if the command tag contains the given string.
  s in cr.commandTag

proc isNull*(row: Row, col: int): bool =
  ## Check if the column value is NULL.
  if col < 0 or col >= int(row.data.numCols):
    raise newException(
      IndexDefect, "column index " & $col & " out of range 0..<" & $row.data.numCols
    )
  let idx = (int(row.rowIdx) * int(row.data.numCols) + col) * 2
  row.data.cellIndex[idx + 1] == -1'i32

proc isBinaryCol*(row: Row, col: int): bool {.inline.} =
  ## Check if column was received in binary format.
  row.data.colFormats.len > col and row.data.colFormats[col] == 1'i16

proc colTypeOid*(row: Row, col: int): int32 {.inline.} =
  ## Get the type OID for a column, or 0 if not available.
  if row.data.colTypeOids.len > col:
    row.data.colTypeOids[col]
  else:
    0'i32

const NumericBinaryHeaderLen = 8
  ## Minimum byte length of a binary numeric value (4 x int16: ndigits, weight, sign, dscale).

template raiseIfBadNumericBinary(col, clen: int) =
  if clen < NumericBinaryHeaderLen:
    raise newException(
      PgTypeError,
      "Column " & $col & ": unexpected binary length " & $clen & " for numeric",
    )

proc getStr*(row: Row, col: int): string =
  ## Get a column value as a string. Handles binary-to-text conversion for
  ## common types (bool, int2/4/8, float4/8). Raises `PgTypeError` on NULL.
  let (off, clen) = cellInfo(row, col)
  if clen == -1:
    raise newException(PgTypeError, "Column " & $col & " is NULL")
  if row.isBinaryCol(col):
    let oid = row.colTypeOid(col)
    let b = row.data.buf
    case oid
    of 16: # bool
      if clen != 1:
        raise newException(
          PgTypeError,
          "Column " & $col & ": unexpected binary length " & $clen & " for bool",
        )
      return if b[off] != 0: "t" else: "f"
    of 21: # int2
      if clen != 2:
        raise newException(
          PgTypeError,
          "Column " & $col & ": unexpected binary length " & $clen & " for int2",
        )
      return $int16((uint16(b[off]) shl 8) or uint16(b[off + 1]))
    of 23: # int4
      if clen != 4:
        raise newException(
          PgTypeError,
          "Column " & $col & ": unexpected binary length " & $clen & " for int4",
        )
      return $int32(
        (uint32(b[off]) shl 24) or (uint32(b[off + 1]) shl 16) or
          (uint32(b[off + 2]) shl 8) or uint32(b[off + 3])
      )
    of 20: # int8
      if clen != 8:
        raise newException(
          PgTypeError,
          "Column " & $col & ": unexpected binary length " & $clen & " for int8",
        )
      return $int64(
        (uint64(b[off]) shl 56) or (uint64(b[off + 1]) shl 48) or
          (uint64(b[off + 2]) shl 40) or (uint64(b[off + 3]) shl 32) or
          (uint64(b[off + 4]) shl 24) or (uint64(b[off + 5]) shl 16) or
          (uint64(b[off + 6]) shl 8) or uint64(b[off + 7])
      )
    of 700: # float4
      if clen != 4:
        raise newException(
          PgTypeError,
          "Column " & $col & ": unexpected binary length " & $clen & " for float4",
        )
      let bits = uint32(
        (uint32(b[off]) shl 24) or (uint32(b[off + 1]) shl 16) or
          (uint32(b[off + 2]) shl 8) or uint32(b[off + 3])
      )
      return $cast[float32](bits)
    of 701: # float8
      if clen != 8:
        raise newException(
          PgTypeError,
          "Column " & $col & ": unexpected binary length " & $clen & " for float8",
        )
      let bits = uint64(
        (uint64(b[off]) shl 56) or (uint64(b[off + 1]) shl 48) or
          (uint64(b[off + 2]) shl 40) or (uint64(b[off + 3]) shl 32) or
          (uint64(b[off + 4]) shl 24) or (uint64(b[off + 5]) shl 16) or
          (uint64(b[off + 6]) shl 8) or uint64(b[off + 7])
      )
      return $cast[float64](bits)
    of OidNumeric:
      raiseIfBadNumericBinary(col, clen)
      return $decodeNumericBinary(b.toOpenArray(off, off + clen - 1))
    else:
      discard # text, varchar, bytea: fall through to raw copy
  result = readString(row.data.buf, off, clen)

proc getInt*(row: Row, col: int): int32 =
  ## Get a column value as int32. Handles binary int2/int4 directly. Raises `PgTypeError` on NULL.
  let (off, clen) = cellInfo(row, col)
  if clen == -1:
    raise newException(PgTypeError, "Column " & $col & " is NULL")
  if row.isBinaryCol(col):
    if clen == 4:
      let b = row.data.buf
      return int32(
        (uint32(b[off]) shl 24) or (uint32(b[off + 1]) shl 16) or
          (uint32(b[off + 2]) shl 8) or uint32(b[off + 3])
      )
    elif clen == 2:
      let b = row.data.buf
      return int32(int16((uint16(b[off]) shl 8) or uint16(b[off + 1])))
    else:
      raise newException(
        PgTypeError,
        "Column " & $col & ": unexpected binary length " & $clen & " for int32",
      )
  var v: int
  if parseInt(row.bufView(off, clen), v) == 0:
    raise newException(PgTypeError, "Column " & $col & ": invalid integer value")
  result = int32(v)

proc getInt16*(row: Row, col: int): int16 =
  ## Get a column value as int16. Handles binary int2 directly. Raises `PgTypeError` on NULL.
  let (off, clen) = cellInfo(row, col)
  if clen == -1:
    raise newException(PgTypeError, "Column " & $col & " is NULL")
  if row.isBinaryCol(col):
    if clen == 2:
      let b = row.data.buf
      return int16((uint16(b[off]) shl 8) or uint16(b[off + 1]))
    else:
      raise newException(
        PgTypeError,
        "Column " & $col & ": unexpected binary length " & $clen & " for int16",
      )
  var v: int
  if parseInt(row.bufView(off, clen), v) == 0:
    raise newException(PgTypeError, "Column " & $col & ": invalid int16 value")
  result = int16(v)

proc getInt64*(row: Row, col: int): int64 =
  ## Get a column value as int64. Handles binary int2/4/8 directly. Raises `PgTypeError` on NULL.
  let (off, clen) = cellInfo(row, col)
  if clen == -1:
    raise newException(PgTypeError, "Column " & $col & " is NULL")
  if row.isBinaryCol(col):
    if clen == 8:
      let b = row.data.buf
      return int64(
        (uint64(b[off]) shl 56) or (uint64(b[off + 1]) shl 48) or
          (uint64(b[off + 2]) shl 40) or (uint64(b[off + 3]) shl 32) or
          (uint64(b[off + 4]) shl 24) or (uint64(b[off + 5]) shl 16) or
          (uint64(b[off + 6]) shl 8) or uint64(b[off + 7])
      )
    elif clen == 4:
      let b = row.data.buf
      return int64(
        int32(
          (uint32(b[off]) shl 24) or (uint32(b[off + 1]) shl 16) or
            (uint32(b[off + 2]) shl 8) or uint32(b[off + 3])
        )
      )
    elif clen == 2:
      let b = row.data.buf
      return int64(int16((uint16(b[off]) shl 8) or uint16(b[off + 1])))
    else:
      raise newException(
        PgTypeError,
        "Column " & $col & ": unexpected binary length " & $clen & " for int64",
      )
  var v: BiggestInt
  if parseBiggestInt(row.bufView(off, clen), v) == 0:
    raise newException(PgTypeError, "Column " & $col & ": invalid int64 value")
  result = v

proc getFloat*(row: Row, col: int): float64 =
  ## Get a column value as float64. Handles binary float4/8 directly. Raises `PgTypeError` on NULL.
  let (off, clen) = cellInfo(row, col)
  if clen == -1:
    raise newException(PgTypeError, "Column " & $col & " is NULL")
  if row.isBinaryCol(col):
    if clen == 8:
      let b = row.data.buf
      let bits =
        (uint64(b[off]) shl 56) or (uint64(b[off + 1]) shl 48) or
        (uint64(b[off + 2]) shl 40) or (uint64(b[off + 3]) shl 32) or
        (uint64(b[off + 4]) shl 24) or (uint64(b[off + 5]) shl 16) or
        (uint64(b[off + 6]) shl 8) or uint64(b[off + 7])
      return cast[float64](bits)
    elif clen == 4:
      let b = row.data.buf
      let bits =
        (uint32(b[off]) shl 24) or (uint32(b[off + 1]) shl 16) or
        (uint32(b[off + 2]) shl 8) or uint32(b[off + 3])
      return float64(cast[float32](bits))
    else:
      raise newException(
        PgTypeError,
        "Column " & $col & ": unexpected binary length " & $clen & " for float64",
      )
  if parseFloat(row.bufView(off, clen), result) == 0:
    raise newException(PgTypeError, "Column " & $col & ": invalid float value")

proc getFloat32*(row: Row, col: int): float32 =
  ## Get a column value as float32. Handles binary float4 directly. Raises `PgTypeError` on NULL.
  let (off, clen) = cellInfo(row, col)
  if clen == -1:
    raise newException(PgTypeError, "Column " & $col & " is NULL")
  if row.isBinaryCol(col):
    if clen == 4:
      let b = row.data.buf
      let bits =
        (uint32(b[off]) shl 24) or (uint32(b[off + 1]) shl 16) or
        (uint32(b[off + 2]) shl 8) or uint32(b[off + 3])
      return cast[float32](bits)
    else:
      raise newException(
        PgTypeError,
        "Column " & $col & ": unexpected binary length " & $clen & " for float32",
      )
  var f: float64
  if parseFloat(row.bufView(off, clen), f) == 0:
    raise newException(PgTypeError, "Column " & $col & ": invalid float32 value")
  result = float32(f)

proc getNumeric*(row: Row, col: int): PgNumeric =
  ## Get a column value as PgNumeric. Handles binary numeric format.
  if row.isBinaryCol(col):
    let (off, clen) = cellInfo(row, col)
    if clen == -1:
      raise newException(PgTypeError, "Column " & $col & " is NULL")
    raiseIfBadNumericBinary(col, clen)
    return decodeNumericBinary(row.data.buf.toOpenArray(off, off + clen - 1))
  parsePgNumeric(row.getStr(col))

proc getMoney*(row: Row, col: int, scale: int = 2): PgMoney =
  ## Get a column value as PgMoney. Handles binary money (8-byte int64) and
  ## locale-formatted text (see ``parsePgMoney`` for accepted forms).
  ## ``scale`` is the server's ``frac_digits`` (default 2 for ``C`` /
  ## ``en_US``; pass 0 for ``ja_JP`` etc.). The wire protocol does not expose
  ## this, so callers must specify it when it differs from the default.
  ## Raises ``PgTypeError`` on NULL or when ``scale`` is outside ``0..18``.
  if scale < 0 or scale > 18:
    raise newException(PgTypeError, "PgMoney scale out of range: " & $scale)
  let (off, clen) = cellInfo(row, col)
  if clen == -1:
    raise newException(PgTypeError, "Column " & $col & " is NULL")
  if row.isBinaryCol(col):
    if clen == 8:
      return PgMoney(
        amount: fromBE64(row.data.buf.toOpenArray(off, off + 7)), scale: int8(scale)
      )
    raise newException(
      PgTypeError,
      "Column " & $col & ": unexpected binary length " & $clen & " for money",
    )
  parsePgMoney(row.getStr(col), scale)

proc getUuid*(row: Row, col: int): PgUuid =
  ## Get a column value as PgUuid. Handles binary format (16 bytes).
  if row.isBinaryCol(col):
    let (off, clen) = cellInfo(row, col)
    if clen == -1:
      raise newException(PgTypeError, "Column " & $col & " is NULL")
    if clen != 16:
      raise newException(
        PgTypeError,
        "Column " & $col & ": unexpected binary length " & $clen & " for uuid",
      )
    const hexChars = "0123456789abcdef"
    var s = newString(36)
    var pos = 0
    for i in 0 ..< 16:
      if i == 4 or i == 6 or i == 8 or i == 10:
        s[pos] = '-'
        inc pos
      let b = row.data.buf[off + i]
      s[pos] = hexChars[int(b shr 4)]
      s[pos + 1] = hexChars[int(b and 0x0F)]
      pos += 2
    return PgUuid(s)
  PgUuid(row.getStr(col))

proc getBool*(row: Row, col: int): bool =
  ## Get a column value as bool. Handles binary format directly. Raises `PgTypeError` on NULL.
  let (off, clen) = cellInfo(row, col)
  if clen == -1:
    raise newException(PgTypeError, "Column " & $col & " is NULL")
  if row.isBinaryCol(col):
    if clen != 1:
      raise newException(
        PgTypeError,
        "Column " & $col & ": unexpected binary length " & $clen & " for bool",
      )
    return row.data.buf[off] != 0
  let c = char(row.data.buf[off])
  case c
  of 't', '1':
    true
  of 'f', '0':
    false
  else:
    raise newException(PgTypeError, "Invalid boolean value: " & c)

proc getBytes*(row: Row, col: int): seq[byte] =
  ## Get a column value as raw bytes. Decodes hex-encoded bytea in text format.
  ## Raises `PgTypeError` on NULL.
  let (off, clen) = cellInfo(row, col)
  if clen == -1:
    raise newException(PgTypeError, "Column " & $col & " is NULL")
  if row.isBinaryCol(col):
    # Binary format: raw bytes, no hex encoding
    result = readBytes(row.data.buf, off, clen)
    return
  # Text format: bytea uses hex encoding \xDEADBEEF
  if clen >= 2 and row.data.buf[off] == byte('\\') and row.data.buf[off + 1] == byte(
    'x'
  ):
    let hexLen = clen - 2
    var hex = newString(hexLen)
    for i in 0 ..< hexLen:
      hex[i] = char(row.data.buf[off + 2 + i])
    result = newSeq[byte](hexLen div 2)
    for i in 0 ..< result.len:
      result[i] = byte(parseHexInt(hex[i * 2 .. i * 2 + 1]))
  else:
    result = readBytes(row.data.buf, off, clen)

proc getTimestamp*(row: Row, col: int): DateTime =
  ## Get a column value as DateTime. Handles binary timestamp format.
  if row.isBinaryCol(col):
    let (off, clen) = cellInfo(row, col)
    if clen == -1:
      raise newException(PgTypeError, "Column " & $col & " is NULL")
    if clen != 8:
      raise newException(
        PgTypeError,
        "Column " & $col & ": unexpected binary length " & $clen & " for timestamp",
      )
    return decodeBinaryTimestamp(row.data.buf.toOpenArray(off, off + 7))
  let s = row.getStr(col)
  return parseTimestampText(s)

proc getDate*(row: Row, col: int): DateTime =
  ## Get a column value as DateTime. Handles binary date format.
  if row.isBinaryCol(col):
    let (off, clen) = cellInfo(row, col)
    if clen == -1:
      raise newException(PgTypeError, "Column " & $col & " is NULL")
    if clen != 4:
      raise newException(
        PgTypeError,
        "Column " & $col & ": unexpected binary length " & $clen & " for date",
      )
    return decodeBinaryDate(row.data.buf.toOpenArray(off, off + 3))
  let s = row.getStr(col)
  try:
    return parse(s, "yyyy-MM-dd")
  except TimeParseError:
    raise newException(PgTypeError, "Invalid date: " & s)

proc getTimestampTz*(row: Row, col: int): DateTime =
  ## Get a column value as DateTime from a timestamptz column.
  if row.isBinaryCol(col):
    let (off, clen) = cellInfo(row, col)
    if clen == -1:
      raise newException(PgTypeError, "Column " & $col & " is NULL")
    if clen != 8:
      raise newException(
        PgTypeError,
        "Column " & $col & ": unexpected binary length " & $clen & " for timestamptz",
      )
    return decodeBinaryTimestamp(row.data.buf.toOpenArray(off, off + 7))
  let s = row.getStr(col)
  return parseTimestampText(s)

proc getTime*(row: Row, col: int): PgTime =
  ## Get a column value as PgTime. Handles binary time format.
  if row.isBinaryCol(col):
    let (off, clen) = cellInfo(row, col)
    if clen == -1:
      raise newException(PgTypeError, "Column " & $col & " is NULL")
    if clen != 8:
      raise newException(
        PgTypeError,
        "Column " & $col & ": unexpected binary length " & $clen & " for time",
      )
    return decodeBinaryTime(row.data.buf.toOpenArray(off, off + 7))
  let s = row.getStr(col)
  return parseTimeText(s)

proc getTimeTz*(row: Row, col: int): PgTimeTz =
  ## Get a column value as PgTimeTz. Handles binary timetz format.
  if row.isBinaryCol(col):
    let (off, clen) = cellInfo(row, col)
    if clen == -1:
      raise newException(PgTypeError, "Column " & $col & " is NULL")
    if clen != 12:
      raise newException(
        PgTypeError,
        "Column " & $col & ": unexpected binary length " & $clen & " for timetz",
      )
    return decodeBinaryTimeTz(row.data.buf.toOpenArray(off, off + 11))
  let s = row.getStr(col)
  return parseTimeTzText(s)

proc getJson*(row: Row, col: int): JsonNode =
  ## Get a column value as a parsed JsonNode. Handles binary json/jsonb format.
  if row.isBinaryCol(col):
    let (off, clen) = cellInfo(row, col)
    if clen == -1:
      raise newException(PgTypeError, "Column " & $col & " is NULL")
    var jsonStr: string
    if row.colTypeOid(col) == OidJsonb and clen > 0 and row.data.buf[off] == 1:
      # jsonb binary: skip version byte
      jsonStr = newString(clen - 1)
      for i in 1 ..< clen:
        jsonStr[i - 1] = char(row.data.buf[off + i])
    else:
      jsonStr = newString(clen)
      for i in 0 ..< clen:
        jsonStr[i] = char(row.data.buf[off + i])
    try:
      return parseJson(jsonStr)
    except JsonParsingError:
      raise newException(PgTypeError, "Invalid JSON: " & jsonStr)
  let s = row.getStr(col)
  try:
    return parseJson(s)
  except JsonParsingError:
    raise newException(PgTypeError, "Invalid JSON: " & s)

proc getInterval*(row: Row, col: int): PgInterval =
  ## Get a column value as PgInterval. Handles binary interval format.
  if row.isBinaryCol(col):
    let (off, clen) = cellInfo(row, col)
    if clen == -1:
      raise newException(PgTypeError, "Column " & $col & " is NULL")
    if clen != 16:
      raise newException(PgTypeError, "Invalid binary interval length: " & $clen)
    result.microseconds = fromBE64(row.data.buf.toOpenArray(off, off + 7))
    result.days = fromBE32(row.data.buf.toOpenArray(off + 8, off + 11))
    result.months = fromBE32(row.data.buf.toOpenArray(off + 12, off + 15))
    return
  let s = row.getStr(col)
  parseIntervalText(s)

proc getInet*(row: Row, col: int): PgInet =
  ## Get a column value as PgInet (IP address with mask). Handles binary format.
  if row.isBinaryCol(col):
    let (off, clen) = cellInfo(row, col)
    if clen == -1:
      raise newException(PgTypeError, "Column " & $col & " is NULL")
    let (ip, mask) = decodeInetBinary(row.data.buf.toOpenArray(off, off + clen - 1))
    return PgInet(address: ip, mask: mask)
  let s = row.getStr(col)
  let (ip, mask) = parseInetText(s)
  PgInet(address: ip, mask: mask)

proc getCidr*(row: Row, col: int): PgCidr =
  ## Get a column value as PgCidr (CIDR network address). Handles binary format.
  if row.isBinaryCol(col):
    let (off, clen) = cellInfo(row, col)
    if clen == -1:
      raise newException(PgTypeError, "Column " & $col & " is NULL")
    let (ip, mask) = decodeInetBinary(row.data.buf.toOpenArray(off, off + clen - 1))
    return PgCidr(address: ip, mask: mask)
  let s = row.getStr(col)
  let (ip, mask) = parseInetText(s)
  PgCidr(address: ip, mask: mask)

proc getMacAddr*(row: Row, col: int): PgMacAddr =
  ## Get a column value as PgMacAddr. Handles binary format.
  if row.isBinaryCol(col):
    let (off, clen) = cellInfo(row, col)
    if clen == -1:
      raise newException(PgTypeError, "Column " & $col & " is NULL")
    if clen != 6:
      raise newException(PgTypeError, "Invalid binary macaddr length: " & $clen)
    var parts = newSeq[string](6)
    for i in 0 ..< 6:
      parts[i] = toHex(row.data.buf[off + i], 2).toLowerAscii()
    return PgMacAddr(parts.join(":"))
  PgMacAddr(row.getStr(col))

proc getMacAddr8*(row: Row, col: int): PgMacAddr8 =
  ## Get a column value as PgMacAddr8 (EUI-64). Handles binary format.
  if row.isBinaryCol(col):
    let (off, clen) = cellInfo(row, col)
    if clen == -1:
      raise newException(PgTypeError, "Column " & $col & " is NULL")
    if clen != 8:
      raise newException(PgTypeError, "Invalid binary macaddr8 length: " & $clen)
    var parts = newSeq[string](8)
    for i in 0 ..< 8:
      parts[i] = toHex(row.data.buf[off + i], 2).toLowerAscii()
    return PgMacAddr8(parts.join(":"))
  PgMacAddr8(row.getStr(col))

proc getBit*(row: Row, col: int): PgBit =
  ## Get a column value as PgBit. Handles both text and binary format.
  if row.isBinaryCol(col):
    let (off, clen) = cellInfo(row, col)
    if clen == -1:
      raise newException(PgTypeError, "Column " & $col & " is NULL")
    if clen < 4:
      raise newException(PgTypeError, "Invalid binary bit data: too short")
    let nbits = fromBE32(row.data.buf.toOpenArray(off, off + 3))
    if nbits < 0:
      raise
        newException(PgTypeError, "Invalid binary bit data: negative nbits " & $nbits)
    if nbits > PgBitMaxBits:
      raise newException(
        PgTypeError,
        "Invalid binary bit data: nbits " & $nbits & " exceeds limit (" & $PgBitMaxBits &
          ")",
      )
    let dataLen = clen - 4
    if (int64(nbits) + 7) div 8 != int64(dataLen):
      raise newException(
        PgTypeError,
        "Invalid binary bit data: nbits=" & $nbits & " inconsistent with dataLen=" &
          $dataLen,
      )
    var data = newSeq[byte](dataLen)
    for i in 0 ..< dataLen:
      data[i] = row.data.buf[off + 4 + i]
    return PgBit(nbits: nbits, data: data)
  parseBitString(row.getStr(col))

proc getTsVector*(row: Row, col: int): PgTsVector =
  ## Get a column value as PgTsVector. Handles both text and binary format.
  if row.isBinaryCol(col):
    let (off, clen) = cellInfo(row, col)
    if clen == -1:
      raise newException(PgTypeError, "Column " & $col & " is NULL")
    return
      PgTsVector(decodeBinaryTsVector(row.data.buf.toOpenArray(off, off + clen - 1)))
  PgTsVector(row.getStr(col))

proc getTsQuery*(row: Row, col: int): PgTsQuery =
  ## Get a column value as PgTsQuery. Handles both text and binary format.
  if row.isBinaryCol(col):
    let (off, clen) = cellInfo(row, col)
    if clen == -1:
      raise newException(PgTypeError, "Column " & $col & " is NULL")
    return PgTsQuery(decodeBinaryTsQuery(row.data.buf.toOpenArray(off, off + clen - 1)))
  PgTsQuery(row.getStr(col))

proc getXml*(row: Row, col: int): PgXml =
  ## Get a column value as PgXml. Handles both text and binary format.
  if row.isBinaryCol(col):
    let (off, clen) = cellInfo(row, col)
    if clen == -1:
      raise newException(PgTypeError, "Column " & $col & " is NULL")
    var s = newString(clen)
    for i in 0 ..< clen:
      s[i] = char(row.data.buf[off + i])
    return PgXml(s)
  PgXml(row.getStr(col))

proc getHstore*(row: Row, col: int): PgHstore =
  ## Get a column value as PgHstore. Handles both text and binary format.
  if row.isBinaryCol(col):
    let (off, clen) = cellInfo(row, col)
    if clen == -1:
      raise newException(PgTypeError, "Column " & $col & " is NULL")
    return decodeHstoreBinary(row.data.buf.toOpenArray(off, off + clen - 1))
  parseHstoreText(row.getStr(col))

proc getPoint*(row: Row, col: int): PgPoint =
  ## Get a column value as PgPoint. Handles binary format.
  if row.isBinaryCol(col):
    let (off, clen) = cellInfo(row, col)
    if clen == -1:
      raise newException(PgTypeError, "Column " & $col & " is NULL")
    if clen != 16:
      raise newException(PgTypeError, "Invalid binary point length: " & $clen)
    return decodePointBinary(row.data.buf, off)
  parsePointText(row.getStr(col))

proc getLine*(row: Row, col: int): PgLine =
  ## Get a column value as PgLine. Handles binary format.
  if row.isBinaryCol(col):
    let (off, clen) = cellInfo(row, col)
    if clen == -1:
      raise newException(PgTypeError, "Column " & $col & " is NULL")
    if clen != 24:
      raise newException(PgTypeError, "Invalid binary line length: " & $clen)
    result.a = decodeFloat64BE(row.data.buf, off)
    result.b = decodeFloat64BE(row.data.buf, off + 8)
    result.c = decodeFloat64BE(row.data.buf, off + 16)
    return
  let s = row.getStr(col)
  var inner = s.strip()
  if inner.len >= 2 and inner[0] == '{' and inner[^1] == '}':
    inner = inner[1 ..^ 2]
  else:
    raise newException(PgTypeError, "Invalid line: " & s)
  let parts = inner.split(',')
  if parts.len != 3:
    raise newException(PgTypeError, "Invalid line: " & s)
  PgLine(a: parseFloat(parts[0]), b: parseFloat(parts[1]), c: parseFloat(parts[2]))

proc getLseg*(row: Row, col: int): PgLseg =
  ## Get a column value as PgLseg. Handles binary format.
  if row.isBinaryCol(col):
    let (off, clen) = cellInfo(row, col)
    if clen == -1:
      raise newException(PgTypeError, "Column " & $col & " is NULL")
    if clen != 32:
      raise newException(PgTypeError, "Invalid binary lseg length: " & $clen)
    return PgLseg(
      p1: decodePointBinary(row.data.buf, off),
      p2: decodePointBinary(row.data.buf, off + 16),
    )
  let s = row.getStr(col).strip()
  var inner = s
  if inner.len >= 2 and inner[0] == '[' and inner[^1] == ']':
    inner = inner[1 ..^ 2]
  let points = parsePointsText(inner)
  if points.len != 2:
    raise newException(PgTypeError, "Invalid lseg: " & s)
  PgLseg(p1: points[0], p2: points[1])

proc getBox*(row: Row, col: int): PgBox =
  ## Get a column value as PgBox. Handles binary format.
  if row.isBinaryCol(col):
    let (off, clen) = cellInfo(row, col)
    if clen == -1:
      raise newException(PgTypeError, "Column " & $col & " is NULL")
    if clen != 32:
      raise newException(PgTypeError, "Invalid binary box length: " & $clen)
    return PgBox(
      high: decodePointBinary(row.data.buf, off),
      low: decodePointBinary(row.data.buf, off + 16),
    )
  let s = row.getStr(col).strip()
  let points = parsePointsText(s)
  if points.len != 2:
    raise newException(PgTypeError, "Invalid box: " & s)
  PgBox(high: points[0], low: points[1])

proc getPath*(row: Row, col: int): PgPath =
  ## Get a column value as PgPath. Handles binary format.
  if row.isBinaryCol(col):
    let (off, clen) = cellInfo(row, col)
    if clen == -1:
      raise newException(PgTypeError, "Column " & $col & " is NULL")
    if clen < 5:
      raise newException(
        PgTypeError,
        "Column " & $col & ": binary path header too short (" & $clen & " bytes)",
      )
    let b = row.data.buf
    result.closed = b[off] != 0
    let npts = fromBE32(b.toOpenArray(off + 1, off + 4))
    if npts < 0:
      raise newException(
        PgTypeError,
        "Column " & $col & ": binary path has negative point count " & $npts,
      )
    if npts > (clen - 5) div 16:
      raise newException(
        PgTypeError,
        "Column " & $col & ": binary path " & $npts & " points exceed " & $clen &
          "-byte cell",
      )
    result.points = newSeq[PgPoint](npts)
    for i in 0 ..< npts:
      result.points[i] = decodePointBinary(b, off + 5 + i * 16)
    return
  let s = row.getStr(col).strip()
  if s.len < 2:
    raise newException(PgTypeError, "Invalid path: " & s)
  let closed = s[0] == '('
  let inner = s[1 ..^ 2]
  let points = parsePointsText(inner)
  PgPath(closed: closed, points: points)

proc getPolygon*(row: Row, col: int): PgPolygon =
  ## Get a column value as PgPolygon. Handles binary format.
  if row.isBinaryCol(col):
    let (off, clen) = cellInfo(row, col)
    if clen == -1:
      raise newException(PgTypeError, "Column " & $col & " is NULL")
    if clen < 4:
      raise newException(
        PgTypeError,
        "Column " & $col & ": binary polygon header too short (" & $clen & " bytes)",
      )
    let b = row.data.buf
    let npts = fromBE32(b.toOpenArray(off, off + 3))
    if npts < 0:
      raise newException(
        PgTypeError,
        "Column " & $col & ": binary polygon has negative point count " & $npts,
      )
    if npts > (clen - 4) div 16:
      raise newException(
        PgTypeError,
        "Column " & $col & ": binary polygon " & $npts & " points exceed " & $clen &
          "-byte cell",
      )
    result.points = newSeq[PgPoint](npts)
    for i in 0 ..< npts:
      result.points[i] = decodePointBinary(b, off + 4 + i * 16)
    return
  let s = row.getStr(col).strip()
  if s.len < 2 or s[0] != '(' or s[^1] != ')':
    raise newException(PgTypeError, "Invalid polygon: " & s)
  let inner = s[1 ..^ 2]
  PgPolygon(points: parsePointsText(inner))

proc getCircle*(row: Row, col: int): PgCircle =
  ## Get a column value as PgCircle. Handles binary format.
  if row.isBinaryCol(col):
    let (off, clen) = cellInfo(row, col)
    if clen == -1:
      raise newException(PgTypeError, "Column " & $col & " is NULL")
    if clen != 24:
      raise newException(PgTypeError, "Invalid binary circle length: " & $clen)
    result.center = decodePointBinary(row.data.buf, off)
    result.radius = decodeFloat64BE(row.data.buf, off + 16)
    return
  let s = row.getStr(col).strip()
  if s.len < 2 or s[0] != '<' or s[^1] != '>':
    raise newException(PgTypeError, "Invalid circle: " & s)
  let inner = s[1 ..^ 2]
  # Find the last comma that's outside parens
  var depth = 0
  var lastComma = -1
  for i in 0 ..< inner.len:
    if inner[i] == '(':
      depth += 1
    elif inner[i] == ')':
      depth -= 1
    elif inner[i] == ',' and depth == 0:
      lastComma = i
  if lastComma < 0:
    raise newException(PgTypeError, "Invalid circle: " & s)
  let center = parsePointText(inner[0 ..< lastComma])
  let radius = parseFloat(inner[lastComma + 1 ..^ 1])
  PgCircle(center: center, radius: radius)

# NULL-safe Option accessors — return `none` for NULL instead of raising.

template optAccessor*(getProc, optProc: untyped, T: typedesc) =
  ## Generate ``optProc*(row, col): Option[T]`` that delegates to ``getProc``.
  proc optProc*(row: Row, col: int): Option[T] =
    if row.isNull(col):
      none(T)
    else:
      some(row.getProc(col))

template nameAccessor*(getProc: untyped, T: typedesc) =
  ## Generate ``getProc*(row, name): T`` that delegates to the index-based overload.
  proc getProc*(row: Row, name: string): T =
    row.getProc(row.columnIndex(name))

optAccessor(getStr, getStrOpt, string)
optAccessor(getInt, getIntOpt, int32)
optAccessor(getInt16, getInt16Opt, int16)
optAccessor(getInt64, getInt64Opt, int64)
optAccessor(getFloat, getFloatOpt, float64)
optAccessor(getFloat32, getFloat32Opt, float32)
optAccessor(getNumeric, getNumericOpt, PgNumeric)
optAccessor(getMoney, getMoneyOpt, PgMoney)
optAccessor(getUuid, getUuidOpt, PgUuid)
optAccessor(getBool, getBoolOpt, bool)
optAccessor(getBytes, getBytesOpt, seq[byte])
optAccessor(getJson, getJsonOpt, JsonNode)
optAccessor(getTimestamp, getTimestampOpt, DateTime)
optAccessor(getDate, getDateOpt, DateTime)
optAccessor(getTime, getTimeOpt, PgTime)
optAccessor(getTimeTz, getTimeTzOpt, PgTimeTz)
optAccessor(getTimestampTz, getTimestampTzOpt, DateTime)
optAccessor(getInterval, getIntervalOpt, PgInterval)
optAccessor(getInet, getInetOpt, PgInet)
optAccessor(getCidr, getCidrOpt, PgCidr)
optAccessor(getMacAddr, getMacAddrOpt, PgMacAddr)
optAccessor(getMacAddr8, getMacAddr8Opt, PgMacAddr8)
optAccessor(getTsVector, getTsVectorOpt, PgTsVector)
optAccessor(getTsQuery, getTsQueryOpt, PgTsQuery)
optAccessor(getXml, getXmlOpt, PgXml)
optAccessor(getBit, getBitOpt, PgBit)
optAccessor(getHstore, getHstoreOpt, PgHstore)
optAccessor(getPoint, getPointOpt, PgPoint)
optAccessor(getLine, getLineOpt, PgLine)
optAccessor(getLseg, getLsegOpt, PgLseg)
optAccessor(getBox, getBoxOpt, PgBox)
optAccessor(getPath, getPathOpt, PgPath)
optAccessor(getPolygon, getPolygonOpt, PgPolygon)
optAccessor(getCircle, getCircleOpt, PgCircle)

proc getIntArray*(row: Row, col: int): seq[int32] =
  ## Get a column value as a seq of int32. Handles binary array format.
  if row.isBinaryCol(col):
    let (off, clen) = cellInfo(row, col)
    if clen == -1:
      raise newException(PgTypeError, "Column " & $col & " is NULL")
    let decoded = decodeBinaryArray(row.data.buf.toOpenArray(off, off + clen - 1))
    rejectMultiDim(decoded)
    result = newSeq[int32](decoded.elements.len)
    for i, e in decoded.elements:
      if e.len == -1:
        raise newException(PgTypeError, "NULL element in int array")
      if e.len != 4:
        raise newException(
          PgTypeError, "Unexpected binary element length " & $e.len & " for int4 array"
        )
      result[i] =
        fromBE32(row.data.buf.toOpenArray(off + e.off, off + e.off + e.len - 1))
    return
  let s = row.getStr(col)
  let elems = parseTextArray(s)
  for e in elems:
    if e.isNone:
      raise newException(PgTypeError, "NULL element in int array")
    result.add(int32(parseInt(e.get)))

proc getInt16Array*(row: Row, col: int): seq[int16] =
  ## Get a column value as a seq of int16. Handles binary array format.
  if row.isBinaryCol(col):
    let (off, clen) = cellInfo(row, col)
    if clen == -1:
      raise newException(PgTypeError, "Column " & $col & " is NULL")
    let decoded = decodeBinaryArray(row.data.buf.toOpenArray(off, off + clen - 1))
    rejectMultiDim(decoded)
    result = newSeq[int16](decoded.elements.len)
    for i, e in decoded.elements:
      if e.len == -1:
        raise newException(PgTypeError, "NULL element in int16 array")
      if e.len != 2:
        raise newException(
          PgTypeError, "Unexpected binary element length " & $e.len & " for int2 array"
        )
      result[i] =
        fromBE16(row.data.buf.toOpenArray(off + e.off, off + e.off + e.len - 1))
    return
  let s = row.getStr(col)
  let elems = parseTextArray(s)
  for e in elems:
    if e.isNone:
      raise newException(PgTypeError, "NULL element in int16 array")
    result.add(int16(parseInt(e.get)))

proc getInt64Array*(row: Row, col: int): seq[int64] =
  ## Get a column value as a seq of int64. Handles binary array format.
  if row.isBinaryCol(col):
    let (off, clen) = cellInfo(row, col)
    if clen == -1:
      raise newException(PgTypeError, "Column " & $col & " is NULL")
    let decoded = decodeBinaryArray(row.data.buf.toOpenArray(off, off + clen - 1))
    rejectMultiDim(decoded)
    result = newSeq[int64](decoded.elements.len)
    for i, e in decoded.elements:
      if e.len == -1:
        raise newException(PgTypeError, "NULL element in int64 array")
      if e.len != 8:
        raise newException(
          PgTypeError, "Unexpected binary element length " & $e.len & " for int8 array"
        )
      result[i] =
        fromBE64(row.data.buf.toOpenArray(off + e.off, off + e.off + e.len - 1))
    return
  let s = row.getStr(col)
  let elems = parseTextArray(s)
  for e in elems:
    if e.isNone:
      raise newException(PgTypeError, "NULL element in int64 array")
    result.add(parseBiggestInt(e.get))

proc getMoneyArray*(row: Row, col: int, scale: int = 2): seq[PgMoney] =
  ## Get a column value as a seq of PgMoney. Handles binary array format and
  ## locale-formatted text arrays (see ``parsePgMoney``). ``scale`` tags each
  ## element's ``frac_digits`` and is also used for text parsing.
  ## Raises ``PgTypeError`` when ``scale`` is outside ``0..18``.
  if scale < 0 or scale > 18:
    raise newException(PgTypeError, "PgMoney scale out of range: " & $scale)
  if row.isBinaryCol(col):
    let (off, clen) = cellInfo(row, col)
    if clen == -1:
      raise newException(PgTypeError, "Column " & $col & " is NULL")
    let decoded = decodeBinaryArray(row.data.buf.toOpenArray(off, off + clen - 1))
    rejectMultiDim(decoded)
    result = newSeq[PgMoney](decoded.elements.len)
    for i, e in decoded.elements:
      if e.len == -1:
        raise newException(PgTypeError, "NULL element in money array")
      if e.len != 8:
        raise newException(
          PgTypeError, "Unexpected binary element length " & $e.len & " for money array"
        )
      result[i] = PgMoney(
        amount: fromBE64(row.data.buf.toOpenArray(off + e.off, off + e.off + e.len - 1)),
        scale: int8(scale),
      )
    return
  let s = row.getStr(col)
  let elems = parseTextArray(s)
  for e in elems:
    if e.isNone:
      raise newException(PgTypeError, "NULL element in money array")
    result.add(parsePgMoney(e.get, scale))

proc getFloatArray*(row: Row, col: int): seq[float64] =
  ## Get a column value as a seq of float64. Handles binary array format.
  if row.isBinaryCol(col):
    let (off, clen) = cellInfo(row, col)
    if clen == -1:
      raise newException(PgTypeError, "Column " & $col & " is NULL")
    let decoded = decodeBinaryArray(row.data.buf.toOpenArray(off, off + clen - 1))
    rejectMultiDim(decoded)
    result = newSeq[float64](decoded.elements.len)
    for i, e in decoded.elements:
      if e.len == -1:
        raise newException(PgTypeError, "NULL element in float array")
      if e.len == 4:
        result[i] = float64(
          cast[float32](cast[uint32](fromBE32(
            row.data.buf.toOpenArray(off + e.off, off + e.off + e.len - 1)
          )))
        )
      elif e.len == 8:
        result[i] = cast[float64](cast[uint64](fromBE64(
          row.data.buf.toOpenArray(off + e.off, off + e.off + e.len - 1)
        )))
      else:
        raise newException(
          PgTypeError, "Unexpected binary element length " & $e.len & " for float array"
        )
    return
  let s = row.getStr(col)
  let elems = parseTextArray(s)
  for e in elems:
    if e.isNone:
      raise newException(PgTypeError, "NULL element in float array")
    result.add(parseFloat(e.get))

proc getFloat32Array*(row: Row, col: int): seq[float32] =
  ## Get a column value as a seq of float32. Handles binary array format.
  if row.isBinaryCol(col):
    let (off, clen) = cellInfo(row, col)
    if clen == -1:
      raise newException(PgTypeError, "Column " & $col & " is NULL")
    let decoded = decodeBinaryArray(row.data.buf.toOpenArray(off, off + clen - 1))
    rejectMultiDim(decoded)
    result = newSeq[float32](decoded.elements.len)
    for i, e in decoded.elements:
      if e.len == -1:
        raise newException(PgTypeError, "NULL element in float32 array")
      if e.len != 4:
        raise newException(
          PgTypeError,
          "Unexpected binary element length " & $e.len & " for float32 array",
        )
      result[i] = cast[float32](cast[uint32](fromBE32(
        row.data.buf.toOpenArray(off + e.off, off + e.off + e.len - 1)
      )))
    return
  let s = row.getStr(col)
  let elems = parseTextArray(s)
  for e in elems:
    if e.isNone:
      raise newException(PgTypeError, "NULL element in float32 array")
    result.add(float32(parseFloat(e.get)))

proc getBoolArray*(row: Row, col: int): seq[bool] =
  ## Get a column value as a seq of bool. Handles binary array format.
  if row.isBinaryCol(col):
    let (off, clen) = cellInfo(row, col)
    if clen == -1:
      raise newException(PgTypeError, "Column " & $col & " is NULL")
    let decoded = decodeBinaryArray(row.data.buf.toOpenArray(off, off + clen - 1))
    rejectMultiDim(decoded)
    result = newSeq[bool](decoded.elements.len)
    for i, e in decoded.elements:
      if e.len == -1:
        raise newException(PgTypeError, "NULL element in bool array")
      if e.len != 1:
        raise newException(
          PgTypeError, "Unexpected binary element length " & $e.len & " for bool array"
        )
      result[i] = row.data.buf[off + e.off] == 1'u8
    return
  let s = row.getStr(col)
  let elems = parseTextArray(s)
  for e in elems:
    if e.isNone:
      raise newException(PgTypeError, "NULL element in bool array")
    case e.get
    of "t", "true", "1":
      result.add(true)
    of "f", "false", "0":
      result.add(false)
    else:
      raise newException(PgTypeError, "Invalid boolean: " & e.get)

proc getStrArray*(row: Row, col: int): seq[string] =
  ## Get a column value as a seq of strings. Handles binary array format.
  if row.isBinaryCol(col):
    let (off, clen) = cellInfo(row, col)
    if clen == -1:
      raise newException(PgTypeError, "Column " & $col & " is NULL")
    let decoded = decodeBinaryArray(row.data.buf.toOpenArray(off, off + clen - 1))
    rejectMultiDim(decoded)
    result = newSeq[string](decoded.elements.len)
    for i, e in decoded.elements:
      if e.len == -1:
        raise newException(PgTypeError, "NULL element in string array")
      result[i] = readString(row.data.buf, off + e.off, e.len)
    return
  let s = row.getStr(col)
  let elems = parseTextArray(s)
  for e in elems:
    if e.isNone:
      raise newException(PgTypeError, "NULL element in string array")
    result.add(e.get)

proc getBitArray*(row: Row, col: int): seq[PgBit] =
  ## Get a column value as a seq of PgBit. Handles both text and binary format.
  if row.isBinaryCol(col):
    let (off, clen) = cellInfo(row, col)
    if clen == -1:
      raise newException(PgTypeError, "Column " & $col & " is NULL")
    let decoded = decodeBinaryArray(row.data.buf.toOpenArray(off, off + clen - 1))
    rejectMultiDim(decoded)
    result = newSeq[PgBit](decoded.elements.len)
    for i, e in decoded.elements:
      if e.len == -1:
        raise newException(PgTypeError, "NULL element in bit array")
      if e.len < 4:
        raise newException(PgTypeError, "Invalid binary bit element: too short")
      let nbits = fromBE32(row.data.buf.toOpenArray(off + e.off, off + e.off + 3))
      if nbits < 0:
        raise newException(
          PgTypeError, "Invalid binary bit element: negative nbits " & $nbits
        )
      if nbits > PgBitMaxBits:
        raise newException(
          PgTypeError,
          "Invalid binary bit element: nbits " & $nbits & " exceeds limit (" &
            $PgBitMaxBits & ")",
        )
      let dataLen = e.len - 4
      if (int64(nbits) + 7) div 8 != int64(dataLen):
        raise newException(
          PgTypeError,
          "Invalid binary bit element: nbits=" & $nbits & " inconsistent with dataLen=" &
            $dataLen,
        )
      var data = newSeq[byte](dataLen)
      for j in 0 ..< dataLen:
        data[j] = row.data.buf[off + e.off + 4 + j]
      result[i] = PgBit(nbits: nbits, data: data)
    return
  let s = row.getStr(col)
  let elems = parseTextArray(s)
  for e in elems:
    if e.isNone:
      raise newException(PgTypeError, "NULL element in bit array")
    result.add(parseBitString(e.get))

# Generic array decoder skeleton: handles binary array header parsing and the
# binary/text NULL-element checks. ``binBody`` is the expression that decodes
# one binary element (with ``row``/``off``/``e``/``decoded`` in scope), and
# ``textBody`` decodes one text element (with ``e`` — an ``Option[string]`` —
# in scope).
template genArrayDecoder(
    getProc: untyped, T: typedesc, typeName: static string, binBody, textBody: untyped
) {.dirty.} =
  proc getProc*(row: Row, col: int): seq[T] =
    if row.isBinaryCol(col):
      let (off, clen) = cellInfo(row, col)
      if clen == -1:
        raise newException(PgTypeError, "Column " & $col & " is NULL")
      let decoded = decodeBinaryArray(row.data.buf.toOpenArray(off, off + clen - 1))
      rejectMultiDim(decoded)
      result = newSeq[T](decoded.elements.len)
      for i, e in decoded.elements:
        if e.len == -1:
          raise newException(PgTypeError, "NULL element in " & typeName & " array")
        result[i] = binBody
      return
    for e in parseTextArray(row.getStr(col)):
      if e.isNone:
        raise newException(PgTypeError, "NULL element in " & typeName & " array")
      result.add(textBody)

# Temporal array decoders

genArrayDecoder(
  getTimestampArray,
  DateTime,
  "timestamp",
  decodeBinaryTimestamp(row.data.buf.toOpenArray(off + e.off, off + e.off + 7)),
  parseTimestampText(e.get),
)
genArrayDecoder(
  getTimestampTzArray,
  DateTime,
  "timestamptz",
  decodeBinaryTimestamp(row.data.buf.toOpenArray(off + e.off, off + e.off + 7)),
  parseTimestampText(e.get),
)

proc dateElemFromText(s: string): DateTime =
  try:
    parse(s, "yyyy-MM-dd")
  except TimeParseError:
    raise newException(PgTypeError, "Invalid date: " & s)

genArrayDecoder(
  getDateArray,
  DateTime,
  "date",
  decodeBinaryDate(row.data.buf.toOpenArray(off + e.off, off + e.off + 3)),
  dateElemFromText(e.get),
)
genArrayDecoder(
  getTimeArray,
  PgTime,
  "time",
  decodeBinaryTime(row.data.buf.toOpenArray(off + e.off, off + e.off + 7)),
  parseTimeText(e.get),
)
genArrayDecoder(
  getTimeTzArray,
  PgTimeTz,
  "timetz",
  decodeBinaryTimeTz(row.data.buf.toOpenArray(off + e.off, off + e.off + 11)),
  parseTimeTzText(e.get),
)

proc intervalElemFromBinary(buf: openArray[byte], off, elen: int): PgInterval =
  if elen != 16:
    raise newException(PgTypeError, "Invalid binary interval element length: " & $elen)
  result.microseconds = fromBE64(buf.toOpenArray(off, off + 7))
  result.days = fromBE32(buf.toOpenArray(off + 8, off + 11))
  result.months = fromBE32(buf.toOpenArray(off + 12, off + 15))

genArrayDecoder(
  getIntervalArray,
  PgInterval,
  "interval",
  intervalElemFromBinary(row.data.buf, off + e.off, e.len),
  parseIntervalText(e.get),
)

# Identifier / network array decoders

proc uuidElemFromBinary(buf: openArray[byte], off, elen: int): PgUuid =
  if elen != 16:
    raise newException(PgTypeError, "Invalid binary uuid element length: " & $elen)
  const hexChars = "0123456789abcdef"
  var s = newString(36)
  var pos = 0
  for j in 0 ..< 16:
    if j == 4 or j == 6 or j == 8 or j == 10:
      s[pos] = '-'
      inc pos
    let b = buf[off + j]
    s[pos] = hexChars[int(b shr 4)]
    s[pos + 1] = hexChars[int(b and 0x0F)]
    pos += 2
  PgUuid(s)

genArrayDecoder(
  getUuidArray,
  PgUuid,
  "uuid",
  uuidElemFromBinary(row.data.buf, off + e.off, e.len),
  PgUuid(e.get),
)

proc inetElemFromBinary[T](buf: openArray[byte], lo, hi: int): T =
  let (ip, mask) = decodeInetBinary(buf.toOpenArray(lo, hi))
  result.address = ip
  result.mask = mask

proc inetElemFromText[T](s: string): T =
  let (ip, mask) = parseInetText(s)
  result.address = ip
  result.mask = mask

genArrayDecoder(
  getInetArray,
  PgInet,
  "inet",
  inetElemFromBinary[PgInet](row.data.buf, off + e.off, off + e.off + e.len - 1),
  inetElemFromText[PgInet](e.get),
)
genArrayDecoder(
  getCidrArray,
  PgCidr,
  "cidr",
  inetElemFromBinary[PgCidr](row.data.buf, off + e.off, off + e.off + e.len - 1),
  inetElemFromText[PgCidr](e.get),
)

proc macAddrElemFromBinary[T](
    buf: openArray[byte], off, elen: int, nBytes: static int, typeName: static string
): T =
  if elen != nBytes:
    raise newException(
      PgTypeError, "Invalid binary " & typeName & " element length: " & $elen
    )
  var parts = newSeq[string](nBytes)
  for j in 0 ..< nBytes:
    parts[j] = toHex(buf[off + j], 2).toLowerAscii()
  T(parts.join(":"))

genArrayDecoder(
  getMacAddrArray,
  PgMacAddr,
  "macaddr",
  macAddrElemFromBinary[PgMacAddr](row.data.buf, off + e.off, e.len, 6, "macaddr"),
  PgMacAddr(e.get),
)
genArrayDecoder(
  getMacAddr8Array,
  PgMacAddr8,
  "macaddr8",
  macAddrElemFromBinary[PgMacAddr8](row.data.buf, off + e.off, e.len, 8, "macaddr8"),
  PgMacAddr8(e.get),
)

# Numeric / binary / JSON array decoders

genArrayDecoder(
  getNumericArray,
  PgNumeric,
  "numeric",
  decodeNumericBinary(row.data.buf.toOpenArray(off + e.off, off + e.off + e.len - 1)),
  parsePgNumeric(e.get),
)

proc bytesElemFromText(s: string): seq[byte] =
  if s.len >= 2 and s[0] == '\\' and s[1] == 'x':
    let hexStr = s[2 ..^ 1]
    result = newSeq[byte](hexStr.len div 2)
    for j in 0 ..< result.len:
      result[j] = byte(parseHexInt(hexStr[j * 2 .. j * 2 + 1]))
  else:
    result = toBytes(s)

genArrayDecoder(
  getBytesArray,
  seq[byte],
  "bytea",
  readBytes(row.data.buf, off + e.off, e.len),
  bytesElemFromText(e.get),
)

proc jsonElemFromBinary(
    buf: openArray[byte], off, elen: int, elemOid: int32
): JsonNode =
  var jsonStr: string
  if elemOid == OidJsonb and elen > 0 and buf[off] == 1:
    jsonStr = newString(elen - 1)
    for j in 1 ..< elen:
      jsonStr[j - 1] = char(buf[off + j])
  else:
    jsonStr = newString(elen)
    for j in 0 ..< elen:
      jsonStr[j] = char(buf[off + j])
  try:
    parseJson(jsonStr)
  except JsonParsingError:
    raise newException(PgTypeError, "Invalid JSON element: " & jsonStr)

proc jsonElemFromText(s: string): JsonNode =
  try:
    parseJson(s)
  except JsonParsingError:
    raise newException(PgTypeError, "Invalid JSON element: " & s)

genArrayDecoder(
  getJsonArray,
  JsonNode,
  "json",
  jsonElemFromBinary(row.data.buf, off + e.off, e.len, decoded.elemOid),
  jsonElemFromText(e.get),
)

# Geometric array decoders

genArrayDecoder(
  getPointArray,
  PgPoint,
  "point",
  decodePointBinary(row.data.buf, off + e.off),
  parsePointText(e.get),
)

proc lineElemFromBinary(buf: openArray[byte], off, elen: int): PgLine =
  if elen != 24:
    raise newException(PgTypeError, "Invalid binary line element length: " & $elen)
  result.a = decodeFloat64BE(buf, off)
  result.b = decodeFloat64BE(buf, off + 8)
  result.c = decodeFloat64BE(buf, off + 16)

proc lineElemFromText(s: string): PgLine =
  let v = s.strip()
  var inner = v
  if inner.len >= 2 and inner[0] == '{' and inner[^1] == '}':
    inner = inner[1 ..^ 2]
  else:
    raise newException(PgTypeError, "Invalid line: " & v)
  let parts = inner.split(',')
  if parts.len != 3:
    raise newException(PgTypeError, "Invalid line: " & v)
  PgLine(a: parseFloat(parts[0]), b: parseFloat(parts[1]), c: parseFloat(parts[2]))

genArrayDecoder(
  getLineArray,
  PgLine,
  "line",
  lineElemFromBinary(row.data.buf, off + e.off, e.len),
  lineElemFromText(e.get),
)

proc lsegElemFromBinary(buf: openArray[byte], off: int): PgLseg =
  PgLseg(p1: decodePointBinary(buf, off), p2: decodePointBinary(buf, off + 16))

proc lsegElemFromText(s: string): PgLseg =
  let v = s.strip()
  var inner = v
  if inner.len >= 2 and inner[0] == '[' and inner[^1] == ']':
    inner = inner[1 ..^ 2]
  let points = parsePointsText(inner)
  if points.len != 2:
    raise newException(PgTypeError, "Invalid lseg: " & v)
  PgLseg(p1: points[0], p2: points[1])

genArrayDecoder(
  getLsegArray,
  PgLseg,
  "lseg",
  lsegElemFromBinary(row.data.buf, off + e.off),
  lsegElemFromText(e.get),
)

proc getBoxArray*(row: Row, col: int): seq[PgBox] =
  if row.isBinaryCol(col):
    let (off, clen) = cellInfo(row, col)
    if clen == -1:
      raise newException(PgTypeError, "Column " & $col & " is NULL")
    let decoded = decodeBinaryArray(row.data.buf.toOpenArray(off, off + clen - 1))
    rejectMultiDim(decoded)
    result = newSeq[PgBox](decoded.elements.len)
    for i, e in decoded.elements:
      if e.len == -1:
        raise newException(PgTypeError, "NULL element in box array")
      result[i] = PgBox(
        high: decodePointBinary(row.data.buf, off + e.off),
        low: decodePointBinary(row.data.buf, off + e.off + 16),
      )
    return
  # PostgreSQL uses ';' as array element delimiter for box type
  let s = row.getStr(col)
  if s.len < 2 or s[0] != '{' or s[^1] != '}':
    raise newException(PgTypeError, "Invalid box array literal: " & s)
  let inner = s[1 ..^ 2]
  if inner.len == 0:
    return
  let parts = inner.split(';')
  for p in parts:
    let v = p.strip()
    if v == "NULL":
      raise newException(PgTypeError, "NULL element in box array")
    let points = parsePointsText(v)
    if points.len != 2:
      raise newException(PgTypeError, "Invalid box: " & v)
    result.add(PgBox(high: points[0], low: points[1]))

proc pathElemFromBinary(buf: openArray[byte], off, elen: int): PgPath =
  if elen < 5:
    raise newException(PgTypeError, "Invalid binary path element: too short " & $elen)
  result.closed = buf[off] != 0
  let npts = fromBE32(buf.toOpenArray(off + 1, off + 4))
  if npts < 0 or elen != 5 + npts * 16:
    raise newException(
      PgTypeError,
      "Invalid binary path element: bad npts " & $npts & " (elen " & $elen & ")",
    )
  result.points = newSeq[PgPoint](npts)
  for j in 0 ..< npts:
    result.points[j] = decodePointBinary(buf, off + 5 + j * 16)

proc pathElemFromText(s: string): PgPath =
  let v = s.strip()
  if v.len < 2:
    raise newException(PgTypeError, "Invalid path: " & v)
  let closed = v[0] == '('
  let inner = v[1 ..^ 2]
  PgPath(closed: closed, points: parsePointsText(inner))

genArrayDecoder(
  getPathArray,
  PgPath,
  "path",
  pathElemFromBinary(row.data.buf, off + e.off, e.len),
  pathElemFromText(e.get),
)

proc polygonElemFromBinary(buf: openArray[byte], off, elen: int): PgPolygon =
  if elen < 4:
    raise
      newException(PgTypeError, "Invalid binary polygon element: too short " & $elen)
  let npts = fromBE32(buf.toOpenArray(off, off + 3))
  if npts < 0 or elen != 4 + npts * 16:
    raise newException(
      PgTypeError,
      "Invalid binary polygon element: bad npts " & $npts & " (elen " & $elen & ")",
    )
  result.points = newSeq[PgPoint](npts)
  for j in 0 ..< npts:
    result.points[j] = decodePointBinary(buf, off + 4 + j * 16)

proc polygonElemFromText(s: string): PgPolygon =
  let v = s.strip()
  if v.len < 2 or v[0] != '(' or v[^1] != ')':
    raise newException(PgTypeError, "Invalid polygon: " & v)
  PgPolygon(points: parsePointsText(v[1 ..^ 2]))

genArrayDecoder(
  getPolygonArray,
  PgPolygon,
  "polygon",
  polygonElemFromBinary(row.data.buf, off + e.off, e.len),
  polygonElemFromText(e.get),
)

proc circleElemFromBinary(buf: openArray[byte], off, elen: int): PgCircle =
  if elen != 24:
    raise newException(PgTypeError, "Invalid binary circle element length: " & $elen)
  result.center = decodePointBinary(buf, off)
  result.radius = decodeFloat64BE(buf, off + 16)

proc circleElemFromText(s: string): PgCircle =
  let v = s.strip()
  if v.len < 2 or v[0] != '<' or v[^1] != '>':
    raise newException(PgTypeError, "Invalid circle: " & v)
  let inner = v[1 ..^ 2]
  var depth = 0
  var lastComma = -1
  for j in 0 ..< inner.len:
    if inner[j] == '(':
      depth += 1
    elif inner[j] == ')':
      depth -= 1
    elif inner[j] == ',' and depth == 0:
      lastComma = j
  if lastComma < 0:
    raise newException(PgTypeError, "Invalid circle: " & v)
  PgCircle(
    center: parsePointText(inner[0 ..< lastComma]),
    radius: parseFloat(inner[lastComma + 1 ..^ 1]),
  )

genArrayDecoder(
  getCircleArray,
  PgCircle,
  "circle",
  circleElemFromBinary(row.data.buf, off + e.off, e.len),
  circleElemFromText(e.get),
)

# Other array decoders

proc stringElemFromBinary[T](buf: openArray[byte], off, elen: int): T =
  T(readString(buf, off, elen))

genArrayDecoder(
  getXmlArray,
  PgXml,
  "xml",
  stringElemFromBinary[PgXml](row.data.buf, off + e.off, e.len),
  PgXml(e.get),
)
genArrayDecoder(
  getTsVectorArray,
  PgTsVector,
  "tsvector",
  stringElemFromBinary[PgTsVector](row.data.buf, off + e.off, e.len),
  PgTsVector(e.get),
)
genArrayDecoder(
  getTsQueryArray,
  PgTsQuery,
  "tsquery",
  stringElemFromBinary[PgTsQuery](row.data.buf, off + e.off, e.len),
  PgTsQuery(e.get),
)

genArrayDecoder(
  getHstoreArray,
  PgHstore,
  "hstore",
  decodeHstoreBinary(row.data.buf.toOpenArray(off + e.off, off + e.off + e.len - 1)),
  parseHstoreText(e.get),
)

# Element-level NULL-safe array getters

proc getIntArrayElemOpt*(row: Row, col: int): seq[Option[int32]] =
  if row.isBinaryCol(col):
    let (off, clen) = cellInfo(row, col)
    if clen == -1:
      raise newException(PgTypeError, "Column " & $col & " is NULL")
    let decoded = decodeBinaryArray(row.data.buf.toOpenArray(off, off + clen - 1))
    rejectMultiDim(decoded)
    result = newSeq[Option[int32]](decoded.elements.len)
    for i, e in decoded.elements:
      if e.len == -1:
        result[i] = none(int32)
      else:
        result[i] =
          some(fromBE32(row.data.buf.toOpenArray(off + e.off, off + e.off + e.len - 1)))
    return
  let s = row.getStr(col)
  for e in parseTextArray(s):
    if e.isNone:
      result.add(none(int32))
    else:
      result.add(some(int32(parseInt(e.get))))

proc getInt16ArrayElemOpt*(row: Row, col: int): seq[Option[int16]] =
  if row.isBinaryCol(col):
    let (off, clen) = cellInfo(row, col)
    if clen == -1:
      raise newException(PgTypeError, "Column " & $col & " is NULL")
    let decoded = decodeBinaryArray(row.data.buf.toOpenArray(off, off + clen - 1))
    rejectMultiDim(decoded)
    result = newSeq[Option[int16]](decoded.elements.len)
    for i, e in decoded.elements:
      if e.len == -1:
        result[i] = none(int16)
      else:
        result[i] =
          some(fromBE16(row.data.buf.toOpenArray(off + e.off, off + e.off + e.len - 1)))
    return
  let s = row.getStr(col)
  for e in parseTextArray(s):
    if e.isNone:
      result.add(none(int16))
    else:
      result.add(some(int16(parseInt(e.get))))

proc getInt64ArrayElemOpt*(row: Row, col: int): seq[Option[int64]] =
  if row.isBinaryCol(col):
    let (off, clen) = cellInfo(row, col)
    if clen == -1:
      raise newException(PgTypeError, "Column " & $col & " is NULL")
    let decoded = decodeBinaryArray(row.data.buf.toOpenArray(off, off + clen - 1))
    rejectMultiDim(decoded)
    result = newSeq[Option[int64]](decoded.elements.len)
    for i, e in decoded.elements:
      if e.len == -1:
        result[i] = none(int64)
      else:
        result[i] =
          some(fromBE64(row.data.buf.toOpenArray(off + e.off, off + e.off + e.len - 1)))
    return
  let s = row.getStr(col)
  for e in parseTextArray(s):
    if e.isNone:
      result.add(none(int64))
    else:
      result.add(some(parseBiggestInt(e.get)))

proc getFloatArrayElemOpt*(row: Row, col: int): seq[Option[float64]] =
  if row.isBinaryCol(col):
    let (off, clen) = cellInfo(row, col)
    if clen == -1:
      raise newException(PgTypeError, "Column " & $col & " is NULL")
    let decoded = decodeBinaryArray(row.data.buf.toOpenArray(off, off + clen - 1))
    rejectMultiDim(decoded)
    result = newSeq[Option[float64]](decoded.elements.len)
    for i, e in decoded.elements:
      if e.len == -1:
        result[i] = none(float64)
      elif e.len == 4:
        result[i] = some(
          float64(
            cast[float32](cast[uint32](fromBE32(
              row.data.buf.toOpenArray(off + e.off, off + e.off + e.len - 1)
            )))
          )
        )
      else:
        result[i] = some(
          cast[float64](cast[uint64](fromBE64(
            row.data.buf.toOpenArray(off + e.off, off + e.off + e.len - 1)
          )))
        )
    return
  let s = row.getStr(col)
  for e in parseTextArray(s):
    if e.isNone:
      result.add(none(float64))
    else:
      result.add(some(parseFloat(e.get)))

proc getFloat32ArrayElemOpt*(row: Row, col: int): seq[Option[float32]] =
  if row.isBinaryCol(col):
    let (off, clen) = cellInfo(row, col)
    if clen == -1:
      raise newException(PgTypeError, "Column " & $col & " is NULL")
    let decoded = decodeBinaryArray(row.data.buf.toOpenArray(off, off + clen - 1))
    rejectMultiDim(decoded)
    result = newSeq[Option[float32]](decoded.elements.len)
    for i, e in decoded.elements:
      if e.len == -1:
        result[i] = none(float32)
      else:
        result[i] = some(
          cast[float32](cast[uint32](fromBE32(
            row.data.buf.toOpenArray(off + e.off, off + e.off + e.len - 1)
          )))
        )
    return
  let s = row.getStr(col)
  for e in parseTextArray(s):
    if e.isNone:
      result.add(none(float32))
    else:
      result.add(some(float32(parseFloat(e.get))))

proc getBoolArrayElemOpt*(row: Row, col: int): seq[Option[bool]] =
  if row.isBinaryCol(col):
    let (off, clen) = cellInfo(row, col)
    if clen == -1:
      raise newException(PgTypeError, "Column " & $col & " is NULL")
    let decoded = decodeBinaryArray(row.data.buf.toOpenArray(off, off + clen - 1))
    rejectMultiDim(decoded)
    result = newSeq[Option[bool]](decoded.elements.len)
    for i, e in decoded.elements:
      if e.len == -1:
        result[i] = none(bool)
      else:
        result[i] = some(row.data.buf[off + e.off] == 1'u8)
    return
  let s = row.getStr(col)
  for e in parseTextArray(s):
    if e.isNone:
      result.add(none(bool))
    else:
      case e.get
      of "t", "true", "1":
        result.add(some(true))
      of "f", "false", "0":
        result.add(some(false))
      else:
        raise newException(PgTypeError, "Invalid boolean: " & e.get)

proc getStrArrayElemOpt*(row: Row, col: int): seq[Option[string]] =
  if row.isBinaryCol(col):
    let (off, clen) = cellInfo(row, col)
    if clen == -1:
      raise newException(PgTypeError, "Column " & $col & " is NULL")
    let decoded = decodeBinaryArray(row.data.buf.toOpenArray(off, off + clen - 1))
    rejectMultiDim(decoded)
    result = newSeq[Option[string]](decoded.elements.len)
    for i, e in decoded.elements:
      if e.len == -1:
        result[i] = none(string)
      else:
        result[i] = some(readString(row.data.buf, off + e.off, e.len))
    return
  let s = row.getStr(col)
  result = parseTextArray(s)

# Array Opt accessors (text format)

optAccessor(getIntArray, getIntArrayOpt, seq[int32])
optAccessor(getInt16Array, getInt16ArrayOpt, seq[int16])
optAccessor(getInt64Array, getInt64ArrayOpt, seq[int64])
optAccessor(getFloatArray, getFloatArrayOpt, seq[float64])
optAccessor(getFloat32Array, getFloat32ArrayOpt, seq[float32])
optAccessor(getBoolArray, getBoolArrayOpt, seq[bool])
optAccessor(getStrArray, getStrArrayOpt, seq[string])
optAccessor(getBitArray, getBitArrayOpt, seq[PgBit])
optAccessor(getTimestampArray, getTimestampArrayOpt, seq[DateTime])
optAccessor(getTimestampTzArray, getTimestampTzArrayOpt, seq[DateTime])
optAccessor(getDateArray, getDateArrayOpt, seq[DateTime])
optAccessor(getTimeArray, getTimeArrayOpt, seq[PgTime])
optAccessor(getTimeTzArray, getTimeTzArrayOpt, seq[PgTimeTz])
optAccessor(getIntervalArray, getIntervalArrayOpt, seq[PgInterval])
optAccessor(getUuidArray, getUuidArrayOpt, seq[PgUuid])
optAccessor(getInetArray, getInetArrayOpt, seq[PgInet])
optAccessor(getCidrArray, getCidrArrayOpt, seq[PgCidr])
optAccessor(getMacAddrArray, getMacAddrArrayOpt, seq[PgMacAddr])
optAccessor(getMacAddr8Array, getMacAddr8ArrayOpt, seq[PgMacAddr8])
optAccessor(getNumericArray, getNumericArrayOpt, seq[PgNumeric])
optAccessor(getMoneyArray, getMoneyArrayOpt, seq[PgMoney])
optAccessor(getBytesArray, getBytesArrayOpt, seq[seq[byte]])
optAccessor(getJsonArray, getJsonArrayOpt, seq[JsonNode])
optAccessor(getPointArray, getPointArrayOpt, seq[PgPoint])
optAccessor(getLineArray, getLineArrayOpt, seq[PgLine])
optAccessor(getLsegArray, getLsegArrayOpt, seq[PgLseg])
optAccessor(getBoxArray, getBoxArrayOpt, seq[PgBox])
optAccessor(getPathArray, getPathArrayOpt, seq[PgPath])
optAccessor(getPolygonArray, getPolygonArrayOpt, seq[PgPolygon])
optAccessor(getCircleArray, getCircleArrayOpt, seq[PgCircle])
optAccessor(getXmlArray, getXmlArrayOpt, seq[PgXml])
optAccessor(getTsVectorArray, getTsVectorArrayOpt, seq[PgTsVector])
optAccessor(getTsQueryArray, getTsQueryArrayOpt, seq[PgTsQuery])
optAccessor(getHstoreArray, getHstoreArrayOpt, seq[PgHstore])

# Column-level + element-level NULL-safe
optAccessor(getIntArrayElemOpt, getIntArrayElemOptOpt, seq[Option[int32]])
optAccessor(getInt16ArrayElemOpt, getInt16ArrayElemOptOpt, seq[Option[int16]])
optAccessor(getInt64ArrayElemOpt, getInt64ArrayElemOptOpt, seq[Option[int64]])
optAccessor(getFloatArrayElemOpt, getFloatArrayElemOptOpt, seq[Option[float64]])
optAccessor(getFloat32ArrayElemOpt, getFloat32ArrayElemOptOpt, seq[Option[float32]])
optAccessor(getBoolArrayElemOpt, getBoolArrayElemOptOpt, seq[Option[bool]])
optAccessor(getStrArrayElemOpt, getStrArrayElemOptOpt, seq[Option[string]])

# PgArray[T] decoder registry and ``getArrayND`` — companion to the encoder
# registry in ``encoding.nim``. Supports multi-dimensional arrays.

proc decodePgArrayElement*(_: typedesc[int16], buf: openArray[byte]): int16 {.inline.} =
  if buf.len != 2:
    raise newException(PgTypeError, "int2 array element: bad length " & $buf.len)
  fromBE16(buf)

proc decodePgArrayElement*(_: typedesc[int32], buf: openArray[byte]): int32 {.inline.} =
  if buf.len != 4:
    raise newException(PgTypeError, "int4 array element: bad length " & $buf.len)
  fromBE32(buf)

proc decodePgArrayElement*(_: typedesc[int64], buf: openArray[byte]): int64 {.inline.} =
  if buf.len != 8:
    raise newException(PgTypeError, "int8 array element: bad length " & $buf.len)
  fromBE64(buf)

proc decodePgArrayElement*(
    _: typedesc[float32], buf: openArray[byte]
): float32 {.inline.} =
  if buf.len != 4:
    raise newException(PgTypeError, "float4 array element: bad length " & $buf.len)
  cast[float32](cast[uint32](fromBE32(buf)))

proc decodePgArrayElement*(
    _: typedesc[float64], buf: openArray[byte]
): float64 {.inline.} =
  if buf.len != 8:
    raise newException(PgTypeError, "float8 array element: bad length " & $buf.len)
  cast[float64](cast[uint64](fromBE64(buf)))

proc decodePgArrayElement*(_: typedesc[bool], buf: openArray[byte]): bool {.inline.} =
  if buf.len != 1:
    raise newException(PgTypeError, "bool array element: bad length " & $buf.len)
  buf[0] != 0'u8

proc decodePgArrayElement*(_: typedesc[string], buf: openArray[byte]): string =
  result = newString(buf.len)
  for i in 0 ..< buf.len:
    result[i] = char(buf[i])

proc decodePgArrayElement*(_: typedesc[PgUuid], buf: openArray[byte]): PgUuid =
  if buf.len != 16:
    raise newException(PgTypeError, "uuid array element: bad length " & $buf.len)
  const hexChars = "0123456789abcdef"
  var s = newString(36)
  var pos = 0
  for j in 0 ..< 16:
    if j == 4 or j == 6 or j == 8 or j == 10:
      s[pos] = '-'
      inc pos
    let b = buf[j]
    s[pos] = hexChars[int(b shr 4)]
    s[pos + 1] = hexChars[int(b and 0x0F)]
    pos += 2
  PgUuid(s)

proc decodePgArrayElement*(_: typedesc[PgNumeric], buf: openArray[byte]): PgNumeric =
  decodeNumericBinary(buf)

# Intentionally no ``decodePgArrayElement(PgMoney, ...)``: the binary money
# wire format does not carry the fractional-digit count, so the scale must
# come from the caller. ``getArrayND[PgMoney]`` is ``{.error.}``-gated, and
# ``getMoneyArrayND`` decodes elements inline with the caller-supplied scale.

proc decodePgArrayElement*(_: typedesc[PgBit], buf: openArray[byte]): PgBit =
  if buf.len < 4:
    raise newException(PgTypeError, "bit array element too short")
  let nbits = fromBE32(buf.toOpenArray(0, 3))
  if nbits < 0:
    raise newException(PgTypeError, "bit array element: negative nbits " & $nbits)
  if nbits > PgBitMaxBits:
    raise newException(
      PgTypeError,
      "bit array element: nbits " & $nbits & " exceeds limit (" & $PgBitMaxBits & ")",
    )
  let dataLen = buf.len - 4
  if (int64(nbits) + 7) div 8 != int64(dataLen):
    raise newException(
      PgTypeError,
      "bit array element: nbits=" & $nbits & " inconsistent with dataLen=" & $dataLen,
    )
  var data = newSeq[byte](dataLen)
  for j in 0 ..< dataLen:
    data[j] = buf[4 + j]
  PgBit(nbits: nbits, data: data)

proc decodePgArrayElement*(_: typedesc[PgInterval], buf: openArray[byte]): PgInterval =
  if buf.len != 16:
    raise newException(PgTypeError, "interval array element: bad length " & $buf.len)
  result.microseconds = fromBE64(buf.toOpenArray(0, 7))
  result.days = fromBE32(buf.toOpenArray(8, 11))
  result.months = fromBE32(buf.toOpenArray(12, 15))

proc decodePgArrayElement*(_: typedesc[PgTime], buf: openArray[byte]): PgTime =
  decodeBinaryTime(buf)

proc decodePgArrayElement*(_: typedesc[PgTimeTz], buf: openArray[byte]): PgTimeTz =
  decodeBinaryTimeTz(buf)

proc decodePgArrayElement*(_: typedesc[PgInet], buf: openArray[byte]): PgInet =
  let (ip, mask) = decodeInetBinary(buf)
  PgInet(address: ip, mask: mask)

proc decodePgArrayElement*(_: typedesc[PgCidr], buf: openArray[byte]): PgCidr =
  let (ip, mask) = decodeInetBinary(buf)
  PgCidr(address: ip, mask: mask)

proc decodePgArrayElement*(_: typedesc[PgMacAddr], buf: openArray[byte]): PgMacAddr =
  if buf.len != 6:
    raise newException(PgTypeError, "macaddr array element: bad length " & $buf.len)
  var parts = newSeq[string](6)
  for j in 0 ..< 6:
    parts[j] = toHex(buf[j], 2).toLowerAscii()
  PgMacAddr(parts.join(":"))

proc decodePgArrayElement*(_: typedesc[PgMacAddr8], buf: openArray[byte]): PgMacAddr8 =
  if buf.len != 8:
    raise newException(PgTypeError, "macaddr8 array element: bad length " & $buf.len)
  var parts = newSeq[string](8)
  for j in 0 ..< 8:
    parts[j] = toHex(buf[j], 2).toLowerAscii()
  PgMacAddr8(parts.join(":"))

proc decodePgArrayElement*(_: typedesc[PgXml], buf: openArray[byte]): PgXml =
  var s = newString(buf.len)
  for i in 0 ..< buf.len:
    s[i] = char(buf[i])
  PgXml(s)

proc decodePgArrayElement*(_: typedesc[PgPoint], buf: openArray[byte]): PgPoint =
  if buf.len != 16:
    raise newException(PgTypeError, "point array element: bad length " & $buf.len)
  decodePointBinary(buf, 0)

proc decodePgArrayElement*(_: typedesc[PgLine], buf: openArray[byte]): PgLine =
  if buf.len != 24:
    raise newException(PgTypeError, "line array element: bad length " & $buf.len)
  result.a = decodeFloat64BE(buf, 0)
  result.b = decodeFloat64BE(buf, 8)
  result.c = decodeFloat64BE(buf, 16)

proc decodePgArrayElement*(_: typedesc[PgLseg], buf: openArray[byte]): PgLseg =
  if buf.len != 32:
    raise newException(PgTypeError, "lseg array element: bad length " & $buf.len)
  PgLseg(p1: decodePointBinary(buf, 0), p2: decodePointBinary(buf, 16))

proc decodePgArrayElement*(_: typedesc[PgBox], buf: openArray[byte]): PgBox =
  if buf.len != 32:
    raise newException(PgTypeError, "box array element: bad length " & $buf.len)
  PgBox(high: decodePointBinary(buf, 0), low: decodePointBinary(buf, 16))

proc decodePgArrayElement*(_: typedesc[PgPath], buf: openArray[byte]): PgPath =
  if buf.len < 5:
    raise newException(PgTypeError, "path array element too short")
  result.closed = buf[0] != 0
  let npts = fromBE32(buf.toOpenArray(1, 4))
  if npts < 0 or buf.len != 5 + npts * 16:
    raise newException(
      PgTypeError,
      "path array element: bad npts " & $npts & " (buf.len " & $buf.len & ")",
    )
  result.points = newSeq[PgPoint](npts)
  for j in 0 ..< npts:
    result.points[j] = decodePointBinary(buf, 5 + j * 16)

proc decodePgArrayElement*(_: typedesc[PgPolygon], buf: openArray[byte]): PgPolygon =
  if buf.len < 4:
    raise newException(PgTypeError, "polygon array element too short")
  let npts = fromBE32(buf.toOpenArray(0, 3))
  if npts < 0 or buf.len != 4 + npts * 16:
    raise newException(
      PgTypeError,
      "polygon array element: bad npts " & $npts & " (buf.len " & $buf.len & ")",
    )
  result.points = newSeq[PgPoint](npts)
  for j in 0 ..< npts:
    result.points[j] = decodePointBinary(buf, 4 + j * 16)

proc decodePgArrayElement*(_: typedesc[PgCircle], buf: openArray[byte]): PgCircle =
  if buf.len != 24:
    raise newException(PgTypeError, "circle array element: bad length " & $buf.len)
  result.center = decodePointBinary(buf, 0)
  result.radius = decodeFloat64BE(buf, 16)

proc getArrayND*[T](row: Row, col: int): PgArray[T] =
  ## Read an N-dimensional PostgreSQL array column as a ``PgArray[T]``.
  ## Requires binary column format; text-format multi-dimensional arrays are
  ## not supported. Raises ``PgTypeError`` when the column is NULL, or when
  ## the wire ``elemOid`` does not match the registered OID for ``T``
  ## (``JsonNode`` accepts both ``json`` and ``jsonb``).
  ##
  ## Validation looks only at the wire ``elemOid`` carried in the array
  ## payload, not at the column's field OID from ``RowDescription``. A bind
  ## mismatch (e.g. reading a ``text[]`` column as ``getArrayND[int32]``) is
  ## caught by the elemOid check; reading e.g. ``int4[]`` via
  ## ``getArrayND[int32]`` against a column declared as ``int8[]`` succeeds
  ## as long as the wire bytes match the requested ``T``. For ``JsonNode``,
  ## the leading jsonb version byte is stripped only when ``elemOid == jsonb``;
  ## ``json`` payloads pass through unchanged, and any other wire ``elemOid``
  ## (e.g. ``int4``) is rejected by the OID check so calling
  ## ``getArrayND[JsonNode]`` on a non-JSON column raises rather than
  ## silently misinterpreting the bytes.
  when T is DateTime:
    {.
      error:
        "getArrayND[DateTime] is ambiguous (timestamp / timestamptz / date " &
        "have distinct OIDs). Use the dedicated 1-D accessors " &
        "(getTimestampArray / getTimestampTzArray / getDateArray) instead."
    .}
  elif T is seq[byte]:
    {.
      error:
        "getArrayND[seq[byte]] is not supported by the PgArray registry. " &
        "Use getByteaArray instead."
    .}
  elif T is int:
    {.
      error:
        "getArrayND[int] is not supported (platform-dependent width). " &
        "Use getArrayND[int32] or getArrayND[int64] explicitly."
    .}
  elif T is PgMoney:
    {.
      error:
        "getArrayND[PgMoney] would silently hardcode scale=2 and produce " &
        "wrong values on servers whose lc_monetary frac_digits differ from " &
        "2. Use getMoneyArrayND(row, col, scale = ...) instead " &
        "(getMoneyArrayNDOpt for the NULL-safe variant)."
    .}
  elif T is PgTsVector or T is PgTsQuery:
    {.
      error:
        "getArrayND[PgTsVector] / getArrayND[PgTsQuery] is not supported by " &
        "the PgArray registry: the binary wire format for tsvector / " &
        "tsquery is structured (not the text representation), so element " &
        "round-trip would not match what PostgreSQL sends. Use the 1-D " &
        "accessor (getTsVectorArray / getTsQueryArray) instead; " &
        "PgArray[T] currently has no multi-dim equivalent for these types."
    .}
  if not row.isBinaryCol(col):
    raise newException(
      PgTypeError, "getArrayND requires binary column format (col " & $col & ")"
    )
  let (off, clen) = cellInfo(row, col)
  if clen == -1:
    raise newException(PgTypeError, "Column " & $col & " is NULL")
  let decoded = decodeBinaryArray(row.data.buf.toOpenArray(off, off + clen - 1))
  when T is JsonNode:
    if decoded.elemOid != OidJson and decoded.elemOid != OidJsonb:
      raise newException(
        PgTypeError,
        "getArrayND[JsonNode]: wire elemOid=" & $decoded.elemOid &
          " is neither json nor jsonb",
      )
  else:
    if decoded.elemOid != pgArrayElemOid(T):
      raise newException(
        PgTypeError,
        "getArrayND[" & $T & "]: wire elemOid=" & $decoded.elemOid & " expected " &
          $pgArrayElemOid(T),
      )
  result.dims = decoded.dims
  result.lowerBounds = decoded.lowerBounds
  result.elements = newSeq[Option[T]](decoded.elements.len)
  for i, e in decoded.elements:
    if e.len == -1:
      result.elements[i] = none(T)
    else:
      when T is JsonNode:
        # Strip the leading jsonb version byte only when the wire elemOid
        # actually says jsonb. Plain ``json`` payloads are forwarded as-is.
        result.elements[i] =
          some(jsonElemFromBinary(row.data.buf, off + e.off, e.len, decoded.elemOid))
      else:
        result.elements[i] = some(
          decodePgArrayElement(
            T, row.data.buf.toOpenArray(off + e.off, off + e.off + e.len - 1)
          )
        )

proc getArrayNDOpt*[T](row: Row, col: int): Option[PgArray[T]] =
  ## NULL-safe column-level variant of ``getArrayND[T]``.
  if row.isNull(col):
    none(PgArray[T])
  else:
    some(getArrayND[T](row, col))

proc getMoneyArrayND*(row: Row, col: int, scale: int = 2): PgArray[PgMoney] =
  ## ``getArrayND``-style accessor for ``money[]`` (any dimensionality).
  ## ``getArrayND[PgMoney]`` is intentionally ``{.error.}``-gated because the
  ## binary ``money`` wire format does not carry the fractional-digit count,
  ## so the caller must supply ``scale`` (matching the server's
  ## ``lc_monetary`` ``frac_digits``) — this accessor is the only way to
  ## read a ``money[]`` column. Defaults to ``scale = 2`` for the common
  ## locale. Raises ``PgTypeError`` when ``scale`` is outside ``0..18``.
  if scale < 0 or scale > 18:
    raise newException(PgTypeError, "PgMoney scale out of range: " & $scale)
  if not row.isBinaryCol(col):
    raise newException(
      PgTypeError, "getMoneyArrayND requires binary column format (col " & $col & ")"
    )
  let (off, clen) = cellInfo(row, col)
  if clen == -1:
    raise newException(PgTypeError, "Column " & $col & " is NULL")
  let decoded = decodeBinaryArray(row.data.buf.toOpenArray(off, off + clen - 1))
  if decoded.elemOid != pgArrayElemOid(PgMoney):
    raise newException(
      PgTypeError,
      "getMoneyArrayND: wire elemOid=" & $decoded.elemOid & " expected " &
        $pgArrayElemOid(PgMoney),
    )
  result.dims = decoded.dims
  result.lowerBounds = decoded.lowerBounds
  result.elements = newSeq[Option[PgMoney]](decoded.elements.len)
  for i, e in decoded.elements:
    if e.len == -1:
      result.elements[i] = none(PgMoney)
    else:
      if e.len != 8:
        raise newException(
          PgTypeError, "Unexpected binary element length " & $e.len & " for money array"
        )
      result.elements[i] = some(
        PgMoney(
          amount:
            fromBE64(row.data.buf.toOpenArray(off + e.off, off + e.off + e.len - 1)),
          scale: int8(scale),
        )
      )

proc getMoneyArrayNDOpt*(row: Row, col: int, scale: int = 2): Option[PgArray[PgMoney]] =
  ## NULL-safe column-level variant of ``getMoneyArrayND``.
  if row.isNull(col):
    none(PgArray[PgMoney])
  else:
    some(getMoneyArrayND(row, col, scale))

# Generic accessors — static dispatch by type, no OID branching.

proc get*(row: Row, col: int, T: typedesc[int16]): int16 =
  ## Generic typed accessor. Usage: ``row.get(0, int16)``
  row.getInt16(col)

proc get*(row: Row, col: int, T: typedesc[int32]): int32 =
  ## Generic typed accessor. Usage: ``row.get(0, int32)``
  row.getInt(col)

proc get*(row: Row, col: int, T: typedesc[int64]): int64 =
  row.getInt64(col)

proc get*(row: Row, col: int, T: typedesc[float32]): float32 =
  row.getFloat32(col)

proc get*(row: Row, col: int, T: typedesc[float64]): float64 =
  row.getFloat(col)

proc get*(row: Row, col: int, T: typedesc[bool]): bool =
  row.getBool(col)

proc get*(row: Row, col: int, T: typedesc[string]): string =
  row.getStr(col)

proc get*(row: Row, col: int, T: typedesc[seq[byte]]): seq[byte] =
  row.getBytes(col)

proc get*(row: Row, col: int, T: typedesc[PgNumeric]): PgNumeric =
  row.getNumeric(col)

proc get*(row: Row, col: int, T: typedesc[PgMoney]): PgMoney =
  row.getMoney(col)

proc get*(row: Row, col: int, T: typedesc[JsonNode]): JsonNode =
  row.getJson(col)

proc get*(row: Row, col: int, T: typedesc[PgInterval]): PgInterval =
  row.getInterval(col)

proc get*(row: Row, col: int, T: typedesc[PgInet]): PgInet =
  row.getInet(col)

proc get*(row: Row, col: int, T: typedesc[PgCidr]): PgCidr =
  row.getCidr(col)

proc get*(row: Row, col: int, T: typedesc[PgMacAddr]): PgMacAddr =
  row.getMacAddr(col)

proc get*(row: Row, col: int, T: typedesc[PgMacAddr8]): PgMacAddr8 =
  row.getMacAddr8(col)

proc get*(row: Row, col: int, T: typedesc[PgTsVector]): PgTsVector =
  row.getTsVector(col)

proc get*(row: Row, col: int, T: typedesc[PgTsQuery]): PgTsQuery =
  row.getTsQuery(col)

proc get*(row: Row, col: int, T: typedesc[PgXml]): PgXml =
  row.getXml(col)

proc get*(row: Row, col: int, T: typedesc[PgBit]): PgBit =
  row.getBit(col)

proc get*(row: Row, col: int, T: typedesc[PgTime]): PgTime =
  row.getTime(col)

proc get*(row: Row, col: int, T: typedesc[PgTimeTz]): PgTimeTz =
  row.getTimeTz(col)

proc get*(row: Row, col: int, T: typedesc[PgHstore]): PgHstore =
  row.getHstore(col)

proc get*(row: Row, col: int, T: typedesc[PgUuid]): PgUuid =
  row.getUuid(col)

proc get*(row: Row, col: int, T: typedesc[PgPoint]): PgPoint =
  row.getPoint(col)

proc get*(row: Row, col: int, T: typedesc[PgLine]): PgLine =
  row.getLine(col)

proc get*(row: Row, col: int, T: typedesc[PgLseg]): PgLseg =
  row.getLseg(col)

proc get*(row: Row, col: int, T: typedesc[PgBox]): PgBox =
  row.getBox(col)

proc get*(row: Row, col: int, T: typedesc[PgPath]): PgPath =
  row.getPath(col)

proc get*(row: Row, col: int, T: typedesc[PgPolygon]): PgPolygon =
  row.getPolygon(col)

proc get*(row: Row, col: int, T: typedesc[PgCircle]): PgCircle =
  row.getCircle(col)

# Array types

proc get*(row: Row, col: int, T: typedesc[seq[int16]]): seq[int16] =
  row.getInt16Array(col)

proc get*(row: Row, col: int, T: typedesc[seq[int32]]): seq[int32] =
  row.getIntArray(col)

proc get*(row: Row, col: int, T: typedesc[seq[int64]]): seq[int64] =
  row.getInt64Array(col)

proc get*(row: Row, col: int, T: typedesc[seq[float32]]): seq[float32] =
  row.getFloat32Array(col)

proc get*(row: Row, col: int, T: typedesc[seq[float64]]): seq[float64] =
  row.getFloatArray(col)

proc get*(row: Row, col: int, T: typedesc[seq[bool]]): seq[bool] =
  row.getBoolArray(col)

proc get*(row: Row, col: int, T: typedesc[seq[string]]): seq[string] =
  row.getStrArray(col)

proc get*(row: Row, col: int, T: typedesc[seq[seq[byte]]]): seq[seq[byte]] =
  row.getBytesArray(col)

proc get*(row: Row, col: int, T: typedesc[seq[PgBit]]): seq[PgBit] =
  row.getBitArray(col)

proc get*(row: Row, col: int, T: typedesc[seq[PgTime]]): seq[PgTime] =
  row.getTimeArray(col)

proc get*(row: Row, col: int, T: typedesc[seq[PgTimeTz]]): seq[PgTimeTz] =
  row.getTimeTzArray(col)

proc get*(row: Row, col: int, T: typedesc[seq[PgInterval]]): seq[PgInterval] =
  row.getIntervalArray(col)

proc get*(row: Row, col: int, T: typedesc[seq[PgUuid]]): seq[PgUuid] =
  row.getUuidArray(col)

proc get*(row: Row, col: int, T: typedesc[seq[PgInet]]): seq[PgInet] =
  row.getInetArray(col)

proc get*(row: Row, col: int, T: typedesc[seq[PgCidr]]): seq[PgCidr] =
  row.getCidrArray(col)

proc get*(row: Row, col: int, T: typedesc[seq[PgMacAddr]]): seq[PgMacAddr] =
  row.getMacAddrArray(col)

proc get*(row: Row, col: int, T: typedesc[seq[PgMacAddr8]]): seq[PgMacAddr8] =
  row.getMacAddr8Array(col)

proc get*(row: Row, col: int, T: typedesc[seq[PgNumeric]]): seq[PgNumeric] =
  row.getNumericArray(col)

proc get*(row: Row, col: int, T: typedesc[seq[PgMoney]]): seq[PgMoney] =
  row.getMoneyArray(col)

proc get*(row: Row, col: int, T: typedesc[seq[JsonNode]]): seq[JsonNode] =
  row.getJsonArray(col)

proc get*(row: Row, col: int, T: typedesc[seq[PgPoint]]): seq[PgPoint] =
  row.getPointArray(col)

proc get*(row: Row, col: int, T: typedesc[seq[PgLine]]): seq[PgLine] =
  row.getLineArray(col)

proc get*(row: Row, col: int, T: typedesc[seq[PgLseg]]): seq[PgLseg] =
  row.getLsegArray(col)

proc get*(row: Row, col: int, T: typedesc[seq[PgBox]]): seq[PgBox] =
  row.getBoxArray(col)

proc get*(row: Row, col: int, T: typedesc[seq[PgPath]]): seq[PgPath] =
  row.getPathArray(col)

proc get*(row: Row, col: int, T: typedesc[seq[PgPolygon]]): seq[PgPolygon] =
  row.getPolygonArray(col)

proc get*(row: Row, col: int, T: typedesc[seq[PgCircle]]): seq[PgCircle] =
  row.getCircleArray(col)

proc get*(row: Row, col: int, T: typedesc[seq[PgXml]]): seq[PgXml] =
  row.getXmlArray(col)

proc get*(row: Row, col: int, T: typedesc[seq[PgTsVector]]): seq[PgTsVector] =
  row.getTsVectorArray(col)

proc get*(row: Row, col: int, T: typedesc[seq[PgTsQuery]]): seq[PgTsQuery] =
  row.getTsQueryArray(col)

proc get*(row: Row, col: int, T: typedesc[seq[PgHstore]]): seq[PgHstore] =
  row.getHstoreArray(col)

# Per-element Option array types

proc get*(row: Row, col: int, T: typedesc[seq[Option[int16]]]): seq[Option[int16]] =
  row.getInt16ArrayElemOpt(col)

proc get*(row: Row, col: int, T: typedesc[seq[Option[int32]]]): seq[Option[int32]] =
  row.getIntArrayElemOpt(col)

proc get*(row: Row, col: int, T: typedesc[seq[Option[int64]]]): seq[Option[int64]] =
  row.getInt64ArrayElemOpt(col)

proc get*(row: Row, col: int, T: typedesc[seq[Option[float32]]]): seq[Option[float32]] =
  row.getFloat32ArrayElemOpt(col)

proc get*(row: Row, col: int, T: typedesc[seq[Option[float64]]]): seq[Option[float64]] =
  row.getFloatArrayElemOpt(col)

proc get*(row: Row, col: int, T: typedesc[seq[Option[bool]]]): seq[Option[bool]] =
  row.getBoolArrayElemOpt(col)

proc get*(row: Row, col: int, T: typedesc[seq[Option[string]]]): seq[Option[string]] =
  row.getStrArrayElemOpt(col)

proc columnIndex*(fields: seq[FieldDescription], name: string): int =
  ## Find the index of a column by name. Raises PgTypeError if not found.
  for i, f in fields:
    if f.name == name:
      return i
  raise newException(PgTypeError, "Column not found: " & name)

proc columnMap*(fields: seq[FieldDescription]): Table[string, int] =
  ## Build a name-to-index mapping for all columns.
  for i, f in fields:
    result[f.name] = i

# Name-based column access

proc columnIndex*(row: Row, name: string): int =
  ## Find the index of a column by name using a cached name→index table on the
  ## row's underlying ``RowData``.  The table is built lazily on first access.
  ## Raises ``PgTypeError`` if the metadata is not available (e.g. the Row was
  ## constructed manually) or the column name is not found.
  if row.data == nil or row.data.fields.len == 0:
    raise newException(PgTypeError, "Column name lookup requires field metadata")
  if row.data.colMap.len == 0 and row.data.fields.len > 0:
    for i, f in row.data.fields:
      row.data.colMap[f.name] = i
  let idx = row.data.colMap.getOrDefault(name, -1)
  if idx < 0:
    raise newException(PgTypeError, "Column not found: " & name)
  idx

# Generic typed accessor by column name

proc get*[T](row: Row, name: string, _: typedesc[T]): T =
  ## Generic typed accessor by column name. Usage: ``row.get("id", int32)``
  row.get(row.columnIndex(name), T)
