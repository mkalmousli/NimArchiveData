import std/[unittest, deques, tables, importutils]

import ../async_postgres/[async_backend, pg_protocol, pg_connection]
import ../async_postgres/pg_pool {.all.}
import ../async_postgres/pg_pool_cluster {.all.}

privateAccess(PgPool)
privateAccess(PgConnection)
privateAccess(PooledConn)
privateAccess(Waiter)
privateAccess(PgPoolCluster)

proc mockConn(state: PgConnState = csReady, pool: PgPool = nil): PgConnection =
  PgConnection(
    recvBuf: @[],
    state: state,
    txStatus: tsIdle,
    serverParams: initTable[string, string](),
    createdAt: Moment.now(),
    ownerPool: pool,
  )

proc makePool(minSize: int = 0, maxSize: int = 5): PgPool =
  PgPool(
    config: PoolConfig(
      connConfig: ConnConfig(host: "localhost", port: 5432),
      minSize: minSize,
      maxSize: maxSize,
      maxWaiters: -1,
      maintenanceInterval: seconds(30),
    ),
    idle: initDeque[PooledConn](),
    active: 0,
    waiters: initDeque[Waiter](),
    waiterCount: 0,
    closed: false,
  )

proc makeCluster(
    fallback = fallbackNone,
    primaryMaxSize = 5,
    replicaMaxSize = 5,
    fallbackTimeout = ZeroDuration,
): PgPoolCluster =
  PgPoolCluster(
    primary: makePool(maxSize = primaryMaxSize),
    replica: makePool(maxSize = replicaMaxSize),
    fallback: fallback,
    fallbackTimeout: fallbackTimeout,
    closed: false,
  )

proc mockIdle(pool: PgPool, conn: PgConnection) =
  ## Place a mock connection in the pool's idle queue, wiring `ownerPool`
  ## the same way production `newPool` does. Without this, a subsequent
  ## `conn.release()` (e.g. via `withReadConnection`) would raise because
  ## the back-reference is nil.
  conn.ownerPool = pool
  pool.idle.addLast(PooledConn(conn: conn, lastUsedAt: Moment.now()))

suite "newPoolCluster targetSessionAttrs":
  test "auto-sets tsaReadWrite for primary and tsaPreferStandby for replica when tsaAny":
    var pCfg = PoolConfig(
      connConfig: ConnConfig(host: "localhost", port: 5432, targetSessionAttrs: tsaAny),
      minSize: 0,
      maxSize: 1,
      maintenanceInterval: seconds(30),
    )
    var rCfg = PoolConfig(
      connConfig: ConnConfig(host: "localhost", port: 5433, targetSessionAttrs: tsaAny),
      minSize: 0,
      maxSize: 1,
      maintenanceInterval: seconds(30),
    )

    # We can't call newPoolCluster without a real server, so verify the logic
    # by checking the config mutation directly.
    if pCfg.connConfig.targetSessionAttrs == tsaAny:
      pCfg.connConfig.targetSessionAttrs = tsaReadWrite
    if rCfg.connConfig.targetSessionAttrs == tsaAny:
      rCfg.connConfig.targetSessionAttrs = tsaPreferStandby

    check pCfg.connConfig.targetSessionAttrs == tsaReadWrite
    check rCfg.connConfig.targetSessionAttrs == tsaPreferStandby

  test "preserves explicit targetSessionAttrs":
    var pCfg = PoolConfig(
      connConfig:
        ConnConfig(host: "localhost", port: 5432, targetSessionAttrs: tsaPrimary)
    )
    var rCfg = PoolConfig(
      connConfig:
        ConnConfig(host: "localhost", port: 5433, targetSessionAttrs: tsaStandby)
    )

    if pCfg.connConfig.targetSessionAttrs == tsaAny:
      pCfg.connConfig.targetSessionAttrs = tsaReadWrite
    if rCfg.connConfig.targetSessionAttrs == tsaAny:
      rCfg.connConfig.targetSessionAttrs = tsaPreferStandby

    check pCfg.connConfig.targetSessionAttrs == tsaPrimary
    check rCfg.connConfig.targetSessionAttrs == tsaStandby

suite "Read routing":
  test "acquireRead returns connection from replica pool":
    let cluster = makeCluster()
    let conn = mockConn()
    cluster.replica.mockIdle(conn)

    let (acquired, pool) = waitFor acquireRead(cluster)
    check acquired == conn
    check pool == cluster.replica
    check cluster.replica.active == 1
    check cluster.primary.active == 0

  test "withReadConnection acquires from replica and releases":
    proc t() {.async.} =
      let cluster = makeCluster()
      let conn = mockConn()
      cluster.replica.mockIdle(conn)

      cluster.withReadConnection(c):
        doAssert c == conn
        doAssert cluster.replica.active == 1

      doAssert cluster.replica.active == 0
      doAssert cluster.replica.idle.len == 1

    waitFor t()

  test "withWriteConnection acquires from primary and releases":
    proc t() {.async.} =
      let cluster = makeCluster()
      let conn = mockConn()
      cluster.primary.mockIdle(conn)

      cluster.withWriteConnection(c):
        doAssert c == conn
        doAssert cluster.primary.active == 1

      doAssert cluster.primary.active == 0
      doAssert cluster.primary.idle.len == 1

    waitFor t()

  test "withWriteConnection and withReadConnection in same scope with same name":
    proc t() {.async.} =
      let cluster = makeCluster()
      let wConn = mockConn()
      let rConn = mockConn()
      cluster.primary.mockIdle(wConn)
      cluster.replica.mockIdle(rConn)

      cluster.withWriteConnection(conn):
        doAssert conn == wConn
        doAssert cluster.primary.active == 1

      cluster.withReadConnection(conn):
        doAssert conn == rConn
        doAssert cluster.replica.active == 1

      doAssert cluster.primary.active == 0
      doAssert cluster.replica.active == 0

    waitFor t()

suite "Exception safety":
  test "withReadConnection releases on exception":
    proc t() {.async.} =
      let cluster = makeCluster()
      let conn = mockConn()
      cluster.replica.mockIdle(conn)

      var caught = false
      try:
        cluster.withReadConnection(c):
          doAssert cluster.replica.active == 1
          raise newException(ValueError, "boom")
      except ValueError:
        caught = true

      doAssert caught
      doAssert cluster.replica.active == 0
      doAssert cluster.replica.idle.len == 1

    waitFor t()

  test "withWriteConnection releases on exception":
    proc t() {.async.} =
      let cluster = makeCluster()
      let conn = mockConn()
      cluster.primary.mockIdle(conn)

      var caught = false
      try:
        cluster.withWriteConnection(c):
          doAssert cluster.primary.active == 1
          raise newException(ValueError, "boom")
      except ValueError:
        caught = true

      doAssert caught
      doAssert cluster.primary.active == 0
      doAssert cluster.primary.idle.len == 1

    waitFor t()

suite "Fallback":
  test "fallbackPrimary falls back to primary when replica unavailable":
    let cluster = makeCluster(fallback = fallbackPrimary)
    # replica has no idle connections and is at max
    cluster.replica.active = cluster.replica.config.maxSize
    cluster.replica.config.acquireTimeout = ZeroDuration
    # But we need the waiter to fail immediately — set maxWaiters to reject
    cluster.replica.config.maxWaiters = 1
    # Fill the waiter queue so next acquire is rejected
    let dummyFut = newFuture[PgConnection]("dummy")
    cluster.replica.waiters.addLast(Waiter(fut: dummyFut, cancelled: false))
    cluster.replica.waiterCount = 1

    let primaryConn = mockConn()
    cluster.primary.idle.addLast(
      PooledConn(conn: primaryConn, lastUsedAt: Moment.now())
    )

    let (acquired, pool) = waitFor acquireRead(cluster)
    check acquired == primaryConn
    check pool == cluster.primary
    check cluster.primary.active == 1

    # Clean up
    dummyFut.complete(mockConn())

  test "fallbackNone raises when replica unavailable":
    let cluster = makeCluster(fallback = fallbackNone)
    cluster.replica.active = cluster.replica.config.maxSize
    cluster.replica.config.maxWaiters = 1
    let dummyFut = newFuture[PgConnection]("dummy")
    cluster.replica.waiters.addLast(Waiter(fut: dummyFut, cancelled: false))
    cluster.replica.waiterCount = 1

    expect(PgError):
      discard waitFor acquireRead(cluster)

    check cluster.primary.active == 0

    # Clean up
    dummyFut.complete(mockConn())

  test "fallbackPrimary raises when both pools unavailable":
    let cluster = makeCluster(fallback = fallbackPrimary)
    # Both pools at max with full waiter queues
    cluster.replica.active = cluster.replica.config.maxSize
    cluster.replica.config.maxWaiters = 1
    let replicaFut = newFuture[PgConnection]("replica-dummy")
    cluster.replica.waiters.addLast(Waiter(fut: replicaFut, cancelled: false))
    cluster.replica.waiterCount = 1

    cluster.primary.active = cluster.primary.config.maxSize
    cluster.primary.config.maxWaiters = 1
    let primaryFut = newFuture[PgConnection]("primary-dummy")
    cluster.primary.waiters.addLast(Waiter(fut: primaryFut, cancelled: false))
    cluster.primary.waiterCount = 1

    expect(PgError):
      discard waitFor acquireRead(cluster)

    # Clean up
    replicaFut.complete(mockConn())
    primaryFut.complete(mockConn())

  test "fallbackTimeout raises PgPoolError when primary acquire exceeds timeout":
    let cluster =
      makeCluster(fallback = fallbackPrimary, fallbackTimeout = milliseconds(50))
    cluster.replica.closed = true
    # Primary at max with no idle connections — acquire will wait
    cluster.primary.active = cluster.primary.config.maxSize

    expect(PgError):
      discard waitFor acquireRead(cluster)

  test "fallbackTimeout succeeds when primary available within timeout":
    let cluster = makeCluster(fallback = fallbackPrimary, fallbackTimeout = seconds(5))
    cluster.replica.closed = true

    let primaryConn = mockConn()
    cluster.primary.idle.addLast(
      PooledConn(conn: primaryConn, lastUsedAt: Moment.now())
    )

    let (acquired, pool) = waitFor acquireRead(cluster)
    check acquired == primaryConn
    check pool == cluster.primary

  test "fallbackPrimary fallback when replica pool is closed":
    let cluster = makeCluster(fallback = fallbackPrimary)
    cluster.replica.closed = true

    let primaryConn = mockConn()
    cluster.primary.idle.addLast(
      PooledConn(conn: primaryConn, lastUsedAt: Moment.now())
    )

    let (acquired, pool) = waitFor acquireRead(cluster)
    check acquired == primaryConn
    check pool == cluster.primary

suite "Close":
  test "close sets closed and closes both pools":
    let cluster = makeCluster()
    check not cluster.closed
    check not cluster.primary.closed
    check not cluster.replica.closed

    waitFor cluster.close()

    check cluster.closed
    check cluster.primary.closed
    check cluster.replica.closed

  test "close drains idle from both pools":
    let cluster = makeCluster()
    cluster.primary.idle.addLast(
      PooledConn(conn: mockConn(csClosed), lastUsedAt: Moment.now())
    )
    cluster.replica.idle.addLast(
      PooledConn(conn: mockConn(csClosed), lastUsedAt: Moment.now())
    )

    waitFor cluster.close()
    check cluster.primary.idle.len == 0
    check cluster.replica.idle.len == 0

  test "close closes replica even if primary.close raises":
    ## Ensures try/finally guarantees replica cleanup when primary fails.
    let cluster = makeCluster()
    # Add an idle connection with csReady state to primary — closing it will
    # attempt to send Terminate on a nil socket, which raises.
    cluster.primary.idle.addLast(
      PooledConn(conn: mockConn(csReady), lastUsedAt: Moment.now())
    )
    cluster.replica.idle.addLast(
      PooledConn(conn: mockConn(csClosed), lastUsedAt: Moment.now())
    )

    # close() should not propagate the primary error (pool.close catches it)
    waitFor cluster.close()
    check cluster.closed
    check cluster.primary.closed
    check cluster.replica.closed
    check cluster.replica.idle.len == 0

suite "Write routing":
  test "writeConnection routes to primary":
    let cluster = makeCluster()
    cluster.primary.closed = true

    expect(PgError):
      discard waitFor cluster.writeConnection()

  test "readConnection routes to replica":
    let cluster = makeCluster()
    cluster.replica.closed = true
    cluster.fallback = fallbackNone

    expect(PgError):
      discard waitFor cluster.readConnection()

  test "readConnection falls back to primary when replica unavailable":
    let cluster = makeCluster(fallback = fallbackPrimary)
    cluster.replica.active = cluster.replica.config.maxSize
    cluster.replica.config.acquireTimeout = ZeroDuration
    cluster.replica.config.maxWaiters = 1
    let dummyFut = newFuture[PgConnection]("dummy")
    cluster.replica.waiters.addLast(Waiter(fut: dummyFut, cancelled: false))
    cluster.replica.waiterCount = 1

    let primaryConn = mockConn()
    primaryConn.ownerPool = cluster.primary
    cluster.primary.idle.addLast(
      PooledConn(conn: primaryConn, lastUsedAt: Moment.now())
    )

    let h = waitFor cluster.readConnection()
    check h.conn == primaryConn
    h.release()

    dummyFut.complete(mockConn())

suite "Closed pool cluster":
  test "acquire on closed replica raises error":
    let cluster = makeCluster()
    cluster.replica.closed = true
    cluster.fallback = fallbackNone

    expect(PgError):
      discard waitFor acquireRead(cluster)

  test "acquire on closed primary raises error":
    let cluster = makeCluster()
    cluster.primary.closed = true

    expect(PgError):
      discard waitFor cluster.primary.acquire()
