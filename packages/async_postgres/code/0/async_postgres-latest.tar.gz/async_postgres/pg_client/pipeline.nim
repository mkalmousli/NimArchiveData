## Pipelined batch execution of `addExec`/`addQuery` operations against the
## PostgreSQL extended-query protocol. Includes both the single-Sync `execute`
## variant and the per-op Sync `executeIsolated` (error-isolated) variant.

import std/[options, tables]

import ../[async_backend, pg_protocol, pg_connection, pg_types]
import ./core

type
  PipelineOpKind* = enum
    pokExec
    pokQuery

  PipelineOp* = object
    kind: PipelineOpKind
    sql: string
    # Legacy path — populated by the `seq[PgParam]` overloads. These seqs own
    # the per-parameter byte payloads directly, avoiding an extra copy into
    # Pipeline-level storage for bulk-string workloads.
    params: seq[Option[seq[byte]]]
    paramOids: seq[int32]
    paramFormats: seq[int16]
    resultFormats: seq[int16]
    # Inline path — populated by the `openArray[PgParamInline]` overloads.
    # Points at slices of the Pipeline-level SoA buffers
    # (`inlineRanges`/`inlineOids`/`inlineFormats`/`inlineData`). `hasInline`
    # true means the send phase should use these slices instead of the legacy
    # fields above.
    hasInline: bool
    inlineStart: int32
    inlineCount: int32
    # Set during send phase
    cacheHit: bool
    cacheMiss: bool
    stmtName: string

  PipelineResultKind* = enum
    ## Discriminator for pipeline result variants.
    prkExec
    prkQuery

  PipelineResult* = object ## Result of a single operation within a pipeline.
    case kind*: PipelineResultKind
    of prkExec:
      commandResult*: CommandResult
    of prkQuery:
      queryResult*: QueryResult

  Pipeline* = ref object
    ## Batch of queries/execs sent through the PostgreSQL pipeline protocol.
    conn: PgConnection
    ops: seq[PipelineOp]
    # SoA storage shared by all ops added via the `PgParamInline` path.
    # Index ranges in each op point into these sequences, eliminating per-op
    # parameter allocations.
    inlineData: seq[byte]
    inlineRanges: seq[tuple[off: int32, len: int32]]
    inlineOids: seq[int32]
    inlineFormats: seq[int16]
    autoReset*: bool
      ## When true, `execute`/`executeIsolated` call `reset()` in a `finally`
      ## block so the Pipeline can be safely reused without leaking state from
      ## the previous run. Default: false (backward-compatible).

  IsolatedPipelineResults* = object
    ## Results from `executeIsolated`: per-op error isolation via per-query SYNC.
    results*: seq[PipelineResult]
    errors*: seq[ref CatchableError] ## errors[i] is nil if ops[i] succeeded

proc newPipeline*(conn: PgConnection, autoReset: bool = false): Pipeline =
  ## Create a new pipeline for batching multiple operations into a single round trip.
  ## When `autoReset` is true, the pipeline's queued ops and inline buffers are
  ## cleared automatically after each `execute`/`executeIsolated` call, making
  ## it safe to reuse the same Pipeline instance.
  Pipeline(conn: conn, ops: @[], autoReset: autoReset)

proc reset*(p: Pipeline) =
  ## Clear all queued ops and inline SoA buffers. Safe to call at any time,
  ## including while the pipeline is empty. Does not affect the underlying
  ## connection or its statement cache. When `p.autoReset` is true,
  ## `execute`/`executeIsolated` call this automatically (including on raise),
  ## so manual calls are only needed when `autoReset` is false.
  p.ops.setLen(0)
  p.inlineData.setLen(0)
  p.inlineRanges.setLen(0)
  p.inlineOids.setLen(0)
  p.inlineFormats.setLen(0)

proc appendInline(
    p: Pipeline, params: openArray[PgParamInline]
): tuple[start, count: int32] =
  ## Append inline params to the Pipeline-level SoA buffers. Returns
  ## `(start, count)` identifying the appended slice.
  result.start = int32(p.inlineRanges.len)
  result.count = int32(params.len)
  for pi in params:
    appendInlineParam(p.inlineData, p.inlineRanges, p.inlineOids, p.inlineFormats, pi)

proc addExec*(p: Pipeline, sql: string, params: seq[PgParam] = @[]) =
  ## Add an exec operation to the pipeline with typed parameters.
  var op = PipelineOp(kind: pokExec, sql: sql)
  if params.len > 0:
    op.paramOids = newSeqOfCap[int32](params.len)
    op.paramFormats = newSeqOfCap[int16](params.len)
    op.params = newSeqOfCap[Option[seq[byte]]](params.len)
    for param in params:
      op.paramOids.add param.oid
      op.paramFormats.add param.format
      op.params.add param.value
  p.ops.add move(op)

proc addQuery*(
    p: Pipeline,
    sql: string,
    params: seq[PgParam] = @[],
    resultFormat: ResultFormat = rfAuto,
) =
  ## Add a query operation to the pipeline with typed parameters.
  let (oids, formats, values) = extractParams(params)
  p.ops.add PipelineOp(
    kind: pokQuery,
    sql: sql,
    params: values,
    paramOids: oids,
    paramFormats: formats,
    resultFormats: resultFormat.toFormatCodes(),
  )

proc addExec*(p: Pipeline, sql: string, params: openArray[PgParamInline]) =
  ## Add an exec operation using the heap-alloc-free `PgParamInline` path.
  let (start, count) = p.appendInline(params)
  p.ops.add PipelineOp(
    kind: pokExec, sql: sql, hasInline: true, inlineStart: start, inlineCount: count
  )

proc addQuery*(
    p: Pipeline,
    sql: string,
    params: openArray[PgParamInline],
    resultFormat: ResultFormat = rfAuto,
) =
  ## Add a query operation using the heap-alloc-free `PgParamInline` path.
  let (start, count) = p.appendInline(params)
  p.ops.add PipelineOp(
    kind: pokQuery,
    sql: sql,
    hasInline: true,
    inlineStart: start,
    inlineCount: count,
    resultFormats: resultFormat.toFormatCodes(),
  )

proc buildSendPhase(p: Pipeline, perOpSync: bool): seq[CachedStmt] =
  ## Encode all queued ops into `p.conn.sendBuf` and return the per-op
  ## `CachedStmt` snapshots needed by the receive phase for cache-hit queries
  ## (lazy: empty unless at least one pokQuery cache-hit was seen). When
  ## `perOpSync` is true a Sync is appended after each op (executeIsolated);
  ## otherwise a single trailing Sync is appended (execute).
  let conn = p.conn
  conn.sendBuf.setLen(0)
  var hasCachedStmts = false
  var pendingCacheAdds = 0 # track pending additions for LRU eviction in pipeline
  var defaultFormats: seq[int16] # reused across ops when paramFormats is empty

  for i in 0 ..< p.ops.len:
    let hasInline = p.ops[i].hasInline
    let startIdx = int(p.ops[i].inlineStart)
    let endIdx = startIdx + int(p.ops[i].inlineCount) - 1
    if not hasInline and p.ops[i].paramFormats.len == 0:
      let needed = p.ops[i].params.len
      if defaultFormats.len != needed:
        defaultFormats = newSeq[int16](needed)

    template currentFormats(): openArray[int16] =
      if hasInline:
        p.inlineFormats.toOpenArray(startIdx, endIdx)
      elif p.ops[i].paramFormats.len > 0:
        p.ops[i].paramFormats.toOpenArray(0, p.ops[i].paramFormats.high)
      else:
        defaultFormats.toOpenArray(0, defaultFormats.high)

    template emitBind(stmt: string, resultFmts: openArray[int16]) =
      if hasInline:
        conn.sendBuf.addBindRaw(
          "",
          stmt,
          currentFormats(),
          p.inlineData,
          p.inlineRanges.toOpenArray(startIdx, endIdx),
          resultFmts,
        )
      else:
        conn.sendBuf.addBind("", stmt, currentFormats(), p.ops[i].params, resultFmts)

    template emitParse(stmt: string) =
      if hasInline:
        conn.sendBuf.addParse(
          stmt, p.ops[i].sql, p.inlineOids.toOpenArray(startIdx, endIdx)
        )
      else:
        conn.sendBuf.addParse(stmt, p.ops[i].sql, p.ops[i].paramOids)

    let cached = conn.lookupStmtCache(p.ops[i].sql)
    p.ops[i].cacheHit = cached != nil
    p.ops[i].cacheMiss = false

    if cached != nil:
      p.ops[i].stmtName = cached.name
      if p.ops[i].kind == pokQuery:
        if not hasCachedStmts:
          result = newSeq[CachedStmt](p.ops.len)
          hasCachedStmts = true
        result[i] = cached[]
      var effectiveResultFormats: seq[int16]
      if p.ops[i].kind == pokQuery:
        effectiveResultFormats =
          if p.ops[i].resultFormats.len == 0:
            cached.resultFormats
          else:
            p.ops[i].resultFormats
        p.ops[i].resultFormats = effectiveResultFormats
      emitBind(cached.name, effectiveResultFormats)
      conn.sendBuf.addExecute("", 0)
    elif conn.stmtCacheCapacity > 0:
      p.ops[i].cacheMiss = true
      p.ops[i].stmtName = conn.nextStmtName()
      if conn.stmtCache.len + pendingCacheAdds >= conn.stmtCacheCapacity and
          conn.stmtCache.len > 0:
        let evicted = conn.evictStmtCache()
        conn.sendBuf.addClose(dkStatement, evicted.name)
      inc pendingCacheAdds
      emitParse(p.ops[i].stmtName)
      conn.sendBuf.addDescribe(dkStatement, p.ops[i].stmtName)
      emitBind(p.ops[i].stmtName, p.ops[i].resultFormats)
      conn.sendBuf.addExecute("", 0)
    else:
      emitParse("")
      emitBind("", p.ops[i].resultFormats)
      if p.ops[i].kind == pokQuery:
        conn.sendBuf.addDescribe(dkPortal, "")
      conn.sendBuf.addExecute("", 0)

    if perOpSync:
      conn.sendBuf.addSync()

  if not perOpSync:
    conn.sendBuf.addSync()

proc executeImpl(
    p: Pipeline, timeout: Duration = ZeroDuration
): Future[seq[PipelineResult]] {.async.} =
  let conn = p.conn
  conn.checkReady()
  conn.state = csBusy

  let cachedStmts = buildSendPhase(p, perOpSync = false)
  when hasChronos:
    # chronos drains the send Future in the background while we descend into
    # the receive loop. The outer try/except below owns sendFut's lifetime:
    # it drains sendFut on the normal path (propagating any stored write
    # error) and cancels it on any abnormal exit so the Future never leaks.
    var sendFut = conn.sendBufMsg()
  else:
    await conn.sendBufMsg()

  # Receive Phase
  var results = newSeq[PipelineResult](p.ops.len)
  var activeOpIdx = 0
  var queryError: ref PgQueryError
  var cachedFieldsPerOp: seq[seq[FieldDescription]] # lazy-init for cache misses

  # Initialize query results
  for i in 0 ..< p.ops.len:
    if p.ops[i].kind == pokQuery:
      results[i] = PipelineResult(kind: prkQuery)
      if p.ops[i].cacheHit:
        let c = cachedStmts[i]
        results[i].queryResult.fields = c.fields
        if p.ops[i].resultFormats.len > 0 and c.colFmts.len > 0:
          for j in 0 ..< results[i].queryResult.fields.len:
            results[i].queryResult.fields[j].formatCode = c.colFmts[j]
        if results[i].queryResult.fields.len > 0:
          results[i].queryResult.data =
            newRowData(int16(results[i].queryResult.fields.len), c.colFmts, c.colOids)
          results[i].queryResult.data.fields = results[i].queryResult.fields
    else:
      results[i] = PipelineResult(kind: prkExec)

  try:
    block recvLoop:
      while true:
        var rowData: RowData = nil
        var rowCount: ptr int32 = nil
        if activeOpIdx < p.ops.len and p.ops[activeOpIdx].kind == pokQuery:
          rowData = results[activeOpIdx].queryResult.data
          rowCount = addr results[activeOpIdx].queryResult.rowCount

        while (let opt = conn.nextMessage(rowData, rowCount); opt.isSome):
          let msg = opt.get
          case msg.kind
          of bmkParseComplete, bmkBindComplete, bmkCloseComplete:
            discard
          of bmkParameterDescription:
            discard
          of bmkRowDescription:
            if activeOpIdx < p.ops.len and p.ops[activeOpIdx].kind == pokQuery:
              var cf: seq[int16]
              var co: seq[int32]
              if p.ops[activeOpIdx].cacheMiss:
                if cachedFieldsPerOp.len == 0:
                  cachedFieldsPerOp = newSeq[seq[FieldDescription]](p.ops.len)
                cachedFieldsPerOp[activeOpIdx] = msg.fields
                results[activeOpIdx].queryResult.fields = msg.fields
                if p.ops[activeOpIdx].resultFormats.len > 0:
                  cf = newSeq[int16](msg.fields.len)
                  co = newSeq[int32](msg.fields.len)
                  for j in 0 ..< msg.fields.len:
                    co[j] = msg.fields[j].typeOid
                    if p.ops[activeOpIdx].resultFormats.len == 1:
                      results[activeOpIdx].queryResult.fields[j].formatCode =
                        p.ops[activeOpIdx].resultFormats[0]
                      cf[j] = p.ops[activeOpIdx].resultFormats[0]
                    elif j < p.ops[activeOpIdx].resultFormats.len:
                      results[activeOpIdx].queryResult.fields[j].formatCode =
                        p.ops[activeOpIdx].resultFormats[j]
                      cf[j] = p.ops[activeOpIdx].resultFormats[j]
              else:
                results[activeOpIdx].queryResult.fields = msg.fields
              results[activeOpIdx].queryResult.data =
                newRowData(int16(msg.fields.len), cf, co)
              results[activeOpIdx].queryResult.data.fields =
                results[activeOpIdx].queryResult.fields
              # Update pointers for nextMessage
              rowData = results[activeOpIdx].queryResult.data
              rowCount = addr results[activeOpIdx].queryResult.rowCount
          of bmkNoData:
            discard
          of bmkCommandComplete:
            if activeOpIdx < p.ops.len:
              if p.ops[activeOpIdx].kind == pokExec:
                results[activeOpIdx].commandResult = initCommandResult(msg.commandTag)
              else:
                results[activeOpIdx].queryResult.commandTag = msg.commandTag
              inc activeOpIdx
              # Update rowData/rowCount for next op
              if activeOpIdx < p.ops.len and p.ops[activeOpIdx].kind == pokQuery:
                rowData = results[activeOpIdx].queryResult.data
                rowCount = addr results[activeOpIdx].queryResult.rowCount
              else:
                rowData = nil
                rowCount = nil
          of bmkEmptyQueryResponse:
            if activeOpIdx < p.ops.len:
              inc activeOpIdx
              if activeOpIdx < p.ops.len and p.ops[activeOpIdx].kind == pokQuery:
                rowData = results[activeOpIdx].queryResult.data
                rowCount = addr results[activeOpIdx].queryResult.rowCount
              else:
                rowData = nil
                rowCount = nil
          of bmkErrorResponse:
            if queryError == nil:
              queryError = newPgQueryError(msg.errorFields)
          of bmkReadyForQuery:
            conn.txStatus = msg.txStatus
            conn.state = csReady
            if queryError != nil:
              # Invalidate cache for 26000 (prepared statement does not exist)
              if queryError.sqlState == "26000":
                for i in 0 ..< p.ops.len:
                  if p.ops[i].cacheHit:
                    conn.removeStmtCache(p.ops[i].sql)
              raise queryError
            # Cache misses: add to cache
            for i in 0 ..< p.ops.len:
              if p.ops[i].cacheMiss:
                let fields =
                  if cachedFieldsPerOp.len > 0:
                    cachedFieldsPerOp[i]
                  else:
                    @[]
                conn.addStmtCache(
                  p.ops[i].sql, CachedStmt(name: p.ops[i].stmtName, fields: fields)
                )
            break recvLoop
          else:
            discard
        await conn.fillRecvBuf(timeout)

    when hasChronos:
      # Normal path: drain sendFut to propagate any stored write error.
      await sendFut
  except CatchableError as e:
    when hasChronos:
      # Abnormal path (recv error, cancellation, failed stored write):
      # ensure sendFut never escapes as an unhandled Future.
      if not sendFut.finished:
        try:
          await cancelAndWait(sendFut)
        except CatchableError:
          discard
      else:
        try:
          await sendFut
        except CatchableError:
          discard
    raise e

  return results

proc execute*(
    p: Pipeline, timeout: Duration = ZeroDuration
): Future[seq[PipelineResult]] {.async.} =
  ## Execute all queued pipeline operations in a single round trip.
  ## On timeout, the connection is marked csClosed (protocol out of sync).
  ## When `p.autoReset` is true, the pipeline is reset on exit (including on
  ## raise) so it can be safely reused.
  var results: seq[PipelineResult]
  try:
    if p.ops.len == 0:
      return @[]
    withConnTracing(
      p.conn,
      onPipelineStart,
      onPipelineEnd,
      TracePipelineStartData(opCount: p.ops.len),
      TracePipelineEndData,
      TracePipelineEndData(),
    ):
      if timeout > ZeroDuration:
        try:
          results = await executeImpl(p, timeout).wait(timeout)
        except AsyncTimeoutError:
          p.conn.invalidateOnTimeout("Pipeline execute timed out")
      else:
        results = await executeImpl(p, timeout)
  finally:
    if p.autoReset:
      p.reset()
  return results

proc executeIsolatedImpl(
    p: Pipeline, timeout: Duration = ZeroDuration
): Future[IsolatedPipelineResults] {.async.} =
  ## Execute pipeline ops with per-query SYNC for error isolation.
  ## Each op gets its own ReadyForQuery; a failed op does not abort others.
  let conn = p.conn
  conn.checkReady()
  conn.state = csBusy

  let cachedStmts = buildSendPhase(p, perOpSync = true)
  when hasChronos:
    # Same concurrent-send pattern as executeImpl: the write drains while the
    # recv loop consumes per-op ReadyForQuery messages. Per-op SYNC still
    # provides error isolation; only the IO scheduling differs.
    var sendFut = conn.sendBufMsg()
  else:
    await conn.sendBufMsg()

  # Receive Phase (per-op ReadyForQuery)
  var results = newSeq[PipelineResult](p.ops.len)
  var errors = newSeq[ref CatchableError](p.ops.len)

  # Initialize query results
  for i in 0 ..< p.ops.len:
    if p.ops[i].kind == pokQuery:
      results[i] = PipelineResult(kind: prkQuery)
      if p.ops[i].cacheHit:
        let c = cachedStmts[i]
        results[i].queryResult.fields = c.fields
        if p.ops[i].resultFormats.len > 0 and c.colFmts.len > 0:
          for j in 0 ..< results[i].queryResult.fields.len:
            results[i].queryResult.fields[j].formatCode = c.colFmts[j]
        if results[i].queryResult.fields.len > 0:
          results[i].queryResult.data =
            newRowData(int16(results[i].queryResult.fields.len), c.colFmts, c.colOids)
          results[i].queryResult.data.fields = results[i].queryResult.fields
    else:
      results[i] = PipelineResult(kind: prkExec)

  try:
    for opIdx in 0 ..< p.ops.len:
      var opError: ref PgQueryError
      var cachedFields: seq[FieldDescription]

      block opRecv:
        while true:
          var rowData: RowData = nil
          var rowCount: ptr int32 = nil
          if p.ops[opIdx].kind == pokQuery:
            rowData = results[opIdx].queryResult.data
            rowCount = addr results[opIdx].queryResult.rowCount

          while (let opt = conn.nextMessage(rowData, rowCount); opt.isSome):
            let msg = opt.get
            case msg.kind
            of bmkParseComplete, bmkBindComplete, bmkCloseComplete:
              discard
            of bmkParameterDescription:
              discard
            of bmkRowDescription:
              if p.ops[opIdx].kind == pokQuery:
                if p.ops[opIdx].cacheMiss:
                  cachedFields = msg.fields
                  results[opIdx].queryResult.fields = msg.fields
                  var cf: seq[int16]
                  var co: seq[int32]
                  if p.ops[opIdx].resultFormats.len > 0:
                    cf = newSeq[int16](msg.fields.len)
                    co = newSeq[int32](msg.fields.len)
                    for j in 0 ..< msg.fields.len:
                      co[j] = msg.fields[j].typeOid
                      if p.ops[opIdx].resultFormats.len == 1:
                        results[opIdx].queryResult.fields[j].formatCode =
                          p.ops[opIdx].resultFormats[0]
                        cf[j] = p.ops[opIdx].resultFormats[0]
                      elif j < p.ops[opIdx].resultFormats.len:
                        results[opIdx].queryResult.fields[j].formatCode =
                          p.ops[opIdx].resultFormats[j]
                        cf[j] = p.ops[opIdx].resultFormats[j]
                  results[opIdx].queryResult.data =
                    newRowData(int16(msg.fields.len), cf, co)
                  results[opIdx].queryResult.data.fields =
                    results[opIdx].queryResult.fields
                  rowData = results[opIdx].queryResult.data
                  rowCount = addr results[opIdx].queryResult.rowCount
                else:
                  results[opIdx].queryResult.fields = msg.fields
                  results[opIdx].queryResult.data = newRowData(int16(msg.fields.len))
                  results[opIdx].queryResult.data.fields =
                    results[opIdx].queryResult.fields
                  rowData = results[opIdx].queryResult.data
                  rowCount = addr results[opIdx].queryResult.rowCount
            of bmkNoData:
              discard
            of bmkCommandComplete:
              if p.ops[opIdx].kind == pokExec:
                results[opIdx].commandResult = initCommandResult(msg.commandTag)
              else:
                results[opIdx].queryResult.commandTag = msg.commandTag
            of bmkEmptyQueryResponse:
              discard
            of bmkErrorResponse:
              if opError == nil:
                opError = newPgQueryError(msg.errorFields)
            of bmkReadyForQuery:
              conn.txStatus = msg.txStatus
              if opError != nil:
                if opError.sqlState == "26000" and p.ops[opIdx].cacheHit:
                  conn.removeStmtCache(p.ops[opIdx].sql)
                errors[opIdx] = opError
              elif p.ops[opIdx].cacheMiss:
                conn.addStmtCache(
                  p.ops[opIdx].sql,
                  CachedStmt(name: p.ops[opIdx].stmtName, fields: cachedFields),
                )
              break opRecv
            else:
              discard
          await conn.fillRecvBuf(timeout)

    when hasChronos:
      # Normal path: drain sendFut to propagate any stored write error.
      await sendFut
  except CatchableError as e:
    when hasChronos:
      # Abnormal path: cancel or drain sendFut so the Future never leaks.
      if not sendFut.finished:
        try:
          await cancelAndWait(sendFut)
        except CatchableError:
          discard
      else:
        try:
          await sendFut
        except CatchableError:
          discard
    raise e

  conn.state = csReady
  return IsolatedPipelineResults(results: results, errors: errors)

proc executeIsolated*(
    p: Pipeline, timeout: Duration = ZeroDuration
): Future[IsolatedPipelineResults] {.async.} =
  ## Execute all queued pipeline operations with per-query error isolation.
  ## Each operation gets its own SYNC message, so a failed operation does not
  ## abort subsequent ones. Returns results and per-op errors.
  ## On timeout, the connection is marked csClosed (protocol out of sync).
  ## When `p.autoReset` is true, the pipeline is reset on exit (including on
  ## raise) so it can be safely reused.
  var ir: IsolatedPipelineResults
  try:
    if p.ops.len == 0:
      return IsolatedPipelineResults(results: @[], errors: @[])
    withConnTracing(
      p.conn,
      onPipelineStart,
      onPipelineEnd,
      TracePipelineStartData(opCount: p.ops.len),
      TracePipelineEndData,
      TracePipelineEndData(),
    ):
      if timeout > ZeroDuration:
        try:
          ir = await executeIsolatedImpl(p, timeout).wait(timeout)
        except AsyncTimeoutError:
          p.conn.invalidateOnTimeout("Pipeline executeIsolated timed out")
      else:
        ir = await executeIsolatedImpl(p, timeout)
  finally:
    if p.autoReset:
      p.reset()
  return ir
