import os, unittest, strutils, times

const pqlibPath = currentSourcePath().parentDir / "greskewelbox" / "bin" / "16.9.0" / "darwin" / "lib"
const greskewel_lib = pqlibPath / "libpq.dylib"

import pkg/db_connector/db_postgres
import pkg/greskewel

import ../src/ozark

var greskew = initEmbeddedPostgres(
  PostgresConfig(
    basePath: getCurrentDir() / "tests" / "greskewelbox",
  )
)

newModel Users:
  id {.pk.}: Serial
  username {.unique.}: Varchar(50)
  name: Varchar(100)
  email {.notnull, unique.}: Varchar(100)
  created_at {.notnull.}: TimestampTz

newModel SubscriptionPlan:
  id {.pk.}: Serial
  name {.notnull, unique.}: Varchar(50)
  price {.notnull.}: Money

newModel Subscriptions:
  id {.pk.}: Serial
  user_id: Users.id
  plan {.notnull.}: SubscriptionPlan.id
  created_at {.notnull.}: TimestampTz

{.push dynlib: greskewel_lib.}
test "init embedded postgres and create tables":
  greskew.init()
  greskew.start()

  initOzarkDatabase("localhost", "postgres", "postgres", "postgres", Port(5432))
  withDB do:
    Models.table(Users).prepareTable().exec()
    Models.table(Users).dropTable(cascade = true).exec()
    Models.table(Users).prepareTable().exec()
    Models.table(SubscriptionPlan).prepareTable().exec()
    Models.table(Subscriptions).prepareTable().exec()

  initOzarkPool(15)

suite "INSERT and SELECT queries":
  test "insert and select data":
    withDBPool do:
      let id = Models.table(Users).insert({
        name: "John Doe",
        username: "johndoe",
        email: "johndoe@example.com",
        created_at: $now()
      }).execGet() # returns the id of the inserted row

      let res = Models.table(Users).selectAll()
                      .where("id", $id)
                      .getAll()

      check res.isEmpty == false
      check parseInt(res.entries[0].id) == id
      check res.entries[0].name == "John Doe"
      check res.entries[0].username == "johndoe"
      check res.entries[0].email == "johndoe@example.com"

  test "select specific columns":
    withDBPool do:
      let res = Models.table(Users)
                      .select(["name", "email"])
                      .where("name", "John Doe").get()
      check res.isEmpty == false
      check res.get(0).name == "John Doe"
      check res.get(0).email == "johndoe@example.com"
      check res.get(0).username == "" # not selected, should be empty

suite "WHERE queries":
  test "where query":
    withDBPool do:
      let res = Models.table(Users)
                      .select("name")
                      .where("name", "John Doe").get()
      check res.isEmpty == false
      # check res.get(0).name == "John Doe"

  test "whereNot query":
    withDBPool do:
      let res = Models.table(Users)
                      .select("name")
                      .whereNot("name", "John Doe").get()
      check res.isEmpty

  test "orWhere query":
    withDBPool do:
      let res = Models.table(Users)
                      .select("name")
                      .where("name", "Ghost")
                      .orWhere("name", "John Doe").get()
      check res.isEmpty == false
      check res.get(0).name == "John Doe"
  
  test "orWhereNot query":
    withDBPool do:
      let res = Models.table(Users)
                      .select("name")
                      .whereNot("name", "John Doe")
                      .orWhereNot("name", "Ghost").get()
      check res.isEmpty == false
      check res.get(0).name == "John Doe"
  

suite "LIKE queries":
  test "like query":
    withDBPool do:
      let res = Models.table(Users).select("name")
                      .whereLike("name", "Jo").get()
      check res.isEmpty == false
      check res.get(0).name == "John Doe"

  test "whereStartsLike query":
    withDBPool do:
      let res = Models.table(Users).select("name")
                      .whereStartsLike("name", "Jo").get()
      check res.isEmpty == false
      check res.get(0).name == "John Doe"
  

  test "whereEndsLike query":
    withDBPool do:
      let res = Models.table(Users).select("name")
                      .whereEndsLike("name", "oe").get()
      check res.isEmpty == false
      check res.get(0).name == "John Doe"
  
  test "whereNotLike query":
    withDBPool do:
      let res = Models.table(Users).select("name")
                      .whereNot("name", "Ghost").get()
      check res.isEmpty == false
      check res.get(0).name == "John Doe"

  test "wereNotStartsLike query":
    withDBPool do:
      let res = Models.table(Users).select("name")
                      .whereNotStartsLike("name", "Gh").get()
      check res.isEmpty == false
      check res.get(0).name == "John Doe"

  test "whereNotEndsLike query":
    withDBPool do:
      let res = Models.table(Users).select("name")
                      .whereNotEndsLike("name", "st").get()
      check res.isEmpty == false
      check res.get(0).name == "John Doe"

suite "IN queries":
  test "whereNotIn query":
    withDBPool do:
      let res = Models.table(Users).select("name")
                      .whereNotIn("name", "John Doe").get()
      check res.isEmpty == true

suite "Resumable Queries":
  test "chain where clauses based on runtime conditions":
    withDBPool do:
      var baseQuery = Models.table(Users).select("name").extractSQL()
      let filterByName = true
      if filterByName:
        baseQuery = baseQuery.fromSQL().where("name", "John Doe").extractSQL()

      baseQuery = baseQuery.fromSQL().whereIn("email", "johndoe@example.com").extractSQL()
      let res = baseQuery.fromSQL().getAll()
      check res.isEmpty == false
      check res.get(0).name == "John Doe"

  test "chain where clauses with whereNot based on runtime conditions":
    withDBPool do:
      var baseQuery = Models.table(Users).select("name").extractSQL()
      var emailAddress: string
      let filterByName = true
      if filterByName:
        emailAddress = "johndoe@example.com"
        baseQuery = baseQuery.fromSQL().whereNot("name", "Ghost").extractSQL()
      else:
        emailAddress = "none@example.com"

      baseQuery = baseQuery.fromSQL().whereIn("email", emailAddress).extractSQL()
      let res = baseQuery.fromSQL().getAll()
      check res.isEmpty == false
      check res.get(0).name == "John Doe"

suite "RAW queries":
  test "raw where query":
    withDBPool do:
      let res = Models.rawSQL("SELECT name FROM users WHERE name = $1", "Alice")
                       .getWith(Users)
      assert res.isEmpty
  test "raw query with subqueries":
    withDBPool do:
      let res = Models.rawSQL("""
SELECT 
  users.*,
  (SELECT COUNT(*) FROM subscriptions WHERE subscriptions.user_id = users.id) AS subscriptions_count
FROM users ORDER BY users.id DESC LIMIT 20 OFFSET 0;""").getWith(Users)
{.pop.}

test "close embedded postgres":
  greskew.stop()
  greskew.dispose()