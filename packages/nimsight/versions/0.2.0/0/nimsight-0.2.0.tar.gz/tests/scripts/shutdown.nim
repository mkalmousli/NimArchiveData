#> :wait textDocument/publishDiagnostics
#> :Shutdown
