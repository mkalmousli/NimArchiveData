# MIT License
# 
# Copyright (c) 2020-2021 Francesco Cameli
# 
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
# 
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

import ../../lang/omni_call_types
import ../alloc/omni_alloc
import ../data/omni_data
import ../auto_mem/omni_auto_mem
import ../math/omni_math
from   ../stdlib/omni_stdlib import linear_interp

type
    Delay_omni_struct* = object
        mask  : int
        phase : int
        data  : Data[float]

    Delay* = ptr Delay_omni_struct

    Delay_omni_struct_ptr* = Delay

proc Delay_omni_struct_new*[S : SomeNumber](size : S = int(0), samplerate : float, bufsize : int, omni_struct_type : typedesc[Delay_omni_struct_ptr], omni_auto_mem : Omni_AutoMem, omni_call_type : typedesc[Omni_CallType] = Omni_InitCall) : Delay {.inline.} =
    #Trying to allocate in perform block!
    when omni_call_type is Omni_PerformCall:
        {.fatal: "struct 'Delay': attempting to allocate memory in the 'perform' or 'sample' blocks.".}

    #If size <= 0 (default), delay length will be samplerate
    var actual_size = int(size)
    if actual_size <= 0:
        actual_size = int(samplerate)

    #Allocate obj
    result = cast[Delay](omni_alloc0(sizeof(Delay_omni_struct), omni_auto_mem))

    #Allocate data
    let 
        delay_length = int(nextPowerOfTwo(actual_size))
        data  = Data_omni_struct_new(delay_length, G1=float, samplerate=samplerate, bufsize=bufsize, omni_struct_type=Data_omni_struct_ptr, omni_auto_mem=omni_auto_mem, omni_call_type=omni_call_type)
        mask  = int(delay_length - 1)

    #Register obj (data has already been registered in Data.omni_struct_new)
    omni_auto_mem.omni_auto_mem_register_child(result)

    #Assign values
    result.mask = mask
    result.phase = 0
    result.data = data

#As any other struct
proc omni_check_datas_validity*(obj : Delay, samplerate : float, bufsize : int, omni_auto_mem : Omni_AutoMem, omni_call_type : typedesc[Omni_CallType] = Omni_InitCall) : void =
    discard

#Read proc (uses linear interp)
proc read*[Y : SomeNumber](delay : Delay, delay_time : Y) : float {.inline.} =
    let 
        float_delay_time = float(delay_time)
        frac : float = float_delay_time - delay_time
        index  = (delay.phase - int(delay_time))
        index1 = index and delay.mask
        index2 = (index + 1) and delay.mask

    return float(linear_interp(frac, delay.data[index1], delay.data[index2]))

#Write proc
proc write*[Y : SomeNumber](delay : Delay, val : Y) : void {.inline.} =
    delay.data[delay.phase] = float(val)
    delay.phase = (delay.phase + 1) and delay.mask

#Infos
proc len*(delay : Delay) : int {.inline.} =
    return delay.data.len

proc length*(delay : Delay) : int {.inline.} =
    return delay.data.len

proc size*(delay : Delay) : int {.inline.} =
    return delay.data.len
