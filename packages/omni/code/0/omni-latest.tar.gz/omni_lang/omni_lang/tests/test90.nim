struct Ah:
  a.sometn
