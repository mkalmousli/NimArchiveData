import std/enumutils

type
  Reader* = object
    pos: int32
    len*: int32
    data*: ptr UncheckedArray[byte]

proc empty*(r: var Reader): bool =
  r.pos >= r.len

proc next*[T](r: var Reader, _: typedesc[T], min: T = low(T), max: T = high(T)): T =
  var
    idx = int32(0)
    temp: uint64

  while r.pos < r.len and idx < sizeof(T):
    temp = temp shl 8
    temp = temp or uint64(r.data[r.pos])
    r.pos += 1
    idx += 1

  when T is enum:
    var
      count = int32(0)
    for _ in items(T):
      inc count, 1

    result = low(T)
    idx = int32(temp) mod count

    for val in items(T):
      if idx <= 0:
        result = val
        break

      dec idx, 1
    return

  elif T is SomeOrdinal:
    let
      n = uint64(max) - uint64(min)

    result = min
    if n > 0:
      result = cast[T](uint64(min) + (temp mod n))
    return

  else:
    assert false, "unreachable"
