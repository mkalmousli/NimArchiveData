import buju
import buju/core
import buju/dumps

import ./reader

when defined(linux):
  import std/posix

const
  MAX_NODES_COUNT = high(int32) - 1

type
  Action = enum
    NEW
    SET_LAYOUT
    SET_ALIGN
    SET_MAIN_AXIS_ALIGN
    SET_CROSS_AXIS_ALIGN
    SET_CROSS_AXIS_LINE_ALIGN
    SET_WRAP
    SET_SIZE
    SET_GAP
    SET_MARGIN
    SET_PADDING
    INSERT_CHILD
    REMOVE_CHILD
    COMPUTE

proc hasChild(ctx: var Context, parentID, childID: NodeID): bool =
  when defined(debug):
    var
      c = childID
    while not c.isNil:
      let
        n = ctx.addr.node(c)
      assert not n.isNil
      if n.parent == parentID:
        result = true
        break

      c = n.parent

proc hasDirectChild(ctx: var Context, parentID, childID: NodeID): bool =
  when defined(debug):
    var
      n = ctx.addr.node(childID)
    n.parent == parentID

proc dump(ctx: var Context) =
  when defined(debug):
    for idx in 0 ..< ctx.nodes.len:
      let
        n = ctx.nodes[idx].addr
      echo "n: ", n.id, " parent: ", n.parent, " firstChild: ", n.firstChild,
          " lastChild: ", n.lastChild, " nextSibling: ", n.nextSibling,
          " prevSibling: ", n.prevSibling

proc fuzzBody(p: var Reader, ctx: var Context, root: var NodeID) =
  var
    nodes: seq[NodeID]

  while not p.empty:
    if nodes.len == 0:
      let
        n = ctx.node()
      nodes.add(n)
      continue

    case p.next(Action):
    of NEW:
      if nodes.len < MAX_NODES_COUNT:
        let
          n = ctx.node()
        nodes.add(n)

    of SET_LAYOUT:
      let
        idx = p.next(int32, 0, int32(nodes.len - 1))
        n = nodes[idx]
        layout = p.next(Layout)
      ctx.setLayout(n, layout)

    of SET_ALIGN:
      let
        idx = p.next(int32, 0, int32(nodes.len - 1))
        n = nodes[idx]
        count = p.next(int32, 0, 4)

      var
        aligns: set[Align]
      for idx in 0 ..< count:
        let
          align = p.next(Align)
        aligns.incl(align)

      ctx.setAlign(n, aligns)

    of SET_MAIN_AXIS_ALIGN:
      let
        idx = p.next(int32, 0, int32(nodes.len - 1))
        n = nodes[idx]
        mainAxisAlign = p.next(MainAxisAlign)
      ctx.setMainAxisAlign(n, mainAxisAlign)

    of SET_CROSS_AXIS_ALIGN:
      let
        idx = p.next(int32, 0, int32(nodes.len - 1))
        n = nodes[idx]
        crossAxisAlign = p.next(CrossAxisAlign)
      ctx.setCrossAxisAlign(n, crossAxisAlign)

    of SET_CROSS_AXIS_LINE_ALIGN:
      let
        idx = p.next(int32, 0, int32(nodes.len - 1))
        n = nodes[idx]
        crossAxisLineAlign = p.next(CrossAxisLineAlign)
      ctx.setCrossAxisLineAlign(n, crossAxisLineAlign)

    of SET_WRAP:
      let
        idx = p.next(int32, 0, int32(nodes.len - 1))
        n = nodes[idx]
        wrap = p.next(Wrap)
      ctx.setWrap(n, wrap)

    of SET_SIZE:
      let
        idx = p.next(int32, 0, int32(nodes.len - 1))
        n = nodes[idx]
        w = p.next(int32, 0, 100000)
        h = p.next(int32, 0, 100000)
        size = [float32(w), float32(h)]
      ctx.setSize(n, size)

    of SET_GAP:
      let
        idx = p.next(int32, 0, int32(nodes.len - 1))
        n = nodes[idx]
        w = p.next(int32, 0, 100000)
        h = p.next(int32, 0, 100000)
        gap = [float32(w), float32(h)]
      ctx.setGap(n, gap)

    of SET_MARGIN:
      let
        idx = p.next(int32, 0, int32(nodes.len - 1))
        n = nodes[idx]
        l = p.next(int32, 0, 100000)
        t = p.next(int32, 0, 100000)
        r = p.next(int32, 0, 100000)
        b = p.next(int32, 0, 100000)
        margin = [float32(l), float32(t), float32(r), float32(b)]
      ctx.setMargin(n, margin)

    of SET_PADDING:
      let
        idx = p.next(int32, 0, int32(nodes.len - 1))
        n = nodes[idx]
        l = p.next(int32, 0, 100000)
        t = p.next(int32, 0, 100000)
        r = p.next(int32, 0, 100000)
        b = p.next(int32, 0, 100000)
        padding = [float32(l), float32(t), float32(r), float32(b)]
      ctx.setPadding(n, padding)

    of INSERT_CHILD:
      let
        idx1 = p.next(int32, 0, int32(nodes.len - 1))
        idx2 = p.next(int32, 0, int32(nodes.len - 1))
        n1 = nodes[idx1]
        n2 = nodes[idx2]

      if n1 == n2 or ctx.hasChild(n2, n1):
        continue

      when defined(debug):
        let
          n = ctx.addr.node(n2)
        if not n.parent.isNil:
          continue

      ctx.insertChild(n1, n2)

    of REMOVE_CHILD:
      let
        idx1 = p.next(int32, 0, int32(nodes.len - 1))
        idx2 = p.next(int32, 0, int32(nodes.len - 1))
        n1 = nodes[idx1]
        n2 = nodes[idx2]

      if n1 == n2 or not ctx.hasDirectChild(n1, n2):
        continue

      when defined(debug):
        let
          n = ctx.addr.node(n2)
        if n.parent.isNil:
          continue

      ctx.removeChild(n1, n2)

    of COMPUTE:
      let
        idx = p.next(int32, 0, int32(nodes.len - 1))
        n = nodes[idx]
      root = n
      ctx.compute(n)

    if nodes.len > 0:
      root = nodes[0]
      ctx.compute(nodes[0])

proc initialize(): cint {.exportc: "LLVMFuzzerInitialize".} =
  {.emit: "N_CDECL(void, NimMain)(void); NimMain();".}

proc testOneInput(data: ptr UncheckedArray[byte], len: int): cint {.
    exportc: "LLVMFuzzerTestOneInput", raises: [].} =
  result = 0

  var
    root: NodeID
    ctx: Context
    reader = Reader(data: data, len: int32(len))
    hasError = false

  try:
    fuzzBody(reader, ctx, root)
  except Exception as e:
    hasError = true
    echo getStackTrace(e)

  if hasError:
    dump(ctx)

    try:
      let
        json = dumpJson(ctx, root)

      writeFile("fuzzer.json", json)
    except:
      discard

    when defined(linux):
      discard kill(getpid(), SIGSEGV)
