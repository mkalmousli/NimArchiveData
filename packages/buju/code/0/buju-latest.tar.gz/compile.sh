#! /bin/bash

set -eu

# nim c -d:release -d:danger bench.nim
# nim c -d:debug -d:bujuDumpResult bench.nim

# nim c -d:release example.nim

# nim js -d:danger -d:release tools/viewer/app.nim
# python assets/tpl.py

nim c --nimcache:nimcache -d:debug --debugger:native --lineDir:off --passC:"-g" --cc:clang -t:"-fsanitize=fuzzer,address,undefined" -l:"-fsanitize=fuzzer,address,undefined" -d:nosignalhandler --nomain:on -o:fuzzer tools/fuzzer/app.nim
