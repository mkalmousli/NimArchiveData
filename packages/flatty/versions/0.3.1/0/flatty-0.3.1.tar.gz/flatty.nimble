# Package

version       = "0.3.1"
author        = "Andre von Houck"
description   = "Flatty - tools and serializer for plain flat binary files."
license       = "MIT"
srcDir        = "src"

# Dependencies

requires "nim >= 1.0.0"
