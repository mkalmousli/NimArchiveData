import
  std/[intsets, json, options, tables, sets],
  flatty

when not defined(js):
  import std/[asyncdispatch, nativesockets]

# Test booleans.
doAssert true.toFlatty.fromFlatty(bool) == true
doAssert false.toFlatty.fromFlatty(bool) == false

# Test chars.
doAssert 'a'.toFlatty.fromFlatty(char) == 'a'
doAssert 'z'.toFlatty.fromFlatty(char) == 'z'
doAssert '\0'.toFlatty.fromFlatty(char) == '\0'
doAssert '\n'.toFlatty.fromFlatty(char) == '\n'

# Test numbers.
doAssert 123.toFlatty.fromFlatty(int) == 123
doAssert 123.uint.toFlatty.fromFlatty(uint) == 123.uint
doAssert 123.uint8.toFlatty.fromFlatty(uint8) == 123
doAssert 123.uint16.toFlatty.fromFlatty(uint16) == 123
doAssert 123.uint32.toFlatty.fromFlatty(uint32) == 123
doAssert 123.uint64.toFlatty.fromFlatty(uint64) == 123
doAssert 123.int8.toFlatty.fromFlatty(int8) == 123
doAssert 123.int16.toFlatty.fromFlatty(int16) == 123
doAssert 123.int32.toFlatty.fromFlatty(int32) == 123
doAssert 123.int64.toFlatty.fromFlatty(int64) == 123
doAssert cint(123).toFlatty.fromFlatty(cint) == cint(123)
doAssert cuint(123).toFlatty.fromFlatty(cuint) == cuint(123)

doAssert 123.25.toFlatty.fromFlatty(float) == 123.25
doAssert $(123.25.float32).toFlatty.fromFlatty(float32) == "123.25"
doAssert (123.25.float64).toFlatty.fromFlatty(float64) == 123.25

# Test strings.
var str: string
doAssert str.toFlatty.fromFlatty(string) == str
doAssert "".toFlatty.fromFlatty(string) == ""
doAssert "hello world".toFlatty.fromFlatty(string) == "hello world"
doAssert "乾隆己酉夏".toFlatty.fromFlatty(string) == "乾隆己酉夏"
doAssert "\0\0\0\0".toFlatty.fromFlatty(string) == "\0\0\0\0"

# Test arrays.
var seqr: seq[int]
doAssert $(seqr.toFlatty.fromFlatty(seq[int])) == $(seqr)
doAssert $(@[1, 2, 3].toFlatty.fromFlatty(seq[int])) == $(@[1, 2, 3])
doAssert $(@[1.uint8, 2, 3].toFlatty.fromFlatty(seq[uint8])) ==
  $(@[1.uint8, 2, 3])
doAssert $(@["hi", "ho", "hey"].toFlatty.fromFlatty(seq[string])) ==
  $(@["hi", "ho", "hey"])
doAssert $(@[@["hi"], @[], @[]].toFlatty.fromFlatty(seq[seq[string]])) ==
  $(@[@["hi"], @[], @[]])

# Test enums.
type RandomEnum = enum
  Left
  Right
  Top
  Bottom

doAssert Left.toFlatty().fromFlatty(RandomEnum) == Left
doAssert Right.toFlatty().fromFlatty(RandomEnum) == Right
doAssert Top.toFlatty().fromFlatty(RandomEnum) == Top
doAssert Bottom.toFlatty().fromFlatty(RandomEnum) == Bottom

# Test regular objects.
type Foo = object
  id: int
  name: string
  time: float
  active: bool

let foo = Foo(id: 32, name: "yes", time: 16.77, active: true)
doAssert foo.toFlatty().fromFlatty(Foo) == foo

# Test odd Nim object field identifiers.
type FooBar = object
  `Foo Bar`: string

let fooBar = FooBar(`Foo Bar`: "Hello World")
doAssert fooBar.toFlatty.fromFlatty(FooBar) == fooBar

when NimMajor >= 2:
  # Test default object field values.
  type Frog = object
    legs: int = 4

  let frog = Frog()
  doAssert frog.toFlatty.fromFlatty(Frog) == frog

# Test ref objects.
type Bar = ref object
  id: int
  arr: seq[int]
  foo: Foo

var bar = Bar(id: 12)
var bar2 = bar.toFlatty().fromFlatty(Bar)
doAssert bar2 != nil
doAssert bar.id == bar2.id
doAssert bar.arr.len == 0
doAssert bar.foo == Foo()

# Test nested ref objects.
type Node = ref object
  left: Node
  right: Node
var node = Node(left: Node(left: Node()))
var node2 = node.toFlatty().fromFlatty(Node)
doAssert node2.left != nil
doAssert node2.left.left != nil
doAssert node2.left.left.left == nil
doAssert node2.right == nil

# Test distinct objects
type Ts = distinct float64
var ts = Ts(123.123)
func `==`(a, b: Ts): bool = float64(a) == float64(b)
doAssert ts.toFlatty.fromFlatty(Ts) == ts

# Test tables
block:
  var table: Table[string, string]
  table["hi"] = "bye"
  table["foo"] = "bar"
  doAssert table.toFlatty.fromFlatty(Table[string, string]) == table

block:
  var table: OrderedTable[string, string]
  table["hi"] = "bye"
  table["foo"] = "bar"
  doAssert table.toFlatty.fromFlatty(OrderedTable[string, string]) == table

block:
  var table: CountTable[string]
  table.inc("hi")
  table.inc("hi")
  table.inc("foo")
  doAssert table.toFlatty.fromFlatty(type(table)) == table

block:
  var table: TableRef[string, string]
  new(table)
  table["hi"] = "bye"
  table["foo"] = "bar"
  doAssert table.toFlatty.fromFlatty(type(table)) == table

block:
  var table: OrderedTableRef[string, string]
  new(table)
  table["hi"] = "bye"
  table["foo"] = "bar"
  doAssert table.toFlatty.fromFlatty(type(table)) == table

block:
  var table: CountTableRef[string]
  new(table)
  table.inc("hi")
  table.inc("hi")
  table.inc("foo")
  doAssert table.toFlatty.fromFlatty(type(table)) == table


# Test arrays
var arr: array[3, int] = [1, 2, 3]
doAssert arr.toFlatty.fromFlatty(array[3, int]) == arr

# Test tuples
var tup: tuple[count: int, id: byte, name: string] = (1, 2.byte, "3")
doAssert tup.toFlatty.fromFlatty(tuple[count: int, id: byte, name: string]) == tup
var tup2: tuple[foo: Foo, id: uint8] = (Foo(), 1.uint8)
doAssert tup2.toFlatty.fromFlatty(tuple[foo: Foo, id: uint8]) == tup2

# Test arrays of tuples (requires forward declarations)
var arrOfTuples: array[2, (int, int)] = [(1, 2), (0, 3)]
doAssert arrOfTuples.toFlatty.fromFlatty(array[2, (int, int)]) == arrOfTuples

# Test options.
block:
  var a: Option[int] = some(123)
  var b: Option[int]
  doAssert a.toFlatty.fromFlatty(Option[int]) == a
  doAssert b.toFlatty.fromFlatty(Option[int]) == b

  type Test = object
    key: Option[Foo]

  let test = Test(key: some(foo))
  doAssert test.toFlatty.fromFlatty(Test) == test

when not defined(js):
  # Test intsets
  var intSet = initIntSet()
  for i in 0 .. 10:
    intSet.incl i
  doAssert intSet.toFlatty.fromFlatty(type(intSet)) == intSet

# Test OOP
type
  Person = ref object of RootObj
    name*: string # the * means that `name` is accessible from other modules
    age: int      # no * means that the field is hidden from other modules

  Student = ref object of Person # Student inherits from Person
    id: int
var
  student: Student
  person: Person
doAssert student.toFlatty.fromFlatty(type(student)) == student
doAssert person.toFlatty.fromFlatty(type(person)) == person

block:
  var student = Student(name: "Ada", age: 19, id: 42)
  var student2 = student.toFlatty.fromFlatty(Student)
  doAssert student2 != nil
  doAssert student2.name == student.name
  doAssert student2.age == student.age
  doAssert student2.id == student.id

  type
    ValuePerson = object of RootObj
      name: string
      age: int
    ValueStudent = object of ValuePerson
      id: int

  let valueStudent = ValueStudent(name: "Ada", age: 19, id: 42)
  doAssert valueStudent.toFlatty.fromFlatty(ValueStudent) == valueStudent

# Test Object variants
type
  NodeNumKind = enum # the different node types
    nkInt,           # a leaf with an integer value
    nkFloat,         # a leaf with a float value
  RefNode = ref object
    active: bool
    case kind: NodeNumKind # the ``kind`` field is the discriminator
    of nkInt: intVal: int
    of nkFloat: floatVal: float

  ValueNode = object
    active: bool
    case kind: NodeNumKind # the ``kind`` field is the discriminator
    of nkInt: intVal: int
    of nkFloat: floatVal: float

block:
  var nodeNum = RefNode(kind: nkFloat, active: true, floatVal: 3.14)
  var nodeNum2 = RefNode(kind: nkInt, active: false, intVal: 42)

  doAssert nodeNum.toFlatty.fromFlatty(type(nodeNum)).floatVal ==
      nodeNum.floatVal
  doAssert nodeNum2.toFlatty.fromFlatty(type(nodeNum2)).intVal ==
      nodeNum2.intVal
  doAssert nodeNum.toFlatty.fromFlatty(type(nodeNum)).active == nodeNum.active
  doAssert nodeNum2.toFlatty.fromFlatty(type(nodeNum2)).active ==
      nodeNum2.active

block:
  var nodeNum = ValueNode(kind: nkFloat, active: true, floatVal: 3.14)
  var nodeNum2 = ValueNode(kind: nkInt, active: false, intVal: 42)

  doAssert nodeNum.toFlatty.fromFlatty(type(nodeNum)).floatVal ==
      nodeNum.floatVal
  doAssert nodeNum2.toFlatty.fromFlatty(type(nodeNum2)).intVal ==
      nodeNum2.intVal
  doAssert nodeNum.toFlatty.fromFlatty(type(nodeNum)).active == nodeNum.active
  doAssert nodeNum2.toFlatty.fromFlatty(type(nodeNum2)).active ==
      nodeNum2.active

  let nodes = @[nodeNum, nodeNum2]
  let nodes2 = nodes.toFlatty.fromFlatty(type(nodes))
  doAssert nodes2[0].kind == nkFloat
  doAssert nodes2[0].floatVal == nodeNum.floatVal
  doAssert nodes2[1].kind == nkInt
  doAssert nodes2[1].intVal == nodeNum2.intVal

var jsonNode = parseJson("{\"json\": true, \"count\":20}")
doAssert jsonNode.toFlatty.fromFlatty(type(jsonNode)) == jsonNode

# Enum indexed array
block:
  type Colors = enum
    red, green, yellow, blue
  let a = [
    red: 100,
    green: 300,
    yellow: -100,
    blue: 42
  ]
  doAssert a.toFlatty.fromFlatty(a.typeof) == a

# Complex object
block:
  type Side = enum
    left, right
  type
    SubObject = object
      a: int64
      b: string
    BigObject = object
      subs: seq[SubObject]
      arr: array[Side, SubObject]
  let a = BigObject(
    subs: @[
      SubObject(a: 100, b: "Hmm"),
      SubObject(a: 20, b: "Heh")
    ],
    arr: [
      left: SubObject(a: 42, b: "Ahhh"),
      right: SubObject(a: 31415, b: "Pi")
    ]
  )
  doAssert a.toFlatty.fromFlatty(a.type) == a

block:
  # Sets
  # set is too large???
  # doAssert {1, 2, 3}.toFlatty.fromFlatty(set[int]) == {1, 2, 3}
  doAssert {'a'..'z'}.toFlatty.fromFlatty(set[char]) == {'a'..'z'}
  doAssert {1.uint8, 2.uint8}.toFlatty.fromFlatty(set[uint8]) == {1.uint8, 2.uint8}
  doAssert {1.uint16, 2.uint16}.toFlatty.fromFlatty(set[uint16]) == {1.uint16, 2.uint16}

  let hSet1 = toHashSet(["dog", "cat"])
  doAssert hSet1.toFlatty.fromFlatty(HashSet[string]) == hSet1
  let hSet2 = toOrderedSet(["dog", "cat"])
  doAssert hSet2.toFlatty.fromFlatty(OrderedSet[string]) == hSet2

  let hSet3 = toHashSet([1.1, 2.2, 3.3])
  doAssert hSet3.toFlatty.fromFlatty(HashSet[float64]) == hSet3
  let hSet4 = toOrderedSet([1.1, 2.2, 3.3])
  doAssert hSet4.toFlatty.fromFlatty(OrderedSet[float64]) == hSet4

static:
  type
    PtrObject = object
      p: pointer
      value: int
    CstringObject = object
      text: cstring
    Callback = proc (value: int): int
    CallbackObject = object
      cb: Callback
    RawAddress = distinct pointer

  doAssert not compiles(default(pointer).toFlatty)
  doAssert not compiles(default(ptr int).toFlatty)
  doAssert not compiles(default(cstring).toFlatty)
  doAssert not compiles(default(Callback).toFlatty)
  doAssert not compiles(default(RawAddress).toFlatty)
  when declared(AsyncFD):
    doAssert not compiles(default(AsyncFD).toFlatty)
    doAssert not compiles(default(seq[AsyncFD]).toFlatty)
  when declared(SocketHandle):
    doAssert not compiles(default(SocketHandle).toFlatty)
    doAssert not compiles(default(seq[SocketHandle]).toFlatty)

  doAssert not compiles(default(PtrObject).toFlatty)
  doAssert not compiles(default(CstringObject).toFlatty)
  doAssert not compiles(default(CallbackObject).toFlatty)

  doAssert not compiles(@[default(PtrObject)].toFlatty)
  doAssert not compiles([default(ptr int)].toFlatty)
  doAssert not compiles([default(cstring)].toFlatty)
  doAssert not compiles(@[default(Callback)].toFlatty)
  doAssert not compiles(@[default(RawAddress)].toFlatty)

echo "DONE"
