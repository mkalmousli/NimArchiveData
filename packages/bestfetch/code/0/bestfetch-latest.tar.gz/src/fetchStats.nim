import std/[os, osproc, strutils, strformat, math]
import elvis
import ./objects
import bytesized

const mac:bool = defined(macosx)
when mac: import plists
else: import std/parsecfg

when not mac:
  let
    osRelease = "/etc/os-release".loadConfig()
    bedrockLinux:bool = "/bedrock".dirExists()
else:
  let
    systemVersion:JsonNode = loadPlist("/System/Library/CoreServices/SystemVersion.plist")
    preferences:JsonNode = loadPlist("/Library/Preferences/SystemConfiguration/preferences.plist")

proc getUsername*(): string =
  return getEnv("USER")

proc getHostname*(): string =
  when not mac:
    const hostname:string = "/etc/hostname"

    if hostname.fileExists():
      return hostname.open.readLine
    else:
      const hostnameOpenRC:string = "/etc/conf.d/hostname"

      if hostnameOpenRC.fileExists():
        return hostnameOpenRC.loadConfig.getSectionValue("", "hostname")
      else:
        return ""
  else:
    return preferences["System"]["Network"]["HostNames"]["LocalHostName"].getStr()

proc getDistro*(): string =
  when not mac:
    if(bedrockLinux): # check for bedrock linux because otherwise it'll read the os-release file of the stratum
      return "Bedrock Linux"

    let prettyName = osRelease.getSectionValue("", "PRETTY_NAME")

    if(prettyName != ""):
      return prettyName
    else:
      return osRelease.getSectionValue("", "NAME")
  else:
    return systemVersion["ProductName"].getStr() & " " & systemVersion["ProductVersion"].getStr()

proc getDistroID*(): string =
  when not mac:
    if(bedrockLinux):
      return "bedrock"
    else:
      return osRelease.getSectionValue("", "ID")
  else:
    return "macos"

proc getKernel*(): string =
  when not mac:
    return "/proc/version".open.readLine.split(" ")[2]
  else:
    return execCmdEx("uname -sr").output.strip()

proc getArch*(): string =
  return execCmdEx("uname -m").output.splitWhitespace()[0]

proc getUptime*(): string =
  when not mac:
    return execCmdEx("uptime -p").output[3 .. ^2]
  else:
    let
      uptime:string = execCmdEx("uptime").output
      startIndex:int = uptime.find("up ") + len("up ")
      endIndex:int = uptime.find("user") - 5

    const remove = [
      (",", " "),
      ("days", " "),
      ("day", " "),
      (":", " "),
    ]

    let uptimeValues:seq[string] = (uptime[startIndex .. endIndex]).multiReplace(remove).splitWhitespace()

    return case len(uptimeValues):
      of 1:
        uptimeValues[0] & " minute" & (parseInt(uptimeValues[0]) > 1 ? "s" ! "")
      of 2:
        uptimeValues[0] & " hour" & (parseInt(uptimeValues[0]) > 1 ? "s" ! "") & ", " & uptimeValues[1] & " minute" & (parseInt(uptimeValues[1]) > 1 ? "s" ! "")
      of 3:
        uptimeValues[0] & " day" & (parseInt(uptimeValues[0]) > 1 ? "s" ! "") & ", " & uptimeValues[1] & " hour" & (parseInt(uptimeValues[1]) > 1 ? "s" ! "") & ", " & uptimeValues[2] & " minute" & (parseInt(uptimeValues[2]) > 1 ? "s" ! "")
      else:
        uptime[startIndex .. endIndex]

proc getShell*(): string =
  return getEnv("SHELL").split("/")[^1]

proc getDesktop*(): string =
  when not mac:
    var desktop:string = getEnv("DESKTOP_SESSION")

    if(desktop == ""):
      desktop = getEnv("XDG_CURRENT_DESKTOP") # some desktops (Hyprland) don't use DESKTOP_SESSION

    if(desktop == ""):
      return "none"
    else:
      return desktop
  else:
    let majorVersion:int = parseInt(systemVersion["ProductVersion"].getStr().split(".")[0])

    if majorVersion > 15:
      return "Liquid Glass"
    elif majorVersion >= 10:
      return "Aqua"
    elif majorVersion >= 8:
      return "Platinum"
    else:
      return "Classic"

proc getTerminal*(): string =
  var term:string = getEnv("TERM")

  if(term == "xterm-kitty"): return "kitty" # kitty is called "xterm-kitty" for some reason
  else: return term

proc getCPU*(): string =
  when not mac:
    let cpuinfo:string = readFile("/proc/cpuinfo")

    # model name
    let modelLocation:int = cpuinfo.find("model name")
    let model:seq[string] = cpuinfo[modelLocation .. cpuinfo.find("\n", modelLocation)].replace("model name", "").replace(":", "").splitWhitespace()

    # threads
    let threadsLocation:int = cpuinfo.rfind("processor")
    let threads:int = cpuinfo[threadsLocation .. cpuinfo.find("\n", threadsLocation)].replace("processor", "").replace(":", "").strip().parseInt() + 1

    # clockspeed
    var keepSearching:bool = true
    var clockspeed:float = 0.0
    var index:int = 0
    while keepSearching:
      let thisClockspeed = parseFloat(readFile(fmt"/sys/devices/system/cpu/cpu{index}/cpufreq/cpuinfo_max_freq").strip())
      if(thisClockspeed > clockspeed):
        clockspeed = thisClockspeed
      index += 1
      if(index >= threads - 1):
        keepSearching = false

    clockspeed = round(clockspeed / 100000) / 10

    if(model.contains("Intel(R)") and len(model) >= 3):
      return fmt"{model[2]} ({threads}) @ {clockspeed} GHz"
    elif(model.contains("AMD") and len(model) >= 4):
      return fmt"{model[1]} {model[2]} {model[3]} ({threads}) @ {clockspeed} GHz"
    else:
      return fmt"{model} ({threads}) @ {clockspeed} GHz"  # return the unformatted cpuinfo value if it can't be identified
  else:
    var cpu:string = execCmdEx("sysctl -n machdep.cpu.brand_string").output

    const remove = [
      ("(R)", ""),
      ("(TM)", ""),
      ("CPU", ""),
      ("Intel", ""),
      ("Core", ""),
      ("Apple", ""),
      ("AMD", ""), # virtual machines ?? i don't really know when an AMD processor would run macOS
    ]

    return cpu.multiReplace(remove).splitWhitespace().join(" ")

proc getMemory*(gibibytes:bool): string =
  # This method comes from btop
  let unit:Units = gibibytes ? Units.GiB ! Units.GB

  var
    total:float
    used:float
    percentUsed:int

  when not mac:
    let
      meminfo:string = readFile("/proc/meminfo")
      totalIndex:int = "MemTotal:".len()
      availableIndex:int = meminfo.find("MemAvailable:") + "MemAvailable:".len()

    # memInfo is always the first value, so can use index 0
    total = parseFloat(meminfo[totalIndex .. meminfo.find("kB")-1].strip()).convertBytes(Units.KiB, unit)
    # https://github.com/aristocratos/btop/blob/6e39144aaf5a6bc01b9f795010b0914431067183/src/linux/btop_collect.cpp#L2184
    let available = parseFloat(memInfo[availableIndex .. meminfo.find("kB", availableIndex)-1].strip()).convertBytes(Units.KiB, unit)
    if available > total:
      let freeIndex:int = meminfo.find("MemFree:") + "MemFree:".len()
      used = total - parseFloat(memInfo[freeIndex .. meminfo.find("kB", freeIndex)-1].strip()).convertBytes(Units.KiB, unit)
    else:
      used = total - available
  else:
    # https://github.com/aristocratos/btop/blob/6e39144aaf5a6bc01b9f795010b0914431067183/src/osx/btop_collect.cpp#L1226
    let
      vmstat:string = execCmdEx("vm_stat").output
      pageSizeIndex:int = vmstat.find("page size of ") + "page size of ".len()
      activeIndex:int = vmstat.find("Pages active:") + "Pages active:".len()
      wireIndex:int = vmstat.find("Pages wired down:") + "Pages wired down:".len()
      pageSize:int = parseInt(vmstat[pageSizeIndex .. vmstat.find(" ", pageSizeIndex)-1].strip())
      pagesActive:int = parseInt(vmstat[activeIndex .. vmstat.find(".", activeIndex)-1].strip())
      pagesWiredDown:int = parseInt(vmstat[wireIndex .. vmstat.find(".", wireIndex)-1].strip())

    total = parseFloat(execCmdEx("sysctl -n hw.memsize").output.strip()).convertBytes(unit)
    used = toFloat((pagesActive + pagesWiredDown) * pageSize).convertBytes(unit)

  percentUsed = toInt(math.round((used / total) * 100))

  return fmt"{$used} {$unit} / {$total} {$unit} ({$percentUsed}%)"

proc getStats*(): Stats =
  return Stats(
    username: fetchStats.getUsername(),
    hostname: fetchStats.getHostname(),
    distro: fetchStats.getDistro(),
    kernel: fetchStats.getKernel(),
    arch: fetchStats.getArch(),
    uptime: fetchStats.getUptime(),
    shell: fetchStats.getShell(),
    desktop: fetchStats.getDesktop(),
    terminal: fetchStats.getTerminal(),
    cpu: fetchStats.getCPU(),
    memory: "" # empty string because memory will be found after config initializes for gibibytes
  )