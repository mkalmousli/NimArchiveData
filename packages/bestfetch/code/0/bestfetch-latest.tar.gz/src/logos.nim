import termstyle
import std/strformat

# will make more logos for other distros in the future
# logos must be 9 lines long but the width of the line doesn't matter.
# also, the width of the lines needs to be the same for all lines
# and it has to be manually inputed into a variable because len()
# counts the escape codes that termstyle adds to the strings :(

const
  bestfetchLength:int = 14
  archLength:int = 19
  bedrockLength:int = 26
  cachyosLength:int = 21
  debianLength:int = 14
  endeavourosLength:int = 23
  fedoraLength:int = 20
  macosLength:int = 16
  nixosLength:int = 20
  popLength:int = 18
  ubuntuLength:int = 21
  voidLength:int = 21

  bestfetchLogo:array[9, string] = [
    fmt"     ____      ".blue,
    fmt"    / ".blue & "__ ".magenta & "\\     ".blue,
    fmt"   / ".blue & "/_/".magenta & "_/     ".blue,
    fmt"  / ".blue & "/_/".magenta & " /      ".blue,
    fmt" /_____/".blue & "______ ".cyan,
    fmt"       / ____".cyan & "/ ".magenta,
    fmt"      / /_     ".cyan,
    fmt"     / __".cyan & "/     ".magenta,
    fmt"    /".cyan & "_".magenta & "/        ".cyan
  ]

  archLogo:array[9, string] = [ # inspired by the pfetch arch logo
    fmt"         /\         ".cyan,
    fmt"        /  \        ".cyan,
    fmt"       /\   \       ".cyan,
    fmt"      /  \".cyan & fmt"   \      ".blue,
    fmt"     /".cyan & fmt"        \     ".blue,
    fmt"    /    __    \    ".blue,
    fmt"   /    /  \  \_\   ".blue,
    fmt"  /    |    |    \  ".blue,
    fmt" /_-'''      '''-_\ ".blue,
  ]

  bedrockLogo:array[9, string] = [ # there's no dark green :(
    fmt"-".black & fmt"\\\\\\\\\".white.bold & fmt"-----------------".black,
    fmt"--".black & fmt"\\     \\".white.bold & fmt"----------------".black,
    fmt"---".black & fmt"\\     \\".white.bold & fmt"---------------".black,
    fmt"----".black & fmt"\\     \\\\\\\\\\\\\".white.bold & fmt"---".black,
    fmt"-----".black & fmt"\\                \\".white.bold & fmt"--".black,
    fmt"------".black & fmt"\\      ______    \\".white.bold & fmt"-".black,
    fmt"-------".black & fmt"\\               //".white.bold & fmt"-".black,
    fmt"--------".black & fmt"\\             //".white.bold & fmt"--".black,
    fmt"---------".black & fmt"\\/////////////".white.bold & fmt"---".black,
  ]

  cachyosLogo:array[9, string] = [
    fmt"     _________        ".cyan,
    fmt"    /".blue & fmt"|".cyan & fmt"\'-,".blue & fmt"   /        ".cyan,
    fmt"   /".blue & fmt" |".cyan & fmt" \/".blue & fmt"___/    O    ".cyan,
    fmt"  /".blue & fmt"  | /       ".cyan & "_      ".blue,
    fmt" /___".blue & fmt"|/       |_|     ".cyan,
    fmt" \.--'".blue & fmt"\           ".cyan & fmt"/`\ ".blue,
    fmt"  \`--.\".cyan & fmt"_________".blue & fmt" \_/ ".cyan,
    fmt"   \ | /`-._    ".cyan & fmt"/     ".blue,
    fmt"    \|/_____`-.".cyan & fmt"/      ".blue
  ]

  debianLogo:array[9, string] = [
    fmt"    .______.   ".red,
    fmt"   /  ____  \  ".red,
    fmt"  /  /    \  \ ".red,
    fmt" '  '     /  / ".red,
    fmt" |   \_____./  ".red,
    fmt" '             ".red,
    fmt"  \            ".red,
    fmt"    \          ".red,
    fmt"      \        ".red
  ]

  endeavourosLogo:array[9, string] = [
    fmt"           .".red & fmt"/'\".magenta & fmt".        ".blue,
    fmt"         .'".red & fmt"/   \".magenta & fmt"'.      ".blue,
    fmt"        /".red & fmt" /     \ ".magenta & fmt"'\    ".blue,
    fmt"      .'".red & fmt" /       \  ".magenta & fmt"\   ".blue,
    fmt"     /".red & fmt"  /         \  ".magenta & fmt"\  ".blue,
    fmt"   /".red & fmt"   /           |  ".magenta & fmt"| ".blue,
    fmt" /____".red & fmt"/           /".magenta & fmt"  /  ".blue,
    fmt"     /".blue & fmt"''--____--''  ".magenta & "/   ".blue,
    fmt"    /___________--''    ".blue
  ]

  fedoraLogo:array[9, string] = [
    fmt"           ______".white & "_   ".blue,
    fmt"          / ____/".white & fmt" \  ".blue,
    fmt"         | |".white & "     | | ".blue,
    fmt"         | |___".white & "__| | ".blue,
    fmt"   ____".blue & "__| |__/".white & "___/  ".blue,
    fmt"  / __".blue & "/__| |         ".white,
    fmt" | |".blue & "     | |         ".white,
    fmt" | |".blue & "_____| |         ".white,
    fmt"  \_".blue & fmt"\_____/          ".white
  ]

  macosLogo:array[9, string] = [
    fmt"         .'.     ".green,
    fmt"        '.'      ".green,
    fmt"    ,-:~._.~:-,  ".green,
    fmt"  .` . ' . '  .` ".yellow,
    fmt" , ' . ' . ' `   ".red,
    fmt" : ' . ' . ' `,  ".red,
    fmt" ' ' . ' . ' . ` ".magenta,
    fmt"  `  . ' . ' . ' ".magenta,
    fmt"   `~._.-*-._.`  ".blue,
  ]

  nixosLogo:array[9, string] = [
    fmt"                     ",
    fmt"     \".blue & fmt"     \  /      ".cyan,
    fmt"  ____\_____".blue & fmt"\/       ".cyan,
    fmt"      /      \".cyan & "  /    ".blue,
    fmt" ____/        \".cyan & "/____ ".blue,
    fmt"    /".cyan & fmt"\        /      ".blue,
    fmt"   /".cyan & fmt"  \".blue & " _____".cyan & "/".blue & "____   ".cyan,
    fmt"      /\".blue & fmt"     \       ".cyan,
    fmt"     /  \ ".blue & fmt"    \      ".cyan
  ]

  popLogo:array[9, string] = [
    fmt"   ,'```'.         ".cyan,
    fmt"  /  ,`.  \   .~.  ".cyan,
    fmt"  \  `.'  /  '  '  ".cyan,
    fmt"   \   ,~`   | /   ".cyan,
    fmt"    \  \     '/    ".cyan,
    fmt"     \  \   .-.    ".cyan,
    fmt"      \_/   `-`    ".cyan,
    fmt" ,---------------, ".cyan,
    fmt" '~-------------~' ".cyan,
  ]

  ubuntuLogo:array[9, string] = [
    fmt"          ____/''\    ".red,
    fmt"       .'\    \__/    ".red,
    fmt"      /   \".red & fmt" _     \   ".yellow,
    fmt"  .-.'".red & "    .' '.    '  ".yellow,
    fmt" |   |".red & "   |     |---|  ".yellow,
    fmt"  '''".red & ".    '._.'    '  ".yellow,
    fmt"      \   /      _/   ".yellow,
    fmt"       `'/-___/''\    ".yellow,
    fmt"              \__/    ".yellow
  ]

  voidLogo:array[9, string] = [ # there's no dark green :(
    fmt"       \``````'~.     ".green,
    fmt"   /\   \____    '.   ".green,
    fmt"  /  \    __ `.    \  ".green,
    fmt" '   '  .`  `. '.   . ".green,
    fmt" |   | |      | |   | ".green,
    fmt" `   `. `.__.`  ,   ' ".green,
    fmt"  \    '.____   \  /  ".green,
    fmt"   `.        \   \/   ".green,
    fmt"     `~.______\       ".green
  ]

proc printLogo*(logo:string, line:int, box:bool, otherColor:proc): void =
  if(box):
    stdout.write(" │".otherColor)
  case(logo):
    of "bestfetch":
      stdout.write(bestfetchLogo[line])
    of "arch":
      stdout.write(archLogo[line])
    of "bedrock":
      stdout.write(bedrockLogo[line])
    of "cachyos":
      stdout.write(cachyosLogo[line])
    of "debian":
      stdout.write(debianLogo[line])
    of "endeavouros":
      stdout.write(endeavourosLogo[line])
    of "fedora":
      stdout.write(fedoraLogo[line])
    of "macos":
      stdout.write(macosLogo[line])
    of "nixos":
      stdout.write(nixosLogo[line])
    of "pop":
      stdout.write(popLogo[line])
    of "ubuntu":
      stdout.write(ubuntuLogo[line])
    of "void":
      stdout.write(voidLogo[line])
    else:
      stdout.write(bestfetchLogo[line])

proc getLineLength*(logo:string): int =
  case(logo):
    of "bestfetch":
      return bestfetchLength
    of "arch":
      return archLength
    of "bedrock":
      return bedrockLength
    of "cachyos":
      return cachyosLength
    of "debian":
      return debianLength
    of "endeavouros":
      return endeavourosLength
    of "fedora":
      return fedoraLength
    of "macos":
      return macosLength
    of "nixos":
      return nixosLength
    of "pop":
      return popLength
    of "ubuntu":
      return ubuntuLength
    of "void":
      return voidLength
    else:
      return bestfetchLength