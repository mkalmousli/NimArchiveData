import std/[os, linenoise, strformat, strutils, streams]
import yaml, termstyle
import ./objects.nim

const user:string = getEnv("USER")
var configDir:string

when defined(macosx):
  configDir = fmt"/Users/{user}/Library/Application Support"
else:
  configDir = fmt"/home/{user}/.config"

const defaultConfig:string = """
- # toggles
  icons: true # use nerdfont icons instead of labels
  box: true # draw a box around the fetch in unicode characters
  boxLogo: true # draw a box around the logo (requires `box` to be true)
  roundCorners: true # use round (╭) or right-angle (┌) corners
  login: false # print the login (user@hostname)
  gibibytes: true # round memory to 1024 bytes instead of 1000 to be more accurate

  # strings
  logo: auto # auto, bestfetch, arch, debian, fedora, ubuntu, nixos, endeavouros, void, bedrock, cachyos, pop
  colorSymbol: "●" # ● looks nice but can be any *reasonable* string

  # colors
  # can be set to: black, red, yellow, green, cyan, blue, magenta, or white
  titleColor: cyan
  dataColor: blue
  otherColor: magenta
"""

if dirExists(configDir):
  configDir = configDir & "/bestfetch"
else:
  echo(fmt"!!! No config directory found, trying /home/{user}/.bestfetch/ !!!".yellow)
  configDir = fmt"/home/{user}/.bestfetch"

let configPath:string = fmt"{configDir}/config.yaml"

var
  configuration*:seq[Config]
  configExists*:bool = true

if not dirExists(configDir):
  createDir(configDir)

proc resetConfig*(): void =
  when (defined(linux) or defined(macosx)):
    echo "!!! Running bestfetch on an OS other than Linux or macOS is unsupported. It may work with other UNIX-based systems !!!".red

  if fileExists(configPath): removeFile(configPath) # for args in bestfetch.nim, not needed for config.nim

  writeFile(configPath, defaultConfig)
  echo("!!! Config options (like ".yellow & "c".red & "o".yellow & "l".green & "o".cyan & "r".magenta & ") stored at ".yellow & configPath.green & " !!!".yellow)

if not fileExists(configPath):
  resetConfig()

proc loadConfig*(): Config =
  var stream = newFileStream(configPath)
  load(stream, configuration)
  stream.close()
  return configuration[0]