import ./[config, printer]

when isMainModule:
  printer.printFetch(config.loadConfig())