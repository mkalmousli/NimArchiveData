import std/[os, osproc, strutils, strformat, math]
import elvis

proc getUsername*(): string =
  return getEnv("USER")

proc getHostname*(): string =
  return execCmdEx("cat /etc/hostname").output[0 .. ^2]

proc getDistro*(): string =
  let
    distro:string = execCmdEx("cat /etc/os-release").output
    distroIndex:int = distro.find("NAME=")

  return distro[distroIndex+6 .. distro.find("\n", distroIndex)-2]

proc getDistroID*(): string =
  let
    distro: string = execCmdEx("cat /etc/os-release").output
    lines = distro.splitLines()

  for line in lines:
    if line.startsWith("ID="):
      return line[3 .. ^1]
  return "unknown"

proc getKernel*(): string =
  return execCmdEx("uname -mrs").output[0 .. ^2].split(" ")[1]

proc getArch*(): string =
  return execCmdEx("uname -mrs").output[0 .. ^2].split(" ")[2]

proc getUptime*(): string =
  return execCmdEx("uptime -p").output[3 .. ^2]

proc getShell*(): string =
  return getEnv("SHELL").split("/")[^1]

proc getDesktop*(): string =
  var desktop:string = getEnv("DESKTOP_SESSION")

  if(desktop == ""):
    desktop = getEnv("XDG_CURRENT_DESKTOP") # some desktops (Hyprland) don't use DESKTOP_SESSION

  if(desktop == ""):
    return "none"
  else:
    return desktop

proc getTerminal*(): string =
  var term:string = getEnv("TERM")

  if(term == "xterm-kitty"): return "kitty" # kitty is called "xterm-kitty" for some reason
  else: return term

proc getCPU*(): string =
  var cpu:seq[string] = execCmdEx("cat /proc/cpuinfo | grep 'model name' | head -n 1").output.splitWhitespace()

  var cpuReturn:string
  if(cpu.contains("Intel(R)") and cpu.contains("Core(TM)")):
    cpuReturn = fmt"{cpu[5]} @ {cpu[8]}"
  elif(cpu.contains("AMD")):
    cpuReturn = fmt"{cpu[4]} {cpu[5]} {cpu[6]}"
  else:
    return execCmdEx("cat /proc/cpuinfo | grep 'model name' | head -n 1").output # don't return the seq if it can't be formatted

  return cpuReturn

proc getMemory*(gibibytes:bool): string =
  let memoryString:seq[string] = execCmdEx("cat /proc/meminfo | head -n 2").output.split("\n")

  var
    memoryTotal:float = math.round(parseFloat(memoryString[0].splitWhitespace()[1]) / math.pow(gibibytes ? 1024f ! 1000f, 2), 1)
    memoryFree:float = math.round(parseFloat(memoryString[1].splitWhitespace()[1]) / math.pow(gibibytes ? 1024f ! 1000f, 2), 1)

  let units = gibibytes ? "GiB" ! "GB"
  return fmt"{$memoryTotal} {units} total, {$memoryFree} {units} free"