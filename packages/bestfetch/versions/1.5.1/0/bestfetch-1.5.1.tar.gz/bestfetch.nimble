# Package

version       = "1.5.0"
author        = "lx12ucy"
description   = "The bestest sysfetch ever"
license       = "GPL-3.0-only"
srcDir        = "src"
binDir        = "build"
bin           = @["bestfetch"]


# Dependencies
requires "nim >= 2.0.8"
requires "termstyle >= 0.1.0"
requires "elvis >= 0.5.0"
requires "yaml >= 2.1.1"
requires "bytesized >= 1.2.0"