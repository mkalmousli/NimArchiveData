import termstyle, elvis
import ./[logos, fetchStats, objects]
import std/[strformat]

proc parseColor*(color:string): proc =
  case(color):
    of "black":
      return black
    of "red":
      return red
    of "yellow":
      return yellow
    of "green":
      return green
    of "cyan":
      return cyan
    of "blue":
      return blue
    of "magenta":
      return magenta
    of "white":
      return white
    else:
      return white

var
  icons:bool
  box:bool
  boxLogo:bool
  gibibytes:bool
  titleColor:string
  dataColor:string
  otherColor:string
  logo:string
  dataIndex:int
  logoLength*:int
  stats*:Stats = fetchStats.getStats()
  width*:int

# find the longest data string length for formatting purposes
var dataVars = @[
  stats.username & "@" & stats.hostname,
  stats.distro & " " & stats.arch,
  stats.kernel,
  stats.uptime,
  stats.shell,
  stats.desktop,
  stats.terminal,
  stats.cpu
]

proc initializePrintHelpers*(configuration:Config): void =
  icons = configuration.icons
  box = configuration.box
  boxLogo = configuration.boxLogo
  gibibytes = configuration.gibibytes
  titleColor = configuration.titleColor
  dataColor = configuration.dataColor
  otherColor = configuration.otherColor
  logo = configuration.logo
  dataIndex = 0

  if(logo == "auto"):
    logo = fetchStats.getDistroID()

  logoLength = logos.getLineLength(logo);

  stats.memory = fetchStats.getMemory(gibibytes)
  dataVars.add(stats.memory)

  var longestData:int = 0
  for i in dataVars:
    if(len(i) > longestData): longestData = len(i)

  # figure out the actual width
  width = longestData + len(" │ ")
  width = icons ? width + 2 ! width + 8 # icons icons take up 3 chars and labels take 8

proc printTitle*(icon:string, label:string): void =
  if(dataIndex > 8): # if line index is past 9 lines (starts on 0) don't print logo
    if(boxLogo and box):
      stdout.write(parseColor(otherColor)(" │"))

    for i in 0..logoLength:
      stdout.write(" ")
  else:
    logos.printLogo(logo, dataIndex, (boxLogo and box), parseColor(otherColor))

  if(box): stdout.write(parseColor(otherColor)("│"))
  stdout.write(icons ? fmt" {parseColor(titleColor)(icon)} " ! fmt" {parseColor(titleColor)(label).bold}", parseColor(otherColor)(" │ "))
  dataIndex += 1

proc printTitleData*(icon:string, label:string, data:string): void =
  printTitle(icon, label)
  stdout.write(parseColor(dataColor)(data))

proc printEndWallCharCount*(dataCharacters:int): void =
  if(box):
    var space = width - dataCharacters
    space = icons ? space - 4 ! space - 10
    space -= 2 # i dont know why but it needs extra spaces removed

    for i in 0..space:
      stdout.write(" ")

    echo(parseColor(otherColor)("│"))
  else:
    echo()

proc printEndWall*(data:string): void =
  printEndWallCharCount(len(data))