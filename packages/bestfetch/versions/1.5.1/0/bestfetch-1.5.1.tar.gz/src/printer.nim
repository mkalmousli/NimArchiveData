import ./[objects, printHelpers]
import termstyle, elvis

proc printFetch*(configuration:Config): void =
  printHelpers.initializePrintHelpers(configuration)

  var stats:Stats = printHelpers.stats

  let
    dataC:proc = printHelpers.parseColor(configuration.dataColor)
    otherC:proc = printHelpers.parseColor(configuration.otherColor)

  if(configuration.box):
    if(configuration.boxLogo):
      stdout.write(configuration.roundCorners ? " ╭".otherC ! " ┌".otherC)

      for i in 0..logoLength:
        stdout.write("─".otherC)

      stdout.write("┬".otherC)
    else:
      for i in 0..logoLength:
        stdout.write(" ")

      stdout.write(configuration.roundCorners ? "╭".otherC ! "┌".otherC)

    for i in 0..(configuration.icons ? 3 ! 9):
      stdout.write("─".otherC)

    stdout.write("┬".otherC)

    for i in (configuration.icons ? 5 ! 11)..width:
      stdout.write("─".otherC)

    echo(configuration.roundCorners ? "╮".otherC ! "┐".otherC)

  if(configuration.login):
    printTitle("", "   login")
    stdout.write(stats.username.dataC & "@".otherC.bold & stats.hostname.dataC)
    printEndWall(stats.username & "@" & stats.hostname)

  printTitle("󰌢", "  distro")
  stdout.write(stats.distro.dataC & " " & stats.arch.otherC.bold)
  printEndWall(stats.distro & " " & stats.arch)

  printTitleData("", "  kernel", stats.kernel)
  printEndWall(stats.kernel)

  printTitleData("", "  uptime", stats.uptime)
  printEndWall(stats.uptime)

  printTitleData("", "   shell", stats.shell)
  printEndWall(stats.shell)

  printTitleData("󰧨", " desktop", stats.desktop)
  printEndWall(stats.desktop)

  printTitleData("", "terminal", stats.terminal)
  printEndWall(stats.terminal)

  printTitleData("", "     cpu", stats.cpu)
  printEndWall(stats.cpu)

  printTitleData("", "  memory", stats.memory)
  printEndWall(stats.memory)

  printTitle("", "  colors")
  stdout.write(
    configuration.colorSymbol.black & " " &
    configuration.colorSymbol.red & " " &
    configuration.colorSymbol.yellow & " " &
    configuration.colorSymbol.green & " " &
    configuration.colorSymbol.cyan & " " &
    configuration.colorSymbol.blue & " " &
    configuration.colorSymbol.magenta & " " &
    configuration.colorSymbol.white
  )

  var colorSymbolLen:int
  if(configuration.colorSymbol == "●"): # the circle symbol doesnt get counted as one char for some reason
    colorSymbolLen = 1
  else:
    colorSymbolLen = len(configuration.colorSymbol)

  colorSymbolLen *= 8 # 8 colors
  colorSymbolLen += 7 # 7 spaces

  printEndWallCharCount(colorSymbolLen)

  if(configuration.box):
    if(configuration.boxLogo):
      stdout.write(configuration.roundCorners ? " ╰".otherC ! " └".otherC)

      for i in 0..logoLength:
        stdout.write("─".otherC)

      stdout.write("┴".otherC)
    else:
      for i in 0..logoLength:
        stdout.write(" ")

      stdout.write(configuration.roundCorners ? "╰".otherC ! "└".otherC)

    for i in 0..(configuration.icons ? 3 ! 9):
      stdout.write("─".otherC)
    stdout.write("┴".otherC)
    for i in (configuration.icons ? 5 ! 11)..width:
      stdout.write("─".otherC)
    echo(configuration.roundCorners ? "╯".otherC ! "┘".otherC)