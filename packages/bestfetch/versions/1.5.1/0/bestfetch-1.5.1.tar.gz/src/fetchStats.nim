import std/[os, osproc, strutils, strformat, math, parsecfg]
import elvis
import ./objects
import bytesized

proc getUsername*(): string =
  return getEnv("USER")

proc getHostname*(): string =
  const
    hostname:string = "/etc/hostname"
    hostnameOpenRC:string = "/etc/conf.d/hostname"

  if hostname.fileExists():
    return hostname.open.readLine
  elif hostnameOpenRC.fileExists():
    return hostnameOpenRC.loadConfig.getSectionValue("", "hostname")
  else:
    return ""

let
  osRelease = "/etc/os-release".loadConfig()
  bedrockLinux:bool = "/bedrock".dirExists() # check for bedrock linux because otherwise it'll read the os-release file of the stratum

proc getDistro*(): string =
  if(bedrockLinux):
    return "Bedrock Linux"

  let prettyName = osRelease.getSectionValue("", "PRETTY_NAME")

  if(prettyName != ""):
    return prettyName
  else:
    return osRelease.getSectionValue("", "NAME")

proc getDistroID*(): string =
  if(bedrockLinux):
    return "bedrock"
  else:
    return osRelease.getSectionValue("", "ID")

proc getKernel*(): string =
  return "/proc/version".open.readLine.split(" ")[2]

proc getArch*(): string =
  return execCmdEx("uname -m").output.splitWhitespace()[0]

proc getUptime*(): string =
  return execCmdEx("uptime -p").output[3 .. ^2]

proc getShell*(): string =
  return getEnv("SHELL").split("/")[^1]

proc getDesktop*(): string =
  var desktop:string = getEnv("DESKTOP_SESSION")

  if(desktop == ""):
    desktop = getEnv("XDG_CURRENT_DESKTOP") # some desktops (Hyprland) don't use DESKTOP_SESSION

  if(desktop == ""):
    return "none"
  else:
    return desktop

proc getTerminal*(): string =
  var term:string = getEnv("TERM")

  if(term == "xterm-kitty"): return "kitty" # kitty is called "xterm-kitty" for some reason
  else: return term

proc getCPU*(): string =
  let cpuinfo:string = readFile("/proc/cpuinfo")

  # model name
  let modelLocation:int = cpuinfo.find("model name")
  let model:seq[string] = cpuinfo[modelLocation .. cpuinfo.find("\n", modelLocation)].replace("model name", "").replace(":", "").splitWhitespace()

  # threads
  let threadsLocation:int = cpuinfo.rfind("processor")
  let threads:int = cpuinfo[threadsLocation .. cpuinfo.find("\n", threadsLocation)].replace("processor", "").replace(":", "").strip().parseInt() + 1

  # clockspeed
  var keepSearching:bool = true
  var clockspeed:float = 0.0
  var index:int = 0
  while keepSearching:
    let thisClockspeed = parseFloat(readFile(fmt"/sys/devices/system/cpu/cpu{index}/cpufreq/cpuinfo_max_freq").strip())
    if(thisClockspeed > clockspeed):
      clockspeed = thisClockspeed
    index += 1
    if(index >= threads - 1):
      keepSearching = false

  clockspeed = round(clockspeed / 100000) / 10

  if(model.contains("Intel(R)") and len(model) >= 3):
    return fmt"{model[2]} ({threads}) @ {clockspeed} GHz"
  elif(model.contains("AMD") and len(model) >= 4):
    return fmt"{model[1]} {model[2]} {model[3]} ({threads}) @ {clockspeed} GHz"
  else:
    return fmt"{model} ({threads}) @ {clockspeed} GHz"  # return the unformatted cpuinfo value if it can't be identified

proc getMemory*(gibibytes:bool): string =
  let
    meminfo:string = readFile("/proc/meminfo")
    totalIndex:int = "MemTotal:".len()
    activeIndex:int = meminfo.find("Active:") + "Active:".len()
    unit:Units = gibibytes ? Units.GiB ! Units.GB

  var
    # memInfo is always the first value, so can use index 0
    total:float = parseFloat(meminfo[totalIndex .. meminfo.find("kB")].splitWhitespace()[0])
    # need to do extra work since "Active" is the 7th line
    active:float = parseFloat(memInfo[activeIndex .. meminfo.find("kB", activeIndex)].splitWhitespace()[0])

  total = convertBytes(total, Units.KiB, unit)
  active = convertBytes(active, Units.KiB, unit)

  return fmt"{$total} {$unit} total, {$active} {$unit} used"

proc getStats*(): Stats =
  return Stats(
    username: fetchStats.getUsername(),
    hostname: fetchStats.getHostname(),
    distro: fetchStats.getDistro(),
    kernel: fetchStats.getKernel(),
    arch: fetchStats.getArch(),
    uptime: fetchStats.getUptime(),
    shell: fetchStats.getShell(),
    desktop: fetchStats.getDesktop(),
    terminal: fetchStats.getTerminal(),
    cpu: fetchStats.getCPU(),
    memory: "" # empty string because memory will be found after config initializes for gibibytes
  )