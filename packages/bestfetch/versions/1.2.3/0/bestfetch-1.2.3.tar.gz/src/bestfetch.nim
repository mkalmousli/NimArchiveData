import ./[config, printer, objects, help]
import std/[osproc, sequtils, os, strutils, parsecfg, streams]
import termstyle

proc parseBool(input:string, default:bool): bool =
  case(input.toLowerAscii()):
    of "true":
      return true
    of "false":
      return false
    else:
      echo "Invalid arguments.".red
      return default

const version = staticRead("../bestfetch.nimble").newStringStream.loadConfig.getSectionValue("", "version") # https://stackoverflow.com/a/77463816

var
  configuration:objects.Config
  icons:bool
  box:bool
  boxLogo:bool
  roundCorners:bool
  login:bool
  gibibytes:bool
  logo:string
  colorSymbol:string
  titleColor:string
  dataColor:string
  otherColor:string
  printType:int = 0 # 0 = fetch, 1 = help, 2 = version

proc initConfig(): void =
  configuration = config.loadConfig()
  icons = configuration.icons
  box = configuration.box
  boxLogo = configuration.boxLogo
  roundCorners = configuration.roundCorners
  login = configuration.login
  gibibytes = configuration.gibibytes
  logo = configuration.logo
  colorSymbol = configuration.colorSymbol
  titleColor = configuration.titleColor
  dataColor = configuration.dataColor
  otherColor = configuration.otherColor

when isMainModule:
  initConfig()

  for i in countup(1,paramCount()): # start on 1 because "bestfetch" is also a param
    let charSeq = toSeq(paramStr(i).items)

    if charSeq[0] == '-':
      case(paramStr(i)):
        of "--help", "-h", "-H":
          printType = 1
        of "--version", "-v", "-V":
          printType = 2
        of "--clear", "-c":
          let clear = execCmd("clear")
        of "--reset", "-R":
          config.resetConfig()
          initConfig()
        of "--icons", "-i":
          icons = parseBool(paramStr(i+1), icons)
        of "--box", "-b":
          box = parseBool(paramStr(i+1), box)
        of "--boxLogo", "-B":
          boxLogo = parseBool(paramStr(i+1), boxLogo)
        of "--roundCorners", "-r":
          roundCorners = parseBool(paramStr(i+1), roundCorners)
        of "--login", "-L":
          login = parseBool(paramStr(i+1), login)
        of "--gibibytes", "-g":
          gibibytes = parseBool(paramStr(i+1), gibibytes)
        of "--logo", "-l":
          logo = paramStr(i+1)
        of "--colorSymbol", "-C":
          colorSymbol = paramStr(i+1)
        of "--titleColor", "-tc":
          titleColor = paramStr(i+1)
        of "--dataColor", "-dc":
          dataColor = paramStr(i+1)
        of "--otherColor", "-oc":
          otherColor = paramStr(i+1)
        else:
          echo "Invalid arguments.".red

  case(printType):
    of 0:
      printer.printFetch(objects.Config(
        icons: icons,
        box: box,
        boxLogo: boxLogo,
        roundCorners: roundCorners,
        login: login,
        gibibytes: gibibytes,
        logo: logo,
        colorSymbol: colorSymbol,
        titleColor: titleColor,
        dataColor: dataColor,
        otherColor: otherColor
      ))
    of 1:
      help.printHelp()
    of 2:
      echo "bestfetch".blue & " v".green & version.green
    else:
      echo "Invalid arguments.".red
