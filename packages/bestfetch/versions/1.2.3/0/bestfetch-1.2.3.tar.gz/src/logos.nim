import termstyle
import std/strformat

# will make more logos for other distros in the future
# logos must be 9 lines long but the width of the line doesn't matter.
# also, the width of the lines needs to be the same for all lines
# and it has to be manually inputed into a variable because len()
# counts the escape codes that termstyle adds to the strings :(

const bestfetchLogo:array[9, string] = [
  fmt"      ____       ".blue,
  fmt"     / ".blue & "__ ".magenta & "\\      ".blue,
  fmt"    / ".blue & "/_/".magenta & "_/      ".blue,
  fmt"   / ".blue & "/_/".magenta & " /       ".blue,
  fmt"  /_____/".blue & "______  ".cyan,
  fmt"        / ____".cyan & "/  ".magenta,
  fmt"       / /_      ".cyan,
  fmt"      / __".cyan & "/      ".magenta,
  fmt"     /".cyan & "_".magenta & "/         ".cyan
]

const archLogo:array[9, string] = [ # inspired by the pfetch arch logo
  fmt"          /\          ".cyan,
  fmt"         /  \         ".cyan,
  fmt"        /\   \        ".cyan,
  fmt"       /  \".cyan & fmt"   \       ".blue,
  fmt"      /".cyan & fmt"        \      ".blue,
  fmt"     /    __    \     ".blue,
  fmt"    /    /  \  \_\    ".blue,
  fmt"   /    |    |    \   ".blue,
  fmt"  /_-'''      '''-_\  ".blue,
]

const debianLogo:array[9, string] = [
  fmt"     .______.    ".red,
  fmt"    /  ____  \   ".red,
  fmt"   /  /    \  \  ".red,
  fmt"  '  '     /  /  ".red,
  fmt"  |   \_____./   ".red,
  fmt"  '              ".red,
  fmt"   \             ".red,
  fmt"     \           ".red,
  fmt"       \         ".red
]

const fedoraLogo:array[9, string] = [
  fmt"           ______".white & "_   ".blue,
  fmt"          / ____/".white & fmt" \  ".blue,
  fmt"         | |".white & "     | | ".blue,
  fmt"         | |___".white & "__| | ".blue,
  fmt"   ____".blue & "__| |__/".white & "___/  ".blue,
  fmt"  / __".blue & "/__| |         ".white,
  fmt" | |".blue & "     | |         ".white,
  fmt" | |".blue & "_____| |         ".white,
  fmt"  \_".blue & fmt"\_____/          ".white
]

const ubuntuLogo:array[9, string] = [
  fmt"          ____/''\    ".red,
  fmt"       .'\    \__/    ".red,
  fmt"      /   \".red & fmt" _     \   ".yellow,
  fmt"  .-.'".red & "    .' '.    '  ".yellow,
  fmt" |   |".red & "   |     |---|  ".yellow,
  fmt"  '''".red & ".    '._.'    '  ".yellow,
  fmt"      \   /      _/   ".yellow,
  fmt"       `'/-___/''\    ".yellow,
  fmt"              \__/    ".yellow
]

const nixosLogo:array[9, string] = [
  fmt"                        ",
  fmt"      \".blue & fmt"     \  /        ".cyan,
  fmt"   ____\_____".blue & fmt"\/         ".cyan,
  fmt"       /      \".cyan & "  /      ".blue,
  fmt"  ____/        \".cyan & "/____   ".blue,
  fmt"     /".cyan & fmt"\        /        ".blue,
  fmt"    /".cyan & fmt"  \".blue & " _____".cyan & "/".blue & "____     ".cyan,
  fmt"       /\".blue & fmt"     \         ".cyan,
  fmt"      /  \ ".blue & fmt"    \        ".cyan
]

const endeavourosLogo:array[9, string] = [
  fmt"           .".red & fmt"/'\".magenta & fmt".        ".blue,
  fmt"         .'".red & fmt"/   \".magenta & fmt"'.      ".blue,
  fmt"        /".red & fmt" /     \ ".magenta & fmt"'\    ".blue,
  fmt"      .'".red & fmt" /       \  ".magenta & fmt"\   ".blue,
  fmt"     /".red & fmt"  /         \  ".magenta & fmt"\  ".blue,
  fmt"   /".red & fmt"   /           |  ".magenta & fmt"| ".blue,
  fmt" /____".red & fmt"/           /".magenta & fmt"  /  ".blue,
  fmt"     /".blue & fmt"''--____--''  ".magenta & "/   ".blue,
  fmt"    /___________--''    ".blue
]

const
  bestfetchLength:int = 16
  archLength:int = 21
  debianLength:int = 16
  fedoraLength:int = 20
  ubuntuLength:int = 21
  nixosLength:int = 23
  endeavourosLength:int = 23

proc printLogo*(logo:string, line:int, box:bool, otherColor:proc): void =
  if(box):
    stdout.write(" │".otherColor)
  case(logo):
    of "bestfetch":
      stdout.write(bestfetchLogo[line])
    of "arch":
      stdout.write(archLogo[line])
    of "debian":
      stdout.write(debianLogo[line])
    of "fedora":
      stdout.write(fedoraLogo[line])
    of "ubuntu":
      stdout.write(ubuntuLogo[line])
    of "nixos":
      stdout.write(nixosLogo[line])
    of "endeavouros":
      stdout.write(endeavourosLogo[line])
    else:
      stdout.write(bestfetchLogo[line])

proc getLineLength*(logo:string): int =
  case(logo):
    of "bestfetch":
      return bestfetchLength
    of "arch":
      return archLength
    of "debian":
      return debianLength
    of "fedora":
      return fedoraLength
    of "ubuntu":
      return ubuntuLength
    of "nixos":
      return nixosLength
    of "endeavouros":
      return endeavourosLength
    else:
      return bestfetchLength