import termstyle
import std/[parsecfg, streams]

const version = staticRead("../bestfetch.nimble").newStringStream.loadConfig.getSectionValue("", "version") # https://stackoverflow.com/a/77463816

proc printHelp*(): void =
  echo "bestfetch".cyan & " (" & "v".green & version.green & ")" & ": a ".magenta & "customizable".blue & ", ".magenta & "beautiful".blue ", and ".magenta & "blazing fast".blue & " system fetch".magenta

  echo "\nNon-Parameter Arguments:".green
  echo "--help".cyan & ", " & "-h".cyan & "          print this dialogue"
  echo "--version".cyan & ", " & "-v".cyan & "       print the version number"
  echo "--clear".cyan & ", " & "-c".cyan & "         clear the terminal before printing the fetch"
  echo "--reset".cyan & ", " & "-R".cyan & "         reset the configuration file to the default"

  echo "\nBoolean Arguments:".green
  echo "--icons".cyan & ", " & "-i".cyan & "         (true/false) enable icons instead of labels"
  echo "--box".cyan & ", " & "-b".cyan & "           (true/false) draw a box around the fetch"
  echo "--boxLogo".cyan & ", " & "-B".cyan & "       (true/false) draw a box around the logo (requires box to be true)"
  echo "--roundCorners".cyan & ", " & "-r".cyan & "  (true/false) use round corners (╭) instead of right-angle (┌) corners"
  echo "--login".cyan & ", " & "-L".cyan & "         (true/false) print your login (user@hostname) in the fetch"
  echo "--gibibytes".cyan & ", " & "-g".cyan & "     (true/false) round bytes to 1024 instead of 1000 to be more accurate"

  echo "\nString Arguments:".green
  echo "--logo".cyan & ", " & "-l".cyan & "          (string) which logo to draw (see all in config file)"
  echo "--colorSymbol".cyan & ", " & "-C".cyan & "   (string) what to print the colors as (● is the default)"
  echo "--titleColor".cyan & ", " & "-tc".cyan & "   (string) what color to print the titles as (see all colors in config file)"
  echo "--dataColor".cyan & ", " & "-dc".cyan & "    (string) what color to print the data as (see all colors in config file)"
  echo "--otherColor".cyan & ", " & "-oc".cyan & "   (string) what color to print other stuff as (see all colors in config file)"

