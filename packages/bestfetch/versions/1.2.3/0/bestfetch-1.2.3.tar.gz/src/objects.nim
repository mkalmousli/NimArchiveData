type Config* = object
  icons*:bool
  box*:bool
  boxLogo*:bool
  roundCorners*:bool
  login*:bool
  gibibytes*:bool
  logo*:string
  colorSymbol*:string
  titleColor*:string
  dataColor*:string
  otherColor*:string

type Stats* = object
  username*:string
  hostname*:string
  distro*:string
  kernel*:string
  arch*:string
  uptime*:string
  shell*:string
  desktop*:string
  terminal*:string
  cpu*:string
  memory*:string

export Config, Stats