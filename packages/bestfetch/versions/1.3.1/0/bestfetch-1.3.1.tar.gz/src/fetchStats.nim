import std/[os, osproc, strutils, strformat, math, parsecfg]
import elvis
import ./objects
import bytesized

proc getUsername*(): string =
  return getEnv("USER")

proc getHostname*(): string =
  const
    hostname:string = "/etc/hostname"
    hostnameOpenRC:string = "/etc/conf.d/hostname"

  if hostname.fileExists():
    return hostname.open.readLine
  elif hostnameOpenrc.fileExists():
    return hostnameOpenrc.loadConfig.getSectionValue("", "hostname")
  else:
    return ""

let osRelease = "/etc/os-release".loadConfig()

proc getDistro*(): string =
  let prettyName = osRelease.getSectionValue("", "PRETTY_NAME")

  if(prettyName != ""):
    return prettyName
  else:
    return osRelease.getSectionValue("", "NAME")

proc getDistroID*(): string =
  return osRelease.getSectionValue("", "ID")

proc getKernel*(): string =
  return "/proc/version".open.readLine.split(" ")[2]

proc getArch*(): string =
  return execCmdEx("uname -m").output.splitWhitespace()[0]

proc getUptime*(): string =
  return execCmdEx("uptime -p").output[3 .. ^2]

proc getShell*(): string =
  return getEnv("SHELL").split("/")[^1]

proc getDesktop*(): string =
  var desktop:string = getEnv("DESKTOP_SESSION")

  if(desktop == ""):
    desktop = getEnv("XDG_CURRENT_DESKTOP") # some desktops (Hyprland) don't use DESKTOP_SESSION

  if(desktop == ""):
    return "none"
  else:
    return desktop

proc getTerminal*(): string =
  var term:string = getEnv("TERM")

  if(term == "xterm-kitty"): return "kitty" # kitty is called "xterm-kitty" for some reason
  else: return term

proc getCPU*(): string =
  var cpuinfo:string = readFile("/proc/cpuinfo")

  cpuinfo = cpuinfo[cpuinfo.find("model name") .. ^1].replace("model name	: ", "") # cut to beginning
  cpuinfo = cpuinfo[0 .. cpuinfo.find("\n")].replace("\n", "") # cut to end
  let cpu:seq[string] = cpuinfo.splitWhitespace() # convert to sequence

  if(cpu.contains("Intel(R)") and cpu.contains("Core(TM)")):
    return fmt"{cpu[2]} @ {cpu[5]}"
  elif(cpu.contains("AMD")):
    return fmt"{cpu[1]} {cpu[2]} {cpu[3]}"
  else:
    return cpuinfo # return the unformatted cpuinfo value if it can't be identified


proc getMemory*(gibibytes:bool): string =
  let
    meminfo:string = readFile("/proc/meminfo")
    totalIndex:int = "MemTotal:".len()
    activeIndex:int = meminfo.find("Active:") + "Active:".len()
    unit:Units = gibibytes ? Units.GiB ! Units.GB

  var
    # memInfo is always the first value, so can use index 0
    total:float = parseFloat(meminfo[totalIndex .. meminfo.find("kB")].splitWhitespace()[0])
    # need to do extra work since "Active" is the 7th line
    active:float = parseFloat(memInfo[activeIndex .. meminfo.find("kB", activeIndex)].splitWhitespace()[0])

  total = convertBytes(total, Units.KiB, unit)
  active = convertBytes(active, Units.KiB, unit)

  return fmt"{$total} {$unit} total, {$active} {$unit} used"

proc getStats*(): Stats =
  return Stats(
    username: fetchStats.getUsername(),
    hostname: fetchStats.getHostname(),
    distro: fetchStats.getDistro(),
    kernel: fetchStats.getKernel(),
    arch: fetchStats.getArch(),
    uptime: fetchStats.getUptime(),
    shell: fetchStats.getShell(),
    desktop: fetchStats.getDesktop(),
    terminal: fetchStats.getTerminal(),
    cpu: fetchStats.getCPU(),
    memory: "" # empty string because memory will be found after config initializes for gibibytes
  )