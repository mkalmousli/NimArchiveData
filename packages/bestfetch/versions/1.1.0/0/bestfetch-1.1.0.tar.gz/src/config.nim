import std/[os, linenoise, strformat, strutils, streams]
import yaml, termstyle
import ./objects.nim

const
  user:string = getEnv("USER")
  configDir:string = fmt"/home/{user}/.config/bestfetch"
  configPath:string = fmt"{configDir}/config.yaml"

const defaultConfig:string = """
- # toggles
  icons: true # use nerdfont icons instead of labels
  box: true # draw a box around the fetch in unicode characters
  boxLogo: true # draw a box around the logo (requires `box` to be true)
  roundCorners: true # use round (╭) or right-angle (┌) corners
  login: true # print the login (user@hostname)
  gibibytes: true # round memory to 1024 bytes instead of 1000 to be more accurate

  # strings
  logo: auto # auto, bestfetch, arch, debian, fedora, ubuntu, nixos, endeavouros
  colorSymbol: "●" # ● looks nice but can be any *reasonable* string

  # colors
  # can be set to: black, red, yellow, green, cyan, blue, magenta, or white
  titleColor: cyan
  dataColor: blue
  otherColor: magenta
"""

var
  configuration*:seq[Config]
  configExists*:bool = true

if not dirExists(configDir):
  createDir(configDir)

if not fileExists(configPath):
  configExists = false
  writeFile(configPath, defaultConfig)
  echo("!!! Config options (like ".yellow & "c".red & "o".yellow & "l".green & "o".cyan & "r".magenta & ") stored at ".yellow & configPath.green & " !!!".yellow)

proc loadConfig*(): Config =
  var stream = newFileStream(configPath)
  load(stream, configuration)
  stream.close()
  return configuration[0]