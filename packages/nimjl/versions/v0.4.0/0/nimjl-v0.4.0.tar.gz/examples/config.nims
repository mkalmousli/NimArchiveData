switch("outdir", "build")
