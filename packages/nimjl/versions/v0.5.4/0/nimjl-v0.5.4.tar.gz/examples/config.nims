switch("outdir", "bin")
