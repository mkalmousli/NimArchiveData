# Package

version       = "0.2.3"
author        = "ThomasTJdev"
description   = "SQL query builder and validator - opiniated"
license       = "MIT"
srcDir        = "src"


# Dependencies

requires "nim >= 1.6.18"
requires "waterpark >= 0.1.0"