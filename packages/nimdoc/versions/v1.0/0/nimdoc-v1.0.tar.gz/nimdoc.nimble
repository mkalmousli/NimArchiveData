## Copyright (c) 2026 Ben Tomlin
## Licensed under the MIT license

version       = "1.0.0"
author        = "Ben Tomlin"
description   = "Generate and view local documentation of installed nimble packages"
license       = "MIT"
srcDir        = "src"
bin           = @["nimdoc"]


# Dependencies

requires "nim >= 2.2.6"

requires "https://github.com/WaywardWizard/nim-argparse >= 4.1.2"