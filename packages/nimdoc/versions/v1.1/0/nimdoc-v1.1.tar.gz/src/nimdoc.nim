## Copyright (c) 2026 Ben Tomlin
## Licensed under the MIT license
##
## Start HTTP server for documentation if needed
## Generate documentation from nim package if needed
## Open index page in browser
{.experimental: "codeReordering".}
import std/[osproc, pegs, strutils, dirs, paths, files, strformat, options]
import argparse
const
  SRVROOT = "/srv/doc/nim"
  DOCGEN_TASKS = ["docgen", "gendocs", "builddocs", "mkdocs", "docs"]
  DOCGEN_OUTPUT_FOLDERS = ["docs", "htmldocs", "httpdocs"]
  DOCGEN_FILES = ["docutils.nim", "docs.nim"]
  MASTER_INDEX = "theindex.html"
type
  CmdEx = tuple[output: string, exitCode: int]

  Server = object
    host: string = "localhost"
    port: int = 7070
    root: string = SRVROOT

proc url(x: Server): string =
  &"http://{x.host}:{x.port}/"

var dryrun: bool = false
var parser = newParser("nimdoc"):
  help("Generate and serve Nim package documentation")
  arg(
    "package",
    completionsGenerator = [sckFish: """nimble list -i|grep -E '^\w'"""],
    help = "Package documentation to show",
    default = some(""),
  )
  flag("-r", "--regenerate", help = "Regenerate documentation even if it exists")
  flag("-R", "--restartsrv", help = "Restart server if already running")
  flag(
    "-d", "--dryrun", help = "Do not start server or generate docs, just show commands"
  )
  flag("-p", "--private", help = "Generate documentation for private symbols")
  run:
    dryrun = opts.dryrun
    var httpServer = Server()
    echo "Starting nim doc server..."
    httpServer.start(opts.restartsrv)
    echo "Generating documentation..."
    generateDocs(opts.package, opts.regenerate, opts.private)
    openBrowser(httpServer, opts.package)
parser.run(commandLineParams())

proc portProc(port: int): string =
  let pnProc = peg"""\(\(@@\,@@\,@@(\)\))"""
  var matched: array[3, string]
  var cmd: CmdEx = execCmdEx(&"ss -4lt -H -p sport :{port}")
  if cmd.exitCode != 0:
    raise newException(ValueError, &"Failed to execute ss command {cmd.output}")
  discard cmd.output.find(pnProc, matched)
  if matched.len > 0:
    return matched[0].strip(chars = {' ', '"'})
  else:
    return ""

# Start HTTP server if not already running
proc start(x: Server, forceRestart = false) =
  var srvcmd: string = "python -m http.server $1 --bind $2 --directory $3"
  if findExe("live-server") != "":
    srvcmd = "live-server --port $1 --host $2 --index $3"
  srvcmd = srvcmd.format(x.port, x.host, x.root)

  if portProc(x.port) == "" or forceRestart:
    if dryrun:
      echo "[Dry Run] ", srvcmd
    else:
      var ssrvcmd = srvcmd.split(" ")
      var p: Process = startProcess(
        ssrvcmd[0], args = ssrvcmd[1 ..^ 1], options = {poUsePath, poDaemon}
      )

proc dryEx(cmdstr: string, workingDir = ""): Option[CmdEx] =
  if dryrun:
    echo "[Dry Run] ", cmdstr
    return none[CmdEx]()
  else:
    return some(execCmdEx(cmdstr, workingDir = workingDir))

proc nimbleTasks(dir: Path, allowFail = true): seq[string] =
  var cmd = execCmdEx("nimble tasks|cut -f1 -d' '", workingDir = $dir)
  if cmd.exitCode != 0 and not allowFail:
    raise newException(ValueError, "Failed to get nimble tasks")
  result = cmd.output.splitLines().filterIt(it.len > 0)

proc generateDocs(pkg: string, regenerate = false, private = false): void =
  ## Generate documentation for package or master index for all generated docs
  ##
  ## Master index will be generated where pkg == ""
  if pkg == "":
    return # Noop. Buildindex below is not linking relative to SRVROOT

  if regenerate:
    echo "Regenerating..."
  var outdir = Path(SRVROOT) / Path(pkg)
  var tasktarget, doctarget: string
  var cmd: CmdEx = execCmdEx("nimble path " & pkg)
  if cmd.exitCode != 0:
    raise newException(ValueError, "Package not found")
  var pkgpath: Path = cmd.output.strip().split('\n')[0].Path

  for task in nimbleTasks(pkgpath):
    if task in DOCGEN_TASKS:
      echo &"Using nimble task {task} to generate documentation"
      tasktarget = task
      break

  # find a doctarget file for use if the task fails
  for item in @[pkg & ".nim"] & @DOCGEN_FILES:
    if fileExists(pkgpath / item.Path):
      echo &"Using project file {item} to generate documentation"
      doctarget = $item

  # Generate documentation
  var dcmd: Option[CmdEx]
  if not fileExists(outdir) or regenerate:
    var cmdstr: string
    if tasktarget.len > 0:
      cmdstr = &"nimble {doctarget}"
      dcmd = dryEx(cmdstr, workingDir = $pkgpath)
      if dcmd.issome():
        if dcmd.get().exitCode == 0:
          for folder in DOCGEN_OUTPUT_FOLDERS:
            let generatedDir = pkgpath / folder.Path
            let genindex = generatedDir / "theindex.html".Path
            if fileExists(genindex):
              copyDir(generatedDir, outdir)
              return
        echo "[Warning] did not find task generated docs. Fallback to manual generation"

    var extraArgs = if private: "--docInternal" else: ""
    for index in ["only", "on"]:
      cmdstr =
        &"nim --path:{pkgpath} {extraArgs} --project --index:{index} --outdir:{outdir} doc {doctarget}"
      dcmd = dryEx(cmdstr, $pkgpath)
      if dcmd.issome():
        if dcmd.get().exitCode != 0:
          raise newException(
            ValueError,
            &"{pkg} documentation generation failed {dcmd.get(default(CmdEx)).output}",
          )

# Open browser
proc openBrowser(server: Server, pkg = "") =
  var outdir = Path(SRVROOT) / Path(pkg)
  var index = outdir / Path("theindex.html")
  # fallback to dir listing
  var murl =
    if pkg == "":
      server.url()
    else:
      server.url() & pkg
  if fileExists(index):
    murl &= "/theindex.html"
  elif fileExists(outdir / Path(&"{pkg}.html")):
    murl &= &"/{pkg}.html"

  discard startProcess(&"$BROWSER {murl}", options = {poEvalCommand, poDaemon})
