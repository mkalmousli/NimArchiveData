## Copyright (c) 2026 Ben Tomlin
## Licensed under the MIT license

version       = "1.1.0"
author        = "Ben Tomlin"
description   = "Generate and view local documentation of installed nimble packages"
license       = "MIT"
srcDir        = "src"
bin           = @["nimdoc"]


# Dependencies

requires "nim >= 2.2.6"

requires "https://github.com/WaywardWizard/nim-argparse >= 4.1.2"

import std/strformat
task compatibility, "Check compatibility with older Nim versions":
  let getVersions:string = r"choosenim --noColor versions|awk '/.*\*?.*([0-9]+\.){2}[0-9]+/'|grep -Po '(\d|\.)+'|sort -V"
  let thisVersion = (gorgeEx r"""choosenim show | grep "*"|tr -d " *"""").output

  var versions = gorgeEx(getVersions).output.splitLines()
  echo &"Testing with nim versions : {versions}"

  var passedVersions = newSeq[string]()
  var testAll = false
  var result: tuple[output:string, exitCode:int]
  for ver in versions: # oldest first
    discard gorgeEx &"choosenim -y {ver}"
    for task in ["build"]:
      # The useSystemNim flag seems ignored
      result = gorgeEx &"nimble --useSystemNim {task}"
      if result.exitCode != 0:
        break
    if result.exitCode == 0:
      echo &"Checking compatibility with nim {ver}... PASSED"
      passedVersions.add ver
      if not testAll:
        break
    else:
      echo &"Checking compatibility with nim {ver}... FAILED"
      echo result.output
  discard gorgeEx(&"choosenim {thisVersion}")
  echo &"Passed versions: {passedVersions}"
