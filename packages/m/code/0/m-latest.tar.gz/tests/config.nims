switch("path", "$projectDir/../examples/")
