import std/[streams]
import ../lispobject
import ../alien
from std/strformat import fmt
from std/tables import toTable

type
  FileStreamObj = ref object of Alien
    stream: FileStream
    isOpen: bool
  StringStreamObj = ref object of Alien
    stream: StringStream
    isOpen: bool


proc newFileStreamObj(filename: string=""; mode: FileMode=fmReadWrite; stream=newFileStream(filename, mode); isOpen=false): LispObject =
  return newAlien(FileStreamObj(tname: "FileStream", stream: stream, isOpen: isOpen))

proc newStringStreamObj(buffer: string=""; stream=newStringStream(buffer); isOpen=false): LispObject =
  return newAlien(StringStreamObj(tname: "StringStream", stream: stream, isOpen: isOpen))
  
proc openFileStream(args: LispObject): LispObject =
  if args.len != 1 or not (args.first.kind == String):
    raise newException(ValueError, fmt"`openFileStream` is of type String -> FileStream but got {args}")
  let filename = args.first.str
  result = newFileStreamObj(stream=openFileStream(filename), isOpen=true)

proc openStringStream(args: LispObject): LispObject =
  if args.len != 1 or not (args.first.kind == String):
    raise newException(ValueError, fmt"`openStringStream` is of type String -> StringStream but got {args}")
  let buffer = args.first.str
  result = newStringStreamObj(buffer=buffer, isOpen=true)
  

proc readChar(args: LispObject): LispObject =
  if args.len != 1 or not (args.first.kind == AlienObj and (args.first.alien.tname != "FileStream" or args.first.alien.tname != "StringStream")):
    raise newException(ValueError, fmt"`readChar` is of type Stream -> Char | Nil but got {args}")
  result = NIL()
  let strmObj = args.first.alien
  if strmObj.tname == "FileStream":
    let stream = FileStreamObj(strmObj)
    if not stream.isOpen:
      raise newException(ValueError, fmt"attempt to use closed Stream at `readChar`") # maybe remove these later and just return NIL()
    if not stream.stream.atEnd():
      return newChar(stream.stream.readChar())
  else:
    let stream = StringStreamObj(strmObj)
    if not stream.isOpen:
      raise newException(ValueError, fmt"attempt to use closed Stream at `readChar`")
    if not stream.stream.atEnd():
      return newChar(stream.stream.readChar())

proc peekChar(args: LispObject): LispObject =
  if args.len != 1 or not (args.first.kind == AlienObj and (args.first.alien.tname != "FileStream" or args.first.alien.tname != "StringStream")):
    raise newException(ValueError, fmt"`peekChar` is of type Stream -> Char | Nil but got {args}")
  result = NIL()
  let strmObj = args.first.alien
  if strmObj.tname == "FileStream":
    let stream = FileStreamObj(strmObj)
    if not stream.isOpen:
      raise newException(ValueError, fmt"attempt to use closed Stream at `peekChar`") # maybe remove these later and just return NIL()
    if not stream.stream.atEnd():
      return newChar(stream.stream.peekChar())
  else:
    let stream = StringStreamObj(strmObj)
    if not stream.isOpen:
      raise newException(ValueError, fmt"attempt to use closed Stream at `peekChar`")
    if not stream.stream.atEnd():
      return newChar(stream.stream.peekChar())


proc readString(args: LispObject): LispObject =
  if args.len != 2 or not (args.first.kind == AlienObj and (args.first.alien.tname != "FileStream" or args.first.alien.tname != "StringStream") and args.second.kind == Int):
    raise newException(ValueError, fmt"`readString` is of type Stream -> Int -> String | Nil but got {args}")
  result = NIL()
  let
    strmObj = args.first.alien
    length  = args.second.intVal
  try:
    if strmObj.tname == "FileStream":
      let stream = FileStreamObj(strmObj)
      if not stream.isOpen:
        raise newException(ValueError, fmt"attempt to use closed Stream at `readString`") 
      if not stream.stream.atEnd():
        return newStr(stream.stream.readStr(length))
    else:
      let stream = StringStreamObj(strmObj)
      if not stream.isOpen:
        raise newException(ValueError, fmt"attempt to use closed Stream at `readString`")
      if not stream.stream.atEnd():
        return newStr(stream.stream.readStr(length))
  except IOError as e:
    raise newException(ValueError, fmt"exception at call to `readString` with {args} :: {e.msg}")



proc peekString(args: LispObject): LispObject =
  if args.len != 2 or not (args.first.kind == AlienObj and (args.first.alien.tname != "FileStream" or args.first.alien.tname != "StringStream") and args.second.kind == Int):
    raise newException(ValueError, fmt"`peekString` is of type Stream -> Int -> String | Nil but got {args}")
  result = NIL()
  let
    strmObj = args.first.alien
    length  = args.second.intVal
  try:
    if strmObj.tname == "FileStream":
      let stream = FileStreamObj(strmObj)
      if not stream.isOpen:
        raise newException(ValueError, fmt"attempt to use closed Stream at `peekString`")
      if not stream.stream.atEnd():
        return newStr(stream.stream.peekStr(length))
    else:
      let stream = StringStreamObj(strmObj)
      if not stream.isOpen:
        raise newException(ValueError, fmt"attempt to use closed Stream at `peekString`")
      if not stream.stream.atEnd():
        return newStr(stream.stream.peekStr(length))
  except IOError as e:
    raise newException(ValueError, fmt"exception at call to `peekString` with {args} :: {e.msg}")



proc atEnd(args: LispObject): LispObject =
  if args.len != 1 or not (args.first.kind == AlienObj and (args.first.alien.tname != "FileStream" or args.first.alien.tname != "StringStream")):
    raise newException(ValueError, fmt"`atEnd` is of type Stream -> T | Nil but got {args}")
  result = NIL()
  let strmObj = args.first.alien
  if strmObj.tname == "FileStream":
    let stream = FileStreamObj(strmObj)
    if (not stream.isOpen) or (stream.stream.atEnd()):
      return T()
  else:
    let stream = StringStreamObj(strmObj)
    if (not stream.isOpen) or (stream.stream.atEnd()):
      return T()
      
proc getPosition(args: LispObject): LispObject =
  if args.len != 1 or not (args.first.kind == AlienObj and (args.first.alien.tname != "FileStream" or args.first.alien.tname != "StringStream")):
    raise newException(ValueError, fmt"`getPosition` is of type Stream -> Int | Nil but got {args}")
  result = NIL()
  let strmObj = args.first.alien
  if strmObj.tname == "FileStream":
    let stream = FileStreamObj(strmObj)
    if stream.isOpen:
      return newInt(stream.stream.getPosition())
  else:
    let stream = StringStreamObj(strmObj)
    if stream.isOpen:
      return newInt(stream.stream.getPosition())

proc setPosition(args: LispObject): LispObject =
  if args.len != 2 or not (args.first.kind == AlienObj and (args.first.alien.tname != "FileStream" or args.first.alien.tname != "StringStream") and args.second.kind == Int):
    raise newException(ValueError, fmt"`setPosition` is of type Stream -> Int -> T | Nil but got {args}")
  result = NIL()
  let
    strmObj = args.first.alien
    newPos  = args.second.intVal
  if strmObj.tname == "FileStream":
    let stream = FileStreamObj(strmObj)
    if stream.isOpen:
      stream.stream.setPosition(newPos)
      return T()
  else:
    let stream = StringStreamObj(strmObj)
    if stream.isOpen:
      stream.stream.setPosition(newPos)
      return T()

proc close(args: LispObject): LispObject =
  if args.len != 1 or not (args.first.kind == AlienObj and (args.first.alien.tname != "FileStream" or args.first.alien.tname != "StringStream")):
    raise newException(ValueError, fmt"`close` is of type Stream -> T | NIL but got {args}")
  let strmObj = args.first.alien
  if strmObj.tname == "FileStream":
    let stream = FileStreamObj(strmObj)
    if not stream.isOpen:
      raise newException(ValueError, fmt"attempt to close previously closed Stream")
    close(stream.stream)
    stream.isOpen = false
  else:
    let stream = StringStreamObj(strmObj)
    if not stream.isOpen:
       raise newException(ValueError, fmt"attempt to close previously closed Stream")
    close(stream.stream)
    stream.isOpen = false
  result = T()
  

const Module* = toTable {
  "openFileStream"  : BuiltinFn Streams.openFileStream,
  "openStringStream": BuiltinFn Streams.openStringStream,
  "close"           : BuiltinFn Streams.close,
  "readChar"        : BuiltinFn Streams.readChar,
  "peekChar"        : BuiltinFn Streams.peekChar,
  "readString"      : BuiltinFn Streams.readString,
  "peekString"      : BuiltinFn Streams.peekString,
  "getPosition"     : BuiltinFn Streams.getPosition,
  "setPosition"     : BuiltinFn Streams.setPosition,
  "atEnd"           : BuiltinFn Streams.atEnd

}
