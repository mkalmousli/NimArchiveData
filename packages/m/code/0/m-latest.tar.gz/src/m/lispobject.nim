import std/[tables, strutils, hashes]
import bigints
import alien

type
  LispObjectKind* = enum
    Nil,
    Int,
    Char,
    Float,
    BigInt,
    Symbol,
    String,
    Cons,
    Builtin,
    Lambda,
    Macro,
    HashTable,
    AlienObj,
    FieldAccess,
    Index,
    Seq
    
  SymbolRef* = ref object
    name*: string
  
  BuiltinFn* = proc (args: LispObject): LispObject
               
  Env* = ref object
    interned*     : Table[string, LispObject]
    loadedModules*: TableRef[string, Table[string, BuiltinFn]]
    parent*       : Env
    
  LispObject* = ref object
    case kind*: LispObjectKind:
      of Symbol:
        sym*: SymbolRef
      of Int:
        intVal*: int
      of Char:
        charVal*: char
      of Float:
        floatVal*: float
      of BigInt:
        bigNum*: BigInt
      of String:
        str*: string
      of Cons:
        car*, cdr*: LispObject
      of Builtin:
        fun*: BuiltinFn
        name*: string
      of Lambda, Macro:
        params*, body*: LispObject
        closure*: Env
      of HashTable:
        literal*: bool
        table*: Table[LispObject, LispObject]
      of AlienObj:
        alien*: Alien
      of FieldAccess:
        tableSym*, field*: LispObject
      of Index:
        obj*: LispObject
        startIdx*, endIdx*: LispObject
      of Seq:
        literalSeq*: bool
        sequence*: seq[LispObject]
      of Nil:
       discard

let
  nilObj = LispObject(kind: Nil)
  tObj   = LispObject(kind: Symbol, sym: SymbolRef(name: "t"))
  
func T*(): LispObject {.inline.} =
  {.cast(noSideEffect).}:
    return tObj
    
func NIL*(): LispObject {.inline.} =
  {.cast(noSideEffect).}:
    return nilObj

func newChar*(c: sink char): owned LispObject =
  return LispObject(kind: Char, charVal: c)
  
func newSeq*(sequence: seq[LispObject] = @[]): owned LispObject =
  return LispObject(kind: Seq, sequence: sequence)
  
func newIndex*(obj: sink LispObject; startIdx, endIdx: sink LispObject): owned LispObject =
  return LispObject(kind: Index, obj: obj, startIdx: startIdx, endIdx: endIdx)

func newFieldAccess*(tableSym: sink LispObject; field: sink LispObject): owned LispObject =
  return LispObject(kind: FieldAccess, tableSym: tableSym, field: field)
  
func newAlien*(alien: Alien): owned LispObject =
  return LispObject(kind: AlienObj, alien: alien)

func newTable*(): owned LispObject =
  return LispObject(kind: HashTable, table: initTable[LispObject, LispObject]())

func newTable*(table: Table[LispObject, LispObject]): owned LispObject =
  return LispObject(kind: HashTable, table: table)
  
func newScope*(parent: Env): owned Env =
  return Env(interned: initTable[string, LispObject](), loadedModules: newTable[string, Table[string, BuiltinFn]](), parent: parent)
  
func newLambda*(env: Env; params, body: LispObject): owned LispObject =
  return LispObject(kind: Lambda, params: params, body: body, closure: env.newScope())
  
func newMacro*(env: Env; params, body: LispObject): owned LispObject =
  return LispObject(kind: Macro, params: params, body: body, closure: env.newScope())
  
func newBuiltin*(fun: BuiltinFn; name: string): owned LispObject {.inline.} =
  return LispObject(kind: Builtin, fun: fun, name: name)
                    
func newSym*(sym: sink string): owned LispObject =
  return LispObject(kind: Symbol, sym: SymbolRef(name: sym))

func newInt*(val: sink int): owned LispObject =
  return LispObject(kind: Int , intVal: val)

func newFloat*(val: sink float): owned LispObject =
  return LispObject(kind: Float, floatVal: val)

func newBigInt*(val: sink int): owned LispObject =
  return LispObject(kind: BigInt, bigNum: initBigInt(val))
  
func newStr*(s: sink string): owned LispObject =
  return LispObject(kind: String, str: s)

func cons*(car, cdr: LispObject): owned LispObject =
  return LispObject(kind: Cons, car: car, cdr: cdr)

func list*(objs: seq[LispObject]): owned LispObject =
  result = NIL()
  for i in countdown(objs.high, 0):
    result = cons(objs[i], result)
  return result
  
func `==`*(a, b: SymbolRef)    : bool   = a.name == b.name    
func isAtom*(obj: LispObject)  : bool   = obj.kind != Cons
func isSymbol*(obj: LispObject): bool   = obj.kind == Symbol
func isT*(obj: LispObject)     : bool   = obj.kind != Nil
func isNil*(obj: LispObject)   : bool   =
  if obj.kind == Symbol:
    obj.sym.name == "nil"
  else:
    obj.kind == Nil
    
func len*(list: LispObject): int =
  if list.isNil:
    return 0
  elif list.isAtom: 
    return 1
  else:
    return 1 + len(list.cdr)

func first*(list: LispObject): owned LispObject =
  if list.len < 1: return NIL()
  return list.car

func second*(list: LispObject): owned LispObject =
  if list.len < 2: return NIL()
  return list.cdr.car 
  
func third*(list: LispObject): owned LispObject =
  if list.len < 3: return NIL()
  return list.cdr.cdr.car

func fourth*(list: LispObject): owned LispObject =
  if list.len < 4: return NIL()
  return list.cdr.cdr.cdr.car 

func fifth*(list: LispObject): owned LispObject =
  if (list.len < 5): return NIL()
  return list.cdr.cdr.cdr.cdr.car

   
from std/strformat import fmt
proc `$`*(s: LispObject;): owned string =
  case s.kind:
  of Nil:
    return "NIL"
  of Symbol:
    if s.sym.name == "t": return s.sym.name.toUpper
    return s.sym.name
  of Builtin:
    return fmt"#<Builtin {s.name}>"
  of Lambda:
    return fmt"#<Lambda {s.params} {s.body}>"
  of Macro:
    return fmt"#<Macro {s.params} {s.body}>"
  of HashTable:
    return $s.table
  of FieldAccess:
    return fmt"#<FieldAccess table = {s.tableSym} field = {s.field}>"
  of AlienObj:
    return fmt"#<{s.alien.tname} {describe s.alien}>"
  of Float:
    result = $s.floatVal
    if result.find('.') == -1:
      result.add ".0"
    return result
  of Int:
    return $s.intVal
  of Char:
    return $s.charVal
  of BigInt:
    return $s.bigNum
  of String:
    return s.str.escape
  of Index:
    if s.startIdx == s.endIdx:
      return fmt"{s.obj}[{s.startIdx}]"
    return fmt"{s.obj}[{s.startIdx}..{s.endIdx}]"
  of Cons:
    result = "("
    var
      current = s
      first = true
    while not current.isNil and current.kind == Cons:
      if not first:
        result.add " "
      result.add $(current.car) 
      current = current.cdr 
      first = false
    if not current.isNil:
      result.add " . " & $current
    result.add ")"    
    return result
  of Seq:
    return ($s.sequence).replace("@", "")
  
func toSeq*(list: LispObject): owned seq[LispObject] =
  var current: LispObject = list
  while not current.isNil:
    if current.kind == Cons:
      if not current.car.isNil:
        result.add(current.car)
      current = current.cdr
    else:
      result.add(current)
      break       
  return result


proc hash*(obj: LispObject): owned Hash =
  case obj.kind
  of Int:
    result = hash(obj.intVal)
  of Float:
    result = hash(obj.floatVal)
  of String:
    result = hash(obj.str)
  of Char:
    return hash(obj.charVal)
  of Symbol:
    if obj.sym.name == "t":
      result = hash(true)
    else:
      result = hash(obj.sym.name)
  of BigInt:
    result = hash(obj.bigNum) 
  of Nil:
    result = hash(false) 
  of Cons:
    var
      h: Hash = 0
      curr = obj
    while not curr.isNil:
      h = h !& hash(curr.car) 
      curr = curr.cdr
    return h
  of Builtin, Lambda, HashTable, Macro, AlienObj:
    return hash(cast[pointer](addr obj))
  of FieldAccess:
    return hash($obj)
  of Index:
    return hash($obj)
  of Seq:
    return hash(obj.sequence)
  

proc `==`*(x, y: LispObject): bool =
  if x.kind != y.kind:
    return false
  case x.kind
  of Int:
    return x.intVal == y.intVal
  of Float:
    return x.floatVal == y.floatVal
  of String:
    return x.str == y.str
  of Char:
    return x.charVal == y.charVal
  of Symbol:
    return x.sym.name == y.sym.name
  of BigInt:
    return x.bigNum == y.bigNum
  of Nil: 
    return true
  of Cons:
    var
      currX = x
      currY = y
    while not currX.isNil and not currY.isNil:
      if not (currX.car == currY.car):
        return false
      currX = currX.cdr
      currY = currY.cdr
    return currX.isNil and currY.isNil
  of HashTable:
    return x.table == y.table
  of Lambda:
    return x.params == y.params and x.body == y.body and x.closure == y.closure
  of Macro:
    return x.params == y.params and x.body == y.body and x.closure == y.closure
  of Builtin:
    return x.fun == y.fun
  of AlienObj:
    return (cast[pointer](addr x) == cast[pointer](addr y))
  of Seq:
    if x.sequence.len != y.sequence.len:
      return false
    for idx, obj in x.sequence:
      if y.sequence[idx] != obj:
        return false
    return true    
  else:
    discard


