import std/[strutils, strformat, streams, lexbase]
import lispobject

type
  TokenKind* = enum
    tkSym
    tkFloat
    tkInt
    tkStr
    tkEof
    tkLpar     # (
    tkRpar     # )
    tkDot      # .
    tkQuote    # '
    tkBquote   # `
    tkComma    # ,
    tkSplice   # ,@
    tkComment  # ;
    tkColon    # :
    tkLBrace   # {
    tkRBrace   # }
    tkLBracket # [
    tkRBracket # ]
    tkChar  # #

  Token* = object
    case kind*: TokenKind:
      of tkSym:     sym*:     SymbolRef
      of tkStr:     str*:     string
      of tkFloat:   flt*:     float
      of tkInt:     intv*:    int
      of tkChar: charVal*: char
      else: discard

  MLexr* = object of BaseLexer
    filename*: string
    curLine*: string
    curTok*: Token
    

const
  SymbolChars = {'a'..'z', 'A'..'Z', '0'..'9', '*', '+', '-', '!', '?', '_', '>', '<', '$', '|', '=', '@', '`', '^', '/', '~'}

proc initLexer*(lx: var MLexr, input: Stream, filename: string = "") =
  lexbase.open(lx, input, refillChars = {EndOfFile})
  lx.filename = filename

template handleEof (lexer: var MLexr) =
  lexer.bufpos = lexer.handleRefillChar(lexer.bufpos)
  if lexer.buf[lexer.bufpos] == EndOfFile:
    lexer.curTok = Token(kind: tkEof)
    return

proc skip* (lexer: var MLexr) =
  while true:
    case lexer.buf[lexer.bufpos] 
    of ' ', '\t':
      inc(lexer.bufpos)
    of '\L':
      lexer.bufpos = lexer.handleLF(lexer.bufpos)
    of '\c':
      lexer.bufpos = lexer.handleCR(lexer.bufpos)
    of EndOfFile:
      lexer.handleEof()
    else:
      break


func parseSym*(lx: var MLexr, start: int) =
  while lx.buf[lx.bufpos] in SymbolChars:
    inc lx.bufpos
  let symStr = lx.buf.substr(start, lx.bufpos - 1)
  lx.curTok = Token(kind: tkSym, sym: newSym(symStr).sym)

func parseNumber*(lx: var MLexr, start: int) =
  var 
    pos = start 
    isFloat = false
  
  if lx.buf[pos] in {'+', '-'}:
    inc pos

  while pos < lx.buf.len:
    let c = lx.buf[pos]
    if c.isDigit:
      inc pos
    elif c == '.':
      if pos + 1 < lx.buf.len and lx.buf[pos+1] == '.': # ignore if there is `..` because its StringIndex initializer; see `parseStringIndex` in `reader.nim`
        break 
      isFloat = true
      inc pos
    else:
      break

  if pos < lx.buf.len and lx.buf[pos] in {'e', 'E'}:
    isFloat = true
    inc pos
    if pos < lx.buf.len and lx.buf[pos] in {'+', '-'}:
      inc pos
    while pos < lx.buf.len and lx.buf[pos].isDigit:
      inc pos

  let numStr = lx.buf.substr(start, pos - 1)
  lx.bufpos = pos
  try:
    if isFloat:
      lx.curTok = Token(kind: tkFloat, flt: parseFloat(numStr))
    else:
      lx.curTok = Token(kind: tkInt, intv: parseInt(numStr))
  except:
    raise newException(ValueError, fmt"Invalid number: {numStr}")


proc parseStr*(lx: var MLexr) =
  var str = ""
  inc lx.bufpos 
  while lx.buf[lx.bufpos] != '\0':
    let c = lx.buf[lx.bufpos]
    if c == '"':
      inc lx.bufpos 
      break
    elif c == '\\':
      inc lx.bufpos
      let escapedChar = lx.buf[lx.bufpos]
      case escapedChar
      of '"': str.add('"')
      of '\\': str.add('\\')
      of 'n': str.add('\n')
      of 'r': str.add('\r')
      of 't': str.add('\t')
      else: str.add(escapedChar)
      inc lx.bufpos 
    elif c == EndOfFile:
      lx.handleEof()
    else:
      str.add(c)
      inc lx.bufpos 
  lx.curTok = Token(kind: tkStr, str: str)



  
proc getTok*(lx: var MLexr) =
  lx.skip()
  let start = lx.bufpos 
    
  if lx.buf[lx.bufpos] == EndOfFile:
    lx.handleEof()

  case lx.buf[lx.bufpos]
  of '#':
    inc lx.bufpos # move past `#`      
    lx.curTok = Token(kind: tkChar, charVal: lx.buf[lx.bufpos]) # this is very lax... just remember this is here
    inc lx.bufpos # move past the character
  of '{':
    inc lx.bufpos
    lx.curTok = Token(kind: tkLBrace)
  of '}':
    inc lx.bufpos
    lx.curTok = Token(kind: tkRBrace)
  of '[':
    inc lx.bufpos
    lx.curTok = Token(kind: tkLBracket)
  of ']':
    inc lx.bufpos
    lx.curTok = Token(kind: tkRBracket)
  of ':':
    inc lx.bufpos
    lx.curTok = Token(kind: tkColon)
  of '(':
    inc lx.bufpos
    lx.curTok = Token(kind: tkLpar)
  of ')':
    inc lx.bufpos
    lx.curTok = Token(kind: tkRpar)
  of '.':
    inc lx.bufpos
    lx.curTok = Token(kind: tkDot)
  of '\'':
    inc lx.bufpos
    lx.curTok = Token(kind: tkQuote)
  of '`':
    inc lx.bufpos
    lx.curTok = Token(kind: tkBquote)
  of ',':
    if (lx.bufpos + 1 < lx.buf.len) and (lx.buf[lx.bufpos + 1] == '@'):
      lx.bufpos += 2
      lx.curTok = Token(kind: tkSplice)
    else:
      inc lx.bufpos
      lx.curTok = Token(kind: tkComma)
  of ';':
    inc lx.bufpos
    lx.curTok = Token(kind: tkComment)
  of '"':
    lx.parseStr()
  of '0'..'9':
    lx.parseNumber(start) 
  of '+', '-':
    if (lx.bufpos + 1 < lx.buf.len) and lx.buf[lx.bufpos + 1].isDigit:
      lx.parseNumber(start)
    else:
      lx.parseSym(start)
  else:
    if lx.buf[lx.bufpos] in SymbolChars:
      lx.parseSym(start)
    else:
      raise newException(ValueError, "Invalid character: " & $lx.buf[lx.bufpos] & " at " & $lx.bufpos)    
  
