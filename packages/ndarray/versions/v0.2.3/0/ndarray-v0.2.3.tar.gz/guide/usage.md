## Usage

## Helper Macros

The library uses macros that simplify array operations and make the code
more readable. These macros use C99's compound literal feature to create
temporary arrays.

`NDA_DIMS(...)`: To define a list of dimensions for array creation.

```c
// Create a 3x4 array
NDArray arr = ndarray_new(NDA_DIMS(3, 4));
```

`NDA_POS(...)`: A position index for accessing array elements.

```c
// Set value at position (1, 2)
ndarray_set(arr, NDA_POS(1, 2), 42.0);
```

`NDA_AXES(...)`: A list of axes for tensor operations.

```c
// Contract on axes 2 of A and axis 0 of B
NDArray result = ndarray_new_tensordot(A, B, NDA_AXES(2), NDA_AXES(0));

// Contract on multiple axes
NDArray result = ndarray_new_tensordot(A, B, NDA_AXES(1, 2), NDA_AXES(0, 1));
```

`NDA_NO_AXES`: Special constant for tensor operations with no axis contraction.

```c
// Compute outer product
NDArray result = ndarray_new_tensordot(A, B, NDA_NO_AXES, NDA_NO_AXES);
```

`NDA_ALL_AXES`: Constant for operations on all axes (value: -1).

```c
// Aggregate over all axes
NDArray total = ndarray_new_aggr(A, NDA_ALL_AXES, NDA_AGGR_SUM);
NDArray max_val = ndarray_new_aggr(A, NDA_ALL_AXES, NDA_AGGR_MAX);
```

`NDA_LIST(...)`: Creates list of NDArray pointers.

```c
// Free multiple arrays at once
ndarray_free_all(NDA_LIST(A, B, C));
```

## Array Creation

```c
// Create a 3x4 array
NDArray arr = ndarray_new(NDA_DIMS(3, 4));

// Create arrays filled with values
NDArray zeros = ndarray_new_zeros(NDA_DIMS(2, 3));
NDArray ones = ndarray_new_ones(NDA_DIMS(2, 3));
NDArray filled = ndarray_new_full(NDA_DIMS(2, 3), 5.0);

// Create arrays with sequences
NDArray range = ndarray_new_arange(NDA_DIMS(1, 10), 0.0, 10.0, 1.0);
NDArray linsp = ndarray_new_linspace(NDA_DIMS(1, 100), 0.0, 1.0, 100);

// Create arrays with random values
NDArray norm = ndarray_new_randnorm(NDA_DIMS(3, 3), 0.0, 1.0);  // mean=0, std=1
NDArray unif = ndarray_new_randunif(NDA_DIMS(3, 3), 0.0, 1.0);  // min=0, max=1

// Always free arrays when done
ndarray_free(arr);
ndarray_free_all(NDA_LIST(zeros, ones, filled, range, linsp, norm, unif));
```

**Creating Arrays from Literals:**

```c
// 2D array (matrix)
double data_2d[3][4] = {
    {1.0, 2.0, 3.0, 4.0},
    {5.0, 6.0, 7.0, 8.0},
    {9.0, 10.0, 11.0, 12.0}
};
NDArray arr_2d = ndarray_new_from_data(NDA_DIMS(3, 4), (double*)data_2d);

// 3D array (tensor)
double data_3d[2][3][4] = {
    {
        {1.0, 2.0, 3.0, 4.0},
        {5.0, 6.0, 7.0, 8.0},
        {9.0, 10.0, 11.0, 12.0}
    },
    {
        {13.0, 14.0, 15.0, 16.0},
        {17.0, 18.0, 19.0, 20.0},
        {21.0, 22.0, 23.0, 24.0}
    }
};
NDArray arr_3d = ndarray_new_from_data(NDA_DIMS(2, 3, 4), (double*)data_3d);

// 4D and higher dimensions are also supported
double data_4d[2][2][3][2] = { /* ... */ };
NDArray arr_4d = ndarray_new_from_data(NDA_DIMS(2, 2, 3, 2), (double*)data_4d);

ndarray_free_all(NDA_LIST(arr_2d, arr_3d, arr_4d));
```

## Saving and Loading Arrays

```c
// Save an array to file
NDArray arr = ndarray_new_randunif(NDA_DIMS(3, 4), 0.0, 1.0);
if (ndarray_save(arr, "mydata.bin") != 0) {
    fprintf(stderr, "Failed to save array\n");
}

// Load an array from file
NDArray loaded = ndarray_load("mydata.bin");
if (loaded == NULL) {
    fprintf(stderr, "Failed to load array\n");
    return 1;
}

ndarray_print(loaded, "Loaded Array", 4);
ndarray_free_all(NDA_LIST(arr, loaded));
```

Binary File Format:

- Magic number: `0x4E444152` ("NDAR" in ASCII)
- Version: `uint32_t` (currently 1)
- Number of dimensions: `uint64_t`
- Dimension sizes: array of `uint64_t`
- Data: array of `double` (row-major order)

## Getting and Setting Values

```c
NDArray arr = ndarray_new_zeros(NDA_DIMS(3, 4));

// Set value at position (1, 2)
ndarray_set(arr, NDA_POS(1, 2), 42.0);

// Get value at position (1, 2)
double val = ndarray_get(arr, NDA_POS(1, 2));

// Set an entire row (axis 0) from an array of values
double row_data[] = {1.0, 2.0, 3.0, 4.0};
ndarray_set_slice(arr, 0, 1, row_data);  // Set row 1

// Set an entire column (axis 1) from an array of values
double col_data[] = {10.0, 20.0, 30.0};
ndarray_set_slice(arr, 1, 2, col_data);  // Set column 2

// Fill an entire row with a scalar value
ndarray_fill_slice(arr, 0, 0, 0.0);  // Fill row 0 with zeros

// Fill an entire column with a scalar value
ndarray_fill_slice(arr, 1, 3, 99.0);  // Fill column 3 with 99.0

// Works for any dimension - set a hyperplane in 3D array
NDArray arr3d = ndarray_new_zeros(NDA_DIMS(2, 3, 4));
double plane_data[8];  // 2*4 = 8 values for plane perpendicular to axis 1
for (int i = 0; i < 8; i++) plane_data[i] = i * 5.0;
ndarray_set_slice(arr3d, 1, 1, plane_data);  // Set middle plane

ndarray_free_all(NDA_LIST(arr, arr3d));
```

```c
// Print the array
ndarray_print(arr, "My Array", 4);  // precision = 4 decimal places

ndarray_free(arr);
```

## Element-wise Operations

```c
NDArray A = ndarray_new_ones(NDA_DIMS(3, 3));
NDArray B = ndarray_new_full(NDA_DIMS(3, 3), 2.0);

// Element-wise addition (modifies A in place)
ndarray_add(A, B);

// Element-wise multiplication (modifies A in place)
ndarray_mul(A, B);

// Scalar operations
ndarray_add_scalar(A, 10.0);
ndarray_mul_scalar(A, 2.0);

// Linear combination: A = alpha*A + beta*B
NDArray C = ndarray_new_full(NDA_DIMS(3, 3), 5.0);
NDArray D = ndarray_new_full(NDA_DIMS(3, 3), 3.0);
ndarray_axpby(C, 2.0, D, 3.0);  // C = 2*C + 3*D = 2*5 + 3*3 = 19

// Fused operations for better performance
ndarray_scale_shift(C, 0.5, 10.0);  // C = 0.5*C + 10 (scale and shift)
ndarray_mul_scaled(C, D, 2.0);       // C = C * D * 2 (multiply then scale)

// Map function then multiply (common in numerical computing)
double sqrt_fn(double x) { return sqrt(x); }
ndarray_map_mul(C, sqrt_fn, D, 0.5);  // C = sqrt(C) * D * 0.5

// Fused multiply-add
NDArray E = ndarray_new_ones(NDA_DIMS(3, 3));
ndarray_mul_add(C, D, E, 2.0, 1.0);  // E = 2*(C*D) + E

// Apply custom function element-wise
double square(double x) { return x * x; }
ndarray_mapfnc(A, square);

ndarray_free_all(NDA_LIST(A, B, C, D, E));
```

## Function Chaining (Nesting)

In-place operations return a pointer to the modified array, allowing them to be
chained/nested in a single expression.

```c
// Basic chaining: operations executed left-to-right
NDArray A = ndarray_new_ones(NDA_DIMS(3, 3));
NDArray B = ndarray_new_full(NDA_DIMS(3, 3), 2.0);

// Chain arithmetic operations: A = (A + B) * 5.0
ndarray_mul_scalar(ndarray_add(A, B), 5.0);

// Complex expression in single line
// result = ((A * 2) + 3) clipped to [0, 10]
ndarray_clip(
    ndarray_add_scalar(
        ndarray_mul_scalar(A, 2.0),
        3.0
    ),
    0.0, 10.0
);

ndarray_free_all(NDA_LIST(A, B));
```

```c
// Mathematical transformations
NDArray data = ndarray_new_randunif(NDA_DIMS(100, 100), -5.0, 5.0);

// ReLU activation: max(0, x)
ndarray_clip_min(data, 0.0);

// Normalized ReLU: clip to [0,1] then apply function
double sigmoid(double x) { return 1.0 / (1.0 + exp(-x)); }
ndarray_mapfnc(ndarray_clip(data, 0.0, 1.0), sigmoid);

// Chain with logical: abs(x) where x > 0, else 0
NDArray mask = ndarray_new_greater_scalar(data, 0.0);
NDArray result = ndarray_where(mask, ndarray_abs(data), 
                                ndarray_new_zeros(NDA_DIMS(100, 100)));

ndarray_free_all(NDA_LIST(data, mask, result));
```

```c
// Statistical preprocessing pipeline
NDArray raw_data = ndarray_new_randnorm(NDA_DIMS(1000, 50), 0.0, 1.0);

// Center and scale: (x - mean) / std, then clip outliers
NDArray mean = ndarray_new_aggr(raw_data, 0, NDA_AGGR_MEAN);
NDArray std = ndarray_new_aggr(raw_data, 0, NDA_AGGR_STD);

// Process in one expression: center, scale, clip
NDArray processed = ndarray_clip(
    ndarray_mul_scalar(
        ndarray_add(raw_data, ndarray_mul_scalar(mean, -1.0)),
        1.0  // Would normally be 1.0/std
    ),
    -3.0, 3.0  // Clip to ±3 standard deviations
);

ndarray_free_all(NDA_LIST(raw_data, mean, std, processed));
```

```c
// Combining transformations
NDArray X = ndarray_new_arange(NDA_DIMS(10, 10), -50.0, 50.0, 1.0);

// Multi-step transformation in single expression:
// 1. Apply abs() 
// 2. Add 10
// 3. Take square root via mapfnc
// 4. Clip to maximum of 5.0
double sqrt_fn(double x) { return sqrt(x); }
ndarray_clip_max(
    ndarray_mapfnc(
        ndarray_add_scalar(
            ndarray_abs(X), 
            10.0
        ), 
        sqrt_fn
    ), 
    5.0
);

ndarray_free(X);
```

About Chaining:

1. In-place operations (those without `_new_` in the name) modify the first
   argument and return it for chaining
2. Operations creating new arrays (with `_new_` in the name) cannot be
   chained as seamlessly since they allocate memory
3. Memory management: Only the outermost array needs to be freed when
   chaining in-place operations
4. Readability: While chaining is powerful, break complex chains across
   lines or use intermediate variables for clarity

```c
// Good: Clear and maintainable
NDArray data = ndarray_new_ones(NDA_DIMS(5, 5));
ndarray_mul_scalar(data, 2.0);
ndarray_add_scalar(data, 1.0);
ndarray_clip_max(data, 5.0);

// Also good: Chained but readable
ndarray_clip_max(
    ndarray_add_scalar(
        ndarray_mul_scalar(data, 2.0),
        1.0
    ),
    5.0
);

// Avoid: Too complex
ndarray_mul_scalar(ndarray_clip(ndarray_add(ndarray_abs(
                                 ndarray_mul_scalar(data, -1.0)), 
                                 ndarray_new_ones(NDA_DIMS(5,5))),
                                 0.0, 1.0), 10.0);

ndarray_free(data);
```

## Matrix Operations

```c
// Matrix multiplication
NDArray A = ndarray_new_ones(NDA_DIMS(3, 4));
NDArray B = ndarray_new_ones(NDA_DIMS(4, 5));
NDArray C = ndarray_new_matmul(A, B);  // Result: 3x5

// Transpose
NDArray At = ndarray_new_transpose(A);

// Matrix-vector multiply: y = alpha * A * x + beta * y
NDArray x = ndarray_new_full(NDA_DIMS(4, 1), 2.0);  // Column vector
NDArray y = ndarray_new_zeros(NDA_DIMS(3, 1));
ndarray_gemv(A, x, 1.0, 0.0, y);  // y = A * x

// Tensor contraction
NDArray X = ndarray_new(NDA_DIMS(2, 3, 4));
NDArray Y = ndarray_new(NDA_DIMS(4, 5));
// Contract on axis 2 of X and axis 0 of Y
NDArray Z = ndarray_new_tensordot(X, Y, NDA_AXES(2), NDA_AXES(0));  

ndarray_free_all(NDA_LIST(A, B, C, At, x, y, X, Y, Z));
```

## Conditional Operations

```c
// Non-negativity constraints (common in physics, finance, ML)
NDArray values = ndarray_new_arange(NDA_DIMS(3, 3), -4.0, 5.0, 1.0);
ndarray_clip_min(values, 0.0);  // ReLU activation, non-negative constraints

// Saturation / capping
ndarray_clip_max(values, 100.0);  // Prevent overflow

// Normalize to range [0, 1]
ndarray_clip(values, 0.0, 1.0);  // Probabilities, normalized ranges

// Absolute value and sign
NDArray errors = ndarray_new_arange(NDA_DIMS(2, 3), -2.0, 4.0, 1.0);
ndarray_abs(errors);   // Distance calculations, L1 norm
ndarray_sign(errors);  // Direction indicators

ndarray_free_all(NDA_LIST(values, errors));
```

## Comparison and Logical Operations

```c
// Element-wise comparisons (returns 1.0 for true, 0.0 for false)
NDArray A = ndarray_new_arange(NDA_DIMS(2, 3), 0.0, 6.0, 1.0);
NDArray B = ndarray_new_full(NDA_DIMS(2, 3), 3.0);

NDArray eq = ndarray_new_equal(A, B);           // A == B
NDArray lt = ndarray_new_less(A, B);            // A < B
NDArray gt = ndarray_new_greater(A, B);         // A > B

// Scalar comparisons
NDArray positive = ndarray_new_greater_scalar(A, 0.0);  // Find positive values
NDArray zeros = ndarray_new_equal_scalar(A, 0.0);       // Find zeros

// Logical operations
NDArray mask1 = ndarray_new_greater_scalar(A, 2.0);
NDArray mask2 = ndarray_new_less_scalar(A, 5.0);
NDArray combined = ndarray_logical_and(mask1, mask2);   // 2 < A < 5

// NumPy-style where (ternary operator)
NDArray x = ndarray_new_full(NDA_DIMS(2, 3), 10.0);
NDArray y = ndarray_new_full(NDA_DIMS(2, 3), -10.0);
NDArray result = ndarray_where(positive, x, y);  // positive ? x : y

ndarray_free_all(NDA_LIST(A, B, eq, lt, gt, positive, zeros, 
                          mask1, mask2, combined, x, y, result));
```

## Slice Access

```c
// Direct pointer access for advanced users
NDArray matrix = ndarray_new_arange(NDA_DIMS(4, 5), 0.0, 20.0, 1.0);

// Get pointer to row 2 (5 elements)
double* row2 = ndarray_get_slice_ptr(matrix, 0, 2);
printf("Row 2: [%.1f, %.1f, %.1f, %.1f, %.1f]\n", 
       row2[0], row2[1], row2[2], row2[3], row2[4]);

// Copy slices between arrays
NDArray dest = ndarray_new_zeros(NDA_DIMS(4, 5));
ndarray_copy_slice(matrix, 0, 1, dest, 0, 3);  // Copy row 1 to row 3

// Get slice size for allocation
size_t row_size = ndarray_get_slice_size(matrix, 0);  // 5 elements per row
size_t col_size = ndarray_get_slice_size(matrix, 1);  // 4 elements per column

ndarray_free_all(NDA_LIST(matrix, dest));
```

## Array Manipulation

```c
// Stack arrays along a new axis
NDArray A = ndarray_new_ones(NDA_DIMS(2, 3));
NDArray B = ndarray_new_zeros(NDA_DIMS(2, 3));
NDArray stacked = ndarray_new_stack(0, NDA_LIST(A, B));  // Result: 2x2x3

// Concatenate arrays along an existing axis
NDArray concat = ndarray_new_concat(1, NDA_LIST(A, B));  // Result: 2x6

// Extract subregion
NDArray sub = ndarray_new_take(A, 1, 0, 2);  // Take columns 0 and 1

// Reshape array in-place (data preserved in row-major order)
NDArray C = ndarray_new_arange(NDA_DIMS(2, 6), 0, 12, 1);  // [2,6]
ndarray_reshape(C, NDA_DIMS(3, 4));  // Now [3,4]
ndarray_reshape(C, NDA_DIMS(2, 2, 3));  // Now [2,2,3]
ndarray_reshape(C, NDA_DIMS(4, -1));  // Now [4,3] (inferred dimension)

ndarray_free_all(NDA_LIST(A, B, stacked, concat, sub, C));
```

## Aggregations

```c
NDArray A = ndarray_new_randunif(NDA_DIMS(3, 4), 0.0, 10.0);

// Aggregate along specific axis (returns NDArray)
NDArray sum_axis0 = ndarray_new_aggr(A, 0, NDA_AGGR_SUM);
NDArray mean_axis1 = ndarray_new_aggr(A, 1, NDA_AGGR_MEAN);
NDArray std_axis0 = ndarray_new_aggr(A, 0, NDA_AGGR_STD);

// Aggregate over all axes (returns NDArray with shape [1,1])
NDArray max_all = ndarray_new_aggr(A, NDA_ALL_AXES, NDA_AGGR_MAX);
NDArray min_all = ndarray_new_aggr(A, NDA_ALL_AXES, NDA_AGGR_MIN);

// Scalar aggregations (returns double directly, no memory allocation)
double total = ndarray_scalar_aggr(A, NDA_AGGR_SUM);
double average = ndarray_scalar_aggr(A, NDA_AGGR_MEAN);
double maximum = ndarray_scalar_aggr(A, NDA_AGGR_MAX);
double minimum = ndarray_scalar_aggr(A, NDA_AGGR_MIN);
double std_dev = ndarray_scalar_aggr(A, NDA_AGGR_STD);

ndarray_free_all(NDA_LIST(A, sum_axis0, mean_axis1, std_axis0, max_all, min_all));
// Note: No need to free scalar results (total, average, etc.)
```

## Example

```c
#include <stdio.h>
#include <math.h>
#include "ndarray.h"

int main() {
    // Create matrices from literals
    double m1_data[2][3] = {{1.0, 2.0, 3.0}, {4.0, 5.0, 6.0}};
    double m2_data[3][2] = {{7.0, 8.0}, {9.0, 10.0}, {11.0, 12.0}};
    
    NDArray A = ndarray_new_from_data(NDA_DIMS(2, 3), (double*)m1_data);
    NDArray B = ndarray_new_from_data(NDA_DIMS(3, 2), (double*)m2_data);
    
    ndarray_print(A, "Matrix A", 1);
    ndarray_print(B, "Matrix B", 1);
    
    // Matrix multiplication
    NDArray C = ndarray_new_matmul(A, B);
    ndarray_print(C, "A @ B", 1);
    
    // Save result
    if (ndarray_save(C, "result.bin") == 0) {
        printf("Result saved to result.bin\n");
    }
    
    // Load and verify
    NDArray loaded = ndarray_load("result.bin");
    if (loaded != NULL) {
        ndarray_print(loaded, "Loaded Result", 1);
        ndarray_free(loaded);
    }
    
    // Clean up
    ndarray_free_all(NDA_LIST(A, B, C));
    return 0;
}
```

Output:

```
Array 'Matrix A' [2, 3]:
[[    1.0     2.0     3.0]
 [    4.0     5.0     6.0]]
Array 'Matrix B' [3, 2]:
[[    7.0     8.0]
 [    9.0    10.0]
 [   11.0    12.0]]
Array 'A @ B' [2, 2]:
[[   58.0    64.0]
 [  139.0   154.0]]
Result saved to result.bin
Array 'Loaded Result' [2, 2]:
[[   58.0    64.0]
 [  139.0   154.0]]
```
