import std/[json, oids, strutils, sequtils, options]
import tiny_sqlite


##
## Exception types for NJSDB
type NJSDBError* = object of CatchableError
  ## Base exception for all NJSDB errors

type ValidationError* = object of NJSDBError
  ## Raised when input validation fails

type DocumentError* = object of NJSDBError
  ## Raised when document operations fail


##
## Helper: Convert field name to SQLite JSON path
## "user.name" -> "$.user.name"
## "tags[0]" -> "$.tags[0]"
proc toJsonPath(field: string): string =
  if field.len == 0:
    return "$"
  return "$." & field




##
## Query filter types
type LogicalOp = enum
  loAnd, loOr, loNor

type ArrayOp = enum
  aoAll, aoElemMatch, aoSize

##
## Query filter info for a single condition
type NJSDBFilter* = object
  field*: string
  operation*: string
  value*: string
  values*: seq[string]  # For IN operations
  fieldIsNumber*: bool
  fieldIsBoolean*: bool  # For boolean comparisons
  negate*: bool  # For $not operator (negate this filter)

##
## Logical filter group for $and/$or operations
type NJSDBLogicalFilter* = object
  op*: LogicalOp
  filters*: seq[NJSDBFilter]

##
## Not filter for $not operator
type NJSDBNotFilter* = object
  filter*: NJSDBFilter

##
## Array filter for array operations ($all, $size)
type NJSDBArrayFilter* = object
  field*: string
  op*: ArrayOp
  values*: seq[string]  # For $all operation
  size*: int  # For $size operation

##
## Exists filter for $exists operator
type NJSDBExistsFilter* = object
  field*: string
  exists*: bool  # true = field exists, false = field does not exist

##
## Type filter for $type operator
type NJSDBTypeFilter* = object
  field*: string
  jsonType*: string  # "string", "number", "boolean", "array", "object", "null"

##
## Regex filter for $regex operator
type NJSDBRegexFilter* = object
  field*: string
  pattern*: string
  options*: string  # "i" for case-insensitive (using GLOB)


##
## Shared validation logic for where methods
proc validateWhereParams(field, operation: string) {.inline.} =
  if field.len == 0:
    raise newException(ValidationError, "No field provided")
  if operation.len == 0:
    raise newException(ValidationError, "No operation provided")
  if operation notin ["==", "!=", "<", "<=", ">", ">="]:
    raise newException(ValidationError, "Unknown operation: " & operation)

##
## A simple NoSQL database written in Nim.
type NJSDB* = ref object
  ## (private) Database connection
  conn*: DbConn

  ## (private) True if the database has been prepared yet
  hasPrepared*: bool

  ## (private) Extra columns that have been created for indexing
  extraColumns*: seq[string]

  ## (private) List of hashes of generated indexes
  createdIndexHashes*: seq[string]

  ## (private) Current collection/table name (empty until collection() is called)
  currentCollection*: string

##
## Query builder
type NJSDBQuery* = ref object
  ## Reference to the database
  db*: NJSDB

  ## List of filters
  filters*: seq[NJSDBFilter]

  ## List of logical filter groups ($and, $or)
  logicalFilters*: seq[NJSDBLogicalFilter]

  ## List of not filters ($not)
  notFilters*: seq[NJSDBNotFilter]

  ## List of array filters ($all, $size)
  arrayFilters*: seq[NJSDBArrayFilter]

  ## List of exists filters ($exists)
  existsFilters*: seq[NJSDBExistsFilter]

  ## List of type filters ($type)
  typeFilters*: seq[NJSDBTypeFilter]

  ## List of regex filters ($regex)
  regexFilters*: seq[NJSDBRegexFilter]

  ## Projection fields (field selection)
  projection*: JsonNode  # nil means no projection (return all fields)
  projectionInclude*: bool    # true = include specified fields, false = exclude specified fields

  ## Sort field
  sortField*: string
  sortAscending*: bool
  sortIsNumber*: bool

  ## Limit
  pLimit*: int

  ## Offset
  pOffset*: int

## Initialize a new NJSDBQuery
proc newNJSDBQuery*(): NJSDBQuery =
  new(result)
  result.db = nil
  result.filters = @[]
  result.logicalFilters = @[]
  result.notFilters = @[]
  result.arrayFilters = @[]
  result.existsFilters = @[]
  result.typeFilters = @[]
  result.regexFilters = @[]
  result.projection = nil
  result.projectionInclude = true
  result.sortField = ""
  result.sortAscending = true
  result.sortIsNumber = true
  result.pLimit = -1
  result.pOffset = 0

## (chainable) Add a filter. Operation is one of: `==` `!=` `<` `<=` `>` `>=`
proc where*(this: NJSDBQuery, field: string, operation: string, value: string): NJSDBQuery {.gcsafe.} =
  validateWhereParams(field, operation)
  let filter = NJSDBFilter(field: field, operation: operation, value: value, fieldIsNumber: false)
  this.filters.add(filter)
  return this

## (chainable) Add a filter. Operation is one of: `==` `!=` `<` `<=` `>` `>=`
proc where*(this: NJSDBQuery, field: string, operation: string, value: float): NJSDBQuery {.gcsafe.} =
  validateWhereParams(field, operation)
  let filter = NJSDBFilter(field: field, operation: operation, value: $value, fieldIsNumber: true)
  this.filters.add(filter)
  return this


## (chainable) Add a filter from a JsonNode filter object (supports MongoDB-style $in)
proc filter*(this: NJSDBQuery, filterObj: JsonNode): NJSDBQuery {.gcsafe.} =

  # Check input
  if filterObj == nil or filterObj.kind != JObject:
    raise newException(ValidationError, "Filter must be a JSON object")

  proc jsonToString(node: JsonNode): string =
    case node.kind:
      of JString: return node.getStr()
      of JInt: return $node.getInt()
      of JFloat: return $node.getFloat()
      of JBool: return $node.getBool()
      else: return $node

  proc processCondition(field: string, val: JsonNode): NJSDBFilter =
    if val.kind == JObject:
      # Check for MongoDB-style operators like $in
      if "$in" in val:
        let inValues = val["$in"]
        if inValues.kind == JArray and inValues.len > 0:
          var values: seq[string] = @[]
          var isNum = false
          for v in inValues:
            values.add(jsonToString(v))
            if v.kind == JInt or v.kind == JFloat:
              isNum = true
          return NJSDBFilter(field: field, operation: "IN", values: values, fieldIsNumber: isNum)
      elif "$nin" in val:
        let ninValues = val["$nin"]
        if ninValues.kind == JArray and ninValues.len > 0:
          var values: seq[string] = @[]
          var isNum = false
          for v in ninValues:
            values.add(jsonToString(v))
            if v.kind == JInt or v.kind == JFloat:
              isNum = true
          return NJSDBFilter(field: field, operation: "NOT IN", values: values, fieldIsNumber: isNum)
      elif "$eq" in val:
        let eqVal = val["$eq"]
        let isNum = eqVal.kind == JInt or eqVal.kind == JFloat
        return NJSDBFilter(field: field, operation: "==", value: jsonToString(eqVal), fieldIsNumber: isNum)
      elif "$ne" in val:
        let neVal = val["$ne"]
        let isNum = neVal.kind == JInt or neVal.kind == JFloat
        return NJSDBFilter(field: field, operation: "!=", value: jsonToString(neVal), fieldIsNumber: isNum)
      elif "$gt" in val:
        let gtVal = val["$gt"]
        let isNum = gtVal.kind == JInt or gtVal.kind == JFloat
        return NJSDBFilter(field: field, operation: ">", value: jsonToString(gtVal), fieldIsNumber: isNum)
      elif "$gte" in val:
        let gteVal = val["$gte"]
        let isNum = gteVal.kind == JInt or gteVal.kind == JFloat
        return NJSDBFilter(field: field, operation: ">=", value: jsonToString(gteVal), fieldIsNumber: isNum)
      elif "$lt" in val:
        let ltVal = val["$lt"]
        let isNum = ltVal.kind == JInt or ltVal.kind == JFloat
        return NJSDBFilter(field: field, operation: "<", value: jsonToString(ltVal), fieldIsNumber: isNum)
      elif "$lte" in val:
        let lteVal = val["$lte"]
        let isNum = lteVal.kind == JInt or lteVal.kind == JFloat
        return NJSDBFilter(field: field, operation: "<=", value: jsonToString(lteVal), fieldIsNumber: isNum)
      elif "$not" in val:
        # $not operator - negate the inner condition
        let notVal = val["$not"]
        if notVal.kind == JObject:
          # Process the inner condition and negate it
          var innerFilter = processCondition(field, notVal)
          if innerFilter.field.len > 0:
            innerFilter.negate = true
            return innerFilter
        elif notVal.kind == JBool:
          # $not: true means field should be false (not true)
          # $not: false means field should be true (not false)
          let boolValue = if notVal.getBool(): "1" else: "0"
          return NJSDBFilter(field: field, operation: "==", value: boolValue, fieldIsNumber: true, fieldIsBoolean: true, negate: true)
        elif notVal.kind == JNull:
          # $not: null means field should exist and not be null
          return NJSDBFilter(field: field, operation: "IS NOT NULL", value: "", fieldIsNumber: false, negate: false)
        else:
          # $not: value means field != value
          let isNum = notVal.kind == JInt or notVal.kind == JFloat
          return NJSDBFilter(field: field, operation: "!=", value: jsonToString(notVal), fieldIsNumber: isNum)
    elif val.kind == JString:
      return NJSDBFilter(field: field, operation: "==", value: val.getStr(), fieldIsNumber: false)
    elif val.kind == JInt or val.kind == JFloat:
      return NJSDBFilter(field: field, operation: "==", value: $val, fieldIsNumber: true)
    elif val.kind == JBool:
      # SQLite stores booleans as integers (1/0)
      let boolValue = if val.getBool(): "1" else: "0"
      return NJSDBFilter(field: field, operation: "==", value: boolValue, fieldIsNumber: true, fieldIsBoolean: true)

    return NJSDBFilter()

  if "$or" in filterObj:
    let orArray = filterObj["$or"]
    if orArray.kind == JArray:
      var orFilters: seq[NJSDBFilter] = @[]
      for item in orArray:
        if item.kind == JObject and item.len > 0:
          # Get the first (and typically only) field from the object
          for field, val in item:
            let f = processCondition(field, val)
            if f.field.len > 0:
              orFilters.add(f)
            break
      if orFilters.len > 0:
        let logicalFilter = NJSDBLogicalFilter(op: loOr, filters: orFilters)
        this.logicalFilters.add(logicalFilter)

  if "$and" in filterObj:
    let andArray = filterObj["$and"]
    if andArray.kind == JArray:
      var andFilters: seq[NJSDBFilter] = @[]
      for item in andArray:
        if item.kind == JObject and item.len > 0:
          for field, val in item:
            let f = processCondition(field, val)
            if f.field.len > 0:
              andFilters.add(f)
            break
      if andFilters.len > 0:
        let logicalFilter = NJSDBLogicalFilter(op: loAnd, filters: andFilters)
        this.logicalFilters.add(logicalFilter)

  if "$nor" in filterObj:
    let norArray = filterObj["$nor"]
    if norArray.kind == JArray:
      var norFilters: seq[NJSDBFilter] = @[]
      for item in norArray:
        if item.kind == JObject and item.len > 0:
          for field, val in item:
            let f = processCondition(field, val)
            if f.field.len > 0:
              norFilters.add(f)
            break
      if norFilters.len > 0:
        # $nor is equivalent to NOT ($or(...))
        let logicalFilter = NJSDBLogicalFilter(op: loNor, filters: norFilters)
        this.logicalFilters.add(logicalFilter)

  # $not can be used like: { field: { $not: { $gt: 5 } } }
  # or: { field: { $not: { $in: [1, 2, 3] } } }

  for field, val in filterObj:
    if field == "$or" or field == "$and" or field == "$nor":
      continue
    
    if val.kind == JObject:
      var processedSpecialOp = false
      
      # Check for $all operator
      if "$all" in val:
        let allValues = val["$all"]
        if allValues.kind == JArray and allValues.len > 0:
          var values: seq[string] = @[]
          for v in allValues:
            values.add(jsonToString(v))
          let arrayFilter = NJSDBArrayFilter(field: field, op: aoAll, values: values)
          this.arrayFilters.add(arrayFilter)
        processedSpecialOp = true
      
      # Check for $size operator
      if "$size" in val:
        let sizeVal = val["$size"]
        if sizeVal.kind == JInt:
          let arrayFilter = NJSDBArrayFilter(field: field, op: aoSize, size: sizeVal.getInt())
          this.arrayFilters.add(arrayFilter)
        processedSpecialOp = true
      
      # Check for $exists operator
      if "$exists" in val:
        let existsVal = val["$exists"]
        if existsVal.kind == JBool:
          let existsFilter = NJSDBExistsFilter(field: field, exists: existsVal.getBool())
          this.existsFilters.add(existsFilter)
        processedSpecialOp = true
      
      # Check for $type operator
      if "$type" in val:
        let typeVal = val["$type"]
        if typeVal.kind == JString:
          let typeFilter = NJSDBTypeFilter(field: field, jsonType: typeVal.getStr())
          this.typeFilters.add(typeFilter)
        processedSpecialOp = true
      
      # Check for $regex operator
      if "$regex" in val:
        let regexVal = val["$regex"]
        var pattern = ""
        var options = ""
        
        if regexVal.kind == JString:
          pattern = regexVal.getStr()
        elif regexVal.kind == JObject:
          if "$regex" in regexVal:
            let patNode = regexVal["$regex"]
            if patNode.kind == JString:
              pattern = patNode.getStr()
          if "$options" in regexVal:
            let optNode = regexVal["$options"]
            if optNode.kind == JString:
              options = optNode.getStr()
        
        if pattern.len > 0:
          let regexFilter = NJSDBRegexFilter(field: field, pattern: pattern, options: options)
          this.regexFilters.add(regexFilter)
        processedSpecialOp = true
      
      # If we processed any special operator, skip regular processing
      if processedSpecialOp:
        continue
    
    let f = processCondition(field, val)
    if f.field.len > 0:
      this.filters.add(f)
  
  return this


## (chainable) Set sort field
proc sort*(this: NJSDBQuery, field: string, ascending: bool = true, isNumber: bool = true): NJSDBQuery {.gcsafe.} =

  # Check input
  if field.len == 0:
    raise newException(ValidationError, "No field provided")
  
  this.sortField = field
  this.sortAscending = ascending
  this.sortIsNumber = isNumber
  return this


## (chainable) Set the maximum number of documents to return, or -1 to return all documents.
proc limit*(this: NJSDBQuery, count: int): NJSDBQuery {.gcsafe.} =

  # Check input
  if count < -1:
    raise newException(ValidationError, "Cannot use negative numbers for the limit")

  this.pLimit = count
  return this


## (chainable) Set the number of documents to skip
proc offset*(this: NJSDBQuery, count: int): NJSDBQuery {.gcsafe.} =

  # Check input
  if count < 0:
    raise newException(ValidationError, "Cannot use negative numbers for the offset")

  this.pOffset = count
  return this


## (chainable) Set projection to return only specific fields.
## Use { "field": 1 } to include fields, { "field": 0 } to exclude fields.
## Cannot mix include and exclude (except _id can always be excluded).
proc project*(this: NJSDBQuery, projectionObj: JsonNode): NJSDBQuery {.gcsafe.} =

  # Check input
  if projectionObj == nil or projectionObj.kind != JObject:
    raise newException(ValidationError, "Projection must be a JSON object")

  var hasInclude = false
  var hasExclude = false
  for field, val in projectionObj:
    if val.kind == JInt:
      if val.getInt() == 1:
        hasInclude = true
      elif val.getInt() == 0:
        hasExclude = true
  
  if hasInclude and hasExclude:
    raise newException(ValidationError, "Cannot mix include and exclude in projection (except _id)")

  this.projection = projectionObj
  this.projectionInclude = hasInclude
  return this




## Forward declarations
proc prepareDB*(this: NJSDB) {.gcsafe.}

## Initialize a new NJSDB
proc newNJSDB*(): NJSDB =
  new(result)
  # conn will be set by open()
  result.hasPrepared = false
  result.extraColumns = @["id"]
  result.createdIndexHashes = @[]
  result.currentCollection = ""

## Open a database connection
##
## Parameters:
##   filename: Path to the SQLite database file. Use ":memory:" for an in-memory database.
##
## Example:
##   var db = newNJSDB()
##   db.open("mydb.db")
##   var memDb = newNJSDB()
##   memDb.open(":memory:")
proc open*(this: NJSDB, filename: string) {.gcsafe.} =

  this.conn = openDatabase(filename)


## Close the database
proc close*(this: NJSDB) {.gcsafe.} =

  # Close database
  if this.conn.isOpen:
    this.conn.close()


## Select a collection (table) to work with
##
## Parameters:
##   name: The name of the collection/table
##
## Returns:
##   The NJSDB instance for method chaining
##
## Example:
##   db.collection("users").put(%*{ "id": "user1", "name": "Alice" })
##   db.collection("orders").put(%*{ "id": "order1", "total": 100 })
proc collection*(this: NJSDB, name: string): NJSDB {.gcsafe.} =

  this.currentCollection = name

  # Reset prepared flag since we're switching to a different table
  this.hasPrepared = false
  this.extraColumns = @["id"]
  this.createdIndexHashes = @[]

  # Prepare the new collection
  this.prepareDB()

  return this


## (private) Prepare the datatabase for use
proc prepareDB*(this: NJSDB) {.gcsafe.} =

  # Only do once
  if this.hasPrepared: return
  this.hasPrepared = true

  # Check if collection has been selected
  if this.currentCollection.len == 0:
    raise newException(NJSDBError, "No collection selected. Call collection(name) first.")

  let createTableSql = "CREATE TABLE IF NOT EXISTS " & this.currentCollection & " (id TEXT PRIMARY KEY, _json TEXT)"
  this.conn.exec(createTableSql)

  let pragmaSql = "PRAGMA table_info(" & this.currentCollection & ")"
  for row in this.conn.iterate(pragmaSql):

    let columnName = row[1].strVal
    if columnName == "_json": continue
    if not this.extraColumns.contains(columnName):
      this.extraColumns.add(columnName)


## Execute a transaction. Either they all succeed, or the database will not be updated. This is also much faster when saving lots of documents at once.
proc withTransaction*(this: NJSDB, code: proc() {.gcsafe.}) {.gcsafe.} =

  # Prepate database
  this.prepareDB()

  # Use tiny_sqlite's transaction template
  this.conn.transaction:
    # Execute the caller's code
    code()


## Start a query
proc query*(this: NJSDB): NJSDBQuery {.gcsafe.} =

  # Prepare database
  this.prepareDB()

  result = newNJSDBQuery()
  result.db = this


## (private) Ensure column exists for the specified field
proc createIndexableColumnForField*(this: NJSDB, name: string, sqlName: string, sqlType: string) {.gcsafe.} =

  if this.extraColumns.contains(sqlName):
    return

  this.withTransaction do():

    # Create new field on the table
    let str = "ALTER TABLE " & this.currentCollection & " ADD \"" & sqlName & "\" " & sqlType
    this.conn.exec(str)

    # Fetch all existing documents ... this is heavy, but we can't iterate and modify at the same time
    let sqlUpdateRow = "UPDATE " & this.currentCollection & " SET \"" & sqlName & "\" = ? WHERE id = ?"
    let selectSql = "SELECT id, _json FROM " & this.currentCollection
    for row in this.conn.all(selectSql):

      # Parse this document
      let id = row[0].strVal
      let json = parseJson(row[1].strVal)

      # Get field value
      let node = json{name}
      var value = ""
      if node.isNil: value = ""
      elif node.kind == JString: value = node.getStr()
      elif node.kind == JFloat: value = $node.getFloat()
      elif node.kind == JInt: value = $node.getInt()

      # Set row value
      if value.len > 0:
        this.conn.exec(sqlUpdateRow, value, id)

  # Done, update extra columns
  this.extraColumns.add(sqlName)


## (private) Create an index for the specified query, if needed
proc createIndex*(this: NJSDB, query: NJSDBQuery) {.gcsafe.} =

  if query.sortField == "" and query.filters.len == 0:
    return

  # Check if index created
  let indexHash = query.filters.mapIt(it.field).join("_") & query.sortField
  if this.createdIndexHashes.contains(indexHash):
    return
  
  var sqlStr = "CREATE INDEX IF NOT EXISTS \"" & this.currentCollection & "_" & indexHash & "\" ON " & this.currentCollection & " ("

  var addedFirst = false
  for filter in query.filters:

    var sqlType = if filter.fieldIsNumber: "REAL" else: "TEXT"
    var sqlName = filter.field & "_" & sqlType
    
    if addedFirst: sqlStr &= ", "
    addedFirst = true

    sqlStr &= "\"" & sqlName & "\""

  if query.sortField.len > 0:

    var sqlType = if query.sortIsNumber: "REAL" else: "TEXT"
    var sqlName = query.sortField & "_" & sqlType
    
    if addedFirst: sqlStr &= ", "
    addedFirst = true

    sqlStr &= "\"" & sqlName & "\""

  # Close the SQL
  sqlStr &= ")"

  this.conn.exec(sqlStr)

  # Done, store index hash
  this.createdIndexHashes.add(indexHash)



## Helper: Build SQL condition for a single filter
proc buildFilterSql(filter: NJSDBFilter, bindValues: var seq[DbValue]): string =
  if filter.operation == "IN":
    # Handle IN operation with multiple values
    if filter.negate:
      result &= "NOT ("
    # For numeric fields, cast json_extract result to REAL
    if filter.fieldIsNumber:
      result &= "CAST(json_extract(_json, ?) AS REAL) IN ("
    else:
      result &= "json_extract(_json, ?) IN ("
    bindValues.add(toDbValue(filter.field.toJsonPath()))
    for i in 0 ..< filter.values.len:
      if i > 0: result &= ", "
      result &= "?"
      bindValues.add(toDbValue(filter.values[i]))
    result &= ")"
    if filter.negate:
      result &= ")"
  elif filter.operation == "NOT IN":
    # Handle NOT IN operation with multiple values
    if filter.negate:
      result &= "NOT ("
    # For numeric fields, cast json_extract result to REAL
    if filter.fieldIsNumber:
      result &= "CAST(json_extract(_json, ?) AS REAL) NOT IN ("
    else:
      result &= "json_extract(_json, ?) NOT IN ("
    bindValues.add(toDbValue(filter.field.toJsonPath()))
    for i in 0 ..< filter.values.len:
      if i > 0: result &= ", "
      result &= "?"
      bindValues.add(toDbValue(filter.values[i]))
    result &= ")"
    if filter.negate:
      result &= ")"
  elif filter.operation == "IS NOT NULL":
    # Handle IS NOT NULL (for $not: null)
    result &= "json_extract(_json, ?) IS NOT NULL"
    bindValues.add(toDbValue(filter.field.toJsonPath()))
  else:
    # For numeric comparisons, cast json_extract result to REAL
    if filter.negate:
      result &= "NOT ("
    if filter.fieldIsNumber:
      result &= "CAST(json_extract(_json, ?) AS REAL) " & filter.operation & " CAST(? AS REAL)"
    elif filter.fieldIsBoolean:
      # For boolean comparisons, SQLite stores booleans as integers (1/0)
      # Use numeric comparison
      result &= "CAST(json_extract(_json, ?) AS INTEGER) " & filter.operation & " CAST(? AS INTEGER)"
    else:
      result &= "json_extract(_json, ?) " & filter.operation & " ?"
    bindValues.add(toDbValue(filter.field.toJsonPath()))
    bindValues.add(toDbValue(filter.value))
    if filter.negate:
      result &= ")"


## Helper: Build SQL condition for array filters
proc buildArrayFilterSql(arrayFilter: NJSDBArrayFilter, bindValues: var seq[DbValue]): string =
  case arrayFilter.op:
    of aoAll:
      # $all - Array contains all specified values
      # Use json_each to check if all values exist in the array
      var conditions: seq[string] = @[]
      for value in arrayFilter.values:
        conditions.add("EXISTS (SELECT 1 FROM json_each(_json, ?) WHERE value = ?)")
        bindValues.add(toDbValue(arrayFilter.field.toJsonPath()))
        bindValues.add(toDbValue(value))
      result &= conditions.join(" AND ")
    of aoSize:
      # $size - Array has specific length
      # Check if json_type is 'array' and length matches
      # Use CAST to ensure proper comparison
      result &= "json_type(json_extract(_json, ?)) = 'array' AND CAST(json_array_length(json_extract(_json, ?)) AS TEXT) = ?"
      bindValues.add(toDbValue(arrayFilter.field.toJsonPath()))
      bindValues.add(toDbValue(arrayFilter.field.toJsonPath()))
      bindValues.add(toDbValue($arrayFilter.size))
    of aoElemMatch:
      # $elemMatch - Not implemented yet (requires complex subquery)
      discard


## Helper: Build SQL condition for exists filters
proc buildExistsFilterSql(existsFilter: NJSDBExistsFilter, bindValues: var seq[DbValue]): string =
  # Note: SQLite's json_extract returns NULL for both non-existent fields AND null values
  # So $exists: true matches fields with non-null values
  # And $exists: false matches non-existent fields OR null values
  if existsFilter.exists:
    # Field exists with non-null value
    result &= "json_extract(_json, ?) IS NOT NULL"
  else:
    # Field does not exist or is null
    result &= "json_extract(_json, ?) IS NULL"
  bindValues.add(toDbValue(existsFilter.field.toJsonPath()))


## Helper: Convert MongoDB-style type names to SQLite json_type values
proc toJsonTypeName(mongoType: string): seq[string] =
  # SQLite json_type returns: 'null', 'true', 'false', 'integer', 'real', 'text', 'array', 'object'
  # MongoDB types: "string", "number", "boolean", "array", "object", "null"
  case mongoType:
    of "string": return @["text"]
    of "number": return @["integer", "real"]
    of "boolean": return @["true", "false"]
    of "array": return @["array"]
    of "object": return @["object"]
    of "null": return @["null"]
    else: return @[]


## Helper: Build SQL condition for type filters
proc buildTypeFilterSql(typeFilter: NJSDBTypeFilter, bindValues: var seq[DbValue]): string =
  let sqliteTypes = toJsonTypeName(typeFilter.jsonType)
  if sqliteTypes.len == 0:
    return "1=1"  # Invalid type, match everything
  
  # Note: Use json_type(_json, path) directly, not json_type(json_extract(...))
  # The latter causes "malformed JSON" errors in SQLite
  if sqliteTypes.len == 1:
    result &= "json_type(_json, ?) = ?"
    bindValues.add(toDbValue(typeFilter.field.toJsonPath()))
    bindValues.add(toDbValue(sqliteTypes[0]))
  else:
    # Multiple SQLite types (e.g., number = integer OR real)
    result &= "json_type(_json, ?) IN ("
    bindValues.add(toDbValue(typeFilter.field.toJsonPath()))
    for i in 0 ..< sqliteTypes.len:
      if i > 0: result &= ", "
      result &= "?"
      bindValues.add(toDbValue(sqliteTypes[i]))
    result &= ")"


## Helper: Convert regex pattern to SQL LIKE pattern
## Note: This is a basic conversion. Complex regex features are not supported.
## Supports: .* -> %, . -> _, * -> %, ? -> _
proc regexToLikePattern(regexPattern: string): string =
  result = regexPattern
  
  # Handle anchors first
  let hasStartAnchor = result.startsWith("^")
  let hasEndAnchor = result.endsWith("$")
  
  if hasStartAnchor:
    result = result[1..^1]
  if hasEndAnchor and result.len > 0:
    result = result[0..^2]
  
  # Replace common regex patterns with LIKE patterns
  # .* -> % (any characters)
  result = result.replace(".*", "%")
  # . -> _ (single character)
  result = result.replace(".", "_")
  # Also support shell-style wildcards
  # * -> % (any characters)
  result = result.replace("*", "%")
  # ? -> _ (single character)
  result = result.replace("?", "_")
  
  if not hasStartAnchor and not result.startsWith("%"):
    result = "%" & result
  
  if not hasEndAnchor and not result.endsWith("%"):
    result = result & "%"


## Helper: Build SQL condition for regex filters
proc buildRegexFilterSql(regexFilter: NJSDBRegexFilter, bindValues: var seq[DbValue]): string =
  # Use LIKE for basic regex support (case-insensitive with options="i")
  # GLOB is case-sensitive by default, LIKE is case-insensitive by default in SQLite
  # We use LIKE for case-insensitive, GLOB for case-sensitive
  
  let likePattern = regexToLikePattern(regexFilter.pattern)
  
  # Check if case-insensitive is requested
  let caseInsensitive = "i" in regexFilter.options
  
  if caseInsensitive or regexFilter.options.len == 0:
    # Use LIKE (case-insensitive by default in SQLite)
    result &= "json_extract(_json, ?) LIKE ? ESCAPE '\\'"
  else:
    # Use GLOB (case-sensitive)
    result &= "json_extract(_json, ?) GLOB ?"
  
  bindValues.add(toDbValue(regexFilter.field.toJsonPath()))
  bindValues.add(toDbValue(likePattern))


## Execute the query and return all documents.
proc prepareQuerySql(this: NJSDBQuery, sqlPrefix: string): (string, seq[DbValue]) =

  var db = this.db
  
  var bindValues : seq[DbValue]
  var sqlStr = sqlPrefix

  # Check if we have any filters
  let hasFilters = this.filters.len > 0 or this.logicalFilters.len > 0 or this.arrayFilters.len > 0 or this.existsFilters.len > 0 or this.typeFilters.len > 0 or this.regexFilters.len > 0

  if hasFilters:

    sqlStr &= " WHERE "
    var addedFirst = false

    for filter in this.filters:
      # Add the 'AND' if this is not the first filter
      if addedFirst: sqlStr &= " AND "
      addedFirst = true

      # Add the filter
      sqlStr &= buildFilterSql(filter, bindValues)

    for logicalFilter in this.logicalFilters:
      if addedFirst: sqlStr &= " AND "
      addedFirst = true

      if logicalFilter.op == loNor:
        # $nor is NOT ($or(...))
        sqlStr &= "NOT ("
        var firstInGroup = true
        for filter in logicalFilter.filters:
          if not firstInGroup: sqlStr &= " OR "
          firstInGroup = false
          sqlStr &= buildFilterSql(filter, bindValues)
        sqlStr &= ")"
      else:
        let logicalOp = if logicalFilter.op == loOr: " OR " else: " AND "
        sqlStr &= "("
        var firstInGroup = true
        for filter in logicalFilter.filters:
          if not firstInGroup: sqlStr &= logicalOp
          firstInGroup = false
          sqlStr &= buildFilterSql(filter, bindValues)
        sqlStr &= ")"

    for arrayFilter in this.arrayFilters:
      if addedFirst: sqlStr &= " AND "
      addedFirst = true
      sqlStr &= buildArrayFilterSql(arrayFilter, bindValues)

    for existsFilter in this.existsFilters:
      if addedFirst: sqlStr &= " AND "
      addedFirst = true
      sqlStr &= buildExistsFilterSql(existsFilter, bindValues)
    
    for typeFilter in this.typeFilters:
      if addedFirst: sqlStr &= " AND "
      addedFirst = true
      sqlStr &= buildTypeFilterSql(typeFilter, bindValues)
    
    for regexFilter in this.regexFilters:
      if addedFirst: sqlStr &= " AND "
      addedFirst = true
      sqlStr &= buildRegexFilterSql(regexFilter, bindValues)
      
  if this.sortField.len > 0:

    var sqlType = if this.sortIsNumber: "REAL" else: "TEXT"
    var sqlName = this.sortField & "_" & sqlType

    # Ensure an indexable column exists for this field
    db.createIndexableColumnForField(this.sortField, sqlName, sqlType)
    
    sqlStr &= " ORDER BY \"" & sqlName & "\" " & (if this.sortAscending: "asc" else: "desc")
    
  if this.pLimit >= 0:
    sqlStr &= " LIMIT " & $this.pLimit
  elif this.pOffset > 0:
    # SQLite requires LIMIT when using OFFSET
    sqlStr &= " LIMIT -1"

  if this.pOffset > 0:
    sqlStr &= " OFFSET " & $this.pOffset

  db.createIndex(this)

  # Done, prepare and bind the query
  return (sqlStr, bindValues)


## Helper: Apply projection to a document
proc applyProjection(doc: JsonNode, projection: JsonNode, includeMode: bool): JsonNode =
  if projection == nil or projection.kind != JObject:
    return doc

  if includeMode:
    # Include mode: only include specified fields
    var projected = newJObject()
    for field, val in projection:
      if val.getInt() == 1:
        # Handle nested fields with dot notation
        let parts = field.split('.')
        var currentDoc = doc
        var currentResult = projected
        var found = true

        for i, part in parts:
          if currentDoc.hasKey(part):
            if i == parts.len - 1:
              # Last part - copy the value
              currentResult[part] = currentDoc[part]
            else:
              # Navigate deeper
              currentDoc = currentDoc[part]
              if not currentResult.hasKey(part):
                currentResult[part] = newJObject()
              currentResult = currentResult[part]
          else:
            found = false
            break

        # If not found as nested, try as flat field
        if not found and doc.hasKey(field):
          projected[field] = doc[field]
    return projected
  else:
    # Exclude mode: copy all fields except excluded ones
    result = doc.copy()
    for field, val in projection:
      if val.getInt() == 0:
        # Handle nested fields - for now just delete top-level
        let parts = field.split('.')
        if parts.len == 1:
          if result.hasKey(field):
            result.delete(field)
        else:
          # For nested fields, we'd need more complex logic
          # For now, just delete the top-level key if it matches
          if result.hasKey(parts[0]):
            var shouldDelete = true
            var current = result[parts[0]]
            for i in 1 ..< parts.len:
              if current.kind == JObject and current.hasKey(parts[i]):
                current = current[parts[i]]
              else:
                shouldDelete = false
                break
            # Note: Full nested deletion is complex, skip for now
    return result


## Helper: Check if projection has nested fields (contains dots)
proc hasNestedFields(this: NJSDBQuery): bool =
  if this.projection == nil:
    return false
  for field, val in this.projection:
    if val.getInt() == 1 and field.contains('.'):
      return true
  return false


## Helper: Build SQL SELECT clause for projection
proc buildProjectionSql(this: NJSDBQuery, collection: string): string =
  ## Builds SQL SELECT clause using json_extract for include projections
  ## Returns "SELECT _json" if no projection, exclude mode, or nested fields
  ## Returns "SELECT json_object(...)" for flat include mode projections
  
  if this.projection == nil or not this.projectionInclude:
    # No projection or exclude mode - fetch full document
    return "SELECT _json FROM " & collection
  
  if this.hasNestedFields():
    return "SELECT _json FROM " & collection
  
  # Include mode with only flat fields - build json_object
  var extracts: seq[string] = @[]
  for field, val in this.projection:
    if val.getInt() == 1:
      # Build json_extract for this field
      let jsonPath = toJsonPath(field)
      extracts.add("'" & field & "', json_extract(_json, '" & jsonPath & "')")
  
  if extracts.len == 0:
    # No valid fields to include
    return "SELECT _json FROM " & collection
  
  return "SELECT json_object(" & extracts.join(", ") & ") FROM " & collection


## Execute the query and return all documents.
proc list*(this: NJSDBQuery): seq[JsonNode] =
  ## Returns all documents matching the query
  ## 
  ## Example:
  ##   let docs = db.query().where("status", "==", "active").list()
  
  let db = this.db
  
  let selectPrefix = this.buildProjectionSql(db.currentCollection)
  let (sqlStr, bindValues) = prepareQuerySql(this, selectPrefix)

  for row in db.conn.iterate(sqlStr, bindValues):
    var doc = parseJson(row[0].strVal)
    # - Exclude mode (always done in memory)
    # - Include mode with nested fields (fall back to in-memory)
    if this.projection != nil and (not this.projectionInclude or this.hasNestedFields()):
      doc = applyProjection(doc, this.projection, this.projectionInclude)
    result.add(doc)


## Execute the query and iterate through the resulting documents.
iterator list*(this: NJSDBQuery): JsonNode =

  let db = this.db

  let selectPrefix = this.buildProjectionSql(db.currentCollection)
  let (sqlStr, bindValues) = prepareQuerySql(this, selectPrefix)

  for row in db.conn.iterate(sqlStr, bindValues):

    var doc = parseJson(row[0].strVal)

    # - Exclude mode (always done in memory)
    # - Include mode with nested fields (fall back to in-memory)
    if this.projection != nil and (not this.projectionInclude or this.hasNestedFields()):
      doc = applyProjection(doc, this.projection, this.projectionInclude)

    # Yield the document
    yield doc


## Execute the query and return the query plan for analysis.
## Returns a sequence of JsonNode with query plan details.
proc explain*(this: NJSDBQuery): seq[JsonNode] =

  let db = this.db

  # Prepare the query SQL (but we don't need bind values for EXPLAIN)
  let selectPrefix = "SELECT _json FROM " & db.currentCollection
  let (sqlStr, bindValues) = prepareQuerySql(this, selectPrefix)

  let explainSql = "EXPLAIN QUERY PLAN " & sqlStr

  result = @[]
  for row in db.conn.iterate(explainSql, bindValues):
    # Each row contains: id, parent, notused, detail
    result.add(%*{
      "id": row[0].intVal.int,
      "parent": row[1].intVal.int,
      "notused": row[2].intVal.int,
      "detail": row[3].strVal
    })


## Execute the query and return the count of matching documents.
proc count*(this: NJSDBQuery): int {.discardable.} =

  let db = this.db

  # Prepare the query
  let countPrefix = "SELECT COUNT(*) FROM " & db.currentCollection
  let (sqlStr, bindValues) = prepareQuerySql(this, countPrefix)

  let countOpt = db.conn.value(sqlStr, bindValues)
  if countOpt.isSome:
    return countOpt.get.intVal.int
  else:
    return 0


## Execute the query and return distinct values for a field using SQL DISTINCT.
proc distinctValues*(this: NJSDBQuery, field: string): seq[string] {.gcsafe.} =

  let db = this.db

  # Note: We need to handle the query filters but select distinct values
  let (whereSql, bindValues) = prepareQuerySql(this, "")
  
  var sqlStr = "SELECT DISTINCT json_extract(_json, '$.' || ?) FROM " & db.currentCollection
  var allBindValues = @[toDbValue(field)]
  
  if whereSql.len > 0:
    sqlStr &= whereSql
    allBindValues.add(bindValues)

  result = @[]
  for row in db.conn.iterate(sqlStr, allBindValues):
    if row[0].kind == sqliteText and row[0].strVal.len > 0:
      result.add(row[0].strVal)


## Delete the documents matched by this query.
proc delete*(this: NJSDBQuery): int {.discardable.} =

  let db = this.db

  # Prepare the query
  let deletePrefix = "DELETE FROM " & db.currentCollection
  let (sqlStr, bindValues) = prepareQuerySql(this, deletePrefix)

  db.conn.exec(sqlStr, bindValues)
  let changesOpt = db.conn.value("SELECT changes()")
  if changesOpt.isSome:
    return changesOpt.get.intVal.int
  return 0


## Execute the query and return the first document found, or null if not found.
proc get*(this: NJSDBQuery): JsonNode =

  # Limit to one
  this.pLimit = 1

  let docs = this.list()
  if docs.len == 0:
    return nil
  else:
    return docs[0]


## Helper: Get a document with the specified ID, or return nil if not found
proc get*(this: NJSDB, id: string): JsonNode =
  var q = this.query()
  return q.where("id", "==", id).get()


## Delete a document with the specified ID. Returns true if a document was deleted.
proc delete*(this: NJSDB, id: string): bool =
  var q = this.query()
  return q.where("id", "==", id).limit(1).delete() > 0


## Update the documents matched by this query with the given fields. Returns the number of documents updated.
## Supports MongoDB-style operators:
##   $set: {"$set": {"field": value}} - Set field to value
##   $inc: {"$inc": {"field": value}} - Increment field by value (default 0 if not exists)
##   $mul: {"$mul": {"field": value}} - Multiply field by value (default 0 if not exists)
proc update*(this: NJSDBQuery, updates: JsonNode): int {.discardable.} =

  # Check input
  if updates == nil:
    raise newException(ValidationError, "Cannot update with null document")
  if updates.kind != JObject:
    raise newException(ValidationError, "Updates must be an object")
  if updates.len == 0: return 0

  let db = this.db

  # Collect all json_set operations and their bind parameters
  var jsonSetPaths: seq[string] = @[]
  var jsonSetValues: seq[string] = @[]
  
  if "$set" in updates:
    let fieldsToUpdate = updates["$set"]
    if fieldsToUpdate.kind != JObject:
      raise newException(ValidationError, "$set value must be an object")
    
    for key, value in fieldsToUpdate.pairs:
      # Skip id field updates
      if key == "id": continue
      
      # Collect path and value as bind parameters
      jsonSetPaths.add("$." & key)
      jsonSetValues.add($value)
  
  if "$inc" in updates:
    let fieldsToInc = updates["$inc"]
    if fieldsToInc.kind != JObject:
      raise newException(ValidationError, "$inc value must be an object")
    
    for key, value in fieldsToInc.pairs:
      # Skip id field updates
      if key == "id": continue
      
      # For $inc, we need to use json_extract in the expression
      # We'll handle this separately after building the base json_set
      let jsonPath = "$." & key
      let incValue = if value.kind == JString: value.getStr() else: $value
      # Store as special marker for increment operation
      jsonSetPaths.add(jsonPath & "||INC||" & incValue)
      jsonSetValues.add("")  # Placeholder
  
  if "$mul" in updates:
    let fieldsToMul = updates["$mul"]
    if fieldsToMul.kind != JObject:
      raise newException(ValidationError, "$mul value must be an object")
    
    for key, value in fieldsToMul.pairs:
      # Skip id field updates
      if key == "id": continue
      
      let jsonPath = "$." & key
      let mulValue = if value.kind == JString: value.getStr() else: $value
      # Store as special marker for multiply operation
      jsonSetPaths.add(jsonPath & "||MUL||" & mulValue)
      jsonSetValues.add("")  # Placeholder
  
  var unsetPaths: seq[string] = @[]
  if "$unset" in updates:
    let fieldsToUnset = updates["$unset"]
    if fieldsToUnset.kind != JObject:
      raise newException(ValidationError, "$unset value must be an object")
    
    for key, value in fieldsToUnset.pairs:
      # Skip id field updates
      if key == "id": continue
      
      unsetPaths.add("$." & key)
  
  var renameOps: seq[tuple[oldPath, newPath: string]] = @[]
  if "$rename" in updates:
    let fieldsToRename = updates["$rename"]
    if fieldsToRename.kind != JObject:
      raise newException(ValidationError, "$rename value must be an object")
    
    for oldKey, newKeyNode in fieldsToRename.pairs:
      # Skip id field updates
      if oldKey == "id": continue
      if newKeyNode.kind != JString:
        raise newException(ValidationError, "$rename values must be strings")
      let newKey = newKeyNode.getStr()
      if newKey == "id":
        raise newException(ValidationError, "Cannot rename to 'id' field")
      
      renameOps.add(("$." & oldKey, "$." & newKey))

  # Start with _json and apply json_set for each path
  var sqlExpr = "_json"
  var bindValues: seq[DbValue] = @[]
  
  for i in 0..<jsonSetPaths.len:
    let path = jsonSetPaths[i]
    
    # Check if this is a special operation (INC or MUL)
    if "||INC||" in path:
      let parts = path.split("||INC||")
      let jsonPath = parts[0]
      let incValue = parts[1]
      # Use json_extract with COALESCE for increment
      sqlExpr = "json_set(" & sqlExpr & ", ?, COALESCE(json_extract(_json, ?), 0) + " & incValue & ")"
      bindValues.add(toDbValue(jsonPath))
      bindValues.add(toDbValue(jsonPath))
    elif "||MUL||" in path:
      let parts = path.split("||MUL||")
      let jsonPath = parts[0]
      let mulValue = parts[1]
      # Use json_extract with COALESCE for multiply
      sqlExpr = "json_set(" & sqlExpr & ", ?, COALESCE(json_extract(_json, ?), 0) * " & mulValue & ")"
      bindValues.add(toDbValue(jsonPath))
      bindValues.add(toDbValue(jsonPath))
    else:
      # Regular $set operation - use parameter for value
      sqlExpr = "json_set(" & sqlExpr & ", ?, json(?))"
      bindValues.add(toDbValue(path))
      bindValues.add(toDbValue(jsonSetValues[i]))
  
  for unsetPath in unsetPaths:
    sqlExpr = "json_remove(" & sqlExpr & ", ?)"
    bindValues.add(toDbValue(unsetPath))
  
  for renameOp in renameOps:
    # First copy: json_set(..., '$.new', json_extract(_json, '$.old'))
    sqlExpr = "json_set(" & sqlExpr & ", ?, json_extract(_json, ?))"
    bindValues.add(toDbValue(renameOp.newPath))
    bindValues.add(toDbValue(renameOp.oldPath))
    # Then remove: json_remove(..., '$.old')
    sqlExpr = "json_remove(" & sqlExpr & ", ?)"
    bindValues.add(toDbValue(renameOp.oldPath))

  var sqlStr = "UPDATE " & db.currentCollection & " SET _json = " & sqlExpr
  
  if this.filters.len > 0:
    sqlStr &= " WHERE "
    var addedFirst = false
    for filter in this.filters:
      if addedFirst: sqlStr &= " AND "
      addedFirst = true
      
      sqlStr &= "json_extract(_json, '$.' || ?) " & filter.operation & " ?"
      bindValues.add(toDbValue(filter.field))
      bindValues.add(toDbValue(filter.value))
  
  db.conn.exec(sqlStr, bindValues)
  let changesOpt = db.conn.value("SELECT changes()")
  if changesOpt.isSome:
    return changesOpt.get.intVal.int
  return 0


## Helper: Update a document with the specified ID. Returns true if a document was updated.
proc updateOne*(this: NJSDB, id: string, updates: JsonNode): bool =
  var q = this.query()
  return q.where("id", "==", id).limit(1).update(updates) > 0

## Aggregation result type
type AggregateResult* = object
  groupId*: string
  count*: int
  sum*: float
  avg*: float
  min*: float
  max*: float


## Extended aggregation with multiple operators
## Supports: $sum, $avg, $min, $max, $count
## Example: aggregate("category", "amount", %*{ "$sum": "amount", "$avg": "amount" })
proc aggregate*(this: NJSDB, groupField: string, aggregations: JsonNode, matchFilter: JsonNode = nil): seq[AggregateResult] {.gcsafe.} =
  ## Performs aggregation with multiple operators
  ## groupField: Field to group by
  ## aggregations: Json object with aggregation operators
  ##   Example: %*{ "$sum": "amount", "$avg": "price", "$min": "stock" }
  ## matchFilter: Optional filter to apply before aggregation
  
  # Prepare database
  this.prepareDB()
  
  var query = this.query()
  
  if matchFilter != nil and matchFilter.len > 0:
    query = query.filter(matchFilter)
  
  let (whereSql, bindValues) = prepareQuerySql(query, "")
  
  var selectFields = @[
    "json_extract(_json, '$.' || ?) as _id",  # Group by field
    "COUNT(*) as count"
  ]
  var allBindValues: seq[DbValue] = @[toDbValue(groupField)]
  
  var hasSum = false
  var hasAvg = false
  var hasMin = false
  var hasMax = false
  var sumField = ""
  var avgField = ""
  var minField = ""
  var maxField = ""
  
  if aggregations != nil and aggregations.kind == JObject:
    if "$sum" in aggregations:
      hasSum = true
      sumField = aggregations["$sum"].getStr()
      selectFields.add("SUM(CAST(json_extract(_json, '$.' || ?) AS REAL)) as sum_val")
      allBindValues.add(toDbValue(sumField))
    
    if "$avg" in aggregations:
      hasAvg = true
      avgField = aggregations["$avg"].getStr()
      selectFields.add("AVG(CAST(json_extract(_json, '$.' || ?) AS REAL)) as avg_val")
      allBindValues.add(toDbValue(avgField))
    
    if "$min" in aggregations:
      hasMin = true
      minField = aggregations["$min"].getStr()
      selectFields.add("MIN(CAST(json_extract(_json, '$.' || ?) AS REAL)) as min_val")
      allBindValues.add(toDbValue(minField))
    
    if "$max" in aggregations:
      hasMax = true
      maxField = aggregations["$max"].getStr()
      selectFields.add("MAX(CAST(json_extract(_json, '$.' || ?) AS REAL)) as max_val")
      allBindValues.add(toDbValue(maxField))
  
  var sqlStr = "SELECT " & selectFields.join(", ") & " FROM " & this.currentCollection
  
  if whereSql.len > 0:
    sqlStr &= whereSql
    allBindValues.add(bindValues)
  
  sqlStr &= " GROUP BY json_extract(_json, '$.' || ?)"
  allBindValues.add(toDbValue(groupField))
  
  result = @[]
  var colIndex = 0
  for row in this.conn.iterate(sqlStr, allBindValues):
    colIndex = 0
    var res = AggregateResult()
    res.groupId = row[colIndex].strVal; colIndex += 1
    res.count = row[colIndex].intVal.int; colIndex += 1
    
    if hasSum:
      if row[colIndex].kind == sqliteReal or row[colIndex].kind == sqliteInteger:
        res.sum = row[colIndex].floatVal
      colIndex += 1
    
    if hasAvg:
      if row[colIndex].kind == sqliteReal or row[colIndex].kind == sqliteInteger:
        res.avg = row[colIndex].floatVal
      colIndex += 1
    
    if hasMin:
      if row[colIndex].kind == sqliteReal or row[colIndex].kind == sqliteInteger:
        res.min = row[colIndex].floatVal
      colIndex += 1
    
    if hasMax:
      if row[colIndex].kind == sqliteReal or row[colIndex].kind == sqliteInteger:
        res.max = row[colIndex].floatVal
      colIndex += 1
    
    result.add(res)


## Put a new document into the database, or replace it if it already exists
proc writeDocument(this: NJSDB, document: JsonNode) =

  # Check input
  if document == nil:
    raise newException(DocumentError, "Cannot put a null document into the database")
  if document.kind != JObject:
    raise newException(DocumentError, "Document must be an object")

  var docCopy = document.copy()

  # Generate ID if not provided
  if docCopy{"id"}.isNil:
    docCopy["id"] = % $genOid()
  if docCopy{"id"}.kind != JString:
    raise newException(DocumentError, "Document ID must be a string")

  # Prepare database
  this.prepareDB()

  let str = "INSERT OR REPLACE INTO " & this.currentCollection & " (_json, " & this.extraColumns.join(", ") & ") VALUES (?, " & this.extraColumns.mapIt("?").join(", ") & ")"

  # First field is the JSON content
  var args: seq[DbValue] = @[ toDbValue($docCopy) ]

  for columnName in this.extraColumns:

    let fieldName = if columnName == "id": "id" else: columnName.substr(0, columnName.len - 6)

    args.add toDbValue(docCopy{fieldName}.getStr())

  # Bind and execute the query
  this.conn.exec(str, args)


## Put a new document into the database, merging the fields if it already exists
proc put*(this: NJSDB, document: JsonNode, merge: bool = false) =

  if not merge:
    this.writeDocument(document)
    return

  # Check input
  if document == nil:
    raise newException(DocumentError, "Cannot put a null document into the database")
  if document.kind != JObject:
    raise newException(DocumentError, "Document must be an object")
  if document{"id"}.isNil: 
    this.writeDocument(document)
    return
  if document{"id"}.kind != JString:
    raise newException(DocumentError, "Document ID must be a string")

  let id = document["id"].getStr()
  var existingDoc = this.get(id)
  if existingDoc == nil:
    this.writeDocument(document)
    return
    
  # Merge new fields
  for key, value in document.pairs:
    existingDoc[key] = value

  # Write it
  this.writeDocument(existingDoc)


## Upsert a document: Update if it exists, insert if it doesn't.
## Returns the number of documents affected (always 1).
proc upsert*(this: NJSDB, document: JsonNode): int {.discardable.} =

  # Check input
  if document == nil:
    raise newException(DocumentError, "Cannot upsert a null document into the database")
  if document.kind != JObject:
    raise newException(DocumentError, "Document must be an object")

  var docCopy = document.copy()

  # Generate ID if not provided
  if docCopy{"id"}.isNil:
    docCopy["id"] = % $genOid()
  if docCopy{"id"}.kind != JString:
    raise newException(DocumentError, "Document ID must be a string")

  let id = docCopy["id"].getStr()

  # Check if document exists
  let existingDoc = this.get(id)
  if existingDoc == nil:
    # Document doesn't exist, insert it
    this.writeDocument(docCopy)
  else:
    # Document exists, update it (full replace)
    this.writeDocument(docCopy)
  return 1


## Upsert with merge: Update by merging fields if it exists, insert if it doesn't.
## Returns the number of documents affected (always 1).
proc upsert*(this: NJSDB, document: JsonNode, merge: bool): int {.discardable.} =

  if not merge:
    return this.upsert(document)

  # Check input
  if document == nil:
    raise newException(DocumentError, "Cannot upsert a null document into the database")
  if document.kind != JObject:
    raise newException(DocumentError, "Document must be an object")

  var docCopy = document.copy()

  # Generate ID if not provided
  if docCopy{"id"}.isNil:
    docCopy["id"] = % $genOid()
  if docCopy{"id"}.kind != JString:
    raise newException(DocumentError, "Document ID must be a string")

  let id = docCopy["id"].getStr()

  # Check if document exists
  var existingDoc = this.get(id)
  if existingDoc == nil:
    # Document doesn't exist, insert it
    this.writeDocument(docCopy)
  else:
    # Document exists, merge new fields into existing document
    for key, value in docCopy.pairs:
      existingDoc[key] = value
    this.writeDocument(existingDoc)
  return 1

## Insert multiple documents efficiently
## Returns the number of documents inserted
proc insertMany*(this: NJSDB, documents: seq[JsonNode]): int {.discardable.} =
  ## Efficiently inserts multiple documents in a single transaction
  ## Much faster than individual put() calls for large datasets
  
  if documents.len == 0:
    return 0
  
  var count = 0
  this.withTransaction do():
    for doc in documents:
      this.put(doc)
      count += 1
  return count


## Aggregation pipeline stage types
type AggregateStage* = enum
  asMatch    ## $match - Filter documents
  asGroup    ## $group - Group by field and aggregate
  asSort     ## $sort - Sort results
  asLimit    ## $limit - Limit number of results
  asSkip     ## $skip - Skip number of results
  asProject  ## $project - Select fields

## Aggregation pipeline result
type AggregatePipelineResult* = object
  data*: seq[JsonNode]  ## Result documents
  count*: int           ## Total count (before limit)

## MongoDB-style aggregation pipeline
## Supports: $match, $group, $sort, $limit, $skip, $project
## Example:
##   db.collection("orders").aggregate(@[
##     %*{ "$match": { "status": "completed" } },
##     %*{ "$group": { "_id": "$customerId", "total": { "$sum": "$amount" } } },
##     %*{ "$sort": { "total": -1 } },
##     %*{ "$limit": 10 }
##   ])
proc aggregate*(this: NJSDB, pipeline: seq[JsonNode]): AggregatePipelineResult {.gcsafe.} =
  ## Executes an aggregation pipeline
  ## Returns aggregated results as JsonNode sequence
  
  # Prepare database
  this.prepareDB()
  
  var matchFilter: JsonNode = nil
  var groupField = ""
  var groupAggregations: JsonNode = nil
  var sortField = ""
  var sortAscending = true
  var limitVal = -1
  var skipVal = 0
  var projectFields: seq[string] = @[]
  var countField = ""  # For $count stage
  
  for stage in pipeline:
    if stage.kind != JObject or stage.len == 0:
      continue
    
    var stageName = ""
    var stageValue: JsonNode = nil
    for key, val in stage.pairs:
      stageName = key
      stageValue = val
      break
    
    case stageName:
    of "$match":
      matchFilter = stageValue
    of "$group":
      if stageValue.kind == JObject:
        if "_id" in stageValue:
          let idVal = stageValue["_id"]
          if idVal.kind == JString:
            # Handle "$field" format
            var idStr = idVal.getStr()
            if idStr.startsWith("$"):
              idStr = idStr.substr(1)
            groupField = idStr
        # Get aggregation operators (everything except _id)
        groupAggregations = newJObject()
        for key, val in stageValue.pairs:
          if key != "_id":
            groupAggregations[key] = val
    of "$sort":
      if stageValue.kind == JObject and stageValue.len > 0:
        for key, val in stageValue.pairs:
          sortField = key
          let sortOrder = val
          if sortOrder.kind == JInt:
            sortAscending = sortOrder.getInt() > 0
          elif sortOrder.kind == JFloat:
            sortAscending = sortOrder.getFloat() > 0
          break
    of "$limit":
      if stageValue.kind == JInt:
        limitVal = stageValue.getInt()
    of "$skip":
      if stageValue.kind == JInt:
        skipVal = stageValue.getInt()
    of "$project":
      if stageValue.kind == JObject:
        for field, val in stageValue.pairs:
          if val.kind == JInt and val.getInt() == 1:
            projectFields.add(field)
    of "$count":
      # $count stage - returns a single document with the count
      if stageValue.kind == JString:
        countField = stageValue.getStr()
      else:
        countField = "count"  # default field name
  
  var query = this.query()
  
  if matchFilter != nil and matchFilter.len > 0:
    query = query.filter(matchFilter)
  
  let (whereSql, bindValues) = prepareQuerySql(query, "")
  
  var sqlStr = ""
  var allBindValues: seq[DbValue] = @[]
  
  if groupField.len > 0:
    # Aggregation query with GROUP BY
    var selectFields = @[
      "json_extract(_json, '$.' || ?) as _id",
      "COUNT(*) as count"
    ]
    allBindValues.add(toDbValue(groupField))
    
    var hasSum = false
    var hasAvg = false
    var hasMin = false
    var hasMax = false
    var sumField = ""
    var avgField = ""
    var minField = ""
    var maxField = ""
    var sumAlias = ""
    var avgAlias = ""
    var minAlias = ""
    var maxAlias = ""
    
    if groupAggregations != nil and groupAggregations.kind == JObject:
      for alias, aggDef in groupAggregations.pairs:
        if aggDef.kind == JObject:
          if "$sum" in aggDef:
            hasSum = true
            sumAlias = alias
            let sumVal = aggDef["$sum"]
            if sumVal.kind == JString:
              sumField = sumVal.getStr()
              if sumField.startsWith("$"):
                sumField = sumField.substr(1)
              selectFields.add("SUM(CAST(json_extract(_json, '$.' || ?) AS REAL)) as " & alias)
              allBindValues.add(toDbValue(sumField))
            elif sumVal.kind == JInt and sumVal.getInt() == 1:
              # $sum: 1 means count - use COUNT(*) instead
              selectFields.add("COUNT(*) as " & alias)
            else:
              # Other numeric sum
              selectFields.add("SUM(CAST(json_extract(_json, '$.' || ?) AS REAL)) as " & alias)
              allBindValues.add(toDbValue(sumField))
          if "$avg" in aggDef:
            hasAvg = true
            avgAlias = alias
            let avgVal = aggDef["$avg"]
            if avgVal.kind == JString:
              avgField = avgVal.getStr()
              if avgField.startsWith("$"):
                avgField = avgField.substr(1)
            selectFields.add("AVG(CAST(json_extract(_json, '$.' || ?) AS REAL)) as " & alias)
            allBindValues.add(toDbValue(avgField))
          if "$min" in aggDef:
            hasMin = true
            minAlias = alias
            let minVal = aggDef["$min"]
            if minVal.kind == JString:
              minField = minVal.getStr()
              if minField.startsWith("$"):
                minField = minField.substr(1)
            selectFields.add("MIN(CAST(json_extract(_json, '$.' || ?) AS REAL)) as " & alias)
            allBindValues.add(toDbValue(minField))
          if "$max" in aggDef:
            hasMax = true
            maxAlias = alias
            let maxVal = aggDef["$max"]
            if maxVal.kind == JString:
              maxField = maxVal.getStr()
              if maxField.startsWith("$"):
                maxField = maxField.substr(1)
            selectFields.add("MAX(CAST(json_extract(_json, '$.' || ?) AS REAL)) as " & alias)
            allBindValues.add(toDbValue(maxField))
    
    sqlStr = "SELECT " & selectFields.join(", ") & " FROM " & this.currentCollection
    
    if whereSql.len > 0:
      sqlStr &= whereSql
      allBindValues.add(bindValues)
    
    sqlStr &= " GROUP BY json_extract(_json, '$.' || ?)"
    allBindValues.add(toDbValue(groupField))
    
    if sortField.len > 0:
      let sortDir = if sortAscending: "ASC" else: "DESC"
      sqlStr &= " ORDER BY " & sortField & " " & sortDir
    
    if limitVal > 0:
      sqlStr &= " LIMIT " & $limitVal
    if skipVal > 0:
      sqlStr &= " OFFSET " & $skipVal
    
    # Execute aggregation query
    result.data = @[]
    for row in this.conn.iterate(sqlStr, allBindValues):
      var doc = newJObject()
      doc["_id"] = %row[0].strVal
      doc["count"] = %row[1].intVal.int
      
      var colIdx = 2
      if hasSum:
        if row[colIdx].kind == sqliteReal or row[colIdx].kind == sqliteInteger:
          # Check if this was a $sum: 1 (count) or actual sum
          if sumField.len > 0:
            doc[sumAlias] = %row[colIdx].floatVal
          else:
            doc[sumAlias] = %row[colIdx].intVal.int
        colIdx += 1
      if hasAvg:
        if row[colIdx].kind == sqliteReal or row[colIdx].kind == sqliteInteger:
          doc[avgAlias] = %row[colIdx].floatVal
        colIdx += 1
      if hasMin:
        if row[colIdx].kind == sqliteReal or row[colIdx].kind == sqliteInteger:
          doc[minAlias] = %row[colIdx].floatVal
        colIdx += 1
      if hasMax:
        if row[colIdx].kind == sqliteReal or row[colIdx].kind == sqliteInteger:
          doc[maxAlias] = %row[colIdx].floatVal
        colIdx += 1
      
      result.data.add(doc)
  
  else:
    # No grouping - just filter, sort, limit
    sqlStr = "SELECT _json FROM " & this.currentCollection
    
    if whereSql.len > 0:
      sqlStr &= whereSql
      allBindValues = bindValues
    
    if sortField.len > 0:
      let sortDir = if sortAscending: "ASC" else: "DESC"
      sqlStr &= " ORDER BY json_extract(_json, '$.' || ?) " & sortDir
      allBindValues.add(toDbValue(sortField))
    
    if limitVal > 0:
      sqlStr &= " LIMIT " & $limitVal
    if skipVal > 0:
      sqlStr &= " OFFSET " & $skipVal
    
    # Execute query
    result.data = @[]
    for row in this.conn.iterate(sqlStr, allBindValues):
      var doc = row[0].strVal.parseJson()
      result.data.add(doc)
  
  # Handle $count stage - return a single document with the count
  if countField.len > 0:
    let countValue = result.data.len
    result.data = @[%*{(countField): countValue}]
  
  result.count = result.data.len
