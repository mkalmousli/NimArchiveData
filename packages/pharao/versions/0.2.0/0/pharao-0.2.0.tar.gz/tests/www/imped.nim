import imp

foo()

