# Package

version       = "1.0.1"
author        = "Tobias Dély"
description   = "git profile manager"
license       = "MIT"
srcDir        = "src"
bin           = @["dira"]


# Dependencies

requires "nim >= 2.0.2"
requires "cligen >= 1.7"
