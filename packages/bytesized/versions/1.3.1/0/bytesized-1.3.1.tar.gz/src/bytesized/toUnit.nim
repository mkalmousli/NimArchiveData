import ./[util, convertBytes]

# Aliases for convertBytes to make it simpler to use

proc toKiB*(input:int): float = return convertBytes(input, Units.KiB)
proc toKiB*(input:int, roundDigits:int): float = return convertBytes(input, Units.KiB, roundDigits)
proc toKiB*(input:float, inUnit:Units): float = return convertBytes(input, inUnit, Units.KiB)
proc toKiB*(input:float, inUnit:Units, roundDigits:int): float = return convertBytes(input, inUnit, Units.KiB, roundDigits)

proc toMiB*(input:int): float = return convertBytes(input, Units.MiB)
proc toMiB*(input:int, roundDigits:int): float = return convertBytes(input, Units.MiB, roundDigits)
proc toMiB*(input:float, inUnit:Units): float = return convertBytes(input, inUnit, Units.MiB)
proc toMiB*(input:float, inUnit:Units, roundDigits:int): float = return convertBytes(input, inUnit, Units.MiB, roundDigits)

proc toGiB*(input:int): float = return convertBytes(input, Units.GiB)
proc toGiB*(input:int, roundDigits:int): float = return convertBytes(input, Units.GiB, roundDigits)
proc toGiB*(input:float, inUnit:Units): float = return convertBytes(input, inUnit, Units.GiB)
proc toGiB*(input:float, inUnit:Units, roundDigits:int): float = return convertBytes(input, inUnit, Units.GiB, roundDigits)

proc toTiB*(input:int): float = return convertBytes(input, Units.TiB)
proc toTiB*(input:int, roundDigits:int): float = return convertBytes(input, Units.TiB, roundDigits)
proc toTiB*(input:float, inUnit:Units): float = return convertBytes(input, inUnit, Units.TiB)
proc toTiB*(input:float, inUnit:Units, roundDigits:int): float = return convertBytes(input, inUnit, Units.TiB, roundDigits)

proc toPiB*(input:int): float = return convertBytes(input, Units.PiB)
proc toPiB*(input:int, roundDigits:int): float = return convertBytes(input, Units.PiB, roundDigits)
proc toPiB*(input:float, inUnit:Units): float = return convertBytes(input, inUnit, Units.PiB)
proc toPiB*(input:float, inUnit:Units, roundDigits:int): float = return convertBytes(input, inUnit, Units.PiB, roundDigits)

proc toKB*(input:int): float = return convertBytes(input, Units.KB)
proc toKB*(input:int, roundDigits:int): float = return convertBytes(input, Units.KB, roundDigits)
proc toKB*(input:float, inUnit:Units): float = return convertBytes(input, inUnit, Units.KB)
proc toKB*(input:float, inUnit:Units, roundDigits:int): float = return convertBytes(input, inUnit, Units.KB, roundDigits)

proc toMB*(input:int): float = return convertBytes(input, Units.MB)
proc toMB*(input:int, roundDigits:int): float = return convertBytes(input, Units.MB, roundDigits)
proc toMB*(input:float, inUnit:Units): float = return convertBytes(input, inUnit, Units.MB)
proc toMB*(input:float, inUnit:Units, roundDigits:int): float = return convertBytes(input, inUnit, Units.MB, roundDigits)

proc toGB*(input:int): float = return convertBytes(input, Units.GB)
proc toGB*(input:int, roundDigits:int): float = return convertBytes(input, Units.GB, roundDigits)
proc toGB*(input:float, inUnit:Units): float = return convertBytes(input, inUnit, Units.GB)
proc toGB*(input:float, inUnit:Units, roundDigits:int): float = return convertBytes(input, inUnit, Units.GB, roundDigits)

proc toTB*(input:int): float = return convertBytes(input, Units.TB)
proc toTB*(input:int, roundDigits:int): float = return convertBytes(input, Units.TB, roundDigits)
proc toTB*(input:float, inUnit:Units): float = return convertBytes(input, inUnit, Units.TB)
proc toTB*(input:float, inUnit:Units, roundDigits:int): float = return convertBytes(input, inUnit, Units.TB, roundDigits)

proc toPB*(input:int): float = return convertBytes(input, Units.PB)
proc toPB*(input:int, roundDigits:int): float = return convertBytes(input, Units.PB, roundDigits)
proc toPB*(input:float, inUnit:Units): float = return convertBytes(input, inUnit, Units.PB)
proc toPB*(input:float, inUnit:Units, roundDigits:int): float = return convertBytes(input, inUnit, Units.PB, roundDigits)