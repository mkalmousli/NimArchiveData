# Package

version       = "1.3.1"
author        = "lx12ucy"
description   = "a library for manipulating data storage units"
license       = "GPL-3.0-only"
srcDir        = "src"


# Dependencies

requires "nim >= 2.0.8"