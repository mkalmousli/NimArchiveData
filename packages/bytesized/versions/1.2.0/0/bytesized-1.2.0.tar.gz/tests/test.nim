import unittest
import bytesized

echo "toBytes tests:"

test "GiB to Bytes":
  check toBytes(32, Units.GiB) == 34359738368

test "GiB to Bytes (float)":
  check toBytesFloat(32, Units.GiB) == 34359738368.0

test "GB to Bytes":
  check toBytes(32, Units.GB) == 32000000000

echo "convertBytes tests:"

test "Bytes to GiB":
  check convertBytes(17179869184, Units.GiB) == 16.0

test "Bytes to GiB (5 decimal places rounding)":
  check convertBytes(16000000000, Units.GiB, 5) == 14.90116

test "Bytes to GB":
  check convertBytes(16000000000, Units.GB) == 16.0

test "GB to GiB":
  check convertBytes(16, Units.GB, Units.GiB) == 14.9

test "MB to TiB":
  check convertBytes(8000000000f, Units.MB, Units.TiB) == 7276.0

echo "toUnit tests:"

test "toMiB":
  check 2621440.toMiB() == 2.5

test "toMiB (3 decimal places rounding)":
  check 1293943.toMiB(3) == 1.234

test "toGB":
  check 8000000000.toGB() == 8.0