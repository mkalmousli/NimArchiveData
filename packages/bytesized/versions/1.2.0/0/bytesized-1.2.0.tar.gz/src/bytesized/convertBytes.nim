import std/math
import ./[util, toBytes]

proc convertBytes*(input:float, inUnit:Units, outUnit:Units, roundDigits:int): float =
  util.unitAmountOut = -1

  let bytes:int = toBytes(input, inUnit)

  case outUnit:
    of KiB:
      return math.round(bytes / 1024, roundDigits)
    of KB:
      return math.round(bytes / 1000, roundDigits)
    of MiB:
      return divide(bytes, true, 2, roundDigits)
    of MB:
      return divide(bytes, false, 2, roundDigits)
    of GiB:
      return divide(bytes, true, 3, roundDigits)
    of GB:
      return divide(bytes, false, 3, roundDigits)
    of TiB:
      return divide(bytes, true, 4, roundDigits)
    of TB:
      return divide(bytes, false, 4, roundDigits)
    of PiB:
      return divide(bytes, true, 5, roundDigits)
    of PB:
      return divide(bytes, false, 5, roundDigits)
    else:
      return toFloat(bytes) # if already bytes, no conversion is necessary

proc convertBytes*(input:int, outUnit:Units, roundDigits:int): float =
  convertBytes(toFloat(input), Units.Bytes, outUnit, roundDigits)

proc convertBytes*(input:int, outUnit:Units): float =
  convertBytes(toFloat(input), Units.Bytes, outUnit, 1)

proc convertBytes*(input:float, inUnit:Units, outUnit:Units): float =
  convertBytes(input, inUnit, outUnit, 1)

proc convertBytes*(input:float, outUnit:Units): float =
  convertBytes(input, Units.Bytes, outUnit, 1)

proc convertBytes*(input:float, outUnit:Units, roundDigits:int): float =
    convertBytes(input, Units.Bytes, outUnit, roundDigits)