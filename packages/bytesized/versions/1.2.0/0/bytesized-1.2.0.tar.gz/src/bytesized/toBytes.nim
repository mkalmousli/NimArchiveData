import ./util

proc toBytes*(input:float, inUnit:Units): int =
  util.unitAmountIn = -1

  case inUnit:
    of KiB:
      return toInt(input * 1024)
    of KB:
      return toInt(input * 1000)
    of MiB:
      return multiply(input, true, 2)
    of MB:
      return multiply(input, false, 2)
    of GiB:
      return multiply(input, true, 3)
    of GB:
      return multiply(input, false, 3)
    of TiB:
      return multiply(input, true, 4)
    of TB:
      return multiply(input, false, 4)
    of PiB:
      return multiply(input, true, 5)
    of PB:
      return multiply(input, false, 5)
    else:
      return toInt(input) # if already bytes, no conversion is necessary

proc toBytesFloat*(input:float, inUnit:Units): float =
  return toFloat(toBytes(input, inUnit))