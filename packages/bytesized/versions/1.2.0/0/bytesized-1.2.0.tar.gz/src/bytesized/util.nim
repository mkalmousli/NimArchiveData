import std/math

type Units* = enum
  Bytes, KiB, KB, MiB, MB, GiB, GB, TiB, TB, PiB, PB

var
  unitAmountIn*: int = -1  # Initialize to -1 for the first check
  unitAmountOut*: int = -1  # Initialize to -1 for the first check

proc getUnitAmountIn(gibibytes: bool): int =
  if unitAmountIn == -1:
    if gibibytes:
      unitAmountIn = 1024
    else:
      unitAmountIn = 1000
  return unitAmountIn

proc getUnitAmountOut(gibibytes: bool): int =
  if unitAmountOut == -1:
    if gibibytes:
      unitAmountOut = 1024
    else:
      unitAmountOut = 1000
  return unitAmountOut

proc multiply*(input: float, gibibytes: bool, exponent: int): int =
  return toInt(input * toFloat(getUnitAmountIn(gibibytes) ^ exponent))

proc divide*(input: int, gibibytes: bool, exponent: int, roundDigits: int): float =
  return math.round(toFloat(input) / toFloat(getUnitAmountOut(gibibytes) ^ exponent), roundDigits)