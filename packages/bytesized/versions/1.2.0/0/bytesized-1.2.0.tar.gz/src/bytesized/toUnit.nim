import ./[util, convertBytes]

# Aliases for convertBytes to make it simpler to use

proc toKiB*(input:int): float = return convertBytes(input, Units.KiB)
proc toKiB*(input:int, roundDigits:int): float = return convertBytes(input, Units.KiB, roundDigits)

proc toMiB*(input:int): float = return convertBytes(input, Units.MiB)
proc toMiB*(input:int, roundDigits:int): float = return convertBytes(input, Units.MiB, roundDigits)

proc toGiB*(input:int): float = return convertBytes(input, Units.GiB)
proc toGiB*(input:int, roundDigits:int): float = return convertBytes(input, Units.GiB, roundDigits)

proc toTiB*(input:int): float = return convertBytes(input, Units.TiB)
proc toTiB*(input:int, roundDigits:int): float = return convertBytes(input, Units.TiB, roundDigits)

proc toPiB*(input:int): float = return convertBytes(input, Units.PiB)
proc toPiB*(input:int, roundDigits:int): float = return convertBytes(input, Units.PiB, roundDigits)

proc toKB*(input:int): float = return convertBytes(input, Units.KB)
proc toKB*(input:int, roundDigits:int): float = return convertBytes(input, Units.KB, roundDigits)

proc toMB*(input:int): float = return convertBytes(input, Units.MB)
proc toMB*(input:int, roundDigits:int): float = return convertBytes(input, Units.MB, roundDigits)

proc toGB*(input:int): float = return convertBytes(input, Units.GB)
proc toGB*(input:int, roundDigits:int): float = return convertBytes(input, Units.GB, roundDigits)

proc toTB*(input:int): float = return convertBytes(input, Units.TB)
proc toTB*(input:int, roundDigits:int): float = return convertBytes(input, Units.TB, roundDigits)

proc toPB*(input:int): float = return convertBytes(input, Units.PB)
proc toPB*(input:int, roundDigits:int): float = return convertBytes(input, Units.PB, roundDigits)