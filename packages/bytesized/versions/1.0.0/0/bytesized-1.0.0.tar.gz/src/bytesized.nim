import std/math

type Units* = enum
  Bytes, KiB, KB, MiB, MB, GiB, GB, TiB, TB, PiB, PB

var # better for performance to set a variable once instead of checking each time
  unitAmountIn:int
  unitAmountOut:int

proc getUnitAmountIn(gibibytes:bool): int =
  if unitAmountIn == -1: 
    if gibibytes: unitAmountIn = 1024
    else: unitAmountIn = 1000
  return unitAmountIn

proc getUnitAmountOut(gibibytes:bool): int =
  if unitAmountOut == -1:
    if gibibytes: unitAmountOut = 1024
    else: unitAmountOut = 1000
  return unitAmountOut

proc multiply(input:float, gibibytes:bool, exponent:int): int =
  return toInt(input * toFloat(getUnitAmountIn(gibibytes) ^ exponent))

proc divide(input:int, gibibytes:bool, exponent:int, roundDigits:int): float =
  return math.round(toFloat(input) / toFloat(getUnitAmountOut(gibibytes) ^ exponent), roundDigits)

proc toBytes*(input:float, inUnit:Units): int =
  unitAmountIn = -1

  case inUnit:
    of KiB: 
      return toInt(input * 1024)
    of KB: 
      return toInt(input * 1000)
    of MiB:
      return multiply(input, true, 2)
    of MB:
      return multiply(input, false, 2)
    of GiB:
      return multiply(input, true, 3)
    of GB:
      return multiply(input, false, 3)
    of TiB:
      return multiply(input, true, 4)
    of TB:
      return multiply(input, false, 4)
    of PiB:
      return multiply(input, true, 5)
    of PB:
      return multiply(input, false, 5)
    else: 
      return toInt(input) # if already bytes, no conversion is necessary

proc toBytesFloat*(input:float, inUnit:Units): float =
  return toFloat(toBytes(input, inUnit))

proc convertBytes*(input:float, inUnit:Units, outUnit:Units, roundDigits:int): float =
  unitAmountOut = -1

  let bytes:int = toBytes(input, inUnit)

  case outUnit:
    of KiB: 
      return math.round(bytes / 1024, roundDigits)
    of KB: 
      return math.round(bytes / 1000, roundDigits)
    of MiB:
      return divide(bytes, true, 2, roundDigits)
    of MB:
      return divide(bytes, false, 2, roundDigits)
    of GiB:
      return divide(bytes, true, 3, roundDigits)
    of GB:
      return divide(bytes, false, 3, roundDigits)
    of TiB:
      return divide(bytes, true, 4, roundDigits)
    of TB:
      return divide(bytes, false, 4, roundDigits)
    of PiB:
      return divide(bytes, true, 5, roundDigits)
    of PB:
      return divide(bytes, false, 5, roundDigits)
    else: 
      return toFloat(bytes) # if already bytes, no conversion is necessary

proc convertBytes*(input:int, outUnit:Units, roundDigits:int): float =
  convertBytes(toFloat(input), Units.Bytes, outUnit, roundDigits)

proc convertBytes*(input:int, outUnit:Units): float =
  convertBytes(toFloat(input), Units.Bytes, outUnit, 1)

proc convertBytes*(input:float, inUnit:Units, outUnit:Units): float =
  convertBytes(input, inUnit, outUnit, 1)