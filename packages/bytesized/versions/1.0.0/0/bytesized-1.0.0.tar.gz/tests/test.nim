import unittest
import bytesized

# toBytes

test "GiB to Bytes":
  check toBytes(32, Units.GiB) == 34359738368

test "GiB to Bytes (float)":
  check toBytesFloat(32, Units.GiB) == 34359738368.0

test "GB to Bytes":
  check toBytes(32, Units.GB) == 32000000000

# convertBytes

test "Bytes to GiB":
  check convertBytes(17179869184, Units.GiB) == 16.0

test "Bytes to GiB (5 decimal places rounding)":
  check convertBytes(16000000000, Units.GiB, 5) == 14.90116

test "Bytes to GB":
  check convertBytes(16000000000, Units.GB) == 16.0

test "GB to GiB":
  check convertBytes(16, Units.GB, Units.GiB) == 14.9

test "MB to TiB":
  check convertBytes(8000000000f, Units.MB, Units.TiB) == 7276.0