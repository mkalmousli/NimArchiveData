
# Code of Conduct

### Our Pledge

In the interest of fostering an open and welcoming environment, we as contributors and maintainers pledge to making participation in our project and our community a harassment-free experience for everyone, regardless of age, body size, disability, ethnicity, sex characteristics, gender identity and expression, level of experience, education, socio-economic status, nationality, personal appearance, race, religion, or sexual identity and orientation.

### Our Standards

Examples of behavior that contributes to creating a positive environment include:

Using welcoming and inclusive language
Being respectful of differing viewpoints and experiences
Gracefully accepting constructive criticism
Focusing on what is best for the community
Showing empathy towards other community members
Examples of unacceptable behavior by participants include:

The use of sexualized language or imagery and unwelcome sexual attention or advances
Trolling, insulting/derogatory comments, and personal or political attacks
Public or private harassment
Publishing others' private information, such as a physical or electronic address, without explicit permission
Other conduct which could reasonably be considered inappropriate in a professional setting
Our Responsibilities
Project maintainers are responsible for clarifying the standards of acceptable behavior and are expected to take appropriate and fair corrective action in response to any instances of unacceptable behavior.

Project maintainers have the right and responsibility to remove, edit, or reject comments, commits, code, wiki edits, issues, and other contributions that are not aligned to this Code of Conduct, or to ban temporarily or permanently any contributor for other behaviors that they deem inappropriate, threatening, offensive, or harmful.

#### Anti-harassment

The project is dedicated to a harassment-free experience for everyone,
regardless of gender, gender identity and expression, sexual orientation, disability, physical appearance, body size, race, age, etc.

We do not tolerate harassment of participants in any form.
Participants violating these rules may be sanctioned.

Harassment includes:
- Unsolicited sexual contents in public spaces
- Unsolicited intimidation or stalking
- Unsolicited disruption of discussions or events
- Unsolicited inappropriate physical contact
- Unsolicited sexual attention


### Attribution

This Code of Conduct is adapted from:

- https://www.contributor-covenant.org/version/1/4/code-of-conduct.html
- https://geekfeminism.wikia.org/wiki/Conference_anti-harassment/Policy
