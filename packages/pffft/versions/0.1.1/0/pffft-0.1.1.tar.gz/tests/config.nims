switch("path", "$projectDir/..")
