switch("path", "$projectDir/../src")

