# Package

version = "2.0"
author = "Adam Chesak"
description = "Nim RSS parser"
license = "MIT"
srcDir = "src"

# Deps

requires "nim >= 1.6.10"
