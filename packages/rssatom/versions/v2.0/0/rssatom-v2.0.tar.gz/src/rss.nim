# Nim RSS (Really Simple Syndication) module

# Written by Adam Chesak.
# Released under the MIT open source license.


# Import modules.
import httpclient
import strutils
import sequtils
import xmlparser
import xmltree
import streams
import sugar
import htmlparser
import options


# Create the types.
type
  FeedType* = enum
    RSSv2,Atom

  RSS* = object
    title*: Option[string]
    link*: Option[string]
    description*: Option[string]
    language*: Option[string]
    copyright*: Option[string]
    managingEditor*: Option[string]
    webMaster*: Option[string]
    pubDate*: Option[string]
    lastBuildDate*: Option[string]
    category*: seq[string]
    generator*: Option[string]
    docs*: Option[string]
    cloud*: RSSCloud
    ttl*: Option[string]
    image*: RSSImage
    rating*: Option[string]
    textInput*: RSSTextInput
    skipHours*: seq[string]
    skipDays*: seq[string]
    items*: seq[RSSItem]
    author*: Author
    feedType: FeedType

  RSSEnclosure* = object
    url*: string
    length*: string
    enclosureType*: string

  RSSCloud* = object
    domain*: Option[string]
    port*: Option[string]
    path*: Option[string]
    registerProcedure*: Option[string]
    protocol*: Option[string]

  RSSImage* = object
    url*: Option[string]
    title*: Option[string]
    link*: Option[string]
    width*: Option[string]
    height*: Option[string]
    description*: Option[string]

  RSSTextInput* = object
    title*: Option[string]
    description*: Option[string]
    name*: Option[string]
    link*: Option[string]

  RSSItem* = object
    title*: Option[string]
    link*: Option[string]
    description*: Option[string]
    author*: Author
    category*: seq[string]
    comments*: Option[string]
    enclosure*: RSSEnclosure
    guid*: Option[string]
    pubDate*: Option[string]
    sourceUrl*: Option[string]
    sourceText*: Option[string]
    id*: Option[string] #Atom
    updated*: Option[string] #Atom
    feedType*: FeedType

  Author* = object
    name*: Option[string]
    email*: Option[string]
    uri*: Option[string]
    legacyRss*: Option[string] #RSSV2


proc innerTexts*(n: XmlNode): Option[string] =
  if not isNil(n):
    result = some(n.innerText)
  else:
    result = none(string)


proc parseTextxn(node:XmlNode, childQuery:string): Option[string] =
  let 
    tnode = node.child(childQuery)
  if not isNil(tnode):
    case tnode.innerText:
    of "":
      if len(tnode) > 0:
        if node[0].kind == xnCData:
          result = some(parseHtml(node[0].rawText).innerText)
    else:
      result = some(tnode.innerText)
  else:
    result = none(string)


proc parseMultiple(node:XmlNode, children:seq[string]): Option[string] =
  for kid in children:
    if not isNil(node.child(kid)):
      result = node.parseTextxn(kid)

      
proc getEnclosure(node:XmlNode): RSSEnclosure =
  var 
    encl: RSSEnclosure = RSSEnclosure()
  encl.url = node.attr("url")
  encl.length = node.attr("length")
  encl.enclosureType = node.attr("type")

  return(encl)


proc parseAtomtext(node:XmlNode, childQuery:string, attribute:string): Option[string] =
  let 
    tnode = node.child(childQuery)
  if not isNil(tnode):
    case tnode.attr(attribute):
    of "":
      result = none(string)
    else:
      result = some(tnode.attr(attribute))
  else:
    result = none(string)


proc parseItem(node: XmlNode): RSSItem =
  var 
    item: RSSItem = RSSItem()
  item.feedType = RSSv2
  item.title = node.parseTextxn("title")
  item.link = node.parseTextxn("link")
  item.description = node.parseTextxn("description")
  item.author.legacyRss = node.parseMultiple(@["author", "dc:creator"])
  if not isNil(node.child("category")):
    item.category = map(node.findAll("category"), (x: XmlNode) -> string => x.innerText)
  item.comments = node.parseTextxn("comments")
  if not isNil(node.child("enclosure")):
    let 
      enclosure = node.child("enclosure")
    var 
      encl = getEnclosure(enclosure)
    item.enclosure = encl
  item.guid = node.parseTextxn("guid")
  item.pubDate = node.parseTextxn("pubDate")
  if not isNil(node.child("source")):
    item.sourceUrl = some(node.child("source").attr("url"))
    item.sourceText = some(node.child("source").innerText)

  return item


proc getCloud(channelCloud:XmlNode): RSSCloud =
  var 
    cloud: RSSCloud = RSSCloud()
  cloud.domain = some(channelCloud.attr("domain"))
  cloud.port = some(channelCloud.attr("port"))
  cloud.path = some(channelCloud.attr("path"))
  cloud.registerProcedure = some(channelCloud.attr("registerProcedure"))
  cloud.protocol = some(channelCloud.attr("protocol"))

  return(cloud)


proc getImage(img:XmlNode): RSSImage =
  var 
    image: RSSImage = RSSImage()
  image.url = img.parseTextxn("url")
  if img.attr("rdf:resource").len != 0 and img.attr("rdf:resource") != "":
    image.url = some(img.attr("rdf:resource"))  
  image.title = img.parseTextxn("title")
  image.link = img.parseTextxn("link") 
  image.width = img.parseTextxn("width")
  image.height = img.parseTextxn("height")
  image.description = img.parseTextxn("description")

  return(image)


proc getTextInput(textNode:XmlNode): RSSTextInput =
  var 
    textInput: RSSTextInput = RSSTextInput()
  textInput.title = textNode.parseTextxn("title")
  textInput.description = textNode.parseTextxn("description")
  textInput.name = textNode.parseTextxn("name")
  textInput.link = textNode.parseTextxn("link")

  return(textInput)


proc parseRSS*(data: string): RSS =
  ## Parses the RSS from the given string.
  # Parse into XML.
  let root: XmlNode = parseXML(newStringStream(data))
  let channel: XmlNode = root.child("channel")

  # Create the return object.
  var rss: RSS = RSS()
  rss.feedType = RSSv2
  # Fill the required fields.
  rss.title = channel.parseTextxn("title")
  rss.link = channel.parseTextxn("link")
  rss.description = channel.parseTextxn("description")

  # Fill the optional fields.
  rss.language = channel.parseMultiple(@["language", "dc:language"])
  rss.copyright = channel.parseTextxn("copyright")
  rss.managingEditor = channel.parseTextxn("managingEditor")
  rss.webMaster = channel.parseTextxn("webMaster")
  rss.pubDate = channel.parseMultiple(@["pubDate", "dc:date"])
  rss.lastBuildDate  = channel.parseTextxn("lastBuildDate")
  if not isNil(channel.child("category")):
    rss.category = map(channel.findAll("category"), (x: XmlNode) -> string => x.innerText)

  rss.generator = channel.parseMultiple(@["generator", "dc:publisher"])
  rss.docs = channel.parseTextxn("docs")
  if not isNil(channel.child("cloud")):
    let
      channelCloud = channel.child("cloud")
    var 
      cloud = getCloud(channelCloud)
    rss.cloud = cloud
  rss.ttl = channel.parseTextxn("ttl")
  if not isNil(channel.child("image")):
    let 
      img = channel.child("image")
    var image = getImage(img)
    rss.image = image
  rss.rating = channel.parseTextxn("rating")
  if not isNil(channel.child("textInput")):
    let
      textNode = channel.child("textInput")
    var 
      textInput = getTextInput(textNode)
    rss.textInput = textInput
  if not isNil(channel.child("skipHours")):
    rss.skipHours = map(channel.findAll("hour"), (x: XmlNode) -> string => x.innerText)
  if not isNil(channel.child("skipDays")):
    rss.skipDays = map(channel.findAll("day"), (x: XmlNode) -> string => x.innerText)

  # If there are no items:
  if isNil(channel.child("item")) and isNil(root.child("item")):
    rss.items = @[]
    return rss

  # Otherwise, add the items.
  if not isNil(channel.child("item")):
    rss.items = map(channel.findAll("item"), parseItem)
  else:
    rss.items = map(root.findAll("item"), parseItem)

  # Return the RSS data.
  return rss


proc getAuthor(node:XmlNode): Author =
  var
    author = Author()
  author.name = node.child("name").innerTexts
  author.email = node.child("email").innerTexts
  author.uri = node.child("uri").innerTexts

  return(author)


proc parseEntry(node: XmlNode): RSSItem =
  var 
    item: RSSItem = RSSItem()
  item.feedType = Atom
  item.id = node.parseTextxn("id")
  item.title = node.parseTextxn("title")
  item.link = node.parseAtomtext("link", "href")
  item.description = node.parseTextxn("summary")
  if not isNil(node.child("author")):
    let
      authorship = node.child("author")
    var 
      author = getAuthor(authorship)
    item.author = author
  if not isNil(node.child("category")):
    item.category = map(node.findAll("category"), (x: XmlNode) -> string => x.innerText)
  item.comments = node.parseTextxn("comments")
  item.guid = node.parseTextxn("guid")
  item.pubDate = node.parseTextxn("published")
  item.updated = node.parseTextxn("updated")
  if not isNil(node.child("source")):
    item.sourceUrl = some(node.child("source").attr("url"))
    item.sourceText = some(node.child("source").innerText)

  return item


proc parseAtom*(data: string): RSS =
  ## Parses the RSS from the given string.
  # Parse into XML.
  let channel: XmlNode = parseXML(newStringStream(data))
  # Create the return object.
  var rss: RSS = RSS()
  rss.feedType = Atom
  # Fill the required fields.
  rss.title = channel.parseTextxn("title")
  rss.link = channel.parseAtomtext("link", "href")
  rss.description = channel.parseTextxn("description")

  # Fill the optional fields.
  rss.language = channel.parseMultiple(@["language", "dc:language"])
  rss.copyright = channel.parseTextxn("rights")
  rss.pubDate = channel.parseMultiple(@["published", "dc:date"])
  rss.lastBuildDate  = channel.parseTextxn("updated")
  if not isNil(channel.child("category")):
    rss.category = map(channel.findAll("category"), (x: XmlNode) -> string => x.innerText)
  rss.generator = channel.parseMultiple(@["generator", "dc:publisher"])
  rss.docs = channel.parseTextxn("docs")
  rss.ttl = channel.parseTextxn("ttl")
  if not isNil(channel.child("skipHours")):
    rss.skipHours = map(channel.findAll("hour"), (x: XmlNode) -> string => x.innerText)
  if not isNil(channel.child("skipDays")):
    rss.skipDays = map(channel.findAll("day"), (x: XmlNode) -> string => x.innerText)

  # If there are no items:
  if isNil(channel.child("entry")) and isNil(channel.child("item")):
    rss.items = @[]
    return rss

  # Otherwise, add the items.
  if not isNil(channel.child("entry")):
    rss.items = map(channel.findAll("entry"), parseEntry)

  # Return the RSS data.
  return rss


proc loadRSS*(filename: string): RSS =
  ## Loads the RSS from the given ``filename``.

  # Load the data from the file.
  var rss: string = readFile(filename)

  return parseRSS(rss)


proc loadAtom*(filename: string): RSS =
  var
    rss: string = readFile(filename)

  result = parseAtom(rss)


proc getRSS*(url: string): RSS =
  ## Gets the RSS over from the specified ``url``.

  # Get the data.
  var rss: string = newHttpClient().getContent(url)

  return parseRSS(rss)
