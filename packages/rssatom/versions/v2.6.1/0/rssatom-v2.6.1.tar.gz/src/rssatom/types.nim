import options


# Create the types.
type
  FeedType* = enum
    RSSv2,Atom

  RSS* = object
    id*: Option[string] #atom
    title*: Option[string]
    link*: Option[string]
    description*: Option[string]
    language*: Option[string]
    copyright*: Option[string]
    managingEditor*: Option[string]
    webMaster*: Option[string]
    pubDate*: Option[string]
    lastBuildDate*: Option[string]
    category*: seq[string]
    generator*: Option[string]
    docs*: Option[string]
    cloud*: RSSCloud
    ttl*: Option[string]
    image*: RSSImage
    rating*: Option[string]
    textInput*: RSSTextInput
    skipHours*: seq[string]
    skipDays*: seq[string]
    items*: seq[RSSItem]
    author*: Author
    feedType*: FeedType

  RSSEnclosure* = object
    url*: string
    length*: string
    enclosureType*: string

  RSSCloud* = object
    domain*: Option[string]
    port*: Option[string]
    path*: Option[string]
    registerProcedure*: Option[string]
    protocol*: Option[string]

  RSSImage* = object
    url*: Option[string]
    title*: Option[string]
    link*: Option[string]
    width*: Option[string]
    height*: Option[string]
    description*: Option[string]

  RSSTextInput* = object
    title*: Option[string]
    description*: Option[string]
    name*: Option[string]
    link*: Option[string]

  RSSItem* = object
    title*: Option[string]
    link*: Option[string]
    description*: Option[string]
    author*: Author
    category*: seq[string]
    comments*: Option[string]
    enclosure*: RSSEnclosure
    guid*: Option[string]
    pubDate*: Option[string]
    sourceUrl*: Option[string]
    sourceText*: Option[string]
    id*: Option[string] #Atom
    updated*: Option[string] #Atom
    feedType*: FeedType

  Author* = object
    name*: Option[string]
    email*: Option[string]
    uri*: Option[string]
    legacyRss*: Option[string] #RSSV2