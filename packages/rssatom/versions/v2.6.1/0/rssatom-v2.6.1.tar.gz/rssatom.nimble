# Package

version = "2.6"
author = "Samuel Rosado, original work: Adam Chesak"
description = "Nim RSS and Atom parser, Atom and RSS creator"
license = "MIT"
srcDir = "src"

# Deps

requires "nim >= 1.6.10"
