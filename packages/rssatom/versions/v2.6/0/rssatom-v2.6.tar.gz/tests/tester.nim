import rssatom
import unittest
import options, xmltree

test "parse rss file":
  let feed = loadRSS("./tests/test.rss")
  check(feed.title.get() == "FeedForAll Sample Feed")
  check(feed.link.get() == "http://www.feedforall.com/industry-solutions.htm")
  check(feed.description.get() == "RSS is a fascinating technology. The uses for RSS are expanding daily. Take a closer look at how various industries are using the benefits of RSS in their businesses.")
  check(feed.language.get() == "en-us")
  check(feed.copyright.get() == "Copyright 2004 NotePage, Inc.")
  check(feed.managingEditor.get() == "marketing@feedforall.com")
  check(feed.pubDate.get() == "Tue, 19 Oct 2004 13:38:55 -0400")
  check(feed.webMaster.get() == "webmaster@feedforall.com")
  check(feed.lastBuildDate.get() == "Tue, 19 Oct 2004 13:39:14 -0400")
  check(feed.category == @["Computers/Software/Internet/Site Management/Content Management", "Computers/Software/Internet/Site Management/Content Management", "Computers/Software/Internet/Site Management/Content Management", "Computers/Software/Internet/Site Management/Content Management", "Computers/Software/Internet/Site Management/Content Management", "Computers/Software/Internet/Site Management/Content Management", "Computers/Software/Internet/Site Management/Content Management", "Computers/Software/Internet/Site Management/Content Management", "Computers/Software/Internet/Site Management/Content Management", "Computers/Software/Internet/Site Management/Content Management"])
  check(feed.generator.get() == "FeedForAll Beta1 (0.0.1.8)")
  check(feed.docs.get() == "http://blogs.law.harvard.edu/tech/rss")
  check(feed.cloud == RSSCloud())
  check(feed.ttl.isNone())
  check(feed.image == RSSImage(url: some("http://www.feedforall.com/ffalogo48x48.gif"), title: some("FeedForAll Sample Feed"), link: some("http://www.feedforall.com/industry-solutions.htm"), width: some("48"), height: some("48"), description: some("FeedForAll Sample Feed")))
  check(feed.rating.isNone())
  check(feed.textInput == RSSTextInput())
  check(len(feed.skipHours) == 0)
  check(len(feed.skipDays) == 0)
  check(feed.items.len == 9)
  let item = feed.items[0]
  check(item.title.get() == "RSS Solutions for Restaurants")
  check(item.link.get() == "http://www.feedforall.com/restaurant.htm")
  check(item.description.get() == """<b>FeedForAll </b>helps Restaurant's communicate with customers. Let your customers know the latest specials or events.<br>
<br>
RSS feed uses include:<br>
<i><font color="#FF0000">Daily Specials <br>
Entertainment <br>
Calendar of Events </i></font>""")
  check(item.author.legacyRss.isNone())
  check(item.category == @["Computers/Software/Internet/Site Management/Content Management"])
  check(item.comments.get() == "http://www.feedforall.com/forum")
  check(item.enclosure == RSSEnclosure())
  check(item.guid.isNone())
  check(item.pubDate.get() == "Tue, 19 Oct 2004 11:09:11 -0400")
  check(item.sourceUrl.isNone())
  check(item.sourceText.isNone())

test "parse rdf file":
  let feed = loadRSS("./tests/test.rdf")
  check(feed.title.get() == "cs updates on arXiv.org")
  check(feed.link.get() == "http://arxiv.org/")
  check(feed.description.get() == "Computer Science (cs) updates on the arXiv.org e-print archive")
  check(feed.language.get() == "en-us")
  check(feed.copyright.isNone())
  check(feed.managingEditor.isNone())
  check(feed.pubDate.get() == "2018-08-30T20:30:00-05:00")
  check(feed.webMaster.isNone())
  check(feed.lastBuildDate.isNone())
  check(len(feed.category) == 0)
  check(feed.generator.get() == "www-admin@arxiv.org")
  check(feed.docs.isNone())
  check(feed.cloud == RSSCloud())
  check(feed.ttl.isNone())
  check(feed.image == RSSImage(url: some("http://arxiv.org/icons/sfx.gif"), title: none(string), link: none(string), width: none(string), height: none(string), description: none(string)))
  check(feed.rating.isNone())
  check(feed.textInput == RSSTextInput())
  check(len(feed.skipHours) == 0)
  check(len(feed.skipDays) == 0)
  check(feed.items.len == 185)
  let item = feed.items[0]
  check(item.title.get() == "QuasarNET: Human-level spectral classification and redshifting with Deep Neural Networks. (arXiv:1808.09955v1 [astro-ph.IM])")
  check(item.link.get() == "http://arxiv.org/abs/1808.09955")
  check(item.description.get() == """<p>We introduce QuasarNET, a deep convolutional neural network that performs
    classification and redshift estimation of astrophysical spectra with
    human-expert accuracy. We pose these two tasks as a \emph{feature detection}
    problem: presence or absence of spectral features determines the class, and
    their wavelength determines the redshift, very much like human-experts proceed.
    When ran on BOSS data to identify quasars through their emission lines,
    QuasarNET defines a sample $99.51\pm0.03$\% pure and $99.52\pm0.03$\% complete,
    well above the requirements of many analyses using these data. QuasarNET
    significantly reduces the problem of line-confusion that induces catastrophic
    redshift failures to below 0.2\%. We also extend QuasarNET to classify spectra
    with broad absorption line (BAL) features, achieving an accuracy of
    $98.0\pm0.4$\% for recognizing BAL and $97.0\pm0.2$\% for rejecting non-BAL
    quasars. QuasarNET is trained on data of low signal-to-noise and medium
    resolution, typical of current and future astrophysical surveys, and could be
    easily applied to classify spectra from current and upcoming surveys such as
    eBOSS, DESI and 4MOST.
    </p>
    """)
  check(item.author.legacyRss.get() == """<a href="http://arxiv.org/find/astro-ph/1/au:+Busca_N/0/1/0/all/0/1">Nicolas Busca</a>, <a href="http://arxiv.org/find/astro-ph/1/au:+Balland_C/0/1/0/all/0/1">Christophe Balland</a>""")
  check(len(item.category) == 0)
  check(item.comments.isNone())
  check(item.enclosure == RSSEnclosure())
  check(item.guid.isNone())
  check(item.pubDate.isNone())
  check(item.sourceUrl.isNone())
  check(item.sourceText.isNone())

test "democracy now rss":
  let feed = loadRSS("./tests/democracynow.rss")
  check(feed.title.get() == "Democracy Now!")
  check(feed.link.get() == "http://www.democracynow.org/")
  check(feed.docs.get() == "http://www.rssboard.org/rss-specification")
  check(feed.image.url.get() == "http://www.democracynow.org/assets/dn-logo-for-podcast-7372130f672a82cfeb392d7de1c62fa4183649c2770d4426b11573f81cd104a9.png")
  check(feed.items.len == 34)
  check(feed.items[0].title.get() == "Hunter Biden Is Indicted on Gun Charges as House GOP Launch Impeachment Inquiry into Joe Biden")
  check(feed.items[0].link.get() == "http://www.democracynow.org/2023/9/15/hunter_biden_ryan_grim")

test "atom the Register":
  let feed = loadAtom("./tests/headlines.atom")
  check(feed.title.get() == "The Register")
  check(feed.link.get() == "https://www.theregister.com/headlines.atom")
  check(feed.description.isSome())
  check(feed.copyright.get() == "Copyright © 2023, Situation Publishing")
  check(feed.lastBuildDate.get() == "2023-09-17T14:33:08.00Z")
  check(feed.items[0].title.get == "Gandalf chatbot security game counters privacy fireballs")
  check(feed.items[0].id.get == "tag:theregister.com,2005:story229643")
  check(feed.items[0].author.name.get == "Thomas Claburn")
  check(feed.items[0].author.email.isNone())
  check(feed.items[0].description.get == "<h4>You shall not pass judgement, Lakera AI insists, because exposed player info was harmless</h4> <p>Gandalf, an educational game designed to teach people about the risks of prompt injection attacks on large language models (LLMs), until recently included an unintended expert level: a publicly accessible analytics dashboard that provided access to the prompts players submitted and related metrics.…</p>")

  test "404 media weird RSS":
    let feed = loadRSS("./tests/404media.xml")
    check(feed.items[0].title.get() == "I Gambled in MGM\'s Hacked Casinos")

  test "proceso":
    let feed = loadAtom("./tests/proceso.xml")

    check(feed.id.get() == "https://www.proceso.com.mx/rss/feed.html?r=172")
    check(feed.author.name.isNone())
    check(feed.lastBuildDate.get() == "2023-09-30T14:32:16-03:00")
    check(feed.items[0].title.get() == "Banqueros, dispuestos a otorgar créditos por 500 mil mdp: López Obrador")
    check(feed.items[0].link.get() == "https://www.proceso.com.mx/revista/2019/7/26/banqueros-dispuestos-otorgar-creditos-por-500-mil-mdp-lopez-obrador-228444.html")
    check(feed.items[0].author.name.get() == "Carlos Alberto Jimenez")

  test "create from object":
    let 
      feed = loadAtom("./tests/headlines.atom")
      parsedXml = buildAtom(feed)
      reloadfeed = parseAtom($parsedXml)
    
    check(feed.id.get() == reloadfeed.id.get())
    check(feed.title.get() == reloadfeed.title.get())
    check(feed.link.get() == reloadfeed.link.get())
    check(feed.author == reloadfeed.author)
    check(feed.description.get() == reloadfeed.description.get())
    check(len(feed.items) == len(reloadfeed.items))
    check(feed.items[0].title.get() == reloadfeed.items[0].title.get())
    check(feed.items[0].link.get() == reloadfeed.items[0].link.get())
    check(feed.items[1].title.get == reloadfeed.items[1].title.get)

  test "create from another object":
    let 
      feed = loadAtom("./tests/proceso.xml")
      parsedXml = buildAtom(feed)
      reloadfeed = parseAtom($parsedXml)
    
    check(feed.id.get() == reloadfeed.id.get())
    check(feed.author.name.isNone())
    check(reloadfeed.author.name.get == "")
    check(feed.items[0].title.get == reloadfeed.items[0].title.get)
    check(feed.items[2].title.get == reloadfeed.items[2].title.get)
    check(feed.items[2].link.get == reloadfeed.items[2].link.get)
    dumpAtom("./tests/redoingProceso.xml", feed)

  test "rss from object":
    let 
      rss = loadRss("./tests/democracynow.rss")
      rssXml = buildRss(rss)
      reloadRss = parseRss($rssXml)

    check(rss.link.get() == reloadRss.link.get())
    check(rss.title.get() == reloadRss.title.get())
    check(rss.items[0].title.get() == "Hunter Biden Is Indicted on Gun Charges as House GOP Launch Impeachment Inquiry into Joe Biden")
    check(reloadRss.items[0].title.get() == "Hunter Biden Is Indicted on Gun Charges as House GOP Launch Impeachment Inquiry into Joe Biden")
    check(rss.items[3].author.legacyRss.get() == reloadRss.items[3].author.legacyRss.get())
    check(rss.items[3].pubDate.get() == reloadRss.items[3].pubDate.get())
    dumpRss("./tests/redoingDN.xml", rss)