# Package

version = "2.6.3"
author = "Samuel Rosado, original work: Adam Chesak"
description = "Nim RSS and Atom parser and creator"
license = "MIT"
srcDir = "src"

# Deps

requires "nim >= 1.6.10"
