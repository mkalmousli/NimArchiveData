# Package

version = "2.7"
author = "Samuel Rosado"
description = "Nim RSS and Atom parser and creator"
license = "MIT"
srcDir = "src"

# Deps

requires "nim >= 1.6.10"
