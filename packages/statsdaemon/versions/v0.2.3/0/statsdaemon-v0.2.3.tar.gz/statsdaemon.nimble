# Package

version       = "0.2.3"
author        = "Vladimir Berezenko"
description   = "StatsD compatible daemon in pure Nim"
license       = "MIT"
srcDir        = "src"
bin           = @["statsdaemon"]


# Dependencies

requires "nim >= 2.0.0"
requires "https://github.com/Q-Master/serverloggers.nim.git >= 0.1.1"
