# Package

version       = "0.3.0"
author        = "penguinite"
description   = "Wrapper over std/sysrand"
license       = "BSD-3-Clause"
srcDir        = "src"


# Dependencies

requires "nim >= 1.6.14"
