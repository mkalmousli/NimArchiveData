# tabulator Changelog

## Unreleased

### Added

### Changed

### Fixed

### Removed

____
## [v0.5.0] - 2026-01-11
### Changed

- Various refinements and additional tests

## [v0.3.0] - 2026-01-10
### Changed

- Made tables with and without separator align equally
  - Separator only for visuals

## [v0.2.0] - 2026-01-10
### Added

- Position-based terminal output
  - Much better Unicode handling (especially for complicated scripts)
- Expand auto-sized columns to reach table width (if defined)

### Changed

- Improved file output
  - Strip out any embedded ANSI codes
- Use pipe characters for borders

## [v0.1.0] - 2026-01-10

- Initial release

____
[v0.5.0]:https://github.com/erykjj/tabulator/releases/tag/v0.5.0
[v0.3.0]:https://github.com/erykjj/tabulator/releases/tag/v0.3.0
[v0.2.0]:https://github.com/erykjj/tabulator/releases/tag/v0.2.0
[v0.1.0]:https://github.com/erykjj/tabulator/releases/tag/v0.1.0
