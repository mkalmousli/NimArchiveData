# © 2023 Adam Blažek <blazead5@cvut.cz>
# SPDX-License-Identifier: GPL-3.0-or-later

import pkg/raylib

proc palette[height: static int](columns: varargs[array[height, Color]]): Image =
  result = genImageColor(columns.len.int32, height.int32, Black)
  for x, column in columns:
    for y, color in column:
      result.imageDrawPixel(x.int32, y.int32, color)

let
  rgbBasic* =
    palette(
      [
        Color(a: 255, r: 255, g: 0, b: 0),
        Color(a: 255, r: 255, g: 85, b: 0),
        Color(a: 255, r: 255, g: 170, b: 0),
        Color(a: 255, r: 255, g: 255, b: 0),
        Color(a: 255, r: 170, g: 255, b: 0),
        Color(a: 255, r: 85, g: 255, b: 0)
      ],
      [
        Color(a: 255, r: 255, g: 0, b: 85),
        Color(a: 0, r: 0, g: 0, b: 0),
        Color(a: 0, r: 0, g: 0, b: 0),
        Color(a: 0, r: 0, g: 0, b: 0),
        Color(a: 0, r: 0, g: 0, b: 0),
        Color(a: 255, r: 0, g: 255, b: 0)
      ],
      [
        Color(a: 255, r: 255, g: 0, b: 170),
        Color(a: 255, r: 0, g: 0, b: 0),
        Color(a: 255, r: 85, g: 85, b: 85),
        Color(a: 255, r: 170, g: 170, b: 170),
        Color(a: 255, r: 255, g: 255, b: 255),
        Color(a: 255, r: 0, g: 255, b: 85)
      ],
      [
        Color(a: 255, r: 255, g: 0, b: 255),
        Color(a: 0, r: 0, g: 0, b: 0),
        Color(a: 0, r: 0, g: 0, b: 0),
        Color(a: 0, r: 0, g: 0, b: 0),
        Color(a: 0, r: 0, g: 0, b: 0),
        Color(a: 255, r: 0, g: 255, b: 170)
      ],
      [
        Color(a: 255, r: 170, g: 0, b: 255),
        Color(a: 255, r: 85, g: 0, b: 255),
        Color(a: 255, r: 0, g: 0, b: 255),
        Color(a: 255, r: 0, g: 85, b: 255),
        Color(a: 255, r: 0, g: 170, b: 255),
        Color(a: 255, r: 0, g: 255, b: 255)
      ],
    )

let
  colar* =
    palette(
      [
        Color(a: 255, r: 248, g: 250, b: 251),
        Color(a: 255, r: 242, g: 244, b: 246),
        Color(a: 255, r: 235, g: 237, b: 239),
        Color(a: 255, r: 224, g: 228, b: 229),
        Color(a: 255, r: 209, g: 214, b: 216),
        Color(a: 255, r: 177, g: 182, b: 185),
        Color(a: 255, r: 151, g: 155, b: 157),
        Color(a: 255, r: 126, g: 130, b: 130),
        Color(a: 255, r: 102, g: 105, b: 104),
        Color(a: 255, r: 80, g: 81, b: 79),
        Color(a: 255, r: 58, g: 58, b: 55),
        Color(a: 255, r: 37, g: 37, b: 33),
        Color(a: 255, r: 18, g: 18, b: 16)
      ],
      [
        Color(a: 255, r: 255, g: 245, b: 245),
        Color(a: 255, r: 255, g: 227, b: 227),
        Color(a: 255, r: 255, g: 201, b: 201),
        Color(a: 255, r: 255, g: 168, b: 168),
        Color(a: 255, r: 255, g: 135, b: 135),
        Color(a: 255, r: 255, g: 107, b: 107),
        Color(a: 255, r: 250, g: 82, b: 82),
        Color(a: 255, r: 240, g: 62, b: 62),
        Color(a: 255, r: 224, g: 49, b: 49),
        Color(a: 255, r: 201, g: 42, b: 42),
        Color(a: 255, r: 176, g: 37, b: 37),
        Color(a: 255, r: 150, g: 32, b: 32),
        Color(a: 255, r: 125, g: 26, b: 26)
      ],
      [
        Color(a: 255, r: 255, g: 240, b: 246),
        Color(a: 255, r: 255, g: 222, b: 235),
        Color(a: 255, r: 252, g: 194, b: 215),
        Color(a: 255, r: 250, g: 162, b: 193),
        Color(a: 255, r: 247, g: 131, b: 172),
        Color(a: 255, r: 240, g: 101, b: 149),
        Color(a: 255, r: 230, g: 73, b: 128),
        Color(a: 255, r: 214, g: 51, b: 108),
        Color(a: 255, r: 194, g: 37, b: 92),
        Color(a: 255, r: 166, g: 30, b: 77),
        Color(a: 255, r: 140, g: 25, b: 65),
        Color(a: 255, r: 115, g: 21, b: 54),
        Color(a: 255, r: 89, g: 16, b: 42)
      ],
      [
        Color(a: 255, r: 248, g: 240, b: 252),
        Color(a: 255, r: 243, g: 217, b: 250),
        Color(a: 255, r: 238, g: 190, b: 250),
        Color(a: 255, r: 229, g: 153, b: 247),
        Color(a: 255, r: 218, g: 119, b: 242),
        Color(a: 255, r: 204, g: 93, b: 232),
        Color(a: 255, r: 190, g: 75, b: 219),
        Color(a: 255, r: 174, g: 62, b: 201),
        Color(a: 255, r: 156, g: 54, b: 181),
        Color(a: 255, r: 134, g: 46, b: 156),
        Color(a: 255, r: 112, g: 38, b: 130),
        Color(a: 255, r: 90, g: 30, b: 105),
        Color(a: 255, r: 68, g: 23, b: 79)
      ],
      [
        Color(a: 255, r: 243, g: 240, b: 255),
        Color(a: 255, r: 229, g: 219, b: 255),
        Color(a: 255, r: 208, g: 191, b: 255),
        Color(a: 255, r: 177, g: 151, b: 252),
        Color(a: 255, r: 151, g: 117, b: 250),
        Color(a: 255, r: 132, g: 94, b: 247),
        Color(a: 255, r: 121, g: 80, b: 242),
        Color(a: 255, r: 112, g: 72, b: 232),
        Color(a: 255, r: 103, g: 65, b: 217),
        Color(a: 255, r: 95, g: 61, b: 196),
        Color(a: 255, r: 82, g: 53, b: 171),
        Color(a: 255, r: 70, g: 45, b: 145),
        Color(a: 255, r: 58, g: 37, b: 120)
      ],
      [
        Color(a: 255, r: 237, g: 242, b: 255),
        Color(a: 255, r: 219, g: 228, b: 255),
        Color(a: 255, r: 186, g: 200, b: 255),
        Color(a: 255, r: 145, g: 167, b: 255),
        Color(a: 255, r: 116, g: 143, b: 252),
        Color(a: 255, r: 92, g: 124, b: 250),
        Color(a: 255, r: 76, g: 110, b: 245),
        Color(a: 255, r: 66, g: 99, b: 235),
        Color(a: 255, r: 59, g: 91, b: 219),
        Color(a: 255, r: 54, g: 79, b: 199),
        Color(a: 255, r: 47, g: 68, b: 173),
        Color(a: 255, r: 40, g: 58, b: 148),
        Color(a: 255, r: 33, g: 48, b: 122)
      ],
      [
        Color(a: 255, r: 231, g: 245, b: 255),
        Color(a: 255, r: 208, g: 235, b: 255),
        Color(a: 255, r: 165, g: 216, b: 255),
        Color(a: 255, r: 116, g: 192, b: 252),
        Color(a: 255, r: 77, g: 171, b: 247),
        Color(a: 255, r: 51, g: 154, b: 240),
        Color(a: 255, r: 34, g: 139, b: 230),
        Color(a: 255, r: 28, g: 126, b: 214),
        Color(a: 255, r: 25, g: 113, b: 194),
        Color(a: 255, r: 24, g: 100, b: 171),
        Color(a: 255, r: 20, g: 85, b: 145),
        Color(a: 255, r: 17, g: 70, b: 120),
        Color(a: 255, r: 13, g: 55, b: 94)
      ],
      [
        Color(a: 255, r: 227, g: 250, b: 252),
        Color(a: 255, r: 197, g: 246, b: 250),
        Color(a: 255, r: 153, g: 233, b: 242),
        Color(a: 255, r: 102, g: 217, b: 232),
        Color(a: 255, r: 59, g: 201, b: 219),
        Color(a: 255, r: 34, g: 184, b: 207),
        Color(a: 255, r: 21, g: 170, b: 191),
        Color(a: 255, r: 16, g: 152, b: 173),
        Color(a: 255, r: 12, g: 133, b: 153),
        Color(a: 255, r: 11, g: 114, b: 133),
        Color(a: 255, r: 9, g: 92, b: 107),
        Color(a: 255, r: 7, g: 70, b: 82),
        Color(a: 255, r: 5, g: 48, b: 56)
      ],
      [
        Color(a: 255, r: 230, g: 252, b: 245),
        Color(a: 255, r: 195, g: 250, b: 232),
        Color(a: 255, r: 150, g: 242, b: 215),
        Color(a: 255, r: 99, g: 230, b: 190),
        Color(a: 255, r: 56, g: 217, b: 169),
        Color(a: 255, r: 32, g: 201, b: 151),
        Color(a: 255, r: 18, g: 184, b: 134),
        Color(a: 255, r: 12, g: 166, b: 120),
        Color(a: 255, r: 9, g: 146, b: 104),
        Color(a: 255, r: 8, g: 127, b: 91),
        Color(a: 255, r: 6, g: 102, b: 73),
        Color(a: 255, r: 5, g: 77, b: 55),
        Color(a: 255, r: 3, g: 51, b: 37)
      ],
      [
        Color(a: 255, r: 235, g: 251, b: 238),
        Color(a: 255, r: 211, g: 249, b: 216),
        Color(a: 255, r: 178, g: 242, b: 187),
        Color(a: 255, r: 140, g: 233, b: 154),
        Color(a: 255, r: 105, g: 219, b: 124),
        Color(a: 255, r: 81, g: 207, b: 102),
        Color(a: 255, r: 64, g: 192, b: 87),
        Color(a: 255, r: 55, g: 178, b: 77),
        Color(a: 255, r: 47, g: 158, b: 68),
        Color(a: 255, r: 43, g: 138, b: 62),
        Color(a: 255, r: 35, g: 112, b: 50),
        Color(a: 255, r: 27, g: 87, b: 39),
        Color(a: 255, r: 19, g: 61, b: 27)
      ],
      [
        Color(a: 255, r: 244, g: 252, b: 227),
        Color(a: 255, r: 233, g: 250, b: 200),
        Color(a: 255, r: 216, g: 245, b: 162),
        Color(a: 255, r: 192, g: 235, b: 117),
        Color(a: 255, r: 169, g: 227, b: 75),
        Color(a: 255, r: 148, g: 216, b: 45),
        Color(a: 255, r: 130, g: 201, b: 30),
        Color(a: 255, r: 116, g: 184, b: 22),
        Color(a: 255, r: 102, g: 168, b: 15),
        Color(a: 255, r: 92, g: 148, b: 13),
        Color(a: 255, r: 76, g: 122, b: 11),
        Color(a: 255, r: 60, g: 97, b: 9),
        Color(a: 255, r: 44, g: 71, b: 6)
      ],
      [
        Color(a: 255, r: 255, g: 249, b: 219),
        Color(a: 255, r: 255, g: 243, b: 191),
        Color(a: 255, r: 255, g: 236, b: 153),
        Color(a: 255, r: 255, g: 224, b: 102),
        Color(a: 255, r: 255, g: 212, b: 59),
        Color(a: 255, r: 252, g: 196, b: 25),
        Color(a: 255, r: 250, g: 176, b: 5),
        Color(a: 255, r: 245, g: 159, b: 0),
        Color(a: 255, r: 240, g: 140, b: 0),
        Color(a: 255, r: 230, g: 119, b: 0),
        Color(a: 255, r: 179, g: 92, b: 0),
        Color(a: 255, r: 128, g: 66, b: 0),
        Color(a: 255, r: 102, g: 53, b: 0)
      ],
      [
        Color(a: 255, r: 255, g: 244, b: 230),
        Color(a: 255, r: 255, g: 232, b: 204),
        Color(a: 255, r: 255, g: 216, b: 168),
        Color(a: 255, r: 255, g: 192, b: 120),
        Color(a: 255, r: 255, g: 169, b: 77),
        Color(a: 255, r: 255, g: 146, b: 43),
        Color(a: 255, r: 253, g: 126, b: 20),
        Color(a: 255, r: 247, g: 103, b: 7),
        Color(a: 255, r: 232, g: 89, b: 12),
        Color(a: 255, r: 217, g: 72, b: 15),
        Color(a: 255, r: 191, g: 64, b: 13),
        Color(a: 255, r: 153, g: 51, b: 11),
        Color(a: 255, r: 128, g: 43, b: 9)
      ],
      [
        Color(a: 255, r: 255, g: 248, b: 220),
        Color(a: 255, r: 252, g: 225, b: 188),
        Color(a: 255, r: 247, g: 202, b: 158),
        Color(a: 255, r: 241, g: 178, b: 128),
        Color(a: 255, r: 233, g: 155, b: 98),
        Color(a: 255, r: 223, g: 133, b: 69),
        Color(a: 255, r: 212, g: 110, b: 37),
        Color(a: 255, r: 189, g: 95, b: 27),
        Color(a: 255, r: 164, g: 81, b: 23),
        Color(a: 255, r: 138, g: 69, b: 19),
        Color(a: 255, r: 112, g: 58, b: 19),
        Color(a: 255, r: 87, g: 47, b: 18),
        Color(a: 255, r: 61, g: 33, b: 13)
      ],
      [
        Color(a: 255, r: 250, g: 244, b: 235),
        Color(a: 255, r: 237, g: 224, b: 209),
        Color(a: 255, r: 224, g: 202, b: 183),
        Color(a: 255, r: 211, g: 183, b: 158),
        Color(a: 255, r: 197, g: 162, b: 133),
        Color(a: 255, r: 183, g: 143, b: 109),
        Color(a: 255, r: 168, g: 124, b: 86),
        Color(a: 255, r: 149, g: 107, b: 71),
        Color(a: 255, r: 130, g: 91, b: 58),
        Color(a: 255, r: 111, g: 75, b: 45),
        Color(a: 255, r: 94, g: 58, b: 33),
        Color(a: 255, r: 78, g: 43, b: 21),
        Color(a: 255, r: 66, g: 36, b: 18)
      ],
      [
        Color(a: 255, r: 248, g: 250, b: 251),
        Color(a: 255, r: 230, g: 228, b: 220),
        Color(a: 255, r: 213, g: 207, b: 189),
        Color(a: 255, r: 194, g: 185, b: 160),
        Color(a: 255, r: 174, g: 165, b: 140),
        Color(a: 255, r: 154, g: 145, b: 120),
        Color(a: 255, r: 134, g: 124, b: 101),
        Color(a: 255, r: 115, g: 106, b: 83),
        Color(a: 255, r: 95, g: 87, b: 70),
        Color(a: 255, r: 75, g: 70, b: 57),
        Color(a: 255, r: 56, g: 53, b: 45),
        Color(a: 255, r: 37, g: 37, b: 33),
        Color(a: 255, r: 18, g: 18, b: 16)
      ],
      [
        Color(a: 255, r: 249, g: 251, b: 231),
        Color(a: 255, r: 232, g: 237, b: 156),
        Color(a: 255, r: 210, g: 223, b: 78),
        Color(a: 255, r: 194, g: 206, b: 52),
        Color(a: 255, r: 181, g: 187, b: 46),
        Color(a: 255, r: 167, g: 168, b: 39),
        Color(a: 255, r: 153, g: 150, b: 33),
        Color(a: 255, r: 140, g: 133, b: 28),
        Color(a: 255, r: 126, g: 116, b: 22),
        Color(a: 255, r: 109, g: 100, b: 20),
        Color(a: 255, r: 93, g: 84, b: 17),
        Color(a: 255, r: 77, g: 70, b: 14),
        Color(a: 255, r: 54, g: 48, b: 10)
      ],
      [
        Color(a: 255, r: 236, g: 254, b: 176),
        Color(a: 255, r: 222, g: 243, b: 154),
        Color(a: 255, r: 208, g: 232, b: 132),
        Color(a: 255, r: 194, g: 221, b: 110),
        Color(a: 255, r: 181, g: 209, b: 91),
        Color(a: 255, r: 168, g: 198, b: 72),
        Color(a: 255, r: 155, g: 187, b: 54),
        Color(a: 255, r: 143, g: 176, b: 36),
        Color(a: 255, r: 132, g: 165, b: 19),
        Color(a: 255, r: 122, g: 153, b: 8),
        Color(a: 255, r: 101, g: 128, b: 6),
        Color(a: 255, r: 81, g: 102, b: 5),
        Color(a: 255, r: 61, g: 77, b: 4)
      ],
    )
