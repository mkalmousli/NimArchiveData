# © 2023 Adam Blažek <blazead5@cvut.cz>
# SPDX-License-Identifier: GPL-3.0-or-later

import ./palettes
import ./vector
import pkg/raylib
import pkg/spryvm/spryvm
import pkg/spryvm/sprycore
import std/bitops
import std/cmdline
import std/math
import std/sequtils
import std/sets
import std/sugar
import std/unicode

type
  Mode = enum
    mInject = "Inject"
    # mAdd = "Add"
    mSelect = "Select"
    mColor = "Color"
    mCommand = "Command"

  ToolKind = enum
    tBrush = "Brush"
    tFlood = "Flood"
    tRect = "Rect"

  RectMode = enum
    rFilled
    rOutline

  Tool = object
    case kind: ToolKind
    of tBrush:
      brushSize: int32 # ignored for now
    of tFlood:
      tolerance: int32
    of tRect:
      rectMode: RectMode # ignored for now

  PixelChange = object
    ## Represents that the color of a pixel was changed. Used for the undo functionality.
    pos: Vec
    originalColor: Color
    newColor: Color

  ImageChange = object
    ## Holds a list of all changes that were made in a single step. Used for the undo functionality.
    pixelChanges: seq[PixelChange]

  Picture = ref object
    image: Image
    texture: Texture
    fileName: string
    cursor: Vec
    anchor: Vec
    scale: int32
    selection: seq[Vec]
    history: seq[ImageChange]
    historyPos: int
    lastWritePos: int

  App = ref object
    spry: spryvm.Interpreter
    font: Font
    palettes: seq[Picture]
    pictures: seq[Picture]
    selectedPaletteIndex: int
    selectedPictureIndex: int
    color: Color
    movementTime: int
    command: string
    mode: Mode
    tool: Tool

const
  backgroundColor0 = Color(a: 255, r: 85, g: 85, b: 85)
  backgroundColor1 = Color(a: 255, r: 170, g: 170, b: 170)
  defaultScale = 8'i32
  fps = 60'i32
  margin = 4'i32
  maxPaletteHeight = 156'i32
  movementTimeThreshold = fps div 3
  statusSize = 64'i32
  textSize = 20
  textSpacing = 0

proc loadTexture(picture: Picture) =
  ## Creates a Texture for the picture so that it can be rendered on the screen.
  ## Should be called when creating or resizing a picture.
  picture.texture = loadTextureFromImage(picture.image)

proc updateTexture(picture: Picture) =
  ## Updates the picture’s texture to match the image data.
  ## Should be called after making a change to the image.
  picture.texture.updateTexture(picture.image.loadImageColors().toOpenArray())

proc newPicture(): Picture =
  ## Creates a blank picture with a hard-coded size.
  result = Picture(image: genImageColor(16, 16, Blank), scale: defaultScale)
  result.loadTexture()

proc newPicture(fileName: string): Picture =
  ## Creates a picture by opening the given file.
  result = Picture(image: loadImage(fileName), fileName: fileName, scale: defaultScale)
  result.loadTexture()

proc canvasSize(picture: Picture): Vec =
  ## Returns the size in pixels that the picture will be drawn on the screen.
  picture.scale * picture.image.size

proc moveCursor(picture: Picture; movement: Vec) =
  picture.cursor.x = clamp(picture.cursor.x + movement.x, 0'i32..<picture.image.width)
  picture.cursor.y = clamp(picture.cursor.y + movement.y, 0'i32..<picture.image.height)

proc add(picture: Picture; change: ImageChange) =
  ## Adds the change to the picture’s change history. Does *not* apply the change.
  picture.history.setLen(picture.historyPos)
  picture.history.add(change)
  picture.historyPos.inc

proc apply(picture: Picture; change: PixelChange) =
  picture.image.imageDrawPixel(change.pos.x, change.pos.y, change.newColor)

proc apply(picture: Picture; change: ImageChange) =
  for pixelChange in change.pixelChanges:
    picture.apply(pixelChange)
  picture.updateTexture()

proc redo(picture: Picture) =
  if picture.historyPos < picture.history.len:
    picture.apply(picture.history[picture.historyPos])
    picture.historyPos.inc

proc undo(picture: Picture; change: PixelChange) =
  picture.image.imageDrawPixel(change.pos.x, change.pos.y, change.originalColor)

proc undo(picture: Picture; change: ImageChange) =
  for pixelChange in change.pixelChanges:
    picture.undo(pixelChange)
  picture.updateTexture()

proc undo(picture: Picture) =
  if picture.historyPos > 0:
    picture.historyPos.dec
    picture.undo(picture.history[picture.historyPos])

proc zoomIn(picture: Picture) =
  ## Increases the scale of the picture to approximately 5/4 the original,
  ## in a way that forms a nice sequence.
  picture.scale += 1'i32 shl max(0, picture.scale.fastLog2() - 2)

proc zoomOut(picture: Picture) =
  ## Inverse of the zoomIn operation.
  if picture.scale > 1:
    picture.scale -=
      1'i32 shl
      max(0, picture.scale.fastLog2() - 2 - int(picture.scale.countSetBits() == 1))

proc distance(x, y: Color): int32 =
  ## Calculates the taxicab distance between the two colors.
  abs(x.r.int32 - y.r.int32) + abs(x.g.int32 - y.g.int32) + abs(x.b.int32 - y.b.int32)

proc select(picture: Picture; target: Vec; tool: Tool) =
  case tool.kind
  of tBrush:
    # TODO: brush size
    picture.selection.add(target)
  of tFlood:
    var stack = @[target]
    var toSelect = initHashSet[Vec]()
    while stack.len != 0:
      let pos = stack.pop
      if pos in toSelect:
        continue
      let currentColor = picture.image.getImageColor(pos.x, pos.y)
      toSelect.incl(pos)
      template check(x, y: int) =
        if distance(picture.image.getImageColor(x, y), currentColor) <= tool.tolerance:
          stack.add((x, y))

      if pos.x > 0:
        check(pos.x - 1, pos.y)
      if pos.x < picture.image.width - 1:
        check(pos.x + 1, pos.y)
      if pos.y > 0:
        check(pos.x, pos.y - 1)
      if pos.y < picture.image.height - 1:
        check(pos.x, pos.y + 1)
    picture.selection = toSelect.toSeq()
  of tRect:
    picture.selection =
      collect:
        for y in min(picture.anchor.y, target.y)..max(picture.anchor.y, target.y):
          for x in min(picture.anchor.x, target.x)..max(picture.anchor.x, target.x):
            (x, y)

proc injectColor(picture: Picture; color: Color) =
  let change =
    ImageChange(
      pixelChanges:
        collect(
          for pixel in picture.selection:
            PixelChange(
              pos: pixel,
              originalColor: picture.image.getImageColor(pixel.x, pixel.y),
              newColor: color,
            )
        )
    )
  picture.add(change)
  picture.apply(change)

proc clickPixel(picture: Picture; target: Vec; mode: Mode; tool: Tool; color: Color) =
  ## Reacts to clicking the image at the given point or pressing spacebar with the cursor on it.
  picture.selection = @[]
  picture.anchor = target
  case mode
  of mInject:
    picture.select(target, tool)
    picture.injectColor(color)
  of mSelect:
    picture.select(target, tool)
  of mColor, mCommand:
    discard

proc dragPixel(picture: Picture; target: Vec; mode: Mode; tool: Tool; color: Color) =
  ## Reacts to dragging the mouse over the given point with the mouse button held down,
  ## or to moving the cursor over the point while holding spacebar.
  case mode
  of mInject:
    picture.select(target, tool)
    picture.undo()
    picture.injectColor(color)
  of mSelect:
    picture.select(target, tool)
  of mColor, mCommand:
    discard

proc isSaved(picture: Picture): bool =
  picture.historyPos == picture.lastWritePos

proc write(picture: Picture) =
  # TODO: else case
  if picture.fileName != "":
    # TODO: handle possible error
    discard picture.image.exportImage(picture.fileName.cstring)
    picture.lastWritePos = picture.historyPos

proc draw(picture: Picture; origin: Vec; selected: bool) =
  ## Draws the picture on the screen with its northwest corner at the given point.
  let canvasSize = picture.canvasSize
  drawRectangle(origin, canvasSize, backgroundColor0)
  for t in 0..<canvasSize.x + canvasSize.y:
    if t mod 8 >= 4:
      let xOverlap = max(0, t - canvasSize.x)
      let yOverlap = max(0, t - canvasSize.y)
      drawLine(
        origin + (t - xOverlap, xOverlap),
        origin + (yOverlap, t - yOverlap),
        backgroundColor1,
      )
  drawTexture(
    picture.texture,
    Vector2(x: origin.x.float32, y: origin.y.float32),
    rotation = 0,
    scale = picture.scale.float32,
    tint = White,
  )
  drawRectangleLines(
    origin + picture.scale * picture.cursor, square(picture.scale), Black
  )
  drawRectangleLines(
    origin + picture.scale * picture.cursor + square(1),
    square(picture.scale - 2),
    White,
  )
  if selected:
    drawRectangleLines(origin, canvasSize, White)
  else:
    drawRectangle(origin, canvasSize, Color(a: 64, r: 0, g: 0, b: 0))

iterator layout(
    pictures: openArray[Picture]; pos: Vec; maxSize: Vec; selectedIndex: int32
): (int, Picture, Vec) =
  ## Lays out the given pictures into the given rectangle and yields each picture along with its position.
  ## If the pictures exceed the allowed width, prefers to place the selection at the center of the container.
  let totalSize: Vec =
    (
      x: pictures.mapIt(it.canvasSize.x).sum() + (pictures.len.int32 - 1) * margin,
      y: pictures.mapIt(it.canvasSize.y).max(),
    )
  let selectedPicture = pictures[selectedIndex]
  var origin =
    pos +
      (
        x: (
          if totalSize.x <= maxSize.x: 0'i32
          else:
            let center =
              pictures[0..<selectedIndex].mapIt(it.canvasSize.x).sum() +
                selectedIndex * margin + selectedPicture.scale * selectedPicture.cursor.x +
                selectedPicture.scale div 2
            let halfMax = maxSize.x div 2
            if center <= halfMax: 0
            elif totalSize.x - center <= halfMax:
              maxSize.x - totalSize.x
            else:
              halfMax - center
        ),
        y: (
          if totalSize.y <= maxSize.y: 0'i32
          else:
            let center =
              selectedPicture.scale * selectedPicture.cursor.y +
                selectedPicture.scale div 2
            let halfMax = maxSize.y div 2
            if center <= halfMax: 0
            elif totalSize.y - center <= halfMax:
              maxSize.y - totalSize.y
            else:
              halfMax - center
        ),
      )
  for index, picture in pictures:
    if origin.x + picture.canvasSize.x >= pos.x and origin.x <= pos.x + maxSize.x:
      yield (index, picture, origin)
    origin.x += picture.canvasSize.x + margin

proc selectedPicture(app: App): Picture =
  app.pictures[app.selectedPictureIndex]

proc selectedPalette(app: App): Picture =
  app.palettes[app.selectedPaletteIndex]

proc updateColor(app: App) =
  ## Sets the primary color to the color currently selected in the palette.
  let palette = app.selectedPalette
  app.color = palette.image.getImageColor(palette.cursor.x, palette.cursor.y)

proc ensureNonEmptyPictures(app: App) =
  ## Ensures that the app has at least one picture.
  ## Should be called whenever there is a possibility that the app has no pictures.
  if app.pictures.len == 0:
    app.pictures.add(newPicture())

proc drawStatus(app: App; origin: Vec) =
  drawRectangle(origin, (statusSize, statusSize), app.color)
  drawText(
    app.font,
    cstring($app.mode),
    (origin.x, origin.y + statusSize + margin).toVector2,
    textSize,
    textSpacing,
    White,
  )
  drawText(
    app.font,
    cstring($app.tool.kind),
    (origin.x, origin.y + statusSize + margin + textSize + margin).toVector2,
    textSize,
    textSpacing,
    White,
  )

proc draw(app: App) =
  let screenSize: Vec = (getScreenWidth(), getScreenHeight())
  drawRectangle(square(0), screenSize, Black)
  app.drawStatus((margin, margin))
  block palettes:
    let origin: Vec = (margin + statusSize + margin, margin)
    let maxSize: Vec = (screenSize.x - margin - origin.x, maxPaletteHeight)
    scissorMode(origin.x, origin.y, maxSize.x, maxSize.y):
      for index, palette, origin in layout(
        app.palettes, origin, maxSize, app.selectedPaletteIndex.int32
      ):
        palette.draw(origin, selected = index == app.selectedPaletteIndex)
  block pictures:
    let origin: Vec = (margin, margin + maxPaletteHeight + margin)
    let maxSize: Vec = screenSize - (margin, margin + textSize + margin) - origin
    scissorMode(origin.x, origin.y, maxSize.x, maxSize.y):
      for index, picture, origin in layout(
        app.pictures, origin, maxSize, app.selectedPictureIndex.int32
      ):
        picture.draw(origin, selected = index == app.selectedPictureIndex)
  drawText(
    app.font,
    app.command.cstring,
    (margin, screenSize.y - margin - textSize).toVector2,
    textSize,
    textSpacing,
    White,
  )

proc processKeyboard(app: App) =
  let shift = isKeyDown(LeftShift) or isKeyDown(RightShift)
  let control = isKeyDown(LeftControl) or isKeyDown(RightControl)
  if app.mode == mCommand:
    if isKeyPressed(Escape):
      app.mode = mInject
      app.command = ""
    elif isKeyPressed(Enter):
      app.mode = mInject
      try:
        let res = app.spry.eval("[" & app.command & "]")
        if res.isNil or res of NilVal:
          app.command = ""
        else:
          app.command = $res
      except:
        app.command = getCurrentExceptionMsg()
    elif isKeyPressed(Backspace):
      if app.command.len == 0:
        app.mode = mInject
      else:
        app.command.setLen(app.command.len - 1)
    else:
      while (
        var ch = getCharPressed()
        ch != 0
      ):
        app.command.add(Rune(ch))
  else:
    if isKeyPressed(B):
      app.tool = Tool(kind: tBrush)
    if isKeyPressed(C):
      app.mode = mColor
    if isKeyPressed(F):
      app.tool = Tool(kind: tFlood)
    if isKeyPressed(Q):
      if shift or app.pictures.all(isSaved):
        closeWindow()
        quit(QuitSuccess)
      else:
        app.command = "There are unsaved pictures; use Shift+Q to force quit"
    if isKeyPressed(R):
      if control:
        app.selectedPicture.redo
      else:
        app.tool = Tool(kind: tRect)
    if isKeyPressed(U):
      app.selectedPicture.undo
    if isKeyPressed(V):
      app.mode = mSelect
    if isKeyPressed(Semicolon):
      app.mode = mCommand
      app.command = ""
      discard getCharPressed()
    if isKeyPressed(W):
      if shift:
        app.pictures.apply(write)
      else:
        app.selectedPicture.write()
    if isKeyPressed(Equal):
      if shift:
        app.pictures.apply(zoomIn)
      else:
        app.selectedPicture.zoomIn()
    if isKeyPressed(Minus):
      if shift:
        app.pictures.apply(zoomOut)
      else:
        app.selectedPicture.zoomOut()
    var movement =
      int32(isKeyDown(H)) * (-1'i32, 0'i32) + int32(isKeyDown(J)) * (0'i32, 1'i32) +
        int32(isKeyDown(K)) * (0'i32, -1'i32) + int32(isKeyDown(L)) * (1'i32, 0'i32)
    if movement == square(0):
      app.movementTime = 0
    else:
      if app.movementTime != 0 and app.movementTime < movementTimeThreshold:
        movement = square(0)
      app.movementTime.inc
    case app.mode
    of mInject, mSelect:
      if movement != square(0):
        if control:
          app.selectedPictureIndex =
            clamp(app.selectedPictureIndex + movement.x, 0..app.pictures.high)
        else:
          app.selectedPicture.moveCursor(movement)
          if isKeyDown(Space) and not isKeyPressed(Space):
            app.selectedPicture.dragPixel(
              app.selectedPicture.cursor, app.mode, app.tool, app.color
            )
      if isKeyPressed(Space):
        app.selectedPicture.clickPixel(
          app.selectedPicture.cursor, app.mode, app.tool, app.color
        )
    of mColor:
      if movement != square(0):
        if control:
          app.selectedPictureIndex =
            clamp(app.selectedPictureIndex + movement.x, 0..app.pictures.high)
        else:
          app.selectedPalette.moveCursor(movement)
          app.updateColor()
    of mCommand:
      discard

proc processMouse(app: App) =
  let pos: Vec = (getMouseX(), getMouseY())
  let screenSize: Vec = (getScreenWidth(), getScreenHeight())
  var cursor = MouseCursor.default
  block palettes:
    let origin: Vec = (margin + statusSize + margin, margin)
    let maxSize: Vec = (screenSize.x - margin - origin.x, maxPaletteHeight)
    for index, palette, canvasOrigin in layout(
      app.palettes, origin, maxSize, app.selectedPaletteIndex.int32
    ):
      if pos >= origin and pos >= canvasOrigin and pos < origin + maxSize and
          pos < canvasOrigin + palette.canvasSize:
        cursor = PointingHand
        if isMouseButtonPressed(Left):
          app.selectedPaletteIndex = index
          palette.cursor = (pos - canvasOrigin) div palette.scale
          app.updateColor()
        break
  block pictures:
    let origin: Vec = (margin, margin + maxPaletteHeight + margin)
    let maxSize: Vec = screenSize - (margin, margin + textSize + margin) - origin
    scissorMode(origin.x, origin.y, maxSize.x, maxSize.y):
      for index, picture, canvasOrigin in layout(
        app.pictures, origin, maxSize, app.selectedPictureIndex.int32
      ):
        if pos >= origin and pos >= canvasOrigin and pos < origin + maxSize and
            pos < canvasOrigin + picture.canvasSize:
          cursor = Crosshair
          if isMouseButtonPressed(Left):
            app.selectedPictureIndex = index
            picture.clickPixel(
              (pos - canvasOrigin) div picture.scale, app.mode, app.tool, app.color
            )
          elif isMouseButtonDown(Left):
            # TODO: only do this if the mouse has changed pixel position
            picture.dragPixel(
              (pos - canvasOrigin) div picture.scale, app.mode, app.tool, app.color
            )
          break
  setMouseCursor(cursor)

proc addApi(spry: var spryvm.Interpreter; app: App) =
  ## Adds functions for interacting with the editor to the Spry virtual machine.
  nimFunc("edit"):
    let fileNameNode = spry.evalArg()
    let fileName =
      if fileNameNode of StringVal:
        fileNameNode.StringVal.value
      else:
        raiseRuntimeException("File name not a string: " & $fileNameNode)
        ""
    app.pictures.add(newPicture(fileName))
    app.selectedPictureIndex = app.pictures.high
  nimFunc("e"):
    let fileNameNode = spry.arg()
    let fileName =
      if fileNameNode of Word:
        fileNameNode.Word.word
      elif fileNameNode of StringVal:
        fileNameNode.StringVal.value
      else:
        raiseRuntimeException("File name not a word or string: " & $fileNameNode)
        ""
    app.pictures.add(newPicture(fileName))
    app.selectedPictureIndex = app.pictures.high
  nimFunc("new"):
    app.pictures.add(newPicture())
    app.selectedPictureIndex = app.pictures.high
  nimFunc("resize-nn"):
    let widthNode = spry.evalArg()
    let heightNode = spry.evalArg()
    if widthNode of IntVal and heightNode of IntVal:
      let width = widthNode.IntVal.value.int32
      let height = heightNode.IntVal.value.int32
      app.selectedPicture.image.imageResizeNN(width, height)
      app.selectedPicture.loadTexture()
    else:
      raiseRuntimeException("Dimensions must be integers")
  nimFunc("write"):
    let fileNameNode = spry.evalArg()
    let fileName =
      if fileNameNode of StringVal:
        fileNameNode.StringVal.value
      else:
        raiseRuntimeException("File name not a string: " & $fileNameNode)
        ""
    app.selectedPicture.fileName = fileName
    app.selectedPicture.write()
  nimFunc("w"):
    let fileNameNode = spry.arg()
    let fileName =
      if fileNameNode of Word:
        fileNameNode.Word.word
      elif fileNameNode of StringVal:
        fileNameNode.StringVal.value
      else:
        raiseRuntimeException("File name not a word or string: " & $fileNameNode)
        ""
    app.selectedPicture.fileName = fileName
    app.selectedPicture.write()

proc main() =
  let app = App(spry: spryvm.newInterpreter())
  app.spry.addCore()
  app.spry.addApi(app)
  when defined(release):
    # Hide terminal spam from Raylib
    setTraceLogLevel(Error)
  setConfigFlags(flags(VsyncHint, WindowMaximized, WindowResizable))
  setTargetFPS(fps)
  initWindow(800, 600, "Quadratix")
  app.font = loadFont("assets/fonts/Iosevka-Regular.ttf", textSize, 256)
  app.pictures = commandLineParams().map(newPicture)
  app.ensureNonEmptyPictures()
  app.palettes = @[Picture(image: colar, scale: 12)]
  app.palettes.apply(loadTexture)
  app.updateColor()
  while true:
    app.processKeyboard()
    app.processMouse()
    drawing:
      app.draw()

main()
