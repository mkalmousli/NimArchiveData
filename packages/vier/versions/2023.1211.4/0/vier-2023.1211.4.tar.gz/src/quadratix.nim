# © 2023 Adam Blažek <blazead5@cvut.cz>
# SPDX-License-Identifier: GPL-3.0-or-later

import ./palettes
import ./vector
import pkg/raylib
import std/cmdline
import std/sets
import std/sugar

type
  Mode = enum
    mPaint = "Paint"
    mColor = "Color"
    mFlood = "Flood"
  PixelChange = object
    pos: Vec
    originalColor: Color
    newColor: Color
  ImageChange = object
    pixelChanges: seq[PixelChange]
  Picture = ref object
    image: Image
    texture: Texture
    cursor: Vec
    scale: int32
    history: seq[ImageChange]
    historyPos: int
  App = object
    mode: Mode
    palettes: seq[Picture]
    pictures: seq[Picture]
    selectedPaletteIndex: int
    selectedPictureIndex: int
    color: Color
    movementTime: int

const
  fps = 30'i32
  margin = 8'i32
  backgroundColor0 = Color(a: 255, r: 85, g: 85, b: 85)
  backgroundColor1 = Color(a: 255, r: 170, g: 170, b: 170)
  movementTimeThreshold = fps div 3

proc loadTexture(picture: Picture) =
  picture.texture = loadTextureFromImage(picture.image)

proc updateTexture(picture: Picture) =
  picture.texture.updateTexture(picture.image.loadImageColors().toOpenArray())

proc moveCursor(picture: Picture, movement: Vec) =
  picture.cursor += movement
  if picture.cursor.x < 0:
    picture.cursor.x = 0
  elif picture.cursor.x > picture.image.width - 1:
    picture.cursor.x = picture.image.width - 1
  if picture.cursor.y < 0:
    picture.cursor.y = 0
  elif picture.cursor.y > picture.image.height - 1:
    picture.cursor.y = picture.image.height - 1

proc add(picture: Picture, change: ImageChange) =
  picture.history.setLen(picture.historyPos)
  picture.history.add(change)
  picture.historyPos.inc

proc apply(picture: Picture, change: PixelChange) =
  picture.image.imageDrawPixel(change.pos.x, change.pos.y, change.newColor)

proc apply(picture: Picture, change: ImageChange) =
  for pixelChange in change.pixelChanges:
    picture.apply(pixelChange)
  picture.updateTexture()

proc distance(x, y: Color): int32 =
  abs(x.r.int32 - y.r.int32) + abs(x.g.int32 - y.g.int32) + abs(x.b.int32 - y.b.int32)

proc flood(picture: Picture, target: Vec, color: Color, tolerance: int32) =
  var stack = @[target]
  var toChange = initHashSet[Vec]()
  while stack.len != 0:
    let pos = stack.pop
    if pos in toChange: continue
    let currentColor = picture.image.getImageColor(pos.x, pos.y)
    toChange.incl(pos)
    template check(x, y: int) =
      if distance(picture.image.getImageColor(x, y), currentColor) <= tolerance:
        stack.add((x, y))
    if pos.x > 0: check(pos.x - 1, pos.y)
    if pos.x < picture.image.width - 1: check(pos.x + 1, pos.y)
    if pos.y > 0: check(pos.x, pos.y - 1)
    if pos.y < picture.image.height - 1: check(pos.x, pos.y + 1)
  let change = ImageChange(pixelChanges: collect(for pos in toChange: PixelChange(
    pos: pos,
    originalColor: picture.image.getImageColor(pos.x, pos.y),
    newColor: color,
  )))
  picture.add(change)
  picture.apply(change)

proc clickPixel(picture: Picture, target: Vec, mode: Mode, color: Color) =
  case mode
  of mPaint:
    let originalColor = picture.image.getImageColor(target.x, target.y)
    picture.add(ImageChange(pixelChanges: @[PixelChange(pos: target, originalColor: originalColor, newColor: color)]))
    imageDrawPixel(picture.image, target.x, target.y, color)
    picture.updateTexture() # TODO: optimize so that only the pixel is updated
  of mColor:
    discard
  of mFlood:
    picture.flood(target, color, 0)

proc dragPixel(picture: Picture, target: Vec, mode: Mode, color: Color) =
  case mode
  of mPaint:
    let originalColor = picture.image.getImageColor(target.x, target.y)
    if originalColor != color:
      picture.history[^1].pixelChanges.add(PixelChange(pos: target, originalColor: originalColor, newColor: color))
      imageDrawPixel(picture.image, target.x, target.y, color)
      picture.updateTexture() # TODO: optimize so that only the pixel is updated
  of mColor, mFlood:
    discard

proc undo(picture: Picture, change: PixelChange) =
  picture.image.imageDrawPixel(change.pos.x, change.pos.y, change.originalColor)

proc undo(picture: Picture, change: ImageChange) =
  for pixelChange in change.pixelChanges:
    picture.undo(pixelChange)
  picture.updateTexture()

proc undo(picture: Picture) =
  if picture.historyPos > 0:
    picture.historyPos.dec
    picture.undo(picture.history[picture.historyPos])

proc redo(picture: Picture) =
  if picture.historyPos < picture.history.len:
    picture.apply(picture.history[picture.historyPos])
    picture.historyPos.inc

proc draw(picture: Picture, origin: var Vec) =
  let canvasSize = picture.scale * picture.image.size
  drawRectangle(origin, canvasSize, backgroundColor0)
  for t in 0 ..< canvasSize.x + canvasSize.y:
    if t mod 8 >= 4:
      let xOverlap = max(0, t - canvasSize.x)
      let yOverlap = max(0, t - canvasSize.y)
      drawLine(origin + (t - xOverlap, xOverlap), origin + (yOverlap, t - yOverlap), backgroundColor1)
  drawTexture(picture.texture, Vector2(x: origin.x.float32, y: origin.y.float32), rotation = 0, scale = picture.scale.float32, tint = White)
  drawRectangleLines(origin + picture.scale * picture.cursor, square(picture.scale), Black)
  drawRectangleLines(origin + picture.scale * picture.cursor + square(1), square(picture.scale - 2), White)
  origin.x += picture.scale * picture.image.width + margin

proc selectedPicture(app: App): Picture =
  app.pictures[app.selectedPictureIndex]

proc selectedPalette(app: App): Picture =
  app.palettes[app.selectedPaletteIndex]

proc updateColor(app: var App) =
  let palette = app.selectedPalette
  app.color = palette.image.getImageColor(palette.cursor.x, palette.cursor.y)

proc ensureNonEmptyPictures(app: var App) =
  if app.pictures.len == 0:
    let picture = Picture(image: genImageColor(16, 16, Blank), scale: 16)
    picture.loadTexture()
    app.pictures.add(picture)

proc drawStatus(app: App, origin: var Vec) =
  const size = 64'i32
  drawRectangle(origin, (size, size), app.color)
  drawText(cstring($app.mode), origin.x, origin.y + size + margin, 24, White)
  origin.x += size + margin

proc draw(app: App) =
  drawRectangle(0, 0, getScreenWidth(), getScreenHeight(), Black)
  var origin = (margin, margin)
  app.drawStatus(origin)
  for palette in app.palettes:
    palette.draw(origin)
  origin = (8, 158)
  for picture in app.pictures:
    picture.draw(origin)

proc processKeyboard(app: var App) =
  if isKeyPressed(P):
    app.mode = mPaint
  if isKeyPressed(C):
    app.mode = mColor
  if isKeyPressed(F):
    app.mode = mFlood
  if isKeyPressed(U):
    app.selectedPicture.undo
  if isKeyPressed(R):
    app.selectedPicture.redo
  var movement =
    int32(isKeyDown(H)) * (-1'i32, 0'i32) +
    int32(isKeyDown(J)) * (0'i32, 1'i32) +
    int32(isKeyDown(K)) * (0'i32, -1'i32) +
    int32(isKeyDown(L)) * (1'i32, 0'i32)
  if movement == square(0):
    app.movementTime = 0
  else:
    if app.movementTime != 0 and app.movementTime < movementTimeThreshold:
      movement = square(0)
    app.movementTime.inc
  case app.mode
  of mPaint, mFlood:
    if movement != square(0):
      app.selectedPicture.moveCursor(movement)
    if isKeyPressed(Space):
      app.selectedPicture.clickPixel(app.selectedPicture.cursor, app.mode, app.color)
    elif isKeyDown(Space) and movement != square(0):
      app.selectedPicture.dragPixel(app.selectedPicture.cursor, app.mode, app.color)
  of mColor:
    if movement != square(0):
      app.selectedPalette.moveCursor(movement)
      app.updateColor()

proc main() =
  var app = App()
  when defined(release):
    setTraceLogLevel(Error)
  setConfigFlags(flags(WindowMaximized, WindowResizable))
  setTargetFPS(fps)
  initWindow(800, 600, "Quadratix")
  app.palettes = @[Picture(image: colar, scale: 12)]
  app.pictures = collect:
    for fileName in commandLineParams():
      Picture(
        image: loadImage(fileName),
        scale: 8,
      )
  app.ensureNonEmptyPictures()
  for palette in app.palettes.mitems:
    palette.loadTexture()
  for picture in app.pictures.mitems:
    picture.loadTexture()
  app.updateColor()
  while not windowShouldClose():
    app.processKeyboard()
    drawing:
      app.draw()

main()
