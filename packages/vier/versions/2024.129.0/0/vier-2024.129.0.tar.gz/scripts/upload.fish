#!/usr/bin/env fish
tar -cvz -C website . -f site.tar.gz
hut pages publish -d xigoi.srht.site -s vier site.tar.gz
rm site.tar.gz
