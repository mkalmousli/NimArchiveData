# © 2023 Adam Blažek <blazead5@cvut.cz>
# SPDX-License-Identifier: GPL-3.0-or-later

version       = "2023.1212.1"
author        = "Adam Blažek"
description   = "Pixel art editor"
license       = "GPL-3.0-or-later"
srcDir        = "src"
bin           = @["quadratix"]

requires "nim >= 2.0.0"

requires "naylib"
