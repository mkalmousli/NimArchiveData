# © 2023 Adam Blažek <blazead5@cvut.cz>
# SPDX-License-Identifier: GPL-3.0-or-later

import ./palettes
import ./vector
import pkg/raylib
import std/cmdline
import std/math
import std/sequtils
import std/sets
import std/sugar

type
  Mode = enum
    mPaint = "Paint"
    mColor = "Color"
    mFlood = "Flood"
  PixelChange = object
    pos: Vec
    originalColor: Color
    newColor: Color
  ImageChange = object
    pixelChanges: seq[PixelChange]
  Picture = ref object
    image: Image
    texture: Texture
    fileName: string
    cursor: Vec
    scale: int32
    history: seq[ImageChange]
    historyPos: int
  App = object
    mode: Mode
    palettes: seq[Picture]
    pictures: seq[Picture]
    selectedPaletteIndex: int
    selectedPictureIndex: int
    color: Color
    movementTime: int

const
  fps = 60'i32
  margin = 4'i32
  backgroundColor0 = Color(a: 255, r: 85, g: 85, b: 85)
  backgroundColor1 = Color(a: 255, r: 170, g: 170, b: 170)
  movementTimeThreshold = fps div 3
  statusSize = 64'i32
  maxPaletteHeight = 156'i32

proc canvasSize(picture: Picture): Vec =
  picture.scale * picture.image.size

proc loadTexture(picture: Picture) =
  picture.texture = loadTextureFromImage(picture.image)

proc updateTexture(picture: Picture) =
  picture.texture.updateTexture(picture.image.loadImageColors().toOpenArray())

proc moveCursor(picture: Picture, movement: Vec) =
  picture.cursor.x = clamp(picture.cursor.x + movement.x, 0'i32 ..< picture.image.width)
  picture.cursor.y = clamp(picture.cursor.y + movement.y, 0'i32 ..< picture.image.height)

proc add(picture: Picture, change: ImageChange) =
  picture.history.setLen(picture.historyPos)
  picture.history.add(change)
  picture.historyPos.inc

proc apply(picture: Picture, change: PixelChange) =
  picture.image.imageDrawPixel(change.pos.x, change.pos.y, change.newColor)

proc apply(picture: Picture, change: ImageChange) =
  for pixelChange in change.pixelChanges:
    picture.apply(pixelChange)
  picture.updateTexture()

proc distance(x, y: Color): int32 =
  abs(x.r.int32 - y.r.int32) + abs(x.g.int32 - y.g.int32) + abs(x.b.int32 - y.b.int32)

proc flood(picture: Picture, target: Vec, color: Color, tolerance: int32) =
  var stack = @[target]
  var toChange = initHashSet[Vec]()
  while stack.len != 0:
    let pos = stack.pop
    if pos in toChange: continue
    let currentColor = picture.image.getImageColor(pos.x, pos.y)
    toChange.incl(pos)
    template check(x, y: int) =
      if distance(picture.image.getImageColor(x, y), currentColor) <= tolerance:
        stack.add((x, y))
    if pos.x > 0: check(pos.x - 1, pos.y)
    if pos.x < picture.image.width - 1: check(pos.x + 1, pos.y)
    if pos.y > 0: check(pos.x, pos.y - 1)
    if pos.y < picture.image.height - 1: check(pos.x, pos.y + 1)
  let change = ImageChange(pixelChanges: collect(for pos in toChange: PixelChange(
    pos: pos,
    originalColor: picture.image.getImageColor(pos.x, pos.y),
    newColor: color,
  )))
  picture.add(change)
  picture.apply(change)

proc clickPixel(picture: Picture, target: Vec, mode: Mode, color: Color) =
  case mode
  of mPaint:
    let originalColor = picture.image.getImageColor(target.x, target.y)
    picture.add(ImageChange(pixelChanges: @[PixelChange(pos: target, originalColor: originalColor, newColor: color)]))
    imageDrawPixel(picture.image, target.x, target.y, color)
    picture.updateTexture() # TODO: optimize so that only the pixel is updated
  of mColor:
    discard
  of mFlood:
    picture.flood(target, color, 0)

proc dragPixel(picture: Picture, target: Vec, mode: Mode, color: Color) =
  case mode
  of mPaint:
    let originalColor = picture.image.getImageColor(target.x, target.y)
    if originalColor != color:
      picture.history[^1].pixelChanges.add(PixelChange(pos: target, originalColor: originalColor, newColor: color))
      imageDrawPixel(picture.image, target.x, target.y, color)
      picture.updateTexture() # TODO: optimize so that only the pixel is updated
  of mColor, mFlood:
    discard

proc undo(picture: Picture, change: PixelChange) =
  picture.image.imageDrawPixel(change.pos.x, change.pos.y, change.originalColor)

proc undo(picture: Picture, change: ImageChange) =
  for pixelChange in change.pixelChanges:
    picture.undo(pixelChange)
  picture.updateTexture()

proc undo(picture: Picture) =
  if picture.historyPos > 0:
    picture.historyPos.dec
    picture.undo(picture.history[picture.historyPos])

proc redo(picture: Picture) =
  if picture.historyPos < picture.history.len:
    picture.apply(picture.history[picture.historyPos])
    picture.historyPos.inc

proc write(picture: Picture) =
  # TODO: else case
  if picture.fileName != "":
    # TODO: handle possible error
    discard picture.image.exportImage(picture.fileName.cstring)

proc draw(picture: Picture, origin: Vec, selected: bool) =
  let canvasSize = picture.canvasSize
  drawRectangle(origin, canvasSize, backgroundColor0)
  for t in 0 ..< canvasSize.x + canvasSize.y:
    if t mod 8 >= 4:
      let xOverlap = max(0, t - canvasSize.x)
      let yOverlap = max(0, t - canvasSize.y)
      drawLine(origin + (t - xOverlap, xOverlap), origin + (yOverlap, t - yOverlap), backgroundColor1)
  drawTexture(picture.texture, Vector2(x: origin.x.float32, y: origin.y.float32), rotation = 0, scale = picture.scale.float32, tint = White)
  drawRectangleLines(origin + picture.scale * picture.cursor, square(picture.scale), Black)
  drawRectangleLines(origin + picture.scale * picture.cursor + square(1), square(picture.scale - 2), White)
  if selected:
    drawRectangleLines(origin, canvasSize, White)
  else:
    drawRectangle(origin, canvasSize, Color(a: 64, r: 0, g: 0, b: 0))

iterator layout(pictures: openArray[Picture], pos: Vec, maxSize: Vec, selectedIndex: int32): (int, Picture, Vec) =
  ## Lay out the given pictures into the given rectangle and yield each picture along with its position
  let totalSize: Vec = (
    x: pictures.mapIt(it.canvasSize.x).sum() + (pictures.len.int32 - 1) * margin,
    y: pictures.mapIt(it.canvasSize.y).max(),
  )
  let selectedPicture = pictures[selectedIndex]
  var origin = pos + (
    x: (
      if totalSize.x <= maxSize.x: 0'i32
      else:
        let center = pictures[0 ..< selectedIndex].mapIt(it.canvasSize.x).sum() + selectedIndex * margin +
          selectedPicture.scale * selectedPicture.cursor.x + selectedPicture.scale div 2
        let halfMax = maxSize.x div 2
        if center <= halfMax: 0
        elif totalSize.x - center <= halfMax: maxSize.x - totalSize.x
        else: halfMax - center
    ),
    y: (
      if totalSize.y <= maxSize.y: 0'i32
      else:
        let center = selectedPicture.scale * selectedPicture.cursor.y + selectedPicture.scale div 2
        let halfMax = maxSize.y div 2
        if center <= halfMax: 0
        elif totalSize.y - center <= halfMax: maxSize.y - totalSize.y
        else: halfMax - center
    ),
  )
  for index, picture in pictures:
    if origin.x + picture.canvasSize.x >= pos.x and origin.x <= pos.x + maxSize.x:
      yield (index, picture, origin)
    origin.x += picture.canvasSize.x + margin

proc selectedPicture(app: App): Picture =
  app.pictures[app.selectedPictureIndex]

proc selectedPalette(app: App): Picture =
  app.palettes[app.selectedPaletteIndex]

proc updateColor(app: var App) =
  let palette = app.selectedPalette
  app.color = palette.image.getImageColor(palette.cursor.x, palette.cursor.y)

proc ensureNonEmptyPictures(app: var App) =
  if app.pictures.len == 0:
    let picture = Picture(image: genImageColor(16, 16, Blank), scale: 16)
    picture.loadTexture()
    app.pictures.add(picture)

proc drawStatus(app: App, origin: Vec) =
  drawRectangle(origin, (statusSize, statusSize), app.color)
  drawText(cstring($app.mode), origin.x, origin.y + statusSize + margin, 24, White)

proc draw(app: App) =
  let screenSize: Vec = (getScreenWidth(), getScreenHeight())
  drawRectangle(square(0), screenSize, Black)
  app.drawStatus((margin, margin))
  block palettes:
    let origin: Vec = (margin + statusSize + margin, margin)
    let maxSize: Vec = (screenSize.x - margin - origin.x, maxPaletteHeight)
    scissorMode(origin.x, origin.y, maxSize.x, maxSize.y):
      for index, palette, origin in layout(app.palettes, origin, maxSize, app.selectedPaletteIndex.int32):
        palette.draw(origin, selected = index == app.selectedPaletteIndex)
  block pictures:
    let origin: Vec = (margin, margin + maxPaletteHeight + margin)
    let maxSize: Vec = screenSize - square(margin) - origin
    scissorMode(origin.x, origin.y, maxSize.x, maxSize.y):
      for index, picture, origin in layout(app.pictures, origin, maxSize, app.selectedPictureIndex.int32):
        picture.draw(origin, selected = index == app.selectedPictureIndex)

proc processKeyboard(app: var App) =
  if isKeyPressed(P):
    app.mode = mPaint
  if isKeyPressed(C):
    app.mode = mColor
  if isKeyPressed(F):
    app.mode = mFlood
  if isKeyPressed(U):
    app.selectedPicture.undo
  if isKeyPressed(R):
    app.selectedPicture.redo
  if isKeyPressed(W):
    if isKeyDown(LeftShift) or isKeyDown(RightShift):
      for picture in app.pictures:
        picture.write()
    else:
      app.selectedPicture.write()
  var movement =
    int32(isKeyDown(H)) * (-1'i32, 0'i32) +
    int32(isKeyDown(J)) * (0'i32, 1'i32) +
    int32(isKeyDown(K)) * (0'i32, -1'i32) +
    int32(isKeyDown(L)) * (1'i32, 0'i32)
  if movement == square(0):
    app.movementTime = 0
  else:
    if app.movementTime != 0 and app.movementTime < movementTimeThreshold:
      movement = square(0)
    app.movementTime.inc
  case app.mode
  of mPaint, mFlood:
    if movement != square(0):
      if isKeyDown(LeftControl) or isKeyDown(RightControl):
        app.selectedPictureIndex = clamp(app.selectedPictureIndex + movement.x, 0 .. app.pictures.high)
      else:
        app.selectedPicture.moveCursor(movement)
        if isKeyDown(Space) and not isKeyPressed(Space):
          app.selectedPicture.dragPixel(app.selectedPicture.cursor, app.mode, app.color)
    if isKeyPressed(Space):
      app.selectedPicture.clickPixel(app.selectedPicture.cursor, app.mode, app.color)
  of mColor:
    if movement != square(0):
      if isKeyDown(LeftControl) or isKeyDown(RightControl):
        app.selectedPictureIndex = clamp(app.selectedPictureIndex + movement.x, 0 .. app.pictures.high)
      else:
        app.selectedPalette.moveCursor(movement)
        app.updateColor()

proc processMouse(app: var App) =
  let pos: Vec = (getMouseX(), getMouseY())
  let screenSize: Vec = (getScreenWidth(), getScreenHeight())
  var cursor = MouseCursor.default
  block palettes:
    let origin: Vec = (margin + statusSize + margin, margin)
    let maxSize: Vec = (screenSize.x - margin - origin.x, maxPaletteHeight)
    for index, palette, canvasOrigin in layout(app.palettes, origin, maxSize, app.selectedPaletteIndex.int32):
      if pos >= origin and pos >= canvasOrigin and pos < origin + maxSize and pos < canvasOrigin + palette.canvasSize:
        cursor = PointingHand
        if isMouseButtonPressed(Left):
          app.selectedPaletteIndex = index
          palette.cursor = (pos - canvasOrigin) div palette.scale
          app.updateColor()
        break
  block pictures:
    let origin: Vec = (margin, margin + maxPaletteHeight + margin)
    let maxSize: Vec = screenSize - square(margin) - origin
    scissorMode(origin.x, origin.y, maxSize.x, maxSize.y):
      for index, picture, canvasOrigin in layout(app.pictures, origin, maxSize, app.selectedPictureIndex.int32):
        if pos >= origin and pos >= canvasOrigin and pos < origin + maxSize and pos < canvasOrigin + picture.canvasSize:
          cursor = Crosshair
          if isMouseButtonPressed(Left):
            app.selectedPictureIndex = index
            picture.clickPixel((pos - canvasOrigin) div picture.scale, app.mode, app.color)
          elif isMouseButtonDown(Left):
            picture.dragPixel((pos - canvasOrigin) div picture.scale, app.mode, app.color)
          break
  setMouseCursor(cursor)

proc main() =
  var app = App()
  when defined(release):
    setTraceLogLevel(Error)
  setConfigFlags(flags(VsyncHint, WindowMaximized, WindowResizable))
  setTargetFPS(fps)
  initWindow(800, 600, "Quadratix")
  app.palettes = @[Picture(image: colar, scale: 12)]
  app.pictures = collect:
    for fileName in commandLineParams():
      Picture(
        image: loadImage(fileName),
        fileName: fileName,
        scale: 8,
      )
  for palette in app.palettes.mitems:
    palette.loadTexture()
  for picture in app.pictures.mitems:
    picture.loadTexture()
  app.ensureNonEmptyPictures()
  app.updateColor()
  while not windowShouldClose():
    app.processKeyboard()
    app.processMouse()
    drawing:
      app.draw()

main()
