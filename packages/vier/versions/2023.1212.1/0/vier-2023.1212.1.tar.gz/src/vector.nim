# © 2023 Adam Blažek <blazead5@cvut.cz>
# SPDX-License-Identifier: GPL-3.0-or-later

import pkg/raylib

type
  Vec* = tuple
    x: int32
    y: int32

proc `+`*(u, v: Vec): Vec =
  (u.x + v.x, u.y + v.y)

proc `-`*(u, v: Vec): Vec =
  (u.x - v.x, u.y - v.y)

proc `*`*(n: int32, u: Vec): Vec =
  (n * u.x, n * u.y)

proc `div`*(u: Vec, n: int32): Vec =
  (u.x div n, u.y div n)

proc `+=`*(u: var Vec, v: Vec) =
  u.x += v.x
  u.y += v.y

proc `-=`*(u: var Vec, v: Vec) =
  u.x -= v.x
  u.y -= v.y

proc `*=`*(u: var Vec, n: int32) =
  u.x *= n
  u.y *= n

proc `<`*(u, v: Vec): bool =
  u.x < v.x and u.y < v.y

proc `<=`*(u, v: Vec): bool =
  u.x <= v.x and u.y <= v.y

proc `>`*(u, v: Vec): bool =
  u.x > v.x and u.y > v.y

proc `>=`*(u, v: Vec): bool =
  u.x >= v.x and u.y >= v.y

proc square*(n: int32): Vec =
  (n, n)

proc drawRectangle*(position, size: Vec, color: Color) =
  drawRectangle(position.x, position.y, size.x, size.y, color)

proc drawRectangleLines*(position, size: Vec, color: Color) =
  drawRectangleLines(position.x, position.y, size.x, size.y, color)

proc drawLine*(startPos, endPos: Vec, color: Color) =
  drawLine(startPos.x, startPos.y, endPos.x, endPos.y, color)

proc size*(image: Image): Vec =
  (image.width, image.height)
