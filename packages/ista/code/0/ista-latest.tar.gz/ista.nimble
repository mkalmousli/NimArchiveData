# Package

version       = "0.1.0"
author        = "M"
description   = "Ista - A versatile command line speed reader to enhance your reading efficiency"
license       = "GPL-2.0"
srcDir        = "src"
binDir        = "bin"
bin           = @["ista"]


# Dependencies

requires "nim >= 2.2.0"

requires "therapist#HEAD"