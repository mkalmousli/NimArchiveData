import std/[os, strutils, terminal, monotimes, times]
import ista/[cli]

type
  IstaConfig = ref object
    wpm: int
    focus: bool
    chunk: int

proc clearLine() =
  stdout.write("\r" & repeat(" ", 80) & "\r")
  stdout.flushFile()

proc getOrp(word: string): int =
  let len = word.len
  if len <= 1: return 0
  if len <= 5: return len div 2
  if len <= 9: return len div 2
  return (len div 2) - 1

proc renderWord(word: string, config: IstaConfig) =
  clearLine()
  
  if config.focus and word.len > 1:
    let orp = getOrp(word)
    let before = word[0..<orp]
    let focus = word[orp]
    let after = if orp + 1 < word.len: word[(orp + 1)..^1] else: ""
    
    let width = 40
    let leftPad = width - (word.len div 2)
    
    stdout.write(repeat(" ", leftPad))
    stdout.write(before)
    stdout.styledWrite(fgRed, styleBright, $focus)
    stdout.write(after)
  else:
    let width = 40
    let leftPad = width - (word.len div 2)
    stdout.write(repeat(" ", leftPad) & word)
  
  stdout.flushFile()

proc readText(text: string, config: IstaConfig) =
  let words = text.split()
  let delay = (60000 div (config.wpm * config.chunk)).int
  
  hideCursor()
  defer: showCursor()
  
  echo "\nStarting in 3 seconds... (Press Ctrl+C to stop)"
  echo "Reading at ", config.wpm, " WPM"
  echo repeat("=", 80) & "\n"
  sleep(3000)
  
  var i = 0
  while i < words.len:
    var chunk = ""
    for j in 0..<config.chunk:
      if i + j < words.len:
        if j > 0: chunk.add(" ")
        chunk.add(words[i + j])
    
    let startTime = getMonoTime()

    renderWord(chunk, config)

    let elapsed =
      (getMonoTime() - startTime).inMilliseconds().int

    let remaining = delay - elapsed
    if remaining > 0:
      sleep(remaining)

    i += config.chunk
  
  clearLine()
  echo "\n\n" & repeat("=", 80)
  echo "Finished!"

proc main() =
  var config = IstaConfig()
  
  spec.parseOrHelp("Ista - A versatile command line speed reader to enhance your reading efficiency")

  config.wpm = spec.wpm.value
  config.focus = not spec.focus.seen
  config.chunk = spec.chunk.value
  
  var text: string
  if spec.file.value != "":
    text = readFile(spec.file.value)
  else:
    text = stdin.readAll()
  
  if text.strip().len == 0:
    echo "Error: No text to read"
    echo spec.renderHelp("Ista - A versatile command line speed reader to enhance your reading efficiency")
    return
  
  # Start reading
  readText(text, config)

when isMainModule:
  main()