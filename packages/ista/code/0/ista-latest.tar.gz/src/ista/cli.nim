import therapist; export therapist
import strutils

const versionNum* = staticRead("../../ista.nimble").splitLines()[2].split("=")[1].strip().replace("\"", "")

const release = defined(release)
var build = if release: "release" else: "debug"

let spec* = (
  file: newFileArg(@["<file>"], help="The file to read (reads from stdin if not provided)", optional = true),
  wpm: newIntArg(@["-w", "--wpm"], help="Words per minute", optional = true, defaultVal = 300),
  chunk: newIntArg(@["-c", "--chunk"], help="Number of words to display at once", optional = true, defaultVal = 1),
  focus: newFlagArg(@["-f", "--no-focus"], help="Disable focus highlighting"),
  version: newMessageArg(@["--version", "-v"], "Ista v$#\nBuild: $#" % @[versionNum, $build], help = "Show version information"),  
  help: newHelpArg(@["-h", "--help"])
)