import std/[httpclient, json, base64, os, strutils, md5]
import cligen
import dotenv

func nimbleValue(content, key: string): string =
  for line in content.splitLines:
    if line.startsWith(key):
      return line.split("=")[1].strip().strip(chars = {'"'})

const Version = nimbleValue(staticRead("../lxprs.nimble"), "version")

const
  BaseUrl = "https://api.letterxpress.de/v3/"
  ExitUsage = 2
  ExitConfig = 3
  ExitNotFound = 4
  ExitApi = 5

type
  LetterType = enum
    ltRegular = "regular"
    ltEinwurf = "einwurf" # Einwurf-Einschreiben (r1)
    ltPersoenlich = "persoenlich" # Persönliches Einschreiben (r2)

  JobFilter = enum
    jfAll = "all"
    jfQueue = "queue"
    jfHold = "hold"
    jfDone = "done"
    jfCanceled = "canceled"
    jfDraft = "draft"

proc die(msg: string, code: int) {.noreturn.} =
  stderr.writeLine msg
  quit code

proc getAuth(envFile: string): JsonNode =
  if fileExists(envFile):
    dotenv.load(filename = envFile)
  let user = getEnv("LETTERXPRESS_USER")
  let key = getEnv("LETTERXPRESS_KEY")
  if user == "":
    die "LETTERXPRESS_USER not set", ExitConfig
  if key == "":
    die "LETTERXPRESS_KEY not set", ExitConfig
  let sandbox = getEnv("LETTERXPRESS_SANDBOX", "0") == "1"
  %*{
    "username": user,
    "apikey": key,
    "mode": if sandbox: "test" else: "live"
  }

proc apiRequest(httpMethod: HttpMethod, endpoint: string, body: JsonNode): JsonNode =
  let client = newHttpClient()
  client.headers = newHttpHeaders({"Content-Type": "application/json"})
  try:
    let resp = client.request(BaseUrl & endpoint, httpMethod = httpMethod, body = $body)
    result = parseJson(resp.body)
  except CatchableError as e:
    die e.msg, ExitApi
  let status = result{"status"}.getInt
  if status != 200:
    die result{"message"}.getStr("request failed"),
        (if status == 404: ExitNotFound else: ExitApi)

proc authRequest(httpMethod: HttpMethod, endpoint, envFile: string): JsonNode =
  apiRequest(httpMethod, endpoint, %*{"auth": getAuth(envFile)})

proc letter(
    pdf: string,
    letterType: LetterType = ltRegular,
    color: bool = false,
    duplex: bool = false,
    international: bool = false,
    env: string = ".env"
  ): int =
  ## Send a PDF letter via LetterXpress
  if not fileExists(pdf):
    die "file not found: " & pdf, ExitNotFound
  if not pdf.toLowerAscii.endsWith(".pdf"):
    die "not a PDF: " & pdf, ExitUsage

  let pdfBase64 = encode(readFile(pdf))
  var spec = %*{
    "color": if color: "4" else: "1",
    "mode": if duplex: "duplex" else: "simplex",
    "shipping": if international: "international" else: "national"
  }
  case letterType
  of ltEinwurf: spec["registered"] = %"r1"
  of ltPersoenlich: spec["registered"] = %"r2"
  of ltRegular: discard

  let body = %*{
    "auth": getAuth(env),
    "letter": {
      "base64_file": pdfBase64,
      "base64_file_checksum": $toMD5(pdfBase64),
      "specification": spec
    }
  }
  let resp = apiRequest(HttpPost, "printjobs", body)
  echo resp{"data", "id"}.getInt

proc balance(env: string = ".env"): int =
  ## Show account balance
  let resp = authRequest(HttpGet, "balance", env)
  echo formatFloat(resp{"data", "balance"}.getFloat, ffDecimal, 2), " ",
       resp{"data", "currency"}.getStr("EUR")

proc jobs(filter: JobFilter = jfAll, env: string = ".env"): int =
  ## List print jobs from the Postausgangsbuch
  let endpoint = if filter == jfAll: "printjobs" else: "printjobs?filter=" & $filter
  let resp = authRequest(HttpGet, endpoint, env)
  for job in resp{"data", "printjobs"}.getElems:
    let items = job{"items"}.getElems
    var amount = 0.0
    for item in items:
      amount += item{"amount"}.getFloat
    var address = if items.len > 0: items[0]{"address"}.getStr else: ""
    if items.len > 1:
      address &= " (+" & $(items.len - 1) & ")"
    echo @[
      $job{"id"}.getInt,
      job{"created_at"}.getStr,
      job{"status"}.getStr,
      formatFloat(amount, ffDecimal, 2),
      address,
      job{"filename_original"}.getStr
    ].join("\t")

proc job(id: seq[int] = @[], env: string = ".env"): int =
  ## Show details of a print job
  if id.len == 0:
    die "specify a job id", ExitUsage
  let data = authRequest(HttpGet, "printjobs/" & $id[0], env){"data"}
  echo "id: ", data{"id"}.getInt
  for field in ["status", "created_at", "updated_at", "shipping", "mode", "color",
                "registered", "dispatch_date", "filename_original", "notice"]:
    let v = data{field}.getStr
    if v != "":
      echo field, ": ", v
  for i, item in data{"items"}.getElems:
    if i > 0: echo "---"
    echo "address: ", item{"address"}.getStr
    echo "pages: ", item{"pages"}.getInt
    echo "amount: ", formatFloat(item{"amount"}.getFloat, ffDecimal, 2)
    echo "item_status: ", item{"status"}.getStr

proc cancel(id: seq[int] = @[], env: string = ".env"): int =
  ## Cancel a print job
  ##
  ## Only possible within 15 minutes of submission, and not once the job
  ## has reached status "done".
  if id.len == 0:
    die "specify a job id", ExitUsage
  discard authRequest(HttpDelete, "printjobs/" & $id[0], env)

proc version(): int =
  ## Show version
  echo "lxprs ", Version

when isMainModule:
  dispatchMulti(
    [letter, help = {
      "pdf": "PDF file to send",
      "letterType": "regular, einwurf (Einwurf-Einschreiben), persoenlich (Persönliches Einschreiben)",
      "color": "Print in color (default: black/white)",
      "duplex": "Print double-sided (default: single-sided)",
      "international": "International shipping (default: national)",
      "env": "Path to .env config file"
    }],
    [balance, help = {
      "env": "Path to .env config file"
    }],
    [jobs, help = {
      "filter": "all, queue, hold, done, canceled, draft",
      "env": "Path to .env config file"
    }],
    [job, help = {
      "id": "Job ID",
      "env": "Path to .env config file"
    }, positional = "id"],
    [cancel, help = {
      "id": "Job ID",
      "env": "Path to .env config file"
    }, positional = "id"],
    [version]
  )
