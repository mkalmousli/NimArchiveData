version       = "0.1.1"
author        = "capocasa"
description   = "LetterXpress client for sending German postal letters from PDF"
license       = "MIT"
srcDir        = "src"
bin           = @["lxprs"]

requires "nim >= 2.0.0"
requires "cligen"
requires "dotenv"
