

import packages/docutils/highlite
import strutils

proc getClass(op: TokenClass): string = 
  case op
  of gtKeyword: return $op & " keyword control"
  of gtIdentifier: return $op & " keyword2 other common function"
  of gtStringLit: return $op & " string quoted double"
  of gtPunctuation: return $op & " white"
  of gtDecNumber: return $op & " constant numeric integer decimal"
  else: return $op

proc spanify(s: string, op: TokenClass = gtNone, lang: string): string =
  let 
    start_str = "<span class='" & op.getClass() & " " & lang.toLower & "'>"
    end_str = "</span>"
  return start_str & s & end_str

proc highlight*(body: string, ext: string): string = 
  return body
  if ext == "":
    return body
  let lang = getSourceLanguage(ext)
  var tokenizer: GeneralTokenizer
  initGeneralTokenizer(tokenizer, body)
  var code = ""
  if lang == langNone:
    return body
  while lang != langNone:
    getNextToken(tokenizer, lang)

    case tokenizer.kind
    of gtEof: break
    of gtNone: continue
    of gtWhitespace:
      let newstr = substr(body, tokenizer.start, tokenizer.length + tokenizer.start - 1)
      code &= newstr
    else:
      let newstr = spanify(substr(body, tokenizer.start, tokenizer.length + tokenizer.start - 1), tokenizer.kind, ext)
      echo newstr
      code &= newstr
  return "<span class='source " & ext.toLower & "'>" & code & "</span>"
