import os
import mummy
import strutils
import nimja/parser
import threadlogging

import handlers/errors
import ../config
import ../storage
import ../model/note
export errors

proc renderIndex(): string =
  {.gcsafe.}:
    let virt_dir = note_config.virt_dir
  compileTemplateFile("templates/index.html", baseDir=getScriptDir() / "../")

proc indexHandler*(request: Request) =
  debug request
  var headers: HttpHeaders
  request.respond(200, headers, renderIndex())

proc highlightCSSHandler*(request: Request) =
  const CSS = staticRead("../templates/highlight.css")
  debug request
  var headers: HttpHeaders
  headers.add({"content-type":"text/css"})
  request.respond(200, headers, CSS)

proc indexPostHandler*(request: Request) =
  debug request
  debug request.uri
  let note_id = storeNote(request.body)
  debug note_id
  {.gcsafe.}:
    let vd = noteConfig.virt_dir
  if note_id != "":
    let redir = vd & "/" & note_id
    debug "302 Found: ", redir
    var headers: HttpHeaders
    headers.add({"Location": redir})
    debug headers
    request.respond(302, headers)
  else:
    internalServerError(request)

proc safe*(note: Note): string =
  # TODO more work here, but at least getting rid of <> symbols should stop nasty js attacks
  var body = ""
  let lines =  note.content.split("\n")
  var 
    code_s = "<code>"
    code_e = "</code>"
  if note.syntax != "":
    code_s = "<code class='language-" & note.syntax & "'>"
  for line in lines:
    body &= code_s & line & code_e
  return body

proc renderNote(note: Note): string =
  compileTemplateFile("templates/paste.html", baseDir = getScriptDir() / "../")

proc noteHandler*(request: Request) =
  debug "Getting Note : ", request
  {.gcsafe.}:
    let vd = noteConfig.virt_dir
  let id = request.uri.replace(vd,"").strip(trailing = false, chars = {'/'})
  var count = 0
  let note = getNote(id, count)
  if note.content != "":
    var headers: HttpHeaders
    debug "200 Found: ", id
    request.respond(200, headers, renderNote(note))
  else:
    debug "404 Not Found: ", id
    notFound(request)
