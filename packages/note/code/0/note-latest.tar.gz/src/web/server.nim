import mummy
import router
import threadlogging

import ../config

proc initServer*() =
  var router = newRouter(note_config.virt_dir)
  let server = newServer(router)
  let address = noteConfig.http_address
  let port = noteConfig.http_port
  try:
    info "Starting web server on ", address, ":", port
    if note_config.virt_dir != "/":
      info "Virt dir is: ", note_config.virt_dir
    server.serve(address = address, port = Port(port))
  except MummyError:
    fatal "Cannot start Web Server: ", getCurrentExceptionMsg()
  
