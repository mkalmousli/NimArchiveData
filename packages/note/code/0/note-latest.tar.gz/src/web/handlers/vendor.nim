import strutils
import tables
import os

import mummy

import threadlogging

import errors

proc getPrismComponents(): Table[string,string] =
  var components: Table[string,string]
  echo "Getting Components"
  for file in walkDir("src/templates/vendor/prism/components"):
    let syn = file.path.split("/")[^1]
    echo syn
    let file_path = file.path.replace("src/","../../")
    components[syn] = staticRead(file_path)
  return components

proc prismComponentHandler*(request: Request) =
  debug request
  var headers: HttpHeaders
  headers.add({"content-type":"application/javascript"})
  const COMPONENTS = getPrismComponents()
  let js =  request.uri.split("/")[^1]
  if COMPONENTS.hasKey(js):
    request.respond(200, headers, COMPONENTS[js])
  else:
    echo js
    notFound(request)

proc prismCSSHandler*(request: Request) =
  debug request
  var headers: HttpHeaders
  headers.add({"content-type":"text/css"})
  const CSS = staticRead("../../templates/vendor/prism/prism.css")
  request.respond(200, headers, CSS)

proc prismJSHandler*(request: Request) =
  debug request
  var headers: HttpHeaders
  headers.add({"content-type":"application/javascript"})
  const JS = staticRead("../../templates/vendor/prism/prism.js")
  request.respond(200, headers, JS)

