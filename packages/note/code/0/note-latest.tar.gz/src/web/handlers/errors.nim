import mummy
import threadlogging

import nimja/parser

proc render404(): string =
  compileTemplateFile("templates/404.html", baseDir = getScriptDir() & "../../../")

proc notFound*(req: Request) =
  info req
  var headers: HttpHeaders
  req.respond(404, headers, render404())

proc render503(): string =
  compileTemplateFile("templates/503.html", baseDir = getScriptDir() & "../../../")

proc notAllowedHandler*(req: Request) =
  info req
  var headers: HttpHeaders
  req.respond(503, headers, render503())

proc render500(): string =
  compileTemplateFile("templates/500.html", baseDir = getScriptDir() & "../../../")


proc internalServerError*(req: Request) =
  info req
  var headers: HttpHeaders
  req.respond(500, headers, render500())
