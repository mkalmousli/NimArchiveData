import mummy
import mummy/routers
import handlers
import handlers/vendor

proc newRouter*(vd: string = ""): Router =
  var note_router: Router
  note_router.get(vd, indexHandler)
  note_router.get(vd & "/", indexHandler)
  note_router.get(vd & "/vendor/prism/prism.css", prismCSSHandler)
  note_router.get(vd & "/vendor/prism/prism.js", prismJSHandler)
  note_router.get(vd & "/vendor/prism/components/*", prismComponentHandler)
  note_router.get(vd & "/highlight.css", highlightCSSHandler)
  note_router.post(vd, indexPostHandler)
  note_router.post(vd & "/", indexPostHandler)
  note_router.get(vd & "/*", noteHandler)
  note_router.post(vd & "/*", noteHandler)
  note_router.notFoundHandler = notFound
  note_router.methodNotAllowedHandler = notAllowedHandler
  return note_router
