import model/config
export config

var noteConfig*: Config

proc initConfig*() =
  noteConfig = newConfig()
