import strutils
import tables
import uri

import threadlogging
import model/note

type 
  NoteStore = ref object
    notes: Table[string,Note]

proc newNoteStore(): NoteStore =
  var store = NoteStore()
  store.notes["info"] = infoNote()
  store.notes["nimtest"] = nimTestNote()
  return store

var note_store: NoteStore = newNoteStore()

# we did this originally to try to help with gcsafe issues
# but it's a little dodgy as we cannot protect race conditions
# so we're going to remove this completely and just use a gcsafe write/read to 
# the Note Store instead
#var storeChannel: Channel[Note]
#var sendChannel: Channel[string]
#var recvChannel: Channel[Note]
#var storeThread: Thread[string]
#var sendThread: Thread[string]
#proc initStoreListener(ok: string) =
#  while ok != "":
#    let note = recv storeChannel
#    {.gcsafe.}:
#      note_store.notes[note.id] = note

#proc initSendListener(ok: string) =
#  while ok != "":
#    let id = recv sendChannel
#    {.gcsafe.}:
#      if note_store.notes.hasKey(id):
#        let note = note_store.notes[id]
#        recvChannel.send note
#      else:
#        recvChannel.send Note()

#proc initStorage*() =
#  storeChannel.open()
#  sendChannel.open()
#  recvChannel.open()
#  createThread storeThread, initStoreListener, "Anything"
#  createThread sendThread, initSendListener, "Anything"

proc storeNote*(s: string): string =
  let content = s[4..^1].decodeUrl
  echo content
  var n = newNote(content)
  {.gcsafe.}:
    note_store.notes[n.id] = n
  #storeChannel.send n
  return n.id

proc getNote*(id: string, count: var int): Note =
  let note_id = id.split(".")
  # Probabl need to sort out a better way to do this, maybe just check the sequence directly with {.gcsafe.} considering I still have to use it anyway. I dunno
  #sendChannel.send(note_id[0])
  #let note = recv recvChannel
  var note: Note
  {.gcsafe.}:
    if note_store.notes.hasKey(note_id[0]):
      note = note_store.notes[note_id[0]]
  if note_id.len > 1:
    note.syntax = note_id[1]
  if count > 5:
    return note
  if note.id != "" and note.id != note_id[0]:
    debug "ID not equal to Note ID\r\nPossible race condition, trying again"
    count += 1
    return getNote(id, count)
  else:
    return note
