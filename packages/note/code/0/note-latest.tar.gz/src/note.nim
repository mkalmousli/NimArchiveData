import web/server
import config

import logging
import threadlogging as tl

when isMainModule:
  var consoleLogger = newConsoleLogger(lvlDebug, "[$time] - $levelname")
  var loggers: seq[Logger] = @[Logger(consoleLogger)]
  initLogThread(loggers)
  #initStorage()
  initConfig()
  tl.notice "Note Started"
  initServer()
  finishLogging()
