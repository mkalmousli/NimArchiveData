import times
import random
import sequtils
import strutils
import encodings

type
  Note* = object
    id*: string
    content*: string
    created*: Time
    syntax*: string

const alpha = "abcdefghijklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ".toSeq

proc newNoteID(l: int): string =
  var a = alpha
  randomize()
  a.shuffle
  var str = a[0..l].join("")
  return str

proc newNote*(s: string = ""): Note = 
  var n = Note()
  n.content = s.replace("+"," ").convert
  n.created = times.now().toTime
  n.id = newNoteID(8)
  return n

proc infoNote*(): Note =
  var n = Note()
  n.content = """# Hello, this is `note`

  1. visit the root of this webpage (remove "info" from the url in the address bar)
  2. type your message, or write some code, etc.
  3. click the icon at the bottom right of the screen 
  4. copy and paste the url from the address bar
  5. send the link to somebody!!

**Yay!!**

## Notes are ephemeral.
They will disappear after some time and don't get stored except in memory.

- Source Code: https://codeberg.org/pswilde/note



_ Inspired by bin. https://github.com/w4/bin _
_ Imitation is the sincerest form of flattery. _
  """
  n.id = "info"
  n.syntax = "md"
  return n

proc nimTestNote*(): Note =
  var n = Note()
  n.content = """import strutils
  echo "This is a test of syntax highlighting for nim"
  proc doSomething(s: string): bool = 
    if s.len > 8: return true
    else:
      return false

  discard doSomething("hi")
  """
  n.id = "nimtest"
  n.syntax = "nim"
  return n
