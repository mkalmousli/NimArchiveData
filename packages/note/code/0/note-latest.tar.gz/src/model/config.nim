import strutils
import argparse

type
  Config* = object
    virt_dir*: string
    http_address*: string
    http_port*: int

proc newConfig*(): Config =
  var cfg = Config(
    virt_dir: "",
    http_address: "0.0.0.0",
    http_port: 8820
  )
  var p = newParser:
    help("note. - A Simple pastebin")
    option("-b","--bind-addr",help="Bind Address i.e. '0.0.0.0:8820'", default=some("0.0.0.0:8820"))
    option("-d","--virt-dir",help="Virtual Directory i.e. '/note'", default=some(""))
  try:
    let opts = p.parse(commandLineParams())
    if opts.bind_addr != "0.0.0.0:8820":
      let ad = opts.bind_addr.split(":")
      cfg.http_address = ad[0]
      cfg.http_port = ad[1].parseInt
    if opts.virt_dir != "":
      cfg.virt_dir = opts.virt_dir
  except ShortCircuit as err:
    if err.flag == "argparse_help":
      echo err.help
      quit(1)
  except UsageError:
    stderr.writeLine getCurrentExceptionMsg()
    quit(1)
  return cfg
