# Package

version       = "1.0.1"
author        = "Paul Wilde"
description   = "A simple paste bin"
license       = "AGPL-3.0-or-later"
srcDir        = "src"
binDir        = "bin"
bin           = @["note"]


# Dependencies

requires "nim >= 2.0.0"
requires "mummy >= 0.3.5"
requires "nimja >= 0.8.7"
requires "threadlogging >= 0.1.5"
requires "argparse >= 4.0.1"

task buildrelease, "Builds and compresses for upload to codeberg releases":
  exec "nimble install"
  exec "mkdir -p releases"
  exec "zip releases/note.zip bin/note"
  exec "tar -czvf releases/note.tar.gz bin/note"
