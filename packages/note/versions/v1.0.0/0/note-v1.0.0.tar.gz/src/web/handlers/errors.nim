import mummy
import threadlogging

import nimja/parser

proc render404(): string =
  compileTemplateFile(getScriptDir() / "templates/404.html")

proc notFound*(req: Request) =
  info req
  var headers: HttpHeaders
  req.respond(404, headers, render404())

proc render503(): string =
  compileTemplateFile(getScriptDir() / "templates/503.html")

proc notAllowedHandler*(req: Request) =
  info req
  var headers: HttpHeaders
  req.respond(503, headers, render503())

proc render500(): string =
  compileTemplateFile(getScriptDir() / "templates/500.html")

proc internalServerError*(req: Request) =
  info req
  var headers: HttpHeaders
  req.respond(500, headers, render500())
