# Package

version       = "0.1.1"
author        = "penguinite" # Wrapper author, not blowfish implementation author
description   = "bcrypt library using Solar Designer's crypt_blowfish (Windows-compatible)"
license       = "crypt_blowfish" # See LICENSE file or "Copyright" section in README
srcDir        = "src"

# Dependencies

requires "nim >= 2.0.0"

task docs, "Generate documentation using nim doc":
  var gitCommit = gorge "git rev-parse --short HEAD || echo \"\"" 
  exec "nimble doc --project --index:on --git.url:\"https://codeberg.org/penguinite/bcryptrocks\" --git.commit:\"" & gitCommit & "\" --outdir:htmldocs src/bcrypt.nim"