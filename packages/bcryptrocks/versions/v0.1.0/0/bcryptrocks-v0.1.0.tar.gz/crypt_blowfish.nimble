# Package

version       = "0.1.0"
author        = "penguinite"
description   = "bcrypt library using Solar Designer's crypt_blowfish (Windows-compatible)"
license       = "CC0" # TODO: Unsure if this is the actual license.
srcDir        = "src"

# Dependencies

requires "nim >= 2.0.0"
