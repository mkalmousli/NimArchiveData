## bcryptnim-compatible module
{.compile: "crypt_blowfish/crypt_blowfish.c".}
{.pragma: cd, cdecl.}
import std/sysrand

proc gensalt_func(
  prefix: cstring,
  count: culong,
  input: cstring,
  size: cint,
  result: cstring,
  output_size: cint
): cstring {.cd, importc: "_crypt_gensalt_blowfish_rn".}

proc bytesToString(bytes: seq[byte]): string =
  ## Converts a sequence of bytes into a string.
  for b in bytes: result.add(char(ord(b)))

proc genSalt*(rounds: int8 = 12, prefix: string = "$2b$"): string =
  ## This generates a salt, a random value that can be used
  ## alongside password hashing to prevent rainbow table attacks.
  ## Salting your passwords is standard security practice.
  ## 
  ## You can set the number of rounds to a number from 4 to 31,
  ## invalid values will make the number fallback to 12.
  ##
  ## Note: If you want perfect compatability with bcryptnim, then you might
  ## have to set the prefix parameter to "$2a$", if you don't care about
  ## compatability then don't keep it as "$2b$", or else you might end up using
  ## a flawed salt generation system.
  runnableExamples "-r:off":
    let rounds = 12

    echo "Your salt is: ", genSalt(rounds)
  let
    # Read 16 bytes from the system CSPRNG 
    input = bytesToString(urandom(16))

    # Fallback to 12 as the number of rounds if the
    # caller specifies less than 4 or more than 31 rounds
    factor = (if (rounds < 4 or rounds > 31): 12 else: rounds)

  var tmpStr = cast[cstring](allocShared0(64))

  if gensalt_func(
    prefix.cstring,
    factor.culong,
    input.cstring,
    16.cint,
    tmpStr,
    64.cint
  ).isNil():
    raise newException(CatchableError, "bcrypt's gensalt function returned nil")

  result = $(tmpStr)
  deallocShared(tmpStr)

proc hash_func(
  key: cstring,
  setting: cstring,
  output: cstring,
  size: cint
): cstring {.cd, importc: "_crypt_blowfish_rn".}

proc hash*(key, salt: string): string =
  ## This procedure takes two string and returns the bcrypt hash for them.
  ## 
  ## Note: It's best that you provide a salt generated using genSalt(),
  ## you could run into undefined behavior otherwise.
  runnableExamples "-r:off":
    var
      pass = "SOMETHING_SECRET"
      salt = genSalt(12)
    
    echo "Your hash is: ", hash(pass, salt)
  var tmpStr = cast[cstring](allocShared0(64))

  if hash_func(
    key.cstring,
    salt.cstring,
    tmpStr,
    64.cint
  ).isNil():
    raise newException(CatchableError, "bcrypt's hash function returned nil")

  result = $(tmpStr)
  deallocShared(tmpStr)

proc compare*(s1, s2: string): bool =
  ## This is a constant-time string comparator.
  ## 
  ## You might not wish to use this, this implementation is provided
  ## as a best effort and is most likely not actually constant-time.
  ## There's also nothing stopping the Nim (or C) compiler from optimizing this
  ## down into variable time instructions.
  ## 
  ## In other words, implement your own check in assembly if you're serious
  ## about security.
  ## 
  ## This procedure is translated from libbcrypt (like all the other procedures)
  runnableExamples:
    assert compare("a", "b") == false

  # Yes, this does technically present an opening for a timing attack.
  # But I don't know of any other way to do this!
  result = true
  let loopableLen = (if len(s1) < len(s2): high(s1) else: high(s2))

  # Empty string don't run through the loop.
  # Again, this is yet another vector for a constant-time attack.
  # But there's nothing I can do against this.
  if len(s1) != len(s2):
    result = false

  for i in 0..loopableLen:
    if s1[i] != s2[i]:
      result = false
  return result