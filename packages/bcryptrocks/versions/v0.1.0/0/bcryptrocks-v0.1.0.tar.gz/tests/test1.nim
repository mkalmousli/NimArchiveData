import std/[unittest, strutils], bcrypt

test "compare() on identical strings":
  check compare("", "") == true
  check compare("a", "a") == true
  check compare("aaa", "aaa") == true
  check compare("aaaa", "aaaa") == true
  check compare("afgewkmowewpo", "afgewkmowewpo") == true

test "compare() on different strings":
  check compare("a", "") == false
  check compare("", "a") == false
  check compare("aa", "a") == false
  check compare("a", "aa") == false
  check compare("adwqikodwqop", "adwqi") == false
  check compare("adwqi", "adwqikodwqop") == false
  check compare("adwqikodwqopadwqikodwqop", "") == false
  check compare("", "adwqikodwqopadwqikodwqop") == false

proc getRounds(s: string): int =
  return parseInt($(s[4] & s[5]))

proc getPrefix(s: string): string =
  return s[0..3]

test "genSalt() rounds fallback test":
  let
    salt2 = genSalt(2)
    salt64 = genSalt(64)
  
  check salt2.getRounds() == 12
  check salt64.getRounds() == 12

test "genSalt() rounds test":
  let
    saltDefault = genSalt()
    salt4 = genSalt(4)
    salt12 = genSalt(12)
    salt31 = genSalt(31)
  
  check salt4.getRounds() == 4
  check salt12.getRounds() == 12
  check saltDefault.getRounds() == 12
  check salt31.getRounds() == 31

test "genSalt() \"$2b$\" prefix test":
  check genSalt().getPrefix() == "$2b$" # Default value test
  check genSalt(prefix = "$2b$").getPrefix() == "$2b$"
  check genSalt(prefix = "$2a$").getPrefix() != "$2b$"

test "genSalt() \"$2a$\" prefix test":
  check genSalt().getPrefix() != "$2a$" # Default value test
  check genSalt(prefix = "$2a$").getPrefix() == "$2a$"
  check genSalt(prefix = "$2b$").getPrefix() != "$2a$"

test "hash() regression (bcryptnim hashes)":
  ## These passwords, salts and hashes were generated all with the original bcryptnim.
  ## This is basically our insurance that we won't suddenly lose compatability with bcryptnim projects
  check hash("z9YnDsIGsAUGOOqEVtgKhyHnVvWKmr7v", "$2a$12$Q2oixrCeFa4XbCb9dn7mD.") == "$2a$12$Q2oixrCeFa4XbCb9dn7mD.Bsy4ISu/G3i2wduqrPXCrzmYdyZvDWy"
  check hash("6XgiFyXO0Awd6svSczRlbDCifxHjnZd4", "$2a$12$HCZs7pNy27F7XYoyq1AQje") == "$2a$12$HCZs7pNy27F7XYoyq1AQjeLGHHj3v6aaes9PqNR8UKVodmbRmwHYK"
  check hash("eL5ReGcvyrptaIodx9EdUpkQMvk7M1nR", "$2a$12$3jmJMThwFp9v2ivAYQNnkO") == "$2a$12$3jmJMThwFp9v2ivAYQNnkOBiXLpvZNLrBs8KelUyKW./0Sohjxgf6"
  check hash("lYHuoClr5PXthHIZNTnv7FUTh3IbcxZE", "$2a$12$QxUrTsvTn8K5l7V8ULAu2.") == "$2a$12$QxUrTsvTn8K5l7V8ULAu2.ltyzsKfQiD7HvvLB1Kv707IWqi8nG6."
  check hash("62KGQOB2sQ8a3DLTTnfEQZt2VF3OHYLF", "$2a$12$XykdpmfGbf6QcUi1HJD4y.") == "$2a$12$XykdpmfGbf6QcUi1HJD4y.BGl.x8sZkmSgKhajz3At0YBsw04VYge"
  check hash("cMx68dP0QKBMwk6aNorwJ1tsSK2bhQyF", "$2a$12$bdo2vKFBBwxORKqCcnOYHO") == "$2a$12$bdo2vKFBBwxORKqCcnOYHOK8o6Imw92W8drZ0V7rbEEoED34R6j5q"
  check hash("2XxPyIT38ILarUpFAfMnZojVSP7lE7Ti", "$2a$12$4sSL/xkgaE0UJIPwDqcuq.") == "$2a$12$4sSL/xkgaE0UJIPwDqcuq.kTzRtTXllFxUgCj9zw8z2kX8Ikmq1Cy"
  check hash("oo6EBFS5L1sBmqnkwdjKYSIdwKU9q9YI", "$2a$12$6Lqsa3Ui8BcwKxUKhNL2Ze") == "$2a$12$6Lqsa3Ui8BcwKxUKhNL2ZeitQulo5Feh22KMGVsf9UhnTpO727Zry"
  check hash("hg9nJgcysjbUXKzGPJkTi1iubhsL6K8I", "$2a$12$83elVKJNo0kGH1nBQqOPYu") == "$2a$12$83elVKJNo0kGH1nBQqOPYuVpzv.PC37vKMbrguoef07LNloBkWQgG"
  check hash("iWMtPAlPED5TIITgrrsMREStMlI6nTh2", "$2a$12$hCg8GUAnFj7g2Vp0TYj72O") == "$2a$12$hCg8GUAnFj7g2Vp0TYj72OvITEsLd.ut5JkPBLUH8CrKcgUUuVcOi"
  check hash("gniqZkw8L2AK5EJtGunaidO5cSt44ptI", "$2a$12$AHxDRWhEwu4fonrmaqot3.") == "$2a$12$AHxDRWhEwu4fonrmaqot3.mypEtPEFdc3j2cUzjxADApX6OBVMGcy"
  check hash("qs5xCiqzu3OLsDtlMgkLIyY5cNHVwLrO", "$2a$12$GHklBm2IeCyH6M.LwzBYU.") == "$2a$12$GHklBm2IeCyH6M.LwzBYU.DjcHL26soONIgH7qC5l99PXIf0LBDP2"
  check hash("rjPcibM2NQ0nR8DzUy2ZiJVmTTEeM1XQ", "$2a$12$4pQ9nqDPcE350pBaA4kI.u") == "$2a$12$4pQ9nqDPcE350pBaA4kI.uECEB7QX4OWB.e4NKKvnZMTkdHvMYBYK"
  check hash("PwrU4yG4Ughk9xc6SLmRNji51Qoh4pZH", "$2a$12$KGap5TPrHJRBImuAEHIsmO") == "$2a$12$KGap5TPrHJRBImuAEHIsmOWRGKq7gMEFoKNcSqGiI96ho3zBLxQmi"
  check hash("UwPSqOB128uG2Hh95Jlb7dSkx0BbCBZT", "$2a$12$fmdPw8w9RR61w3TDd2n4E.") == "$2a$12$fmdPw8w9RR61w3TDd2n4E.nkDHXJzrMiVe7x1EwDq3R6Cb.8HhMVG"
  check hash("0sx62Sv9SwBvms8AP54SBPbVMOHsVasn", "$2a$12$AcrB/x6/cLiljgQ0XpLJ0O") == "$2a$12$AcrB/x6/cLiljgQ0XpLJ0OWVKdMiDDJMWyq/o1q7nFLpeAww7xzou"

test "hash() regression (crypt_blowfish hashes)":
  check hash("MRcfb4mEaEnysX3EiOgxeQOD0vJGgJfn", "$2b$12$Tbt4M2Gj9DkdMrztZCjN.u") == "$2b$12$Tbt4M2Gj9DkdMrztZCjN.u6KiJmwBz0gyTbcCmZ907lRxDFPw2eEi"
  check hash("4xpRwnjkkM0hd5iN4DrGF51heV4zYWHd", "$2b$12$gCyIpzM8n5abXyhXZBkk0e") == "$2b$12$gCyIpzM8n5abXyhXZBkk0eJA1Cwea/SDBSy6dAOb9376tg9pHD2lW"
  check hash("EuwjBlej3nhDuiP6LUurYHXjbSG5NKNr", "$2b$12$H4F8w4waqd5rqzEqTCd50.") == "$2b$12$H4F8w4waqd5rqzEqTCd50.FEk77nw0w8c1l.RrS2WUd0Qb9VSDWfu"
  check hash("J6KhECTpNhlbRFWBKkaZSdIkBZCCsUcd", "$2b$12$laqoKMgCGI7Itguu66y8Ye") == "$2b$12$laqoKMgCGI7Itguu66y8Yev/Uv9s6KkfnmfkOiUokBpM8wtMzd.KG"
  check hash("okOtIBZCa5gTjXv2SFSSgdm1x0EMBxxv", "$2b$12$Uqz5tNeatL/jd2/s1NoDQO") == "$2b$12$Uqz5tNeatL/jd2/s1NoDQOSSRhCzyjxwBaZI9krZiWtMEfjzC1/cm"
  check hash("GDsXOry419zCPoaSsJXvkWs08jteIjPe", "$2b$12$oa6KX6nGSsAV9y1FTO0JTe") == "$2b$12$oa6KX6nGSsAV9y1FTO0JTekNuYroTwX4V126R.ACBJNx56czm9Hea"
  check hash("WFdiSJa0p79ASPvVd1neQvYj3OtLpL8u", "$2b$12$7YUUUzPeeDn20ZMdejs69.") == "$2b$12$7YUUUzPeeDn20ZMdejs69.t.FRPO42nGKra35Fnz1/q5GxH7CBjCe"
  check hash("AoLDyxwSCQJ2O5CHJ3jYUcx6AyS8QG3w", "$2b$12$lJLAxixBX5Tvf1eKe2gnHe") == "$2b$12$lJLAxixBX5Tvf1eKe2gnHeezSwXxhsaUssp/EuX4chOSbavvuDjLC"
  check hash("qRBsCdejcbRXUnV7KLpjqY8vsodVSJaj", "$2b$12$.9tNCACSK6lC9F3ADX2VOu") == "$2b$12$.9tNCACSK6lC9F3ADX2VOuaUyMCSWNOTbyOrdc/6hw1pOEUUc5l1K"
  check hash("zdLFSoqmsIrrEb20xJQVqGdYlhmZM6lW", "$2b$12$9OR4uaF92GoS5tND0A3zJO") == "$2b$12$9OR4uaF92GoS5tND0A3zJOhgSZ1ZsBSB/DlsBhBl./vcU1v8i8ZQO"
  check hash("2WMDGA4WOyjkDOgBS0YhllXOEWznjhmf", "$2b$12$6jf.Hv.YOVrd5Fb4GJoCYO") == "$2b$12$6jf.Hv.YOVrd5Fb4GJoCYOLix6qPtFvUCWwoKVB/MXlyFlCEAYp22"
  check hash("196EqXaidLca8QAqy97FAmzrZPQLBz9o", "$2b$12$2X9yHWEFf/N9JZerLBa6We") == "$2b$12$2X9yHWEFf/N9JZerLBa6WeTiOlAs9YIbmckBufc5LOt8/NAsOUTkm"
  check hash("Ubj6OdWe8BvTyhGaYAhhW6CdikKMdgmM", "$2b$12$x/E4JoupEohOSLFQaqmqlu") == "$2b$12$x/E4JoupEohOSLFQaqmqlu6yxrJiqejEzPKSoF4.La55HcQNNYrEW"
  check hash("SQUoKwY2JJA86WCNriDqMxhi1WDAq9lJ", "$2b$12$MGNjxMlQfLVkyPLvltCYUe") == "$2b$12$MGNjxMlQfLVkyPLvltCYUeyjzsAw1UmZtlPKoziUTgg/vEuDHDfm2"
  check hash("d4rmX2d3HhfhGwdgo7zCGBvQ0erTj7dQ", "$2b$12$6CoA09SGCrCpdKYwaHuyPu") == "$2b$12$6CoA09SGCrCpdKYwaHuyPuzAyIlPivDibRlwZB6gz0cFnfD9/rCi6"
  check hash("DS8zLcP9gmGudU2HANTCl92BhsyOtE67", "$2b$12$4Hh2sWeGyWaLK7NvSJDGzO") == "$2b$12$4Hh2sWeGyWaLK7NvSJDGzOdSNrdwhYz4AT5miOGclbSoIz9JcyTvq"
