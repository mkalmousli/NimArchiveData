# Basic documentation

Run `clone.sh` to replicate the clone the folders.
`NOTES.md` contains some basic notes for the implementation here.

Folders:

1. [`bcryptnim`](https://github.com/runvnc/bcryptnim)

A Nim wrapper over an old version of the OpenBSD bcrypt library.
This is the library we're trying to replace, for compatability reasons. 

2. [`crypt_blowfish`](https://github.com/openwall/crypt_blowfish)

An independent implementation of bcrypt provided by [@solardiz](https://github.com/solardiz) (Solar Designer) [Project Homepage](https://www.openwall.com/crypt/)
This is what we are trying to port to Nim, again, for compatability reasons.

3. [`libbcrypt`](https://github.com/rg3/libbcrypt)

A C wrapper over `crypt_blowfish`, serves as a helpful study tool.

