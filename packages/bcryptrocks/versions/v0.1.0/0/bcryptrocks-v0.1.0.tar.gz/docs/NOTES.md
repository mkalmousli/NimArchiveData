# Notes for Implementors

Everything in the old notes still applies, but I am not gonna be diving deep into the C code.
I've already partially uncovered genSalt() and I've decided to just wrap the C code.

C lives once again.

## Old Notes

`bcryptnim` (the original library) defines the following procedures for use by clients: (exported procedures)

1. `genSalt(rounds: int8): string`
3. `hash(key, salt:string): string`
2. `compare(s1, s2: string): bool`

It makes use of the following C functions, so just find their equivalents and port them to Nim.
I've even added links to the original C functions that `bcryptnim` calls.

1. [`bcrypt_gensalt`](https://github.com/runvnc/bcryptnim/blob/440c5676ff63ae1ba1bd7dae4c0682ba4b9c54b2/bcrypt/crypt-blowfish.c#L176)
2. [`crypt_blowfish`](https://github.com/runvnc/bcryptnim/blob/440c5676ff63ae1ba1bd7dae4c0682ba4b9c54b2/bcrypt/crypt-blowfish.c#L199)
3. [`compare_string`](https://github.com/runvnc/bcryptnim/blob/440c5676ff63ae1ba1bd7dae4c0682ba4b9c54b2/bcrypt/crypt-blowfish.c#L340)

`bcryptnim` wraps over a version of the OpenBSD bcrypt library (AFAIK), which is why it has that weird licensing requirement about mentioning the author Niels Provos.
And also, the version that OpenBSD wraps over is (I think, again) before February 2014, when a flaw was discovered in the library.
My reasoning for this is that the prefix used by `bcryptnim` is `$2a$`, but after February 2014, the prefix in the OpenBSD implementation was upgraded to `$2b$`
So `bcryptnim` *might* be vulnerable in *some way*, See the ["Versioning history" section on bcrypt's Wikipedia article](https://en.wikipedia.org/wiki/Bcrypt#Versioning_history)

Anyway, I've decided against porting the original OpenBSD implementation, even if it *was* secure because of the "mention the author" licensing requirement.
That's just plain dumb, and thankfully [a kind soul](https://github.com/solardiz) did implement bcrypt password hashing which they then put under the public domain (or a fallback equivalent)

Either way, I've done a bit of due diligence and found that the library im porting (`crypt_blowfish`) does use the `$2b$` prefix so it is free from any known vulnerabilities.

The functions I have got to port (equivalent functions) are:

1. 
2. 
3. `compare_string` has no equivalent in the `crypt_blowfish` library, so just port it from the [`compare_string`](https://github.com/runvnc/bcryptnim/blob/440c5676ff63ae1ba1bd7dae4c0682ba4b9c54b2/bcrypt/crypt-blowfish.c#L340)

