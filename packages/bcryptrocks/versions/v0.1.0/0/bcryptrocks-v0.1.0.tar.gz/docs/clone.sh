
git clone https://github.com/runvnc/bcryptnim
git clone https://github.com/openwall/crypt_blowfish
git clone https://github.com/rg3/libbcrypt