# intops
# Copyright 2025-2026 Status Research & Development GmbH
# Licensed under either of
#
#  * Apache License, version 2.0, ([LICENSE-APACHE](LICENSE-APACHE) or http://www.apache.org/licenses/LICENSE-2.0)
#  * MIT license ([LICENSE-MIT](LICENSE-MIT) or http://opensource.org/licenses/MIT)
#
# at your option. This file may not be copied, modified, or distributed except according to those terms.

import ../impl/[pure, intrinsics, inlinec, inlineasm]

import ../consts

template overflowingAdd*[T: SomeInteger](a, b: T): tuple[res: T, didOverflow: bool] =
  ##[ Overflowing addition.

  Takes two integers and returns their sum along with the overflow flag (OF):
  ``true`` means overflow happened, ``false`` means overflow didn't happen.

  Addition wraps for both signed and unsigned integers, so this operation never raises.

  See also:
  - `overflowingSub <sub.html#overflowingSub>`_
  ]##

  when nimvm:
    pure.overflowingAdd(a, b)
  else:
    when compilerGccCompatible and canUseIntrinsics:
      intrinsics.gcc.overflowingAdd(a, b)
    else:
      pure.overflowingAdd(a, b)

template saturatingAdd*[T: SomeInteger](a, b: T): T =
  ##[ Saturating addition.

  Takes two integers and returns their sum; if the result won't fit within the type,
  the maximal possible value is returned.

  See also:
  - `saturatingSub <sub.html#saturatingSub>`_
  ]##

  when nimvm:
    pure.saturatingAdd(a, b)
  else:
    when compilerGccCompatible and canUseIntrinsics:
      intrinsics.gcc.saturatingAdd(a, b)
    elif cpuArm64 and compilerGccCompatible and canUseInlineAsm:
      inlineasm.arm64.saturatingAdd(a, b)
    else:
      pure.saturatingAdd(a, b)

template carryingAdd*(a, b: uint64, carry: bool): tuple[res: uint64, carry: bool] =
  ##[ Carrying addition for unsigned 64-bit integers.

  Takes two integers and returns their sum along with the carrying flag (CF): 
  ``true`` means the previous addition had overflown, ``false`` means it hadn't.

  Useful for chaining operations.

  See also:
  - `borrowingSub <sub.html#borrowingSub>`_
  ]##

  when nimvm:
    pure.carryingAdd(a, b, carry)
  else:
    when cpuX86 and compilerMsvc and canUseIntrinsics:
      intrinsics.x86.carryingAdd(a, b, carry)
    elif compilerGccCompatible and canUseIntrinsics:
      intrinsics.gcc.carryingAdd(a, b, carry)
    elif cpu64Bit and compilerGccCompatible and canUseInlineC:
      inlinec.carryingAdd(a, b, carry)
    else:
      pure.carryingAdd(a, b, carry)

template carryingAdd*(a, b: uint32, carry: bool): tuple[res: uint32, carry: bool] =
  ##[ Carrying addition for unsigned 32-bit integers.

  Takes two integers and returns their sum along with the carrying flag (CF): 
  ``true`` means the previous addition had overflown, ``false`` means it hadn't.

  Useful for chaining operations.

  See also:
  - `borrowingSub <sub.html#borrowingSub>`_
  ]##

  when nimvm:
    pure.carryingAdd(a, b, carry)
  else:
    when cpuX86 and compilerMsvc and canUseIntrinsics:
      intrinsics.x86.carryingAdd(a, b, carry)
    elif compilerGccCompatible and canUseIntrinsics:
      intrinsics.gcc.carryingAdd(a, b, carry)
    else:
      pure.carryingAdd(a, b, carry)

template carryingAdd*(a, b: int64, carry: bool): tuple[res: int64, carry: bool] =
  ##[ Carrying addition for signed 64-bit integers.

  Takes two integers and returns their sum along with the carrying flag (CF): 
  ``true`` means the previous addition had overflown, ``false`` means it hadn't.

  Useful for chaining operations.

  See also:
  - `borrowingSub <sub.html#borrowingSub>`_
  ]##

  when nimvm:
    pure.carryingAdd(a, b, carry)
  else:
    when compilerGccCompatible and canUseIntrinsics:
      intrinsics.gcc.carryingAdd(a, b, carry)
    else:
      pure.carryingAdd(a, b, carry)

template carryingAdd*(a, b: int32, carry: bool): tuple[res: int32, carry: bool] =
  ##[ Carrying addition for signed 32-bit integers.

  Takes two integers and returns their sum along with the carrying flag (CF): 
  ``true`` means the previous addition had overflown, ``false`` means it hadn't.

  Useful for chaining operations.

  See also:
  - `borrowingSub <sub.html#borrowingSub>`_
  ]##

  when nimvm:
    pure.carryingAdd(a, b, carry)
  else:
    when compilerGccCompatible and canUseIntrinsics:
      intrinsics.gcc.carryingAdd(a, b, carry)
    else:
      pure.carryingAdd(a, b, carry)

template carry*(a, b: SomeUnsignedInt, carry: bool): bool =
  ##[ Carrying addition that returns just the carry flag for unsigned integers.

  See also:
  - `carryingAdd`_
  ]##

  when nimvm:
    pure.carry(a, b, carry)
  else:
    when cpuX86 and compilerMsvc and canUseIntrinsics:
      intrinsics.x86.carry(a, b, carry)
    elif compilerGccCompatible and canUseIntrinsics:
      intrinsics.gcc.carry(a, b, carry)
    else:
      pure.carry(a, b, carry)

template carry*(a, b: SomeSignedInt, carry: bool): bool =
  ##[ Carrying addition that returns just the carry flag for signed integers.

  See also:
  - `carryingAdd`_
  ]##

  when nimvm:
    pure.carry(a, b, carry)
  else:
    when compilerGccCompatible and canUseIntrinsics:
      intrinsics.gcc.carry(a, b, carry)
    else:
      pure.carry(a, b, carry)
