# intops
# Copyright 2025-2026 Status Research & Development GmbH
# Licensed under either of
#
#  * Apache License, version 2.0, ([LICENSE-APACHE](LICENSE-APACHE) or http://www.apache.org/licenses/LICENSE-2.0)
#  * MIT license ([LICENSE-MIT](LICENSE-MIT) or http://opensource.org/licenses/MIT)
#
# at your option. This file may not be copied, modified, or distributed except according to those terms.

## GCC/Clang intrinsics-based implementations of arithmetic operations for integers.

import ../../consts

when compilerGccCompatible and canUseIntrinsics:
  func builtinOverflowingAdd*[T: SomeInteger](
    a, b: T, res: var T
  ): bool {.importc: "__builtin_add_overflow", nodecl.}
    ## Checks if a + b overflows. Returns true on overflow.

  func builtinOverflowingSub*[T: SomeInteger](
    a, b: T, res: var T
  ): bool {.importc: "__builtin_sub_overflow", nodecl.}
    ## Checks if a - b overflows. Returns true on overflow.

  {.push raises: [], inline, noinit, gcsafe.}

  func overflowingAdd*[T: SomeInteger](a, b: T): (T, bool) =
    var res {.noinit.}: T

    let didOverflow = builtinOverflowingAdd(a, b, res)

    (res, didOverflow)

  func saturatingAdd*[T: SomeUnsignedInt](a, b: T): T =
    var res {.noinit.}: T

    let didOverflow = builtinOverflowingAdd(a, b, res)

    if unlikely(didOverflow):
      return high(T)

    res

  func saturatingAdd*[T: SomeSignedInt](a, b: T): T =
    var res {.noinit.}: T

    let didOverflow = builtinOverflowingAdd(a, b, res)

    if unlikely(didOverflow):
      if a < 0:
        return low(T)
      else:
        return high(T)

    res

  func carryingAdd*[T: SomeInteger](a, b: T, carry: bool): (T, bool) =
    var t1, final {.noinit.}: T

    let
      c1 = builtinOverflowingAdd(a, b, t1)
      c2 = builtinOverflowingAdd(t1, T(carry), final)

    (final, c1 or c2)

  func carry*[T: SomeInteger](a, b: T, carry: bool): bool =
    var res {.noinit.}: T

    let didOverflow = builtinOverflowingAdd(a, b, res)

    didOverflow or (carry and (res == high(T)))

  func overflowingSub*[T: SomeInteger](a, b: T): (T, bool) =
    var res {.noinit.}: T

    let didBorrow = builtinOverflowingSub(a, b, res)

    (res, didBorrow)

  func saturatingSub*[T: SomeUnsignedInt](a, b: T): T =
    var res {.noinit.}: T

    let didBorrow = builtinOverflowingSub(a, b, res)

    if unlikely(didBorrow):
      return low(T)

    res

  func saturatingSub*[T: SomeSignedInt](a, b: T): T =
    var res {.noinit.}: T

    let didOverflow = builtinOverflowingSub(a, b, res)

    if unlikely(didOverflow):
      if a < 0:
        return low(T)
      else:
        return high(T)

    res

  func borrowingSub*[T: SomeInteger](a, b: T, borrow: bool): (T, bool) =
    var t1, final {.noinit.}: T

    let
      b1 = builtinOverflowingSub(a, b, t1)
      b2 = builtinOverflowingSub(t1, T(borrow), final)

    (final, b1 or b2)

  func borrow*[T: SomeInteger](a, b: T, borrow: bool): bool =
    var res {.noinit.}: T

    let didBorrow = builtinOverflowingSub(a, b, res)

    didBorrow or (borrow and (res == low(T)))
