# intops
# Copyright 2025-2026 Status Research & Development GmbH
# Licensed under either of
#
#  * Apache License, version 2.0, ([LICENSE-APACHE](LICENSE-APACHE) or http://www.apache.org/licenses/LICENSE-2.0)
#  * MIT license ([LICENSE-MIT](LICENSE-MIT) or http://opensource.org/licenses/MIT)
#
# at your option. This file may not be copied, modified, or distributed except according to those terms.

## Arithmetic operations for integers implemented in ARM64 GCC/Clang inline Assembly.

import ../../consts

when cpuArm64 and compilerGccCompatible and canUseInlineAsm:
  {.push raises: [], inline, noinit, gcsafe.}

  func saturatingAdd*(a, b: uint64): uint64 =
    asm """
      uqadd %d[result], %d[a], %d[b]
      : [result] "=w" (`result`)
      : [a] "w" (`a`), [b] "w" (`b`)
    """

  func saturatingAdd*(a, b: uint32): uint32 =
    asm """
      uqadd %s[result], %s[a], %s[b]
      : [result] "=w" (`result`)
      : [a] "w" (`a`), [b] "w" (`b`)
    """

  func saturatingAdd*(a, b: int64): int64 =
    asm """
      sqadd %d[result], %d[a], %d[b]
      : [result] "=w" (`result`)
      : [a] "w" (`a`), [b] "w" (`b`)
    """

  func saturatingAdd*(a, b: int32): int32 =
    asm """
      sqadd %s[result], %s[a], %s[b]
      : [result] "=w" (`result`)
      : [a] "w" (`a`), [b] "w" (`b`)
    """

  func saturatingSub*(a, b: uint64): uint64 =
    asm """
      uqsub %d[result], %d[a], %d[b]
      : [result] "=w" (`result`)
      : [a] "w" (`a`), [b] "w" (`b`)
    """

  func saturatingSub*(a, b: uint32): uint32 =
    asm """
      uqsub %s[result], %s[a], %s[b]
      : [result] "=w" (`result`)
      : [a] "w" (`a`), [b] "w" (`b`)
    """

  func saturatingSub*(a, b: int64): int64 =
    asm """
      sqsub %d[result], %d[a], %d[b]
      : [result] "=w" (`result`)
      : [a] "w" (`a`), [b] "w" (`b`)
    """

  func saturatingSub*(a, b: int32): int32 =
    asm """
      sqsub %s[result], %s[a], %s[b]
      : [result] "=w" (`result`)
      : [a] "w" (`a`), [b] "w" (`b`)
    """
