# Package

version       = "0.2.0"
author        = "Yes DrX"
description   = "A new awesome nimble package"
license       = "MIT"
srcDir        = "src"


# Dependencies

requires "nim >= 2.2.4"

# genearte doc: nim doc --project --index:on --git.url:https://github.com/yesdrx/nimodbclite --git.commit:master --outdir:docs ./src/nimodbclite.nim
