version       = "2.1.4"
author        = "Ryan Oldenburg"
description   = "Nim implementation of Google's Snappy compression."
license       = "MIT"

srcDir = "src"

requires "nim >= 1.0.0"
