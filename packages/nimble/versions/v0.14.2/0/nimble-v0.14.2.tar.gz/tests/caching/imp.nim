proc impTest*() =
  echo "imported"