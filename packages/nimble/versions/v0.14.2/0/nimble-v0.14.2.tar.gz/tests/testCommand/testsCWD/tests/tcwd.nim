import os
echo(getCurrentDir())