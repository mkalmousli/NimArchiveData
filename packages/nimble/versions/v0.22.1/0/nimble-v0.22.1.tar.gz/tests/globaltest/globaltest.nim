echo "hello from globaltest"
