echo "Hello from pkgWithSkipDirs!"
