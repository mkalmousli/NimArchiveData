echo "Hello from pkgWithInstallDirs!"
