echo 42
