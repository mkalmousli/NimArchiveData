import issue27b
