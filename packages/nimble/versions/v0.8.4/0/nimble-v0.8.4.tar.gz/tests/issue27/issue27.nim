import issue27a
