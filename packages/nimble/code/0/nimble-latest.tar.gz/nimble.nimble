# Package

version       = "0.99.1"
author        = "Dominik Picheta"
description   = "Nim package manager."
license       = "BSD"

bin = @["nimble"]
srcDir = "src"
installExt = @["nim"]

# Dependencies
requires "nim >= 1.6.20"

when defined(nimdistros):
  import distros
  if detectOs(Ubuntu):
    foreignDep "libssl-dev"
  else:
    foreignDep "openssl"

before install:
  exec "git submodule update --init"

proc runTester(extraFlags = "") =
  var extraParams = ""
  for i in 0 .. paramCount():
    if "::" in paramStr(i):
      extraParams = "test "
      extraParams.addQuoted paramStr(i)

  withDir "tests":
    exec "nim c " & extraFlags & " -r tester " & extraParams

task test, "Run the Nimble tester!":
  runTester()

task cibenchmark, "Run tests with timing instrumentation":
  runTester("-d:timedTests")
