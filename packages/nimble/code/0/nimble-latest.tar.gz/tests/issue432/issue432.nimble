# Package

version       = "0.1.0"
author        = "Dominik Picheta"
description   = "A new awesome nimble package"
license       = "MIT"
srcDir        = "src"



# Dependencies

requires "nim >= 0.16.0"
requires "https://github.com/jmgomez/packagea#head",
         "https://github.com/jmgomez/packagebin2"
