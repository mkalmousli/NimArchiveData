# Copyright (C) Dominik Picheta. All rights reserved.
# BSD License. Look at license.txt for more info.

import os, tables, browsers, algorithm, sets, sugar, strformat

import nimblepkg/compat/[json, sequtils, osproc]
import std/options as std_opt

import strutils except toLower
from unicode import toLower
import sat/sat
{.warning[UnusedImport]: off.}
import nimblepkg/nimbledatafile
{.warning[UnusedImport]: on.}
import nimblepkg/packageinfotypes, nimblepkg/packageinfo, nimblepkg/version,
       nimblepkg/tools, nimblepkg/download, nimblepkg/common,
       nimblepkg/publish, nimblepkg/options, nimblepkg/packageparser,
       nimblepkg/cli, nimblepkg/packageinstaller, nimblepkg/reversedeps,
       nimblepkg/nimscriptexecutor, nimblepkg/init, nimblepkg/vcstools,
       nimblepkg/checksums, nimblepkg/lockfile,
       nimblepkg/nimscriptwrapper, nimblepkg/developfile, nimblepkg/paths,
       nimblepkg/packagemetadatafile,
       nimblepkg/displaymessages, nimblepkg/sha1hashes, nimblepkg/syncfile,
       nimblepkg/deps, nimblepkg/nimblesat, nimblepkg/nimenv,
       nimblepkg/downloadnim, nimblepkg/declarativeparser,
      nimblepkg/build, nimblepkg/install,
      nimblepkg/versiondiscovery, nimblepkg/nimresolution

const
  nimblePathsFileName* = "nimble.paths"
  nimbleConfigFileName* = "config.nims"
  nimbledepsFolderName = "nimbledeps"
  gitIgnoreFileName = ".gitignore"
  hgIgnoreFileName = ".hgignore"
  separator = when defined(windows): ";" else: ":"

template withNimBinFallback*(nimBin: var Option[string], options: Options, body: untyped) =
  ## Catch NeedsNimBinError, resolve bootstrap nim lazily, and retry.
  ## Use around any call that may trigger VM-parser fallback with nimBin=none.
  try:
    body
  except NeedsNimBinError:
    if nimBin.isNone:
      nimBin = some(ensureBootstrapNim(options))
    body

proc initPkgList(pkgInfo: PackageInfo, options: Options, nimBin: Option[string]): seq[PackageInfo] =
  let
    installedPkgs = getInstalledPkgsMin(options.getPkgsDir(), options)
    developPkgs = processDevelopDependencies(pkgInfo, options, nimBin)

  # Get names of develop packages to filter out from installed packages
  let developPkgNames = developPkgs.mapIt(it.basicInfo.name.toLowerAscii()).toHashSet()

  # Filter installed packages that have a develop version (develop takes priority)
  let filteredInstalledPkgs = installedPkgs.filterIt(
    it.basicInfo.name.toLowerAscii() notin developPkgNames
  )

  result = concat(filteredInstalledPkgs, developPkgs)
  result.add getNimBinariesPackages(options)

proc install(packages: seq[PkgTuple], options: Options,
             doPrompt, first, fromLockFile: bool,
             nimBin: Option[string] = none(string),
             preferredPackages: seq[PackageInfo] = @[]): PackageDependenciesInfo

proc getNimDir(options: var Options, nimBin: var Option[string]): string

proc solvePkgs(rootPackage: PackageInfo, options: var Options, nimBin: var Option[string]) {.instrument.}

proc setup(options: Options, nimBin: Option[string])

proc develop(options: var Options, nimBinParam: Option[string])

proc cleanFromDir(pkgInfo: PackageInfo, nimBin: Option[string], options: Options) =
  ## Clean up build files.
  # Handle pre-`clean` hook.
  let pkgDir = pkgInfo.myPath.parentDir()

  cd pkgDir: # Make sure `execHook` executes the correct .nimble file.
    if not execHook(nimBin, options, actionClean, true):
      raise nimbleError("Pre-hook prevented further execution.")

  if pkgInfo.bin.len == 0:
    return

  for bin, _ in pkgInfo.bin:
    let outputDir = pkgInfo.getOutputDir("")
    if dirExists(outputDir):
      if fileExists(outputDir / bin):
        removeFile(outputDir / bin)

  # Handle post-`clean` hook.
  cd pkgDir: # Make sure `execHook` executes the correct .nimble file.
    discard execHook(nimBin, options, actionClean, false)

proc promptRemoveEntirePackageDir(pkgDir: string, options: Options) =
  let exceptionMsg = getCurrentExceptionMsg()
  let warningMsgEnd = if exceptionMsg.len > 0: &": {exceptionMsg}" else: "."
  let warningMsg = &"Unable to read {packageMetaDataFileName}{warningMsgEnd}"

  display("Warning", warningMsg, Warning, HighPriority)

  if not options.prompt(
      &"Would you like to COMPLETELY remove ALL files in {pkgDir}?"):
    raise nimbleQuit()

proc removePackageDir(pkgInfo: PackageInfo, pkgDestDir: string) =
  removePackageDir(pkgInfo.metaData.files & packageMetaDataFileName, pkgDestDir)

proc removeBinariesSymlinks(pkgInfo: PackageInfo, binDir: string) =
  for bin in pkgInfo.metaData.binaries:
    when defined(windows):
      removeFile(binDir / bin.changeFileExt("cmd"))
    removeFile(binDir / bin)

proc reinstallSymlinksForOlderVersion(pkgDir: string, options: Options, nimBin: Option[string]) =
  let (pkgName, _, _) = getNameVersionChecksum(pkgDir)
  let pkgList = getInstalledPkgsMin(options.getPkgsDir(), options)
  var newPkgInfo = initPackageInfo()
  if pkgList.findPkg((pkgName, newVRAny()), newPkgInfo):
    newPkgInfo = newPkgInfo.toFullInfo(options, nimBin)
    for bin, _ in newPkgInfo.bin:
      let symlinkDest = newPkgInfo.getOutputDir(bin)
      let symlinkFilename = options.getBinDir() / bin.extractFilename
      discard setupBinSymlink(symlinkDest, symlinkFilename, options)

proc removePackage(pkgInfo: PackageInfo, options: Options, nimBin: Option[string]) =
  var pkgInfo = pkgInfo
  let pkgDestDir = pkgInfo.getPkgDest(options)

  if not pkgInfo.hasMetaData:
    try:
      fillMetaData(pkgInfo, pkgDestDir, true, options)
    except MetaDataError, ValueError:
      promptRemoveEntirePackageDir(pkgDestDir, options)
      removeDir(pkgDestDir)

  removePackageDir(pkgInfo, pkgDestDir)
  removeBinariesSymlinks(pkgInfo, options.getBinDir())
  reinstallSymlinksForOlderVersion(pkgDestDir, options, nimBin)
  options.nimbleData.removeRevDep(pkgInfo)

proc packageExists(pkgInfo: PackageInfo, options: Options, nimBin: Option[string]):
    Option[PackageInfo] =
  ## Checks whether a package `pkgInfo` already exists in the Nimble cache. If a
  ## package already exists returns the `PackageInfo` of the package in the
  ## cache otherwise returns `none`. Raises a `NimbleError` in the case the
  ## package exists in the cache but it is not valid.
  let pkgDestDir = pkgInfo.getPkgDest(options)
  if not fileExists(pkgDestDir / packageMetaDataFileName):
    return none[PackageInfo]()
  else:
    var oldPkgInfo = initPackageInfo()
    try:
      oldPkgInfo = pkgDestDir.getPkgInfo(options, nimBin = nimBin)
    except CatchableError as error:
      raise nimbleError(&"The package inside \"{pkgDestDir}\" is invalid.",
                        details = error)
    fillMetaData(oldPkgInfo, pkgDestDir, true, options)
    return some(oldPkgInfo)

proc installFromDir(dir: string, requestedVer: VersionRange, options: Options,
                    url: string, first: bool, fromLockFile: bool,
                    nimBin: Option[string],
                    vcsRevision = notSetSha1Hash,
                    deps: seq[PackageInfo] = @[],
                    preferredPackages: seq[PackageInfo] = @[]):
    PackageDependenciesInfo =
  ## Installs a package from a directory. Returns the installed package info
  ## together with its dependencies.
  ##
  ## ``first``
  ##   True if this is the first level of the indirect recursion.
  ## ``fromLockFile``
  ##   True if we are installing dependencies from the lock file.
  if not options.depsOnly:
    cd dir: # Make sure `execHook` executes the correct .nimble file.
      if not execHook(nimBin, options, actionInstall, true):
        raise nimbleError("Pre-hook prevented further execution.")

  var pkgInfo = getPkgInfo(dir, options, nimBin = nimBin)
  # Set the flag that the package is not in develop mode before saving it to the
  # reverse dependencies.
  pkgInfo.source = psInstalled
  if vcsRevision != notSetSha1Hash:
    ## In the case we downloaded the package as tarball we have to set the VCS
    ## revision returned by download procedure because it cannot be queried from
    ## the package directory.
    pkgInfo.metaData.vcsRevision = vcsRevision

  let realDir = pkgInfo.getRealDir()
  let binDir = options.getBinDir()
  var depsOptions = options
  depsOptions.depsOnly = false

  if requestedVer.kind == verSpecial:
    # Add a version alias to special versions set if requested version is a
    # special one.
    pkgInfo.metaData.specialVersions.incl requestedVer.spe

  # Dependencies are already resolved by the SAT solver
  result.deps = deps.toHashSet

  if options.depsOnly:
    result.pkg = pkgInfo
    return result

  display("Installing", "$1@$2" %
    [pkginfo.basicInfo.name, $pkginfo.basicInfo.version],
    priority = MediumPriority)

  let oldPkg = pkgInfo.packageExists(options, nimBin)
  if oldPkg.isSome:
    # In the case we already have the same package in the cache then only merge
    # the new package special versions to the old one.
    displayWarning(pkgAlreadyExistsInTheCacheMsg(pkgInfo), MediumPriority)

  let pkgDestDir = pkgInfo.getPkgDest(options)

  # Fill package Meta data
  pkgInfo.metaData.url = url
  pkgInfo.source = psInstalled

  # Don't copy artifacts if project local deps mode and "installing" the top
  # level package.
  if not (options.localdeps and options.isInstallingTopLevel(dir)):
    createDir(pkgDestDir)
    # Copy this package's files based on the preferences specified in PkgInfo.
    var filesInstalled: HashSet[string]
    iterInstallFiles(realDir, pkgInfo, options,
      proc (file: string) =
        createDir(changeRoot(realDir, pkgDestDir, file.splitFile.dir))
        let dest = changeRoot(realDir, pkgDestDir, file)
        filesInstalled.incl copyFileD(file, dest)
    )

    # Copy the .nimble file.
    let dest = changeRoot(pkgInfo.myPath.splitFile.dir, pkgDestDir,
                          pkgInfo.myPath)
    filesInstalled.incl copyFileD(pkgInfo.myPath, dest)

    var binariesInstalled: HashSet[string]
    if pkgInfo.bin.len > 0 and not pkgInfo.basicInfo.name.isNim:
      # Make sure ~/.nimble/bin directory is created.
      createDir(binDir)
      # Set file permissions to +x for all binaries built,
      # and symlink them on *nix OS' to $nimbleDir/bin/
      for bin, src in pkgInfo.bin:
        let binDest =
          # Issue #308
          if dirExists(pkgDestDir / bin):
            bin & ".out"
          else: bin

        if fileExists(pkgDestDir / binDest):
          display("Warning:", ("Binary '$1' was already installed from source" &
                              " directory. Will be overwritten.") % bin, Warning,
                  MediumPriority)

        # Copy the binary file.
        createDir((pkgDestDir / binDest).parentDir())
        filesInstalled.incl copyFileD(pkgInfo.getOutputDir(bin),
                                      pkgDestDir / binDest)

        # Set up a symlink.
        let symlinkDest = pkgDestDir / binDest
        let symlinkFilename = options.getBinDir() / bin.extractFilename
        binariesInstalled.incl(
          setupBinSymlink(symlinkDest, symlinkFilename, options))

    # Update package path to point to installed directory rather than the temp
    # directory.
    pkgInfo.myPath = dest
    pkgInfo.metaData.files = filesInstalled.toSeq
    pkgInfo.metaData.binaries = binariesInstalled.toSeq

    saveMetaData(pkgInfo.metaData, pkgDestDir)
  else:
    display("Warning:", "Skipped copy in project local deps mode", Warning)

  pkgInfo.source = psInstalled

  displaySuccess(pkgInstalledMsg(pkgInfo.basicInfo.name), MediumPriority)

  result.deps.incl pkgInfo
  result.pkg = pkgInfo

  # Run post-install hook now that package is installed. The `execHook` proc
  # executes the hook defined in the CWD, so we set it to where the package
  # has been installed.
  cd pkgInfo.myPath.splitFile.dir:
    discard execHook(nimBin, options, actionInstall, false)

proc installNimToPkgs2*(nimPkgInfo: PackageInfo, options: Options, nimBin: Option[string]): PackageInfo =
  ## Installs nim to pkgs2 directory by copying from nimbinaries.
  ## This ensures nim is available like other packages for dependency resolution.
  ## Only applies to nim installed via nimbinaries, not system nim.
  ## Returns the updated PackageInfo pointing to pkgs2.
  result = nimPkgInfo

  let srcDir = nimPkgInfo.getRealDir()
  if not dirExists(srcDir):
    return

  # Only install nim from nimbinaries, not system nim
  if "nimbinaries" notin srcDir:
    return

  # Compute checksum from lib/ directory (stdlib source - consistent across platforms)
  let libDir = srcDir / "lib"
  if not dirExists(libDir):
    return

  let nimChecksum = calculateDirSha1Checksum(libDir)

  # Build destination path manually since basicInfo.checksum may be empty
  let pkgDestDir = options.getPkgsDir() /
    &"{nimPkgInfo.basicInfo.name}-{nimPkgInfo.basicInfo.version}-{nimChecksum}"

  if not dirExists(pkgDestDir):
    display("Installing", "nim@$1 to pkgs2" % [$nimPkgInfo.basicInfo.version],
            priority = MediumPriority)

    createDir(pkgDestDir)

    # Copy nim files to pkgs2
    for kind, path in walkDir(srcDir):
      let destPath = pkgDestDir / path.extractFilename
      if kind == pcDir:
        copyDir(path, destPath)
      else:
        copyFile(path, destPath)

    # Save metadata
    var metaData = nimPkgInfo.metaData
    if metaData.url == "":
      metaData.url = "https://github.com/nim-lang/Nim.git"
    saveMetaData(metaData, pkgDestDir, changeRoots = false)

    # Transfer file permissions from source bin/ to dest bin/
    # copyFile/copyDir doesn't preserve execute permissions on Linux
    let srcBinDir = srcDir / "bin"
    let destBinDir = pkgDestDir / "bin"
    if dirExists(srcBinDir) and dirExists(destBinDir):
      for binkind, srcBinPath in walkDir(srcBinDir):
        if binkind == pcFile:
          let destBinPath = destBinDir / srcBinPath.extractFilename
          if fileExists(destBinPath):
            setFilePermissions(destBinPath, getFilePermissions(srcBinPath))

  # Return PackageInfo pointing to pkgs2
  result = getPkgInfo(pkgDestDir, options, nimBin, pikRequires)
  result.basicInfo.checksum = nimChecksum
  result.source = psInstalled

proc developWithDependencies(options: Options): bool =
  ## Determines whether the current executed action is a develop sub-command
  ## with `--with-dependencies` flag.
  options.action.typ == actionDevelop and options.action.withDependencies

proc raiseCannotCloneInExistingDirException(downloadDir: string) =
  let msg = "Cannot clone into '$1': directory exists." % downloadDir
  const hint = "Remove the directory, or run this command somewhere else."
  raise nimbleError(msg, hint)

proc install(packages: seq[PkgTuple], options: Options,
             doPrompt, first, fromLockFile: bool,
             nimBin: Option[string] = none(string),
             preferredPackages: seq[PackageInfo] = @[]): PackageDependenciesInfo =
  ## ``first``
  ##   True if this is the first level of the indirect recursion.
  ## ``fromLockFile``
  ##   True if we are installing dependencies from the lock file.
  ## ``preferredPackages``
  ##   Prefer these packages when performing `processFreeDependencies`

  if packages == @[]:
    let currentDir = getCurrentDir()
    if currentDir.developFileExists:
      displayWarning(
        "Installing a package which currently has develop mode dependencies." &
        "\nThey will be ignored and installed as normal packages.")
    result = installFromDir(currentDir, newVRAny(), options, "", first,
                            fromLockFile, nimBin,
                            preferredPackages = preferredPackages)
  else:
    # Install each package.
    for pv in packages:
      let (meth, url, metadata) = getDownloadInfo(pv, options, doPrompt) #TODO dont download if its nim

      let subdir = metadata.getOrDefault("subdir")
      var downloadPath = ""
      if subdir == "": #Ignore the cache if subdir is set
          downloadPath =  getCacheDownloadDir(url, pv.ver, options)
      var nimInstalled = none(NimInstalled)
      if pv.isNim:
        nimInstalled = installNimFromBinariesDir(pv, options)

      let (downloadDir, downloadVersion, vcsRevision) =
        if nimInstalled.isSome():
          (nimInstalled.get().dir, nimInstalled.get().ver, notSetSha1Hash)
        else:
          downloadPkg(url, pv.ver, meth, subdir, options,
                    downloadPath = downloadPath, vcsRevision = notSetSha1Hash, nimBin = nimBin)
      try:
        var opt = options
        if pv.name.isNim:
          if not downloadDir.isSubdirOf(options.nimBinariesDir):
            compileNim(opt, downloadDir, pv.ver)
          opt.useNimFromDir(downloadDir, pv.ver, true)
        result = installFromDir(downloadDir, pv.ver, opt, url,
                                first, fromLockFile, nimBin, vcsRevision,
                                preferredPackages = preferredPackages)
      except BuildFailed as error:
        # The package failed to build.
        # Check if we tried building a tagged version of the package.
        let headVer = getHeadName(meth)
        if pv.ver.kind != verSpecial and downloadVersion != headVer and
           not fromLockFile:
          # If we tried building a tagged version of the package and this is not
          # fixed in the lock file version then ask the user whether they want
          # to try building #head.
          let promptResult = doPrompt and
              options.prompt(("Build failed for '$1@$2', would you" &
                  " like to try installing '$1@#head' (latest unstable)?") %
                  [pv.name, $downloadVersion])
          if promptResult:
            let toInstall = @[(pv.name, headVer.toVersionRange())]
            result =  install(toInstall, options, doPrompt, first,
                              fromLockFile = false, nimBin = nimBin)
          else:
            raise buildFailed(
              "Aborting installation due to build failure.", details = error)
        else:
          raise

proc addPackages(packages: seq[PkgTuple], options: var Options, nimBin: Option[string]) =
  if packages.len == 0:
    raise nimbleError(
      "Expected packages to add to dependencies, got none."
    )

  let
    dir = findNimbleFile(getCurrentDir(), true, options)
    pkgInfo = getPkgInfo(getCurrentDir(), options, nimBin = nimBin)
    pkgList = options.getPackageList()
    deps = pkgInfo.requires

  var 
    appendStr: string
    addedPkgs: seq[string]

  for apkg in packages:
    var 
      exists = false
      version: string

    let isValidUrl = isURL(apkg.name)
    
    for pkg in pkgList:
      if pkg.name == apkg.name:
        exists = true
        version = case apkg.ver.kind
        of verAny:
          ""
        else:
          $apkg.ver
        break
    
    if not exists and not isValidUrl:
      raise nimbleError(
        "No such package \"$1\" was found in the package list." % [apkg.name]
      )
    
    var doAppend = true
    for dep in deps:
      if dep.name.toLowerAscii() == apkg.name.toLowerAscii():
        displayWarning(
          "$1 is already a dependency to $2; ignoring." % [apkg.name, pkgInfo.name]
        )
        doAppend = false
    
    if not doAppend:
      continue

    # Packages are already installed during resolution
    # Get the version from the solved packages
    var finalVer = if version.len < 1:
      var foundVer = ""
      for pkg in options.satResult.pkgs:
        if pkg.basicInfo.name.toLowerAscii() == apkg.name.toLowerAscii():
          foundVer = $pkg.basicInfo.version
          break
      foundVer
    else:
      version

    let prettyStr = apkg.name & '@' & finalVer

    appendStr &= "\nrequires \"$1$2\"" % [
      apkg.name,
      if finalVer != "":
        " >= " & finalVer
      else:
        ""
    ]

    addedPkgs.add(prettyStr)

  let file = open(dir, fmAppend)
  file.write(appendStr)
  file.close()

  for added in addedPkgs:
    display(
      "Added",
      "$1 as a dependency to $2" % [added, pkgInfo.name],
      priority = HighPriority
    )

proc clean(options: Options, nimBin: Option[string]) =
  let dir = getCurrentDir()
  let pkgInfo = getPkgInfo(dir, options, nimBin = nimBin)
  nimScriptHint(pkgInfo)
  cleanFromDir(pkgInfo, nimBin, options)

proc execBackend(pkgInfo: PackageInfo, options: Options, nimBin: Option[string]) =
  let
    bin = options.getCompilationBinary(pkgInfo).get("")
    binDotNim = bin.addFileExt("nim")
  if bin == "":
    raise nimbleError("You need to specify a file.")

  if not (fileExists(bin) or fileExists(binDotNim)):
    raise nimbleError(
      "Specified file, " & bin & " or " & binDotNim & ", does not exist.")

  let pkgInfo = getPkgInfo(getCurrentDir(), options, nimBin = nimBin)
  nimScriptHint(pkgInfo)

  if not execHook(nimBin, options, options.action.typ, true):
    raise nimbleError("Pre-hook prevented further execution.")

  var args = @["-d:NimblePkgVersion=" & $pkgInfo.basicInfo.version]
  for path in options.getPathsAllPkgs(nimBin):
    args.add("--path:" & path.quoteShell)
  if options.verbosity >= HighPriority:
    # Hide Nim hints by default
    args.add("--hints:off")
  if options.verbosity == SilentPriority:
    # Hide Nim warnings
    args.add("--warnings:off")

  for option in options.getCompilationFlags():
    args.add(option.quoteShell)

  let backend =
    if options.action.backend.len > 0:
      options.action.backend
    else:
      pkgInfo.backend

  if options.action.typ == actionCompile:
    display("Compiling", "$1 (from package $2) using $3 backend" %
            [bin, pkgInfo.basicInfo.name, backend], priority = HighPriority)
  else:
    display("Generating", ("documentation for $1 (from package $2) using $3 " &
            "backend") % [bin, pkgInfo.basicInfo.name, backend], priority = HighPriority)

  doCmd("$# $# --noNimblePath $# $# $#" %
        [nimBin.getNimBin.quoteShell,
         backend,
         join(args, " "),
         bin.quoteShell,
         options.action.additionalArguments.map(quoteShell).join(" ")])

  display("Success:", "Execution finished", Success, HighPriority)

  # Run the post hook for action if it exists
  discard execHook(nimBin, options, options.action.typ, false)

proc search(options: Options) =
  ## Searches for matches in ``options.action.search``.
  ##
  ## Searches are done in a case insensitive way making all strings lower case.
  assert options.action.typ == actionSearch
  if options.action.search == @[]:
    raise nimbleError("Please specify a search string.")
  if needsRefresh(options):
    raise nimbleError("Please run nimble refresh.")
  let pkgList = getPackageList(options)
  var found = false
  template onFound {.dirty.} =
    echoPackage(pkg)
    if pkg.alias.len == 0 and options.action.showSearchVersions:
      echoPackageVersions(pkg)
    echo(" ")
    found = true
    break forPkg

  for pkg in pkgList:
    block forPkg:
      for word in options.action.search:
        # Search by name.
        if word.toLower() in pkg.name.toLower():
          onFound()
        # Search by tag.
        for tag in pkg.tags:
          if word.toLower() in tag.toLower():
            onFound()

  if not found:
    display("Error", "No package found.", Error, HighPriority)

proc list(options: Options) =
  if needsRefresh(options):
    raise nimbleError("Please run nimble refresh.")
  let pkgList = getPackageList(options)
  for pkg in pkgList:
    echoPackage(pkg)
    if pkg.alias.len == 0 and options.action.showListVersions:
      echoPackageVersions(pkg)
    echo(" ")

proc listNimBinaries(options: Options) =
  let nimBininstalledPkgs = getInstalledPkgsMin(options.nimBinariesDir, options)
  displayFormatted(Message, "nim")
  displayFormatted(Hint, "\n")
  for idx, pkg in nimBininstalledPkgs:
    assert pkg.basicInfo.name == "nim"
    if idx == nimBininstalledPkgs.len() - 1:
      displayFormatted(Hint, "└── ")
    else:
      displayFormatted(Hint, "├── ")
    displayFormatted(Success, "@" & $pkg.basicInfo.version)
    displayFormatted(Hint, " ")
    displayFormatted(Details, fmt"({pkg.myPath.splitPath().head})")
    displayFormatted(Hint, "\n")
  displayFormatted(Hint, "\n")

proc listInstalled(options: Options) =
  type
    VersionChecksumTuple = tuple[version: Version, checksum: Sha1Hash, special: seq[string], path: string]
  var vers: OrderedTable[string, seq[VersionChecksumTuple]]
  let pkgs = getInstalledPkgsMin(options.getPkgsDir(), options)
  for pkg in pkgs:
    let
      pName = pkg.basicInfo.name
      pVersion = pkg.basicInfo.version
      pChecksum = pkg.basicInfo.checksum
    if not vers.hasKey(pName): vers[pName] = @[]
    var s = vers[pName]
    add(s, (pVersion, pChecksum, pkg.metadata.specialVersions.toSeq().map(v => $v), pkg.getRealDir()))
    vers[pName] = s

  vers.sort(proc (a, b: (string, seq[VersionChecksumTuple])): int =
    cmpIgnoreCase(a[0], b[0]))

  echo("Package list format: \n{PackageName}")
  echo("└── @{Version} ({CheckSum})[Special Versions (if any)] ({InstallPath})")
  for k in keys(vers):
    displayFormatted(Message, k)
    displayFormatted(Hint, "\n")
    if options.action.showListVersions:
      for idx, item in vers[k]:
        if idx == vers[k].len() - 1:
          displayFormatted(Hint, "└── ")
        else:
          displayFormatted(Hint, "├── ")
        displayFormatted(Success, "@", $item.version)
        displayFormatted(Hint, " ")
        displayFormatted(Details, fmt"({item.checksum})")
        if item.special.len > 1:
          displayFormatted(Hint, " ")
          displayFormatted(Details, fmt"""[{item.special.join(", ")}]""")
        displayFormatted(Hint, " ")
        displayFormatted(Details, fmt"({item.path})")
        displayFormatted(Hint, "\n")

type VersionAndPath = tuple[version: Version, path: string]

proc listPaths(options: Options) =
  ## Loops over the specified packages displaying their installed paths.
  ##
  ## If there are several packages installed, all of them will be displayed.
  ## If any package name is not found, the proc displays a missing message and
  ## continues through the list, but at the end quits with a non zero exit
  ## error.
  ##
  ## On success the proc returns normally.

  cli.setSuppressMessages(true)
  assert options.action.typ == actionPath

  if options.action.packages.len == 0:
    raise nimbleError("A package name needs to be specified")

  var errors = 0
  let pkgs = getInstalledPkgsMin(options.getPkgsDir(), options)
  for name, version in options.action.packages.items:
    var installed: seq[VersionAndPath] = @[]
    # There may be several, list all available ones and sort by version.
    for pkg in pkgs:
      if name == pkg.basicInfo.name and withinRange(pkg.basicInfo.version, version):
        installed.add((pkg.basicInfo.version, pkg.getRealDir))

    if installed.len > 0:
      sort(installed, cmp[VersionAndPath], Descending)
      # The output for this command is used by tools so we do not use display().
      for pkg in installed:
        echo pkg.path
    else:
      display("Warning:", "Package '$1' is not installed" % name, Warning,
              MediumPriority)
      errors += 1
  if errors > 0:
    raise nimbleError(
        "At least one of the specified packages was not found")

proc join(x: seq[PkgTuple]; y: string): string =
  if x.len == 0: return ""
  result = x[0][0] & " " & $x[0][1]
  for i in 1 ..< x.len:
    result.add y
    result.add x[i][0] & " " & $x[i][1]

proc getPackageByPattern(pattern: string, options: Options, nimBin: Option[string]): PackageInfo =
  ## Search for a package file using multiple strategies.
  if pattern == "":
    # Not specified - using current directory
    result = getPkgInfo(os.getCurrentDir(), options, nimBin = nimBin)
  elif pattern.splitFile.ext == ".nimble" and pattern.fileExists:
    # project file specified
    result = getPkgInfoFromFile(nimBin, pattern, options)
  elif pattern.dirExists:
    # project directory specified
    result = getPkgInfo(pattern, options, nimBin = nimBin)
  else:
    # Last resort - attempt to read as package identifier
    let packages = getInstalledPkgsMin(options.getPkgsDir(), options)
    let identTuple = parseRequires(pattern)
    var skeletonInfo = initPackageInfo()
    if not findPkg(packages, identTuple, skeletonInfo):
      raise nimbleError(
          "Specified package not found"
      )
    result = getPkgInfoFromFile(nimBin, skeletonInfo.myPath, options)


proc getEntryPoints(pkgInfo: PackageInfo, options: Options): seq[string] =
  ## Returns the entry points for a package. 
  ## This is useful for tools like the lsp.
  let main = pkgInfo.srcDir / pkgInfo.basicInfo.name & ".nim"
  result.add main
  let entries = pkgInfo.entryPoints & pkgInfo.bin.keys.toSeq
  for entry in entries:
    result.add if entry.endsWith(".nim"): entry else: entry & ".nim"
  
proc dump(options: var Options, nimBin: var Option[string]) =
  var p = getPackageByPattern(options.action.projName, options, nimBin)
  if options.action.collect or options.action.solve:
    p.requires &= options.extraRequires
    let pkgList = initPkgList(p, options, nimBin).toSeq()
    if options.action.collect:
      dumpPackageVersionTable(p, pkgList.toSeq(), options, nimBin)
    else:
      dumpSolvedPackages(p, pkgList, options, nimBin)
    quit()

  cli.setSuppressMessages(true)
  var j: JsonNode
  var s: string
  let json = options.dumpMode == kdumpJson
  if json: j = newJObject()
  template fn(key, val) =
    if json:
      when val is seq[PkgTuple]:
        # jsonutils.toJson would work but is only available since 1.3.5, so we
        # do it manually.
        j[key] = newJArray()
        for (name, ver) in val:
          j[key].add %{
            "name": % name,
            # we serialize both: `ver` may be more convenient for tooling
            # (no parsing needed); while `str` is more familiar.
            "str": % $ver,
            "ver": %* ver,
          }
      else:
        j[key] = %*val
    else:
      if s.len > 0: s.add "\n"
      s.add key & ": "
      when val is string:
        s.add val.escape
      else:
        s.add val.join(", ").escape
  fn "name", p.basicInfo.name
  fn "version", $p.basicInfo.version
  fn "nimblePath", p.myPath
  fn "author", p.author
  fn "desc", p.description
  fn "license", p.license
  fn "skipDirs", p.skipDirs
  fn "skipFiles", p.skipFiles
  fn "skipExt", p.skipExt
  fn "installDirs", p.installDirs
  fn "installFiles", p.installFiles
  fn "installExt", p.installExt
  fn "requires", p.requires
  for task, requirements in p.taskRequires:
    fn task & "Requires", requirements
  fn "bin", p.bin.keys.toSeq
  fn "binDir", p.binDir
  fn "srcDir", p.srcDir
  fn "backend", p.backend
  fn "paths", p.paths
  fn "nimDir", getNimDir(options, nimBin)
  fn "entryPoints", p.getEntryPoints(options)
  fn "testEntryPoint", p.testEntryPoint
  if json:
    s = j.pretty
  echo s

proc init(options: Options, nimBin: Option[string]) =
  # Check whether the vcs is installed.
  let vcsBin = options.action.vcsOption
  if vcsBin != "" and findExe(vcsBin, true) == "":
    raise nimbleError("Please install git or mercurial first")

  # Determine the package name.
  let hasProjectName = options.action.projName != ""
  let pkgName =
    if options.action.projName != "":
      options.action.projName
    else:
      os.getCurrentDir().splitPath.tail.toValidPackageName()

  # Validate the package name.
  validatePackageName(pkgName)

  # Determine the package root.
  let pkgRoot =
    if not hasProjectName:
      os.getCurrentDir()
    else:
      os.getCurrentDir() / pkgName

  let nimbleFile = (pkgRoot / pkgName).changeFileExt("nimble")

  if fileExists(nimbleFile):
    let errMsg = "Nimble file already exists: $#" % nimbleFile
    raise nimbleError(errMsg)

  if options.forcePrompts != forcePromptYes:
    display(
      "Info:",
      "Package initialisation requires info which could not be inferred.\n" &
      "Default values are shown in square brackets, press\n" &
      "enter to use them.",
      priority = HighPriority
    )
  display("Using", "$# for new package name" % [pkgName.escape()],
    priority = HighPriority)

  # Determine author by running an external command
  proc getAuthorWithCmd(cmd: string): string =
    let (name, exitCode) = doCmdEx(cmd)
    if exitCode == QuitSuccess and name.len > 0:
      result = name.strip()
      display("Using", "$# for new package author" % [result],
        priority = HighPriority)

  # Determine package author via git/hg or asking
  proc getAuthor(): string =
    if findExe("git") != "":
      result = getAuthorWithCmd("git config --global user.name")
    elif findExe("hg") != "":
      result = getAuthorWithCmd("hg config ui.username")
    if result.len == 0:
      result = promptCustom(options, "Your name?", "Anonymous")
  let pkgAuthor = getAuthor()

  # Declare the src/ directory
  let pkgSrcDir = "src"
  display("Using", "$# for new package source directory" % [pkgSrcDir.escape()],
    priority = HighPriority)

  # Determine the type of package
  let pkgType = promptList(
    options,
    """Package type?
Library - provides functionality for other packages.
Binary  - produces an executable for the end-user.
Hybrid  - combination of library and binary

For more information see https://goo.gl/cm2RX5""",
    ["library", "binary", "hybrid"]
  )

  # Ask for package version.
  let pkgVersion = promptCustom(options, "Initial version of package?", "0.1.0")
  validateVersion(pkgVersion)

  # Ask for description
  let pkgDesc = promptCustom(options, "Package description?",
    "A new awesome nimble package")

  # Ask for license
  # License list is based on:
  # https://www.blackducksoftware.com/top-open-source-licenses
  var pkgLicense = options.promptList(
    """Package License?
This should ideally be a valid SPDX identifier. See https://spdx.org/licenses/.
""", [
    "MIT",
    "GPL-2.0",
    "Apache-2.0",
    "ISC",
    "GPL-3.0",
    "BSD-3-Clause",
    "LGPL-2.1",
    "LGPL-3.0",
    # LGPLv3 with static linking exception https://spdx.org/licenses/LGPL-3.0-linking-exception.html
    "LGPL-3.0-linking-exception",
    "EPL-2.0",
    "AGPL-3.0",
    "EUPL-1.2",
    # This is what npm calls "UNLICENSED" (which is too similar to "Unlicense")
    "Proprietary",
    "Other"
  ])

  if pkgLicense.toLower == "other":
    pkgLicense = promptCustom(options,
      """Package license?
Please specify a valid SPDX identifier.""",
      "MIT"
    )

  if pkgLicense in ["GPL-2.0", "GPL-3.0", "LGPL-2.1", "LGPL-3.0", "AGPL-3.0"]:
    let orLater = options.promptList(
      "\"Or any later version\" clause?", ["Yes", "No"])
    if orLater == "Yes":
      pkgLicense.add("-or-later")
    else:
      pkgLicense.add("-only")

  # Ask for Nim dependency
  let nimDepDef = getNimrodVersion(options, nimBin)
  let pkgNimDep = promptCustom(options, "Lowest supported Nim version?",
    $nimDepDef)
  validateVersion(pkgNimDep)

  createPkgStructure(
    (
      pkgName,
      pkgVersion,
      pkgAuthor,
      pkgDesc,
      pkgLicense,
      pkgSrcDir,
      pkgNimDep,
      pkgType
    ),
    pkgRoot
  )

  # Create a git or hg repo in the new nimble project.
  if vcsBin != "":
    let cmd = fmt"cd {pkgRoot} && {vcsBin} init"
    let ret: tuple[output: string, exitCode: int] = execCmdEx(cmd)
    if ret.exitCode != 0: quit ret.output

    var ignoreFile = if vcsBin == "git": ".gitignore" else: ".hgignore"
    var fd = open(joinPath(pkgRoot, ignoreFile), fmWrite)
    fd.write(pkgName & "\n")
    fd.close()

  display("Success:", "Package $# created successfully" % [pkgName], Success,
    HighPriority)

proc removePackages(pkgs: HashSet[ReverseDependency], options: var Options, nimBin: Option[string]) =
  for pkg in pkgs:
    let pkgInfo = pkg.toPkgInfo(options, nimBin = nimBin)
    case pkg.kind
    of rdkInstalled:
      pkgInfo.removePackage(options, nimBin)
      display("Removed", $pkg, Success, HighPriority)
    of rdkDevelop:
      options.nimbleData.removeRevDep(pkgInfo)

proc collectNames(pkgs: HashSet[ReverseDependency],
                  includeDevelopRevDeps: bool): seq[string] =
  for pkg in pkgs:
    if pkg.kind != rdkDevelop or includeDevelopRevDeps:
      result.add $pkg

proc uninstall(options: var Options, nimBin: Option[string]) =
  if options.action.packages.len == 0:
    raise nimbleError(
        "Please specify the package(s) to uninstall.")

  var pkgsToDelete: HashSet[ReverseDependency]
  # Do some verification.
  for pkgTup in options.action.packages:
    display("Looking", "for $1 ($2)" % [pkgTup.name, $pkgTup.ver],
            priority = HighPriority)
    let installedPkgs = getInstalledPkgsMin(options.getPkgsDir(), options)
    var pkgList = findAllPkgs(installedPkgs, pkgTup)
    if pkgList.len == 0:
      raise nimbleError("Package not found")

    display("Checking", "reverse dependencies", priority = HighPriority)
    for pkg in pkgList:
      # Check whether any packages depend on the ones the user is trying to
      # uninstall.
      if options.uninstallRevDeps:
        getAllRevDeps(options.nimbleData, pkg.toRevDep, pkgsToDelete)
      else:
        let revDeps = options.nimbleData.getRevDeps(pkg.toRevDep)
        if len(revDeps - pkgsToDelete) > 0:
          let pkgs = revDeps.collectNames(true)
          displayWarning(
            cannotUninstallPkgMsg(pkgTup.name, pkg.basicInfo.version, pkgs))
        else:
          pkgsToDelete.incl pkg.toRevDep

  if pkgsToDelete.len == 0:
    raise nimbleError("Failed uninstall - no packages to delete")

  if not options.prompt(pkgsToDelete.collectNames(false).promptRemovePkgsMsg):
    raise nimbleQuit()

  removePackages(pkgsToDelete, options, nimBin)

proc listTasks(options: Options, nimBin: Option[string]) =
  let nimbleFile = findNimbleFile(getCurrentDir(), true, options)
  nimscriptwrapper.listTasks(nimBin, nimbleFile, options)

proc saveLinkFile(pkgInfo: PackageInfo, options: Options) =
  let
    pkgName = pkgInfo.basicInfo.name
    pkgLinkDir = options.getPkgsLinksDir / pkgName.getLinkFileDir
    pkgLinkFilePath = pkgLinkDir / pkgName.getLinkFileName
    pkgLinkFileContent = pkgInfo.myPath & "\n" & pkgInfo.getNimbleFileDir

  if pkgLinkDir.dirExists and not options.prompt(
    &"The link file for {pkgName} already exists. Overwrite?"):
    return

  pkgLinkDir.createDir
  writeFile(pkgLinkFilePath, pkgLinkFileContent)
  displaySuccess(pkgLinkFileSavedMsg(pkgLinkFilePath))

proc developFromDir(pkgInfo: PackageInfo, options: var Options, topLevel = false, nimBin: Option[string]) =
  assert options.action.typ == actionDevelop,
    "This procedure should be called only when executing develop sub-command."

  let dir = pkgInfo.getNimbleFileDir()

  if options.depsOnly:
    raise nimbleError("Cannot develop dependencies only.")

  cd dir: # Make sure `execHook` executes the correct .nimble file.
    if not execHook(nimBin, options, actionDevelop, true):
      raise nimbleError("Pre-hook prevented further execution.")

  if pkgInfo.bin.len > 0:
    displayWarning(
      "This package's binaries will not be compiled for development.")

  # Dependencies are resolved by the SAT solver
  # (via solvePkgs + setup after develop completes)

  if options.action.global:
    saveLinkFile(pkgInfo, options)

  displaySuccess(pkgSetupInDevModeMsg(pkgInfo.basicInfo.name, dir))

  # Execute the post-develop hook.
  cd dir:
    discard execHook(nimBin, options, actionDevelop, false)

proc installDevelopPackage(pkgTup: PkgTuple, options: var Options, nimBinParam: Option[string]):
    PackageInfo =
  var nimBin = nimBinParam
  let (meth, url, metadata) = getDownloadInfo(pkgTup, options, true)
  let subdir = metadata.getOrDefault("subdir")
  let downloadDir = getDevelopDownloadDir(url, subdir, options)

  if dirExists(downloadDir):
    if options.developWithDependencies:
      displayWarning(skipDownloadingInAlreadyExistingDirectoryMsg(
        downloadDir, pkgTup.name))
      var pkgInfo: PackageInfo
      withNimBinFallback(nimBin, options):
        pkgInfo = getPkgInfo(downloadDir, options, nimBin = nimBin)
      developFromDir(pkgInfo, options, nimBin = nimBin)
      options.action.devActions.add(
        (datAdd, pkgInfo.getNimbleFileDir.normalizedPath))
      return pkgInfo
    else:
      raiseCannotCloneInExistingDirException(downloadDir)


  # Download the HEAD and make sure the full history is downloaded.
  let ver =
    if pkgTup.ver.kind == verAny:
      parseVersionRange("#head")
    else:
      pkgTup.ver

  discard downloadPkg(url, ver, meth, subdir, options, downloadDir,
                      vcsRevision = notSetSha1Hash, nimBin = nimBin)

  let pkgDir = downloadDir / subdir
  var pkgInfo: PackageInfo
  withNimBinFallback(nimBin, options):
    pkgInfo = getPkgInfo(pkgDir, options, nimBin = nimBin)

  developFromDir(pkgInfo, options, nimBin = nimBin)
  options.action.devActions.add(
    (datAdd, pkgInfo.getNimbleFileDir.normalizedPath))

  # Create nimbledeps/ marker inside developed package for localdeps mode
  if options.localdeps:
    createDir(pkgInfo.getNimbleFileDir() / nimbledepsFolderName)

  return pkgInfo

proc updateSyncFile(dependentPkg: PackageInfo, options: Options, nimBin: Option[string])

proc updatePathsFile(pkgInfo: PackageInfo, options: Options, nimBin: Option[string]) =
  var paths = initHashSet[seq[string]]()
  for path in options.getPathsAllPkgs(nimBin):
    paths.incl @[path]
  var pathsFileContent = "--noNimblePath\n"
  for path in paths:
    for p in path:
      pathsFileContent &= &"--path:{p.escape}\n"
  var action = if fileExists(nimblePathsFileName): "updated" else: "generated"
  writeFile(nimblePathsFileName, pathsFileContent)
  var msgPriority = if options.action.typ == actionSetup: HighPriority else: LowPriority
  displayInfo(&"\"{nimblePathsFileName}\" is {action}.", msgPriority)

proc develop(options: var Options, nimBinParam: Option[string]) =
  var nimBin = nimBinParam
  if options.action.path.len == 0:
    # If no path is provided, use the vendor folder as default
    options.action.path = defaultDevelopPath
  let
    hasPackages = options.action.packages.len > 0
    hasPath = options.action.path.len > 0
    isDefaultPath = options.action.path == defaultDevelopPath
    hasDevActions = options.action.devActions.len > 0
    hasDevFile = options.developFile.len > 0
    withDependencies = options.action.withDependencies

  var
    currentDirPkgInfo = initPackageInfo()
    hasError = false

  try:
    # Check whether the current directory is a package directory.
    # getPkgInfo with pikFull needs a nim binary for VM parsing, so ensure
    # bootstrap is resolved before calling it.
    if nimBin.isNone:
      nimBin = some(ensureBootstrapNim(options))
    currentDirPkgInfo = getPkgInfo(getCurrentDir(), options, nimBin = nimBin)
  except CatchableError as error:
    if hasDevActions and not hasDevFile:
      raise nimbleError(developOptionsWithoutDevelopFileMsg, details = error)

  if withDependencies and not hasPackages and not currentDirPkgInfo.isLoaded:
    raise nimbleError(developWithDependenciesWithoutPackagesMsg)

  if hasPath and not isDefaultPath and not hasPackages and
     (not currentDirPkgInfo.isLoaded or not withDependencies):
    raise nimbleError(pathGivenButNoPkgsToDownloadMsg)

  if currentDirPkgInfo.isLoaded and (not hasPackages) and (not hasDevActions):
    developFromDir(currentDirPkgInfo, options, topLevel = true, nimBin = nimBin)

  # Clone each explicitly requested package.
  # Dependencies are NOT traversed here — when --with-dependencies is set,
  # the SAT solver resolves deps and developFromSolution clones them.
  for pkgTup in options.action.packages:
    try:
      discard installDevelopPackage(pkgTup, options, nimBin)
    except CatchableError as error:
      hasError = true
      displayError(&"Cannot install package \"{pkgTup}\" for develop.")
      displayDetails(error)

  if currentDirPkgInfo.isLoaded and not hasDevFile:
    options.developFile = developFileName

  if options.developFile.len > 0:
    hasError = not updateDevelopFile(currentDirPkgInfo, options, nimBin) or hasError
    if currentDirPkgInfo.isLoaded and
       options.developFile == developFileName:
      # If we are updated package's develop file we have to update also
      # sync and paths files.
      updateSyncFile(currentDirPkgInfo, options, nimBin)
      if fileExists(nimblePathsFileName):
        updatePathsFile(currentDirPkgInfo, options, nimBin)

  if hasError:
    raise nimbleError(
      "There are some errors while executing the operation.",
      "See the log above for more details.")

proc test(options: Options, nimBin: Option[string]) =
  ## Executes all tests starting with 't' in the ``tests`` directory.
  ## Subdirectories are not walked.
  var pkgInfo = getPkgInfo(getCurrentDir(), options, nimBin = nimBin)

  var
    files = toSeq(walkDir(getCurrentDir() / "tests"))
    tests, failures: int

  if pkgInfo.testEntryPoint != "" :
    if fileExists(pkgInfo.testEntryPoint):
      displayInfo("Using test entry point: " & pkgInfo.testEntryPoint, HighPriority)
      files = @[(kind: pcFile, path: pkgInfo.testEntryPoint)]
    else:
      raise nimbleError("Test entry point not found: " & pkgInfo.testEntryPoint)

  if files.len < 1:
    display("Warning:", "No tests found!", Warning, HighPriority)
    return

  if not execHook(nimBin, options, actionCustom, true):
    raise nimbleError("Pre-hook prevented further execution.")

  files.sort((a, b) => cmp(a.path, b.path))

  for file in files:
    let (_, name, ext) = file.path.splitFile()
    if ext == ".nim" and name[0] == 't' and file.kind in {pcFile, pcLinkToFile}:
      var optsCopy = options
      optsCopy.action = Action(typ: actionCompile)
      optsCopy.action.file = file.path
      optsCopy.action.additionalArguments = options.action.arguments
      optsCopy.action.backend = pkgInfo.backend
      optsCopy.getCompilationFlags() = options.getCompilationFlags()
      # treat run flags as compile for default test task
      optsCopy.getCompilationFlags().add(options.action.custRunFlags.filterIt(it != "--continue" and it != "-c"))
      optsCopy.getCompilationFlags().add("-r")
      optsCopy.getCompilationFlags().add("--path:.")
      let
        binFileName = file.path.changeFileExt(ExeExt)
        existsBefore = fileExists(binFileName)

      if options.continueTestsOnFailure:
        inc tests
        try:
          execBackend(pkgInfo, optsCopy, nimBin)
        except NimbleError:
          inc failures
      else:
        execBackend(pkgInfo, optsCopy, nimBin)

      let
        existsAfter = fileExists(binFileName)
        canRemove = not existsBefore and existsAfter
      if canRemove:
        try:
          removeFile(binFileName)
        except OSError as exc:
          display("Warning:", "Failed to delete " & binFileName & ": " &
                  exc.msg, Warning, MediumPriority)

  if failures == 0:
    display("Success:", "All tests passed", Success, HighPriority)
  else:
    let error = "Only " & $(tests - failures) & "/" & $tests & " tests files passed"
    display("Error:", error, Error, HighPriority)

  if not execHook(nimBin, options, actionCustom, false):
    return

proc notInRequiredRangeMsg*(dependentPkg, dependencyPkg: PackageInfo,
                            versionRange: VersionRange): string =
  notInRequiredRangeMsg(dependencyPkg.basicInfo.name, dependencyPkg.getNimbleFileDir,
    $dependencyPkg.basicInfo.version, dependentPkg.basicInfo.name, dependentPkg.getNimbleFileDir,
    $versionRange)

proc validateDevelopDependenciesVersionRanges(dependentPkg: PackageInfo,
    dependencies: seq[PackageInfo], options: Options, nimBin: Option[string]) =
  let allPackages = concat(@[dependentPkg], dependencies)
  let developDependencies = processDevelopDependencies(dependentPkg, options, nimBin)
  var errors: seq[string]
  for pkg in allPackages:
    for dep in pkg.requires:
      if dep.ver.kind == verSpecial or dep.ver.kind == verAny:
        # Develop packages versions are not being validated against the special
        # versions in the Nimble files requires clauses, because there is no
        # special versions for develop mode packages. If special version is
        # required then any version for the develop package is allowed.
        # Also skip validation for verAny (any version) requirements.
        continue
      var depPkg = initPackageInfo()
      if not findPkg(developDependencies, dep, depPkg):
        # This dependency is not part of the develop mode dependencies.
        continue
      if not withinRange(depPkg, dep.ver):
        errors.add notInRequiredRangeMsg(pkg, depPkg, dep.ver)
  if errors.len > 0:
    raise nimbleError(invalidDevelopDependenciesVersionsMsg(errors))

proc validateParsedDependencies(pkgInfo: PackageInfo, options: Options, nimBin: Option[string]) =
  displayInfo(&"Validating dependencies for pkgInfo {pkgInfo.infoKind}", HighPriority)
  let declDeps = pkgInfo.toRequiresInfo(options, nimBin).requires
  let vmDeps = pkgInfo.toFullInfo(options, nimBin).requires
  displayInfo(&"Parsed declarative dependencies: {declDeps}", HighPriority)
  displayInfo(&"Parsed VM dependencies: {vmDeps}", HighPriority)
  if declDeps != vmDeps:
    raise nimbleError(&"Parsed declarative and VM dependencies are not the same: {declDeps} != {vmDeps}")

proc check(options: Options, nimBin: Option[string]) =
  try:
    let currentDir = getCurrentDir()
    let pkgInfo = getPkgInfo(currentDir, options, nimBin = nimBin, forValidation = true)
    validateDevelopFile(pkgInfo, options, nimBin)
    let dependencies = options.satResult.pkgs.toSeq
    validateDevelopDependenciesVersionRanges(pkgInfo, dependencies, options, nimBin)
    validateParsedDependencies(pkgInfo, options, nimBin)
    displaySuccess(&"The package \"{pkgInfo.basicInfo.name}\" is valid.")
  except CatchableError as error:
    displayError(error)
    display("Failure:", validationFailedMsg, Error, HighPriority)
    raise nimbleQuit(QuitFailure)

proc updateSyncFile(dependentPkg: PackageInfo, options: Options, nimBin: Option[string]) =
  # Updates the sync file with the current VCS revisions of develop mode
  # dependencies of the package `dependentPkg`.

  let developDeps = processDevelopDependencies(dependentPkg, options, nimBin).toHashSet
  let syncFile = getSyncFile(dependentPkg)

  # Remove old data from the sync file
  syncFile.clear

  # Add all current develop packages' VCS revisions to the sync file.
  for dep in developDeps:
    syncFile.setDepVcsRevision(dep.basicInfo.name, dep.metaData.vcsRevision)

  syncFile.save

proc validateDevModeDepsWorkingCopiesBeforeLock(
    pkgInfo: PackageInfo, options: Options, nimBin: Option[string]): ValidationErrors =
  ## Validates that the develop mode dependencies states are suitable for
  ## locking. They must be under version control, their working copies must be
  ## in a clean state and their current VCS revision must be present on some of
  ## the configured remotes.

  findValidationErrorsOfDevDepsWithLockFile(pkgInfo, options, result, nimBin)

  # Those validation errors are not errors in the context of generating a lock
  # file.
  const notAnErrorSet = {
    vekWorkingCopyNeedsSync,
    vekWorkingCopyNeedsLock,
    vekWorkingCopyNeedsMerge,
    }

  # Remove not errors from the errors set.
  for name, error in common.dup(result):
    if error.kind in notAnErrorSet:
      result.del name

proc displayLockOperationStart(lockFile: string): bool =
  ## Displays a proper log message for starting generating or updating the lock
  ## file of a package in directory `dir`.

  var doesLockFileExist = lockFile.fileExists
  let msg = if doesLockFileExist:
    updatingTheLockFileMsg
  else:
    generatingTheLockFileMsg
  displayInfo(msg)
  return doesLockFileExist

proc displayLockOperationFinish(didLockFileExist: bool) =
  ## Displays a proper log message for finished generation or update of a lock
  ## file.

  let msg = if didLockFileExist:
    lockFileIsUpdatedMsg
  else:
    lockFileIsGeneratedMsg
  displaySuccess(msg)

proc check(errors: ValidationErrors, graph: LockFileDeps) =
  ## Checks that the dependency graph has no errors
  # throw error only for dependencies that are part of the graph
  var err = errors
  for name, error in errors:
    if name notin graph:
      err.del name

  if err.len > 0:
    raise validationErrors(err)

proc lock(options: var Options, nimBin: Option[string]) =
  ## Generates a lock file for the package in the current directory or updates
  ## it if it already exists.  
  let currentDir = getCurrentDir()
  
  let
    pkgInfo = options.satResult.rootPackage
    currentLockFile = options.lockFile(currentDir)
    lockExists = displayLockOperationStart(currentLockFile)

  var baseDeps = options.satResult.pkgs.toSeq

  if options.useSystemNim:
    baseDeps = baseDeps.filterIt(not it.name.isNim)

  pkgInfo.validateDevelopDependenciesVersionRanges(baseDeps, options, nimBin)

  var
    errors = validateDevModeDepsWorkingCopiesBeforeLock(pkgInfo, options, nimBin)
    lockDeps: AllLockFileDeps

  lockDeps[noTask] = LockFileDeps()

  block:
    # Check for develop dependency validation errors
    # Create a minimal graph for error checking - only include actual dependencies, not root package
    #TODO Some errors are not checked here.
    var depGraph: LockFileDeps
    let rootPkgName = pkgInfo.basicInfo.name
    let rootReqNim = pkgInfo.requires.anyIt(it.isNim)
    #Only add nim to the lock file when root requires Nim
    var shouldAddNim = not options.useSystemNim and rootReqNim

    for solvedPkg in options.satResult.solvedPkgs:
      if (not solvedPkg.pkgName.isNim or (shouldAddNim and solvedPkg.pkgName.isNim)) and solvedPkg.pkgName != rootPkgName:
        depGraph[solvedPkg.pkgName] = LockFileDep()  # Minimal entry for error checking
    errors.check(depGraph)
    for solvedPkg in options.satResult.solvedPkgs:
      if solvedPkg.pkgName.isNim and not shouldAddNim: continue
      if solvedPkg.pkgName == rootPkgName: continue
      
      # Get the PackageInfo for this solved package
      let pkgInfo = 
        if solvedPkg.pkgName.isFileURL:
          getPkgInfo(solvedPkg.pkgName.extractFilePathFromURL(), options, nimBin, pikRequires)
        else:
          options.satResult.getPkgInfoFromSolved(solvedPkg, options)
      var vcsRevision = pkgInfo.metaData.vcsRevision
      
      # For develop mode dependencies, ensure VCS revision is set from working copy
      if (pkgInfo.isLink or (vcsRevision == notSetSha1Hash and pkgInfo.getRealDir().dirExists())) and vcsRevision == notSetSha1Hash:
        try:
          vcsRevision = getVcsRevision(pkgInfo.getRealDir())
        except CatchableError:
          discard
      var lockUrl = pkgInfo.metaData.url
      if lockUrl == "":
        lockUrl = nimblesat.getUrlFromPkgName(solvedPkg.pkgName, options.satResult.pkgVersionTable, options)
      # Fallback for nim when no metadata URL is available (e.g., system nim or old binaries installation)
      if lockUrl == "" and solvedPkg.pkgName.isNim:
        lockUrl = "https://github.com/nim-lang/Nim.git"

      var lockChecksum = pkgInfo.basicInfo.checksum

      # For nim with missing metadata, resolve vcsRevision and checksum
      if solvedPkg.pkgName.isNim and lockUrl != "":
        # Resolve vcsRevision from git remote if not set
        if vcsRevision == notSetSha1Hash:
          let versionTag = "v" & $solvedPkg.version
          try:
            vcsRevision = download.getRevision(lockUrl, versionTag)
          except CatchableError:
            displayWarning(&"Could not resolve git revision for nim {solvedPkg.version}")

        # Compute checksum from lib/ directory only (stdlib source)
        # This is consistent across platforms unlike compiled binaries
        if lockChecksum == notSetSha1Hash:
          let libDir = pkgInfo.getRealDir() / "lib"
          if libDir.dirExists():
            try:
              lockChecksum = calculateDirSha1Checksum(libDir)
            except CatchableError:
              displayWarning(&"Could not compute checksum for nim stdlib at {libDir}")

      lockDeps[noTask][pkgInfo.basicInfo.name] = LockFileDep(
        version: solvedPkg.version,
        vcsRevision: vcsRevision,
        url: lockUrl,
        downloadMethod: pkgInfo.metaData.downloadMethod,
        dependencies: solvedPkg.requirements.mapIt(it.name),
        checksums: Checksums(sha1: lockChecksum))
    
    for task in pkgInfo.taskRequires.keys:
      lockDeps[task] = LockFileDeps()
      for (taskDep, _) in pkgInfo.taskRequires[task]:
        for solvedPkg in options.satResult.solvedPkgs:
          if solvedPkg.pkgName == taskDep:
            #Now we have to pick the dep from above
            var found = false
            for key, value in lockDeps[noTask]:
              if key == taskDep:
                lockDeps[task][key] = value
                found = true
                break
            if found: 
              lockDeps[noTask].del(taskDep)
    
    writeLockFile(currentLockFile, lockDeps)
  updateSyncFile(pkgInfo, options, nimBin)
  displayLockOperationFinish(lockExists)

proc depsPrint(options: Options,
              pkgInfo: PackageInfo,
              dependencies: seq[PackageInfo],
              errors: ValidationErrors) =
  ## Prints the dependency tree

  if options.action.format == "json":
    if options.action.depsAction == "inverted":
      raise nimbleError("Deps JSON format does not support inverted tree")
    echo (%depsRecursive(pkgInfo, dependencies, errors)).pretty
  elif options.action.depsAction == "inverted":
    printDepsHumanReadableInverted(pkgInfo, dependencies, errors)
  elif options.action.depsAction == "tree":
    printDepsHumanReadable(pkgInfo, dependencies, errors)
  else:
    printDepsHumanReadable(pkgInfo, dependencies, errors, true)

proc deps(options: Options, nimBin: Option[string]) =
  ## handles deps actions
  let pkgInfo = getPkgInfo(getCurrentDir(), options, nimBin = nimBin)

  var errors = validateDevModeDepsWorkingCopiesBeforeLock(pkgInfo, options, nimBin)
  var dependencies = options.satResult.pkgs.toSeq
  let depNames = dependencies.mapIt(it.basicInfo.name).toHashSet
  # delete errors for dependencies that aren't part of the solution
  for name, error in common.dup errors:
    if name notin depNames:
      errors.del name

  if options.action.depsAction in ["", "tree", "inverted"]:
    depsPrint(options, pkgInfo, dependencies, errors)
  else:
    raise nimbleError("Unknown deps flag: " & options.action.depsAction)

proc syncWorkingCopy(name: string, path: Path, dependentPkg: PackageInfo,
                     options: Options) =
  ## Syncs a working copy of a develop mode dependency of package `dependentPkg`
  ## with name `name` at path `path` with the revision from the lock file of
  ## `dependentPkg`.

  if options.offline:
    raise nimbleError("Cannot sync in offline mode.")

  displayInfo(&"Syncing working copy of package \"{name}\" at \"{path}\"...")

  let lockedDeps = dependentPkg.lockedDeps[noTask]
  assert lockedDeps.hasKey(name),
         &"Package \"{name}\" must be present in the lock file."

  let vcsRevision = lockedDeps[name].vcsRevision
  assert vcsRevision != path.getVcsRevision,
        "If here the working copy VCS revision must be different from the " &
        "revision written in the lock file."

  try:
    if not isVcsRevisionPresentOnSomeBranch(path, vcsRevision):
      # If the searched revision is not present on some local branch retrieve
      # changes sets from the remote branch corresponding to the local one.
      let (remote, branch) = getCorrespondingRemoteAndBranch(path)
      retrieveRemoteChangeSets(path, remote, branch)

    if not isVcsRevisionPresentOnSomeBranch(path, vcsRevision):
      # If the revision is still not found retrieve all remote change sets.
      retrieveRemoteChangeSets(path)

    let
      currentBranch = getCurrentBranch(path)
      localBranches = getBranchesOnWhichVcsRevisionIsPresent(
        path, vcsRevision, btLocal)
      remoteTrackingBranches = getBranchesOnWhichVcsRevisionIsPresent(
        path, vcsRevision, btRemoteTracking)
      allBranches = localBranches + remoteTrackingBranches

    var targetBranch =
      if allBranches.len == 0:
        # Te revision is not found on any branch.
        ""
      elif localBranches.len == 1:
        # If the revision is present on only one local branch switch to it.
        localBranches.toSeq[0]
      elif localBranches.contains(currentBranch):
        # If the current branch is among the local branches on which the
        # revision is found we have to stay to it.
        currentBranch
      elif remoteTrackingBranches.len == 1:
        # If the revision is found on only one remote tracking branch we have to
        # fast forward merge it to a corresponding local branch and to switch to
        # it.
        remoteTrackingBranches.toSeq[0]
      elif (let (hasBranch, branchName) = hasCorrespondingRemoteBranch(
              path, remoteTrackingBranches); hasBranch):
        # If the current branch has corresponding remote tracking branch on
        # which the revision is found we have to get the name of the remote
        # tracking branch in order to try to fast forward merge it to the local
        # branch.
        branchName
      else:
        # If the revision is found on several branches, but nighter of them is
        # the current one or a remote tracking branch corresponding to the
        # current one then give the user a choice to which branch to switch.
        options.promptList(
          &"The revision \"{vcsRevision}\" is found on multiple branches.\n" &
          "Choose a branch to switch to:",
          allBranches.toSeq.toOpenArray(0, allBranches.len - 1))

    if path.getVcsType == vcsTypeGit and
       remoteTrackingBranches.contains(targetBranch):
      # If the target branch is a remote tracking branch get all local branches
      # which track it.
      let localBranches = getLocalBranchesTrackingRemoteBranch(
        path, targetBranch)
      let localBranch =
        if localBranches.len == 0:
          # There is no local branch tracking the remote branch and we have to
          # get a name for a new branch.
          getLocalBranchName(path, targetBranch)
        elif localBranches.len == 1:
          # There is only one local branch tracking the remote branch.
          localBranches[0]
        else:
          # If there are multiple local branches which track the remote branch
          # then give the user a choice to which to try to fast forward merge
          # the remote branch.
          options.promptList("Choose local branch where to try to fast " &
                             &"forward merge \"{targetBranch}\":",
            localBranches.toOpenArray(0, localBranches.len - 1))
      fastForwardMerge(path, targetBranch, localBranch)
      targetBranch = localBranch

    if targetBranch != "":
      if targetBranch != currentBranch:
        switchBranch(path, targetBranch)
      if path.getVcsRevision != vcsRevision:
        setCurrentBranchToVcsRevision(path, vcsRevision)
    else:
      # If the revision is not found on any branch try to set the package
      # working copy to it in detached state. If the revision is completely
      # missing the operation will fail with exception.
      setWorkingCopyToVcsRevision(path, vcsRevision)

    displayInfo(pkgWorkingCopyIsSyncedMsg(name, $path))
  except CatchableError as error:
    displayError(&"Working copy of package \"{name}\" at path \"{path}\" " &
                  "cannot be synced.")
    displayDetails(error.msg)

proc sync(options: Options, nimBin: Option[string]) =
  # Syncs working copies of the develop mode dependencies of the current
  # directory package with the revision data from the lock file.

  let pkgInfo = options.satResult.rootPackage

  if not pkgInfo.areLockedDepsLoaded:
    raise nimbleError("Cannot execute `sync` when lock file is missing.")

  if options.offline:
    raise nimbleError("Cannot execute `sync` in offline mode.")

  if not options.action.listOnly:
    # On `sync` we also want to update Nimble cache with the dependencies'
    # versions from the lock file.
    discard options.satResult.pkgs # deps already resolved by SAT
    if fileExists(nimblePathsFileName):
      updatePathsFile(pkgInfo, options, nimBin)

  var errors: ValidationErrors
  findValidationErrorsOfDevDepsWithLockFile(pkgInfo, options, errors, nimBin)

  for name, error in common.dup(errors):
    if not pkgInfo.lockedDeps.hasPackage(name):
      errors.del name
    elif error.kind == vekWorkingCopyNeedsSync:
      if not options.action.listOnly:
        syncWorkingCopy(name, error.path, pkgInfo, options)
      else:
        displayInfo(pkgWorkingCopyNeedsSyncingMsg(name, $error.path))
      # Remove sync errors because we are doing sync.
      errors.del name

  updateSyncFile(pkgInfo, options, nimBin)

  if errors.len > 0:
    raise validationErrors(errors)

proc append(existingContent: var string; newContent: string) =
  ## Appends `newContent` to the `existingContent` on a new line by inserting it
  ## if the new line doesn't already exist.
  if existingContent.len > 0 and existingContent[^1] != '\n':
    existingContent &= "\n"
  existingContent &= newContent

proc setupNimbleConfig(options: Options, nimBin: Option[string]) =
  ## Creates `nimble.paths` file containing file system paths to the
  ## dependencies. Includes it in `config.nims` file to make them available
  ## for the compiler.
  const
    configFileVersion = 2
    sectionEnd = "# end Nimble config"
    sectionStart = "# begin Nimble config"
    configFileHeader = &"# begin Nimble config (version {configFileVersion})"
    configFileContentNoLock = fmt"""
{configFileHeader}
when withDir(thisDir(), system.fileExists("{nimblePathsFileName}")):
  include "{nimblePathsFileName}"
{sectionEnd}
"""
    configFileContentWithLock = fmt"""
{configFileHeader}
--noNimblePath
when withDir(thisDir(), system.fileExists("{nimblePathsFileName}")):
  include "{nimblePathsFileName}"
{sectionEnd}
"""

  let
    currentDir = getCurrentDir()
    pkgInfo = getPkgInfo(currentDir, options, nimBin = nimBin)
    lockFileExists = options.lockFile(currentDir).fileExists
    configFileContent = if lockFileExists: configFileContentWithLock
                        else: configFileContentNoLock

  updatePathsFile(pkgInfo, options, nimBin)

  var
    writeFile = false
    fileContent: string

  if fileExists(nimbleConfigFileName):
    fileContent = readFile(nimbleConfigFileName)
    if not fileContent.contains(configFileContent):
      let
        startIndex = fileContent.find(sectionStart)
        endIndex = fileContent.find(sectionEnd)
      if startIndex >= 0 and endIndex >= 0:
        fileContent = fileContent[0..<startIndex] & configFileContent[0 ..< ^1] & fileContent[endIndex + sectionEnd.len .. ^1]
      else:
        fileContent.append(configFileContent)
      writeFile = true
  else:
    fileContent.append(configFileContent)
    writeFile = true
  
  var msgPriority = if options.action.typ == actionSetup: HighPriority else: LowPriority
  if writeFile:
    writeFile(nimbleConfigFileName, fileContent)
    displayInfo(&"\"{nimbleConfigFileName}\" is set up.", msgPriority)
  else:
    displayInfo(&"\"{nimbleConfigFileName}\" is already set up.", msgPriority)

proc setupVcsIgnoreFile =
  ## Adds the names of some files which should not be committed to the VCS
  ## ignore file.
  let
    currentDir = getCurrentDir()
    vcsIgnoreFileName = case currentDir.getVcsType
      of vcsTypeGit: gitIgnoreFileName
      of vcsTypeHg: hgIgnoreFileName
      of vcsTypeNone: ""

  if vcsIgnoreFileName.len == 0:
    return

  var
    writeFile = false
    fileContent: string

  if fileExists(vcsIgnoreFileName):
    fileContent = readFile(vcsIgnoreFileName)
    if not fileContent.contains(developFileName):
      fileContent.append(developFileName)
      writeFile = true
    if not fileContent.contains(nimblePathsFileName):
      fileContent.append(nimblePathsFileName)
      writeFile = true
    if not fileContent.contains(nimbledepsFolderName):  
      fileContent.append(nimbledepsFolderName)
      writeFile = true
  else:
    fileContent.append(developFileName)
    fileContent.append(nimblePathsFileName)
    fileContent.append(nimbledepsFolderName)
    writeFile = true

  if writeFile:
    writeFile(vcsIgnoreFileName, fileContent & "\n")

proc setup(options: Options, nimBin: Option[string]) =
  setupNimbleConfig(options, nimBin)
  setupVcsIgnoreFile()

proc getAlteredPath(options: Options, nimBin: Option[string]): string =
  let pkgInfo = options.satResult.rootPackage
  var pkgs = options.satResult.pkgs.toSeq.toOrderedSet
  pkgs.incl(pkgInfo)

  var paths: seq[string] = @[]
  for pkg in pkgs:
    for bin, _ in pkg.bin:
      let folder = pkg.getOutputDir(bin).parentDir.quoteShell
      paths.add folder
  paths.reverse
  let parentDir = nimBin.getNimBin.parentDir
  result = fmt "{getAppDir()}{separator}{paths.join(separator)}{separator}{parentDir}{separator}{getEnv(\"PATH\")}"

proc shellenv(options: var Options, nimBin: Option[string]) =
  setVerbosity(SilentPriority)
  options.verbosity = SilentPriority
  const prefix = when defined(windows): "set PATH=" else: "export PATH="
  echo prefix & getAlteredPath(options, nimBin)

proc shell(options: Options, nimBin: Option[string]) =
  putEnv("PATH", getAlteredPath(options, nimBin))

  when defined windows:
    var shell = getEnv("ComSpec")
    if shell == "": shell = "powershell"
  else:
    var shell = getEnv("SHELL")
    if shell == "": shell = "bash"

  discard waitForExit startProcess(shell, options = {poParentStreams, poUsePath})

proc getPackageForAction(pkgInfo: PackageInfo, options: Options, nimBin: Option[string]): PackageInfo =
  ## Returns the `PackageInfo` for the package in `pkgInfo`'s dependencies tree
  ## with the name specified in `options.package`. If `options.package` is empty
  ## or it matches the name of the `pkgInfo` then `pkgInfo` is returned. Raises
  ## a `NimbleError` if the package with the provided name is not found.

  result = initPackageInfo()

  if options.package.len == 0 or pkgInfo.basicInfo.name == options.package:
    return pkgInfo

  # Search through the SAT result packages as the packages are already solved
  for pkg in options.satResult.pkgs:
    if pkg.basicInfo.name == options.package:
      var fullPkg = getPkgInfo(pkg.getRealDir(), options, nimBin = nimBin)
      # Explicitly check for develop mode conditions
      if fullPkg.developFileExists or not fullPkg.myPath.startsWith(options.getPkgsDir):
        fullPkg.source = psDevelop
      return fullPkg

  raise nimbleError(notFoundPkgWithNameInPkgDepTree(options.package))

proc runAction(options: Options, nimBin: Option[string]) =
  ## Handles `actionRun`: runs a compiled binary from the current package.
  var pkgInfo: PackageInfo
  pkgInfo = options.satResult.rootPackage
  pkgInfo = getPackageForAction(pkgInfo, options, nimBin)

  let binary = options.getCompilationBinary(pkgInfo).get("")
  if binary.len == 0:
    raise nimbleError("Please specify a binary to run")

  if binary notin pkgInfo.bin:
    raise nimbleError(binaryNotDefinedInPkgMsg(binary, pkgInfo.basicInfo.name))

  if pkgInfo.isLink:
    # Use buildPkg for develop mode packages
    let isInRootDir = options.startDir == pkgInfo.myPath.parentDir and
      options.satResult.rootPackage.basicInfo.name == pkgInfo.basicInfo.name
    buildPkg(nimBin, pkgInfo, isInRootDir, options)

  if options.getCompilationFlags.len > 0:
    displayWarning(ignoringCompilationFlagsMsg)
  
  let binaryPath = pkgInfo.getOutputDir(binary)
  let cmd = quoteShellCommand(binaryPath & options.action.runFlags)
  displayDebug("Executing", cmd)

  let exitCode = cmd.execCmd
  raise nimbleQuit(exitCode)

proc openNimbleManual =
  const NimbleGuideURL = "https://nim-lang.github.io/nimble/index.html"
  display(
    "Opened", "the Nimble guide in your default browser."
  )
  displayInfo("If it did not open, you can try going to the link manually: " & NimbleGuideURL)
  openDefaultBrowser(NimbleGuideURL)

proc loadFilePathPkgs*(entryPkg: PackageInfo, options: var Options, nimBin: Option[string]) =
  addUnique(options.filePathPkgs, entryPkg)
  for require in entryPkg.requires:
    if require.name.isFileURL:
      let path = require.name.extractFilePathFromURL()
      let pkg = getPkgInfo(path, options, nimBin = nimBin, level = pikRequires)
      pkg.loadFilePathPkgs(options, nimBin)

proc loadFilePathPkgs(options: var Options, nimBin: Option[string]) =
  options.isFilePathDiscovering = true
  options.satResult.rootPackage.loadFilePathPkgs(options, nimBin)
  options.isFilePathDiscovering = false

proc solvePkgs(rootPackage: PackageInfo, options: var Options, nimBin: var Option[string]) {.instrument.} =
  options.satResult.rootPackage = rootPackage
  options.satResult.rootPackage.requires &= options.extraRequires
  # Add task-specific requirements if a task is being executed
  #Note this wont work until we support taskRequires in the declarative parser
  if options.task.len > 0 and options.task in rootPackage.taskRequires:
    options.satResult.rootPackage.requires &= rootPackage.taskRequires[options.task]  
  #when locking we need to add the task requires to the root package
  if options.action.typ == actionLock:
    for task in rootPackage.taskRequires.keys:
      options.satResult.rootPackage.requires &= rootPackage.taskRequires[task]
  withNimBinFallback(nimBin, options):
    loadFilePathPkgs(options, nimBin)
  var pkgList: seq[PackageInfo]
  withNimBinFallback(nimBin, options):
    pkgList = initPkgList(options.satResult.rootPackage, options, nimBin = nimBin)
  options.satResult.rootPackage.enableFeatures(options)

  var resolvedNim: NimResolved
  withNimBinFallback(nimBin, options):
    resolvedNim = resolveAndConfigureNim(options.satResult.rootPackage, pkgList, options, nimBin)
  if resolvedNim.pkg.isNone:
    let nimInstalled = installNimFromBinariesDir(("nim", resolvedNim.version.toVersionRange()), options)
    if nimInstalled.isSome:
      resolvedNim.pkg = some getPkgInfo(nimInstalled.get.dir, options, nimBin = none(string), level = pikRequires) #Can be empty as the code path for nim doesnt need it.
      resolvedNim.version = nimInstalled.get.ver
    else:
      raise nimbleError("Failed to install nim") #What to do here? Is this ever possible?
  # echo "AFTER FIRST PASS"
  # options.debugSATResult()
  #We set nim in the options here as it is used to get the full info of the packages.
  #Its kinda a big refactor getPkgInfo to parametrize it. At some point we will do it.
  # Install nim to pkgs2 if not already there (for consistency with other packages)
  # This returns a PackageInfo pointing to pkgs2 instead of nimbinaries
  let nimPkgInfo = installNimToPkgs2(resolvedNim.pkg.get, options, nimBin)
  resolvedNim.pkg = some nimPkgInfo
  # Derive nimBin path from resolved package
  let resolvedNimBin = if nimPkgInfo.nimBinPath.isSome:
                         nimPkgInfo.nimBinPath.get  # System nim with non-standard layout (#1609)
                       else:
                         nimPkgInfo.getNimPath()  # Standard layout
  nimBin = some(resolvedNimBin)
  options.nimBin = some makeNimBin(options, resolvedNimBin)
  # Add nim to PATH for subprocesses and handle compilation (only for non-system nim in standard layout)
  if nimPkgInfo.nimBinPath.isNone:
    if not fileExists(resolvedNimBin):
      if options.prompt("Develop version of nim was found but it is not compiled. Compile it now?"):
        compileNim(options, nimPkgInfo.getRealDir, nimPkgInfo.basicInfo.version.toVersionRange())
      else:
        raise nimbleError("Trying to use nim from $1 " % nimPkgInfo.getRealDir,
                          "If you are using develop mode nim make sure to compile it.")
    let separator = when defined(windows): ";" else: ":"
    putEnv("PATH", nimPkgInfo.getRealDir / "bin" & separator & getEnv("PATH"))
  display("Info:", "using $1 for compilation" % resolvedNimBin, priority = HighPriority)
  options.satResult.nimResolved = resolvedNim #TODO maybe we should consider the sat fallback pass. Not sure if we should just warn the user so the packages are corrected
  options.satResult.pkgs.incl(nimPkgInfo) #Make sure its in the solution
  # Only add nim to solvedPkgs if there isn't already one (e.g., with a special version like #devel)
  if not options.satResult.solvedPkgs.anyIt(it.pkgName.isNim):
    addUnique(options.satResult.solvedPkgs, SolvedPackage(pkgName: "nim", version: resolvedNim.version))
  options.satResult.solutionToFullInfo(options, nimBin)
  if rootPackage.hasLockFile(options) and not options.disableLockFile:
    options.satResult.solveLockFileDeps(pkgList, options, nimBin)

  # # When installing nim itself globally, update rootPackage to point to the resolved nim location
  if rootPackage.basicInfo.name.isNim and resolvedNim.pkg.isSome:
    options.satResult.rootPackage = resolvedNim.pkg.get

  # Display declarative parser warnings for packages in the solution
  let pkgsWithErrors = options.satResult.pkgs.toSeq.filterIt(it.declarativeParserErrors.len > 0)
  if pkgsWithErrors.len > 0:
    displayWarning("Declarative parser failed, the file had to be parsed with the VM parser. Please fix your nimble file.")
    for pkg in pkgsWithErrors:
      for line in pkg.declarativeParserErrors:
        displayWarning(line)

  options.satResult.pass = satDone 

proc developFromSolution(rootPkgName: string, options: var Options, nimBin: Option[string]) =
  ## Clones solved packages into vendor/ based on SAT solver results.
  if options.action.path.len == 0:
    options.action.path = defaultDevelopPath

  var currentDirPkgInfo = initPackageInfo()
  try:
    currentDirPkgInfo = getPkgInfo(getCurrentDir(), options, nimBin = nimBin)
  except CatchableError:
    discard

  for solvedPkg in options.satResult.solvedPkgs:
    if solvedPkg.pkgName.isNim:
      continue
    if solvedPkg.pkgName.toLower == rootPkgName.toLower:
      continue
    let pkgTup: PkgTuple = (solvedPkg.pkgName,
      parseVersionRange("== " & $solvedPkg.version))
    try:
      let pkgInfo = installDevelopPackage(pkgTup, options, nimBin)
      options.satResult.pkgs.incl(pkgInfo)
    except CatchableError as error:
      displayError(&"Cannot vendor package \"{solvedPkg.pkgName}\" for develop.")
      displayDetails(error)

  # Update develop file
  if currentDirPkgInfo.isLoaded:
    options.developFile = developFileName
  if options.developFile.len > 0:
    discard updateDevelopFile(currentDirPkgInfo, options, nimBin)

proc runDevelopAction(options: var Options, nimBin: Option[string]): bool =
  ## Handles `actionDevelop`. Returns `true` if fully handled (caller should
  ## `return`), `false` if the caller should fall through to the normal
  ## solve/install flow (the `--with-dependencies` project-dir case).
  if not options.action.withDependencies:
    develop(options, nimBin)
    return true
  # With dependencies: clone only the explicitly requested packages first
  var developedPkgs: seq[PackageInfo] = @[]
  if options.action.packages.len > 0:
    let savedWithDeps = options.action.withDependencies
    options.action.withDependencies = false
    develop(options, nimBin)
    options.action.withDependencies = savedWithDeps
    for devAction in options.action.devActions:
      if devAction.actionType == datAdd:
        try:
          developedPkgs.add getPkgInfo(devAction.argument, options, nimBin = nimBin)
        except CatchableError:
          discard
  if not options.thereIsNimbleFile and developedPkgs.len == 0:
    return true
  # For non-project-dir develops, solve from each cloned package as root
  if not options.thereIsNimbleFile and developedPkgs.len > 0:
    for rootPkg in developedPkgs:
      var nimBinLocal = nimBin
      options.satResult = initSATResult(satSolving)
      solvePkgs(rootPkg, options, nimBinLocal)
      developFromSolution(rootPkg.basicInfo.name, options, nimBinLocal)
    return true
  return false

proc runInstallRootGloballyAction(options: var Options, nimBin: var Option[string]) =
  ## `nimble install -g` inside a project directory: install the current
  ## project globally.
  options.satResult = initSATResult(satSolving)
  var rootPackage: PackageInfo
  withNimBinFallback(nimBin, options):
    rootPackage = getPkgInfo(getCurrentDir(), options, nimBin = nimBin, level = pikRequires)
  solvePkgs(rootPackage, options, nimBin)
  let rootSolvedPkg = SolvedPackage(
    pkgName: rootPackage.basicInfo.name,
    version: rootPackage.basicInfo.version,
    requirements: rootPackage.requires,
    deps: options.satResult.solvedPkgs.filterIt(it.pkgName.toLower != rootPackage.basicInfo.name.toLower)
  )
  options.satResult.solvedPkgs.add(rootSolvedPkg)
  options.satResult.installPkgs(options, nimBin)
  options.satResult.addReverseDeps(options)

proc runInstallPackagesAction(options: var Options, nimBin: var Option[string]) =
  ## Global install of named packages: `nimble install foo bar`.
  for pkg in options.action.packages:
    options.satResult = initSATResult(satSolving)
    # Download package info to pkgcache WITHOUT submodules - submodules are
    # populated in buildtemp during actual install to avoid mutating shared cache (issue #1592)
    # Force git clone (not tarball) so .git and .gitmodules are preserved for buildtemp
    var dlOptions = options
    dlOptions.ignoreSubmodules = true
    dlOptions.enableTarballs = false
    var rootPackage: PackageInfo
    withNimBinFallback(nimBin, options):
      rootPackage = downloadPkInfoForPv(pkg, dlOptions, doPrompt = true, nimBin = nimBin)
    solvePkgs(rootPackage, options, nimBin)

    let rootSolvedPkg = SolvedPackage(
      pkgName: rootPackage.basicInfo.name,
      version: rootPackage.basicInfo.version,
      requirements: rootPackage.requires,
      deps: options.satResult.solvedPkgs.filterIt(it.pkgName.toLower != rootPackage.basicInfo.name.toLower)
    )
    options.satResult.solvedPkgs.add(rootSolvedPkg)
    options.satResult.installPkgs(options, nimBin)
    options.satResult.addReverseDeps(options)

proc runLocalProjectAction(options: var Options, nimBin: var Option[string]): PackageInfo =
  ## Loads the local project root package and runs the SAT solver. Returns
  ## the root package so the caller can feed it into the post-solve tail.
  options.satResult = initSATResult(satSolving)
  options.isFilePathDiscovering = true
  #we need to skip validation for root
  withNimBinFallback(nimBin, options):
    result = getPkgInfo(getCurrentDir(), options, nimBin = nimBin, level = pikRequires)
  options.isFilePathDiscovering = false
  if options.action.typ in {actionInstall, actionAdd}:
    result.requires.add(options.action.packages)
  solvePkgs(result, options, nimBin)

proc warnVersionMismatches(options: Options) =
  ## Warn when an installed package's directory/tag version doesn't match the
  ## version declared in its `.nimble` file. Skips special versions (`#devel`).
  for pkgInfo in options.satResult.pkgs:
    try:
      if pkgInfo.basicInfo.version.isSpecial:
        continue
      let nimbleFileInfo = extractRequiresInfo(pkgInfo.myPath, options)
      if nimbleFileInfo.version != "" and newVersion(nimbleFileInfo.version) != pkgInfo.basicInfo.version:
        displayWarning(&"Version mismatch for {pkgInfo.basicInfo.name}: installed version is {pkgInfo.basicInfo.version} but .nimble file declares {nimbleFileInfo.version}. ({pkgInfo.myPath})", HighPriority)
    except CatchableError:
      discard

proc run*(options: var Options, nimBin: var Option[string]) {.instrument.} =
  ## Main pipeline entry. Dispatches to the appropriate branch helper and
  ## runs the shared post-solve install/reverse-deps tail for branches that
  ## fall through.
  #Make sure we set the right verbosity for commands that output info:
  if options.action.typ in {actionShellEnv}:
    setVerbosity(SilentPriority)
    options.verbosity = SilentPriority

  # For develop without --with-dependencies, just clone and return.
  # For develop with --with-dependencies, solve first then clone from solution.
  if options.action.typ == actionDevelop:
    if runDevelopAction(options, nimBin): return

  let isGlobalInstall = options.explicitGlobal and
    options.action.typ == actionInstall and options.action.packages.len > 0
  var isGlobalInstallRoot = false
  if options.action.typ == actionInstall:
    isGlobalInstallRoot = options.action.global and
      options.action.packages.len == 0 and options.thereIsNimbleFile

  var rootPackage: PackageInfo
  if isGlobalInstallRoot:
    runInstallRootGloballyAction(options, nimBin)
    return
  elif options.thereIsNimbleFile and not isGlobalInstall and
       not (findNimbleFile(getCurrentDir(), error = false, options, warn = false).splitFile.name.isNim and
            options.action.typ == actionInstall and options.action.packages.len > 0):
    rootPackage = runLocalProjectAction(options, nimBin)
  elif options.action.typ == actionInstall:
    runInstallPackagesAction(options, nimBin)
    return
  else:
    # No nimble file and action requires one - raise a friendly error
    raise nimbleError(
      "Could not find a .nimble file in the current directory. " &
      "This command requires a Nimble package file.")

  # For develop --with-dependencies: clone solved packages into vendor/
  # instead of installing to pkgs2.
  if options.action.typ == actionDevelop and options.action.withDependencies:
    developFromSolution(rootPackage.basicInfo.name, options, nimBin)
    return

  options.satResult.installPkgs(options, nimBin)
  options.satResult.addReverseDeps(options)
  warnVersionMismatches(options)


proc getNimDir(options: var Options, nimBin: var Option[string]): string =
  ## returns the nim directory prioritizing the nimBin one if it satisfais the requirement of the project
  ## otherwise it returns the major version of the nim installed packages that satisfies the requirement of the project
  ## if no nim package satisfies the requirement of the project it returns the nimBin parent directory
  ## only used by the `nimble dump` command which is used to drive the lsp
  block:
    #we rely on the SAT solver to get the right Nim but we do not install anything (so the lsp doesnt hang)
    let projectName = options.action.projName
    var projFolder =
      if projectName == "": getCurrentDir()
      elif projectName.endsWith(".nimble"): projectName.absolutePath.parentDir
      else: projectName.absolutePath
    if not dirExists(projFolder):
      #dump for an installed package.
      let pkg = getInstalledPkgsMin(options.getPkgsDir(), options).filterIt(it.basicInfo.name == projectName)
      if pkg.len > 0:
        projFolder = pkg[0].getRealDir
        
    var rootPackage = getPkgInfo(projFolder, options, nimBin = nimBin, level = pikRequires)
    #make it silent as we are going to capture the output
    setVerbosity(SilentPriority)
    options.isFilePathDiscovering = false
    if options.action.typ == actionInstall:
      rootPackage.requires.add(options.action.packages)
    solvePkgs(rootPackage, options, nimBin)    
    return nimBin.getNimBin.parentDir



proc doAction(options: var Options, nimBinParam: Option[string]) {.instrument.} =
  if options.showHelp:
    writeHelp()
  if options.showVersion:
    writeVersion()
  # Lazily resolve bootstrap Nim on demand for non-resolving branches that
  # need it (dump, tasks, check, publish). Resolving branches already get
  # nimBin from the SAT solver (populated by run() → satResult.nimResolved).
  var nimBin = nimBinParam
  template needNim() =
    if nimBin.isNone:
      nimBin = some(ensureBootstrapNim(options))
      if options.nimBin.isNone:
        options.nimBin = some makeNimBin(options, nimBin.getNimBin)
  case options.action.typ
  of actionRefresh:
    refresh(options)
  of actionInstall:
    discard # handled by resolution pipeline
  of actionUninstall:
    uninstall(options, nimBin)
  of actionSearch:
    search(options)
  of actionList:
    if options.action.onlyInstalled:
      listInstalled(options)
    elif options.action.onlyNimBinaries:
      listNimBinaries(options)
    else:
      list(options)
  of actionPath:
    listPaths(options)
  of actionBuild:
    discard # handled by run
  of actionClean:
    clean(options, nimBin)
  of actionRun:
    runAction(options, nimBin)
  of actionUpgrade:
    lock(options, nimBin)
  of actionCompile, actionDoc:
    var pkgInfo = getPkgInfo(getCurrentDir(), options, nimBin = nimBin)
    execBackend(pkgInfo, options, nimBin)
  of actionInit:
    needNim()
    init(options, nimBin)
  of actionPublish:
    needNim()
    var pkgInfo = getPkgInfo(getCurrentDir(), options, nimBin = nimBin)
    publish(pkgInfo, options)
  of actionDump:
    needNim()
    dump(options, nimBin)
  of actionTasks:
    needNim()
    listTasks(options, nimBin)
  of actionDevelop:
    develop(options, nimBin)
  of actionCheck:
    needNim()
    check(options, nimBin)
  of actionLock:
    lock(options, nimBin)
  of actionDeps:
    deps(options, nimBin)
  of actionSync:
    sync(options, nimBin)
  of actionSetup:
    setup(options, nimBin)
  of actionShellEnv:
    shellenv(options, nimBin)
  of actionShell:
    shell(options, nimBin)
  of actionNil:
    assert false
  of actionAdd:
    addPackages(options.action.packages, options, nimBin)
  of actionManual:
    openNimbleManual()
  of actionCustom:
    var optsCopy = options
    optsCopy.task = options.action.command.normalize
    let
      nimbleFile = findNimbleFile(getCurrentDir(), true, options)
      pkgInfo = getPkgInfoFromFile(nimBin, nimbleFile, optsCopy)

    if optsCopy.task in pkgInfo.nimbleTasks:
      # Make sure we have dependencies for the task.
      # We do that here to make sure that any binaries from dependencies
      # are installed
      # If valid task defined in nimscript, run it
      var execResult: ExecutionResult[bool]
      if execCustom(nimBin, nimbleFile, optsCopy, execResult):
        if execResult.hasTaskRequestedCommand():
          var options = execResult.getOptionsForCommand(optsCopy)
          doAction(options, nimBin)
    elif optsCopy.task == "test":
      # If there is no task defined for the `test` task, we run the pre-defined
      # fallback logic.
      test(optsCopy, nimBin)
    else:
      raise nimbleError(msg = "Could not find task $1 in $2" %
                              [options.action.command, nimbleFile],
                        hint = "Run `nimble --help` and/or `nimble tasks` for" &
                               " a list of possible commands." & '\n' &
                               "If you want a tutorial on how to use Nimble, run `nimble guide`."
                       )


when isMainModule:
  var exitCode = QuitSuccess

  var opt: Options
  try:
    opt = parseCmdLine()
    opt.setNimbleDir()
    opt.loadNimbleData()
    if opt.action.typ in {actionTasks, actionRun, actionBuild, actionCompile, actionDevelop}:
      # Implicitly disable package validation for these commands.
      opt.disableValidation = true
    
    # Actions that don't go through the main resolving pipeline (no SAT solve / install).
    const nonResolvingActions = {actionNil, actionRefresh, actionInit, actionDump,
      actionPublish, actionSearch, actionList, actionPath, actionUninstall,
      actionCheck, actionTasks, actionClean, actionManual}
    var shouldRun = opt.action.typ notin nonResolvingActions

    # Check if nimble file is required but not present
    # Actions like build, test, run, etc. require a nimble file
    const actionsRequiringNimbleFile = {actionBuild, actionSetup, actionRun,
      actionLock, actionCustom, actionSync, actionUpgrade, actionDoc,
      actionCompile, actionDeps, actionAdd}
    if shouldRun and opt.action.typ in actionsRequiringNimbleFile and not opt.thereIsNimbleFile:
      # Check for deprecated .babel files
      var hasBabel = false
      for kind, path in walkDir(getCurrentDir()):
        if kind in {pcFile, pcLinkToFile} and path.splitFile.ext == ".babel":
          hasBabel = true
          break
      if hasBabel:
        raise nimbleError(
          "Found .babel file but .babel format is no longer supported. " &
          "Please rename it to .nimble and convert to nimscript format.")
      raise nimbleError(
        "Could not find a .nimble file in the current directory. " &
        "This command requires a Nimble package file.")

    # Resolving actions (build/install/run/etc.) get their Nim from the SAT solver inside run();
    # non-resolving actions call ensureBootstrapNim at their own point-of-use.
    # Actions that never need a Nim binary (refresh, search, list, path,
    # uninstall, clean, manual, init, nil — and --version/--help) stay free.
    var nimBin = none(string)
    if shouldRun:
      # For actionCustom, set the task name before calling run
      if opt.action.typ == actionCustom:
        opt.task = opt.action.command.normalize
      run(opt, nimBin)
      # After run(), the SAT solver has resolved nim for this project.
      # Read it out so subsequent setup()/doAction() can reuse the same binary.
      if opt.satResult.nimResolved.pkg.isSome:
        nimBin = some(opt.satResult.nimResolved.getNimBin())

    #if the action is different than setup we run setup
    #when not doing a global install (no nimble file in the current directory)
    var isGlobalInstallPost = false
    if opt.action.typ == actionInstall:
      isGlobalInstallPost = (opt.explicitGlobal and opt.action.packages.len > 0) or
        (opt.action.global and opt.action.packages.len == 0)
    var shouldRunSetup = shouldRun and opt.action.typ in {actionCompile, actionRun, actionDevelop, actionCustom} and opt.thereIsNimbleFile and not isGlobalInstallPost
    # For develop without --withDependencies, no solving happened - skip setup
    if opt.action.typ == actionDevelop and not opt.action.withDependencies:
      shouldRunSetup = false
    if opt.action.typ == actionCustom and not opt.localdeps:
      shouldRunSetup = false
    # Generate config.nims BEFORE doAction so test tasks can find deps
    if shouldRunSetup:
      setup(opt, nimBin)

    # develop is handled inside run (it must run before the solver)
    if not shouldRun or opt.action.typ != actionDevelop:
      opt.doAction(nimBin)

  except NimbleQuit as quit:
    exitCode = quit.exitCode
  except CatchableError as error:
    exitCode = QuitFailure
    displayTip()
    echo error.getStackTrace()
    displayError(error)
  finally:
    try:
      let folder = getNimbleTempDir()
      if opt.shouldRemoveTmp(folder):
        removeDir(folder)
    except CatchableError as error:
      displayWarning("Couldn't remove Nimble's temp dir")
      displayDetails(error)

    try:
      saveNimbleData(opt)
    except CatchableError as error:
      exitCode = QuitFailure
      displayError(&"Couldn't save \"{nimbleDataFileName}\".")
      displayDetails(error)
  when defined(instrument):
    printInstrumentationReport()
  quit(exitCode)
