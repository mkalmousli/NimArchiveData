# Copyright (C) Dominik Picheta. All rights reserved.
# BSD License. Look at license.txt for more info.

# Stdlib imports
import system except TResult
import hashes, strutils, os, sets, tables, times, httpclient, strformat
from net import SslError

import zippy

import compat/json
# Local imports
import version, tools, common, options, cli, config, lockfile, packageinfotypes,
       packagemetadatafile, sha1hashes

proc initPackageInfo*(): PackageInfo =
  result = PackageInfo(
    basicInfo: ("", notSetVersion, notSetSha1Hash),
    metaData: initPackageMetaData())

proc initPackage*(): Package =
  result = Package(version: notSetVersion)

proc isLoaded*(pkgInfo: PackageInfo): bool =
  return pkgInfo.myPath.len > 0

proc assertIsLoaded*(pkgInfo: PackageInfo) =
  assert pkgInfo.isLoaded, "The package info must be loaded. "

proc areLockedDepsLoaded*(pkgInfo: PackageInfo): bool =
  pkgInfo.lockedDeps.len > 0

proc hasMetaData*(pkgInfo: PackageInfo): bool =
  # if the package info has loaded meta data its files list have to be not empty
  pkgInfo.metaData.files.len > 0

proc hasBeforeInstallHook*(pkgInfo: PackageInfo): bool =
  "install" in pkgInfo.preHooks

proc initPackageInfo*(options: Options, filePath: string): PackageInfo =
  result = initPackageInfo()
  let (fileDir, fileName, _) = filePath.splitFile
  result.myPath = filePath
  result.basicInfo.name = fileName
  result.backend = "c"
  if not options.disableLockFile:
    result.lockedDeps = options.lockFile(fileDir).getLockedDependencies()

proc toValidPackageName*(name: string): string =
  for c in name:
    case c
    of '_', '-':
      if result[^1] != '_': result.add('_')
    of AllChars - IdentChars - {'-'}: discard
    else: result.add(c)

proc optionalField(obj: JsonNode, name: string, default = ""): string =
  ## Queries ``obj`` for the optional ``name`` string.
  ##
  ## Returns the value of ``name`` if it is a valid string, or aborts execution
  ## if the field exists but is not of string type. If ``name`` is not present,
  ## returns ``default``.
  if hasKey(obj, name):
    if obj[name].kind == JString:
      return obj[name].str
    else:
      raise nimbleError("Corrupted packages.json file. " & name &
          " field is of unexpected type.")
  else: return default

proc requiredField(obj: JsonNode, name: string): string =
  ## Queries ``obj`` for the required ``name`` string.
  ##
  ## Aborts execution if the field does not exist or is of invalid json type.
  result = optionalField(obj, name)
  if result.len == 0:
    raise nimbleError(
        "Package in packages.json file does not contain a " & name & " field.")

proc parseDownloadMethod*(meth: string): DownloadMethod =
  case meth
  of "git": return DownloadMethod.git
  of "hg", "mercurial": return DownloadMethod.hg
  else:
    raise nimbleError("Invalid download method: " & meth)

{.warning[ProveInit]: off.}
proc fromJson(obj: JSonNode): Package =
  ## Constructs a Package object from a JSON node.
  ##
  ## Aborts execution if the JSON node doesn't contain the required fields.
  result.name = obj.requiredField("name")
  if obj.hasKey("alias"):
    result.alias = obj.requiredField("alias")
  else:
    result.alias = ""
    result.version = newVersion(obj.optionalField("version"))
    result.url = obj.requiredField("url")
    result.downloadMethod = obj.requiredField("method").parseDownloadMethod
    result.dvcsTag = obj.optionalField("dvcs-tag")
    result.license = obj.requiredField("license")
    result.tags = @[]
    for t in obj["tags"]:
      result.tags.add(t.str)
    result.description = obj.optionalField("description")
    result.web = obj.optionalField("web")
{.warning[ProveInit]: on.}

proc needsRefresh*(options: Options): bool =
  ## Determines whether a ``nimble refresh`` is needed.
  ##
  ## In the future this will check a stored time stamp to determine how long
  ## ago the package list was refreshed.
  result = true
  for name, list in options.config.packageLists:
    if fileExists(options.getNimbleDir() / "packages_" & name & ".json"):
      result = false

proc validatePackagesList(path: string): bool =
  ## Determines whether package list at ``path`` is valid.
  try:
    if not path.fileExists:
      display("Warning:", path & " does not exist.", Warning, HighPriority)
      return false
    let pkgList = parseFile(path)
    if pkgList.kind == JArray:
      if pkgList.len == 0:
        display("Warning:", path & " contains no packages.", Warning,
                HighPriority)
      return true
  except ValueError, JsonParsingError:
    return false

proc fetchList*(list: PackageList, options: Options) =
  ## Downloads or copies the specified package list and saves it in $nimbleDir.
  let verb = if list.urls.len > 0: "Downloading" else: "Copying"
  display(verb, list.name & " package list", priority = HighPriority)

  var
    lastError = ""
    copyFromPath = ""
  if list.urls.len > 0:
    for i in 0 ..< list.urls.len:
      let url = list.urls[i]
      display("Trying", url)
      let tempPath = options.getNimbleDir() / "packages_temp.json"

      # Grab the proxy
      let proxy = getProxy(options)
      if not proxy.isNil:
        var maskedUrl = proxy.url
        if maskedUrl.password.len > 0: maskedUrl.password = "***"
        display("Connecting", "to proxy at " & $maskedUrl,
                priority = LowPriority)

      try:
        let ctx = newSSLContext(options.disableSslCertCheck)
        let client = newHttpClient(proxy = proxy, sslContext = ctx,
                                   userAgent = nimbleUserAgent)
        client.headers = newHttpHeaders({"Accept-Encoding": "gzip"})
        let resp = client.get(url)
        if resp.code.is4xx or resp.code.is5xx:
          raise newException(HttpRequestError,
            "Server returned status: " & $resp.code & " " & resp.status)
        var body = resp.body
        let encoding = ($resp.headers.getOrDefault("content-encoding")).strip.toLowerAscii
        if encoding == "gzip":
          body = uncompress(body, dfGzip)
        writeFile(tempPath, body)
      except SslError:
        let message = "Failed to verify the SSL certificate for " & url
        raise nimbleError(message, "Use --noSSLCheck to ignore this error.")

      except:
        let message = "Could not download: " & getCurrentExceptionMsg()
        display("Warning:", message, Warning)
        lastError = message
        continue

      if not validatePackagesList(tempPath):
        lastError = "Downloaded packages.json file is invalid"
        display("Warning:", lastError & ", discarding.", Warning)
        continue

      copyFromPath = tempPath
      display("Success", "Package list downloaded.", Success, HighPriority)
      lastError = ""
      break

  elif list.path != "":
    if not validatePackagesList(list.path):
      lastError = "Copied packages.json file is invalid"
      display("Warning:", lastError & ", discarding.", Warning)
    else:
      copyFromPath = list.path
      display("Success", "Package list copied.", Success, HighPriority)

  if lastError.len != 0:
    if list.name == "local":
      display("Warning:", lastError & ", discarding.", Warning)
    else:
      raise nimbleError("Refresh failed\n" & lastError)

  if copyFromPath.len > 0:
    copyFile(copyFromPath,
        options.getNimbleDir() / "packages_$1.json" % list.name.toLowerAscii())

# Cache after first call
var
  gPackageJson {.threadvar.}: TableRef[string, JsonNode]

proc getGPackageJson(): TableRef[string, JsonNode] =
  if gPackageJson.isNil:
    gPackageJson = newTable[string, JsonNode]()
  return gPackageJson

proc readPackageList(name: string, options: Options, ignorePackageCache = false): JsonNode =
  # If packages.json is not present ask the user if they want to download it.
  if (not ignorePackageCache) and getGPackageJson().hasKey(name):
    return getGPackageJson()[name]

  display("Reading", "$1 package list" % name, priority = LowPriority)

  if needsRefresh(options):
    if options.prompt("No local packages.json found, download it from " &
            "internet?"):
      for name, list in options.config.packageLists:
        fetchList(list, options)
    else:
      # The user might not need a package list for now. So let's try
      # going further.
      getGPackageJson()[name] = newJArray()
      return getGPackageJson()[name]
  let file = options.getNimbleDir() / "packages_" & name.toLowerAscii() & ".json"
  if file.fileExists:
    getGPackageJson()[name] = parseFile(file)
  else:
    getGPackageJson()[name] = newJArray()
  return getGPackageJson()[name]

proc getPackage*(pkg: string, options: Options, resPkg: var Package, ignorePackageCache = false): bool {.gcsafe, raises: [CatchableError].}
proc resolveAlias(pkg: Package, options: Options): Package =
  result = pkg
  # Resolve alias.
  if pkg.alias.len > 0:
    display("Warning:", "The $1 package has been renamed to $2" %
            [pkg.name, pkg.alias], Warning, HighPriority)
    if not getPackage(pkg.alias, options, result):
      raise nimbleError("Alias for package not found: " &
                         pkg.alias)

proc getPackage*(pkg: string, options: Options, resPkg: var Package, ignorePackageCache = false): bool =
  ## Searches any packages.json files defined in ``options.config.packageLists``
  ## Saves the found package into ``resPkg``.
  ##
  ## Pass in ``pkg`` the name of the package you are searching for. As
  ## convenience the proc returns a boolean specifying if the ``resPkg`` was
  ## successfully filled with good data.
  ##
  ## Aliases are handled and resolved.
  for name, list in options.config.packageLists:
    let packages = readPackageList(name, options, ignorePackageCache)
    for p in packages:
      if normalize(p["name"].str) == normalize(pkg):
        resPkg = p.fromJson()
        resPkg = resolveAlias(resPkg, options)
        return true

{.warning[ProveInit]: off.}
proc getPackage*(name: string, options: Options): Package =
  let success = getPackage(name, options, result)
  if not success:
    raise nimbleError(
      "Cannot find package with name '" & name & "'.")
{.warning[ProveInit]: on.}

proc getPackageList*(options: Options): seq[Package] =
  ## Returns the list of packages found in the downloaded packages.json files.
  var namesAdded: HashSet[string]
  for name, list in options.config.packageLists:
    let packages = readPackageList(name, options)
    for p in packages:
      let pkg: Package = p.fromJson()
      if pkg.name notin namesAdded:
        result.add(pkg)
        namesAdded.incl(pkg.name)


proc setNameVersionChecksum*(pkgInfo: var PackageInfo, pkgDir: string) =
  let (name, version, checksum) = getNameVersionChecksum(pkgDir)
  pkgInfo.basicInfo.name = name
  if pkgInfo.basicInfo.version == notSetVersion:
    # if there is no previously set version from the `.nimble` file
    pkgInfo.basicInfo.version = version
  pkgInfo.metaData.specialVersions.incl version
  pkgInfo.basicInfo.checksum = checksum

proc getInstalledPackageMin*(options: Options, pkgDir, nimbleFilePath: string): PackageInfo =
  result = initPackageInfo(options, nimbleFilePath)
  setNameVersionChecksum(result, pkgDir)
  result.infoKind = pikMinimal
  result.source = psInstalled
  try:
    fillMetaData(result, pkgDir, true, options)
  except MetaDataError:
    discard

proc getInstalledPkgsMin*(libsDir: string, options: Options): seq[PackageInfo] =
  ## Gets a list of installed packages. The resulting package info is
  ## minimal. This has the advantage that it does not depend on the
  ## ``packageparser`` module, and so can be used by ``nimscriptwrapper``.
  ##
  ## ``libsDir`` is in most cases: ~/.nimble/pkgs/ (options.getPkgsDir)
  result = @[]
  for kind, path in walkDir(libsDir):
    if kind == pcDir:
      let nimbleFile = findNimbleFile(path, false, options)
      if nimbleFile != "":
        let pkg = getInstalledPackageMin(options, path, nimbleFile)
        result.add pkg

proc withinRange*(pkgInfo: PackageInfo, verRange: VersionRange): bool =
  ## Determines whether the specified package's version is within the specified
  ## range. As the ordinary version is always added to the special versions set
  ## checking only the special versions is enough.
  return withinRange(pkgInfo.metaData.specialVersions, verRange)

proc resolveAlias*(dep: PkgTuple, options: Options): PkgTuple =
  ## Looks up the specified ``dep.name`` in the packages.json files to resolve
  ## a potential alias into the package's real name.
  result = dep
  var pkg = initPackage()
  # TODO: This needs better caching.
  if getPackage(dep.name, options, pkg):
    # The resulting ``pkg`` will contain the resolved name or the original if
    # no alias is present.
    result.name = pkg.name

proc resolveAlias*(depName: string, options: Options): string =
  var pkg = initPackage()
  if getPackage(depName, options, pkg):
    return pkg.name
  return depName

proc findPkg*(pkglist: seq[PackageInfo], dep: PkgTuple,
              r: var PackageInfo): bool =
  ## Searches ``pkglist`` for a package of which version is within the range
  ## of ``dep.ver``. ``True`` is returned if a package is found. If multiple
  ## packages are found the newest one is returned (the one with the highest
  ## version number). If there is a package in develop mode indicated by its
  ## `isLink` field being `true`, it should be only one for given package name,
  ## and if its version is in the required range, it will be treated with the
  ## highest priority.
  ##
  ## **Note**: dep.name here could be a URL, hence the need for pkglist.meta.
  for pkg in pkglist:
    if cmpIgnoreStyle(pkg.basicInfo.name, dep.name) != 0 and
       cmpIgnoreStyle(pkg.metaData.url, dep.name) != 0: continue
    if pkg.isLink:
      # If `pkg.isLink` this is a develop mode package and develop mode packages
      # are always with higher priority than installed packages. Version range
      # is not being considered for them.
      r = pkg
      return true
    elif withinRange(pkg, dep.ver):
      let isNewer = r.basicInfo.version < pkg.basicInfo.version
      if not result or isNewer:
        r = pkg
        result = true

proc findAllPkgs*(pkglist: seq[PackageInfo], dep: PkgTuple): seq[PackageInfo] =
  ## Searches ``pkglist`` for packages of which version is within the range
  ## of ``dep.ver``. This is similar to ``findPkg`` but returns multiple
  ## packages if multiple are found.
  result = @[]
  for pkg in pkglist:
    if cmpIgnoreStyle(pkg.basicInfo.name, dep.name) != 0 and
       cmpIgnoreStyle(pkg.metaData.url, dep.name) != 0: continue
    if withinRange(pkg, dep.ver):
      result.add pkg


proc getRealDir*(pkgInfo: PackageInfo): string =
  ## Returns the directory containing the package source files.
  if pkgInfo.srcDir != "" and (not pkgInfo.isInstalled or pkgInfo.isLink):
    result = pkgInfo.getNimbleFileDir() / pkgInfo.srcDir
  else:
    result = pkgInfo.getNimbleFileDir()
  
proc getOutputDir*(pkgInfo: PackageInfo, bin: string): string =
  ## Returns a binary output dir for the package.
  if pkgInfo.binDir != "":
    result = pkgInfo.getNimbleFileDir() / pkgInfo.binDir / bin
  else:
    result = pkgInfo.mypath.splitFile.dir / bin
  if bin.len != 0 and dirExists(result):
    result &= ".out"

proc echoPackage*(pkg: Package) =
  displayFormatted(Message, pkg.name & ":")
  displayFormatted(Hint, "\n")

  if pkg.alias.len > 0:
    displayFormatted(Warning, "  Alias for ", pkg.alias)
    displayFormatted(Hint, "\n")
  else:
    displayInfoLine("  url:         ", pkg.url & " (" & $pkg.downloadMethod & ")")
    displayInfoLine("  tags:        ", pkg.tags.join(", "))
    displayInfoLine("  description: ", pkg.description)
    displayInfoLine("  license:     ", pkg.license)
    if pkg.web.len > 0:
      displayInfoLine("  website:     ", pkg.web)

proc echoPackage*(pkg: PackageInfo) =
  displayFormatted(Message, pkg.basicInfo.name & ":")
  displayFormatted(Hint, "\n")


proc checkInstallFile(pkgInfo: PackageInfo,
                      origDir, file: string): bool =
  ## Checks whether ``file`` should be installed.
  ## ``True`` means file should be skipped.

  for ignoreFile in pkgInfo.skipFiles:
    if ignoreFile.endswith("nimble"):
      raise nimbleError(ignoreFile & " must be installed.")
    if file == absolutePath(ignoreFile):
      result = true
      break

  for ignoreExt in pkgInfo.skipExt:
    if file.splitFile.ext == ('.' & ignoreExt):
      result = true
      break

  # Allow dot files inside .git and .hg directories
  if file.splitFile().name[0] == '.':
    # Check if this file is inside a .git or .hg directory
    var isInVcsDir = false
    let normalizedFile = file.replace('\\', '/')
    if ".git/" in normalizedFile or ".hg/" in normalizedFile:
      isInVcsDir = true
    if not isInVcsDir:
      result = true

proc checkInstallDir(pkgInfo: PackageInfo,
                     origDir, dir: string): bool =
  ## Determines whether ``dir`` should be installed.
  ## ``True`` means dir should be skipped.
  for ignoreDir in pkgInfo.skipDirs:
    if samePaths(dir, origDir / ignoreDir):
      result = true
      break

  let thisDir = splitPath(dir).tail
  assert thisDir != ""

  # Allow .git and .hg directories to be installed
  if thisDir == ".git" or thisDir == ".hg":
    result = false
  elif thisDir[0] == '.':
    result = true

  if thisDir == "nimcache" or thisDir == "tests": result = true

proc iterFilesWithExt(dir: string, pkgInfo: PackageInfo,
                      action: proc (f: string)) =
  ## Runs `action` for each filename of the files that have a whitelisted
  ## file extension.
  for kind, path in walkDir(dir):
    if kind == pcDir:
      iterFilesWithExt(path, pkgInfo, action)
    else:
      if path.splitFile.ext.substr(1) in pkgInfo.installExt:
        action(path)

proc iterFilesInDir(dir: string, action: proc (f: string)) =
  ## Runs `action` for each file in ``dir`` and any
  ## subdirectories that are in it.
  for kind, path in walkDir(dir):
    if kind == pcDir:
      iterFilesInDir(path, action)
    else:
      action(path)

proc iterInstallFiles*(realDir: string, pkgInfo: PackageInfo,
                       options: Options, action: proc (f: string)) =
  ## Runs `action` for each file within the ``realDir`` that should be
  ## installed.
  # Get the package root directory for skipDirs comparison
  let pkgRootDir = pkgInfo.getNimbleFileDir()
  
  var whitelistMode =
          pkgInfo.installDirs.len != 0 or
          pkgInfo.installFiles.len != 0 or
          pkgInfo.installExt.len != 0    
  
  
  # Create a mapping of lowercase filesystem names to metadata names
  var metadataNameMap: Table[string, string]
  block:
    # We build in a temp directory before copying, so we CAN use whitelist mode
    # to only copy necessary files. We still need metadataNameMap for case sensitivity.

    # Map installFiles
    for metadataFile in pkgInfo.installFiles:
      let normalizedKey = metadataFile.toLowerAscii()
      metadataNameMap[normalizedKey] = metadataFile
    
    # Map files from installDirs  
    for dir in pkgInfo.installDirs:
      let dirPath = realDir / dir
      if dirExists(dirPath):
        for kind, path in walkDir(dirPath):
          if kind == pcFile:
            let relativePath = path.relativePath(realDir)
            let normalizedKey = relativePath.toLowerAscii()
            metadataNameMap[normalizedKey] = relativePath
    
    # Find the actual main module file with case-insensitive matching
    let expectedMainModuleFile = pkgInfo.basicInfo.name.addFileExt("nim")
    var actualMainModuleFile = expectedMainModuleFile
    
    # Look for the actual file with case-insensitive matching
    if dirExists(realDir):
      for kind, path in walkDir(realDir):
        if kind == pcFile:
          let fileName = path.extractFilename
          if fileName.toLowerAscii == expectedMainModuleFile.toLowerAscii:
            actualMainModuleFile = fileName
            break
    
    let mainModuleNormalized = expectedMainModuleFile.toLowerAscii()
    metadataNameMap[mainModuleNormalized] = actualMainModuleFile
    
  if whitelistMode:
    for file in pkgInfo.installFiles:
      let src = realDir / file
      if not src.fileExists():
        if options.prompt("Missing file " & src & ". Continue?"):
          continue
        else:
          raise nimbleQuit()

      action(src)

    for dir in pkgInfo.installDirs:
      # TODO: Allow skipping files inside dirs?
      let src = realDir / dir
      if not src.dirExists():
        if options.prompt("Missing directory " & src & ". Continue?"):
          continue
        else:
          raise nimbleQuit()

      iterFilesInDir(src, action)

    iterFilesWithExt(realDir, pkgInfo, action)
  else:
    for kind, file in walkDir(realDir):
      if kind == pcDir:
        let skip = pkgInfo.checkInstallDir(pkgRootDir, file)
        if skip: continue
        # we also have to stop recursing if we reach an in-place nimbleDir
        if file == options.getNimbleDir().expandFilename(): continue

        iterInstallFiles(file, pkgInfo, options, action)
      else:
        let skip = pkgInfo.checkInstallFile(realDir, file)
        if skip: 
          # Don't skip .nim files that are needed for binary compilation
          if file.splitFile.ext == ".nim":
            let fileName = file.splitFile.name
            var isNeededForBinary = false
            for binName, srcName in pkgInfo.bin:
              if fileName == srcName or fileName == binName:
                isNeededForBinary = true
                break
            # If this .nim file is needed for binary compilation, don't skip it
            if not isNeededForBinary:
              continue
          else:
            continue
        
        # Skip binary files that match package binary names to avoid conflicts
        block:
          let fileName = file.splitFile.name
          let fileExt = file.splitFile.ext
          var skipBinary = false
          # Only skip if it's not a source file (i.e., doesn't have .nim extension)
          if fileExt != ".nim":
            for binName, _ in pkgInfo.bin:
              if fileName == binName:
                skipBinary = true
                break
          if skipBinary: continue
        
        # Handle symbolic links and case sensitivity
        block:
          let relativePath = file.relativePath(realDir)
          let normalizedPath = relativePath.toLowerAscii()

          if metadataNameMap.len > 0 and metadataNameMap.hasKey(normalizedPath):
            # Use the metadata name instead of filesystem name
            let metadataPath = realDir / metadataNameMap[normalizedPath]
            # Skip broken symbolic links
            if metadataPath.symlinkExists() and not metadataPath.fileExists():
              # This is a broken symbolic link, skip it
              discard
            else:
              action(metadataPath)
          else:
            # Skip broken symbolic links
            if file.symlinkExists() and not file.fileExists():
              # This is a broken symbolic link, skip it
              discard
            else:
              action(file)


proc needsRebuild*(pkgInfo: PackageInfo, bin: string, dir: string, options: Options): bool =
  if options.action.typ != actionInstall:
    return true
  
  if options.action.noRebuild:
    if not fileExists(bin):
      return true

    let binTimestamp = getFileInfo(bin).lastWriteTime
    var rebuild = false
    iterFilesWithExt(dir, pkgInfo,
      proc (file: string) =
        let srcTimestamp = getFileInfo(file).lastWriteTime
        if binTimestamp < srcTimestamp:
          rebuild = true
    )
    return rebuild
  else:
    return true

proc getCacheDir*(pkgInfo: PackageBasicInfo): string =
  &"{pkgInfo.name}-{pkgInfo.version.toDirectoryName}-{$pkgInfo.checksum}"

proc getPkgDest*(pkgInfo: PackageBasicInfo, options: Options): string =
  options.getPkgsDir() / pkgInfo.getCacheDir()

proc getPkgDest*(pkgInfo: PackageInfo, options: Options): string =
  pkgInfo.basicInfo.getPkgDest(options)

proc fullRequirements*(pkgInfo: PackageInfo): seq[PkgTuple] =
  ## Returns all requirements for a package (All top level + all task requirements)
  result = pkgInfo.requires
  for requirements in pkgInfo.taskRequires.values:
    result &= requirements

proc name*(pkgInfo: PackageInfo): string {.inline.} =
  pkgInfo.basicInfo.name

iterator lockedDepsFor*(allDeps: AllLockFileDeps, options: Options): (string, LockFileDep) =
  for task, deps in allDeps:
    if task in [noTask, options.task]:
      for name, dep in deps:
        yield (name, dep)

proc hasLockedDeps*(pkgInfo: PackageInfo): bool =
  ## Returns true if pkgInfo has any locked deps (including any tasks)
  # Check if any tasks have locked deps
  for deps in pkgInfo.lockedDeps.values:
    if deps.len > 0:
      return true

proc hasPackage*(deps: AllLockFileDeps, pkgName: string): bool =
  for deps in deps.values:
    if pkgName in deps:
      return true

proc `==`*(pkg1: PackageInfo, pkg2: PackageInfo): bool =
  pkg1.myPath == pkg2.myPath

proc hash*(x: PackageInfo): Hash =
  var h: Hash = 0
  h = h !& hash(x.myPath)
  result = !$h

proc getNameAndVersion*(pkgInfo: PackageInfo): string =
  &"{pkgInfo.basicInfo.name}@{pkgInfo.basicInfo.version}"

proc isNim*(name: string): bool =
  result = name == "nim" or name == "nimrod" or name == "compiler"

proc isNim*(pv: PkgTuple): bool = pv.name.isNim

proc hasLockFile*(pkgInfo: PackageInfo, options: Options): bool =
  return options.lockFile(pkgInfo.myPath.parentDir()).fileExists

proc hasNimInLockFile*(options: Options, dir: string = ""): bool =
  let lockFile = options.lockFile(if dir == "": getCurrentDir() else: dir)
  if options.useSystemNim or options.disableLockFile or not lockFile.fileExists:
    return false
  for name, dep in lockFile.getLockedDependencies.lockedDepsFor(options):
    if name.isNim:
      return true

when isMainModule:
  import unittest

  test "toValidPackageName":
    check toValidPackageName("foo__bar") == "foo_bar"
    check toValidPackageName("jhbasdh!£$@%#^_&*_()qwe") == "jhbasdh_qwe"
