import chronos
import results
import ./listener
import ./connection
import ./udp/datagram
import ./errors
import ./transport/tlsbackend

export Listener
export accept
export Connection
export Stream
export openStream
export localAddress
export remoteAddress
export incomingStream
export read
export write
export stop
export drop
export close
export waitClosed
export errors
export destroy
export CertificateVerifier
export certificateVerifierCB
export CustomCertificateVerifier
export InsecureCertificateVerifier
export init

type TLSConfig* = object
  certificate: seq[byte]
  key: seq[byte]
  certificateVerifier: Opt[CertificateVerifier]

type Quic = ref object of RootObj
  tlsConfig: TLSConfig

type QuicClient* = object of Quic

type QuicServer* = object of Quic

proc init*(
    t: typedesc[TLSConfig],
    certificate: seq[byte] = @[],
    key: seq[byte] = @[],
    certificateVerifier: Opt[CertificateVerifier] = Opt.none(CertificateVerifier),
): TLSConfig {.gcsafe, raises: [QuicConfigError].} =
  # In a config, certificate and keys are optional, but if using them, both must
  # be specified at the same time
  if certificate.len != 0 or key.len != 0:
    if certificate.len == 0:
      raise newException(QuicConfigError, "certificate is required in TLSConfig")

    if key.len == 0:
      raise newException(QuicConfigError, "key is required in TLSConfig")

  return TLSConfig(
    certificate: certificate, key: key, certificateVerifier: certificateVerifier
  )

proc init*(
    t: typedesc[QuicServer], tlsConfig: TLSConfig
): QuicServer {.raises: [QuicConfigError].} =
  if tlsConfig.certificate.len == 0:
    raise newException(QuicConfigError, "tlsConfig does not contain a certificate")

  return QuicServer(tlsConfig: tlsConfig)

proc init*(t: typedesc[QuicClient], tlsConfig: TLSConfig): QuicClient {.raises: [].} =
  return QuicClient(tlsConfig: tlsConfig)

proc listen*(
    self: QuicServer, address: TransportAddress
): Listener {.raises: [QuicError, TransportOsError].} =
  let tlsBackend = newServerTLSBackend(
    self.tlsConfig.certificate, self.tlsConfig.key, self.tlsConfig.certificateVerifier
  )

  return newListener(tlsBackend, address)

proc dial*(
    self: QuicClient, address: TransportAddress
): Future[Connection] {.async: (raises: [QuicError, TransportOsError]).} =
  let tlsBackend = newClientTLSBackend(
    self.tlsConfig.certificate, self.tlsConfig.key, self.tlsConfig.certificateVerifier
  )
  var connection: Connection
  proc onReceive(udp: DatagramTransport, remote: TransportAddress) {.async.} =
    let datagram = Datagram(data: udp.getMessage())
    connection.receive(datagram)

  let udp = newDatagramTransport(onReceive)
  connection = newOutgoingConnection(tlsBackend, udp, address)
  connection.startHandshake()
  return connection
