# Package

version       = "0.9.2"
author        = "bptato"
description   = "HTML5 parser for Chawan"
license       = "Unlicense"


# Dependencies

requires "nim >= 1.6.10"
requires "https://git.sr.ht/~bptato/chakasu >= 0.1.2"
