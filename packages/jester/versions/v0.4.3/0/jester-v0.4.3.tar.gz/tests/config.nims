switch("path", "..")
switch("path", ".")
