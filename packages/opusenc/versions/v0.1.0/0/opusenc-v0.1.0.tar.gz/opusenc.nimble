# Package

version       = "0.1.0"
author        = "Emery Hemingway"
description   = "Bindings to libopusenc"
license       = "BSD-3-Clause"
srcDir        = "src"

# Dependencies

requires "nim >= 1.2.0"

import distros
if detectOs(NixOS):
  foreignDep "libopus"
  foreignDep "libopusenc"
  foreignDep "pkgconfig"
