# Copyright (c) 2020 Xiph.Org

import options

{.passC: staticExec("pkg-config --cflags opus libopusenc").}
{.passL: staticExec("pkg-config --libs opus libopusenc").}

{.pragma: opeHeader, header: "opus/opusenc.h".}
{.pragma: opeProc, opeHeader, importc: "ope_$1".}
{.pragma: opeConst, opeHeader, importc: "OPE_$1".}

var
  API_VERSION* {.opeConst.}: cint
    ## API version for this module.

  OK* {.opeConst.}: cint
  BAD_ARG* {.opeConst.}: cint
  INTERNAL_ERROR* {.opeConst.}: cint
  UNIMPLEMENTED* {.opeConst.}: cint
  ALLOC_FAIL* {.opeConst.}: cint
  CANNOT_OPEN* {.opeConst.}: cint
  TOO_LATE* {.opeConst.}: cint
  INVALID_PICTURE* {.opeConst.}: cint
  INVALID_ICON* {.opeConst.}: cint
  WRITE_FAIL* {.opeConst.}: cint
  CLOSE_FAIL* {.opeConst.}: cint

proc strerror(error: cint): cstring {.opeProc.}
  ## Converts a libopusenc error code into a human readable string.

proc get_version_string*(): cstring {.opeProc.}
  ## Returns a string representing the version
  ## of libopusenc being used at run time.

proc get_abi_version*(): cint {.opeProc.}

type OpusEncError* = object of CatchableError

template opeCheck(body: untyped) =
  var
    res {.inject.}: cint
    err {.inject.} = addr res
  body
  if res != OK:
    raise newException(OpusEncError, $strerror(res))

type
  ope_write_func = proc (user_data: pointer; `ptr`: ptr cuchar;
      len: int32): cint {.cdecl.}
  ope_close_func = proc (user_data: pointer): cint {.cdecl.}
  ope_packet_func = proc (user_data: pointer; packet_ptr: ptr cuchar;
                        packet_len: int32; flags: uint32) {.cdecl.}

  OpusEncCallbacks {.bycopy.} = object
    write*: ope_write_func
      ## Callback for writing to the stream.
    close*: ope_close_func
      ## Callback for closing the stream.

  Callbacks* = object
    write*: proc (userData: pointer; buf: pointer; len: int): int {.gcsafe.}
      ## Callback for writing to the stream.
    close*: proc (userData: pointer): int {.gcsafe.}
      ## Callback for closing the stream.

  OggOpusComments* = distinct pointer
    ## Opaque comments pointer.

  OggOpusEnc* = distinct pointer
    ## Opaque encoder pointer.

  Family* = enum
    monoStereo = 0, surround = 1

proc newComments*(): OggOpusComments =
  ## Create a new comments object.
  proc comments_create(): OggOpusComments {.opeProc.}
  comments_create()

proc copy*(comments: OggOpusComments): OggOpusComments =
  ## Create a deep copy of a comments object.
  proc comments_copy(comments: OggOpusComments): OggOpusComments {.opeProc.}
  comments_copy(comments)

proc destroy*(comments: OggOpusComments) =
  ## Destroys a comments object.
  proc comments_destroy(comments: OggOpusComments) {.opeProc.}
  comments_destroy(comments)

proc add*(comments: OggOpusComments; tag, val: string) =
  ## Add a comment.
  proc comments_add(comments: OggOpusComments; tag: cstring;
      val: cstring): cint {.opeProc.}
  opeCheck:
    res = comments_add(comments, tag, val)

proc add*(comments: OggOpusComments; tagAndVal: string) =
  ## Add a comment as a single tag=value string.
  proc comments_add_string(comments: OggOpusComments;
      tag_and_val: cstring): cint {.opeProc.}
  opeCheck:
    res = comments_add_string(comments, tagAndVal)

proc addPicture*(comments: OggOpusComments; filename: string;
                              kind = -1; description = "") =
  ## Add a picture from a file.
  proc comments_add_picture(comments: OggOpusComments; filename: cstring;
                                picture_type: cint;
                                    description: cstring): cint {.opeProc.}
  opeCheck:
    let desc = if description == "": (cstring) nil else: (cstring)description
    res = comments_add_picture(comments, filename, (cint)kind, desc)

proc addPicture*(comments: OggOpusComments;
    data: pointer; size: int; kind = -1; description = "") =
  ## Add a picture already in memory.
  proc comments_add_picture_from_memory(comments: OggOpusComments;
      data: cstring; size: csize_t; picture_type: cint;
          description: cstring): cint {.opeProc.}
  opeCheck:
    let desc = if description == "": (cstring) nil else: (cstring)description
    res = comments_add_picture_from_memory(
      comments, cast[cstring](data), (csize_t)size, (cint)kind, desc)


proc encoderCreateFile*(path: string; comments: OggOpusComments;
                             rate: int32; channels: cint;
                                 family = monoStereo): OggOpusEnc =
  ## Create a new OggOpus file.
  proc encoder_create_file(path: cstring; comments: OggOpusComments;
                               rate: int32; channels: cint; family: cint;
                               error: ptr cint): OggOpusEnc {.opeProc.}
  opeCheck:
    result = encoder_create_file(
      path, comments, (int32)rate, channels, (cint)family, err)


proc encoderCreate*(callbacks: Callbacks;
                                  userData: pointer;
                                  comments: OggOpusComments; rate: int32;
                                  channels: cint;
                                      family = monoStereo): OggOpusEnc =
  ## Create a new OggOpus stream to be handled using callbacks
  proc encoder_create_callbacks(callbacks: ptr OpusEncCallbacks;
                                    user_data: pointer;
                                    comments: OggOpusComments; rate: int32;
                                    channels: cint; family: cint;
                                        error: ptr cint): OggOpusEnc {.opeProc.}
  let
    callbacks = OpusEncCallbacks(
      write: proc (user: pointer; buf: ptr cuchar; len: int32): cint {.cdecl.} =
      (cint)callbacks.write(userData, buf, (int)len)
    , close: proc (userData: pointer): cint {.cdecl.} =
      (cint)callbacks.close(userData)
    )
  opeCheck:
    result = encoder_create_callbacks(unsafeAddr callbacks, userData, comments,
        rate, channels, (cint)family, err)


proc createPull*(comments: OggOpusComments; rate: int32;
                             channels: cint; family = monoStereo): OggOpusEnc =
  ## Create a new OggOpus stream to be used along with ``getPage``
  ## This is mostly useful for muxing with other streams.
  proc encoder_create_pull(comments: OggOpusComments; rate: int32;
                               channels: cint; family: cint;
                                   error: ptr cint): OggOpusEnc {.opeProc.}
  opeCheck:
    result = encoder_create_pull(comments, rate, channels, (cint)family, err)

proc deferredInitWithMapping*(enc: OggOpusEnc; family: Family;
    streams: cint; coupledStreams: cint; mapping: ptr cuchar) =
  ## Deferred initialization of the encoder to force an explicit channel
  ## mapping. This can be used to override the default channel coupling,
  ## but using it for regular surround will almost certainly lead to worse
  ## quality.
  proc encoder_deferred_init_with_mapping(enc: OggOpusEnc; family: cint;
      streams: cint; coupled: cint; mapping: ptr cuchar): cint {.opeProc.}
  opeCheck:
    res = encoder_deferred_init_with_mapping(enc, (cint)family, streams,
        coupledStreams, mapping)

proc writeFloat*(enc: OggOpusEnc; pcm: ptr cfloat;
                             samplesPerChannel: int) =
  ## Add/encode any number of float samples to the stream.
  proc encoder_write_float(enc: OggOpusEnc; pcm: ptr cfloat;
                               samples_per_channel: cint): cint {.opeProc.}
  opeCheck:
    res = encoder_write_float(enc, pcm, (cint)samplesPerChannel)

proc write*(enc: OggOpusEnc; pcm: ptr int16;
                       samplesPerChannel: int) =
  ## Add/encode any number of 16-bit linear samples to the stream.
  proc encoder_write(enc: OggOpusEnc; pcm: ptr int16;
                         samples_per_channel: cint): cint {.opeProc.}
  opeCheck:
    res = encoder_write(enc, pcm, (cint)samplesPerChannel)

type Page* = tuple
  data: pointer
  size: int

proc getPage*(enc: OggOpusEnc; flush: bool): Option[Page] =
  ## Get the next page from the stream (only if using ``encoderCreatePull``).
  proc encoder_get_page(enc: OggOpusEnc; page: ptr ptr cuchar;
                            len: ptr int32; flush: cint): cint {.opeProc.}
  var
    page: ptr cuchar
    len: int32
  let res = encoder_get_page(enc, addr page, addr len, (cint)flush)
  if res == 0:
    none(Page)
  else:
    some((data: (pointer)page, size: (int)len))

proc drain*(enc: OggOpusEnc) =
  ## Finalizes the stream, but does not deallocate the object.
  proc encoder_drain(enc: OggOpusEnc): cint {.opeProc.}
  opeCheck:
    res = encoder_drain(enc)

proc destroy*(enc: OggOpusEnc) =
  ## Deallocates the obect. Make sure to ``drain`` first.
  proc encoder_destroy(enc: OggOpusEnc) {.opeProc.}
  encoder_destroy(enc)

proc chainCurrent*(enc: OggOpusEnc; comments: OggOpusComments) =
  ## Ends the stream and create a new stream within the same file.
  proc encoder_chain_current(enc: OggOpusEnc;
      comments: OggOpusComments): cint {.opeProc.}
  opeCheck:
    res = encoder_chain_current(enc, comments)

proc continueNewFile*(enc: OggOpusEnc; path: string;
                                   comments: OggOpusComments) =
  ## Ends the stream and create a new file.
  proc encoder_continue_new_file(enc: OggOpusEnc; path: cstring;
                                     com: OggOpusComments): cint {.opeProc.}
  opeCheck:
    res = encoder_continue_new_file(enc, path, comments)

proc continueNewCallbacks*(enc: OggOpusEnc; userData: pointer;
                                        comments: OggOpusComments) =
  ## Ends the stream and create a new file (callback-based).
  proc encoder_continue_new_callbacks(enc: OggOpusEnc; user_data: pointer;
      comments: OggOpusComments): cint {.opeProc.}
  opeCheck:
    res = encoder_continue_new_callbacks(enc, userData, comments)

proc flushHeader*(enc: OggOpusEnc) =
  ## Write out the header now rather than wait for audio to begin.
  proc encoder_flush_header(enc: OggOpusEnc): cint {.opeProc.}
  opeCheck:
    res = encoder_flush_header(enc)

var
  SET_DECISION_DELAY_REQUEST* {.opeConst.}: cint
  GET_DECISION_DELAY_REQUEST* {.opeConst.}: cint
  SET_MUXING_DELAY_REQUEST* {.opeConst.}: cint
  GET_MUXING_DELAY_REQUEST* {.opeConst.}: cint
  SET_COMMENT_PADDING_REQUEST* {.opeConst.}: cint
  GET_COMMENT_PADDING_REQUEST* {.opeConst.}: cint
  SET_SERIALNO_REQUEST* {.opeConst.}: cint
  GET_SERIALNO_REQUEST* {.opeConst.}: cint
  SET_PACKET_CALLBACK_REQUEST* {.opeConst.}: cint
  GET_PACKET_CALLBACK_REQUEST* {.opeConst.}: cint
  SET_HEADER_GAIN_REQUEST* {.opeConst.}: cint
  GET_HEADER_GAIN_REQUEST* {.opeConst.}: cint
  GET_NB_STREAMS_REQUEST* {.opeConst.}: cint
  GET_NB_COUPLED_STREAMS_REQUEST* {.opeConst.}: cint

proc ctl*(enc: OggOpusEnc; request: cint) {.varargs.} =
  ## Sets encoder options.
  proc encoder_ctl(enc: OggOpusEnc; request: cint): cint {.varargs, opeProc.}
  opeCheck:
    res = encoder_ctl(enc, request)
