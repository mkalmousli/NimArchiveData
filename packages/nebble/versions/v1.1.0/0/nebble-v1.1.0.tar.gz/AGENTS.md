# AGENTS.md — Nebble (Nim + Pebble SDK)

Nebble is a Nim wrapper for the Pebble SDK (4.9.127+), featuring a two-layer architecture: low-level FFI bindings generated from C headers and a high-level idiomatic Nim API on top.

## Build & Test Commands

```bash
nimble build             # Build CLI tool
nimble test              # Full suite: unit + integration + size checks
nimble testUnit          # Fast host-side unit tests only (run this most often)
nimble testSize          # Check Aplite binary < 24KB (skipped on macOS)
```

### Running Single Tests
```bash
# Host-side test — compiles and executes on your local machine
nim c --skipProjCfg -d:pebbleBasalt -r tests/test_macros.nim

# Device-side test — compile-only check (cannot run locally)
nim c -d:pebbleBasalt --compileOnly tests/test_highlevel.nim
```

`--skipProjCfg` bypasses `tests/nim.cfg` (cross-compilation config). Host tests use `tests/host.cfg` and mock headers from `tests/mocks/`.

### CLI Workflow
```bash
nebble new my_app        # Scaffold new project
nebble build --platform basalt
nebble install --emulator basalt
nebble logs --emulator basalt
```

## Architecture

### Two-Layer Design

**Layer 1 — FFI (`src/nebble/ffi/`)**: Auto-generated 1:1 C bindings via Futhark. One file per platform in `ffi/generated/` (e.g., `basalt.nim`). `ffi.nim` multiplexes them via `-d:pebble<Platform>` compile flags. Preserves C naming (`snake_case`).

**Layer 2 — High-Level API (`src/nebble/`)**: Nim-idiomatic wrappers organized by subsystem: `ui/`, `foundation/`, `graphics/`, `input/`, `comms/`. `src/nebble.nim` is the umbrella re-export. Prefer `import nebble` over `import nebble/ffi` in user code.

### Managed Handles (ARC Memory Safety)

All UI resources use `*Handle` types (e.g., `WindowHandle`, `TextLayerHandle`) defined by the `DefineUniqueHandle` macro in `src/nebble/ffi/managed.nim`. They track ownership state:

- `hoOwned` — Nim will call C `_destroy` on scope exit
- `hoParented` — added to a parent layer; SDK owns memory, Nim skips `_destroy`
- `hoUnowned` — wraps a system-provided pointer, never destroyed by Nim

`=copy` is disabled (`{.error.}`); use move semantics. `addChild` automatically transitions ownership to `hoParented`. Removing from a parent transitions back to `hoOwned`.

### `nebbleApp` / `nebbleWatchface` Macro

Defined in `src/nebble/ui/declarative.nim`. Generates the full app skeleton (entry point, window, event loop, `NimMain`, `_exit` stubs). Supports responsive layout keywords: `fullWidth`, `fullHeight`, `x=center`, `y=center`.

### Build Pipeline

The `nebble` CLI (in `src/nebble/cli/`) drives a three-phase build:
1. **Nim → C**: `nim c --os:any --cpu:arm --mm:arc --compileOnly` — outputs C files to platform-specific dirs (`src/c/aplite/`, `src/c/basalt/`, etc.)
2. **Bridge**: CLI generates `package.json` with all target platforms
3. **Pebble → .pbw**: `pebble build` via waf produces a unified bundle for all platforms

## Code Style Guidelines

### 1. Imports & Core Constraints
- **Prefix:** Always use `std/` for standard library modules (e.g., `import std/macros`).
- **Device Code:** NEVER import modules that use syscalls (e.g., `os`, `times`, `asyncdispatch`).
- **API Choice:** Prefer `import nebble` (high-level) over direct FFI.

### 2. Naming Conventions
- **High-Level:** `camelCase` for procs, variables, and parameters (e.g., `newTextLayer`).
- **FFI Layer:** `snake_case` to match C SDK (e.g., `text_layer_create`).
- **Constants:** `UPPER_SNAKE_CASE` (e.g., `GColorBlack`).
- **Platforms:** `pebble` + `CamelCase` (e.g., `-d:pebbleBasalt`).

### 3. Types & Memory
- **Handles:** Use Managed Handles (e.g., `WindowHandle`) for automatic cleanup via ARC.
- **Pointers:** Raw pointers (`ptr T`) should only be used in `{.cdecl.}` callbacks.
- **Strings:** Use `cstring` for device code. Avoid `string` to prevent heap allocations.
- **ARC:** The project uses `--mm:arc -d:useMalloc` for deterministic memory management.

### 4. Error Handling
- **Exceptions:** Disabled via `--os:any`.
- **Assertions:** Use `doAssert condition, "message"` for runtime checks.
- **Results:** Check return codes from FFI calls (e.g., `AppMessageResult`).

### 5. Formatting & Structure
- **Indentation:** 2 spaces.
- **Line Length:** 100 characters max.
- **Banners:** Separate major sections with `# ===` banners.
- **Pragmas:** Callbacks MUST use `{.cdecl.}`. Entry points use `{.exportc, cdecl.}`.

### 6. Platform Feature Detection
```nim
when declared(GColorRed):
  # Color platforms only (Basalt, Chalk, Emery, Gabbro)
  textLayer.textColor = GColorRed
```
`when declared(...)` compiles to zero code on unsupported platforms.

## Implementation Details
- **Managed Handles:** Defined using the `DefineUniqueHandle` macro in `src/nebble/ffi/managed.nim`.
- **Declarative DSL:** Use `nebbleApp` or `nebbleWatchface` for minimal boilerplate.
- **Heap-Free Strings:** Use `FixedString[N]` with the `f` macro for stack-allocated formatting. Use `.cstr` to get a `cstring`. **The `FixedString` must outlive its `cstring` pointer** — `text_layer_set_text` stores the pointer without copying, so always use global or field-level `FixedString` for persistent text.

## Supported Platforms

| Define | Hardware | Display | Color |
|--------|----------|---------|-------|
| `-d:pebbleAplite` | Pebble Classic | 144×168 | B&W |
| `-d:pebbleBasalt` | Pebble Time | 144×168 | Color |
| `-d:pebbleChalk` | Pebble Time Round | 180×180 round | Color |
| `-d:pebbleDiorite` | Pebble 2 | 144×168 | B&W |
| `-d:pebbleFlint` | Pebble 2 Duo | 144×168 | B&W |
| `-d:pebbleEmery` | Pebble Time 2 | 200×228 | Color |
| `-d:pebbleGabbro` | Pebble Round 2 | 260×260 round | Color |

Use `-d:pebbleBasalt` as the default for testing. Aplite has the tightest constraints (24KB binary limit, no color).

## Debug Flags

- `-d:nebbleManagedDebug` — enables runtime assertions and logging in managed handles
- `-d:nebbleManagedStrict` — enables extra assertions and panics on misuse
