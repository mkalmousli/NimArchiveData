switch("path", "$projectDir/src")
