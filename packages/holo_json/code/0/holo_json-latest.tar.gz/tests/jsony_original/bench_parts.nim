import benchy, eminim, jason, random, streams
import jsony
import holo_json except toJson
when defined(packedjson):
  import packedjson, packedjson/deserialiser
else:
  import json
const status = not defined(gcArc) and not defined(js)
when status:
  import serialization
  import json_serialization except Json, toJson

when defined(js):
  template keep(x) =
    let a = x
    {.emit: ["this.keepValue = ", a, ";"].}

block:
  echo "deserialize string:"
  var jsonStr = "\"hello there how are you?\""
  timeIt "treeform/jsony", 100:
    for i in 0 ..< 1000:
      keep jsony.fromJson(jsonStr, string)

  timeIt "holo_json", 100:
    for i in 0 ..< 1000:
      keep holo_json.fromJson(jsonStr, string)

  timeIt "holo_json no line column", 100:
    var reader = initJsonReader(doLineColumn = false)
    for i in 0 ..< 1000:
      reader.startRead(jsonStr)
      var s: string
      holo_json.readJson(reader, s)
      keep s

  when status:
    timeIt "status-im/nim-json-serialization", 100:
      for i in 0 ..< 1000:
        keep json_serialization.Json.decode(jsonStr, string)

block:
  echo "deserialize obj:"
  type Node = ref object
    active: bool
    kind: string
    name: string
    id: int
    kids: seq[Node]
  var node = Node()
  var jsonStr = jsony.toJson(node)
  timeIt "treeform/jsony", 100:
    for i in 0 ..< 1000:
      keep jsony.fromJson(jsonStr, Node)
  timeIt "holo_json", 100:
    for i in 0 ..< 1000:
      keep holo_json.fromJson(jsonStr, Node)

  timeIt "holo_json no line column", 100:
    var reader = initJsonReader(doLineColumn = false)
    for i in 0 ..< 1000:
      reader.startRead(jsonStr)
      var s: Node
      holo_json.readJson(reader, s)
      keep s

  when status:
    timeIt "status-im/nim-json-serialization", 100:
      for i in 0 ..< 1000:
        keep json_serialization.Json.decode(jsonStr, Node)

block:
  echo "deserialize seq[obj]:"
  type Node = object
    active: bool
    kind: string
    name: string
    id: int
    kids: seq[Node]
  var seqObj: seq[Node]
  let count = when defined(js): 1000 else: 100000
  for i in 0 ..< count:
    seqObj.add(Node())
  var jsonStr = seqObj.toJson()
  timeIt "treeform/jsony", 100:
    keep jsony.fromJson(jsonStr, seq[Node])
  timeIt "holo_json", 100:
    keep holo_json.fromJson(jsonStr, seq[Node])

  timeIt "holo_json no line column", 100:
    var reader = initJsonReader(doLineColumn = false)
    reader.startRead(jsonStr)
    var s: seq[Node]
    holo_json.readJson(reader, s)
    keep s

  when status:
    timeIt "status-im/nim-json-serialization", 100:
      keep json_serialization.Json.decode(jsonStr, seq[Node])

block:
  echo "serialize int:"
  var number42: uint64 = 42

  timeIt "$", 100:
    for i in 0 ..< 1000:
      keep $number42

  timeIt "treeform/jsony", 100:
    for i in 0 ..< 1000:
      keep jsony.toJson(number42)

  timeIt "holo_json", 100:
    for i in 0 ..< 1000:
      keep holo_json.toJson(number42)

  timeIt "holo_json writer", 100:
    var writer = initJsonWriter()
    for i in 0 ..< 1000:
      writer.startWrite()
      writer.dumpJson(number42)
      keep finishWrite(writer)

  timeIt "disruptek/jason", 100:
    for i in 0 ..< 1000:
      keep number42.jason.string

  when status:
    timeIt "status-im/nim-json-serialization", 100:
      for i in 0 ..< 1000:
        keep json_serialization.Json.encode(number42)

block:
  echo "serialize string:"
  var hello = "Hello"

  timeIt "'$'", 100:
    for i in 0 ..< 1000:
      keep '"' & hello & '"'

  timeIt "treeform/jsony", 100:
    for i in 0 ..< 1000:
      keep jsony.toJson(hello)

  timeIt "holo_json", 100:
    for i in 0 ..< 1000:
      keep holo_json.toJson(hello)

  timeIt "holo_json writer", 100:
    var writer = initJsonWriter()
    for i in 0 ..< 1000:
      writer.startWrite()
      writer.dumpJson(hello)
      keep finishWrite(writer)

  timeIt "disruptek/jason", 100:
    for i in 0 ..< 1000:
      keep hello.jason.string

  when status:
    timeIt "status-im/nim-json-serialization", 100:
      for i in 0 ..< 1000:
        keep json_serialization.Json.encode(hello)

block:
  echo "serialize seq:"
  var numArray = @[1, 2, 3, 4, 5, 6, 7, 8, 9]

  timeIt "treeform/jsony", 100:
    for i in 0 ..< 1000:
      keep jsony.toJson(numArray)

  timeIt "holo_json", 100:
    for i in 0 ..< 1000:
      keep holo_json.toJson(numArray)

  timeIt "disruptek/jason", 100:
    for i in 0 ..< 1000:
      keep numArray.jason.string

  when status:
    timeIt "status-im/nim-json-serialization", 100:
      for i in 0 ..< 1000:
        keep json_serialization.Json.encode(numArray)

block:
  echo "serialize obj:"
  type Node = ref object
    active: bool
    kind: string
    name: string
    id: int
    kids: seq[Node]
  var node = Node()

  timeIt "treeform/jsony", 100:
    for i in 0 ..< 1000:
      keep jsony.toJson(node)

  timeIt "holo_json", 100:
    for i in 0 ..< 1000:
      keep holo_json.toJson(node)

  timeIt "disruptek/jason", 100:
    for i in 0 ..< 1000:
      keep node.jason.string

  when status:
    timeIt "status-im/nim-json-serialization", 100:
      for i in 0 ..< 1000:
        keep json_serialization.Json.encode(node)
