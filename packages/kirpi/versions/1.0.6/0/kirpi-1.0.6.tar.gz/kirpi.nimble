# Package

version       = "1.0.6"
author        = "Eray Zesen"
description   = "A minimal 2D game and ia framework. "
license       = "MIT"
srcDir        = "src"



# Dependencies

requires "nim >= 2.2.4"
requires "naylib"
