version       = "0.1.0"
author        = "Carlo Capocasa"
description   = "simple-fax.de CLI client"
license       = "MIT"
srcDir        = "."
bin           = @["sfax"]

requires "nim >= 2.0.0"
requires "zippy >= 0.10.0"
