import std/[httpclient, base64, os, strutils, strformat, random, sequtils]
import zippy

const
  Version = staticRead("sfax.nimble").splitLines().filterIt(it.startsWith("version")).
    mapIt(it.split("=")[1].strip().strip(chars = {'"'}))[0]
  UserAgent = "sfax/" & Version & " (+https://github.com/capocasa/sfax)"
  SoapEndpoint = "https://longisland.simple-fax.de/soap/index.php"

proc genId(): string =
  randomize()
  result = "sfax-" & $rand(100000..999999)

proc buildSoapEnvelope(user, pass, faxnumber, data, filetype, identifier, statusurl: string): string =
  result = fmt"""<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                  xmlns:xsd="http://www.w3.org/2001/XMLSchema"
                  xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
                  xmlns:urn="urn:soapservice">
  <soapenv:Header/>
  <soapenv:Body>
    <urn:sendfax soapenv:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
      <username xsi:type="xsd:string">{user}</username>
      <password xsi:type="xsd:string">{pass}</password>
      <faxnumber xsi:type="xsd:string">{faxnumber}</faxnumber>
      <data xsi:type="xsd:string">{data}</data>
      <filetype xsi:type="xsd:string">{filetype}</filetype>
      <identifier xsi:type="xsd:string">{identifier}</identifier>
      <statusurl xsi:type="xsd:string">{statusurl}</statusurl>
    </urn:sendfax>
  </soapenv:Body>
</soapenv:Envelope>"""

proc sendFax(user, pass, faxnumber, pdfPath: string, statusurl = ""): bool =
  if not fileExists(pdfPath):
    stderr.writeLine "Error: File not found: " & pdfPath
    return false

  let pdfData = readFile(pdfPath)
  let b64Data = encode(pdfData)
  let identifier = genId()

  let envelope = buildSoapEnvelope(user, pass, faxnumber, b64Data, "PDF", identifier, statusurl)

  var client = newHttpClient(userAgent = UserAgent)
  client.headers = newHttpHeaders({
    "Accept-Encoding": "gzip, deflate"
  })

  try:
    # Fetch WSDL first like PHP SoapClient does
    discard client.getContent(SoapEndpoint & "?wsdl")

    # Now do the actual SOAP call
    client.headers = newHttpHeaders({
      "Content-Type": "text/xml; charset=utf-8",
      "SOAPAction": "\"urn:soapservice#Service#sendfax\"",
      "Accept-Encoding": "gzip, deflate"
    })
    let resp = client.request(SoapEndpoint, httpMethod = HttpPost, body = envelope)

    # Decompress if gzipped
    var body = resp.body
    if "gzip" in resp.headers.getOrDefault("Content-Encoding"):
      body = uncompress(body)

    # Parse response: look for "success;" or "error;"
    if "success;" in body:
      return true
    elif "error;" in body or "Error" in body:
      let msg = body.split(";")[^1].split("<")[0].strip()
      stderr.writeLine msg
      return false
    else:
      stderr.writeLine "Unknown response: " & body[0..min(200, body.len-1)]
      return false
  except:
    stderr.writeLine getCurrentExceptionMsg()
    return false
  finally:
    client.close()

proc main() =
  let args = commandLineParams()

  if "-v" in args or "--version" in args:
    echo "sfax ", Version
    quit(0)

  if args.len < 2 or "-h" in args or "--help" in args:
    echo "sfax ", Version, " - simple-fax.de CLI client"
    echo ""
    echo "Usage: sfax <faxnumber> <pdf_file> [--user EMAIL] [--pass PASSWORD] [--status-url URL]"
    echo ""
    echo "Environment:"
    echo "  SFAX_USER  simple-fax.de login email"
    echo "  SFAX_PASS  simple-fax.de password"
    echo ""
    echo "Examples:"
    echo "  sfax 08999954391 invoice.pdf"
    echo "  sfax +49899954391 doc.pdf --user me@example.com --pass secret"
    quit(0)

  var
    faxnumber = args[0]
    pdfPath = args[1]
    user = getEnv("SFAX_USER")
    pass = getEnv("SFAX_PASS")
    statusurl = ""

  var i = 2
  while i < args.len:
    case args[i]
    of "--user":
      user = args[i+1]
      i += 2
    of "--pass":
      pass = args[i+1]
      i += 2
    of "--status-url":
      statusurl = args[i+1]
      i += 2
    else:
      i += 1

  if user == "" or pass == "":
    stderr.writeLine "Error: Set SFAX_USER and SFAX_PASS environment variables or use --user/--pass"
    quit(1)

  if sendFax(user, pass, faxnumber, pdfPath, statusurl):
    quit(0)
  else:
    quit(1)

when isMainModule:
  main()
