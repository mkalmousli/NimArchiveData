# Package
version       = "1.0.0"
author        = "Janni Adamski"
description   = "Infer a JSON Schema (draft 2020-12) from any JSON value"
license       = "MIT"
srcDir        = "src"
bin           = @["json2schema"]
binDir        = "bin"

# Dependencies
requires "nim >= 1.6.0"

# ── Tasks ──────────────────────────────────────────────────────────────────

task test, "Run the test suite":
  exec "nim compile --opt:speed -r tests/test_all.nim"

task build, "Build the release binary":
  exec "nim compile --opt:speed -d:release src/json2schema.nim"

task docs, "Generate HTML documentation":
  exec "nim doc --project --index:on --outdir:docs src/json2schemalib.nim"
