## tests/test_all.nim
## Full test suite for json2schemalib.
## Run with:  nim compile -r tests/test_all.nim

import std/[json, strutils, unittest]

# Adjust path so the library is found when running from the project root
import "../src/json2schemalib"

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

proc hasType(schema: JsonNode, t: string): bool =
  schema.hasKey("type") and schema["type"].getStr == t

proc schemaType(schema: JsonNode): string =
  if schema.hasKey("type"): schema["type"].getStr else: ""

# ---------------------------------------------------------------------------
# Primitive types
# ---------------------------------------------------------------------------

suite "Primitive types":

  test "null":
    let s = jsonToSchema(newJNull())
    check hasType(s, "null")

  test "boolean true":
    let s = jsonToSchema(%true)
    check hasType(s, "boolean")

  test "boolean false":
    let s = jsonToSchema(%false)
    check hasType(s, "boolean")

  test "integer":
    let s = jsonToSchema(%42)
    check hasType(s, "integer")

  test "negative integer":
    let s = jsonToSchema(% -7)
    check hasType(s, "integer")

  test "float":
    let s = jsonToSchema(%3.14)
    check hasType(s, "number")

  test "string":
    let s = jsonToSchema(%"hello")
    check hasType(s, "string")

  test "empty string":
    let s = jsonToSchema(%"")
    check hasType(s, "string")

# ---------------------------------------------------------------------------
# No real values leak into the schema
# ---------------------------------------------------------------------------

suite "No real values in output":

  test "string value not present":
    let s = jsonToSchema(%"secret-password")
    check schemaType(s) == "string"
    check s.len == 1   # only "type" key

  test "integer value not present":
    let s = jsonToSchema(%99999)
    check schemaType(s) == "integer"
    check s.len == 1

  test "float value not present":
    let s = jsonToSchema(%2.718)
    check schemaType(s) == "number"
    check s.len == 1

  test "boolean value not present":
    let s = jsonToSchema(%true)
    check schemaType(s) == "boolean"
    check s.len == 1

  test "object values not present":
    let j = parseJson("""{"name":"Alice","age":30}""")
    let s = jsonToSchema(j)
    let raw = $s
    check "Alice" notin raw
    check "30" notin raw

  test "nested string values not present":
    let j = parseJson("""{"user":{"email":"user@example.com","token":"abc123"}}""")
    let s = jsonToSchema(j)
    let raw = $s
    check "user@example.com" notin raw
    check "abc123" notin raw

  test "array string values not present":
    let j = parseJson("""["alpha","beta","gamma"]""")
    let s = jsonToSchema(j)
    let raw = $s
    check "alpha" notin raw
    check "beta" notin raw
    check "gamma" notin raw

# ---------------------------------------------------------------------------
# Objects
# ---------------------------------------------------------------------------

suite "Object schemas":

  test "empty object":
    let s = jsonToSchema(parseJson("{}"))
    check hasType(s, "object")
    check not s.hasKey("properties")
    check not s.hasKey("required")

  test "flat object has properties":
    let s = jsonToSchema(parseJson("""{"x":1,"y":2}"""))
    check hasType(s, "object")
    check s.hasKey("properties")
    check s["properties"].hasKey("x")
    check s["properties"].hasKey("y")

  test "flat object all fields required":
    let s = jsonToSchema(parseJson("""{"a":1,"b":"two"}"""))
    let req = s["required"]
    check req.kind == JArray
    var keys: seq[string]
    for v in req: keys.add(v.getStr)
    check "a" in keys
    check "b" in keys

  test "additionalProperties is false":
    let s = jsonToSchema(parseJson("""{"k":"v"}"""))
    check s.hasKey("additionalProperties")
    check s["additionalProperties"].getBool == false

  test "nested object":
    let s = jsonToSchema(parseJson("""{"inner":{"flag":true}}"""))
    let inner = s["properties"]["inner"]
    check hasType(inner, "object")
    check hasType(inner["properties"]["flag"], "boolean")

  test "property types are correct":
    let j = parseJson("""{"s":"hi","i":1,"f":1.5,"b":true,"n":null}""")
    let props = jsonToSchema(j)["properties"]
    check schemaType(props["s"]) == "string"
    check schemaType(props["i"]) == "integer"
    check schemaType(props["f"]) == "number"
    check schemaType(props["b"]) == "boolean"
    check schemaType(props["n"]) == "null"

# ---------------------------------------------------------------------------
# Arrays
# ---------------------------------------------------------------------------

suite "Array schemas":

  test "empty array — no items key":
    let s = jsonToSchema(parseJson("[]"))
    check hasType(s, "array")
    check not s.hasKey("items")

  test "homogeneous string array":
    let s = jsonToSchema(parseJson("""["a","b","c"]"""))
    check hasType(s, "array")
    check s.hasKey("items")
    check schemaType(s["items"]) == "string"

  test "homogeneous integer array":
    let s = jsonToSchema(parseJson("[1,2,3]"))
    check schemaType(s["items"]) == "integer"

  test "single element array":
    let s = jsonToSchema(parseJson("[42]"))
    check schemaType(s["items"]) == "integer"

  test "mixed-type array uses anyOf":
    let s = jsonToSchema(parseJson("""[1,"two",true]"""))
    let items = s["items"]
    check items.hasKey("anyOf")
    check items["anyOf"].len == 3

  test "mixed array anyOf contains no real values":
    let s = jsonToSchema(parseJson("""[1,"secret",true]"""))
    let raw = $s
    check "secret" notin raw
    check "1" notin raw or raw.contains(""""type": "integer"""") # type label OK

  test "array of identical objects deduplicates":
    let s = jsonToSchema(parseJson("""[{"id":1},{"id":2},{"id":3}]"""))
    # All items have same shape → items should be a single object schema
    let items = s["items"]
    check hasType(items, "object")
    check not items.hasKey("anyOf")

  test "array of objects — item values not present":
    let s = jsonToSchema(parseJson("""[{"name":"Bob"},{"name":"Carol"}]"""))
    let raw = $s
    check "Bob" notin raw
    check "Carol" notin raw

  test "nested array":
    let s = jsonToSchema(parseJson("[[1,2],[3,4]]"))
    check hasType(s, "array")
    let inner = s["items"]
    check hasType(inner, "array")
    check schemaType(inner["items"]) == "integer"

# ---------------------------------------------------------------------------
# buildSchema (top-level wrapper)
# ---------------------------------------------------------------------------

suite "buildSchema wrapper":

  test "adds $schema key":
    let s = buildSchema(parseJson("""{"x":1}"""))
    check s.hasKey("$schema")
    check s["$schema"].getStr == "https://json-schema.org/draft/2020-12/schema"

  test "top-level type preserved":
    let s = buildSchema(parseJson("""{"x":1}"""))
    check hasType(s, "object")

  test "top-level array":
    let s = buildSchema(parseJson("[1,2,3]"))
    check hasType(s, "array")
    check s["$schema"].getStr.startsWith("https://json-schema.org")

  test "no real values in wrapped schema":
    let s = buildSchema(parseJson("""{"password":"hunter2","pin":1234}"""))
    let raw = $s
    check "hunter2" notin raw
    check "1234" notin raw or raw.contains(""""type": "integer"""")

# ---------------------------------------------------------------------------
# mergeSchemas
# ---------------------------------------------------------------------------

suite "mergeSchemas":

  test "empty list → empty object":
    let s = mergeSchemas(@[])
    check s.kind == JObject
    check s.len == 0

  test "single schema returned as-is":
    let s = mergeSchemas(@[%*{"type": "string"}])
    check schemaType(s) == "string"

  test "same type deduplicates to one":
    let schemas = @[%*{"type": "integer"}, %*{"type": "integer"}]
    let s = mergeSchemas(schemas)
    check schemaType(s) == "integer"
    check not s.hasKey("anyOf")

  test "different types produce anyOf":
    let schemas = @[%*{"type": "string"}, %*{"type": "integer"}]
    let s = mergeSchemas(schemas)
    check s.hasKey("anyOf")
    check s["anyOf"].len == 2

  test "structural dedup reduces anyOf entries":
    let schemas = @[
      %*{"type": "string"},
      %*{"type": "string"},
      %*{"type": "integer"}
    ]
    let s = mergeSchemas(schemas)
    check s.hasKey("anyOf")
    check s["anyOf"].len == 2   # "string" deduplicated

# ---------------------------------------------------------------------------
# Round-trip sanity: output is valid JSON
# ---------------------------------------------------------------------------

suite "Output is valid JSON":

  test "complex document parses back":
    let j = parseJson("""
      {
        "id": 1,
        "tags": ["a","b"],
        "meta": {"created": "2024-01-01", "active": true},
        "scores": [1.1, 2.2, 3.3],
        "nothing": null
      }
    """)
    let s = buildSchema(j)
    let reparsed = parseJson(s.pretty())
    check reparsed.hasKey("$schema")
    check reparsed.hasKey("type")
