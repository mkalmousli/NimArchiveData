## json2schema
## ===========
## Command-line tool: converts a JSON file (or stdin) to a JSON Schema.
##
## Usage:
##   json2schema <input.json> [output.json]
##   echo '{"x":1}' | json2schema -

import std/[json, os]
import json2schemalib

proc usage() =
  echo """
json2schema — JSON to JSON Schema converter (draft 2020-12)

Usage:
  json2schema <input.json> [output.json]
  json2schema -                          # read from stdin, write to stdout

Options:
  -h, --help    Show this help and exit

Examples:
  json2schema data.json                  # infer schema, print to stdout
  json2schema data.json schema.json      # infer schema, write to file
  cat data.json | json2schema -          # pipe mode
"""

proc main() =
  let args = commandLineParams()

  if args.len == 0 or args[0] in ["-h", "--help"]:
    usage()
    quit(0)

  # ── Read input ──────────────────────────────────────────────────────────
  var raw: string
  if args[0] == "-":
    raw = stdin.readAll()
  else:
    if not fileExists(args[0]):
      stderr.writeLine "Error: file not found: " & args[0]
      quit(1)
    raw = readFile(args[0])

  let inputJson =
    try:
      parseJson(raw)
    except JsonParsingError as e:
      stderr.writeLine "Error: invalid JSON — " & e.msg
      quit(1)

  # ── Convert ─────────────────────────────────────────────────────────────
  let schema = buildSchema(inputJson)
  let output = schema.pretty() & "\n"

  # ── Write output ─────────────────────────────────────────────────────────
  if args.len >= 2:
    writeFile(args[1], output)
    echo "Schema written to: " & args[1]
  else:
    stdout.write output

main()
