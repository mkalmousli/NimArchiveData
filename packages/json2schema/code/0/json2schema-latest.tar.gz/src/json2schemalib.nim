## json2schemalib
## ===============
## Core logic for inferring a JSON Schema (draft 2020-12) from a JSON value.
## No "real" values from the source document are ever copied into the output;
## only structural / type information is emitted.

import std/[json, sets]

# ---------------------------------------------------------------------------
# Forward declaration
# ---------------------------------------------------------------------------

proc inferArrayItems*(arr: JsonNode): JsonNode

# ---------------------------------------------------------------------------
# Schema inference
# ---------------------------------------------------------------------------

proc jsonToSchema*(node: JsonNode): JsonNode =
  ## Recursively infer a JSON Schema node from a JSON value.
  ##
  ## Rules
  ## -----
  ## * ``null``    → ``{"type": "null"}``
  ## * ``bool``    → ``{"type": "boolean"}``
  ## * ``int``     → ``{"type": "integer"}``
  ## * ``float``   → ``{"type": "number"}``
  ## * ``string``  → ``{"type": "string"}``
  ## * ``array``   → ``{"type": "array", "items": <merged item schema>}``
  ## * ``object``  → ``{"type": "object", "properties": {...},
  ##                    "required": [...], "additionalProperties": false}``
  result = newJObject()

  case node.kind
  of JNull:
    result["type"] = %"null"

  of JBool:
    result["type"] = %"boolean"

  of JInt:
    result["type"] = %"integer"

  of JFloat:
    result["type"] = %"number"

  of JString:
    result["type"] = %"string"

  of JArray:
    result["type"] = %"array"
    if node.len > 0:
      result["items"] = inferArrayItems(node)

  of JObject:
    result["type"] = %"object"
    if node.len > 0:
      let props = newJObject()
      var required: seq[string] = @[]
      for k, v in node:
        props[k] = jsonToSchema(v)
        required.add(k)
      result["properties"] = props
      if required.len > 0:
        result["required"] = %required
      result["additionalProperties"] = %false

proc mergeSchemas*(schemas: seq[JsonNode]): JsonNode =
  ## Merge a list of per-element schemas into a single ``items`` schema.
  ##
  ## * Empty list  → ``{}``  (empty / permissive schema)
  ## * Single      → the schema itself
  ## * All same primitive type → that type schema (de-duplicated)
  ## * Otherwise   → ``{"anyOf": [<unique schemas>]}``
  if schemas.len == 0:
    return newJObject()
  if schemas.len == 1:
    return schemas[0]

  # Fast path: all simple schemas share exactly one type string
  var typeSet: HashSet[string]
  var allSimple = true
  for s in schemas:
    if s.hasKey("type") and s["type"].kind == JString:
      typeSet.incl(s["type"].getStr)
    else:
      allSimple = false
      break

  if allSimple and typeSet.len == 1:
    return schemas[0]

  # Structural deduplication via JSON text representation
  var seen: HashSet[string]
  var unique: seq[JsonNode]
  for s in schemas:
    let key = $s
    if key notin seen:
      seen.incl(key)
      unique.add(s)

  if unique.len == 1:
    return unique[0]

  result = newJObject()
  result["anyOf"] = %unique

proc inferArrayItems*(arr: JsonNode): JsonNode =
  ## Collect per-element schemas for every element of ``arr`` and merge them.
  var itemSchemas: seq[JsonNode]
  for elem in arr.elems:
    itemSchemas.add(jsonToSchema(elem))
  mergeSchemas(itemSchemas)

# ---------------------------------------------------------------------------
# Top-level wrapper
# ---------------------------------------------------------------------------

proc buildSchema*(node: JsonNode): JsonNode =
  ## Wrap an inferred schema with the ``$schema`` declaration.
  result = newJObject()
  result["$schema"] = %"https://json-schema.org/draft/2020-12/schema"
  let inner = jsonToSchema(node)
  for k, v in inner:
    result[k] = v
