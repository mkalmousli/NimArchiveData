# Package

version       = "0.1.0"
author        = "bk20x"
description   = "Small GUI tool for hashing files or mass hashing directories"
license       = "MIT"
srcDir        = "src"
bin           = @["hashbrowns"]


# Dependencies

requires "nim >= 1.6"
requires "nigui >= 0.2.8"
requires "nimcrypto >= 0.7.2"
