import std/[sugar, strutils, os, strformat, times]
import pkg/[nigui, nigui/msgbox, nimcrypto]
import utils



proc hashOfString(algo, contents: string): string =
  case algo
  of "sha1":
    let hash = sha1.digest(contents)
    return $hash
  of "sha256":
    let hash = sha256.digest(contents)
    return $hash
  of "sha384":
    let hash = sha384.digest(contents)
    return $hash
  of "sha512":
    let hash = sha512.digest(contents)
    return $hash
  of "keccak256":
    let hash = keccak256.digest(contents)
    return $hash
  of "keccak512":
    let hash = keccak512.digest(contents)
    return $hash
  of "blake2_224":
    let hash = blake2_224.digest(contents)
    return $hash
  of "blake2_256":
    let hash = blake2_256.digest(contents)
    return $hash
  of "blake2_384":
    let hash = blake2_384.digest(contents)
    return $hash
  of "blake2_512":
    let hash = blake2_512.digest(contents)
    return $hash
  else:
    return "Not implemented"
     
  
app.init()

var
  window                = newWindow("hashbrowns")
  mainContainer         = newLayoutContainer(Layout_Vertical)
  algoContainer         = newLayoutContainer(Layout_Horizontal)

  algoSelect            = newComboBox()
  hashButton            = newButton("Hash")
  hashOutput            = newTextBox()
  hashContainer         = newLayoutContainer(Layout_Horizontal)
  
  selectFileContainer   = newLayoutContainer(Layout_Horizontal)
  selectFileButton      = newButton("Select a file")
  selectedFileBox       = newTextBox()
  selectedFile          = ""
  
  selectDirContainer    = newLayoutContainer(Layout_Horizontal)
  selectDirButton       = newButton("Select a directory")
  selectedDirBox        = newTextBox()

  massHashOutContainer  = newLayoutContainer(Layout_Horizontal)
  massHashButton        = newButton("Hash")
  selectOutPathButton   = newButton("Select output path")
  selectedOutBox        = newTextBox()
  selectedDir           = ""
  outPath               = ""
  


algoSelect.let:
  it.fontSize = 16.0
  it.options  = @[
    "sha1",
    "sha256",
    "sha384",
    "sha512",
    "keccak256",
    "keccak512",
    "blake2_256",
    "blake2_384",
    "blake2_512"
  ]


  
hashContainer.let:
  it.widthMode = WidthMode_Expand
  it.add hashButton
  it.add hashOutput

  
hashButton.let:
  it.onClick = (event: ClickEvent) => (
    if selectedFile.isEmptyOrWhitespace:
      discard window.msgBox("Please select a file!!", "No file selected")
    elif not (fileExists selectedFile):
      discard window.msgBox(fmt"Invalid file! {selectedFile}")
    else:
      let
        contents = readFile(selectedFile)
        algo     = algoSelect.value
        hash     = algo.hashOfString(contents)
      hashOutput.text = hash
  )

  
algoContainer.let:
  let label = newLabel("Algorithm: ")
  label.fontSize = 22.0 
  it.add label
  it.add algoSelect
  it.widthMode = WidthMode_Expand

  
selectFileContainer.let:
  it.add selectFileButton
  it.add selectedFileBox
  it.widthMode = WidthMode_Expand

  
selectFileButton.let:
  it.fontSize = 16.0 
  it.onClick = (event: ClickEvent) => (
    var dialog   = newOpenFileDialog()
    dialog.title = "Select file to hash"
    dialog.run()
    if dialog.files.len == 1:
      let selected = dialog.files[0]
      selectedFile = selected
      selectedFileBox.text = selected
  )

  
selectedFileBox.let:
  it.onTextChange = (event: TextChangeEvent) => (
    selectedFile = it.text
  )

  
selectDirContainer.let:
  it.add selectDirButton
  it.add selectedDirBox
  it.widthMode = WidthMode_Expand

  
selectDirButton.let:
  it.onClick = (event: ClickEvent) => (
    var dialog    = newSelectDirectoryDialog()
    dialog.title  = "Select directory to Mass hash"
    dialog.run()
    if dirExists dialog.selectedDirectory:
      selectedDir = dialog.selectedDirectory
      selectedDirBox.text = selectedDir
  )

  
selectedDirBox.let:
  it.onTextChange = (event: TextChangeEvent) => (
    selectedDir = it.text  
  )

  
massHashOutContainer.let:
  it.heightMode = HeightMode_Expand
  it.add massHashButton 
  it.add selectOutPathButton
  it.add selectedOutBox


selectedOutBox.let:
  it.onTextChange = (event: TextChangeEvent) => (
    outPath = it.text
  )

  
massHashButton.let:
  it.onClick = (event: ClickEvent) => (
    if selectedDir.isEmptyOrWhitespace:
      discard window.msgbox(fmt"Please select a directory!", "Directory missing")
      return
    if outPath.isEmptyOrWhitespace:
      discard window.msgbox(fmt"Please select an output file!", "Output file missing")
      return
    if not (dirExists selectedDir):
      discard window.msgbox(fmt"Invalid directory! {selectedDir}", "Invalid directory")
      return
      
    var output = fmt"{selectedDir} - {now()} - Algorithm: {algoSelect.value}"
    output.add '\n'
    output.add '\n'
    for f in walkDir(selectedDir):
      if f.kind == pcFile:
        let
          contents = readFile(f.path)
          algo     = algoSelect.value
          hash     = algo.hashOfString(contents)
        output.add fmt"{hash}  {f.path}"
        output.add '\n'
        output.add '\n'
    writeFile(outPath, output)
  )

  
selectOutPathButton.let:
  it.onClick = (event: ClickEvent) => (
    var dialog = newSaveFileDialog()
    dialog.title       = "Select output for Mass Hash"
    dialog.run()
    outPath             = dialog.file
    selectedOutBox.text = dialog.file
  )

  
mainContainer.let:
  it.xAlign     = XAlign_Center
  it.heightMode = HeightMode_Expand
  it.add algoContainer
  
  var topLabel = newLabel("Hash a file")
  topLabel.let:
    it.fontSize = 28.0  
  it.add topLabel
  it.add selectFileContainer
  it.add hashContainer
  
  var spacer = newLayoutContainer(Layout_Vertical)
  spacer.let:
    it.height = 24
  it.add spacer
  
  var midLabel = newLabel("Mass Hash")
  midLabel.let:
    it.fontSize = 28.0
  it.add midLabel
  it.add selectDirContainer
  it.add massHashOutContainer

  
window.let:
  it.width  = 1000
  it.height = 800
  it.add mainContainer
  it.show()


app.run()
