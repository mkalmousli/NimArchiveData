


template `let`*(obj, ops) =
  block:
    var it {.inject.} = obj
    ops
    obj = it

